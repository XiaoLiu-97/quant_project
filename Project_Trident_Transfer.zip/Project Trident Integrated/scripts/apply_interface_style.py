"""Apply the compact interface's reusable style policy to a disposable workbook.

This authoring helper changes presentation only. It resolves Tables and owning
headers from the current named schema, preserves raw input and output payloads,
and appends reusable styles without changing existing style resources. The
normal model writer then inherits the formatted template on subsequent runs.
Native Excel open/save/reopen and rendered checks remain a separate QA step.

Example::
    python scripts/apply_interface_style.py --source TEMP/source.xlsx \
        --output TEMP/formatted.xlsx --evidence TEMP/style_changes.json
"""
from __future__ import annotations

import argparse
from copy import deepcopy
from dataclasses import dataclass
from hashlib import sha256
import json
from pathlib import Path
import sys
import xml.etree.ElementTree as ET

# Make this standalone maintenance command work from a fresh source checkout;
# there is no dependency on any external project or historical workbook.
PROJECT_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT_ROOT / "src"))
from trident.adapters.interface_package import (
    WorkbookPackage, TABLE_PREFIX, UI_PREFIX, _tag, _column, _coordinate,
    _bounds, _reference,
)
from trident.adapters import interface_inputs as owners
from trident.adapters.interface_reporting import DATE_FORMAT, FACE_FORMAT, CASH_FORMAT
from trident.domain.models import InputValidationError

DRAWING = "http://schemas.openxmlformats.org/drawingml/2006/main"
CHART = "http://schemas.openxmlformats.org/drawingml/2006/chart"


@dataclass(frozen=True)
class InterfacePalette:
    """Role and status colors; a valid input is not itself a failed test."""
    input_font: str = "FF195CA8"
    label_font: str = "FF18334D"
    reference_font: str = "FF5E6C78"
    failure_font: str = "FF9C0006"
    failure_fill: str = "FFFFC7CE"
    warning_font: str = "FF9C6500"
    warning_fill: str = "FFFFF2CC"
    inactive_font: str = "FF5E6C78"
    inactive_fill: str = "FFF2F2F2"


class StyleResources:
    """Append or reuse resources, preserving the meaning of every original ID.

    Existing financial number formats, fills, borders, and protection travel
    with the source cell. Only blank mixed-unit input capacity uses General:
    inheriting a percent/bps format could otherwise disguise a future value.
    """
    def __init__(self, package: WorkbookPackage) -> None:
        self.package = package
        self.root = package._xml("xl/styles.xml")
        self.fonts = self.root.find(_tag("fonts"))
        self.xfs = self.root.find(_tag("cellXfs"))
        if self.fonts is None or self.xfs is None:
            raise InputValidationError("The template must contain native fonts and cell styles")
        self.font_ids = {ET.tostring(item): i for i, item in enumerate(self.fonts)}
        self.style_ids = {ET.tostring(item): i for i, item in enumerate(self.xfs)}
        self.cache: dict[tuple[int, str | None, bool], int] = {}

    def cell_style(self, base: int, *, color: str | None = None,
                   general: bool = False) -> int:
        key = (base, color, general)
        if key in self.cache:
            return self.cache[key]
        if not 0 <= base < len(self.xfs):
            raise InputValidationError("Source style is outside the registered style array")
        style = deepcopy(self.xfs[base])
        if color is not None:
            font = deepcopy(self.fonts[int(style.get("fontId", "0"))])
            name = font.find(_tag("name"))
            if name is None:
                name = ET.SubElement(font, _tag("name"))
            name.set("val", "Arial")
            font_color = font.find(_tag("color"))
            if font_color is None:
                font_color = ET.SubElement(font, _tag("color"))
            font_color.attrib.clear()
            font_color.set("rgb", color)
            signature = ET.tostring(font)
            if signature not in self.font_ids:
                self.font_ids[signature] = len(self.fonts)
                self.fonts.append(font)
            style.set("fontId", str(self.font_ids[signature]))
            style.set("applyFont", "1")
        if general:
            style.set("numFmtId", "0")
            style.set("applyNumberFormat", "1")
        signature = ET.tostring(style)
        if signature not in self.style_ids:
            self.style_ids[signature] = len(self.xfs)
            self.xfs.append(style)
        result = self.style_ids[signature]
        self.cache[key] = result
        return result

    def table_body_style(self, base: int, *, color: str) -> int:
        """Let the named Table own striping, keeping each cell's units intact.

        A no-pattern fill alone is insufficient: a nonzero xfId can inherit a
        named style's white fill and suppress the Table stripe. Clear that base
        inheritance as well as direct fill. Explicit number format, borders,
        alignment and protection remain on the cell; no values are rewritten.
        Table banding then follows native sorting/filtering and future growth.
        """
        style = deepcopy(self.xfs[self.cell_style(base, color=color)])
        style.set("xfId", "0")
        style.set("fillId", "0")
        style.attrib.pop("applyFill", None)
        font = deepcopy(self.fonts[int(style.get("fontId", "0"))])
        size = font.find(_tag("sz"))
        if size is None:
            size = ET.SubElement(font, _tag("sz"))
        size.set("val", "10")
        font_signature = ET.tostring(font)
        if font_signature not in self.font_ids:
            self.font_ids[font_signature] = len(self.fonts)
            self.fonts.append(font)
        style.set("fontId", str(self.font_ids[font_signature]))
        signature = ET.tostring(style)
        if signature not in self.style_ids:
            self.style_ids[signature] = len(self.xfs)
            self.xfs.append(style)
        return self.style_ids[signature]

    def display_style(self, base: int, *, number_format: str | None = None,
                      wrapped_note: bool = False) -> int:
        """Clone requested display attributes while preserving input role colors.

        A settings Value column mixes dates, cash and ratios. Format follows
        each row's explicit Unit; raw numbers and posting precision stay intact.
        """
        style = deepcopy(self.xfs[base])
        if number_format is not None:
            if number_format == "General":
                identifier = 0
            else:
                formats = self.root.find(_tag("numFmts"))
                if formats is None:
                    formats = ET.Element(_tag("numFmts"), count="0")
                    self.root.insert(0, formats)
                match = next((item for item in formats
                              if item.get("formatCode") == number_format), None)
                if match is None:
                    identifier = max([163, *(int(item.get("numFmtId")) for item in formats)]) + 1
                    ET.SubElement(formats, _tag("numFmt"), numFmtId=str(identifier),
                                  formatCode=number_format)
                    formats.set("count", str(len(formats)))
                else:
                    identifier = int(match.get("numFmtId"))
            style.set("numFmtId", str(identifier))
            style.set("applyNumberFormat", "1")
        if wrapped_note:
            alignment = style.find(_tag("alignment"))
            if alignment is None:
                alignment = ET.SubElement(style, _tag("alignment"))
            alignment.attrib.update(horizontal="left", vertical="center", wrapText="1")
            style.set("applyAlignment", "1")
        signature = ET.tostring(style)
        if signature not in self.style_ids:
            self.style_ids[signature] = len(self.xfs)
            self.xfs.append(style)
        return self.style_ids[signature]

    def differential(self, font_color: str, fill_color: str) -> int:
        """Reuse a status-only differential format; ordinary role styling stays."""
        formats = self.root.find(_tag("dxfs"))
        if formats is None:
            formats = ET.Element(_tag("dxfs"), count="0")
            following = {_tag("tableStyles"), _tag("colors"), _tag("extLst")}
            index = next((i for i, item in enumerate(self.root) if item.tag in following), len(self.root))
            self.root.insert(index, formats)
        item = ET.Element(_tag("dxf"))
        font = ET.SubElement(item, _tag("font"))
        ET.SubElement(font, _tag("color"), rgb=font_color)
        fill = ET.SubElement(item, _tag("fill"))
        pattern = ET.SubElement(fill, _tag("patternFill"), patternType="solid")
        ET.SubElement(pattern, _tag("fgColor"), rgb=fill_color)
        # Native Excel reads differential fill colors through the background
        # color as well as the foreground. An automatic background can make
        # an otherwise correct, true CF rule display no fill at all.
        ET.SubElement(pattern, _tag("bgColor"), rgb=fill_color)
        signature = ET.tostring(item)
        for i, existing in enumerate(formats):
            if ET.tostring(existing) == signature:
                return i
        result = len(formats)
        formats.append(item)
        formats.set("count", str(len(formats)))
        return result

    def finish(self) -> None:
        self.fonts.set("count", str(len(self.fonts)))
        self.xfs.set("count", str(len(self.xfs)))
        self.package._put_xml("xl/styles.xml", self.root)


class InterfaceStylePlan:
    """Small, named-schema-based presentation operations, with no model math."""
    OWNERS = {
        "assets": owners.IDENTITY, "asset_terms": owners.TERMS,
        "asset_details": owners.DETAILS, "asset_ratings": owners.RATINGS,
        "pool": owners.POOL, "stack": owners.STACK,
        "trade_universe": owners.QUOTE, "factor_mapping": owners.FACTOR,
        "limits": owners.LIMIT, "scenario_edits": owners.SCENARIO,
        "principal_schedule": owners.PRINCIPAL, "asset_events": owners.EVENT,
    }
    FREEZE_TABLES = ("stack", "scenario_edits", "optimizer", "comparison", "checks")
    # This is conditional-format metadata capacity, not a financial horizon
    # and not physical cells. Future date columns remain colored without XFD.
    WATERFALL_STATUS_CAPACITY = 300
    MIXED_INPUTS = {("scenario_edits", "New value"), ("limits", "Threshold"), ("asset_events", "Value")}
    # Explicit values rather than containsText prevent 'NO BREACH' or
    # 'UNCHANGED INPUTS' from accidentally acquiring a failure/warning color.
    FAILURE = ("FAIL", "FAILED", "BREACH", "CHECK ID", "CHECK SELECTION")
    WARNING = ("UNAVAILABLE", "MISSING DATA", "MISSING_DATA", "BLOCKED",
               "INPUTS CHANGED", "INPUTS_CHANGED", "STALE", "REVIEW REQUIRED",
               "REVIEW_REQUIRED", "NOT CALCULATED", "NOT_CALCULATED")
    INACTIVE = ("NOT APPLICABLE", "NOT_APPLICABLE", "NOT CONFIGURED", "NOT_CONFIGURED",
                "NOT SELECTED", "NOT_SELECTED", "NOT REQUESTED", "NOT_REQUESTED",
                "NOT EVALUATED", "NOT_EVALUATED", "NOT SET", "N.A.", "N/A", "INACTIVE", "DISABLED")

    def __init__(self, package: WorkbookPackage, palette: InterfacePalette | None = None) -> None:
        self.package = package
        self.palette = palette or InterfacePalette()
        self.styles = StyleResources(package)
        self.tables = package.table_inventory()
        self.sheets = package._sheet_parts()
        self.trees: dict[str, ET.Element] = {}
        self.cells: dict[str, dict[str, ET.Element]] = {}
        self.rows: dict[str, dict[int, ET.Element]] = {}
        self.changed: set[str] = set()
        self.operations: list[dict[str, object]] = []

    def worksheet(self, name: str) -> ET.Element:
        if name not in self.trees:
            tree = self.package._xml(self.sheets[name])
            self.trees[name] = tree
            data = tree.find(_tag("sheetData"))
            self.rows[name] = {int(row.get("r")): row for row in data}
            self.cells[name] = {c.get("r"): c for row in data for c in row}
        return self.trees[name]

    def table(self, key: str):
        name = TABLE_PREFIX + key
        if name not in self.tables:
            raise InputValidationError(f"Required named style owner is missing: {name}")
        return self.tables[name]

    @staticmethod
    def populated(cell: ET.Element | None) -> bool:
        return cell is not None and any(cell.find(_tag(kind)) is not None for kind in ("v", "is", "f"))

    def inputs(self) -> None:
        """Use each owning column's established style for its blank capacity.

        Occupied values keep their existing numerical/date format, even when
        a first example elsewhere in the column uses a different unit. Derived
        lookup/status columns are intentionally excluded from editable colors.
        """
        for key, headers in self.OWNERS.items():
            info = self.table(key)
            self.worksheet(info.sheet)
            left, top, _, bottom = info.bounds
            count = 0
            for offset, header in enumerate(info.headers):
                if header not in headers:
                    continue
                column = _column(left + offset)
                first = self.cells[info.sheet].get(f"{column}{top + 1}")
                if first is None:
                    raise InputValidationError(f"Owning column has no style template: {info.name}/{header}")
                template_style = int(first.get("s", "0"))
                for row in range(top + 1, bottom + 1):
                    cell = self.cells[info.sheet].get(f"{column}{row}")
                    if cell is None:
                        # An absent physical cell is a true blank. A style-only
                        # cell does not create an asset/event/business record.
                        cell = ET.SubElement(self.rows[info.sheet][row], _tag("c"), r=f"{column}{row}")
                        self.cells[info.sheet][cell.get("r")] = cell
                    blank = not self.populated(cell)
                    base = template_style if blank else int(cell.get("s", "0"))
                    style = self.styles.cell_style(base, color=self.palette.input_font,
                        general=blank and (key, header) in self.MIXED_INPUTS)
                    if cell.get("s", "0") != str(style):
                        cell.set("s", str(style))
                        count += 1
            if count:
                self.changed.add(info.sheet)
                self.operations.append({"kind": "owning_input_styles", "table": info.name, "changed_cells": count})
        info = self.table("deal_assumptions")
        self.worksheet(info.sheet)
        left, top, _, bottom = info.bounds
        for offset, header in enumerate(info.headers):
            if header == "Value":
                # Existing four retained-reference Value styles deliberately
                # remain grey. They are not live aggregate overrides.
                continue
            for row in range(top + 1, bottom + 1):
                cell = self.cells[info.sheet].get(f"{_column(left+offset)}{row}")
                if cell is not None:
                    cell.set("s", str(self.styles.cell_style(int(cell.get("s", "0")), color=self.palette.label_font)))
        self.changed.add(info.sheet)
        self.operations.append({"kind": "readonly_assumption_labels", "table": info.name})

    def palettes(self) -> None:
        """Normalize whole Tables, rather than a few visible rows or sections.

        Section labels do not change a field's input/reference role. The four
        retained assumption values stay gray, owning inputs stay blue, and
        metadata stays dark. Native Table banding owns ordinary row fills.
        A conditional warning may still override a normal body color.
        """
        references = {"Collateral Purchase Price", "Purchased Accrued Interest",
                      "Reference Curve", "Collateral Cashflow Input Mode"}
        for key in ("deal_assumptions", "inherited_limits", "comparison_reader", "checks"):
            info = self.table(key)
            self.worksheet(info.sheet)
            records = self.package._table_records(info.name) if key == "deal_assumptions" else ()
            count = 0
            for row in range(info.bounds[1] + 1, info.bounds[3] + 1):
                retained = key == "deal_assumptions" and records[row-info.bounds[1]-1].get("Assumption") in references
                for offset, header in enumerate(info.headers):
                    address = f"{_column(info.bounds[0]+offset)}{row}"
                    cell = self.cells[info.sheet].get(address)
                    if cell is None:
                        if row not in self.rows[info.sheet]:
                            data = self.trees[info.sheet].find(_tag("sheetData"))
                            self.rows[info.sheet][row] = ET.SubElement(data, _tag("row"), r=str(row))
                        cell = ET.SubElement(self.rows[info.sheet][row], _tag("c"), r=address)
                        self.cells[info.sheet][address] = cell
                    base = int(cell.get("s", "0"))
                    if key == "deal_assumptions" and header == "Value":
                        color = self.palette.reference_font if retained else self.palette.input_font
                    else:
                        color = self.palette.label_font
                    # Retained values have an intentional gray fill. Clear both
                    # direct and inherited fills everywhere else, including the
                    # previously unstyled blank tail of expandable readers.
                    updated = (self.styles.cell_style(base, color=color) if retained and header == "Value"
                               else self.styles.table_body_style(base, color=color))
                    if updated != base:
                        cell.set("s", str(updated)); count += 1
            self.changed.add(info.sheet)
            self.operations.append({"kind":"whole_table_palette", "table":info.name,
                                    "rows":info.bounds[3]-info.bounds[1], "changed_cells":count})
        # Fixed settings were added with a different blue. Their shaded input
        # columns are intentional, but owning input text uses one common blue.
        settings = {"optimizer": {"Value"}, "pm_constraints": {"Value"},
                    "opening": {"Value", "Source"},
                    "opening_accounts": {"Balance (EUR)", "Source"},
                    "opening_fees": {"Unpaid (EUR)", "Source"}}
        for key, headers in settings.items():
            info = self.table(key); self.worksheet(info.sheet); count = 0
            records = self.package._table_records(info.name) if key == "opening" else ()
            for row in range(info.bounds[1]+1, info.bounds[3]+1):
                mirror = key == "opening" and records[row-info.bounds[1]-1].get("Opening parameter") in {"Workflow", "Equity value source"}
                for offset, header in enumerate(info.headers):
                    if header not in headers:
                        continue
                    cell = self.cells[info.sheet].get(f"{_column(info.bounds[0]+offset)}{row}")
                    if cell is None:
                        continue
                    if cell.find(_tag("f")) is not None and not mirror:
                        continue  # Other derived lookups retain their role.
                    base = int(cell.get("s", "0"))
                    # Home workflow mirrors can be saved as plain values,
                    # so formula detection alone does not establish ownership.
                    color = self.palette.label_font if mirror else self.palette.input_font
                    updated = self.styles.cell_style(base, color=color)
                    if updated != base:
                        cell.set("s", str(updated)); count += 1
            if count:
                self.changed.add(info.sheet)
            self.operations.append({"kind":"fixed_owning_input_palette", "table":info.name,
                                    "changed_cells":count})

    @staticmethod
    def setting_format(unit: object) -> str | None:
        """Interpret a registered display unit without any financial conversion."""
        unit = str(unit or "").strip().lower()
        return {"date": DATE_FORMAT, "eur face": FACE_FORMAT, "eur cash": CASH_FORMAT,
                "annual fraction": "0.00%;(0.00%);0.00%",
                "fraction": "0.00%;(0.00%);0.00%", "%": "0.00%;(0.00%);0.00%",
                "years": "#,##0.000", "hours": "#,##0", "months": "#,##0",
                "count": "#,##0", "periods": "#,##0", "factor": "#,##0", "bps": "0.0"}.get(unit)

    def setting_formats(self) -> None:
        """Format fixed-schema rows individually, including hidden witnesses.

        Unlike growing Scenario/Event Value columns, each fixed settings row
        declares its unit even when blank. Future dates/percentages therefore
        display usefully without changing values, formulas, validators or owners.
        """
        for key in ("optimizer", "pm_constraints", "opening", "frozen_optimizer",
                    "frozen_pm_constraints", "frozen_opening"):
            name = TABLE_PREFIX + key
            if name not in self.tables:
                continue
            info = self.tables[name]
            if "Value" not in info.headers or "Unit" not in info.headers:
                continue
            self.worksheet(info.sheet)
            column = _column(info.bounds[0] + info.headers.index("Value"))
            count = 0
            for offset, record in enumerate(self.package._table_records(name), start=1):
                display_format = self.setting_format(record.get("Unit"))
                if display_format is None:
                    continue
                address = f"{column}{info.bounds[1] + offset}"
                cell = self.cells[info.sheet].get(address)
                if cell is None:
                    cell = ET.SubElement(self.rows[info.sheet][info.bounds[1]+offset],
                                         _tag("c"), r=address)
                    self.cells[info.sheet][address] = cell
                current = int(cell.get("s", "0"))
                updated = self.styles.display_style(current, number_format=display_format)
                if updated != current:
                    cell.set("s", str(updated)); count += 1
            if count:
                self.changed.add(info.sheet)
                self.operations.append({"kind":"mixed_settings_by_unit", "table":name,
                                        "changed_cells":count})

    def note_lanes(self) -> None:
        """Wrap text in bounded lanes beside the corresponding named Table.

        Empty-lane checks protect neighboring selectors/data. Only blank space
        before the named Table header may be merged; the owning row positions
        stay fixed. The navigation gutter width similarly moves no cell data.
        """
        for key, final_column, height in (("stack", "N", 45), ("checks", "F", 60)):
            info = self.table(key); tree = self.worksheet(info.sheet)
            row_number = info.bounds[1] - 3
            start = _column(info.bounds[0]) + str(row_number)
            target = f"{start}:{final_column}{row_number}"
            left, top, right, bottom = _bounds(target)
            for column in range(left, right + 1):
                address = _column(column) + str(row_number)
                if address != start and self.populated(self.cells[info.sheet].get(address)):
                    raise InputValidationError(f"Note lane collides with content: {info.sheet}!{address}")
            merges = tree.find(_tag("mergeCells"))
            if merges is None:
                merges = ET.Element(_tag("mergeCells"))
                # Native worksheet order places mergeCells before conditional
                # formatting, validations and page setup, never after tableParts.
                following = {_tag(x) for x in ("phoneticPr", "conditionalFormatting",
                    "dataValidations", "hyperlinks", "printOptions", "pageMargins",
                    "pageSetup", "headerFooter", "drawing", "legacyDrawing", "tableParts", "extLst")}
                index = next((i for i,node in enumerate(tree) if node.tag in following),len(tree))
                tree.insert(index,merges)
            existing = [node.get("ref") for node in merges]
            if target not in existing:
                for reference in existing:
                    x1,y1,x2,y2 = _bounds(reference)
                    if not(right<x1 or left>x2 or bottom<y1 or top>y2):
                        raise InputValidationError(f"Note lane collides with merge: {info.sheet}!{reference}")
                ET.SubElement(merges,_tag("mergeCell"),ref=target)
                merges.set("count",str(len(merges)))
            note = self.cells[info.sheet][start]
            note.set("s",str(self.styles.display_style(int(note.get("s","0")),wrapped_note=True)))
            row=self.rows[info.sheet][row_number]
            row.set("ht",str(max(height,float(row.get("ht","15")))));row.set("customHeight","1")
            self.changed.add(info.sheet)
            self.operations.append({"kind":"bounded_explanatory_lane", "table":info.name,
                                    "reference":target, "height":height})
        optimizer = self.table("optimizer")
        # The analysis link occupies this empty separator after the settings
        # Table, so widening it cannot change any selector/data cell address.
        gutter = optimizer.bounds[2] + 1
        self.width(optimizer.sheet,gutter,15)
        self.operations.append({"kind":"navigation_gutter_width", "table":optimizer.name,
                                "column":_column(gutter), "width":15})

    def freeze(self) -> None:
        """Freeze through the actual named Table header, retaining ID columns."""
        for key in self.FREEZE_TABLES:
            info = self.table(key)
            tree = self.worksheet(info.sheet)
            view = tree.find(_tag("sheetViews")).find(_tag("sheetView"))
            pane = view.find(_tag("pane"))
            if pane is None:
                pane = ET.Element(_tag("pane"))
                view.insert(0, pane)
            x = int(float(pane.get("xSplit", "0")))
            pane.attrib.update(ySplit=str(info.bounds[1]), topLeftCell=f"{_column(x+1)}{info.bounds[1]+1}",
                               state="frozen", activePane="bottomRight" if x else "bottomLeft")
            for selection in view.findall(_tag("selection")):
                selection.set("pane", pane.get("activePane"))
            self.changed.add(info.sheet)
            self.operations.append({"kind": "freeze_through_named_header", "table": info.name, "rows": info.bounds[1]})
        if "_Results" in self.sheets:
            tree = self.worksheet("_Results")
            view = tree.find(_tag("sheetViews")).find(_tag("sheetView"))
            pane = view.find(_tag("pane"))
            if pane is None:
                pane = ET.Element(_tag("pane"))
                view.insert(0, pane)
            pane.attrib.update(ySplit="1", topLeftCell="A2", state="frozen", activePane="bottomLeft")
            self.changed.add("_Results")

    def width(self, sheet: str, column: int, minimum: float) -> None:
        """Enlarge a column while preserving hidden/outline/collapsed flags."""
        tree = self.worksheet(sheet)
        columns = tree.find(_tag("cols"))
        if columns is None:
            columns = ET.Element(_tag("cols"))
            tree.insert(list(tree).index(tree.find(_tag("sheetData"))), columns)
        old = next((item for item in columns if int(item.get("min")) <= column <= int(item.get("max"))), None)
        old_width = float(old.get("width", "8.43")) if old is not None else 8.43
        if old_width >= minimum:
            return
        replacement = deepcopy(old) if old is not None else ET.Element(_tag("col"))
        if old is not None:
            columns.remove(old)
            first, last = int(old.get("min")), int(old.get("max"))
            for a, b in ((first, column-1), (column+1, last)):
                if a <= b:
                    fragment = deepcopy(old)
                    fragment.set("min", str(a)); fragment.set("max", str(b)); columns.append(fragment)
        replacement.attrib.update(min=str(column), max=str(column), width=str(minimum), customWidth="1")
        replacement.attrib.pop("bestFit", None)
        columns.append(replacement)
        columns[:] = sorted(columns, key=lambda item: int(item.get("min")))
        self.changed.add(sheet)

    def table_widths(self, key: str, widths: dict[str, float]) -> None:
        info = self.table(key)
        for offset, header in enumerate(info.headers):
            if header in widths:
                self.width(info.sheet, info.bounds[0] + offset, widths[header])
        self.operations.append({"kind": "column_widths", "table": info.name, "fields": widths})

    def layout(self) -> None:
        for name, info in self.tables.items():
            if info.sheet == "_Results":
                for offset, header in enumerate(info.headers):
                    h = header.lower().replace("_", " ")
                    width = max(24, min(36, len(header)*0.7))
                    if "date" in h or h in {"accrual start", "accrual end"}: width = 18
                    if "key" in h: width = 58
                    if "metric" in h or h in {"name", "limit", "limit id"}: width = 46
                    if "status" in h or h == "result": width = 28
                    if "source" in h or "message" in h or "basis" in h: width = 58
                    self.width(info.sheet, info.bounds[0]+offset, width)
            elif info.sheet == "_Lists":
                for offset, header in enumerate(info.headers):
                    self.width(info.sheet, info.bounds[0]+offset, min(48, max(28, len(header)*0.75)))
                row = self.rows[info.sheet].get(info.bounds[1])
                if row is not None and float(row.get("ht", "15")) < 43:
                    row.attrib.update(ht="43", customHeight="1")
                    self.changed.add(info.sheet)
        self.table_widths("dashboard", {"Metric": 42, "Saved Base Case": 22, "Unit": 24, "Data status": 28})
        self.table_widths("metrics", {"Metric": 48, "Value": 22, "Unit": 24, "Coverage": 24, "Data status": 28})
        self.table_widths("limit_results", {"Limit": 48, "Result": 28})
        self.table_widths("economics", {"Economics metric": 48, "Value": 22, "Unit": 24, "Numerator": 24, "Denominator": 24, "Data status": 28})
        self.table_widths("concentrations", {"Dimension": 28, "Bucket": 36})
        self.table_widths("view_comparison", {"Key": 58, "Metric": 46, "Scenario": 26, "Status": 28, "Unit": 24})
        self.table_widths("view_coverage", {"Key": 44})
        self.table_widths("comparison", {"Metric": 46})
        account = self.table("view_accounts")
        self.table_widths("view_accounts", {h: max(28, min(38, len(h)*0.9)) for h in account.headers
            if "fee" in h or "status" in h or h == "reinvestment_strategy"})
        analysis = self.table("dashboard")
        self.worksheet(analysis.sheet)
        row = self.rows[analysis.sheet].get(analysis.bounds[1])
        row.attrib.update(ht=str(max(43, float(row.get("ht", "15")))), customHeight="1")
        self.changed.add(analysis.sheet)
        self.operations.append({"kind": "readable_hidden_headers_and_lanes", "sheet": "_Results"})

    def _add_cf(self, sheet: str, reference: str, rules: tuple[tuple[int, str], ...]) -> None:
        tree = self.worksheet(sheet)
        # A maintenance rerun must not duplicate named freshness banner rules.
        # Priority is execution order, not part of a rule's semantic identity.
        for existing in tree.findall(_tag("conditionalFormatting")):
            existing_rules = tuple((int(rule.get("dxfId", "-1")), rule.findtext(_tag("formula"), "")) for rule in existing)
            if existing.get("sqref") == reference and existing_rules == rules:
                return
        container = ET.Element(_tag("conditionalFormatting"), sqref=reference)
        for dxf_id, formula in rules:
            rule = ET.SubElement(container, _tag("cfRule"), type="expression", dxfId=str(dxf_id), priority="1", stopIfTrue="1")
            ET.SubElement(rule, _tag("formula")).text = formula
        # OOXML requires conditional formatting before validation/hyperlink/
        # drawing nodes. Native Excel rejects invalid ordering on file open.
        following = {_tag(k) for k in ("dataValidations", "hyperlinks", "printOptions", "pageMargins", "pageSetup", "headerFooter", "rowBreaks", "colBreaks", "customProperties", "cellWatches", "ignoredErrors", "smartTags", "drawing", "legacyDrawing", "legacyDrawingHF", "picture", "oleObjects", "controls", "webPublishItems", "tableParts", "extLst")}
        index = next((i for i, item in enumerate(tree) if item.tag in following), len(tree))
        tree.insert(index, container)
        self.changed.add(sheet)

    @staticmethod
    def _status_formula(cell: str, values: tuple[str, ...]) -> str:
        comparisons = ",".join(f'UPPER(TRIM({cell}))="{value}"' for value in values)
        return f"IFERROR(OR({comparisons}),FALSE)"

    def statuses(self) -> None:
        p = self.palette
        definitions = ((self.styles.differential(p.failure_font, p.failure_fill), self.FAILURE),
                       (self.styles.differential(p.warning_font, p.warning_fill), self.WARNING),
                       (self.styles.differential(p.inactive_font, p.inactive_fill), self.INACTIVE))
        targets: dict[str, set[str]] = {}
        fresh_name = UI_PREFIX + "input_freshness_status"
        fresh_formula = f'{fresh_name}="INPUTS CHANGED"'
        for sheet in self.sheets:
            if sheet == "Market Data": continue
            tree = self.worksheet(sheet)
            for container in list(tree.findall(_tag("conditionalFormatting"))):
                # Replace registered status rules, retaining any unrelated
                # data bars, scales, or future custom visualizations verbatim.
                target = container.get("sqref")
                # This named freshness banner is a registered special rule:
                # replace its style when the palette changes, but never feed
                # its long display sentence into ordinary enum status rules.
                banners = [rule for rule in container
                    if rule.get("type") == "expression" and rule.findtext(_tag("formula"), "") == fresh_formula]
                for rule in banners:
                    container.remove(rule)
                if banners:
                    self.changed.add(sheet)
                    if not len(container):
                        tree.remove(container)
                first = target.split()[0].split(":")[0]
                known_values = set(self.FAILURE + self.WARNING + self.INACTIVE)
                known_formulas = {self._status_formula(first, values) for _, values in definitions}
                recognized = [rule for rule in container
                    if (rule.get("type") == "containsText" and rule.get("text", "").strip().upper() in known_values)
                    or (rule.get("type") == "expression" and rule.findtext(_tag("formula"), "") in known_formulas)]
                if recognized:
                    # Unknown/custom expression rules remain intact, even if
                    # they share a container with the registered status rules.
                    for rule in recognized:
                        container.remove(rule)
                    if not len(container):
                        tree.remove(container)
                    if sheet == "Waterfall":
                        a,b,c,d = _bounds(target)
                        info = self.table("view_amortization")
                        capacity = max(self.WATERFALL_STATUS_CAPACITY, info.bounds[3] - info.bounds[1])
                        c = max(c, a + capacity - 1)
                        target = _reference((a,b,c,d))
                    targets.setdefault(sheet, set()).add(target)
                    self.changed.add(sheet)
        for info in self.tables.values():
            if info.sheet == "_Lists": continue
            for offset, header in enumerate(info.headers):
                if "status" in header.lower() or header in {"Result", "result"}:
                    col = info.bounds[0]+offset
                    targets.setdefault(info.sheet, set()).add(_reference((col,info.bounds[1]+1,col,info.bounds[3])))
        fresh_name = UI_PREFIX + "input_freshness_status"
        sheet, bounds = self.package.named_region(fresh_name)
        targets.setdefault(sheet, set()).add(_reference(bounds))
        for sheet, references in targets.items():
            for reference in sorted(references):
                first = reference.split(":")[0]
                self._add_cf(sheet, reference, tuple((dxf, self._status_formula(first, values)) for dxf,values in definitions))
        # Some freshness banners display a sentence rather than the raw enum.
        # Their status color must follow the named owner, not substring matches
        # against that sentence, and must not color 'UNCHANGED INPUTS' amber.
        for sheet in self.sheets:
            if sheet.startswith("_") or sheet == "Market Data": continue
            tree = self.worksheet(sheet)
            merges = tree.find(_tag("mergeCells"))
            for cell in self.cells[sheet].values():
                formula = cell.findtext(_tag("f"), "")
                if fresh_name not in formula: continue
                address = cell.get("r")
                reference = address
                x,y = _coordinate(address)
                for merge in merges if merges is not None else ():
                    a,b,c,d = _bounds(merge.get("ref"))
                    if a<=x<=c and b<=y<=d: reference = merge.get("ref"); break
                self._add_cf(sheet, reference, ((definitions[1][0], f'{fresh_name}="INPUTS CHANGED"'),))
        for sheet in self.changed:
            counter = 1
            for container in self.trees[sheet].findall(_tag("conditionalFormatting")):
                for rule in container:
                    rule.set("priority", str(counter)); counter += 1
        self.operations.append({"kind": "exact_status_and_freshness_rules", "targets": {k:len(v) for k,v in targets.items()}})

    def charts(self) -> None:
        """Readable title/legend/axis text; chart series and anchors stay exact."""
        for part in self.package.parts:
            if not part.startswith("xl/charts/chart") or not part.endswith(".xml"): continue
            root = self.package._xml(part)
            for node in root.iter():
                if node.tag == f"{{{CHART}}}title": size = "1100"
                elif node.tag == f"{{{CHART}}}legend": size = "900"
                elif node.tag in {f"{{{CHART}}}catAx", f"{{{CHART}}}valAx"}: size = "900"
                else: continue
                for prop in node.iter():
                    if prop.tag in {f"{{{DRAWING}}}defRPr", f"{{{DRAWING}}}rPr", f"{{{DRAWING}}}endParaRPr"}:
                        prop.set("sz", size)
            self.package._put_xml(part, root)
        self.operations.append({"kind": "native_chart_text", "title_points":11, "legend_points":9, "axis_points":9})

    def apply(self, *, palette_only: bool = False) -> list[dict[str, object]]:
        if not palette_only:
            self.inputs(); self.setting_formats(); self.freeze(); self.layout(); self.note_lanes(); self.statuses(); self.charts()
        self.palettes()
        self.styles.finish()
        for sheet in self.changed:
            # New blank styled cells are sorted so their transport order still
            # agrees with worksheet geometry and native Table access.
            for row in self.rows[sheet].values():
                row[:] = sorted(row, key=lambda cell:_coordinate(cell.get("r"))[0])
            data = self.trees[sheet].find(_tag("sheetData"))
            data[:] = sorted(data, key=lambda row: int(row.get("r")))
            self.package._put_xml(self.sheets[sheet], self.trees[sheet])
        return self.operations


def payload_signature(contents: bytes) -> str:
    """Hash actual cell types, raw values and formulas, excluding presentation."""
    root = ET.fromstring(contents)
    digest = sha256()
    for row in root.find(_tag("sheetData")):
        for cell in row:
            children = [ET.tostring(node) for node in cell if node.tag in {_tag("v"), _tag("is"), _tag("f")}]
            if not children: continue
            digest.update(json.dumps((cell.get("r"), cell.get("t"), [x.decode() for x in children]), ensure_ascii=False).encode())
    return digest.hexdigest()


def apply_interface_style(source: Path, output: Path, evidence: Path, *,
                          palette_only: bool = False) -> dict[str, object]:
    """Create an independently reviewable style-only workbook and evidence."""
    source, output = source.resolve(strict=True), output.resolve()
    if source == output:
        raise InputValidationError("Style authoring requires a separate disposable output file")
    before_hash = sha256(source.read_bytes()).hexdigest()
    package = WorkbookPackage(source)
    original = dict(package.parts)
    plan = InterfaceStylePlan(package)
    operations = plan.apply(palette_only=palette_only)
    # No formula/value rewrites are authorized here, including cached outputs.
    checks = {}
    for part in plan.sheets.values():
        checks[part] = payload_signature(original[part]) == payload_signature(package.parts[part])
    market = plan.sheets["Market Data"]
    checks["market_data_byte_identical"] = original[market] == package.parts[market]
    checks["named_interfaces_byte_identical"] = original["xl/workbook.xml"] == package.parts["xl/workbook.xml"]
    checks["tables_byte_identical"] = all(original[k] == package.parts[k] for k in original if k.startswith("xl/tables/"))
    checks["parts_unchanged"] = set(original) == set(package.parts)
    if not all(checks.values()):
        raise InputValidationError("Style-only mutation changed financial/input/formula payloads")
    package.save(output, overwrite=True)
    checks["source_unchanged"] = before_hash == sha256(source.read_bytes()).hexdigest()
    if not checks["source_unchanged"]:
        raise InputValidationError("Source workbook changed during style authoring")
    report = {"status":"PASS", "source":str(source), "output":str(output),
              "source_sha256":before_hash, "output_sha256":sha256(output.read_bytes()).hexdigest(),
              "operations":operations, "checks":checks,
              "changed_parts":sorted(k for k in original if original[k] != package.parts[k])}
    evidence.parent.mkdir(parents=True, exist_ok=True)
    evidence.write_text(json.dumps(report, indent=2, ensure_ascii=False), encoding="utf8")
    return report


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--evidence", type=Path, required=True)
    parser.add_argument("--palette-only", action="store_true", help="Normalize role colors and Table banding only")
    args = parser.parse_args()
    report = apply_interface_style(args.source, args.output, args.evidence, palette_only=args.palette_only)
    print(json.dumps({"status":report["status"], "output":report["output"], "sha256":report["output_sha256"], "changed_parts":len(report["changed_parts"])}))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
