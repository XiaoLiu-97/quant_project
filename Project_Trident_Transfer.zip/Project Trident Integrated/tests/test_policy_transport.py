"""Independent financial-policy transport checks for the audited interface."""

from dataclasses import replace
from decimal import Decimal
import unittest

from trident.adapters import excel_schema as current
from trident.adapters.legacy_model_records import legacy_model_request_from_records
from trident.analysis import MetricStatus
from trident.application.clo_services import TridentModelService
from trident.clo.models import PrincipalCouponPolicy
from trident.domain.models import CouponType, InputValidationError
from test_assumption_execution import small_inputs

D = Decimal


def audited_inputs(**overrides):
    assets, capital, controls, factors, provider = small_inputs()
    controls.update(schema_version="0.7", interest_diversion_test_end_date="2027-05-20")
    controls.update(overrides)
    capital = tuple(dict(row, interest_deferrable=False) for row in capital)
    return assets, capital, controls, factors, provider


def audited_request(**overrides):
    assets, capital, controls, factors, provider = audited_inputs(**overrides)
    return legacy_model_request_from_records(assets, capital, provider,
        controls=controls, factors=factors, limits=(), provenance="AUDIT_HAND")


class AuditedIntegrationTests(unittest.TestCase):

    def test_explicit_policy_transport_preserves_units(self):
        request = audited_request(interest_diversion_test_enabled=True,
            interest_diversion_test_class_id="A", interest_diversion_test_oc_minimum=D("1.75"),
            interest_diversion_test_max_fraction=D(".37"), principal_coupon_policy="ALL_CLASSES")
        self.assertEqual(request.clo_terms.interest_diversion_test_oc_minimum, D("1.75"))
        self.assertEqual(request.clo_terms.interest_diversion_test_max_fraction, D(".37"))
        self.assertIs(request.clo_terms.principal_coupon_policy, PrincipalCouponPolicy.ALL_CLASSES)
        self.assertTrue(request.clo_terms.include_deferred_interest_in_oc)
        self.assertFalse(request.notes[0].interest_deferrable)

    def test_missing_deferral_flag_cannot_silently_choose_payment_priority(self):
        assets, capital, controls, factors, provider = audited_inputs()
        capital = tuple({key: value for key, value in row.items() if key != "interest_deferrable"}
                        for row in capital)
        with self.assertRaises(InputValidationError):
            legacy_model_request_from_records(assets, capital, provider,
                controls=controls, factors=factors, limits=(), provenance="AUDIT_HAND")

    def test_current_ccc_mark_is_separate_from_global_acquisition_price(self):
        assets, capital, controls, factors, provider = audited_inputs(
            legacy_use_asset_level_test_data="Yes", legacy_collateral_purchase_price=D(".90"))
        assets = tuple(dict(row, is_ccc=True, is_discount=False,
                            oc_market_price_fraction=D(".60")) for row in assets)
        request = legacy_model_request_from_records(assets, capital, provider,
            controls=controls, factors=factors, limits=(), provenance="AUDIT_HAND")
        self.assertEqual(request.oc_asset_data[0].market_price_fraction, D(".60"))
        self.assertEqual(request.oc_asset_data[0].clean_price_fraction, D(".90"))
        result = TridentModelService().run(request)
        # 100 face, 7.5% allowance, 60% current mark: haircut92.5*.4=37.
        self.assertEqual(result.clo.periods[0].oc_ccc_haircut, D("37.00"))

    def test_native_coupon_metadata_is_verified_and_floating_was_is_available(self):
        request = audited_request()
        result = TridentModelService().run(request)
        self.assertEqual(result.opening_portfolio.metric("WAS_BPS").value, D(400))
        self.assertIs(result.opening_portfolio.metric("WAC_RATE").status, MetricStatus.UNAVAILABLE)
        conflicting = replace(request.exposures[0], coupon_type=CouponType.FIXED, fixed_coupon_rate=D(".1"))
        with self.assertRaisesRegex(InputValidationError, "coupon"):
            TridentModelService().run(replace(request, exposures=(conflicting,)))

    def test_fixed_contract_has_wac_without_fictitious_floating_spread(self):
        request = audited_request()
        position = request.cashflow_request.positions[0]
        terms = replace(position.terms, coupon_type=CouponType.FIXED, fixed_rate=D(".08"),
                        rate_index=None, spread_bps=D(0), index_floor=None)
        position = replace(position, terms=terms)
        exposure = replace(request.exposures[0], spread_bps=None,
                           coupon_type=CouponType.FIXED, fixed_coupon_rate=D(".08"))
        result = TridentModelService().run(replace(request,
            cashflow_request=replace(request.cashflow_request, positions=(position,)), exposures=(exposure,)))
        self.assertEqual(result.opening_portfolio.metric("WAC_RATE").value, D(".08"))
        self.assertIs(result.opening_portfolio.metric("WAS_BPS").status, MetricStatus.UNAVAILABLE)

    def test_new_policy_invalid_inputs_are_rejected(self):
        for values in ({"principal_coupon_policy":"UNKNOWN"},
                       {"interest_diversion_test_max_fraction":D("1.01")},
                       {"interest_diversion_test_enabled":True,"interest_diversion_test_class_id":"MISSING"}):
            with self.subTest(values=values), self.assertRaises((InputValidationError, ValueError)):
                TridentModelService().run(audited_request(**values))
