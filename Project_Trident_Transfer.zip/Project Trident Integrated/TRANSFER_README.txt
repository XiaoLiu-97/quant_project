Project Trident Integrated - Post-unzip environment setup
Software version: 0.12.3

Extract the complete ZIP into a company-approved writable folder. Open
PowerShell in the Project Trident Integrated folder containing pyproject.toml.
Follow docs/deployment.md for the full Chinese guide, offline installation,
Python command alternatives, VS Code setup and troubleshooting.

For the current pinned environment, use Python 3.12, Windows 64-bit AMD64.
The scipy==1.18.1 pin requires Python >=3.12. The package's broader Python3.11
source support is not compatibility with this pinned dependency combination.
A Python interpreter and third-party packages are not included in this ZIP.

Run these commands one at a time; continue only after each succeeds:
py -3.12 --version
py -3.12 -m venv .venv
.\.venv\Scripts\python.exe -m pip install -e ".[excel,optimization]" "openpyxl==3.1.5" "numpy==2.3.5" "scipy==1.18.1"
.\.venv\Scripts\python.exe -m pip check
.\.venv\Scripts\python.exe scripts/check_environment.py --profile model
.\.venv\Scripts\python.exe -m unittest discover -s tests
.\.venv\Scripts\python.exe -m trident check-model outputs/Project_Trident.xlsx --project

No Activate.ps1 or execution-policy change is needed for these commands.
Create the environment on the target computer; do not copy an old .venv.
Use approved company package sources. For fully offline installation,
docs/deployment.md explains the matching wheels and setuptools build dependency.

Save and close outputs/Project_Trident.xlsx in Excel. Double-click Run_Model.cmd.
After SUCCESS, reopen the workbook and review Checks, CLO Analysis and Waterfall.
The existing PDF can be opened without Python reporting packages.

TRANSFER_MANIFEST.json contains SHA256/size for every copied source file.
Source-machine paths in validation records are evidence, not runtime inputs.
