"""Independent regressions for financial policy transport and active sources."""

from dataclasses import replace
from decimal import Decimal
import unittest

from trident.adapters.legacy_model_records import legacy_model_request_from_records
from trident.application.clo_services import TridentModelService
from trident.application.construction import ClosingPoolRedesignService, ConstructionStatus
from trident.application.imported_cashflows import CollateralCashflowInputMode, DetailedImportedCashflow, compile_imported_cashflows
from trident.application.scenarios import ScenarioDefinition, ScenarioEdit, ScenarioTarget, _apply_edits
from trident.clo.lifecycle import AdjustedCollateralValuePolicy, OcAssetData
from trident.domain.models import InputValidationError
from trident.market import FlatRateProvider

from test_assumption_execution import small_inputs
from test_construction import fixture, CLOSE, FIRST


D = Decimal


def parsed(*, imported=False, full_accrued=False, acquired=D(0), price_floor=None, global_floor=D(0)):
    assets, capital, controls, factors, provider = small_inputs(
        legacy_purchased_accrued_interest=acquired,
        legacy_use_asset_level_test_data="No" if imported else "Yes",
        legacy_reinvestment_enabled="No",
        legacy_liability_reference_floor=global_floor,
    )
    # HAND is an explicitly normal credit fixture, not unknown classification.
    assets = tuple(dict(asset, is_ccc=False, is_discount=False) for asset in assets)
    if price_floor is not None:
        debt = dict(capital[0], coupon_type="FLOATING", rate_index="EURIBOR_3M", spread_bps=200,
                    fixed_rate=None, index_floor_bps=price_floor)
        capital = (debt, capital[1])
        provider = FlatRateProvider({"EURIBOR_3M": D("-.01")})
    simple = ()
    if imported:
        controls.update(collateral_projection_source="IMPORTED",
                        imported_cashflows_include_purchased_accrued=full_accrued,
                        legacy_collateral_cashflow_input_mode="Simplified")
        simple = ({"payment_date": "2027-05-20", "interest_proceeds": D(10) + acquired,
                   "principal_proceeds": D(100)},)
    return legacy_model_request_from_records(assets, capital, provider, controls=controls,
                                             factors=factors, limits=(), provenance="INDEPENDENT_REVIEW_TEST",
                                             simplified_records=simple)


class IntegrationReviewTests(unittest.TestCase):
    def test_exact_specific_floor_keeps_all_finite_digits(self):
        floor_bps = D("100.00000000000000000000000000000000001")
        request = parsed(price_floor=floor_bps)
        self.assertEqual(request.notes[0].index_floor, D(".010000000000000000000000000000000000001"))

    def test_missing_specific_floor_does_not_turn_negative_global_floor_into_zero(self):
        assets, capital, controls, factors, _ = small_inputs(legacy_liability_reference_floor=D("-.02"))
        debt = dict(capital[0], coupon_type="FLOATING", rate_index="EURIBOR_3M", spread_bps=300,
                    fixed_rate=None, index_floor_bps=None)
        request = legacy_model_request_from_records(assets, (debt, capital[1]),
            FlatRateProvider({"EURIBOR_3M": D("-.01")}), controls=controls, factors=factors, limits=(),
            provenance="NEGATIVE_REFERENCE_FLOOR_TEST")
        self.assertEqual(request.notes[0].index_floor, D("-.02"))

    def test_global_clean_price_retains_tail_for_cost_and_oc(self):
        price = D("1.00000000000000000000000000000000000001")
        assets, capital, controls, factors, provider = small_inputs(legacy_collateral_purchase_price=price)
        request = legacy_model_request_from_records(assets, capital, provider, controls=controls,
            factors=factors, limits=(), provenance="EXACT_PRICE_TEST")
        self.assertEqual(request.cashflow_request.purchases[0].clean_price_pct,
                         D("100.000000000000000000000000000000000001"))
        self.assertEqual(request.oc_asset_data[0].clean_price_fraction, price)

    def test_global_floor_preserves_higher_specific_note_floor_in_actual_coupon(self):
        request = parsed(price_floor=D(100), global_floor=D(0))
        self.assertEqual(request.notes[0].index_floor, D(".01"))
        result = TridentModelService().run(request)
        # Nov20→Feb22 is94 days; (max(-1%,1%)+2%)*60*94/360=.47.
        self.assertEqual(result.clo.tranche_periods[0].current_coupon_due, D(".47"))
        self.assertEqual(result.clo.tranche_periods[0].all_in_rate, D(".03"))

    def test_zero_accrued_imported_projection_is_accepted_and_reconciles_irr(self):
        result = TridentModelService().run(parsed(imported=True))
        self.assertEqual(result.cashflows.funding.equity_cash_funding, 40)
        self.assertEqual(result.clo.total_equity_distributions, 50)
        self.assertEqual(result.equity_moic.value, D("1.25"))
        self.assertEqual(result.clo.final_collateral_par, 0)

    def test_nonzero_imported_accrued_requires_full_entitlement_acknowledgement(self):
        with self.assertRaisesRegex(InputValidationError, "entitlement"):
            parsed(imported=True, acquired=D(2), full_accrued=False)
        result = TridentModelService().run(parsed(imported=True, acquired=D(2), full_accrued=True))
        # Source supplies10+2 historicalcoupon, not10+2+another2 engine extra.
        self.assertEqual(result.cashflows.funding.equity_cash_funding, 42)
        self.assertEqual(result.clo.total_equity_distributions, 52)
        self.assertEqual(sum(period.received_asset_interest for period in result.clo.periods), 12)

    def test_imported_asset_contract_what_if_cannot_claim_unchanged_source_as_new_cf(self):
        baseline = parsed(imported=True)
        for field, value in (("par", D(90)), ("spread_bps", D(900)), ("index_floor", D(".03"))):
            with self.subTest(field=field), self.assertRaisesRegex(InputValidationError, "refreshed imported"):
                _apply_edits(baseline, ScenarioDefinition("IMPORT_CHANGE", (ScenarioEdit(ScenarioTarget.ASSET, "HAND", field, value),)))

    def test_imported_cost_price_what_if_keeps_source_but_changes_real_funding(self):
        baseline = parsed(imported=True)
        target = _apply_edits(baseline, ScenarioDefinition("PRICE", (ScenarioEdit(ScenarioTarget.ASSET, "HAND", "clean_price_pct", D(90)),)))
        original = TridentModelService().run(baseline)
        changed = TridentModelService().run(target)
        self.assertIs(target.imported_collateral, baseline.imported_collateral)
        self.assertEqual(original.clo.total_equity_distributions, changed.clo.total_equity_distributions)
        self.assertEqual(original.cashflows.funding.equity_cash_funding - changed.cashflows.funding.equity_cash_funding, 10)

    def test_price_scenario_refreshes_oc_discount_value_and_funding_together(self):
        baseline = parsed()
        target = _apply_edits(baseline, ScenarioDefinition("DISCOUNT", (ScenarioEdit(ScenarioTarget.ASSET, "HAND", "clean_price_pct", D(70)),)))
        self.assertEqual(target.oc_asset_data[0].clean_price_fraction, D(".7"))
        old = TridentModelService().run(baseline)
        new = TridentModelService().run(target)
        self.assertEqual(old.clo.periods[0].adjusted_collateral_value, 100)
        self.assertEqual(new.clo.periods[0].adjusted_collateral_value, 70)
        self.assertEqual(old.cashflows.funding.equity_cash_funding - new.cashflows.funding.equity_cash_funding, 30)

    def test_imported_closing_redesign_rejected_before_false_target_returns(self):
        request = fixture()
        source = compile_imported_cashflows(CollateralCashflowInputMode.DETAILED, CLOSE, D(10000),
            detailed_rows=(DetailedImportedCashflow("OLD", 1, FIRST, D(10000), D(125), D(10000), D(0), D(10125)),))
        request = replace(request, baseline=replace(request.baseline, imported_collateral=source))
        with self.assertRaisesRegex(InputValidationError, "imported target cashflow"):
            ClosingPoolRedesignService().run(request)

    def test_new_candidate_needs_sourced_asset_level_oc_classification(self):
        request = fixture()
        baseline = replace(request.baseline,
            clo_terms=replace(request.baseline.clo_terms, adjusted_oc_policy=AdjustedCollateralValuePolicy(use_asset_level_test_data=True)),
            oc_asset_data=(OcAssetData("OLD", clean_price_fraction=D(1)),))
        result = ClosingPoolRedesignService().run(replace(request, baseline=baseline))
        self.assertIs(result.status, ConstructionStatus.REPLAY_FAILED)
        self.assertIsNone(result.target_result)
        self.assertTrue(any("sourced CCC/discount" in finding.message for finding in result.findings))


if __name__ == "__main__":
    unittest.main()
