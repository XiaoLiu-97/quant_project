"""Load versioned CSV/JSON examples without an Excel dependency."""

import csv
import json
from pathlib import Path

from trident.adapters.records import decimal_value, run_request_from_records
from trident.application.services import CashflowRunService, ProjectionResult
from trident.domain.models import InputValidationError
from trident.market.rates import FlatRateProvider


def read_csv_records(path: Path) -> tuple[dict[str, object], ...]:
    """Read explicit CSV headers, retaining blank fields for typed validation."""
    with path.open(encoding="utf-8-sig", newline="") as stream:
        reader = csv.DictReader(stream)
        headers = reader.fieldnames
        if headers is None or len(set(headers)) != len(headers):
            raise InputValidationError(f"Missing/duplicate CSV headers: {path.name}")
        rows = tuple(dict(row) for row in reader)
    if any(None in row for row in rows):
        raise InputValidationError(f"Unexpected extra CSV fields: {path.name}")
    return rows


def run_synthetic_example(directory: Path) -> ProjectionResult:
    """Run only explicitly labelled synthetic example data, not market fixtures."""
    directory = directory.resolve(strict=True)
    terms = json.loads((directory / "deal_terms.json").read_text(encoding="utf-8"))
    if terms.get("provenance", {}).get("classification") != "SYNTHETIC_ONLY":
        raise InputValidationError("CSV example runner requires SYNTHETIC_ONLY provenance")
    market = terms["market_data"]
    if market["provenance"] != "SYNTHETIC_FLAT_RATE_NOT_LIVE_DATA":
        raise InputValidationError("CSV example runner supports explicit flat scenario rates only")
    rate = decimal_value(market["index_rate_fraction"], "synthetic index rate")
    funding = terms["closing_sources_and_uses"]
    request = run_request_from_records(
        read_csv_records(directory / "assets.csv"), read_csv_records(directory / "capital_stack.csv"),
        FlatRateProvider({f"EURIBOR_{tenor}M": rate for tenor in (1, 3, 6)}),
        upfront_fees=decimal_value(funding["upfront_fees"], "upfront_fees"),
        cash_reserve=decimal_value(funding["cash_reserve_funding"], "cash_reserve"),
        rate_provenance="SYNTHETIC_FLAT_RATE_NOT_LIVE_DATA",
    )
    return CashflowRunService().run(request)
