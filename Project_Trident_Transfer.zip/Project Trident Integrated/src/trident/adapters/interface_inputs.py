"""Read the Project Trident 15-tab interface without Excel cache dependencies.

This adapter owns transport, joins and units, not financial calculations.  It
never saves a workbook and never opens an old model or a production fixture.
Only raw owning columns are inputs: selected-rating, Pool lookup and status
formulas are deliberately ignored.  Existing typed financial parsers validate
the resulting request, and the application layer separately runs/replays it.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass, replace
from datetime import date, datetime
from decimal import Decimal
from fractions import Fraction
from hashlib import sha256
import json
from pathlib import Path
from types import MappingProxyType
from typing import Mapping

from openpyxl import load_workbook
from openpyxl.utils.cell import range_boundaries
from openpyxl.utils.datetime import from_excel, to_excel

from trident.application.scenarios import ScenarioDefinition
from trident.clo.lifecycle import OcAssetData
from trident.clo.models import CloNoteCouponClaim, CloOpeningState
from trident.conventions import DayCount
from trident.domain.models import InputValidationError
from trident.domain.numeric import basis_points_rate
from trident.funding import FundingEngine
from trident.market.cash_accounts import (
    CashCurveRateProvider, DiscountFactorCashCurve, ZeroCompounding, ZeroRatePoint,
)
from trident.market.monthly import MonthlyProjectedRateCurve
from trident.market.rates import (
    CurveRateProvider, ExtrapolationPolicy, FlatRateProvider, ProjectedRateCurve, RatePoint,
)
from .candidate_records import timestamp_value
from .credit_records import credit_events_from_records
from .excel import NamedWorkbook
from .excel_model import WorkbookModelInputs, _freeze_records
from .legacy_inputs import LEGACY_INPUTS
from .legacy_model_records import legacy_model_request_from_records, legacy_values
from .model_records import factor_mapping_from_records, notes_from_records, optional_decimal, optional_text
from .pilot_workbook import seasoned_states_from_records
from .records import boolean_value, date_value, decimal_value, integer_value, run_request_from_records, text_value
from .scenario_records import scenarios_from_records

UI_PREFIX = "trident_ui_"
TABLE_PREFIX = "tbl_" + UI_PREFIX


@dataclass(frozen=True)
class InterfaceExecutionPolicy:
    """Versioned generic policy for terms absent from the compact interface.

    These are explicit package assumptions (included in the fingerprint), not
    unobserved deal facts or fallbacks to another workbook.  Defaults follow
    the typed engine's generic profile.  A caller may supply a reviewed custom
    profile; changes are detectable even if workbook values are unchanged.
    Market rates, quote cash, ratings, recovery and opening balances have no
    package defaults.  Out-of-range curves fail unless FLAT is explicit.
    """
    profile_id: str = "TRIDENT_GENERIC_UI_V1"
    clo_accrual_date_basis: str = "ADJUSTED"
    clo_end_of_month: bool = False
    management_fee_day_count: str = "ACT/360"
    senior_expenses_day_count: str = "ACT/365F"
    cash_account_day_count: str = "ACT/360"
    cash_account_fixing_lag_business_days: int = 0
    other_initial_source_type: str = "EXTERNAL_CONTRIBUTION"
    curve_extrapolation: str = "ERROR"


@dataclass(frozen=True)
class InterfaceWorkbookInputs(WorkbookModelInputs):
    """Immutable financial request plus normalized service-specific evidence."""
    library_assets: tuple[Mapping[str, object], ...] = ()
    candidate_assets: tuple[Mapping[str, object], ...] = ()
    candidate_metadata: tuple[Mapping[str, object], ...] = ()
    candidate_ratings: tuple[Mapping[str, object], ...] = ()
    quote_observations: tuple[Mapping[str, object], ...] = ()
    candidate_variants: tuple[Mapping[str, object], ...] = ()
    scenarios: tuple[ScenarioDefinition, ...] = ()
    input_fingerprint: str = ""
    input_snapshot: Mapping[str, object] = None
    execution_policy: InterfaceExecutionPolicy = InterfaceExecutionPolicy()
    warnings: tuple[str, ...] = ()
    input_ownership: Mapping[str, object] = None
    principal_schedule_records: tuple[Mapping[str, object], ...] = ()
    library_principal_schedule_records: tuple[Mapping[str, object], ...] = ()


# Header -> semantic field mapping is the complete owning-column contract.
# Adding a display/lookup column cannot quietly create an executable input.
IDENTITY = {
    "Asset ID": "loan_id", "Obligor ID": "obligor_id", "Asset type": "asset_class",
    "Financing type": "financing_type", "Currency": "currency", "Country": "country_code",
    "Sector": "sector", "Maturity": "maturity_date_unadjusted", "Credit status": "credit_status",
}
TERMS = {
    "Asset ID": "loan_id", "Schedule start": "cashflow_projection_start_date",
    "Coupon type": "coupon_type", "Index": "rate_index", "Spread (bps)": "spread_bps",
    "Fixed coupon (%)": "fixed_rate", "Index floor (bps)": "index_floor_bps",
    "Day count": "day_count", "Payment months": "frequency_months",
    "Reset months": "reset_frequency_months", "Principal strategy": "amortization_type",
    "Amortization reference face": "initial_par", "Seniority": "seniority",
    "Secured": "secured", "Recovery assumption (%)": "recovery_rate",
    "Recovery source": "recovery_rate_source", "Contract source": "contract_source",
}
DETAILS = {
    "Asset ID": "loan_id", "Amort fraction / period": "amortization_fraction_initial_par_per_period",
    "Amort periods": "amortization_periods_remaining", "First amort date": "amortization_first_date_unadjusted",
    "First payment": "first_payment_date_unadjusted", "Anchor day": "schedule_anchor_day",
    "End of month": "end_of_month", "Business-day rule": "business_day_convention",
    "Calendar": "holiday_calendar", "Accrual-date basis": "accrual_date_basis",
    "Fixing lag (business days)": "fixing_lag_target_business_days",
    "Payment lag (business days)": "payment_lag_business_days", "Stub": "stub_convention",
    "Last regular date": "last_regular_payment_date_unadjusted", "Cash / PIK mode": "interest_mode",
    "PIK share": "pik_fraction", "Balloon": "balloon_amount", "Scheduled principal": "scheduled_principal_amount",
    "Index cap (bps)": "index_cap_bps", "All-in floor (bps)": "all_in_floor_bps",
    "All-in cap (bps)": "all_in_cap_bps", "Amortization growth": "amortization_growth",
    "Construction risk": "construction_risk", "Revolver": "revolver", "PIK exposure": "pik",
    "Credit status as of": "credit_status_as_of", "Working sector system": "sector_system",
    "Classification source": "classification_source", "S&P industry": "sp_industry",
    "Moody's industry": "moodys_industry", "Classification as of": "classification_as_of",
    "Contract revision": "contract_revision",
}
RATINGS = {
    "Asset ID": "loan_id", "Agency": "agency", "Rating": "rating", "Rating level": "level",
    "Rating nature": "nature", "Subject ID": "subject_id", "Effective date": "as_of_date",
    "Source": "source", "Use for model": "use_for_model", "Factor system": "system",
    "Factor version": "version", "Selected bucket": "bucket", "Factor source": "factor_source",
}
POOL = {
    "Asset ID": "loan_id", "Held face (EUR)": "current_par", "Purchase price / 100": "purchase_price_pct",
    "Purchased accrued (EUR)": "acquired_accrued_interest", "Trade permission": "trade_permission",
    "Holding as of": "par_as_of_date", "CCC for this CLO": "is_ccc", "Discount for this CLO": "is_discount",
    "Classification source": "oc_classification_source", "Current OC mark / 100": "oc_mark_pct",
    "OC mark as of": "oc_mark_as_of", "OC mark source": "oc_mark_source",
}
STACK = {
    "Tranche": "class_id", "Priority": "payment_priority", "Type": "instrument_type",
    "Face (EUR)": "nominal_amount", "Issue price / 100": "issue_price_pct", "Coupon index": "rate_index",
    "Spread (bps)": "spread_bps", "OC minimum": "oc_minimum", "IC minimum": "ic_minimum",
    "Deferrable": "interest_deferrable", "PIK rate": "pik_rate_fraction", "Day count": "day_count",
    "Calendar": "holiday_calendar", "Opening unpaid coupon (EUR)": "unpaid_coupon", "Claim source": "claim_source",
}
QUOTE = {
    "Asset ID": "loan_id", "Allow buy": "allow_buy", "Allow sell": "allow_sell",
    "Bid / 100": "bid", "Ask / 100": "ask", "Bid size (EUR)": "bid_size", "Ask size (EUR)": "ask_size",
    "Settlement date": "settlement_date", "Quote time": "observed_at", "Quote source": "source",
    "Min ticket": "minimum_ticket", "Lot size": "lot_size", "Buy accrued / par": "buy_accrued",
    "Sell accrued / par": "sell_accrued", "Trade fees / par": "proportional_fee_per_par",
    "Quote quality": "quality", "Fixed BUY fee (EUR)": "buy_fixed_fee", "Fixed SELL fee (EUR)": "sell_fixed_fee",
}
FACTOR = {"System": "system", "Version": "version", "Bucket": "bucket", "Factor": "factor", "Is synthetic": "is_synthetic", "Source": "source"}
LIMIT = {"Limit ID": "limit_id", "Metric": "metric", "Direction": "direction", "Threshold": "threshold", "Applicable phase": "phases", "Enabled": "enabled"}
SCENARIO = {"Scenario ID": "scenario_id", "Change type": "target", "Entity ID": "identifier", "Field": "field", "New value": "value", "Enabled": "enabled", "Applies from": "applies_from", "New option": "option"}
PRINCIPAL = {"Asset ID": "loan_id", "Unadjusted payment date": "payment_date_unadjusted", "Principal amount": "amount", "Currency": "currency", "Case": "case", "Source / note": "source"}
EVENT = {"Asset ID": "loan_id", "Record type": "record_type", "Effective date": "effective_date", "Value": "value", "Unit": "unit", "Case": "case", "Source / note": "source"}
ACCOUNT_FIELDS = {
    "PRINCIPAL": "principal_cash", "INTEREST": "interest_cash", "RESERVE": "reserve",
    "PENDING_PRINCIPAL": "pending_principal_cash", "PENDING_INTEREST": "pending_interest_cash",
    "ORIGINAL_PRINCIPAL_REINVESTMENT": "original_principal_reinvestment_cash",
    "PENDING_ORIGINAL_PRINCIPAL_REINVESTMENT": "pending_original_principal_reinvestment_cash",
    "HELD_DIVERSION": "held_diversion_principal",
}
FEE_FIELDS = {"SENIOR_EXPENSES": "expense_arrears", "SENIOR_MANAGEMENT": "senior_management_fee_arrears", "SUBORDINATED_MANAGEMENT": "subordinated_management_fee_arrears", "DEFERRED_SENIOR_EXPENSES": "deferred_senior_expense_arrears"}
COVERAGE_FIELDS = (
    "include_deferred_interest_in_ic", "include_deferred_interest_in_oc", "principal_coupon_policy",
    "interest_diversion_test_enabled", "interest_diversion_test_class_id", "interest_diversion_test_oc_minimum",
    "interest_diversion_test_max_fraction", "interest_diversion_test_end_date", "interest_diversion_mode",
)
NON_CONTRACT = frozenset({"contract_source", "classification_source", "contract_revision", "credit_status_as_of", "classification_as_of", "sector_system", "sp_industry", "moodys_industry", "trade_permission", "oc_classification_source", "oc_mark_pct", "oc_mark_as_of", "oc_mark_source"})


def _scale(number: Decimal, power: int) -> Decimal:
    """Exact percent/bps transport independent of the caller's Decimal context."""
    parts = number.as_tuple()
    return Decimal((parts.sign, parts.digits, parts.exponent + power))


def _day_count(value: object, label: str) -> str:
    raw = text_value(value, label)
    aliases = {"ACT/365": "ACT/365F", "30/360": "30E/360"}
    raw = aliases.get(raw, raw)
    try:
        return (DayCount[raw] if raw in DayCount.__members__ else DayCount(raw)).value
    except ValueError as exc:
        raise InputValidationError(f"{label}: unsupported day count {raw!r}") from exc


def _index(rows, field: str, label: str) -> dict[str, dict[str, object]]:
    result = {}
    for row in rows:
        identity = text_value(row.get(field), f"{label} {field}")
        if identity in result:
            raise InputValidationError(f"Duplicate {label} identity: {identity}")
        result[identity] = dict(row)
    return result


def _canonical(value):
    if isinstance(value, Mapping):
        return {key: _canonical(item) for key, item in value.items()}
    if isinstance(value, (tuple, list)):
        return [_canonical(item) for item in value]
    if value is None:
        return {"blank": True}
    if isinstance(value, bool):
        return {"bool": value}
    if isinstance(value, datetime) and value.tzinfo is None and value.time() == datetime.min.time():
        return {"date": value.date().isoformat()}
    if isinstance(value, (date, datetime)):
        return {"date": value.isoformat()}
    if isinstance(value, (Decimal, int, float)):
        number=decimal_value(value,"fingerprint value")
        if number.is_zero():return {"number":"0"}
        sign,digits,exponent=number.as_tuple();digits=list(digits)
        while digits[-1]==0:digits.pop();exponent+=1
        return {"number":("-" if sign else "")+''.join(map(str,digits))+"e"+str(exponent)}
    return {"text": str(value)}


def _deep_freeze(value):
    if isinstance(value, Mapping):return MappingProxyType({key:_deep_freeze(item) for key,item in value.items()})
    if isinstance(value,(tuple,list)):return tuple(_deep_freeze(item) for item in value)
    return value


class InterfaceInputReader:
    """Load one immutable UI snapshot; no output writing or calculations.

    Passing an already-loaded normal openpyxl workbook is useful in tests.
    The reader closes only workbooks it loaded itself.  ``read_only=True``
    cannot expose Excel Table metadata, so the normal loader is used strictly
    for reading and no ``save``/input-migration method is ever called.
    """
    def __init__(self, source, *, policy: InterfaceExecutionPolicy | None = None):
        self.source = source
        self.policy = policy or InterfaceExecutionPolicy()
        self._raw: dict[str, object] = {}

    def _scalar(self, key: str):
        result = self.adapter.scalar(UI_PREFIX + key)
        self._raw["scalar:" + key] = result
        sheet,(l,t,r,b)=self.adapter.region(UI_PREFIX+key)
        from openpyxl.utils.cell import get_column_letter
        self._ownership["scalar:"+key]={"name":UI_PREFIX+key,"sheet":sheet.title,"ref":f"{get_column_letter(l)}{t}","mode":"RAW_INPUT"}
        return result

    def _optional_scalar(self, key: str, default):
        if UI_PREFIX + key not in self.adapter.workbook.defined_names:
            return default
        return self._scalar(key)

    def _date(self, value, label: str, *, optional: bool = False):
        if optional and value in (None, ""):
            return None
        # Only an explicitly registered calendar-date field may be an Excel
        # serial.  Never guess a numeric field's type from its magnitude.
        if isinstance(value, (int, float, Decimal)) and not isinstance(value, bool):
            value = from_excel(float(value), self.adapter.workbook.epoch)
        return date_value(value, label)

    def _records(self, key: str, fields: Mapping[str, str], *, optional=False):
        name = TABLE_PREFIX + key
        matches = [(s, t) for s in self.adapter.workbook for t in s.tables.values() if t.displayName.casefold() == name.casefold()]
        if not matches and optional:
            return ()
        sheet, table = self.adapter._table(name)
        bounds = range_boundaries(table.ref)
        left, top, right, bottom = bounds
        headers = [self.adapter._input_value(sheet.cell(top, col), name + " header") for col in range(left, right + 1)]
        if len(headers) != len(set(headers)) or tuple(headers) != tuple(c.name for c in table.tableColumns):
            raise InputValidationError(f"{name}: duplicate or mismatched Table headers")
        missing = set(fields) - set(headers)
        if missing:
            raise InputValidationError(f"{name}: missing owning columns {sorted(missing)}")
        # Registered aliases must cover the full actual table, including an
        # expanded table. This catches author-band aliases cropped on extension.
        alias = UI_PREFIX + key
        if alias in self.adapter.workbook.defined_names:
            alias_sheet, alias_bounds = self.adapter.region(alias)
            if alias_sheet.title != sheet.title or alias_bounds != bounds:
                raise InputValidationError(f"{alias}: name does not cover the full input Table")
        columns = {header: left + headers.index(header) for header in fields}
        rows = []
        for rowno in range(top + 1, bottom + 1):
            row = {target: self.adapter._input_value(sheet.cell(rowno, columns[header]), f"{name} row {rowno} {header}") for header, target in fields.items()}
            if any(value not in (None, "") for value in row.values()):
                rows.append(row)
        self._raw["table:" + key] = tuple(rows)
        self._ownership["table:"+key]={"table":name,"sheet":sheet.title,"ref":table.ref,"owning_columns":dict(fields),"data_rows":bottom-top,"mode":"RAW_INPUT_COLUMNS_ONLY"}
        return tuple(rows)

    def read(self) -> InterfaceWorkbookInputs:
        owned = isinstance(self.source, (str, Path))
        workbook = load_workbook(self.source, data_only=False, keep_links=False) if owned else (self.source.workbook if isinstance(self.source, NamedWorkbook) else self.source)
        try:
            self.adapter = NamedWorkbook(workbook)
            self._raw = {"execution_policy": asdict(self.policy)}
            self._warnings = []
            self._ownership = {}
            return self._read()
        finally:
            if owned:
                workbook.close()

    def _read(self) -> InterfaceWorkbookInputs:
        if text_value(self._scalar("schema"),"UI schema")!="1.0":
            raise InputValidationError("Unsupported Project Trident UI schema; expected1.0")
        controls = self._controls()
        values = legacy_values(controls)
        # Original-pool stress and synthetic reinvestment own different CPR
        # inputs. A nonzero rate behind a disabled switch is retained as user
        # input, but disclosed instead of silently enabling a financial policy.
        # Explicit dated prepayment events remain an independent asset path.
        if controls["mode"] == "CLO_BASELINE":
            if values["original_collateral_cpr"] and values["credit_prepayment_overlay"] != "On":
                self._warnings.append(
                    "Original Collateral CPR is nonzero, but Credit / Prepayment Overlay is Off: "
                    "the original-pool CPR assumption is inactive. Explicit dated asset events are separate."
                )
            if values["reinvestment_annual_prepayment_rate"] and values["reinvestment_enabled"] != "Yes":
                self._warnings.append(
                    "Annual Prepayment Rate belongs only to synthetic reinvestment assets. "
                    "Reinvestment Enabled is No, so no new synthetic purchases use this rate; "
                    "it does not apply to the original collateral pool."
                )
        factors = self._records("factor_mapping", FACTOR)
        for row in factors:
            text_value(row.get("source"), "factor mapping source")
        mapping = factor_mapping_from_records(factors)
        library, metadata, ratings = self._library(mapping)
        pool_rows = self._records("pool", POOL)
        pool = _index(pool_rows, "loan_id", "Collateral Pool")
        assets = []
        for identity, holding in pool.items():
            if identity not in library:
                raise InputValidationError(f"Pool Asset ID missing from Asset Library: {identity}")
            row = {**library[identity], **holding}
            row["par_as_of_date"] = self._date(row["par_as_of_date"], identity + " Holding as of")
            mark = optional_decimal(row["oc_mark_pct"], identity + " Current OC mark / 100")
            row["oc_market_price_fraction"] = None if mark is None else _scale(mark, -2)
            if mark is not None:
                mark_date = self._date(row["oc_mark_as_of"], identity + " OC mark as of")
                if mark_date != row["par_as_of_date"]:
                    raise InputValidationError(f"{identity}: current OC mark must match the held snapshot date")
                text_value(row["oc_mark_source"], identity + " OC mark source")
            for flag in ("is_ccc", "is_discount"):
                if row.get(flag) not in (None, ""):
                    row[flag] = boolean_value(row[flag], identity + " " + flag)
                    text_value(row["oc_classification_source"], identity + " CLO classification source")
            assets.append({k: v for k, v in row.items() if k not in NON_CONTRACT})
        if not assets:
            raise InputValidationError("Collateral Pool is empty")
        capital, claims = self._capital(values, controls)
        opening, equity_value, equity_source = self._opening(capital, claims, controls, values)
        library_principal, steps, credit_rows, recoveries, state_rows, fixing_rows, historical = self._schedules(library, pool)
        principal=tuple(row for row in library_principal if row["loan_id"] in pool)
        states = seasoned_states_from_records(state_rows, fixing_rows, tuple(assets))
        provider, provenance = self._market(controls, values, tuple(library.values()), historical)
        limits = self._records("limits", LIMIT)
        self._optimizer_limits(controls, values, mapping, limits, tuple(assets))
        # Avoid validating the legacy parser's transient aggregate purchase
        # against debt funding before replacing it. A conservative price equal
        # to the maximum entered per-asset price, and exact entered accrued,
        # cannot understate the corrected acquisition cash below. The final
        # returned request and equity hurdle use ONLY identified Pool purchases.
        parser_controls = dict(controls)
        parser_controls["legacy_collateral_purchase_price"] = _scale(max(decimal_value(row["purchase_price_pct"], "Pool purchase price") for row in assets), -2)
        parser_controls["legacy_purchased_accrued_interest"] = sum((decimal_value(row["acquired_accrued_interest"], "Pool acquired accrued") for row in assets), Decimal(0))
        request = legacy_model_request_from_records(tuple(assets), capital, provider, controls=parser_controls, provenance=provenance,
            factors=factors, limits=limits, principal_schedule_records=principal, coupon_step_records=steps,
            seasoned_states=states, clo_opening_state=opening, forward_equity_value=equity_value, equity_value_source=equity_source)
        # The reused legacy parser intentionally applies one aggregate purchase
        # assumption and one deal reference/day count.  The compact UI instead
        # owns identified acquisition cash and per-class coupons. Reconstruct
        # these objects explicitly so no entered financial field is ignored.
        cash = request.cashflow_request
        corrected_cash = run_request_from_records(tuple(assets), capital, provider, upfront_fees=cash.upfront_fees,
            cash_reserve=cash.cash_reserve, rate_provenance=provenance, principal_schedule_records=principal,
            coupon_step_records=steps, seasoned_states=states, existing_clo=opening is not None,
            closing_cost_budget=cash.closing_cost_budget, other_initial_uses=cash.other_initial_uses,
            other_initial_sources=cash.other_initial_sources, other_initial_source_type=cash.other_initial_source_type)
        if opening is not None:
            # A current opening snapshot does not purchase its existing loans,
            # issue debt or repay historical setup fees again. Keep acquisition
            # prices for OC classification, but transport no closing cash uses.
            # Earned coupon ownership is the independently sourced seasoned
            # state, not the historical acquired-accrued settlement cost.
            corrected_cash=replace(corrected_cash,
                purchases=tuple(replace(p,accrued_interest=Decimal(0)) for p in corrected_cash.purchases),
                upfront_fees=Decimal(0),cash_reserve=opening.reserve,closing_cost_budget=None,
                other_initial_uses=Decimal(0),other_initial_sources=Decimal(0),other_initial_source_type=None)
            self._warnings.append("Existing CLO excludes historic closing costs/sources and acquired-accrued purchase cost from forward cash; sourced opening coupon entitlements remain separate")
        terms = request.clo_terms
        notes = request.notes
        if terms is not None:
            notes = notes_from_records(capital, terms)
            # The global liability floor is a contractual lower bound. A future
            # explicit class floor may tighten it; it may not silently weaken it.
            floor = values["liability_reference_floor"]
            notes = tuple(replace(n, index_floor=max(floor, n.index_floor) if n.index_floor is not None else floor)
                          if n.coupon_type.value == "FLOATING" else n for n in notes)
            if opening is None:
                funding = FundingEngine().calculate(corrected_cash.purchases, corrected_cash.issues,
                    upfront_fees=corrected_cash.upfront_fees, cash_reserve=corrected_cash.cash_reserve,
                    other_initial_uses=corrected_cash.other_initial_uses, other_initial_sources=corrected_cash.other_initial_sources,
                    other_initial_source_type=corrected_cash.other_initial_source_type, closing_cost_budget=corrected_cash.closing_cost_budget)
                terms = replace(terms, incentive_initial_equity_funding=funding.equity_cash_funding)
        oc_data = tuple(OcAssetData(row["loan_id"], False if row.get("is_ccc") in (None, "") else boolean_value(row["is_ccc"], "is_ccc"),
            False if row.get("is_discount") in (None, "") else boolean_value(row["is_discount"], "is_discount"),
            _scale(decimal_value(row["purchase_price_pct"], "purchase_price_pct"), -2),
            market_price_fraction=optional_decimal(row.get("oc_market_price_fraction"), "oc_market_price_fraction")) for row in assets)
        credit = credit_events_from_records(credit_rows, recoveries, loan_ids=frozenset(pool))
        request = replace(request, cashflow_request=corrected_cash, notes=notes, clo_terms=terms, oc_asset_data=oc_data, credit_events=credit)
        scenarios, scenario_rows = self._scenarios()
        if opening is not None and controls["candidate_search_enabled"]:
            raise InputValidationError("Full candidate IRR search supports closing redesign only; Existing CLO may use static portfolio research and the opening scenario service")
        quote_rows, observations, candidate_assets, candidate_metadata, candidate_ratings = self._quotes(library, metadata, ratings, pool, controls)
        variants = self._variants()
        # Normalization validates scenario types before financial execution.
        controls["scenario_enabled"] = bool(scenarios)
        digest = sha256(json.dumps(_canonical(self._raw), sort_keys=True, ensure_ascii=False, separators=(",", ":")).encode("utf-8")).hexdigest()
        return InterfaceWorkbookInputs(request, MappingProxyType(controls), _freeze_records(tuple(assets)), _freeze_records(capital),
            _freeze_records(quote_rows), _freeze_records(scenario_rows), _freeze_records(steps), _freeze_records(state_rows), _freeze_records(fixing_rows),
            _freeze_records(tuple(library.values())), _freeze_records(candidate_assets), _freeze_records(candidate_metadata),
            _freeze_records(candidate_ratings), _freeze_records(observations), _freeze_records(variants), scenarios, digest,
            _deep_freeze(self._raw), self.policy, tuple(self._warnings), _deep_freeze(self._ownership),
            _freeze_records(principal),_freeze_records(library_principal))

    def _controls(self):
        rows = self._records("deal_assumptions", {"Assumption": "label", "Value": "value"})
        indexed = {}
        for row in rows:
            indexed.setdefault(text_value(row["label"], "Assumption label"), []).append(row)
        legacy_counts = {field.label:sum(other.label==field.label for other in LEGACY_INPUTS) for field in LEGACY_INPUTS}
        controls = {}
        for field in LEGACY_INPUTS:
            if field.label not in indexed:
                raise InputValidationError(f"Missing owned legacy assumption: {field.label}")
            if len(indexed[field.label]) != legacy_counts[field.label]:
                raise InputValidationError(f"Missing/duplicate owned legacy assumption: {field.label}")
            if legacy_counts[field.label] == 1:
                value = indexed[field.label][0]["value"]
            else:
                # Three labels occur once for original collateral and once
                # for reinvestment. Display sections explain the distinction;
                # registered field-ID names disambiguate their input owners.
                named_sheet,(left,top,right,bottom)=self.adapter.region(UI_PREFIX+field.field_id)
                main_sheet,main_table=self.adapter._table(TABLE_PREFIX+"deal_assumptions")
                ml,mt,mr,mb=range_boundaries(main_table.ref)
                headers=[main_sheet.cell(mt,c).value for c in range(ml,mr+1)]
                value_column=ml+headers.index("Value")
                label_column=ml+headers.index("Assumption")
                if named_sheet.title != main_sheet.title or (left,top)!=(right,bottom) or left!=value_column or not mt<top<=mb or main_sheet.cell(top,label_column).value != field.label:
                    raise InputValidationError(f"{field.field_id}: scalar must identify its owning labelled Value cell")
                value=self._scalar(field.field_id)
            if field.semantic_type == "DATE":
                value = self._date(value, field.field_id)
            elif field.semantic_type in {"DECIMAL", "MONEY", "INTEGER"} and isinstance(value, (date, datetime)):
                # An accidentally inherited date number format must not alter
                # the financial value. Recover its underlying Excel number.
                value = to_excel(value, self.adapter.workbook.epoch)
            controls["legacy_" + field.field_id] = value
        for key in COVERAGE_FIELDS:
            controls[key] = self._scalar(key)
        controls["interest_diversion_test_end_date"] = self._date(controls["interest_diversion_test_end_date"], "IDT end date", optional=True)
        workflow = text_value(self._scalar("workflow"), "Home workflow")
        if workflow not in {"New Issue", "Existing CLO", "Asset Cashflows"}:
            raise InputValidationError("Home workflow must be New Issue, Existing CLO or Asset Cashflows")
        controls.update(asdict(self.policy))
        controls.update(workflow=workflow, mode="CASHFLOW_ONLY" if workflow == "Asset Cashflows" else "CLO_BASELINE",
            collateral_projection_source="INTERNAL_ENGINE", optimizer_enabled=boolean_value(self._optional_scalar("optimizer_enabled",False),"Static portfolio research enabled"),
            valuation_date=self._date(self._scalar("market_date"), "Market Data as of"),
            curve_extrapolation=self._optional_scalar("curve_extrapolation", self.policy.curve_extrapolation))
        controls["market_curve_as_of"] = controls["valuation_date"]
        if self._scalar("market_mode") == "SYNTHETIC_FLAT":
            # Flat rates are explicitly hypothetical. The untouched paste-area
            # B3 date does not turn their scenario anchor into observed data.
            controls["valuation_date"] = controls["legacy_pricing_date"]
        setting_rows = self._records("optimizer", {"Setting / constraint": "label", "Value": "value"})
        settings = _index(setting_rows, "label", "Optimization settings")
        settings_map = {
            "Candidate search enabled": "candidate_search_enabled", "Selection objective": "candidate_selection_policy",
            "Linear candidate objective": "optimizer_objective", "Target collateral par": "optimizer_target_par",
            "Declared incremental cash": "optimizer_starting_cash", "Minimum cash after trades": "optimizer_minimum_cash",
            "Gross BUY + SELL par cap": "optimizer_maximum_trade_par", "Settlement / closing date": "optimizer_settlement_date",
            "Minimum candidate equity IRR": "candidate_minimum_equity_irr", "Quote snapshot ID": "candidate_snapshot_id",
            "Captured at (timezone)": "candidate_snapshot_captured_at", "Snapshot source": "candidate_snapshot_source",
            "Maximum quote age": "candidate_maximum_quote_age_hours", "Admitted quote quality": "candidate_allowed_quote_qualities",
        }
        for label, key in settings_map.items():
            if label not in settings:
                raise InputValidationError(f"Missing Optimization setting: {label}")
            controls[key] = settings[label]["value"]
        controls["candidate_search_enabled"] = boolean_value(controls["candidate_search_enabled"], "Candidate search enabled")
        if controls["candidate_search_enabled"] and controls["optimizer_enabled"]:
            raise InputValidationError("Select only one optimization mode: Static portfolio research or Closing candidate search")
        controls["optimizer_settlement_date"] = self._date(controls["optimizer_settlement_date"], "Optimizer settlement date")
        if controls["optimizer_objective"] not in {"MIN_FACTOR", "MAX_SPREAD"}:
            raise InputValidationError("Linear objective must be MIN_FACTOR or MAX_SPREAD")
        if controls["candidate_selection_policy"] not in {"MAX_EQUITY_IRR", "MIN_FACTOR_THEN_IRR"}:
            raise InputValidationError("Unknown candidate selection objective")
        pm = _index(self._records("pm_constraints", {"Constraint": "label", "Value": "value"}), "label", "PM constraints")
        for label, field in {"Maximum overall factor": "maximum_overall_factor", "Maximum BSL factor": "maximum_bsl_factor",
            "Minimum quoted spread": "minimum_spread_bps", "Maximum sector share": "maximum_sector_share",
            "Maximum obligor share": "maximum_obligor_share", "Maximum country share": "maximum_country_share"}.items():
            if label not in pm:
                raise InputValidationError(f"Missing PM constraint: {label}")
            controls["optimizer_" + field] = pm[label]["value"]
        # Composition has one owner: the deal-limit table. Resolve it only
        # once in _optimizer_limits, after the actual snapshot phase is known;
        # an inactive future covenant must not become an apparent PM override.
        controls["optimizer_maximum_bsl_share"] = None
        controls["optimizer_minimum_infra_share"] = None
        return controls

    def _optimizer_limits(self, controls, values, mapping, limits, assets):
        """Intersect supported static bounds with applicable owning deal limits.

        A PM maximum may tighten but never relax an active legal maximum;
        analogous minimums use max. Other path-dependent/unsupported metrics
        remain on request.limits for the full replay and are not presented as
        LP constraints. TEST averages are never silently called agency WARF.
        """
        dates={row["par_as_of_date"] for row in assets}
        if len(dates)!=1:
            raise InputValidationError("Static opening holdings require one common snapshot date")
        snapshot=next(iter(dates))
        # Match application.portfolio_phases exactly: the reinvestment end
        # date itself is POST_REINVESTMENT, and that canonical phase name is
        # what the owning limit table uses for its date-specific restrictions.
        phase="CLOSING" if controls["workflow"]!="Existing CLO" else ("REINVESTMENT" if snapshot<values["reinvestment_end_date"] else "POST_REINVESTMENT")
        active=[]
        for row in limits:
            if not boolean_value(row["enabled"],"limit enabled"):continue
            phases=optional_text(row["phases"],"limit phases")
            if phases and phase not in tuple(x.strip() for x in phases.split(",")):continue
            active.append(row)
        metrics={"maximum_obligor_share":("LARGEST_OBLIGOR_FRACTION","MAXIMUM"),
            "maximum_country_share":("LARGEST_COUNTRY_FRACTION","MAXIMUM"),
            "maximum_sector_share":("LARGEST_SECTOR_FRACTION","MAXIMUM"),
            "maximum_bsl_share":("concentration:asset_class:BSL","MAXIMUM"),
            "minimum_infra_share":("concentration:asset_class:INFRA","MINIMUM"),
            "minimum_spread_bps":("WAS_BPS","MINIMUM"),
            "maximum_overall_factor":("TEST_FACTOR_AVERAGE" if mapping and mapping.is_synthetic else "WARF","MAXIMUM"),
            "maximum_bsl_factor":("BSL_TEST_FACTOR_AVERAGE" if mapping and mapping.is_synthetic else "BSL_WARF","MAXIMUM")}
        inherited={"maximum_obligor_share":values["maximum_single_obligor"],"maximum_sector_share":values["maximum_industry"],"minimum_spread_bps":_scale(values["minimum_collateral_was"],4)}
        if mapping is not None and not mapping.is_synthetic:inherited["maximum_overall_factor"]=values["maximum_portfolio_warf"]
        for key,(metric,direction) in metrics.items():
            choices=[]
            own=optional_decimal(controls.get("optimizer_"+key),key)
            if own is not None:choices.append(own)
            if key in inherited:choices.append(inherited[key])
            choices.extend(decimal_value(row["threshold"],"legal "+metric) for row in active if row["metric"]==metric and row["direction"]==direction)
            controls["optimizer_"+key]=(min(choices) if direction=="MAXIMUM" else max(choices)) if choices else None
        controls["optimizer_limit_inheritance_scope"]=phase
        supported_pairs=set(metrics.values())
        unmapped=[row["limit_id"] for row in active if (row["metric"],row["direction"]) not in supported_pairs]
        unmapped.extend(("LEGACY_MINIMUM_COLLATERAL_WARR","LEGACY_MAXIMUM_COLLATERAL_WAL","LEGACY_LONG_DATED_ASSET_LIMIT_FRACTION"))
        if mapping is None or mapping.is_synthetic:unmapped.append("LEGACY_MAXIMUM_PORTFOLIO_WARF")
        controls["optimizer_unmapped_limit_ids"]=tuple(unmapped)
        controls["optimizer_scope"]="STATIC_SUPPORTED_CONSTRAINTS_ONLY; NO_EXECUTED_TRADES; NO_CLO_IRR_OPTIMUM"
        if controls["optimizer_enabled"]:
            self._warnings.append("Static research enforces only supported linear/discrete constraints; remaining deal limits require full portfolio/CLO replay: "+", ".join(unmapped))
        self._raw["normalization:optimizer_limit_inheritance_scope"]=phase

    def _library(self, mapping):
        identity = _index(self._records("assets", IDENTITY), "loan_id", "Asset Library identity")
        terms = _index(self._records("asset_terms", TERMS), "loan_id", "Asset Library terms")
        details = _index(self._records("asset_details", DETAILS), "loan_id", "Asset Library details")
        if set(identity) != set(terms) or set(identity) != set(details):
            raise InputValidationError("Asset Library identity, terms and details must have exactly matching unique Asset IDs")
        rating_rows = self._records("asset_ratings", RATINGS)
        selected, factor_rows = {}, {}
        for row in rating_rows:
            key = text_value(row.get("loan_id"), "rating Asset ID")
            if key not in identity:
                raise InputValidationError(f"Rating refers to unknown Asset ID: {key}")
            if boolean_value(row["use_for_model"], key + " Use for model"):
                if key in selected:
                    raise InputValidationError(f"More than one Use for model rating for Asset ID: {key}")
                selected[key] = row
            if any(row.get(k) not in (None, "") for k in ("system", "version", "bucket")):
                for k in ("system", "version", "bucket", "factor_source"):
                    text_value(str(row[k]) if k == "version" and row[k] is not None else row[k], key + " factor " + k)
                if key in factor_rows:
                    raise InputValidationError(f"More than one declared factor designation for Asset ID: {key}")
                factor_rows[key] = row
        library, metadata = {}, {}
        for key in identity:
            row = {**identity[key], **terms[key], **details[key]}
            for field in ("cashflow_projection_start_date", "maturity_date_unadjusted"):
                row[field] = self._date(row[field], key + " " + field)
            for field in ("amortization_first_date_unadjusted", "first_payment_date_unadjusted", "last_regular_payment_date_unadjusted"):
                row[field] = self._date(row[field], key + " " + field, optional=True)
            row["day_count"] = _day_count(row["day_count"], key + " Day count")
            # Baseline Library leaves an optional CASH/PIK selector blank for a
            # cash-only contract. Native parser's default CASH is explicit here.
            if row.get("interest_mode") in (None, ""):
                if row.get("pik") is True or row.get("pik_fraction") not in (None, "", 0):
                    raise InputValidationError(f"{key}: PIK requires an explicit Cash / PIK mode")
                row["interest_mode"] = "CASH"
            row["rating_agency"] = None
            row["agency_rating"] = None
            chosen = selected.get(key)
            if chosen is not None:
                # Selecting an incomplete row reports unavailable rating; no
                # agency or rating is fabricated from TEST buckets or factors.
                row["rating_agency"] = optional_text(chosen["agency"], key + " selected agency")
                row["agency_rating"] = optional_text(chosen["rating"], key + " selected rating")
                if (row["rating_agency"] is None) != (row["agency_rating"] is None):
                    raise InputValidationError(f"{key}: selected rating requires both Agency and Rating")
            designated = factor_rows.get(key)
            if designated is not None:
                if mapping is None:
                    raise InputValidationError(f"{key}: declared factor bucket has no owning Factor Mapping")
                if (designated["system"], str(designated["version"])) != (mapping.system, mapping.version):
                    raise InputValidationError(f"{key}: factor system/version differs from selected mapping")
                if designated["bucket"] not in mapping.factors:
                    raise InputValidationError(f"{key}: unmapped factor bucket {designated['bucket']}")
                if mapping.is_synthetic:
                    row["test_factor_system"], row["test_factor_bucket"] = mapping.system, designated["bucket"]
                else:
                    row["rating_system"], row["rating_version"], row["rating_bucket"] = mapping.system, mapping.version, designated["bucket"]
            if row.get("recovery_rate") not in (None, ""):
                text_value(row.get("recovery_rate_source"), key + " recovery source")
            metadata[key] = {k: row.get(k) for k in NON_CONTRACT}
            library[key] = {k: v for k, v in row.items() if k not in NON_CONTRACT}
        missing_ratings=sum(row.get("agency_rating") in (None,"") for row in library.values())
        missing_recovery=sum(row.get("recovery_rate") in (None,"") for row in library.values())
        if missing_ratings:self._warnings.append(f"{missing_ratings} Library assets have no selected agency rating; rating-based metrics remain unavailable")
        if missing_recovery:self._warnings.append(f"{missing_recovery} Library assets have no sourced asset-level recovery; WARR remains unavailable (global stress recovery is separate)")
        return library, metadata, rating_rows

    def _capital(self, values, controls):
        records = self._records("stack", STACK)
        _index(records, "class_id", "Capital Stack")
        capital, claims = [], {}
        count = int(values["payment_frequency"].replace("M", ""))
        payment_bdc = {"Modified Following": "MODIFIED_FOLLOWING", "Following": "FOLLOWING", "Unadjusted": "UNADJUSTED"}[values["payment_date_convention"]]
        for original in records:
            row = dict(original)
            key = text_value(row["class_id"], "Tranche")
            claims[key] = {"unpaid_coupon": row.pop("unpaid_coupon"), "source": row.pop("claim_source")}
            if row["instrument_type"] not in {"DEBT", "EQUITY"}:
                raise InputValidationError(f"{key}: Capital Stack Type must be DEBT or EQUITY")
            row.update(currency=values["base_currency"], frequency_months=count,
                schedule_anchor_day=values["first_note_payment_date"].day,
                business_day_convention=payment_bdc, accrual_date_basis=controls["clo_accrual_date_basis"],
                fixing_lag_target_business_days=values["rate_fixing_lag"])
            if row["instrument_type"] == "DEBT":
                # A nonempty native index is FLOATING. The current compact
                # Stack has no fixed-coupon input, so FIXED cannot be guessed.
                row["rate_index"] = text_value(row["rate_index"], key + " Coupon index").replace(" ", "_")
                if row["rate_index"] not in {"EURIBOR_1M", "EURIBOR_3M", "EURIBOR_6M"}:
                    raise InputValidationError(f"{key}: supported floating note index required; fixed note input is not present")
                row["coupon_type"] = "FLOATING"
                row["day_count"] = _day_count(row["day_count"], key + " Day count")
            else:
                row["coupon_type"] = "NONE"
            capital.append(row)
        return tuple(capital), claims

    def _opening(self, capital, claims, controls, values):
        # The first/last Value cells are Excel mirrors. Read the raw owning
        # values of the other seven parameters, including source R17, directly.
        parameters = self._records("opening", {"Opening parameter": "label", "Source": "source"})
        sheet, table = self.adapter._table(TABLE_PREFIX + "opening")
        l,t,r,b = range_boundaries(table.ref)
        headers = [sheet.cell(t,c).value for c in range(l,r+1)]
        vc = l + headers.index("Value")
        parsed = {}
        for rowno in range(t+1,b+1):
            label = self.adapter._input_value(sheet.cell(rowno,l), "opening label")
            if label in {"Workflow", "Equity value source"}:
                continue
            source = next((row["source"] for row in parameters if row["label"] == label), None)
            parsed[label] = {"label":label, "value":self.adapter._input_value(sheet.cell(rowno,vc), f"opening {label}"), "source":source}
        self._raw["table:opening"] = tuple(parsed.values())
        from openpyxl.utils.cell import get_column_letter
        self._ownership["table:opening"]["additional_owning_cells"]=[f"{get_column_letter(vc)}{rowno}" for rowno in range(t+1,b+1) if sheet.cell(rowno,l).value not in {"Workflow","Equity value source"}]
        self._ownership["table:opening"]["excluded_display_rows"]=["Workflow","Equity value source"]
        accounts = self._records("opening_accounts", {"Account / designation": "account", "Balance (EUR)": "balance", "Source": "source"})
        fees = self._records("opening_fees", {"Fee claim": "fee_type", "Unpaid (EUR)": "amount", "Source": "source"})
        if controls["workflow"] != "Existing CLO":
            return None, None, ""
        required = ("Opening timing", "Opening as of", "Opening statement source", "Original schedule start", "Original collateral par", "Current equity value", "Equity value date")
        if set(parsed) != set(required):
            raise InputValidationError("Opening parameter labels do not match the registered interface")
        if parsed["Opening timing"]["value"] != "POST_DISTRIBUTION":
            raise InputValidationError("Existing CLO requires POST_DISTRIBUTION opening timing")
        asof = self._date(parsed["Opening as of"]["value"], "Opening as of")
        source = text_value(parsed["Opening statement source"]["value"], "Opening statement source")
        text_value(parsed["Opening as of"]["source"], "Opening as of source")
        original = self._date(parsed["Original schedule start"]["value"], "Original schedule start")
        if original != values["closing_date"]:
            raise InputValidationError("Original schedule start must equal the original Closing Date assumption")
        text_value(parsed["Original schedule start"]["source"], "Original schedule source")
        indexed_accounts = _index(accounts, "account", "opening accounts")
        if set(indexed_accounts) != set(ACCOUNT_FIELDS):
            raise InputValidationError("Existing opening requires all eight accounts/designations, including sourced known zeros")
        kwargs = {}
        for account, target in ACCOUNT_FIELDS.items():
            row = indexed_accounts[account]
            text_value(row["source"], account + " account source")
            kwargs[target] = decimal_value(row["balance"], account + " account balance")
        indexed_fees = _index(fees, "fee_type", "opening fee claims")
        if set(indexed_fees) != set(FEE_FIELDS):
            raise InputValidationError("Existing opening requires all four sourced fee claims, including known zeros")
        for fee, target in FEE_FIELDS.items():
            row = indexed_fees[fee]
            text_value(row["source"], fee + " claim source")
            kwargs[target] = decimal_value(row["amount"], fee + " unpaid claim")
        coupon_claims = []
        for row in capital:
            if row["instrument_type"] != "DEBT":
                continue
            claim = claims[row["class_id"]]
            text_value(claim["source"], row["class_id"] + " opening coupon source")
            coupon_claims.append(CloNoteCouponClaim(row["class_id"], decimal_value(claim["unpaid_coupon"], "Opening unpaid coupon")))
        original_par = optional_decimal(parsed["Original collateral par"]["value"], "Original collateral par")
        if original_par is not None:
            text_value(parsed["Original collateral par"]["source"], "Original collateral par source")
        opening = CloOpeningState(asof, note_coupon_claims=tuple(coupon_claims), source=source,
            initial_collateral_par=original_par, **kwargs)
        equity = decimal_value(parsed["Current equity value"]["value"], "Current equity value")
        equity_source = text_value(parsed["Current equity value"]["source"], "Current equity value source")
        if self._date(parsed["Equity value date"]["value"], "Equity value date") != asof:
            raise InputValidationError("Forward equity value date must match the actual opening snapshot")
        return opening, equity, equity_source

    def _schedules(self, library, pool):
        principal, steps, credit, recoveries, states, fixings, historical = [], [], [], [], [], [], {}
        rows = self._records("principal_schedule", PRINCIPAL)
        for row in rows:
            if row["payment_date_unadjusted"] in (None, "") and row["amount"] in (None, ""):
                continue  # instructional padding has no contractual amount
            key = text_value(row["loan_id"], "Principal Schedule Asset ID")
            if key not in library:
                raise InputValidationError("Principal Schedule active rows must identify an Asset Library contract")
            if row["case"] not in {"BASE", "BASELINE"}:
                raise InputValidationError("Contractual principal schedules currently require BASE case")
            if row["currency"] != library[key]["currency"]:
                raise InputValidationError("Principal Schedule currency differs from the asset")
            text_value(row["source"], key + " principal schedule source")
            principal.append({"loan_id":key, "payment_date_unadjusted":self._date(row["payment_date_unadjusted"], "principal schedule date"), "amount":decimal_value(row["amount"], "principal amount")})
        event_rows = self._records("asset_events", EVENT)
        writeoffs = {}
        for row in event_rows:
            if row["effective_date"] in (None, "") and row["value"] in (None, ""):
                continue
            kind = text_value(row["record_type"], "Record type")
            key = text_value(row["loan_id"], "Event Asset ID")
            when = self._date(row["effective_date"], kind + " date")
            text_value(row["source"], kind + " source")
            if row["case"] not in {"BASE", "BASELINE"}:
                raise InputValidationError("Dated native events currently require BASE case")
            if kind == "FIXING":
                if key not in {"EURIBOR_1M", "EURIBOR_3M", "EURIBOR_6M"}:
                    raise InputValidationError("FIXING Asset ID denotes an explicit EURIBOR index")
                if row["unit"] not in {"fraction", "annual fraction", "%"}:
                    raise InputValidationError("FIXING value must use annual-fraction units")
                pair=(key,when)
                if pair in historical:
                    raise InputValidationError(f"Duplicate historical FIXING: {pair}")
                historical[pair] = decimal_value(row["value"], "historical fixing annual fraction")
                continue
            if key not in library:
                raise InputValidationError(f"Event refers to unknown Asset ID: {key}")
            scope = "ASSET" if key in pool else "CANDIDATE"
            if kind == "COUPON_STEP":
                fixed = library[key]["coupon_type"] == "FIXED"
                if row["unit"] not in ({"fraction", "annual fraction", "%"} if fixed else {"bps"}):
                    raise InputValidationError("COUPON_STEP must use bps for floating margin or annual fraction for fixed coupon")
                steps.append({"scope":scope, "loan_id":key, "effective_date":when, "policy":"ACTUAL_DATE",
                    "fixed_rate":decimal_value(row["value"], "fixed coupon step") if fixed else None,
                    "spread_bps":None if fixed else decimal_value(row["value"], "margin step bps")})
            elif kind in {"DEFAULT_EVENT", "PREPAYMENT_EVENT"}:
                if key not in pool:
                    raise InputValidationError("Credit events require a held asset")
                if row["value"] not in (None, "") or row["unit"] not in (None, ""):
                    raise InputValidationError(f"{kind} is a full remaining-exposure exit: leave Value/Unit blank")
                credit.append({"loan_id":key, "event_type":"DEFAULT" if kind == "DEFAULT_EVENT" else "PREPAYMENT", "event_date":when, "writeoff_date":None})
            elif kind == "RECOVERY_EVENT":
                if row["unit"] not in {"fraction", "%"}:
                    raise InputValidationError("Recovery value is a fraction of exposure at default")
                recoveries.append({"loan_id":key, "recovery_date":when, "recovery_fraction":decimal_value(row["value"], "recovery fraction")})
            elif kind == "WRITE_OFF_EVENT":
                if key in writeoffs or row["value"] not in (None, "") or row["unit"] not in (None, ""):
                    raise InputValidationError("One WRITE_OFF_EVENT date with blank Value/Unit is allowed per default")
                writeoffs[key]=when
            elif kind in {"OPENING_ACCRUED_FULL_CURRENT_PERIOD", "OPENING_ACCRUED_POST_ASOF_ONLY"}:
                if row["unit"] != "EUR":
                    raise InputValidationError("Opening accrued entitlement is a sourced EUR amount")
                optimizer = {row["label"]:row["value"] for row in self._raw["table:optimizer"]}
                expected = pool[key]["par_as_of_date"] if key in pool else self._date(optimizer["Settlement / closing date"], "candidate opening")
                if when != self._date(expected, "holding as of"):
                    raise InputValidationError("Opening accrued entitlement date must match its held-par snapshot")
                states.append({"scope":scope,"loan_id":key,"opening_accrued_interest":decimal_value(row["value"], "opening accrued entitlement"),
                    "source":row["source"],"entitlement_policy":"FULL_CURRENT_PERIOD" if kind.endswith("FULL_CURRENT_PERIOD") else "POST_ASOF_ONLY"})
            elif kind == "OPENING_FIXED_RATE":
                if row["unit"] not in {"fraction", "annual fraction", "%"}:
                    raise InputValidationError("Opening fixed index rate uses annual-fraction units")
                fixings.append({"scope":scope,"loan_id":key,"fixing_date":when,"index_rate":decimal_value(row["value"], "opening observed index rate")})
            else:
                raise InputValidationError(f"Unsupported Asset Events record type: {kind}")
        for key,when in writeoffs.items():
            matching=[row for row in credit if row["loan_id"]==key and row["event_type"]=="DEFAULT"]
            if len(matching)!=1:
                raise InputValidationError("WRITE_OFF_EVENT requires one matching DEFAULT_EVENT")
            matching[0]["writeoff_date"]=when
        return tuple(principal),tuple(steps),tuple(credit),tuple(recoveries),tuple(states),tuple(fixings),historical

    def _market(self, controls, values, library, historical):
        mode = text_value(self._scalar("market_mode"), "Market Data mode")
        method = text_value(self._scalar("term_lookup"), "Term curve method")
        zero_count = _day_count(self._scalar("zero_basis"), "Zero curve day count")
        compounding = ZeroCompounding(text_value(self._scalar("zero_compounding"), "Zero compounding"))
        extrapolation = ExtrapolationPolicy(controls["curve_extrapolation"])
        # Preserve the existing Market Data layout. The historic named block
        # ends at205, but the actual preserved paste area has240 data rows.
        # A range name determines its sheet/column/header ownership; the schema
        # extends that same block through row245, rather than truncating rates.
        sheet,(l,t,r,b)=self.adapter.region(UI_PREFIX+"term_curve")
        if (l,t,r)!=(1,5,5):
            raise InputValidationError("Market term curve must retain A5:E geometry")
        term_rows=[]
        for rowno in range(t+1,max(b,245)+1):
            row=tuple(self.adapter._input_value(sheet.cell(rowno,c), f"Market term row{rowno}") for c in range(l,l+4))
            if any(v not in (None,"") for v in row):term_rows.append(row)
        self._raw["market:term_curve"]=tuple(term_rows)
        self._raw["market:term_sources"]=tuple(self.adapter._input_value(sheet.cell(rowno,5),f"Market term source row{rowno}") for rowno in range(t+1,max(b,245)+1))
        self._ownership["market:term_curve"]={"name":UI_PREFIX+"term_curve","sheet":sheet.title,"ref":f"A{t+1}:E{max(b,245)}","raw_rate_columns":"A:D","source_column":"E","data_rows":max(b,245)-t,"mode":"RAW_INPUT"}
        zero_sheet,(zl,zt,zr,zb)=self.adapter.region(UI_PREFIX+"zero_curve")
        zero_rows=[]
        for rowno in range(zt+1,zb+1):
            row=tuple(self.adapter._input_value(zero_sheet.cell(rowno,c), f"Market zero row{rowno}") for c in range(zl,zr+1))
            if any(v not in (None,"") for v in row):zero_rows.append(row)
        self._raw["market:zero_curve"]=tuple(zero_rows)
        from openpyxl.utils.cell import get_column_letter
        self._ownership["market:zero_curve"]={"name":UI_PREFIX+"zero_curve","sheet":zero_sheet.title,"ref":f"{get_column_letter(zl)}{zt+1}:{get_column_letter(zr)}{zb}","data_rows":zb-zt,"mode":"RAW_INPUT"}
        term_indices=("EURIBOR_1M","EURIBOR_3M","EURIBOR_6M")
        if method not in {"MONTH_BUCKET","LINEAR_DATES"}:
            raise InputValidationError("Term lookup must be MONTH_BUCKET or LINEAR_DATES")
        if mode=="SYNTHETIC_FLAT":
            rate=decimal_value(self._scalar("synthetic_rate"),"Synthetic flat annual rate")
            provenance=f"SYNTHETIC_FLAT; annual rate={rate}; scenario_anchor={controls['valuation_date']}; unused_term_paste_as_of={controls['market_curve_as_of']}; not observed term market data"
            provider=FlatRateProvider({i:rate for i in term_indices},provenance)
            if historical:
                raise InputValidationError("Actual FIXING rows require MARKET_CURVES; do not combine actual observations with the synthetic flat historical proxy")
        elif mode=="MARKET_CURVES":
            curve_type=MonthlyProjectedRateCurve if method=="MONTH_BUCKET" else ProjectedRateCurve
            provenance=f"USER_PROJECTED_TERM_RATES; as_of={controls['valuation_date']}; method={method}; extrapolation={extrapolation.value}"
            curves={index:curve_type(index,tuple(RatePoint(self._date(row[0],"Curve Date"),decimal_value(row[c],index+" forward rate")) for row in term_rows),extrapolation,provenance) for c,index in enumerate(term_indices,1)}
            provider=CurveRateProvider(curves,controls["valuation_date"],historical)
        else:
            raise InputValidationError("Market mode must be SYNTHETIC_FLAT or MARKET_CURVES")
        requested={row.get("rate_index") for row in library}
        if controls["mode"]=="CLO_BASELINE":requested.add(values["cash_accrual_curve"].replace(" ","_"))
        requested &= {"ESTR","SOFR","SONIA"}
        if requested:
            zero_indices=("ESTR","SOFR","SONIA")
            # Zero curves remain independent explicit raw UI inputs even when
            # the term curve is a synthetic flat scenario.
            # The flat toggle selects synthetic EURIBOR term rates. Pasted
            # OIS cash curves remain a separately dated raw input; never relabel
            # them as a fresh Pricing-Date curve when B3 was not refreshed.
            zero_asof=controls["market_curve_as_of"]
            curves={index:DiscountFactorCashCurve(index,zero_asof,tuple(ZeroRatePoint(decimal_value(row[0],"Zero tenor years"),decimal_value(row[zero_indices.index(index)+1],index+" zero rate")) for row in zero_rows),
                compounding,DayCount(zero_count),extrapolation,f"USER_PASTED_OIS_FORWARD_PROJECTION; as_of={zero_asof}; UI annual zero rates") for index in requested}
            provider=CashCurveRateProvider(provider,curves)
            provenance+=f"; cash_zero_curve_as_of={zero_asof}; selected={','.join(sorted(requested))}"
        return provider,provenance

    def _scenarios(self):
        rows=self._records("scenario_edits",SCENARIO)
        normalized=[]
        for row in rows:
            if row["applies_from"] not in {"Base snapshot", "BASELINE", None, ""}:
                raise InputValidationError("Scenario edits apply to the current baseline snapshot; effective-dated trading is unsupported")
            target=text_value(row["target"],"scenario target")
            field=text_value(row["field"],"scenario field")
            value=row["option"] if row["option"] not in (None,"") else row["value"]
            if row["option"] not in (None,"") and row["value"] not in (None,""):
                raise InputValidationError("Scenario edit must use New value or New option, not both")
            if field in {"maturity_date","legal_final_date"} and value not in (None,""):
                value=self._date(value,"scenario "+field)
            normalized.append({"scenario_id":row["scenario_id"],"target":target,"identifier":row["identifier"],"field":field,"value":value,"enabled":row["enabled"]})
        records=tuple(normalized)
        return scenarios_from_records(records),records

    def _quotes(self, library, metadata, ratings, pool, controls):
        rows=self._records("trade_universe",QUOTE)
        _index(rows,"loan_id","Trade Universe")
        quotes,observations,new_assets,candidate_metadata,candidate_ratings=[],[],{}, {}, []
        search=controls["candidate_search_enabled"] or controls["optimizer_enabled"]
        for row in rows:
            key=text_value(row["loan_id"],"Trade Universe Asset ID")
            if key not in library:
                raise InputValidationError(f"Trade Universe missing full Asset Library contract: {key}")
            asset=library[key]
            if row["allow_sell"] not in (None,"") and boolean_value(row["allow_sell"],"Allow sell") and key in pool and pool[key]["trade_permission"]!="TRADABLE":
                # A LOCKED held loan never becomes a sale merely because a
                # copied quote row still contains Allow sell=true.
                sell=False
            else:sell=False if row["allow_sell"] in (None,"") else boolean_value(row["allow_sell"],"Allow sell")
            buy=False if row["allow_buy"] in (None,"") else boolean_value(row["allow_buy"],"Allow buy")
            for side,allowed,price,size,accrued,fixed_fee in (("BUY",buy,row["ask"],row["ask_size"],row["buy_accrued"],row["buy_fixed_fee"]),("SELL",sell,row["bid"],row["bid_size"],row["sell_accrued"],row["sell_fixed_fee"])):
                if not allowed:continue
                supplied=any(v not in (None,"") for v in (price,size))
                if not supplied:continue
                complete=all(v not in (None,"") for v in (price,size,row["settlement_date"],row["observed_at"],row["source"],row["quality"],accrued,row["proportional_fee_per_par"],fixed_fee))
                if not complete:
                    if search and supplied:raise InputValidationError(f"{key} {side}: active frozen quote requires price, size, settlement, timezone timestamp, source, quality and declared accrued/fees/ticket")
                    self._warnings.append(f"{key} {side}: incomplete disabled quote excluded from executable trade records")
                    continue  # incomplete disabled quote is retained in snapshot
                if side=="SELL" and key not in pool:
                    raise InputValidationError(f"{key}: SELL quote requires a current held Pool row")
                if side=="BUY" and key in pool:
                    raise InputValidationError(f"{key}: closing BUY must be a new facility, not an already held asset")
                if asset["asset_class"]!="BSL" or asset["coupon_type"]!="FLOATING":
                    raise InputValidationError("Current static trade research supports floating BSL facilities only")
                bucket=asset.get("test_factor_bucket") or asset.get("rating_bucket") or asset.get("agency_rating")
                quote={"asset_id":key,"side":side,"asset_class":asset["asset_class"],"obligor_id":asset["obligor_id"],"country_code":asset["country_code"],"sector":asset["sector"],"currency":asset["currency"],
                    "spread_bps":asset["spread_bps"],"factor_bucket":bucket,"clean_price_pct":decimal_value(price,"clean price /100"),"maximum_par":decimal_value(size,"quote size EUR"),
                    "accrued_per_par":decimal_value(accrued,"quote accrued per par"),"proportional_fee_per_par":decimal_value(row["proportional_fee_per_par"],"fees per par"),
                    "lot_size":optional_decimal(row["lot_size"],"lot size"),"minimum_ticket":Decimal(0) if row["minimum_ticket"] in (None,"") else decimal_value(row["minimum_ticket"],"minimum ticket"),"fixed_fee":decimal_value(fixed_fee,"fixed trade fee")}
                timestamp_value(row["observed_at"],key+" quote timestamp")
                quotes.append(quote)
                observations.append({"asset_id":key,"side":side,"price_side":"ASK" if side=="BUY" else "BID","quality":row["quality"],"observed_at":row["observed_at"],"settlement_date":self._date(row["settlement_date"],"quote settlement date"),"source":text_value(row["source"],"quote source")})
                meta=metadata[key]
                candidate_metadata[key]={"loan_id":key,"facility_id":key,"bloomberg_security":"MANUAL:"+key,"contract_provenance":meta.get("contract_source"),"classification_provenance":meta.get("classification_source"),"credit_status":asset["credit_status"]}
                if side=="BUY":
                    new_assets[key]={**asset,"current_par":asset["initial_par"],"par_as_of_date":controls["optimizer_settlement_date"],"purchase_price_pct":100,"acquired_accrued_interest":0}
        for row in ratings:
            if row["loan_id"] not in candidate_metadata or row["agency"] in (None,"") or row["rating"] in (None,""):
                continue
            candidate_ratings.append({k:row[k] for k in ("loan_id","agency","rating","level","nature","subject_id","source")}|{"as_of_date":self._date(row["as_of_date"],"candidate rating observation date")})
        return tuple(quotes),tuple(observations),tuple(new_assets.values()),tuple(candidate_metadata.values()),tuple(candidate_ratings)

    def _variants(self):
        fields={"candidate_id":"candidate_id","objective":"objective","maximum_overall_factor":"maximum_overall_factor","maximum_bsl_factor":"maximum_bsl_factor","minimum_spread_bps":"minimum_spread_bps","maximum_trade_par":"maximum_trade_par","enabled":"enabled"}
        rows=self._records("candidate_variants",fields,optional=True)
        if rows:return rows
        # A finite reproducible search profile, not an unbounded IRR optimizer.
        # NO_TRADES is supplied by ClosingPoolSearchService itself and is not
        # duplicated as an LP objective. Policy is included in the fingerprint.
        rows=tuple({"candidate_id":objective,"objective":objective,"maximum_overall_factor":None,"maximum_bsl_factor":None,"minimum_spread_bps":None,"maximum_trade_par":None,"enabled":True} for objective in ("MIN_FACTOR","MAX_SPREAD"))
        self._raw["package:candidate_variants"]=rows
        return rows


def read_interface_inputs(source, *, policy: InterfaceExecutionPolicy | None = None) -> InterfaceWorkbookInputs:
    """Convenience API shared by run, preflight, scenarios and static research."""
    return InterfaceInputReader(source,policy=policy).read()


def static_optimization_request(inputs: InterfaceWorkbookInputs, result=None, *, closing_budget=False):
    """Build a static research mandate from explicit UI cash and owned quotes.

    Works at a supported current opening date; it executes no settlements and
    spends no inferred reserve/interest cash. Closing full-IRR replay uses the
    distinct total-economic-budget scope. A None result means preflight only.
    """
    from .optimization_records import OptimizationBudgetScope, optimization_request_from_records, optimization_snapshot_from_records
    scope=OptimizationBudgetScope.CLOSING_ECONOMIC_BUDGET if closing_budget else OptimizationBudgetScope.PRINCIPAL_ACCOUNT
    if result is not None:
        return optimization_request_from_records(inputs.assets,inputs.quotes,inputs.controls,inputs.request.factor_mapping,result,budget_scope=scope)
    opening=inputs.request.clo_opening_state
    asof=opening.as_of_date if opening is not None else inputs.request.cashflow_request.positions[0].par_as_of_date
    return optimization_snapshot_from_records(inputs.assets,inputs.quotes,inputs.controls,inputs.request.factor_mapping,opening_date=asof,budget_scope=scope)


def closing_candidate_request(inputs: InterfaceWorkbookInputs, result=None):
    """Build finite closing-search inputs; the service supplies NO_TRADES.

    Evidence-free facilities remain quarantinable; TEST coefficients never
    create agency ratings. This function does not run LP/MILP or financial replay.
    """
    from .candidate_records import candidate_search_from_records
    if inputs.request.clo_opening_state is not None:
        raise InputValidationError("Full candidate IRR search is closing-only; use static current-portfolio research for Existing CLO")
    candidate_ids={row["loan_id"] for row in inputs.candidate_assets}
    selected=lambda rows:tuple(row for row in rows if row["scope"]=="ASSET" or row["loan_id"] in candidate_ids)
    return candidate_search_from_records(inputs.request,result,inputs.assets,inputs.quotes,inputs.controls,
        candidate_assets=inputs.candidate_assets,candidate_metadata=inputs.candidate_metadata,candidate_ratings=inputs.candidate_ratings,
        quote_observations=inputs.quote_observations,candidate_variants=inputs.candidate_variants,
        coupon_step_records=selected(inputs.coupon_step_records),seasoned_state_records=selected(inputs.seasoned_state_records),
        opening_fixing_records=selected(inputs.opening_fixing_records),
        principal_schedule_records=tuple(row for row in inputs.library_principal_schedule_records if row["loan_id"] in candidate_ids))


@dataclass(frozen=True)
class LibraryReferenceRequest:
    """Contract-start reference slices; this is not a common-date portfolio."""
    positions: tuple
    rate_provider: object
    rate_provenance: str
    failures: tuple[Mapping[str,object],...] = ()
    basis: str = "REFERENCE_CONTRACT"


@dataclass(frozen=True)
class LibraryReferenceProjection:
    """Contractual reference receipts, with per-asset failures kept explicit."""
    cashflows: tuple
    reference_positions: tuple
    failures: tuple[Mapping[str,object],...]
    rate_provenance: str
    basis: str = "REFERENCE_CONTRACT"


def reference_library_request(inputs: InterfaceWorkbookInputs, *, asset_ids=None, exclude_held=False) -> LibraryReferenceRequest:
    """Build standalone contracts using owned reference face and contract start.

    No Pool acquisition cash, held slice, credit overlay or CLO capital enters
    these references. Different contracts may start on different dates. The
    selected common market provider remains explicit; missing actual historical
    rates will produce an unavailable asset projection rather than a proxy.
    """
    from trident.domain.models import PrincipalScheduleEntry
    from .records import position_from_record, coupon_steps_from_records
    library={row["loan_id"]:row for row in inputs.library_assets}
    selected=set(library) if asset_ids is None else set(asset_ids)
    if selected-set(library):raise InputValidationError(f"Unknown Library reference Asset IDs: {sorted(selected-set(library))}")
    if exclude_held:selected-={row["loan_id"] for row in inputs.assets}
    # The Library namespace contains each contract once. Existing ASSET and
    # CANDIDATE step scopes refer to its held/unheld uses, not separate contracts.
    steps=tuple({**row,"scope":"ASSET"} for row in inputs.coupon_step_records)
    grouped=coupon_steps_from_records(steps,inputs.library_assets,scope="ASSET")
    schedules={}
    for row in inputs.library_principal_schedule_records:
        schedules.setdefault(row["loan_id"],[]).append(PrincipalScheduleEntry(date_value(row["payment_date_unadjusted"],"Library principal date"),decimal_value(row["amount"],"Library principal amount")))
    positions,failures=[],[]
    for key in sorted(selected):
        row=library[key]
        options={"principal_schedule":tuple(sorted(schedules.get(key,()),key=lambda p:p.payment_date))}
        if key in grouped:options.update(coupon_steps=grouped[key][0],coupon_step_policy=grouped[key][1])
        try:
            positions.append(position_from_record({**row,"current_par":row["initial_par"],
                "par_as_of_date":row["cashflow_projection_start_date"],"purchase_price_pct":100,"acquired_accrued_interest":0},**options))
        except (InputValidationError,ValueError,TypeError) as error:
            failures.append({"loan_id":key,"status":"INPUT_ERROR","basis":"REFERENCE_CONTRACT","message":str(error)})
    return LibraryReferenceRequest(tuple(positions),inputs.request.cashflow_request.rate_provider,
        inputs.request.cashflow_request.rate_provenance,_freeze_records(tuple(failures)))


def project_library_cashflows(inputs: InterfaceWorkbookInputs, *, asset_ids=None, exclude_held=False) -> LibraryReferenceProjection:
    """Project selected reusable contracts independently; retain failure reasons."""
    from trident.cashflows.engine import ContractualCashflowEngine
    reference=reference_library_request(inputs,asset_ids=asset_ids,exclude_held=exclude_held)
    engine=ContractualCashflowEngine(reference.rate_provider)
    cashflows,positions,failures=[],[],list(reference.failures)
    for position in reference.positions:
        try:
            rows=engine.generate(position)
            cashflows.extend(rows);positions.append(position)
        except (InputValidationError,ValueError,ArithmeticError) as error:
            failures.append({"loan_id":position.terms.loan_id,"status":"PROJECTION_ERROR","basis":"REFERENCE_CONTRACT","message":str(error)})
    return LibraryReferenceProjection(tuple(cashflows),tuple(positions),_freeze_records(tuple(failures)),reference.rate_provenance)
