"""Independent checks of legacy projected-rate calendar-month lookup."""

from dataclasses import FrozenInstanceError
from datetime import date, datetime
from decimal import Decimal, ROUND_DOWN, localcontext
import unittest

from trident.market import MonthlyProjectedRateCurve
from trident.market.rates import (
    CurveRangeError,
    CurveRateProvider,
    ExtrapolationPolicy,
    MissingCurveError,
    ProjectedRateCurve,
    RatePoint,
    RequiredFixingError,
)


INDEX = "EURIBOR_3M"


class MonthlyProjectedRateCurveTests(unittest.TestCase):
    def setUp(self) -> None:
        self.points = (
            RatePoint(date(2026, 10, 31), Decimal("0.02")),
            RatePoint(date(2026, 11, 30), Decimal("0.03")),
            RatePoint(date(2026, 12, 31), Decimal("0.04")),
        )

    def test_november_fixing_uses_november_month_end_row(self) -> None:
        curve = MonthlyProjectedRateCurve(INDEX, self.points)
        self.assertEqual(curve.rate(INDEX, date(2026, 11, 18)), Decimal("0.03"))

    def test_month_lookup_and_linear_interpolation_are_different_policies(self) -> None:
        monthly = MonthlyProjectedRateCurve(INDEX, self.points)
        linear = ProjectedRateCurve(INDEX, self.points)
        # Nov 18 is 18/30 of the Oct 31-to-Nov 30 interval: 2% + 0.6%.
        self.assertEqual(linear.rate(INDEX, date(2026, 11, 18)), Decimal("0.026"))
        self.assertEqual(monthly.rate(INDEX, date(2026, 11, 18)), Decimal("0.03"))

    def test_first_month_day_one_precedes_node_but_is_covered(self) -> None:
        curve = MonthlyProjectedRateCurve(INDEX, self.points)
        for fixing_date in [date(2026, 10, 1), date(2026, 10, 18), date(2026, 10, 31)]:
            with self.subTest(fixing_date=fixing_date):
                self.assertEqual(curve.rate(INDEX, fixing_date), Decimal("0.02"))

    def test_every_date_in_last_month_uses_its_unchanged_rate(self) -> None:
        curve = MonthlyProjectedRateCurve(INDEX, self.points)
        for fixing_date in [date(2026, 12, 1), date(2026, 12, 18), date(2026, 12, 31)]:
            with self.subTest(fixing_date=fixing_date):
                self.assertEqual(curve.rate(INDEX, fixing_date), Decimal("0.04"))

    def test_non_month_end_dates_are_valid_month_labels(self) -> None:
        curve = MonthlyProjectedRateCurve(INDEX, (
            RatePoint(date(2026, 11, 7), Decimal("0.025")),
            RatePoint(date(2026, 12, 3), Decimal("0.035")),
            RatePoint(date(2027, 1, 1), Decimal("0.045")),
        ))
        self.assertEqual(curve.rate(INDEX, date(2026, 11, 1)), Decimal("0.025"))
        self.assertEqual(curve.rate(INDEX, date(2026, 11, 30)), Decimal("0.025"))
        self.assertEqual(curve.rate(INDEX, date(2026, 12, 31)), Decimal("0.035"))
        self.assertEqual(curve.rate(INDEX, date(2027, 1, 31)), Decimal("0.045"))

    def test_leap_february_has_one_monthly_bucket(self) -> None:
        curve = MonthlyProjectedRateCurve(INDEX, (
            RatePoint(date(2028, 2, 29), Decimal("-0.005")),
            RatePoint(date(2028, 3, 31), Decimal("0.005")),
        ))
        self.assertEqual(curve.rate(INDEX, date(2028, 2, 1)), Decimal("-0.005"))
        self.assertEqual(curve.rate(INDEX, date(2028, 2, 29)), Decimal("-0.005"))
        self.assertEqual(curve.rate(INDEX, date(2028, 3, 1)), Decimal("0.005"))

    def test_default_error_checks_month_range_rather_than_node_date_range(self) -> None:
        curve = MonthlyProjectedRateCurve(INDEX, self.points)
        for fixing_date in [date(2026, 9, 30), date(2027, 1, 1)]:
            with self.subTest(fixing_date=fixing_date), self.assertRaisesRegex(CurveRangeError, "OUTSIDE_MONTH_RANGE"):
                curve.rate(INDEX, fixing_date)

    def test_explicit_flat_extrapolation_uses_endpoint_month_rate(self) -> None:
        curve = MonthlyProjectedRateCurve(INDEX, self.points, ExtrapolationPolicy.FLAT)
        self.assertEqual(curve.rate(INDEX, date(2020, 1, 1)), Decimal("0.02"))
        self.assertEqual(curve.rate(INDEX, date(2050, 1, 1)), Decimal("0.04"))

    def test_one_node_covers_whole_month_only_by_default(self) -> None:
        curve = MonthlyProjectedRateCurve(INDEX, self.points[1:2])
        self.assertEqual(curve.rate(INDEX, date(2026, 11, 1)), Decimal("0.03"))
        self.assertEqual(curve.rate(INDEX, date(2026, 11, 30)), Decimal("0.03"))
        with self.assertRaises(CurveRangeError):
            curve.rate(INDEX, date(2026, 12, 1))

    def test_same_month_duplicate_nodes_are_rejected(self) -> None:
        points = (
            RatePoint(date(2026, 11, 1), Decimal("0.02")),
            RatePoint(date(2026, 11, 30), Decimal("0.03")),
        )
        with self.assertRaisesRegex(ValueError, "exactly one point"):
            MonthlyProjectedRateCurve(INDEX, points)

    def test_missing_middle_month_is_rejected_for_every_extrapolation_policy(self) -> None:
        for policy in ExtrapolationPolicy:
            with self.subTest(policy=policy), self.assertRaisesRegex(ValueError, "missing months"):
                MonthlyProjectedRateCurve(INDEX, (self.points[0], self.points[2]), policy)

    def test_unordered_and_exact_duplicate_dates_retain_parent_validation(self) -> None:
        for points in [self.points[::-1], (self.points[0], self.points[0])]:
            with self.subTest(points=points), self.assertRaisesRegex(ValueError, "strictly increasing"):
                MonthlyProjectedRateCurve(INDEX, points)

    def test_parent_input_validation_is_not_bypassed(self) -> None:
        for invalid in [(), list(self.points), ("invalid point",), None]:
            with self.subTest(points=invalid), self.assertRaises(ValueError):
                MonthlyProjectedRateCurve(INDEX, invalid)
        with self.assertRaises(ValueError):
            MonthlyProjectedRateCurve("", self.points)
        with self.assertRaises(ValueError):
            MonthlyProjectedRateCurve(INDEX, self.points, "FLAT")
        with self.assertRaises(ValueError):
            MonthlyProjectedRateCurve(INDEX, self.points, provenance="")

    def test_query_index_and_date_types_are_strict(self) -> None:
        curve = MonthlyProjectedRateCurve(INDEX, self.points)
        with self.assertRaises(MissingCurveError):
            curve.rate("EURIBOR_6M", date(2026, 11, 18))
        for invalid in ["", " ", "EURIBOR_3M ", True, None]:
            with self.subTest(index=invalid), self.assertRaises(ValueError):
                curve.rate(invalid, date(2026, 11, 18))
        for invalid in [datetime(2026, 11, 18), "2026-11-18", True, None]:
            with self.subTest(fixing_date=invalid), self.assertRaises(ValueError):
                curve.rate(INDEX, invalid)

    def test_node_tuple_and_cached_months_are_immutable_snapshots(self) -> None:
        original = list(self.points)
        curve = MonthlyProjectedRateCurve(INDEX, tuple(original))
        original[1] = RatePoint(date(2026, 11, 30), Decimal("0.9"))
        original.clear()
        self.assertEqual(curve.rate(INDEX, date(2026, 11, 18)), Decimal("0.03"))
        self.assertIsInstance(curve._month_indices, tuple)
        with self.assertRaises(FrozenInstanceError):
            curve.points = ()
        with self.assertRaises(FrozenInstanceError):
            curve._month_indices = ()
        with self.assertRaises(FrozenInstanceError):
            curve.points[0].rate = Decimal("0.9")

    def test_month_rate_preserves_input_precision_and_negative_values(self) -> None:
        exact = Decimal("-0.03123456789012345678901234567890123456789")
        curve = MonthlyProjectedRateCurve(INDEX, (RatePoint(date(2026, 11, 30), exact),))
        with localcontext() as context:
            context.prec = 2
            context.rounding = ROUND_DOWN
            self.assertEqual(curve.rate(INDEX, date(2026, 11, 18)), exact)
            self.assertEqual(context.prec, 2)


class MonthlyCurveProviderIntegrationTests(unittest.TestCase):
    def setUp(self) -> None:
        self.curve = MonthlyProjectedRateCurve(INDEX, (
            RatePoint(date(2026, 11, 30), Decimal("0.03")),
            RatePoint(date(2026, 12, 31), Decimal("0.04")),
        ))

    def test_parent_curve_provider_accepts_monthly_subclass_for_future_dates(self) -> None:
        provider = CurveRateProvider({INDEX: self.curve}, date(2026, 11, 1))
        self.assertIsInstance(self.curve, ProjectedRateCurve)
        self.assertEqual(provider.rate(INDEX, date(2026, 11, 18)), Decimal("0.03"))

    def test_historical_exact_gate_is_preserved_inside_a_covered_month(self) -> None:
        provider = CurveRateProvider({INDEX: self.curve}, date(2026, 11, 20))
        with self.assertRaises(RequiredFixingError):
            provider.rate(INDEX, date(2026, 11, 18))
        with self.assertRaises(RequiredFixingError):
            provider.rate(INDEX, date(2026, 11, 20))

    def test_actual_fixing_takes_priority_without_changing_future_bucket(self) -> None:
        provider = CurveRateProvider({INDEX: self.curve}, date(2026, 11, 20), {
            (INDEX, date(2026, 11, 18)): Decimal("0.025"),
        })
        self.assertEqual(provider.rate(INDEX, date(2026, 11, 18)), Decimal("0.025"))
        self.assertEqual(provider.rate(INDEX, date(2026, 11, 21)), Decimal("0.03"))

    def test_external_curve_map_mutation_does_not_replace_monthly_curve(self) -> None:
        curves = {INDEX: self.curve}
        provider = CurveRateProvider(curves, date(2026, 11, 1))
        curves[INDEX] = ProjectedRateCurve(INDEX, self.curve.points, ExtrapolationPolicy.FLAT)
        self.assertEqual(provider.rate(INDEX, date(2026, 11, 18)), Decimal("0.03"))


if __name__ == "__main__":
    unittest.main()
