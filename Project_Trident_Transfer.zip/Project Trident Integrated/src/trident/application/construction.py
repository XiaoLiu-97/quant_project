"""Replay a static proposal as an independent redesign of the closing pool.

This service does not execute dated trades. Retained assets keep their original
closing purchase economics; new assets use admitted BUY asks and acquisition
accrued/fees in the rebuilt funding request. Seasoned coupon ownership and its
original known fixings remain explicit position state; accrued acquisition cost
does not create another coupon receipt. Other nonzero acquired accrued requires
an explicit inherited-coupon entitlement path. Acquisition cost alone never
establishes a verified investor return. Static ending
trade cash and SELL proceeds never enter redesigned investor cashflows. Replay
verification is separate from solver feasibility and performance preference.
"""

from dataclasses import dataclass, replace
from datetime import date
from decimal import Decimal
from enum import Enum
from fractions import Fraction

from trident.analysis import AssetExposure, FactorMapping, LimitStatus, ReturnStatus, xnpv
from trident.clo.models import CoverageStatus, ProjectionStatus
from trident.cashflows.seasoned import resize_seasoned_state
from trident.domain.models import CouponType, InputValidationError, LoanPosition, require_decimal
from trident.domain.numeric import post_currency
from trident.funding.engine import AssetPurchase
from trident.market.rates import CurveRangeError, MissingCurveError, RequiredFixingError
from trident.optimization import AssetDescriptor, OptimizationRequest, OptimizationResult, StaticTradeOptimizer, TradeSide
from trident.optimization.universe import (
    CandidateAdmissionPolicy, CandidateAdmissionResult, CandidateAssetSnapshot, CandidateUniverseSnapshot,
    CandidateUniverseValidator, TargetPoolPlan, reconcile_proposal,
)

from .clo_services import TridentModelRequest, TridentModelResult, TridentModelService, ModelProjectionRunner
from .scenarios import ScenarioMetricComparison, ScenarioPeriodComparison, compare_model_results, resize_principal_schedule


class ConstructionStatus(str, Enum):
    STATIC_REJECTED = "STATIC_REJECTED"
    REPLAY_FAILED = "REPLAY_FAILED"
    REPLAY_REJECTED = "REPLAY_REJECTED"
    REPLAY_VALIDATED = "REPLAY_VALIDATED"


class FindingSeverity(str, Enum):
    ERROR = "ERROR"
    WARNING = "WARNING"


@dataclass(frozen=True)
class ConstructionFinding:
    """A named projection observation with scope, severity and optional date/class.

    Baseline breaches are warnings for comparison; target hard-limit breaches
    are errors that exclude it. Performance deterioration is not automatically
    a contractual breach unless the user supplied a minimum-return mandate.
    """
    code: str
    message: str
    source: str
    severity: FindingSeverity
    payment_date: date | None = None
    identifier: str | None = None


@dataclass(frozen=True)
class ClosingPoolRedesignRequest:
    """A finite opening-pool redesign with explicit selected factor methodology.

    ``minimum_equity_irr`` is optional, expressed as an annual decimal fraction.
    Without this explicit mandate a negative return is a performance warning,
    not an invented legal breach. The current baseline cannot contain dated
    explicit per-loan credit events. A configured proportional default/prepay
    overlay and synthetic reinvestment template are replayed in that one
    scenario; this is not a multi-stress search or a dated trade engine.
    """

    baseline: TridentModelRequest
    optimization_request: OptimizationRequest
    candidate_snapshot: CandidateUniverseSnapshot
    admission_policy: CandidateAdmissionPolicy
    proposal_id: str = "TARGET_POOL"
    minimum_equity_irr: Decimal | None = None

    def __post_init__(self) -> None:
        for value, item_type, label in (
            (self.baseline, TridentModelRequest, "baseline"),
            (self.optimization_request, OptimizationRequest, "optimization_request"),
            (self.candidate_snapshot, CandidateUniverseSnapshot, "candidate_snapshot"),
            (self.admission_policy, CandidateAdmissionPolicy, "admission_policy"),
        ):
            if not isinstance(value, item_type):
                raise InputValidationError(f"{label} must be {item_type.__name__}")
        if not isinstance(self.proposal_id, str) or not self.proposal_id or self.proposal_id != self.proposal_id.strip():
            raise InputValidationError("proposal_id must be nonempty, unpadded text")
        if self.proposal_id.casefold() == "baseline":
            raise InputValidationError("proposal_id BASELINE is reserved")
        if self.minimum_equity_irr is not None:
            require_decimal(self.minimum_equity_irr, "minimum_equity_irr")
            if self.minimum_equity_irr <= -1:
                raise InputValidationError("minimum_equity_irr must be greater than -1")


@dataclass(frozen=True)
class ClosingPoolRedesignResult:
    """Separate data, solver, settlement-plan and full replay evidence.

    A rejected target retains its failure stage. The baseline remains visible
    for comparison even when it fails a mandate; proposed trades are unexecuted.
    """
    status: ConstructionStatus
    admission: CandidateAdmissionResult
    optimization: OptimizationResult
    baseline_result: TridentModelResult
    plan: TargetPoolPlan | None
    target_request: TridentModelRequest | None
    target_result: TridentModelResult | None
    comparisons: tuple[ScenarioMetricComparison, ...]
    period_comparisons: tuple[ScenarioPeriodComparison, ...]
    findings: tuple[ConstructionFinding, ...]
    equity_irr_improved: bool | None
    mode: str = "CLOSING_POOL_REDESIGN"
    execution_status: str = "NOT_EXECUTED"
    replay_scope: str = "ONE_CONFIGURED_SCENARIO_NO_EXPLICIT_BASELINE_CREDIT_EVENTS"
    optimality_scope: str = "STATIC_SOLVER_OBJECTIVE_ONLY_NO_GLOBAL_EQUITY_IRR_CLAIM"

    @property
    def validated(self) -> bool:
        """Only the reported static mandate and configured closing replay pass.

        This covers portfolio limits and evaluated OC/IC GATE rows, not an
        assertion that every IDT observation passes or every stress was tested.
        IDT cash transfer is a contractual projection action, separately shown.
        """
        return (self.status is ConstructionStatus.REPLAY_VALIDATED and self.optimization.validated
                and self.target_result is not None
                and not any(row.severity is FindingSeverity.ERROR for row in self.findings))


def selected_factor_provenance(mapping: FactorMapping) -> str:
    """Match the existing static adapter label, without treating it as evidence."""
    if not isinstance(mapping, FactorMapping):
        raise InputValidationError("Closing redesign requires an explicit FactorMapping")
    qualification = "SYNTHETIC_TEST_ONLY" if mapping.is_synthetic else "USER_SUPPLIED_UNVERIFIED_AGENCY_MAPPING"
    return f"{mapping.system}/{mapping.version}; {qualification}"


def _selected_factor(exposure: AssetExposure, mapping: FactorMapping) -> Decimal:
    """Resolve factors through actual typed exposure and selected mapping version."""
    if mapping.is_synthetic:
        factor = mapping.factors.get(exposure.test_factor_bucket)
    else:
        if exposure.rating_system is not None and (exposure.rating_system, exposure.rating_version) != (mapping.system, mapping.version):
            raise InputValidationError(f"{exposure.loan_id}: factor system/version differs from selected methodology")
        factor = mapping.factors.get(exposure.rating_bucket)
        if exposure.rating_factor is not None:
            if factor is not None and factor != exposure.rating_factor:
                raise InputValidationError(f"{exposure.loan_id}: direct factor conflicts with selected mapping")
            factor = exposure.rating_factor
    if factor is None:
        raise InputValidationError(f"{exposure.loan_id}: no factor resolved by the explicitly selected methodology")
    return factor


def _check_descriptor(asset: AssetDescriptor, position: LoanPosition, exposure: AssetExposure,
                      mapping: FactorMapping) -> None:
    """Bind static coefficients to verified identity, contract and quality data.

    An attractive descriptor cannot be swapped onto another facility's cashflow
    or rating factor. This validates the user's selected mapping consistency;
    it does not prove agency-specific rating selection/notching methodology.
    A stepped loan's static spread remains its opening quoted-margin proxy.
    The complete position retains its dates/policy for the full dated replay,
    where future WAS/WAC tests are assessed rather than flattened to this value.
    """
    expected = (position.terms.loan_id, exposure.asset_class, exposure.obligor,
                exposure.country, exposure.sector, exposure.spread_bps, _selected_factor(exposure, mapping))
    actual = (asset.asset_id, asset.kind.value, asset.obligor, asset.country, asset.sector, asset.spread_bps, asset.factor)
    if actual != expected:
        raise InputValidationError(f"{asset.asset_id}: static descriptor does not match full exposure/selected factor")
    terms = position.terms
    if (exposure.loan_id != terms.loan_id or exposure.par != position.opening_balance or exposure.currency != "EUR"
            or terms.currency != exposure.currency or terms.coupon_type is not CouponType.FLOATING
            or exposure.spread_bps != terms.spread_bps or exposure.maturity_date != terms.maturity_date):
        raise InputValidationError(f"{asset.asset_id}: full exposure differs from supported floating EUR contract")
    if exposure.fixed_coupon_rate is not None or (exposure.coupon_type is not None
                                                and exposure.coupon_type is not terms.coupon_type):
        raise InputValidationError(f"{asset.asset_id}: full exposure coupon attributes differ from floating contract")
    if exposure.financing_type is None or any(getattr(exposure, name) is None for name in (
        "is_senior", "is_secured", "is_pik", "is_revolver", "is_construction",
    )):
        raise InputValidationError(f"{asset.asset_id}: complete explicit quality metadata is required")
    if any(getattr(exposure, name) is True for name in ("is_pik", "is_revolver", "is_construction")):
        raise InputValidationError(f"{asset.asset_id}: redesign currently supports cash-pay funded assets without contingent commitments")


def _resize_position(position: LoanPosition, new_par: Decimal) -> LoanPosition:
    """Resize held share, preserving nominal dates and complete principal totals.

    Use the same exact largest-remainder allocation as closing what-if for
    bespoke cent schedules. Absolute reference/amortisation/balloon amounts
    scale with the holding; fractional policy parameters and dates do not.
    Domain validators reject unsupported results such as a rounded-zero ticket
    or a projected annuity that no longer admits a nonnegative cent schedule.
    """
    ratio = Fraction(new_par) / Fraction(position.opening_balance)
    terms = position.terms
    amounts = {name: post_currency(Fraction(getattr(terms, name)) * ratio)
               for name in ("reference_principal", "scheduled_principal_amount", "balloon_amount")
               if getattr(terms, name) is not None}
    amounts["principal_schedule"] = resize_principal_schedule(terms.principal_schedule, ratio, new_par)
    state = resize_seasoned_state(position, ratio)
    return replace(position, opening_balance=new_par, terms=replace(terms, **amounts), seasoned_state=state)


def validate_closing_pool_inputs(
    baseline: TridentModelRequest, mandate: OptimizationRequest,
    snapshot: CandidateUniverseSnapshot, policy: CandidateAdmissionPolicy,
) -> CandidateAdmissionResult:
    """Bind common static inputs to native contracts before projection/solving.

    Shared by execution and preflight: coefficient consistency must not depend
    on whether the expensive waterfall has run. Admission establishes data
    support only; it does not validate a proposed target's future limits.
    """
    if baseline.clo_terms is None or not baseline.notes:
        raise InputValidationError("Closing pool redesign requires a complete CLO baseline")
    if baseline.clo_opening_state is not None:
        raise InputValidationError("Closing pool redesign does not replay existing CLO holdings or future reinvestment trades")
    if baseline.coupon_proceeds_allocations:
        # Source instructions name an actual native receipt and funded claim.
        # Resizing or introducing a loan cannot reuse that evidence unchanged.
        raise InputValidationError("Closing pool redesign requires refreshed coupon proceeds balances and receipt instructions; automatic rebinding is unsupported")
    if baseline.credit_events:
        raise InputValidationError("Closing pool redesign does not yet support baseline credit events")
    if baseline.imported_collateral is not None:
        raise InputValidationError(
            "Closing pool redesign requires internally generated identified contracts; "
            "an imported target cashflow/par projection must be independently refreshed for the proposed holdings"
        )
    if mandate.settlement_date != baseline.clo_terms.closing_date or policy.settlement_date != mandate.settlement_date:
        raise InputValidationError("Redesign mandate/admission settlement must equal CLO closing date")
    if any(row.par_as_of_date != mandate.settlement_date for row in baseline.cashflow_request.positions):
        raise InputValidationError("Baseline contract holdings must share the redesign opening settlement date")
    mapping = baseline.factor_mapping
    provenance = selected_factor_provenance(mapping)
    if mandate.factor_provenance != provenance or snapshot.factor_provenance != provenance:
        raise InputValidationError("Redesign mandate/snapshot provenance must match the selected factor methodology label")
    admission = CandidateUniverseValidator().validate(snapshot, policy)
    candidates = {row.asset_id: row for row in admission.admitted}
    positions = {row.terms.loan_id: row for row in baseline.cashflow_request.positions}
    exposures = {row.loan_id: row for row in baseline.exposures}
    held = {row.asset.asset_id: row for row in mandate.holdings}
    if (len(positions) != len(baseline.cashflow_request.positions) or len(exposures) != len(baseline.exposures)
            or positions.keys() != exposures.keys() or held.keys() != positions.keys()):
        raise InputValidationError("Static holdings identities must match all baseline positions and exposures")
    for asset_id, holding in held.items():
        if holding.par != positions[asset_id].opening_balance:
            raise InputValidationError(f"{asset_id}: static held par differs from baseline contract")
        _check_descriptor(holding.asset, positions[asset_id], exposures[asset_id], mapping)
    for quote in mandate.quotes:
        candidate = candidates.get(quote.asset.asset_id)
        if candidate is None:
            reasons = next(("; ".join(row.reasons) for row in admission.quarantined if row.asset_id == quote.asset.asset_id),
                           "Candidate is absent from frozen snapshot")
            raise InputValidationError(f"{quote.asset.asset_id}: optimization quote is not admitted: {reasons}")
        _check_descriptor(candidate.asset, candidate.position, candidate.exposure, mapping)
        if not any(price.quote == quote for price in candidate.prices):
            raise InputValidationError(f"{quote.asset.asset_id}: optimization quote differs from admitted frozen side economics")
        if quote.side is TradeSide.SELL and (
            candidate.position != positions[quote.asset.asset_id] or candidate.exposure != exposures[quote.asset.asset_id]
        ):
            raise InputValidationError(f"{quote.asset.asset_id}: SELL snapshot contract/quality metadata differs from held baseline")
    return admission


class ClosingPoolRedesignService:
    """Generate, reconcile and independently replay one static closing proposal.

    No-op proposals remain a useful benchmark. This service verifies one
    proposal, rather than claiming nonlinear investor-return global optimality.
    Projection errors return named findings and preserve static solver evidence;
    inconsistent input identities/provenance fail before the solver runs.
    """

    def __init__(self, optimizer: StaticTradeOptimizer | None = None,
                 service: ModelProjectionRunner | None = None) -> None:
        self._optimizer = optimizer if optimizer is not None else StaticTradeOptimizer()
        self._service = service if service is not None else TridentModelService()

    def run(self, request: ClosingPoolRedesignRequest) -> ClosingPoolRedesignResult:
        """Admit data, verify static evidence, rebuild economics and replay CLO.

        The gates intentionally run in that order: a mathematically feasible
        solve is unusable if its facility, contract or quote is unsupported.
        The target is an independent opening design, not a mutation of the
        current portfolio or a use of its hypothetical SELL proceeds.
        """
        if not isinstance(request, ClosingPoolRedesignRequest):
            raise InputValidationError("request must be ClosingPoolRedesignRequest")
        baseline, mandate = request.baseline, request.optimization_request
        admission = validate_closing_pool_inputs(baseline, mandate, request.candidate_snapshot, request.admission_policy)
        candidates = {row.asset_id: row for row in admission.admitted}
        # Preserve a real no-trade projection even when the common mandate is
        # breached. It is evidence for performance comparison, not permission
        # to rank a noncompliant pool as eligible.
        baseline_result = self._service.run(baseline)
        findings = list(_projection_findings(baseline_result, "BASELINE", FindingSeverity.WARNING, None))
        optimization = self._optimizer.solve(mandate)
        if not optimization.validated:
            findings.append(ConstructionFinding("STATIC_PROPOSAL_REJECTED", "; ".join(optimization.violations)
                or optimization.solver_message, "OPTIMIZER", FindingSeverity.ERROR))
            return ClosingPoolRedesignResult(ConstructionStatus.STATIC_REJECTED, admission, optimization,
                baseline_result, None, None, None, (), (), tuple(findings), None)
        # Reconciliation failure is invalid evidence, not a projected economic
        # failure. Fail clearly instead of inventing a target from inconsistent
        # quantities or ignoring tampered optimizer results.
        plan = reconcile_proposal(mandate, optimization)
        target_request = None
        try:
            target_request = _target_request(baseline, plan, candidates)
            target_result = self._service.run(target_request)
        except (InputValidationError, ArithmeticError, CurveRangeError, MissingCurveError, RequiredFixingError) as exc:
            findings.append(ConstructionFinding("TARGET_PROJECTION_FAILED", str(exc), "TARGET", FindingSeverity.ERROR))
            return ClosingPoolRedesignResult(ConstructionStatus.REPLAY_FAILED, admission, optimization,
                baseline_result, plan, target_request, None, (), (), tuple(findings), None)
        findings.extend(_projection_findings(target_result, "TARGET", FindingSeverity.ERROR, request.minimum_equity_irr))
        comparisons, periods = compare_model_results(request.proposal_id, baseline, baseline_result, target_request, target_result)
        irr_a, irr_b = baseline_result.equity_irr, target_result.equity_irr
        improved = (irr_b.value > irr_a.value if irr_a.status is ReturnStatus.AVAILABLE
                    and irr_b.status is ReturnStatus.AVAILABLE and irr_a.value is not None and irr_b.value is not None else None)
        if improved is False and irr_b.value is not None and irr_a.value is not None and irr_b.value < irr_a.value:
            findings.append(ConstructionFinding("EQUITY_IRR_DETERIORATED", "Target equity IRR is below the independent no-trade baseline",
                                                "PERFORMANCE", FindingSeverity.WARNING))
        status = (ConstructionStatus.REPLAY_REJECTED if any(row.severity is FindingSeverity.ERROR for row in findings)
                  else ConstructionStatus.REPLAY_VALIDATED)
        return ClosingPoolRedesignResult(status, admission, optimization, baseline_result, plan, target_request,
            target_result, comparisons, periods, tuple(findings), improved)


def _target_request(baseline: TridentModelRequest, plan: TargetPoolPlan,
                    candidates: dict[str, CandidateAssetSnapshot]) -> TridentModelRequest:
    """Build target contracts, quality and actual acquisition cash uses together.

    Ending holdings identify the designed closing pool; quantities scale held
    principal schedules exactly. Retained purchase prices stay original, while
    new positions use their admitted BUY ask/accrued/fees. Static trade cash is
    deliberately absent: it belongs to a hypothetical settlement account,
    whereas this service rebuilds an independently funded initial portfolio.
    """
    if baseline.imported_collateral is not None:
        raise InputValidationError("Imported collateral must be refreshed for the target pool before closing redesign")
    cash = baseline.cashflow_request
    positions = {row.terms.loan_id: row for row in cash.positions}
    exposures = {row.loan_id: row for row in baseline.exposures}
    purchases = {row.loan_id: row for row in cash.purchases}
    trades = {row.asset_id: row for row in plan.trades}
    target_positions, target_exposures, target_purchases, target_oc_data = [], [], [], []
    oc_data = {row.loan_id: row for row in baseline.oc_asset_data}
    asset_level_oc = bool(baseline.clo_terms is not None and baseline.clo_terms.adjusted_oc_policy is not None
                          and baseline.clo_terms.adjusted_oc_policy.use_asset_level_test_data)
    acquisition_fees = Fraction(0)
    for holding in plan.holdings:
        asset_id, par = holding.asset.asset_id, holding.par
        if asset_id in positions:
            source, exposure, purchase = positions[asset_id], exposures[asset_id], purchases[asset_id]
            ratio = Fraction(par) / Fraction(source.opening_balance)
            purchase = replace(purchase, par=par, accrued_interest=post_currency(Fraction(purchase.accrued_interest) * ratio))
        else:
            candidate = candidates[asset_id]
            if asset_level_oc:
                raise InputValidationError(
                    f"{asset_id}: new BUY requires explicit, sourced CCC/discount OC classification; "
                    "candidate snapshots do not yet transport this classification"
                )
            source, exposure, trade = candidate.position, candidate.exposure, trades[asset_id]
            price = next(row.quote.clean_price_pct for row in candidate.prices if row.quote.side is TradeSide.BUY)
            purchase = AssetPurchase(asset_id, par, price, trade.accrued_cash)
            acquisition_fees += Fraction(trade.fee_cash)
        target_positions.append(_resize_position(source, par))
        target_exposures.append(replace(exposure, par=par))
        target_purchases.append(purchase)
        if asset_id in oc_data:
            # Acquisition price determines discount economics; an independently
            # sourced CCC market mark has a different meaning and stays frozen.
            parts = purchase.clean_price_pct.as_tuple()
            clean_fraction = Decimal((parts.sign, parts.digits, parts.exponent - 2))
            target_oc_data.append(replace(oc_data[asset_id], clean_price_fraction=clean_fraction))
    # A closing pool redesign adds actual BUY fees to its closing cash uses.
    # Preserve the explicitly selected cost mode instead of mixing an itemized
    # budget with aggregate upfront fees (which the funding layer rejects).
    cost_budget = cash.closing_cost_budget
    if cost_budget is not None and acquisition_fees:
        from trident.funding import ClosingCostItem
        identifier = "TRIDENT_POOL_ACQUISITION_FEES"
        if any(row.cost_id == identifier for row in cost_budget.fixed_costs):
            raise InputValidationError(f"Closing cost_id {identifier} is reserved for actual target BUY fees")
        cost_budget = replace(cost_budget, fixed_costs=(*cost_budget.fixed_costs,
            ClosingCostItem(identifier, post_currency(acquisition_fees))))
    target_fees = (post_currency(Fraction(cash.upfront_fees) + acquisition_fees)
                   if cost_budget is None else Decimal(0))
    return replace(baseline, cashflow_request=replace(cash, positions=tuple(target_positions),
        purchases=tuple(target_purchases), upfront_fees=target_fees, closing_cost_budget=cost_budget),
        exposures=tuple(target_exposures), oc_asset_data=tuple(target_oc_data))


def _projection_findings(result: TridentModelResult, source: str, severity: FindingSeverity,
                         minimum_equity_irr: Decimal | None) -> tuple[ConstructionFinding, ...]:
    """Explain configured replay failures without turning every action into a limit.

    Mandatory portfolio limits and OC/IC GATE rows are evaluated as configured.
    A later cure is visible but does not erase an earlier failed gate. IDT is a
    separate cash-diversion policy, so its transfer alone is not a hard breach.
    """
    findings: list[ConstructionFinding] = []
    clo = result.clo
    if clo is None or clo.status is not ProjectionStatus.COMPLETED or not clo.terminal_value_available:
        findings.append(ConstructionFinding("CLO_NOT_COMPLETE", "CLO terminal state is unavailable or not COMPLETED", source, severity))
    # Opening admission retains its pre-event economics. Full replay also
    # checks every modeled end-of-day quality observation, including a margin
    # dip that recovers before the next distribution. Legacy/custom runners
    # without observations retain their existing payment-date checks.
    for report in (result.opening_portfolio, *(result.portfolio_observations or result.portfolio_snapshots)):
        for limit in report.limits:
            if limit.status not in {LimitStatus.PASS, LimitStatus.NOT_APPLICABLE}:
                findings.append(ConstructionFinding(f"PORTFOLIO_LIMIT_{limit.status.value}",
                    f"{report.phase}: {limit.metric}; {limit.message}", source, severity, report.as_of_date, limit.limit_id))
    if clo is not None:
        for gate in clo.coverage_tests:
            if gate.stage != "GATE":
                continue
            for name in ("oc", "ic"):
                status, threshold = getattr(gate, f"{name}_status"), getattr(gate, f"{name}_minimum")
                if threshold is not None and status not in {CoverageStatus.PASS, CoverageStatus.NOT_APPLICABLE}:
                    findings.append(ConstructionFinding(f"{name.upper()}_GATE_{status.value}",
                        "Configured coverage gate did not pass; a later cure is reported separately", source, severity,
                        gate.payment_date, gate.class_id))
    for name, observation in (("EQUITY_IRR", result.equity_irr), ("EQUITY_MOIC", result.equity_moic)):
        if observation.status is not ReturnStatus.AVAILABLE or observation.value is None:
            findings.append(ConstructionFinding(f"{name}_UNAVAILABLE", observation.message, source, severity))
    irr = result.equity_irr
    if irr.status is ReturnStatus.AVAILABLE and irr.value is not None:
        if irr.value < 0:
            findings.append(ConstructionFinding("NEGATIVE_EQUITY_IRR", "Projected equity IRR is negative; no implicit minimum-return mandate was assumed",
                                                source, FindingSeverity.WARNING))
        if minimum_equity_irr is not None:
            # An AVAILABLE investor IRR has a unique one-sign-change root;
            # closing funding gives its initial negative cash direction. Test
            # the explicitly supplied rate,
            # rather than comparing it to a numerical root approximation:
            # XNPV(minimum) >= 0 iff IRR >= minimum. An exact one-year 5% return
            # must pass a 5% inclusive limit even when bisection reports a root
            # a few femtounits below .05. No mandate tolerance is introduced.
            try:
                threshold_value = xnpv(minimum_equity_irr, result.equity_cashflows)
            except InputValidationError as exc:
                findings.append(ConstructionFinding("MINIMUM_EQUITY_IRR_UNAVAILABLE", str(exc), source, severity))
            else:
                if threshold_value < 0:
                    findings.append(ConstructionFinding("MINIMUM_EQUITY_IRR_BREACH",
                        "Investor XNPV at the explicit minimum_equity_irr rate is negative", source, severity))
    return tuple(findings)
