"""Resolve monitoring phases from financial state, not an empty denominator.

The TERMINATED phase is a modeled lifecycle conclusion. It is never inferred
from zero performing collateral alone: debt, defaulted face, cash, fee/coupon
claims and future recovery activity can remain after the performing pool exits.
It changes only phase-scoped limits; metrics remain unavailable and an explicit
all-phase user limit continues to require its data. See docs/methodology/analysis.md.
"""

from datetime import date

from trident.clo.models import CloProjection, ProjectionStatus


# Generated portfolio-quality tests monitor a live collateral pool. They stop
# at a proved complete liquidation; user-authored LimitSpec phases are retained.
ACTIVE_PORTFOLIO_PHASES = ("CLOSING", "REINVESTMENT", "POST_REINVESTMENT")


def portfolio_phase(
    projection: CloProjection, snapshot_date: date, reinvestment_end_date: date | None,
) -> str:
    """Identify only the last fully settled snapshot as TERMINATED.

    COMPLETED/terminal_value_available are produced by the engine after its
    dated cash/recovery cursor checks, including future claims. Independently
    require every final balance to be zero so a contradictory completion flag
    cannot suppress quality monitoring. Earlier temporary empty snapshots and
    legal-final states with unpaid debt or claims stay in their active phase.
    """
    final_balances = (
        projection.final_collateral_par, projection.final_defaulted_par,
        projection.final_debt_par, projection.final_interest_cash,
        projection.final_principal_cash, projection.final_pending_interest_cash,
        projection.final_pending_principal_cash, projection.final_reserve,
        projection.final_senior_claims, projection.final_note_coupon_arrears,
        projection.final_subordinated_fee_arrears, projection.final_deferred_senior_expenses,
    )
    if (projection.periods and snapshot_date == projection.periods[-1].payment_date
            and projection.status is ProjectionStatus.COMPLETED
            and projection.terminal_value_available and all(value == 0 for value in final_balances)):
        return "TERMINATED"
    return ("REINVESTMENT" if reinvestment_end_date is not None and snapshot_date < reinvestment_end_date
            else "POST_REINVESTMENT")
