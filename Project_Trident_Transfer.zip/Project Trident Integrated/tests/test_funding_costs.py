"""Independent closing-use, contribution and itemized-budget known answers."""

from dataclasses import replace
from decimal import Decimal, Inexact, localcontext
import unittest

from trident.adapters.credit_example import credit_example_request
from trident.adapters.records import closing_cost_budget_from_records
from trident.application.clo_services import TridentModelService
from trident.application.services import CashflowRunService
from trident.domain.models import InputValidationError
from trident.funding import (
    AssetPurchase, ClosingCostBudget, ClosingCostItem, ClosingSourceType,
    DebtIssue, FundingEngine,
)

D = Decimal


class ItemizedClosingFundingTests(unittest.TestCase):
    def calculate(self, **kwargs):
        return FundingEngine().calculate((AssetPurchase("L", D(100), D(98), D(2)),),
            (DebtIssue("A", D(60), D(99)),), upfront_fees=D(0), cash_reserve=D(3), **kwargs)

    def test_legacy_fee_components_have_an_explicit_percentage_base(self):
        budget = ClosingCostBudget(D("500000000"), D("0.0075"), tuple(
            ClosingCostItem(identifier, D(amount)) for identifier, amount in (
                ("RATING", 250000), ("LEGAL", 350000), ("SETUP", 100000),
                ("LISTING", 50000), ("TAX", 100000), ("WAREHOUSE", 250000),
                ("HEDGE", 50000), ("OTHER", 100000))))
        # 500m * 0.75% = 3.75m; the eight fixed amounts sum to 1.25m.
        self.assertEqual(budget.arrangement_fee, D("3750000.00"))
        self.assertEqual(budget.other_upfront_costs, D("1250000.00"))
        self.assertEqual(budget.total, D("5000000.00"))

    def test_closing_uses_and_cash_sources_conserve_independently(self):
        budget = ClosingCostBudget(D(100), D("0.015"), (ClosingCostItem("LEGAL", D(4)),))
        result = self.calculate(closing_cost_budget=budget, other_initial_uses=D(6),
            other_initial_sources=D(8), other_initial_source_type=ClosingSourceType.EXTERNAL_CONTRIBUTION)
        # Uses 98 clean + 2 accrued + 5.50 costs + 3 reserve + 6 other =114.50.
        # Non-equity cash 59.40 note proceeds + 8 contribution =67.40.
        self.assertEqual(result.total_uses, D("114.50"))
        self.assertEqual(result.debt_proceeds, D("59.40"))
        self.assertEqual(result.equity_cash_funding, D("47.10"))
        self.assertEqual(result.total_sources, D("114.50"))
        self.assertEqual(result.upfront_fees, D("5.50"))
        self.assertEqual(result.arrangement_fee, D("1.50"))
        self.assertEqual(result.other_upfront_costs, D(4))
        self.assertEqual(result.other_initial_uses, D(6))
        self.assertEqual(result.other_initial_sources, D(8))

    def test_external_contribution_requires_positive_explicit_classification(self):
        with self.assertRaisesRegex(InputValidationError, "EXTERNAL_CONTRIBUTION"):
            self.calculate(other_initial_sources=D(1))
        for classification in ("EXTERNAL_CONTRIBUTION", "LOAN", True):
            with self.subTest(classification=classification), self.assertRaises(InputValidationError):
                self.calculate(other_initial_sources=D(1), other_initial_source_type=classification)

    def test_unknown_future_repayment_cannot_be_hidden_in_other_sources(self):
        with self.assertRaises(ValueError):
            ClosingSourceType("WAREHOUSE_FINANCING")

    def test_overfunding_contribution_requires_an_explicit_excess_cash_use(self):
        with self.assertRaisesRegex(InputValidationError, "overfunding"):
            self.calculate(other_initial_sources=D(100), other_initial_source_type=ClosingSourceType.EXTERNAL_CONTRIBUTION)

    def test_exact_zero_equity_is_permitted_but_not_forced_to_positive(self):
        result = self.calculate(other_initial_sources=D("43.60"),
            other_initial_source_type=ClosingSourceType.EXTERNAL_CONTRIBUTION)
        self.assertEqual(result.equity_cash_funding, D(0))

    def test_aggregate_and_component_costs_cannot_be_counted_twice(self):
        with self.assertRaisesRegex(InputValidationError, "double count"):
            FundingEngine().calculate((AssetPurchase("L", D(100), D(100)),), (),
                upfront_fees=D(1), cash_reserve=D(0), closing_cost_budget=ClosingCostBudget(D(100), D("0.01")))

    def test_half_cent_arrangement_fee_posts_once(self):
        budget = ClosingCostBudget(D(1), D("0.005"), (ClosingCostItem("LEGAL", D("0.01")),))
        self.assertEqual(budget.arrangement_fee, D("0.01"))
        self.assertEqual(budget.total, D("0.02"))

    def test_distinct_percentage_base_not_implicitly_overwritten_by_asset_par(self):
        result = self.calculate(closing_cost_budget=ClosingCostBudget(D(60), D("0.1")))
        self.assertEqual(result.arrangement_fee, D(6))
        self.assertEqual(result.upfront_fees, D(6))

    def test_duplicate_or_padded_component_ids_rejected(self):
        with self.assertRaises(InputValidationError):
            ClosingCostItem(" LEGAL", D(1))
        with self.assertRaisesRegex(InputValidationError, "Duplicate"):
            ClosingCostBudget(D(100), D(0), (ClosingCostItem("LEGAL", D(1)), ClosingCostItem("LEGAL", D(2))))

    def test_numeric_and_immutable_budget_validation(self):
        for args in ((D(-1), D(0)), (D(0), D("0.01")), (D(1), D(-1)), (D(1), 0.01)):
            with self.subTest(args=args), self.assertRaises(InputValidationError):
                ClosingCostBudget(*args)
        with self.assertRaises(InputValidationError):
            ClosingCostBudget(D(100), D(0), [])
        with self.assertRaises(InputValidationError):
            ClosingCostItem("LEGAL", D("1.001"))

    def test_exact_aggregation_preserves_small_cash_beside_extremely_large_costs(self):
        # Old precision was based only on purchase par and rounded away cents.
        giant = D("10000000000000000000000000000000000000000.00")
        with localcontext() as context:
            context.prec = 2
            context.traps[Inexact] = True
            result = FundingEngine().calculate((AssetPurchase("L", D("0.01"), D(100), giant),), (),
                upfront_fees=D("0.02"), cash_reserve=D("0.03"), other_initial_uses=D("0.04"))
            self.assertEqual(result.total_uses, D("10000000000000000000000000000000000000000.10"))
            self.assertEqual(result.equity_cash_funding, result.total_uses)

    def test_large_debt_proceeds_and_exact_small_equity(self):
        giant = D("10000000000000000000000000000000000000000")
        with localcontext() as context:
            context.prec = 2
            context.traps[Inexact] = True
            result = FundingEngine().calculate((AssetPurchase("L", D(1), giant),),
                (DebtIssue("A", D(1), giant),), upfront_fees=D("0.01"), cash_reserve=D(0))
            self.assertEqual(result.equity_cash_funding, D("0.01"))

    def test_budget_adapter_rejects_unknown_fields(self):
        with self.assertRaisesRegex(InputValidationError, "unregistered"):
            closing_cost_budget_from_records(({"cost_id": "LEGAL", "amount": 1, "rate": 2},),
                arrangement_fee_base=100, arrangement_fee_rate="0.01")

    def test_budget_adapter_uses_semantic_ids_and_explicit_fraction(self):
        budget = closing_cost_budget_from_records(({"amount": "0.01", "cost_id": "LEGAL"},),
            arrangement_fee_base="100", arrangement_fee_rate="0.005")
        self.assertEqual(budget.total, D("0.51"))

    def test_unified_full_clo_return_uses_actual_all_initial_cash_uses(self):
        request = credit_example_request()
        cash = replace(request.cashflow_request, other_initial_uses=D(7), other_initial_sources=D(2),
            other_initial_source_type=ClosingSourceType.EXTERNAL_CONTRIBUTION,
            closing_cost_budget=ClosingCostBudget(D(100), D("0.01"), (ClosingCostItem("LEGAL", D(4)),)))
        result = TridentModelService().run(replace(request, cashflow_request=cash))
        # Original40 funding +7 other +5 fees -2 gift =50; final equity20.
        self.assertEqual(result.cashflows.funding.equity_cash_funding, D(50))
        self.assertEqual(result.equity_cashflows[0].amount, D(-50))
        self.assertEqual(result.equity_moic.value, D("0.4"))

    def test_typed_application_rejects_cost_mode_conflict_before_projection(self):
        cash = credit_example_request().cashflow_request
        with self.assertRaisesRegex(InputValidationError, "double count"):
            replace(cash, upfront_fees=D(1), closing_cost_budget=ClosingCostBudget(D(100), D("0.01")))

    def test_application_validates_other_cash_inputs_before_projection(self):
        cash = credit_example_request().cashflow_request
        for values in ({"other_initial_uses": D(-1)}, {"other_initial_sources": D(1)},
                       {"other_initial_uses": D("0.001")}, {"closing_cost_budget": "fake"}):
            with self.subTest(values=values), self.assertRaises(InputValidationError):
                replace(cash, **values)

    def test_service_preserves_budget_details_in_funding_output(self):
        cash = credit_example_request().cashflow_request
        result = CashflowRunService().run(replace(cash, closing_cost_budget=ClosingCostBudget(D(500), D("0.002"))))
        self.assertEqual(result.funding.arrangement_fee, D(1))
        self.assertEqual(result.funding.equity_cash_funding, D(41))

    def test_application_aggregates_posted_principal_exactly_for_large_balances(self):
        cash = credit_example_request().cashflow_request
        original = cash.positions[0]
        giant = D("10000000000000000000000000000000000000000.00")
        positions = tuple(replace(original, terms=replace(original.terms, loan_id=identifier,
            reference_principal=par, fixed_rate=D(0)), opening_balance=par)
            for identifier, par in (("L_BIG", giant), ("L_CENT", D("0.01"))))
        request = replace(cash, positions=positions,
            purchases=tuple(AssetPurchase(row.terms.loan_id, row.opening_balance, D(100)) for row in positions), issues=())
        with localcontext() as context:
            context.prec = 2
            context.traps[Inexact] = True
            result = CashflowRunService().run(request)
            self.assertEqual(result.total_principal, D("10000000000000000000000000000000000000000.01"))
            self.assertEqual(result.funding.collateral_par, result.total_principal)


if __name__ == "__main__":
    unittest.main()
