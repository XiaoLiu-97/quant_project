"""External cashflow sources with independent cash and performing-par ledgers.

Detailed rows retain identified asset schedules. Simplified rows describe an
identified aggregate subpool, not invented asset contracts. Mixed consolidates
these two disjoint sources once. Imported credit/default/recovery memo values
are not extra receipts and never get applied a second time as a credit overlay.
An imported performing-par reduction need not equal principal cash (a stressed
pool can repay par, default, or recover claims); the difference is reported as
an external ledger adjustment and is not silently labelled a realized loss.
"""

from collections.abc import Mapping
from dataclasses import dataclass
from datetime import date
from decimal import Decimal
from enum import Enum
from fractions import Fraction
from types import MappingProxyType

from trident.credit.models import AssetCashSource, AssetCollection
from trident.domain.models import InputValidationError, require_date, require_money
from trident.domain.numeric import post_currency

ZERO = Decimal(0)
SIMPLIFIED_POOL_ID = "TRIDENT_SIMPLIFIED_POOL"


class CollateralCashflowInputMode(str, Enum):
    GENERATED = "GENERATED"
    DETAILED = "DETAILED"
    SIMPLIFIED = "SIMPLIFIED"
    MIXED = "MIXED"


def _text(value, label):
    if not isinstance(value, str) or not value or value != value.strip():
        raise InputValidationError(f"{label} must be a nonempty unpadded string")


def _signed_money(value, label):
    if not isinstance(value, Decimal) or not value.is_finite() or post_currency(Fraction(value)) != value:
        raise InputValidationError(f"{label} must be finite cent Decimal")


@dataclass(frozen=True, slots=True)
class DetailedImportedCashflow:
    """One externally calculated identified-asset period, including PIK bridge."""
    loan_id: str
    period_number: int
    payment_date: date
    beginning_par: Decimal
    cash_interest: Decimal
    principal_collection: Decimal
    ending_par: Decimal
    total_cash: Decimal
    pik_interest: Decimal = ZERO
    currency: str = "EUR"
    provenance: str = "USER_SUPPLIED_DETAILED_CASHFLOW"
    accrual_start: date | None = None
    accrual_end: date | None = None

    def __post_init__(self):
        _text(self.loan_id, "Detailed loan_id")
        _text(self.provenance, "Detailed provenance")
        if self.loan_id == SIMPLIFIED_POOL_ID:
            raise InputValidationError("Detailed loan ID collides with reserved simplified subpool")
        if type(self.period_number) is not int or self.period_number <= 0:
            raise InputValidationError("Detailed period_number must be positive integer")
        require_date(self.payment_date, "Detailed payment_date")
        if self.currency != "EUR":
            raise InputValidationError("Imported CLO cashflows must be EUR; no implicit FX conversion")
        for label in ("beginning_par", "principal_collection", "ending_par", "pik_interest"):
            require_money(getattr(self, label), f"Detailed {label}")
        _signed_money(self.cash_interest, "Detailed cash_interest")
        _signed_money(self.total_cash, "Detailed total_cash")
        if Fraction(self.total_cash) != Fraction(self.cash_interest) + Fraction(self.principal_collection):
            raise InputValidationError("Detailed total cash must equal cash interest plus principal")
        if Fraction(self.ending_par) != Fraction(self.beginning_par) + Fraction(self.pik_interest) - Fraction(self.principal_collection):
            raise InputValidationError("Detailed beginning par plus PIK less principal must equal ending par")
        for label in ("accrual_start", "accrual_end"):
            if getattr(self, label) is not None:
                require_date(getattr(self, label), f"Detailed {label}")
        if (self.accrual_start is None) != (self.accrual_end is None):
            raise InputValidationError("Detailed accrual dates must be provided together")
        if self.accrual_start is not None and self.accrual_end <= self.accrual_start:
            raise InputValidationError("Detailed accrual interval must be positive")

    @property
    def pik_capitalization_date(self) -> date:
        """Use contractual accrual end, bounded by any earlier cash settlement.

        A preceding payment convention may redeem the current coupon before
        nominal accrual end. Capitalize that coupon no later than its cash date
        so current PIK can be redeemed without a temporary negative face. When
        dates are absent, retain the explicit legacy settlement-time policy.
        This matches the native LoanCashflow capitalization-date convention.
        """
        return min(self.accrual_end, self.payment_date) if self.accrual_end else self.payment_date


@dataclass(frozen=True, slots=True)
class SimplifiedImportedCashflow:
    """One aggregate receipt; optional balances override principal=par fallback."""
    payment_date: date
    cash_interest: Decimal
    principal_collection: Decimal
    performing_par_reduction: Decimal | None = None
    ending_performing_par: Decimal | None = None
    defaulted_par_memo: Decimal = ZERO
    recovery_proceeds_memo: Decimal = ZERO
    currency: str = "EUR"
    provenance: str = "USER_SUPPLIED_SIMPLIFIED_CASHFLOW"

    def __post_init__(self):
        require_date(self.payment_date, "Simplified payment_date")
        _signed_money(self.cash_interest, "Simplified cash_interest")
        _text(self.provenance, "Simplified provenance")
        if self.currency != "EUR":
            raise InputValidationError("Imported CLO cashflows must be EUR; no implicit FX conversion")
        for label in ("principal_collection", "performing_par_reduction", "ending_performing_par", "defaulted_par_memo", "recovery_proceeds_memo"):
            if getattr(self, label) is not None:
                require_money(getattr(self, label), f"Simplified {label}")
        if self.recovery_proceeds_memo > self.principal_collection:
            raise InputValidationError("Recovery memo is part of principal cash, not an additional receipt")


@dataclass(frozen=True, slots=True)
class ImportedParMovement:
    """External performing-par bridge, with independent received principal.

    Defaulted memo observations are retained separately in source rows; they
    do not create an unrecovered default claim from insufficient information.
    PIK may increase detailed par and is never a cash interest receipt.
    """
    loan_id: str
    event_date: date
    performing_par_before: Decimal
    performing_par_after: Decimal
    principal_receipt: Decimal
    pik_interest: Decimal = ZERO
    source: AssetCashSource = AssetCashSource.SCHEDULED
    defaulted_par_before: Decimal = ZERO
    defaulted_par_after: Decimal = ZERO
    par_loss: Decimal = ZERO

    def __post_init__(self):
        _text(self.loan_id, "Imported movement loan_id")
        require_date(self.event_date, "Imported movement event_date")
        if self.source is not AssetCashSource.SCHEDULED:
            raise InputValidationError("External source bridge does not infer an asset terminating credit event")
        for label in ("performing_par_before", "performing_par_after", "principal_receipt", "pik_interest", "defaulted_par_before", "defaulted_par_after", "par_loss"):
            require_money(getattr(self, label), f"Imported movement {label}")
        if self.defaulted_par_before or self.defaulted_par_after or self.par_loss:
            raise InputValidationError("External memo fields cannot create default-claim or realized-loss state")

    @property
    def external_par_cash_difference(self) -> Decimal:
        return post_currency(Fraction(self.performing_par_before) + Fraction(self.pik_interest) -
                             Fraction(self.performing_par_after) - Fraction(self.principal_receipt))


@dataclass(frozen=True, slots=True)
class ImportedCollateralProjection:
    """Transport immutable source receipts and independently reconciled par."""
    collections: tuple[AssetCollection, ...]
    par_movements: tuple[ImportedParMovement, ...]
    opening_performing_par: Decimal
    loan_opening_par: Mapping[str, Decimal]
    final_principal_dates: Mapping[str, date]
    source_mode: CollateralCashflowInputMode
    credit_effects_included: bool
    detailed_rows: tuple[DetailedImportedCashflow, ...] = ()
    simplified_rows: tuple[SimplifiedImportedCashflow, ...] = ()
    pre_closing_row_count: int = 0
    projection_start_date: date | None = None

    def __post_init__(self):
        require_money(self.opening_performing_par, "Imported opening_performing_par", positive=True)
        if not isinstance(self.source_mode, CollateralCashflowInputMode) or type(self.credit_effects_included) is not bool:
            raise InputValidationError("Imported source mode and credit-effects flag must be typed")
        if type(self.collections) is not tuple or any(not isinstance(row, AssetCollection) for row in self.collections):
            raise InputValidationError("Imported collections must be immutable AssetCollection tuple")
        if type(self.par_movements) is not tuple or any(not isinstance(row, ImportedParMovement) for row in self.par_movements):
            raise InputValidationError("Imported par movements must be immutable ImportedParMovement tuple")
        if self.projection_start_date is not None:
            require_date(self.projection_start_date, "Imported projection start")
        opens = dict(self.loan_opening_par)
        dates = dict(self.final_principal_dates)
        if sum((Fraction(v) for v in opens.values()), Fraction()) != Fraction(self.opening_performing_par):
            raise InputValidationError("Imported identified subpool openings must reconcile to total opening par")
        if dates.keys() != opens.keys():
            raise InputValidationError("Imported final principal dates must identify every opening subpool")
        for value in opens.values():
            require_money(value, "Imported identified opening", positive=True)
        for value in dates.values():
            require_date(value, "Imported final principal date")
        balances = dict(opens)
        principal_moves = {}
        previous_date = self.projection_start_date or date.min
        for row in self.par_movements:
            if row.loan_id not in balances or row.event_date < previous_date or row.performing_par_before != balances[row.loan_id]:
                raise InputValidationError("Imported par movements must form an ordered continuous identified bridge")
            balances[row.loan_id] = row.performing_par_after
            previous_date = row.event_date
            key = row.loan_id, row.event_date
            # Pure PIK capitalization is a face event, not a zero-value cash
            # receipt. Only positive principal needs an actual dated matching
            # collection; otherwise a separate accrual date falsely appears
            # to require an additional cashflow record.
            if row.principal_receipt:
                principal_moves[key] = principal_moves.get(key, Fraction()) + Fraction(row.principal_receipt)
        previous_date = self.projection_start_date or date.min
        principal_cash = {}
        for row in self.collections:
            if row.loan_id not in opens or row.payment_date < previous_date:
                raise InputValidationError("Imported collections must be ordered and identify an opening subpool")
            previous_date = row.payment_date
            key = row.loan_id, row.payment_date
            if row.principal_collection:
                principal_cash[key] = principal_cash.get(key, Fraction()) + Fraction(row.principal_collection)
        if principal_cash != principal_moves:
            raise InputValidationError("Imported source principal cash must reconcile to identified dated bridge receipts")
        object.__setattr__(self, "loan_opening_par", MappingProxyType(opens))
        object.__setattr__(self, "final_principal_dates", MappingProxyType(dates))


def _compile_detailed_asset(
    identifier: str, rows: list[DetailedImportedCashflow], closing_date: date,
) -> tuple[list[AssetCollection], list[ImportedParMovement], Decimal, date]:
    """Separate the nominal period bridge from the dated physical face ledger.

    The source's beginning/ending fields describe successive contractual
    periods. With payment lag, PIK can increase held face before principal cash
    arrives, so those nominal balances cannot be reused as cash-date balances.
    Compile exact capitalization/principal deltas, then replay them once in
    date order. Dated PIK already capitalized strictly before closing belongs
    to opening face and is not applied a second time during the projection.
    """
    rows.sort(key=lambda row: (row.payment_date, row.period_number))
    nominal_balance, previous_period = rows[0].beginning_par, 0
    opening = Fraction(nominal_balance)
    previous_accrual_end = None
    collections: list[AssetCollection] = []
    # Each date holds [PIK capitalization, principal receipt]. Aggregating
    # simultaneous events capitalizes before redemption and preserves the old
    # one-movement-per-date shape when accrual and settlement dates coincide.
    deltas: dict[date, list[Fraction]] = {}
    for row in rows:
        if row.period_number <= previous_period or row.beginning_par != nominal_balance:
            raise InputValidationError(f"Detailed {identifier}: duplicated/reversed periods or discontinuous par bridge")
        if row.accrual_start is not None:
            if row.payment_date < row.accrual_start:
                raise InputValidationError(f"Detailed {identifier}: payment cannot precede its accrual start")
            if (previous_accrual_end is not None
                    and (row.accrual_end <= previous_accrual_end or row.accrual_start < previous_accrual_end)):
                raise InputValidationError(f"Detailed {identifier}: accrual intervals must be ordered and nonoverlapping")
            previous_accrual_end = row.accrual_end
        collections.append(AssetCollection(identifier, row.currency, row.payment_date, AssetCashSource.SCHEDULED,
            row.cash_interest, row.principal_collection, row.total_cash, row.period_number))
        deltas.setdefault(row.payment_date, [Fraction(), Fraction()])[1] += Fraction(row.principal_collection)
        if row.pik_interest:
            capitalization_date = row.pik_capitalization_date
            if capitalization_date < closing_date:
                opening += Fraction(row.pik_interest)
            else:
                deltas.setdefault(capitalization_date, [Fraction(), Fraction()])[0] += Fraction(row.pik_interest)
        nominal_balance, previous_period = row.ending_par, row.period_number
    movements: list[ImportedParMovement] = []
    balance = opening
    for when, (pik, principal) in sorted(deltas.items()):
        after = balance + pik - principal
        if after < 0:
            raise InputValidationError(f"Detailed {identifier}: dated principal receipts exceed available performing face")
        movements.append(ImportedParMovement(identifier, when, post_currency(balance), post_currency(after),
                                            post_currency(principal), post_currency(pik)))
        balance = after
    # A later zero-face cash-only row is an interest receivable, not a
    # remaining performing loan whose principal maturity was extended.
    final_date = max(row.payment_date for row in rows if row.beginning_par > 0 or row.ending_par > 0)
    return collections, movements, post_currency(opening), final_date


def compile_imported_cashflows(
    mode: CollateralCashflowInputMode, closing_date: date,
    opening_performing_par: Decimal,
    detailed_rows: tuple[DetailedImportedCashflow, ...] = (),
    simplified_rows: tuple[SimplifiedImportedCashflow, ...] = (),
    simplified_opening_performing_par: Decimal | None = None,
    credit_effects_included: bool = False, overlay_enabled: bool = False,
) -> ImportedCollateralProjection:
    """Compile active sources once, preserving all future rows beyond legal final.

    Rows before closing are excluded from projected receipts and par movements;
    opening balances already describe the closing snapshot. Optional ending par
    takes precedence only when it reconciles to an also-supplied reduction.
    A three-field aggregate row explicitly falls back to principal=par reduction.
    Duplicate aggregate dates are rejected because multiple ending balances at
    one date have no unambiguous order; combine cash for that date before import.
    """
    require_date(closing_date, "Imported closing_date")
    require_money(opening_performing_par, "Imported opening_performing_par", positive=True)
    if not isinstance(mode, CollateralCashflowInputMode) or mode is CollateralCashflowInputMode.GENERATED:
        raise InputValidationError("Imported mode must be Detailed, Simplified or Mixed")
    if type(credit_effects_included) is not bool or type(overlay_enabled) is not bool:
        raise InputValidationError("Imported credit flags must be boolean")
    if credit_effects_included and overlay_enabled:
        raise InputValidationError("Already stressed imported cashflows cannot receive another credit/prepayment overlay")
    if type(detailed_rows) is not tuple or any(not isinstance(row, DetailedImportedCashflow) for row in detailed_rows):
        raise InputValidationError("Detailed rows must be an immutable typed tuple")
    if type(simplified_rows) is not tuple or any(not isinstance(row, SimplifiedImportedCashflow) for row in simplified_rows):
        raise InputValidationError("Simplified rows must be an immutable typed tuple")
    detail_active = mode in {CollateralCashflowInputMode.DETAILED, CollateralCashflowInputMode.MIXED}
    simple_active = mode in {CollateralCashflowInputMode.SIMPLIFIED, CollateralCashflowInputMode.MIXED}
    if detail_active and not detailed_rows or simple_active and not simplified_rows:
        raise InputValidationError("Each selected imported source requires cashflow rows")
    collections, movements, opens, final_dates = [], [], {}, {}
    active_details = detailed_rows if detail_active else ()
    active_simple = simplified_rows if simple_active else ()
    grouped = {}
    for row in active_details:
        if row.payment_date >= closing_date:
            grouped.setdefault(row.loan_id, []).append(row)
    for identifier, rows in grouped.items():
        asset_collections, asset_movements, opens[identifier], final_dates[identifier] = _compile_detailed_asset(
            identifier, rows, closing_date)
        collections.extend(asset_collections)
        movements.extend(asset_movements)
    if simple_active:
        inferred = post_currency(Fraction(opening_performing_par) - sum((Fraction(v) for v in opens.values()), Fraction()))
        if mode is CollateralCashflowInputMode.SIMPLIFIED:
            simple_opening = opening_performing_par
            if simplified_opening_performing_par not in (None, ZERO, simple_opening):
                raise InputValidationError("Simplified opening must equal total opening collateral par")
        else:
            if simplified_opening_performing_par in (None, ZERO):
                if any(row.ending_performing_par is not None for row in active_simple):
                    raise InputValidationError("Mixed ending-par rows require explicit simplified subpool opening par")
                simple_opening = inferred
            else:
                simple_opening = simplified_opening_performing_par
                if simple_opening != inferred:
                    raise InputValidationError("Mixed detailed plus simplified opening par must equal total opening par")
        require_money(simple_opening, "Simplified subpool opening", positive=True)
        opens[SIMPLIFIED_POOL_ID] = simple_opening
        previous, seen = simple_opening, set()
        future_rows = sorted((row for row in active_simple if row.payment_date >= closing_date), key=lambda row: row.payment_date)
        if not future_rows:
            raise InputValidationError("Simplified source requires at least one on/after-closing row")
        for number, row in enumerate(future_rows, 1):
            if row.payment_date in seen:
                raise InputValidationError("Duplicate simplified payment dates require one consolidated par bridge")
            seen.add(row.payment_date)
            derived = None if row.ending_performing_par is None else Fraction(previous) - Fraction(row.ending_performing_par)
            reduction = Fraction(row.performing_par_reduction) if row.performing_par_reduction is not None else derived
            if reduction is None:
                reduction = Fraction(row.principal_collection)
            if derived is not None and derived != reduction:
                raise InputValidationError("Simplified explicit reduction does not reconcile to ending performing par")
            if reduction < 0 or reduction > Fraction(previous):
                raise InputValidationError("Simplified performing par cannot increase or become negative")
            ending = post_currency(Fraction(previous) - reduction)
            collections.append(AssetCollection(SIMPLIFIED_POOL_ID, row.currency, row.payment_date, AssetCashSource.SCHEDULED,
                                               row.cash_interest, row.principal_collection,
                                               post_currency(Fraction(row.cash_interest) + Fraction(row.principal_collection)), number))
            movements.append(ImportedParMovement(SIMPLIFIED_POOL_ID, row.payment_date, previous, ending, row.principal_collection))
            previous = ending
        final_dates[SIMPLIFIED_POOL_ID] = future_rows[-1].payment_date
    elif simplified_opening_performing_par not in (None, ZERO):
        raise InputValidationError("Simplified opening par is inactive in Detailed mode")
    return ImportedCollateralProjection(tuple(sorted(collections, key=lambda row: (row.payment_date, row.loan_id, row.contractual_period_number))),
                                        tuple(sorted(movements, key=lambda row: (row.event_date, row.loan_id))),
                                        opening_performing_par, opens, final_dates, mode, credit_effects_included,
                                        active_details, active_simple,
                                        sum(row.payment_date < closing_date for row in (*active_details, *active_simple)), closing_date)


def allocate_purchased_accrued(par_by_loan: Mapping[str, Decimal], total: Decimal) -> Mapping[str, Decimal]:
    """Allocate explicit historical coupon claim by opening par, in exact cents.

    This declared allocation assumption supports the old aggregate B111 input;
    identified acquired accrued on the asset tape is preferred when available.
    Tied leftover cents use loan ID order, making the result deterministic.
    """
    require_money(total, "Purchased accrued total")
    if not isinstance(par_by_loan, Mapping) or not par_by_loan:
        raise InputValidationError("Purchased accrued allocation requires identified opening pars")
    for key, value in par_by_loan.items():
        _text(key, "Purchased accrued loan_id")
        require_money(value, "Purchased accrued allocation par", positive=True)
    par = sum((Fraction(value) for value in par_by_loan.values()), Fraction())
    cents = int(Fraction(total) * 100)
    targets = {key: Fraction(cents) * Fraction(value) / par for key, value in par_by_loan.items()}
    amounts = {key: value.numerator // value.denominator for key, value in targets.items()}
    residual = cents - sum(amounts.values())
    for key in sorted(amounts, key=lambda key: (-(targets[key] - amounts[key]), key))[:residual]:
        amounts[key] += 1
    return MappingProxyType({key: post_currency(Fraction(value, 100)) for key, value in amounts.items()})


def inherited_accrued_collections(
    accrued_by_loan: Mapping[str, Decimal], collections: tuple[AssetCollection, ...],
    default_dates: Mapping[str, date] | None = None,
) -> tuple[AssetCollection, ...]:
    """Return only additional acquired-coupon claim receipts, without principal.

    Claim is collected at the first scheduled coupon or earlier prepayment.
    Default on/before that date forfeits it under this explicit cash-pay policy;
    a separately specified recovery of missed interest is not inferred. Same-day
    scheduled cash precedes default consistently with the existing credit engine.
    Imported already-full coupon streams must not use this helper a second time.
    """
    defaults = {} if default_dates is None else dict(default_dates)
    output = []
    for identifier, amount in accrued_by_loan.items():
        _text(identifier, "Inherited accrued loan_id")
        require_money(amount, "Inherited accrued amount")
        if not amount:
            continue
        eligible = [row for row in collections if row.loan_id == identifier and row.source in {AssetCashSource.SCHEDULED, AssetCashSource.PREPAYMENT}]
        if not eligible:
            if identifier in defaults:
                continue
            raise InputValidationError(f"Inherited accrued claim {identifier} has no identified future coupon receipt")
        first = min(eligible, key=lambda row: (row.payment_date, row.source is AssetCashSource.PREPAYMENT))
        if identifier in defaults and defaults[identifier] < first.payment_date:
            continue
        output.append(AssetCollection(identifier, first.currency, first.payment_date, first.source,
                                      amount, ZERO, amount, first.contractual_period_number))
    return tuple(sorted(output, key=lambda row: (row.payment_date, row.loan_id)))


def inherited_accrued_for_overlay(
    accrued_by_loan: Mapping[str, Decimal], collections: tuple,
    par_movements: tuple,
) -> tuple:
    """Settle historical coupon claims against partial default/prepayment slices.

    Each pre-coupon default forfeits the matching fraction of the still-unpaid
    claim. An earlier partial prepayment receives only its proportional claim;
    the first scheduled coupon receives the surviving remainder. Scheduled cash
    executes before same-date default/prepayment, matching the base engine.
    Paid cents are cumulative-target differences so installment rounding cannot
    pay more than the explicitly acquired cent claim. This does not recover
    defaulted historical interest or create a claim from coupon-rate history.
    """
    from trident.credit.overlay import OverlayCollection
    output = []
    for identifier, amount in accrued_by_loan.items():
        _text(identifier, "Overlay acquired loan_id")
        require_money(amount, "Overlay acquired accrued")
        if not amount:
            continue
        receipts = [row for row in collections if row.loan_id == identifier and
                    row.source in {AssetCashSource.SCHEDULED, AssetCashSource.PREPAYMENT}]
        movements = [row for row in par_movements if row.loan_id == identifier]
        prepay_moves = {(row.event_date, row.source): row for row in movements if row.source is AssetCashSource.PREPAYMENT}
        # Only default and claim cash operations change this separate receivable.
        events = [(row.payment_date, 0 if row.source is AssetCashSource.SCHEDULED else 2, row) for row in receipts]
        events.extend((row.event_date, 1, row) for row in movements if row.source is AssetCashSource.DEFAULT)
        events.sort(key=lambda item: (item[0], item[1]))
        remaining, cumulative_paid, posted_paid = Fraction(amount), Fraction(), ZERO
        if not events:
            raise InputValidationError(f"Acquired accrued claim {identifier} requires an identified receipt/default path")
        for _, order, row in events:
            if not remaining:
                break
            if order == 1:
                before = Fraction(row.performing_par_before)
                reduction = before - Fraction(row.performing_par_after)
                if before <= 0 or not 0 <= reduction <= before:
                    raise InputValidationError("Acquired accrued default slice must reconcile to performing par")
                remaining *= (before - reduction) / before
                continue
            if row.source is AssetCashSource.SCHEDULED:
                claim_payment = remaining
            else:
                movement = prepay_moves.get((row.payment_date, AssetCashSource.PREPAYMENT))
                if movement is None:
                    raise InputValidationError("Acquired accrued partial prepayment requires an identified par bridge")
                before = Fraction(movement.performing_par_before)
                prepaid = before - Fraction(movement.performing_par_after)
                if before <= 0 or not 0 <= prepaid <= before:
                    raise InputValidationError("Acquired accrued prepayment slice must reconcile to performing par")
                claim_payment = remaining * prepaid / before
            remaining -= claim_payment
            cumulative_paid += claim_payment
            cumulative_posted = post_currency(cumulative_paid)
            payment = post_currency(Fraction(cumulative_posted) - Fraction(posted_paid))
            posted_paid = cumulative_posted
            if payment:
                output.append(OverlayCollection(identifier, row.currency, row.payment_date, row.source,
                                                payment, ZERO, payment, row.contractual_period_number))
    return tuple(sorted(output, key=lambda row: (row.payment_date, row.loan_id,
                                                row.source is AssetCashSource.PREPAYMENT)))
