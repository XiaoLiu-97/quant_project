"""Named operational interfaces for a reviewable first deployment.

Inputs remain separate from computed reports. The transport extends schema 0.7
in memory, so an existing saved workbook gains the interfaces atomically after
a successful run. No sheet address carries financial meaning.
"""

from types import MappingProxyType

INPUTS = {
    'clo_opening': ('CLO Opening', ('as_of_date', 'timing', 'forward_equity_value', 'equity_value_source', 'use_ledger_snapshot', 'initial_collateral_par', 'source')),
    'clo_opening_accounts': ('Opening CLO Accounts', ('account', 'balance', 'source')),
    'clo_opening_claims': ('Opening CLO Claims', ('claim_type', 'class_id', 'amount', 'source')),
    'clo_retired_assets': ('Retired Ledger Assets', ('asset_id', 'source')),
    'principal_accrued_balances': ('Principal Accrued', ('loan_id', 'as_of_date', 'amount', 'source', 'legal_reference')),
    'coupon_proceeds_allocations': ('Proceeds Allocations', ('allocation_id', 'loan_id', 'payment_date',
        'collection_source', 'principal_amount', 'original_principal_permission', 'source', 'legal_reference')),
    'seasoned_positions': ('Seasoned Positions', ('scope', 'loan_id', 'opening_accrued_interest', 'entitlement_policy', 'source')),
    'opening_fixings': ('Opening Fixings', ('scope', 'loan_id', 'fixing_date', 'index_rate')),
    'observation_dates': ('Observation Dates', ('observation_date', 'source')),
    'benchmarks': ('Benchmarks', ('observation_date', 'entity_type', 'entity_id', 'metric', 'stage',
                               'expected', 'tolerance', 'unit', 'source', 'reference_id')),
    'ledger_controls': ('Ledger Controls', ('as_of_date', 'horizon_date', 'currency', 'principal_cash', 'interest_cash',
        'allow_principal_for_accrued', 'allow_principal_for_fees', 'source')),
    'opening_holdings': ('Opening Holdings', ('asset_id', 'currency', 'settled_par', 'status')),
    'trade_ledger': ('Trade Ledger', ('trade_id', 'asset_id', 'side', 'trade_date', 'settlement_date', 'par',
        'clean_price_pct', 'accrued_cash', 'fees_cash', 'accrued_account', 'fee_account', 'lot_size', 'minimum_ticket', 'maximum_par')),
    'ledger_events': ('Ledger Events', ('event_id', 'event_date', 'kind', 'asset_id', 'principal_cash', 'interest_cash',
        'par_reduction', 'trade_id', 'receivable_id', 'source')),
    'opening_receivables': ('Opening Receivables', ('receivable_id', 'asset_id', 'recognition_date', 'due_date',
        'principal_cash', 'interest_cash', 'source')),
}
OUTPUTS = {
    'clo_opening_audit': ('CLO Opening Audit', ('category', 'identifier', 'amount', 'unit', 'as_of_date', 'source', 'message')),
    'coupon_proceeds_audit': ('Proceeds Audit', ('allocation_id', 'loan_id', 'payment_date', 'collection_source',
        'raw_coupon_cash', 'raw_principal_cash', 'principal_accrued_restored', 'interest_proceeds',
        'principal_proceeds', 'remaining_principal_accrued', 'original_principal_permission', 'receipt_rows',
        'balance_source', 'allocation_source', 'legal_reference')),
    'run_audit': ('Pilot Status', ('readiness_status', 'reconciliation_status', 'ledger_status', 'calculated_at',
        'message', 'mode', 'scope', 'software_version', 'schema_version', 'run_id', 'input_sha256')),
    'reconciliation_catalog': ('Calculated References', ('observation_date', 'entity_type', 'entity_id',
        'metric', 'stage', 'value', 'unit', 'status', 'message')),
    'reconciliation_results': ('Reconciliation', ('observation_date', 'entity_type', 'entity_id', 'metric',
        'stage', 'expected', 'actual', 'difference', 'tolerance', 'unit', 'status', 'source', 'reference_id', 'message')),
    'readiness_findings': ('Pilot Findings', ('code', 'severity', 'entity_id', 'observation_date', 'message')),
    'seasoned_audit': ('Accrual Audit', ('loan_id', 'projection_date', 'original_anchor', 'opening_par',
        'opening_accrued_interest', 'entitlement_policy', 'first_payment_date', 'first_cash_interest', 'historical_fixing_count', 'source')),
    'ledger_snapshots': ('Ledger Cash', ('as_of_date', 'currency', 'settled_par', 'performing_par', 'defaulted_par',
        'committed_buy_par', 'committed_sell_par', 'trade_date_par', 'principal_cash', 'interest_cash',
        'reserved_principal', 'reserved_interest', 'available_principal', 'available_interest', 'receivable_principal', 'receivable_interest')),
    'ledger_positions': ('Holdings Timeline', ('as_of_date', 'asset_id', 'currency', 'status', 'settled_par', 'available_to_sell')),
    'ledger_journal': ('Ledger Journal', ('event_date', 'event_type', 'reference_id', 'asset_id',
        'principal_cash_change', 'interest_cash_change', 'settled_par_change', 'source')),
    'ledger_pending': ('Pending Items', ('kind', 'reference_id', 'asset_id', 'due_date', 'side', 'par',
        'principal_cash', 'interest_cash', 'source')),
}
INPUT_TABLES = tuple(INPUTS)
OUTPUT_TABLES = tuple(OUTPUTS)
DESCRIPTORS = MappingProxyType({**INPUTS, **OUTPUTS})
COLUMNS = MappingProxyType({key: value[1] for key, value in DESCRIPTORS.items()})

INSTRUCTIONS = {
    'clo_opening': 'Optional existing CLO: one POST_DISTRIBUTION row at an original adjusted payment boundary. Keep original closing and first-note-payment controls. Supply an explicit current equity value for forward IRR. Ledger import requires a reconciled final snapshot at this date; future trades are not replayed into the waterfall.',
    'clo_opening_accounts': 'Opening physical balances and separate subsets: PRINCIPAL, INTEREST, RESERVE, PENDING_PRINCIPAL, PENDING_INTEREST, ORIGINAL_PRINCIPAL_REINVESTMENT, PENDING_ORIGINAL_PRINCIPAL_REINVESTMENT, HELD_DIVERSION. Enter all eight, including explicit zeros. Designations are not extra cash. Use cents and a source.',
    'clo_opening_claims': 'NOTE_COUPON for every debt class, including explicit zeros. Also SENIOR_EXPENSES, SENIOR_MANAGEMENT, SUBORDINATED_MANAGEMENT and DEFERRED_SENIOR_EXPENSES, with blank class_id. These are unpaid pre-opening claims, not the next current coupon. Enter all four fees, including zeros, and sources.',
    'clo_retired_assets': 'Optional verified retired identities retained at zero par by a linked ledger. Supply asset_id and source after confirming no remaining cash claim. They are excluded from Assets and future projection. Only valid with use_ledger_snapshot TRUE.',
    'principal_accrued_balances': 'Optional verified remaining principal-financed accrued claim, not asset par or a new receipt. One positive cent balance per native loan at the model opening date, with settlement/trustee source and governing legal reference. Supply one equal full-restoration allocation. Empty tables retain ordinary coupon classification.',
    'coupon_proceeds_allocations': 'Explicit full restoration of one matching Principal Accrued balance at its first positive native SCHEDULED or PREPAYMENT coupon receipt. Enter a unique allocation ID, actual date, equal EUR amount, explicit TRUE/FALSE original-principal permission, source and legal reference. Requires CLO_BASELINE with Scenario, Optimizer and Candidate Search disabled. Imported flows, pool overlay, claimed-loan default and call profiles are unsupported.',
    'coupon_proceeds_audit': 'Calculated actual receipt classification: raw borrower cash remains unchanged; restored accrued moves from interest to principal proceeds without reducing asset par. Remaining claim and original-principal permission are EUR amounts. Receipt rows count underlying cash records. Review sources and legal reference; this report does not prove legal eligibility.',
    'seasoned_positions': 'Optional ASSET/CANDIDATE mid-period opening: retain original contractual anchor. FULL_CURRENT_PERIOD validates historical accrued and posts the full coupon once; POST_ASOF_ONLY excludes history and requires zero; EXPLICIT_CASH_CLAIM adds an agreed cent claim. State the source; purchase accrued cost is separate.',
    'opening_fixings': 'Actual historical EURIBOR observations for seasoned positions, in annual fractions (0.03 = 3%). Dates must match the original reset schedule. Future resets use the frozen market provider.',
    'observation_dates': 'Optional transaction determination/review dates, with source. Dates supplement the finite post-event calendar; they do not introduce waterfall payment gates.',
    'benchmarks': 'Paste keys and units from Calculated References, then enter independently obtained expected values, absolute tolerances, source and reference ID. MATCH certifies only the supplied comparisons.',
    'ledger_controls': 'Optional operational ledger: exactly one row activates it. Supply known opening cash, explicit dates and cash-account permissions with transaction source. Only an explicitly linked reconciled post-distribution snapshot can initialize the CLO opening; the ledger alone does not activate the waterfall.',
    'opening_holdings': 'Settled holdings at the ledger opening date. PERFORMING or DEFAULTED; do not include unsettled buys here. Input commitments separately and preserve asset identity for zero-par claims.',
    'trade_ledger': 'Frozen commitments for review, never orders. Explicit trade/settlement dates and cents cash components; PRINCIPAL or INTEREST account routing for accrued/fees. Pre-opening unsettled trades are opening commitments.',
    'ledger_events': 'Explicit events: CASH_COLLECTION, CASH_PAYMENT, RECEIVABLE_COLLECTION, DEFAULT, WRITE_OFF, TRADE_CANCEL. CASH_PAYMENT uses positive debit amounts. Due dates do not create cash; a receivable collection must reference its claim.',
    'opening_receivables': 'Known opening cash claims and due dates, with source. A collection event is required to turn a claim into cash; do not also enter it as an unlinked cash collection.',
}


def formats(columns: tuple[str, ...]) -> dict[str, str]:
    """Presentation units do not alter the values or tolerances being tested."""
    return {key: ('yyyy-mm-dd' if key.endswith('_date') or key in {'projection_date', 'original_anchor'}
                  else '0.00000000' if key in {'index_rate', 'expected', 'actual', 'value', 'difference', 'tolerance'}
                  else '#,##0.00' if (key == 'original_principal_permission' and 'raw_coupon_cash' in columns) or key in {'opening_par', 'opening_accrued_interest', 'first_cash_interest', 'amount', 'balance', 'forward_equity_value', 'initial_collateral_par',
                      'principal_amount', 'raw_coupon_cash', 'raw_principal_cash', 'principal_accrued_restored',
                      'interest_proceeds', 'principal_proceeds', 'remaining_principal_accrued'}
                  else 'General') for key in columns}
