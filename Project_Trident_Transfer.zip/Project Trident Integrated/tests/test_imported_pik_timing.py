"""Independent dated-face identities and native/export/import PIK parity.

The hand ledger separates capitalization from actual received principal. The
integration cases then prove that exporting a contractual tape and selecting
it as Detailed collateral cannot silently change the same CLO's OC or cash.
"""

from dataclasses import replace
from datetime import date
from decimal import Decimal
from fractions import Fraction
import unittest

from trident.adapters.detailed_export import detailed_cashflow_records
from trident.adapters.imported_records import detailed_from_records
from trident.analysis.models import AssetExposure, MetricStatus
from trident.application.clo_services import TridentModelService
from trident.application.imported_cashflows import (
    CollateralCashflowInputMode as Mode, DetailedImportedCashflow as Detailed,
    compile_imported_cashflows,
)
from trident.application.portfolio_snapshots import build_opening_portfolio
from trident.conventions.calendar import BusinessDayConvention
from trident.credit.overlay import OriginalPoolOverlay
from trident.domain.models import AmortizationType, InputValidationError, InterestMode

import test_native_pik_credit as native_pik_fixtures


D = Decimal
START = date(2026, 1, 1)
CAP = date(2026, 4, 1)
CASH = date(2026, 4, 3)


class ImportedPikTimingTests(unittest.TestCase):
    def hand_rows(self, *, dated=True):
        dates = dict(accrual_start=START, accrual_end=CAP) if dated else {}
        first = Detailed("L", 1, CASH, D(100), D(0), D(20), D(83), D(20), D(3), **dates)
        dates = dict(accrual_start=CAP, accrual_end=date(2026, 7, 1)) if dated else {}
        final = Detailed("L", 2, date(2026, 7, 3), D(83), D(0), D("85.49"),
                         D(0), D("85.49"), D("2.49"), **dates)
        return first, final

    def test_dated_pik_capitalizes_before_lagged_principal_receipt(self):
        projection = compile_imported_cashflows(Mode.DETAILED, START, D(100), self.hand_rows())
        self.assertEqual([(row.event_date, row.performing_par_before, row.performing_par_after,
                           row.principal_receipt, row.pik_interest) for row in projection.par_movements], [
            (CAP, D(100), D(103), D(0), D(3)),
            (CASH, D(103), D(83), D(20), D(0)),
            (date(2026, 7, 1), D(83), D("85.49"), D(0), D("2.49")),
            (date(2026, 7, 3), D("85.49"), D(0), D("85.49"), D(0)),
        ])
        self.assertEqual(sum(row.principal_collection for row in projection.collections), D("105.49"))
        self.assertTrue(all(row.external_par_cash_difference == 0 for row in projection.par_movements))

    def test_undated_detailed_source_retains_cash_date_capitalization(self):
        projection = compile_imported_cashflows(Mode.DETAILED, START, D(100), self.hand_rows(dated=False))
        self.assertEqual([(row.event_date, row.pik_interest) for row in projection.par_movements],
                         [(CASH, D(3)), (date(2026, 7, 3), D("2.49"))])

    def test_preclosing_capitalization_is_opening_face_and_not_replayed(self):
        projection = compile_imported_cashflows(Mode.DETAILED, date(2026, 4, 2), D(103), self.hand_rows())
        self.assertEqual(projection.loan_opening_par, {"L": D(103)})
        self.assertEqual(projection.par_movements[0].performing_par_before, D(103))
        self.assertEqual(sum(row.pik_interest for row in projection.par_movements), D("2.49"))
        self.assertTrue(all(row.event_date >= date(2026, 4, 2) for row in projection.par_movements))
        self.assertEqual(Fraction(projection.opening_performing_par)
                         + sum((Fraction(row.pik_interest) for row in projection.par_movements), Fraction()),
                         sum((Fraction(row.principal_collection) for row in projection.collections), Fraction()))

    def test_on_closing_capitalization_remains_a_projected_event(self):
        projection = compile_imported_cashflows(Mode.DETAILED, CAP, D(100), self.hand_rows())
        self.assertEqual(projection.loan_opening_par["L"], D(100))
        self.assertEqual(projection.par_movements[0].event_date, CAP)
        self.assertEqual(projection.par_movements[0].pik_interest, D(3))

    def test_preceding_payment_capitalizes_current_pik_before_redemption(self):
        cash, accrual_end = date(2026, 4, 2), date(2026, 4, 4)
        row = Detailed("L", 1, cash, D(100), D(0), D(103), D(0), D(103), D(3),
                       accrual_start=START, accrual_end=accrual_end)
        projection = compile_imported_cashflows(Mode.DETAILED, START, D(100), (row,))
        self.assertEqual(row.pik_capitalization_date, cash)
        self.assertEqual([(movement.event_date, movement.performing_par_after, movement.pik_interest)
                          for movement in projection.par_movements], [(cash, D(0), D(3))])

    def test_payment_before_accrual_start_is_rejected(self):
        row = replace(self.hand_rows()[0], accrual_start=date(2026, 4, 4), accrual_end=date(2026, 5, 1))
        with self.assertRaisesRegex(InputValidationError, "payment cannot precede"):
            compile_imported_cashflows(Mode.DETAILED, START, D(100), (row,))

    def test_overlapping_dated_periods_are_rejected(self):
        first, final = self.hand_rows()
        final = replace(final, accrual_start=date(2026, 3, 31))
        with self.assertRaisesRegex(InputValidationError, "ordered and nonoverlapping"):
            compile_imported_cashflows(Mode.DETAILED, START, D(100), (first, final))

    def test_separate_capitalization_does_not_weaken_principal_cash_validation(self):
        projection = compile_imported_cashflows(Mode.DETAILED, START, D(100), self.hand_rows())
        forged = replace(projection.collections[0], principal_collection=D(19), total_cash=D(19))
        with self.assertRaisesRegex(InputValidationError, "principal cash"):
            replace(projection, collections=(forged, *projection.collections[1:]))

    def test_active_imported_pik_rejects_explicit_non_pik_classification(self):
        projection = compile_imported_cashflows(Mode.DETAILED, START, D(100), self.hand_rows())
        exposure = AssetExposure("L", "OBLIGOR", "BSL", "CORPORATE", "GB", "SECTOR", "EUR",
                                 D(100), None, date(2026, 7, 1), is_pik=False)
        with self.assertRaisesRegex(InputValidationError, "positive PIK coupon contradicts"):
            build_opening_portfolio((exposure,), (), START, imported_collateral=projection)

    def test_positive_source_pik_certifies_unknown_but_zero_pik_does_not_prove_cash(self):
        exposure = AssetExposure("L", "OBLIGOR", "BSL", "CORPORATE", "GB", "SECTOR", "EUR",
                                 D(100), None, date(2026, 7, 1), is_pik=None)
        pik = compile_imported_cashflows(Mode.DETAILED, START, D(100), self.hand_rows())
        proved = build_opening_portfolio((exposure,), (), START, imported_collateral=pik).metric("PIK_FRACTION")
        self.assertEqual((proved.value, proved.status, proved.coverage), (D(1), MetricStatus.AVAILABLE, D(1)))
        cash_row = Detailed("L", 1, date(2026, 7, 1), D(100), D(5), D(100), D(0), D(105))
        cash = compile_imported_cashflows(Mode.DETAILED, START, D(100), (cash_row,))
        unknown = build_opening_portfolio((exposure,), (), START, imported_collateral=cash).metric("PIK_FRACTION")
        self.assertIsNone(unknown.value)
        self.assertEqual(unknown.status, MetricStatus.UNAVAILABLE)


class NativeDetailedPikParityTests(unittest.TestCase):
    def assert_roundtrip(self, request):
        native = TridentModelService().run(request)
        records = detailed_cashflow_records(native.cashflows.cashflows, request.cashflow_request.positions)
        imported = compile_imported_cashflows(Mode.DETAILED, request.clo_terms.closing_date,
            native.cashflows.opening_collateral_par, detailed_from_records(records))
        external = TridentModelService().run(replace(request, imported_collateral=imported))
        # Compare the actual cash/face ledger and its OC snapshots. Optional
        # coupon provenance and maturity/WAL availability intentionally differ
        # for externally supplied tapes; they must not alter waterfall money.
        self.assertEqual(external.clo.periods, native.clo.periods)
        self.assertEqual(external.clo.coverage_tests, native.clo.coverage_tests)
        self.assertEqual(external.clo.tranche_periods, native.clo.tranche_periods)
        self.assertEqual(external.equity_cashflows, native.equity_cashflows)
        self.assertEqual(external.equity_irr, native.equity_irr)
        return native, external

    def test_native_full_pik_lag_export_import_preserves_every_period_and_oc(self):
        request = native_pik_fixtures.NativePikUnifiedServiceTests().request(lag=2)
        native, external = self.assert_roundtrip(request)
        self.assertEqual(native.clo.periods[0].closing_collateral_par, D(103))
        self.assertEqual(external.clo.periods[0].closing_collateral_par, D(103))

    def test_native_mixed_amortizing_lag_roundtrip_preserves_cash_and_oc(self):
        request = native_pik_fixtures.NativePikUnifiedServiceTests().request(lag=2)
        position = request.cashflow_request.positions[0]
        position = replace(position, terms=replace(position.terms,
            interest_mode=InterestMode.MIXED, pik_fraction=D(".5"),
            amortization_type=AmortizationType.LINEAR_INITIAL_PAR, amortization_fraction=D(".25")))
        request = replace(request, cashflow_request=replace(request.cashflow_request, positions=(position,)))
        self.assert_roundtrip(request)

    def test_native_preceding_final_redemption_roundtrip_preserves_current_pik(self):
        request = native_pik_fixtures.NativePikUnifiedServiceTests().request()
        maturity = date(2026, 4, 18)  # Saturday; principal settles before nominal end.
        position = request.cashflow_request.positions[0]
        position = replace(position, terms=replace(position.terms, maturity_date=maturity,
            business_day_convention=BusinessDayConvention.PRECEDING))
        request = replace(request,
            cashflow_request=replace(request.cashflow_request, positions=(position,)),
            exposures=(replace(request.exposures[0], maturity_date=maturity),))
        native, _ = self.assert_roundtrip(request)
        self.assertLess(native.cashflows.cashflows[-1].payment_date, maturity)
        self.assertEqual(native.clo.periods[0].closing_collateral_par, D(0))

    def test_lag_roundtrip_keeps_cdr_cpr_on_the_same_source_cash_dates(self):
        overlay = OriginalPoolOverlay(True, annual_default_rate=D(".1"), annual_prepayment_rate=D(".2"),
                                      recovery_rate=D(".5"), recovery_lag_months=2)
        request = native_pik_fixtures.NativePikUnifiedServiceTests().request(lag=2, overlay=overlay)
        native, external = self.assert_roundtrip(request)
        source_cash_dates = {row.payment_date for row in native.cashflows.cashflows}
        from trident.credit.models import AssetCashSource
        self.assertTrue(all(row.payment_date in source_cash_dates
            for row in external.clo.original_overlay_projection.collections
            if row.source is AssetCashSource.PREPAYMENT))


if __name__ == "__main__":
    unittest.main()
