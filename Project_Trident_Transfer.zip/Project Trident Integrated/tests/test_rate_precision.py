"""Exact floating-rate composition must precede half-cent monetary posting.

The independently known boundary is 10 * rate * (90/360) = half a cent when
rate=.002. Any strictly smaller positive rate posts zero, not one cent. The
same signed argument applies to standalone negative coupons. Supply tails
beyond both loan and CLO ledger-context precisions to detect early rounding.
"""

import unittest
from datetime import date
from decimal import Decimal, Inexact, ROUND_DOWN, localcontext
from fractions import Fraction

from trident.adapters.model_records import notes_from_records
from trident.adapters.records import position_from_record
from trident.cashflows import ContractualCashflowEngine
from trident.clo import CloRunRequest, CloTerms, DeterministicCloEngine, NoteTranche, ProjectionStatus
from trident.conventions import AccrualDateBasis, BusinessDayConvention
from trident.domain.models import CouponType, LoanPosition, LoanTerms
from trident.domain.numeric import basis_points_rate, compose_floating_rate
from trident.market import FlatRateProvider

D = Decimal
CLOSE = date(2026, 1, 20)
END = date(2026, 4, 20)  # Both business dates, exactly90 calendar days.
BELOW_TIE = D("0.001" + "9" * 65)
BELOW_TIE_BPS = D("19." + "9" * 65)
HALF_CENT = Fraction(1, 200)


def _loan_row(index: Decimal, *, spread=D(0), floor=None):
    terms = LoanTerms(
        "PRECISION_ASSET", "EUR", CLOSE, END, D(10), CouponType.FLOATING,
        rate_index="EURIBOR_3M", spread_bps=spread, index_floor=floor,
        business_day_convention=BusinessDayConvention.UNADJUSTED,
        accrual_date_basis=AccrualDateBasis.UNADJUSTED,
    )
    row, = ContractualCashflowEngine(FlatRateProvider({"EURIBOR_3M": index})).generate(
        LoanPosition(terms, CLOSE, D(10)),
    )
    return row


def _clo(index: Decimal, *, spread=D(0), floor=None):
    # Independent support receivable:20*.01*90/360=.05interest and20principal.
    terms = LoanTerms("SUPPORT_ASSET", "EUR", CLOSE, END, D(20), CouponType.FIXED, fixed_rate=D(".01"))
    assets = ContractualCashflowEngine(FlatRateProvider({})).generate(LoanPosition(terms, CLOSE, D(20)))
    note = NoteTranche("A", 1, D(10), CouponType.FLOATING, rate_index="EURIBOR_3M", spread_bps=spread, index_floor=floor)
    return DeterministicCloEngine(FlatRateProvider({"EURIBOR_3M": index})).run(
        CloRunRequest(assets, D(20), (note,), CloTerms(CLOSE, END)),
    )


class FloatingRatePrecisionTests(unittest.TestCase):
    def test_complete_finite_basis_point_digits_survive_conversion(self) -> None:
        self.assertEqual(Fraction(basis_points_rate(BELOW_TIE_BPS)), Fraction(BELOW_TIE_BPS) / 10000)
        for value in (D(0), D("-123.456789"), D("1e-80"), D("9e80")):
            with self.subTest(value=value):
                self.assertEqual(Fraction(basis_points_rate(value)), Fraction(value) / 10000)

    def test_exact_rate_sum_retains_cancellation_tails_and_applies_floor_before_margin(self) -> None:
        rate = compose_floating_rate(D("-.002"), BELOW_TIE_BPS)
        self.assertEqual(Fraction(rate), Fraction(D("-.002")) + Fraction(BELOW_TIE_BPS) / 10000)
        self.assertLess(rate, D(0))  # It must not become a rounded zero.
        floored = compose_floating_rate(D("-.03"), D(300), D(".01"))
        self.assertEqual(floored, D(".04"))

    def test_asset_near_tie_index_cannot_be_rounded_up_before_posting(self) -> None:
        self.assertLess(Fraction(10) * Fraction(BELOW_TIE) / 4, HALF_CENT)
        row = _loan_row(BELOW_TIE)
        self.assertEqual(row.all_in_rate, BELOW_TIE)
        self.assertEqual(row.cash_interest, D("0.00"))
        self.assertEqual(row.total_cash, D(10))

    def test_signed_asset_near_tie_cannot_be_rounded_away_from_zero_early(self) -> None:
        rate = BELOW_TIE.copy_negate()
        self.assertGreater(Fraction(10) * Fraction(rate) / 4, -HALF_CENT)
        self.assertEqual(_loan_row(rate).cash_interest, D("0.00"))

    def test_asset_high_precision_spread_and_nonzero_sum_keep_correct_side(self) -> None:
        cases = ((D(0), BELOW_TIE_BPS), (D(".001"), D("9." + "9" * 65)))
        for index, spread in cases:
            with self.subTest(index=index, spread=spread):
                exact = Fraction(index) + Fraction(spread) / 10000
                self.assertLess(Fraction(10) * exact / 4, HALF_CENT)
                row = _loan_row(index, spread=spread)
                self.assertEqual(Fraction(row.all_in_rate), exact)
                self.assertEqual(row.cash_interest, D(0))

    def test_asset_high_precision_floor_is_not_reduced_to_display_precision(self) -> None:
        row = _loan_row(D(0), floor=BELOW_TIE)
        self.assertEqual(row.all_in_rate, BELOW_TIE)
        self.assertEqual(row.cash_interest, D(0))

    def test_note_index_spread_and_floor_preserve_half_cent_equity_allocation(self) -> None:
        cases = ((BELOW_TIE, D(0), None), (D(0), BELOW_TIE_BPS, None), (D(0), D(0), BELOW_TIE),
                 (D(".001"), D("9." + "9" * 65), None))
        for index, spread, floor in cases:
            with self.subTest(index=index, spread=spread, floor=floor):
                result = _clo(index, spread=spread, floor=floor)
                first, = result.tranche_periods
                self.assertEqual(first.current_coupon_due, D(0))
                self.assertEqual(result.status, ProjectionStatus.COMPLETED)
                self.assertEqual(result.total_equity_distributions, D("10.05"))
                self.assertEqual(result.periods[0].cash_conservation_residual, D(0))
                self.assertEqual(result.final_debt_par, D(0))

    def test_asset_and_note_floor_adapters_preserve_all_supplied_basis_point_digits(self) -> None:
        asset = dict(
            loan_id="FLOOR_ASSET", currency="EUR", credit_status="PERFORMING", pik=False, revolver=False,
            construction_risk=False, holiday_calendar="TARGET", cashflow_projection_start_date=CLOSE,
            par_as_of_date=CLOSE, maturity_date_unadjusted=END, frequency_months=3,
            coupon_type="FLOATING", amortization_type="BULLET", initial_par="10", current_par="10",
            schedule_anchor_day=20, day_count="ACT_360", rate_index="EURIBOR_3M", spread_bps="0",
            index_floor_bps=str(BELOW_TIE_BPS), business_day_convention="UNADJUSTED",
            accrual_date_basis="UNADJUSTED", fixing_lag_target_business_days=2,
        )
        note_row = dict(
            class_id="A", instrument_type="DEBT", payment_priority=1, nominal_amount="10",
            coupon_type="FLOATING", rate_index="EURIBOR_3M", spread_bps="0", index_floor_bps=str(BELOW_TIE_BPS),
            day_count="ACT_360", frequency_months=3, schedule_anchor_day=20,
            business_day_convention="MODIFIED_FOLLOWING", accrual_date_basis="ADJUSTED",
            holiday_calendar="TARGET", fixing_lag_target_business_days=2,
        )
        with localcontext() as caller:
            caller.prec = 2
            caller.traps[Inexact] = True
            position = position_from_record(asset)
            note, = notes_from_records((note_row, {"class_id": "EQ", "instrument_type": "EQUITY"}), CloTerms(CLOSE, END))
        expected = Fraction(BELOW_TIE_BPS) / 10000
        self.assertEqual(Fraction(position.terms.index_floor), expected)
        self.assertEqual(Fraction(note.index_floor), expected)
        row, = ContractualCashflowEngine(FlatRateProvider({"EURIBOR_3M": D(0)})).generate(position)
        self.assertEqual(row.cash_interest, D(0))

    def test_exact_ties_and_above_ties_still_round_away_from_zero(self) -> None:
        for rate in (D(".002"), D(".002" + "0" * 65 + "1")):
            with self.subTest(rate=rate):
                self.assertEqual(_loan_row(rate).cash_interest, D(".01"))
                self.assertEqual(_loan_row(rate.copy_negate()).cash_interest, D("-.01"))
                self.assertEqual(_clo(rate).tranche_periods[0].current_coupon_due, D(".01"))

    def test_helpers_and_both_engines_ignore_low_precision_caller_context(self) -> None:
        expected_loan = _loan_row(D(".001"), spread=D("9." + "9" * 65))
        expected_note = _clo(BELOW_TIE)
        with localcontext() as caller:
            caller.prec = 2
            caller.rounding = ROUND_DOWN
            caller.traps[Inexact] = True
            self.assertEqual(Fraction(basis_points_rate(BELOW_TIE_BPS)), Fraction(BELOW_TIE_BPS) / 10000)
            self.assertEqual(Fraction(compose_floating_rate(D(".001"), D("9." + "9" * 65))),
                             Fraction(D(".001")) + Fraction(D("9." + "9" * 65)) / 10000)
            self.assertEqual(_loan_row(D(".001"), spread=D("9." + "9" * 65)), expected_loan)
            self.assertEqual(_clo(BELOW_TIE), expected_note)

    def test_rate_numeric_utilities_reject_nonfinite_or_nondecimal_inputs(self) -> None:
        for invalid in (0.1, True, None, D("NaN"), D("Infinity")):
            with self.subTest(invalid=invalid):
                with self.assertRaises(ValueError):
                    basis_points_rate(invalid)
                with self.assertRaises(ValueError):
                    compose_floating_rate(invalid, D(0))
                with self.assertRaises(ValueError):
                    compose_floating_rate(D(0), invalid)


if __name__ == "__main__":
    unittest.main()
