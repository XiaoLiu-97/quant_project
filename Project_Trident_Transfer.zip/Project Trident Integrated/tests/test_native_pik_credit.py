"""Conservation and economic-order tests across native PIK credit scenarios."""

import unittest
from dataclasses import replace
from datetime import date
from decimal import Decimal
from fractions import Fraction

from trident.cashflows.engine import ContractualCashflowEngine
from trident.conventions.day_count import DayCount
from trident.conventions.calendar import BusinessDayConvention
from trident.credit.engine import CreditEventCashflowEngine
from trident.credit.models import AssetCashSource, DefaultEvent, PrepaymentEvent, RecoveryEvent
from trident.credit.overlay import OriginalPoolOverlay, OverlayCollection, OverlayParMovement
from trident.domain.models import InputValidationError, InterestMode, LoanPosition
from trident.market.rates import FlatRateProvider
from trident.adapters.credit_example import credit_example_request
from trident.application.clo_services import TridentModelService
from trident.clo.models import ProjectionStatus

import test_native_coupon_migration as native_coupon_fixtures
from test_native_coupon_migration import fixed_terms

D = Decimal


def pik_position(**changes):
    values = dict(interest_mode=InterestMode.PIK, pik_fraction=D(1))
    values.update(changes)
    terms = fixed_terms(**values)
    return LoanPosition(terms, terms.start_date, terms.reference_principal)


class NativePikCreditTests(unittest.TestCase):
    def setUp(self):
        self.rates = FlatRateProvider({"EURIBOR_3M": D(".025")})
        self.contractual = ContractualCashflowEngine(self.rates)
        self.credit = CreditEventCashflowEngine(self.rates)

    def assert_bridge(self, result):
        self.assertEqual(result.opening_par + result.total_pik_interest,
            result.final_performing_par + result.final_defaulted_par
            + result.total_principal_collections + result.total_par_loss)
        for row in result.par_movements:
            self.assertEqual(row.performing_par_before + row.defaulted_par_before + row.non_cash_par_change,
                row.performing_par_after + row.defaulted_par_after + row.principal_receipt + row.par_loss)
        for row in result.collections:
            self.assertEqual(row.total_cash, row.cash_interest + row.principal_collection)

    def test_no_event_collects_terminal_enlarged_principal_not_pik_interest(self):
        result = self.credit.generate(pik_position())
        self.assertEqual(result.total_pik_interest, D("12.55"))
        self.assertEqual(result.total_scheduled_principal, D("112.55"))
        self.assertEqual(result.total_cash_interest, 0)
        self.assert_bridge(result)

    def test_horizon_capitalizes_only_completed_boundaries(self):
        result = self.credit.generate(pik_position(), horizon_date=date(2026, 5, 1))
        self.assertEqual(result.final_performing_par, D(103))
        self.assertEqual(result.total_pik_interest, D(3))
        self.assertEqual(result.total_principal_collections, 0)
        self.assert_bridge(result)

    def test_default_before_first_boundary_has_no_unposted_pik_exposure(self):
        loan = pik_position()
        result = self.credit.generate(loan, DefaultEvent(loan.terms.loan_id, date(2026, 2, 1)))
        self.assertEqual(result.defaulted_exposure, D(100))
        self.assertEqual(result.total_pik_interest, 0)
        self.assertEqual(result.total_cash_interest, 0)
        self.assert_bridge(result)

    def test_default_on_coupon_date_occurs_after_current_pik_capitalization(self):
        loan = pik_position()
        result = self.credit.generate(loan, DefaultEvent(loan.terms.loan_id, date(2026, 7, 1),
            (RecoveryEvent(date(2026, 8, 1), D(".5")),), date(2026, 8, 1)))
        self.assertEqual(result.defaulted_exposure, D("106.09"))
        self.assertEqual(result.total_pik_interest, D("6.09"))
        self.assertEqual(result.total_recovery_principal, D("53.05"))
        self.assertEqual(result.total_par_loss, D("53.04"))
        self.assert_bridge(result)

    def test_prepaid_pik_is_capitalized_and_redeemed_without_cash_coupon(self):
        loan = pik_position()
        result = self.credit.generate(loan, PrepaymentEvent(loan.terms.loan_id, date(2026, 2, 15)))
        self.assertEqual(result.total_pik_interest, D("1.47"))  #100*.12*44/360.
        self.assertEqual(result.total_prepayment_principal, D("101.47"))
        self.assertEqual(result.total_cash_interest, 0)
        self.assert_bridge(result)

    def test_same_date_prepayment_does_not_capitalize_current_coupon_twice(self):
        loan = pik_position()
        result = self.credit.generate(loan, PrepaymentEvent(loan.terms.loan_id, date(2026, 4, 1)))
        self.assertEqual(result.total_pik_interest, D(3))
        self.assertEqual(result.total_prepayment_principal, D(103))
        self.assertEqual(result.par_movements[-1].non_cash_par_change, 0)
        self.assert_bridge(result)

    def test_mixed_prepayment_cash_interest_keeps_only_cash_share(self):
        loan = pik_position(interest_mode=InterestMode.MIXED, pik_fraction=D(".5"))
        result = self.credit.generate(loan, PrepaymentEvent(loan.terms.loan_id, date(2026, 2, 15)))
        self.assertEqual(result.total_pik_interest, D(".73"))
        self.assertEqual(result.total_cash_interest, D(".74"))
        self.assertEqual(result.total_prepayment_principal, D("100.73"))
        self.assert_bridge(result)

    def test_forged_reference_pik_is_rejected_even_with_balanced_cash_and_par(self):
        loan = pik_position()
        rows = self.contractual.generate(loan)
        forged = (replace(rows[0], pik_interest=D(4), closing_balance=D(104)), *rows[1:])
        with self.assertRaisesRegex(InputValidationError, "coupon differs"):
            self.credit.apply(loan, forged)

    def test_forged_prepaid_capitalization_cannot_satisfy_coupon_validator(self):
        loan = pik_position()
        result = self.credit.generate(loan, PrepaymentEvent(loan.terms.loan_id, date(2026, 2, 15)))
        receipt = replace(result.collections[-1], principal_collection=D("102.47"), total_cash=D("102.47"))
        move = replace(result.par_movements[-1], non_cash_par_change=D("2.47"), principal_receipt=D("102.47"))
        with self.assertRaisesRegex(InputValidationError, "Prepayment cash interest"):
            replace(result, collections=(receipt,), par_movements=(move,), total_prepayment_principal=D("102.47"),
                total_principal_collections=D("102.47"))

    def test_overnight_partial_prepaid_pik_uses_frozen_projected_period_factor(self):
        setup = native_coupon_fixtures.NativeOvernightMigrationTests()
        terms = setup.terms(interest_mode=InterestMode.PIK, pik_fraction=D(1))
        loan = LoanPosition(terms, terms.start_date, D(10100))
        result = CreditEventCashflowEngine(setup.provider()).generate(loan,
            PrepaymentEvent(terms.loan_id, date(2026, 5, 1)))
        self.assertEqual(result.total_pik_interest, D(100))  #30/90 of frozen300.
        self.assertEqual(result.total_prepayment_principal, D(10200))
        self.assert_bridge(result)

    def test_credit_lag_still_requires_dated_receivable_profile(self):
        loan = pik_position(payment_lag_business_days=2)
        with self.assertRaisesRegex(InputValidationError, "zero contractual payment lag"):
            self.credit.generate(loan)

    def test_unadjusted_weekend_pik_boundary_is_not_moved_to_later_cash_date(self):
        loan = pik_position(start_date=date(2026, 1, 4), maturity_date=date(2026, 4, 4),
            business_day_convention=BusinessDayConvention.FOLLOWING)
        with self.assertRaisesRegex(InputValidationError, "coincident accrual and cash dates"):
            self.credit.generate(loan)


class NativePikFractionalOverlayTests(unittest.TestCase):
    def run_overlay(self, loan, overlay, horizon=None):
        rows = ContractualCashflowEngine(FlatRateProvider({"EURIBOR_3M": D(".025")})).generate(loan)
        result = overlay.project(rows, {loan.terms.loan_id: loan.opening_balance}, loan.par_as_of_date,
            horizon or loan.terms.maturity_date, loan_day_counts={loan.terms.loan_id: loan.terms.day_count})
        for asset in result.assets:
            non_cash = sum((Fraction(m.non_cash_par_change) for m in asset.par_movements), Fraction())
            principal = sum((Fraction(c.principal_collection) for c in asset.collections), Fraction())
            self.assertEqual(Fraction(asset.opening_par) + non_cash,
                Fraction(asset.final_performing_par) + Fraction(asset.final_defaulted_par)
                + Fraction(asset.total_par_loss) + principal)
        return rows, result

    def test_disabled_overlay_preserves_full_native_pik_reference(self):
        rows, result = self.run_overlay(pik_position(), OriginalPoolOverlay(False))
        self.assertEqual(sum(c.total_cash for c in result.collections), D("112.55"))
        self.assertEqual(sum(m.non_cash_par_change for m in result.par_movements), D("12.55"))
        self.assertEqual([c.cash_interest for c in result.collections], [r.cash_interest for r in rows])

    def test_disabled_mixed_overlay_preserves_reference_cent_postings(self):
        rows, result = self.run_overlay(pik_position(interest_mode=InterestMode.MIXED, pik_fraction=D(".5")), OriginalPoolOverlay(False))
        self.assertEqual([c.cash_interest for c in result.collections], [r.cash_interest for r in rows])
        self.assertEqual([c.principal_collection for c in result.collections], [r.principal_repayment for r in rows])

    def test_full_default_forfeits_current_pik_and_recovers_only_existing_face(self):
        _, result = self.run_overlay(pik_position(), OriginalPoolOverlay(True,
            annual_default_rate=D(1), recovery_rate=D(".5"), recovery_lag_months=0))
        self.assertEqual(sum(m.non_cash_par_change for m in result.par_movements), 0)
        self.assertEqual(sum(c.principal_collection for c in result.collections), D(50))
        self.assertEqual(result.total_par_loss, D(50))
        self.assertEqual(result.final_defaulted_par, 0)

    def test_full_cpr_includes_boundary_capitalization_in_par_paid_off(self):
        _, result = self.run_overlay(pik_position(), OriginalPoolOverlay(True, annual_default_rate=D(0), annual_prepayment_rate=D(1)))
        self.assertEqual(sum(m.non_cash_par_change for m in result.par_movements), D(3))
        self.assertEqual(sum(c.principal_collection for c in result.collections if c.source is AssetCashSource.PREPAYMENT), D(103))
        self.assertEqual(result.final_performing_par, 0)

    def test_combined_cdr_cpr_and_recovery_have_conserved_nonnegative_ledgers(self):
        _, result = self.run_overlay(pik_position(interest_mode=InterestMode.MIXED, pik_fraction=D(".6")),
            OriginalPoolOverlay(True, annual_default_rate=D(".2"), annual_prepayment_rate=D(".1"),
                recovery_rate=D(".4"), recovery_lag_months=2), date(2027, 4, 1))
        self.assertEqual(result.final_performing_par, 0)
        self.assertEqual(result.final_defaulted_par, 0)
        self.assertGreater(result.total_par_loss, 0)
        self.assertTrue(all(m.non_cash_par_change >= 0 for m in result.par_movements))

    def test_partial_horizon_does_not_capitalize_unpaid_future_coupon(self):
        _, result = self.run_overlay(pik_position(), OriginalPoolOverlay(False), date(2026, 5, 1))
        self.assertEqual(sum(m.non_cash_par_change for m in result.par_movements), D(3))
        self.assertEqual(result.final_performing_par, D(103))

    def external_lag_reference(self):
        first, first_cash, final, final_cash = date(2026, 4, 1), date(2026, 4, 3), date(2026, 7, 1), date(2026, 7, 3)
        receipts = (OverlayCollection("L", "EUR", first_cash, AssetCashSource.SCHEDULED, D(5), D(0), D(5)),
            OverlayCollection("L", "EUR", final_cash, AssetCashSource.SCHEDULED, D(5), D("106.09"), D("111.09")))
        moves = (OverlayParMovement("L", first, AssetCashSource.SCHEDULED, D(100), D(103), D(0), D(0), D(0), D(0), D(3)),
            OverlayParMovement("L", final, AssetCashSource.SCHEDULED, D(103), D("106.09"), D(0), D(0), D(0), D(0), D("3.09")),
            OverlayParMovement("L", final_cash, AssetCashSource.SCHEDULED, D("106.09"), D(0), D(0), D(0), D("106.09"), D(0)))
        return receipts, moves, {"L": frozenset((first_cash, final_cash))}

    def test_external_native_lag_cpr_occurs_only_on_source_cash_dates(self):
        receipts, moves, dates = self.external_lag_reference()
        result = OriginalPoolOverlay(True, annual_default_rate=D(0), annual_prepayment_rate=D(1)).project_external(
            receipts, moves, {"L": D(100)}, date(2026, 1, 1), date(2026, 7, 3), prepayment_dates_by_loan=dates)
        prepayments = [c for c in result.collections if c.source is AssetCashSource.PREPAYMENT]
        self.assertEqual([(c.payment_date, c.principal_collection) for c in prepayments], [(date(2026, 4, 3), D(103))])
        self.assertEqual(sum(c.cash_interest for c in result.collections), D(5))
        self.assertEqual(sum(m.non_cash_par_change for m in result.par_movements), D(3))

    def test_external_native_lag_cpr_hazard_retains_full_cash_interval(self):
        receipts, moves, dates = self.external_lag_reference()
        result = OriginalPoolOverlay(True, annual_default_rate=D(0), annual_prepayment_rate=D(".2")).project_external(
            receipts, moves, {"L": D(100)}, date(2026, 1, 1), date(2026, 7, 3), prepayment_dates_by_loan=dates)
        first = next(c for c in result.collections if c.source is AssetCashSource.PREPAYMENT)
        # Independent binary arithmetic is adequate away from a cent tie:
        # the interval is 92 days from the prior actual cash boundary, not the
        # two days between capitalization and this receipt.
        expected = D(str(103 * (1 - .8 ** (92 / 365)))).quantize(D(".01"))
        self.assertEqual(first.principal_collection, expected)

    def test_external_prepayment_calendar_rejects_missing_unknown_and_mutable_inputs(self):
        receipts, moves, dates = self.external_lag_reference()
        for bad in ({}, {"UNKNOWN": frozenset()}, {"L": {date(2026, 4, 3)}},
                    {"L": frozenset((date(2026, 4, 1),))}):
            with self.subTest(bad=bad), self.assertRaises(InputValidationError):
                OriginalPoolOverlay(False).project_external(receipts, moves, {"L": D(100)},
                    date(2026, 1, 1), date(2026, 7, 3), prepayment_dates_by_loan=bad)


class NativePikUnifiedServiceTests(unittest.TestCase):
    """Check actual cash/face reaches the waterfall and monitoring together."""

    def request(self, *, lag=0, events=(), overlay=None):
        base = credit_example_request()
        original = base.cashflow_request.positions[0]
        terms = replace(original.terms, fixed_rate=D(".12"), interest_mode=InterestMode.PIK,
            pik_fraction=D(1), payment_lag_business_days=lag)
        position = replace(original, terms=terms)
        cash = replace(base.cashflow_request, positions=(position,))
        return replace(base, cashflow_request=cash, credit_events=events,
            exposures=(replace(base.exposures[0], is_pik=True),),
            notes=(replace(base.notes[0], fixed_rate=D(".04"), pik_rate_fraction=D(1)),),
            clo_terms=replace(base.clo_terms, original_pool_overlay=overlay))

    def assert_service_bridges(self, result):
        self.assertEqual(result.clo.status, ProjectionStatus.COMPLETED)
        self.assertEqual(result.clo.final_collateral_par, 0)
        self.assertEqual(result.clo.final_debt_par, 0)
        self.assertTrue(all(p.cash_conservation_residual == 0 for p in result.clo.periods))
        for snapshot, period in zip(result.portfolio_snapshots, result.clo.periods, strict=True):
            self.assertEqual(snapshot.total_par, period.closing_collateral_par)

    def test_full_pik_asset_and_note_flow_through_unified_baseline(self):
        result = TridentModelService().run(self.request())
        self.assertGreater(result.cashflows.total_pik_interest, 0)
        self.assertEqual(result.cashflows.total_interest, 0)
        self.assertGreater(sum(p.note_pik_capitalized for p in result.clo.periods), 0)
        self.assertEqual(sum(p.collateral_non_cash_par_change for p in result.clo.periods), result.cashflows.total_pik_interest)
        self.assert_service_bridges(result)

    def test_native_api_rejects_false_pik_metadata_and_fills_unknown_from_contract(self):
        request = self.request()
        with self.assertRaisesRegex(InputValidationError, "PIK classification"):
            TridentModelService().run(replace(request, exposures=(replace(request.exposures[0], is_pik=False),)))
        result = TridentModelService().run(replace(request,
            exposures=(replace(request.exposures[0], is_pik=None),)))
        self.assertEqual(result.opening_portfolio.metric("PIK_FRACTION").value, D(1))
        wal = result.opening_portfolio.metric("WAL_YEARS")
        self.assertIsNone(wal.value)
        self.assertIn("PIK funded-principal", wal.message)

    def test_legacy_cdr_cpr_overlay_replays_native_pik_asset_and_note(self):
        overlay = OriginalPoolOverlay(True, annual_default_rate=D(".1"), annual_prepayment_rate=D(".2"),
            recovery_rate=D(".5"), recovery_lag_months=2)
        result = TridentModelService().run(self.request(overlay=overlay))
        capitalized = sum(m.non_cash_par_change for m in result.clo.original_overlay_projection.par_movements)
        self.assertEqual(sum(p.collateral_non_cash_par_change for p in result.clo.periods), capitalized)
        self.assertGreater(result.clo.total_recognized_par_loss, 0)
        self.assert_service_bridges(result)

    def test_native_pik_payment_lag_preserves_cash_dates_and_monitoring(self):
        result = TridentModelService().run(self.request(lag=2))
        self.assertGreater(result.clo.periods[0].closing_collateral_par, D(100))
        self.assertEqual(result.clo.periods[0].received_asset_principal, 0)
        self.assert_service_bridges(result)

    def test_native_pik_payment_lag_and_annual_overlay_keep_actual_cpr_dates(self):
        overlay = OriginalPoolOverlay(True, annual_default_rate=D(".1"), annual_prepayment_rate=D(".2"),
            recovery_rate=D(".5"), recovery_lag_months=2)
        result = TridentModelService().run(self.request(lag=2, overlay=overlay))
        cash_dates = {row.payment_date for row in result.cashflows.cashflows}
        prepayments = [row for row in result.clo.original_overlay_projection.collections
                       if row.source is AssetCashSource.PREPAYMENT]
        self.assertTrue(prepayments)
        self.assertTrue(all(row.payment_date in cash_dates for row in prepayments))
        capitalized = sum(m.non_cash_par_change for m in result.clo.original_overlay_projection.par_movements)
        self.assertEqual(sum(p.collateral_non_cash_par_change for p in result.clo.periods), capitalized)
        self.assert_service_bridges(result)

    def test_explicit_pik_default_reconciles_newface_to_clo_claims(self):
        baseline = self.request()
        identity = baseline.cashflow_request.positions[0].terms.loan_id
        event = DefaultEvent(identity, date(2026, 7, 20),
            (RecoveryEvent(date(2026, 8, 20), D(".8")),), date(2026, 8, 20))
        result = TridentModelService().run(replace(baseline, credit_events=(event,)))
        credit = result.credit_projections[0]
        self.assertGreater(credit.defaulted_exposure, D(100))
        self.assertEqual(sum(p.collateral_non_cash_par_change for p in result.clo.periods), credit.total_pik_interest)
        self.assert_service_bridges(result)


if __name__ == "__main__":
    unittest.main()
