"""Published Microsoft examples plus hand-solvable dated investor returns."""

from datetime import date, datetime, timedelta
from decimal import Decimal, localcontext
import unittest

from trident.analysis import DatedCashflow, ReturnStatus, moic, xirr, xnpv
from trident.domain.models import InputValidationError


D = Decimal
START = date(2025, 1, 1)


def row(amount, days=0):
    return DatedCashflow(START + timedelta(days=days), D(amount))


MICROSOFT_EXAMPLE = (
    DatedCashflow(date(2008, 1, 1), D(-10000)),
    DatedCashflow(date(2008, 3, 1), D(2750)),
    DatedCashflow(date(2008, 10, 30), D(4250)),
    DatedCashflow(date(2009, 2, 15), D(3250)),
    DatedCashflow(date(2009, 4, 1), D(2750)),
)


class InvestorReturnTests(unittest.TestCase):
    def test_microsoft_known_xirr_and_xnpv(self):
        # https://support.microsoft.com/en-us/excel/functions/xirr-function
        # Official example result is 0.373362535; the separate XNPV example
        # publishes 2086.65 at a 9% discount rate.
        result = xirr(MICROSOFT_EXAMPLE)
        self.assertEqual(result.status, ReturnStatus.AVAILABLE)
        # The published value differs from the high-precision zero by ~1.5e-9;
        # allow 1e-8 in rate while checking our actual XNPV residual separately.
        self.assertLess(abs(result.value - D("0.373362535")), D("1e-8"))
        self.assertLess(abs(xnpv(result.value, MICROSOFT_EXAMPLE)), D("0.000001"))
        self.assertEqual(xnpv(D("0.09"), MICROSOFT_EXAMPLE).quantize(D("0.01")), D("2086.65"))

    def test_hand_one_year_and_negative_irr(self):
        for distribution, expected in (("110", "0.1"), ("50", "-0.5"), ("100", "0")):
            result = xirr([row("-100"), row(distribution, 365)])
            self.assertEqual(result.status, ReturnStatus.AVAILABLE)
            self.assertLess(abs(result.value - D(expected)), D("1e-12"))
            self.assertLess(abs(result.residual), D("1e-9"))

    def test_actual_365_denominator_includes_leap_day(self):
        rows = [DatedCashflow(date(2024, 1, 1), D(-100)), DatedCashflow(date(2025, 1, 1), D(110))]
        result = xirr(rows)
        self.assertLess(result.value, D("0.1"))
        self.assertGreater(result.value, D("0.0997"))

    def test_sort_and_exact_same_date_aggregation(self):
        rows = [row("110", 365), row("-60"), row("-40")]
        self.assertLess(abs(xirr(rows).value - D("0.1")), D("1e-12"))
        self.assertEqual(xnpv(D("0.1"), rows), D(0))

    def test_multiple_sign_changes_report_ambiguity(self):
        # -100 + 230/(1+r) - 132/(1+r)^2 has roots at 10% and 20%.
        result = xirr([row("-100"), row("230", 365), row("-132", 730)])
        self.assertEqual(result.status, ReturnStatus.AMBIGUOUS)
        self.assertIsNone(result.value)
        self.assertLess(abs(xnpv(D("0.1"), [row("-100"), row("230", 365), row("-132", 730)])), D("1e-35"))
        self.assertLess(abs(xnpv(D("0.2"), [row("-100"), row("230", 365), row("-132", 730)])), D("1e-35"))

    def test_one_sign_zero_empty_and_same_day_net_zero_unavailable(self):
        for rows in ([], [row("100")], [row("-100"), row("0", 365)], [row("0")], [row("-100"), row("100")]):
            self.assertEqual(xirr(rows).status, ReturnStatus.UNAVAILABLE)

    def test_moic_includes_additional_contributions_and_same_date_gross(self):
        rows = [row("-100"), row("-50", 365), row("25", 365), row("200", 730)]
        self.assertEqual(moic(rows).value, D("1.5"))
        self.assertEqual(moic([row("-100"), row("100")]).value, D(1))
        self.assertEqual(moic([row("-100")]).value, D(0))
        self.assertEqual(moic([row("100")]).status, ReturnStatus.UNAVAILABLE)

    def test_zero_anchor_can_set_xnpv_date_without_irr_numerical_noise(self):
        rows = [row("0", -36500), row("-100"), row("50", 365)]
        self.assertLess(abs(xirr(rows).value + D("0.5")), D("1e-12"))
        self.assertGreater(xnpv(D("0.1"), rows), D(-1))

    def test_extreme_but_representable_one_day_root(self):
        result = xirr([row("-100"), row("110", 1)])
        self.assertEqual(result.status, ReturnStatus.AVAILABLE)
        self.assertGreater(result.value, D("1e14"))
        self.assertLess(abs(result.residual), D("1e-8"))

    def test_low_caller_decimal_precision_independent(self):
        with localcontext() as context:
            context.prec = 2
            result = xirr([row("-100"), row("110", 365)])
            present = xnpv(D("0.1"), [row("-100"), row("110", 365)])
            multiple = moic([row("-100"), row("125", 365)])
        self.assertLess(abs(result.value - D("0.1")), D("1e-12"))
        self.assertEqual(present, D(0))
        self.assertEqual(multiple.value, D("1.25"))

    def test_domain_validation(self):
        for value in (D(-1), D(-2), D("NaN"), 0.1):
            with self.assertRaises(InputValidationError):
                xnpv(value, [row("-100"), row("110", 365)])
        with self.assertRaises(InputValidationError):
            xnpv(D(0), [])
        for amount in (D("Infinity"), 100.0, True):
            with self.assertRaises(InputValidationError):
                DatedCashflow(START, amount)
        with self.assertRaises(InputValidationError):
            DatedCashflow(datetime(2025, 1, 1), D(100))
        with self.assertRaises(InputValidationError):
            xirr([("2025-01-01", D(-100))])


if __name__ == "__main__":
    unittest.main()
