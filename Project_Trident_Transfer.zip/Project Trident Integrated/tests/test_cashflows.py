"""Known-answer financial tests independent of the loan implementation."""

import unittest
from dataclasses import replace
from datetime import date, datetime
from decimal import Decimal, Inexact, ROUND_DOWN, localcontext
from fractions import Fraction

from trident.cashflows.engine import ContractualCashflowEngine
from trident.conventions.calendar import BusinessDayConvention
from trident.conventions.schedule import AccrualDateBasis
from trident.domain.models import AmortizationType, CouponType, LoanPosition, LoanTerms
from trident.domain.numeric import post_currency
from trident.market.rates import FlatRateProvider

D = Decimal


def fixed_terms(**changes: object) -> LoanTerms:
    defaults = dict(
        loan_id="FIXED_1", currency="EUR", start_date=date(2026, 1, 1),
        maturity_date=date(2026, 4, 1), reference_principal=D("10000000"),
        coupon_type=CouponType.FIXED, fixed_rate=D("0.055"),
        business_day_convention=BusinessDayConvention.UNADJUSTED,
        accrual_date_basis=AccrualDateBasis.UNADJUSTED,
    )
    defaults.update(changes)
    return LoanTerms(**defaults)


class CashflowKnownAnswerTests(unittest.TestCase):
    def setUp(self) -> None:
        self.engine = ContractualCashflowEngine(FlatRateProvider({"EURIBOR_3M": D("0.025")}))

    def test_fixed_90_day_coupon_and_bullet(self) -> None:
        terms = fixed_terms()
        row, = self.engine.generate(LoanPosition(terms, terms.start_date, D("10000000")))
        self.assertEqual(row.cash_interest, D("137500.00"))
        self.assertEqual(row.principal_repayment, D("10000000"))
        self.assertEqual(row.total_cash, D("10137500"))
        self.assertEqual(row.closing_balance, 0)
        self.assertIsNone(row.fixing_date)

    def test_exact_half_cent_not_lost_by_repeating_dcf(self) -> None:
        terms = fixed_terms(reference_principal=D("10"), fixed_rate=D("0.0015"),
                            maturity_date=date(2026, 5, 1), frequency_months=6)
        row, = self.engine.generate(LoanPosition(terms, terms.start_date, D("10")))
        # 120 days / 360 = 1/3; 10 * 0.0015 * 1/3 = EXACTLY 0.005.
        self.assertEqual(row.interest_unrounded, D("0.005"))
        self.assertEqual(row.cash_interest, D("0.01"))

    def test_negative_exact_half_cent(self) -> None:
        terms = fixed_terms(reference_principal=D("10"), fixed_rate=D("-0.0015"),
                            maturity_date=date(2026, 5, 1), frequency_months=6)
        row, = self.engine.generate(LoanPosition(terms, terms.start_date, D("10")))
        self.assertEqual(row.cash_interest, D("-0.01"))
        self.assertEqual(row.total_cash, D("9.99"))

    def test_posting_around_signed_ties(self) -> None:
        expected = {"0.004999": "0", "0.005": "0.01", "0.005001": "0.01",
                    "-0.004999": "0", "-0.005": "-0.01", "-0.005001": "-0.01"}
        for amount, result in expected.items():
            with self.subTest(amount=amount):
                self.assertEqual(post_currency(Fraction(D(amount))), D(result))

    def test_index_floor_applies_before_spread(self) -> None:
        terms = fixed_terms(coupon_type=CouponType.FLOATING, fixed_rate=None,
                            rate_index="EURIBOR_3M", spread_bps=D(300), index_floor=D("0.01"))
        engine = ContractualCashflowEngine(FlatRateProvider({"EURIBOR_3M": D("-0.005")}))
        row, = engine.generate(LoanPosition(terms, terms.start_date, D("10000000")))
        self.assertEqual(row.all_in_rate, D("0.04"))
        self.assertEqual(row.cash_interest, D("100000"))

    def test_linear_amortization_and_maturity_conservation(self) -> None:
        terms = fixed_terms(
            reference_principal=D("7000000"), start_date=date(2026, 11, 20),
            maturity_date=date(2036, 11, 20), fixed_rate=D("0.055"),
            business_day_convention=BusinessDayConvention.MODIFIED_FOLLOWING,
            accrual_date_basis=AccrualDateBasis.ADJUSTED,
            amortization_type=AmortizationType.LINEAR_INITIAL_PAR, amortization_fraction=D("0.025"),
        )
        rows = self.engine.generate(LoanPosition(terms, terms.start_date, D("7000000")))
        self.assertEqual(len(rows), 40)
        self.assertEqual(rows[0].cash_interest, D("100527.78"))
        self.assertEqual(rows[0].principal_repayment, D("175000"))
        self.assertEqual(rows[-1].opening_balance, D("175000"))
        self.assertEqual(rows[-1].closing_balance, 0)
        self.assertEqual(sum(row.principal_repayment for row in rows), D("7000000"))
        for previous, current in zip(rows, rows[1:]):
            self.assertEqual(previous.closing_balance, current.opening_balance)

    def test_remaining_balloon_settles_at_maturity(self) -> None:
        terms = fixed_terms(reference_principal=D("100"), maturity_date=date(2027, 1, 1),
                            amortization_type=AmortizationType.LINEAR_INITIAL_PAR,
                            amortization_fraction=D("0.1"))
        rows = self.engine.generate(LoanPosition(terms, terms.start_date, D("100")))
        self.assertEqual([r.principal_repayment for r in rows], [D(10), D(10), D(10), D(70)])

    def test_stops_after_full_early_amortization(self) -> None:
        terms = fixed_terms(reference_principal=D("100"), maturity_date=date(2027, 1, 1),
                            amortization_type=AmortizationType.LINEAR_INITIAL_PAR,
                            amortization_fraction=D("0.5"))
        rows = self.engine.generate(LoanPosition(terms, terms.start_date, D("100")))
        self.assertEqual(len(rows), 2)
        self.assertEqual(rows[-1].closing_balance, 0)

    def test_caller_decimal_context_cannot_change_result(self) -> None:
        with localcontext() as caller:
            caller.prec = 2
            caller.rounding = ROUND_DOWN
            caller.traps[Inexact] = True
            terms = fixed_terms()
            row, = self.engine.generate(LoanPosition(terms, terms.start_date, D("10000000")))
            self.assertEqual(row.cash_interest, D("137500"))

    def test_illegal_or_ambiguous_terms(self) -> None:
        changes = [dict(reference_principal=100.0), dict(reference_principal=D("NaN")),
                   dict(reference_principal=D("0.001")), dict(frequency_months=True),
                   dict(start_date=datetime(2026, 1, 1)), dict(index_floor=D(0)),
                   dict(amortization_fraction=D("0.2")), dict(loan_id=" ")]
        for change in changes:
            with self.subTest(change=change), self.assertRaises(ValueError):
                fixed_terms(**change)

    def test_reset_frequency_mismatch_is_unsupported(self) -> None:
        with self.assertRaises(ValueError):
            fixed_terms(coupon_type=CouponType.FLOATING, fixed_rate=None,
                        rate_index="EURIBOR_1M", frequency_months=3)

    def test_mid_period_opening_balance_is_not_reconstructed(self) -> None:
        terms = fixed_terms()
        with self.assertRaises(ValueError):
            LoanPosition(terms, date(2026, 2, 1), D("10000000"))

    def test_linear_principal_cash_lag_changes_settlement_not_accrual_balance(self) -> None:
        terms = fixed_terms(maturity_date=date(2026, 7, 1),
            amortization_type=AmortizationType.LINEAR_INITIAL_PAR,
            amortization_fraction=D("0.1"), payment_lag_business_days=2)
        rows = self.engine.generate(LoanPosition(terms, terms.start_date, D("10000000")))
        self.assertEqual(rows[0].accrual_end, date(2026, 4, 1))
        self.assertEqual(rows[0].payment_date, date(2026, 4, 7))  # TARGET Easter.
        self.assertEqual(rows[1].opening_balance, D("9000000"))
        self.assertEqual(sum(r.principal_repayment for r in rows), D("10000000"))


if __name__ == "__main__":
    unittest.main()
