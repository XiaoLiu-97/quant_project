"""Independent output-capacity checks: no fabricated rows or lost claims."""
from types import SimpleNamespace
import unittest
from unittest.mock import patch
import xml.etree.ElementTree as ET
from datetime import date

import test_interface_package as fixtures
from trident.adapters.interface_output_capacity import CapacityWorkbookPackage, OutputCapacityPolicy
from trident.adapters.interface_package import FormulaCell, TABLE_PREFIX, _tag
from trident.domain.models import InputValidationError


class OutputCapacityTests(unittest.TestCase):
    def setUp(self):
        fixtures.InterfacePackageTests.setUp(self)
        baseline = SimpleNamespace(cashflows=SimpleNamespace(cashflows=(SimpleNamespace(loan_id='I'),)))
        self.run = SimpleNamespace(baseline=baseline, library_projection=None,
            cases=(SimpleNamespace(result=SimpleNamespace(clo=SimpleNamespace(periods=(1,2)))),),
            inputs=SimpleNamespace(capital=('A','SUB')))

    def package(self, **kwargs):
        return CapacityWorkbookPackage(self.source, run=self.run,
            protected_names=('trident_ui_cash_input',), protected_tables=('tbl_trident_ui_pool',), **kwargs)

    def records(self, count):
        return tuple({'Metric':'M'+str(i),'Value':i,'Date':date(2026,11,20)} for i in range(count))

    def test_reserve_is_native_but_unused_rows_have_no_formulas_or_values(self):
        p=self.package();old=p.table_inventory()['tbl_trident_ui_output']
        info=p.write_table(old.name,self.records(2))
        self.assertEqual(info.bounds[3]-info.bounds[1],300)
        self.assertEqual((info.identifier,info.part),(old.identifier,old.part))
        cells=p._sheet_cells(p._xml(p._sheet_parts()['Output']))
        self.assertNotIn('A301',cells)
        self.assertEqual(p._row_counts[old.name],2)
        self.assertEqual(p.named_region('trident_ui_output')[1],(1,1,3,301))
        self.assertEqual(p.parts[p._sheet_parts()['Market Data']],p._original[p._sheet_parts()['Market Data']])
        self.assertEqual(p.parts[p._sheet_parts()['Inputs']],p._original[p._sheet_parts()['Inputs']])

    def test_shrink_clears_old_results_and_formula_cache_keeps_capacity(self):
        p=self.package();name='tbl_trident_ui_output'
        rows=({'Metric':'F','Value':FormulaCell('1+1',2),'Date':date(2026,11,20)},
              {'Metric':'Zero','Value':0,'Date':date(2027,2,22)})
        p.write_table(name,rows,number_formats={'Date':'dd-mmm-yyyy'})
        p.write_table(name,rows[:1])
        self.assertEqual(p.table_inventory()[name].bounds[3],301)
        cell=p._sheet_cells(p._xml(p._sheet_parts()['Output']))['B3']
        self.assertIsNone(cell.find(_tag('f')));self.assertIsNone(cell.find(_tag('v')))
        self.assertEqual(p._row_counts[name],1)

    def test_repeat_keeps_unchanged_formula_cells_and_table_shape(self):
        p=self.package();name='tbl_trident_ui_output'
        rows=({'Metric':'F','Value':FormulaCell('1+1',2),'Date':date(2026,11,20)},)
        p.write_table(name,rows)
        cells=p._sheet_cells(p._xml(p._sheet_parts()['Output']))
        old=cells['B2'];shape=p.table_inventory()[name].ref
        p.write_table(name,rows)
        self.assertIs(cells['B2'],old)
        self.assertEqual(p.table_inventory()[name].ref,shape)

    def test_layout_boundary_preserves_neighbour_and_actual_record_guard(self):
        p=self.package()
        p.add_table('tbl_trident_ui_neighbour',('A','B','C'),({'A':'NEIGHBOUR','B':123,'C':None},),sheet='Output',start_cell='A10')
        info=p.write_table('tbl_trident_ui_output',self.records(2))
        self.assertEqual(info.bounds[3],9)
        self.assertEqual(p._capacity_modes[info.name],'LAYOUT_BOUND_OUTPUT')
        with self.assertRaises(InputValidationError):p.write_table(info.name,self.records(10))

    def test_unowned_hidden_note_bounds_reserve(self):
        from trident.adapters.interface_package import WorkbookPackage
        p=WorkbookPackage(self.source)
        p.write_cells('Output',{'A8':'KEEP THIS NOTE'})
        p.save(self.source,overwrite=True)
        p=self.package();info=p.write_table('tbl_trident_ui_output',self.records(2))
        self.assertEqual(info.bounds[3],7)
        self.assertEqual(p._cached_value(p._sheet_cells(p._xml(p._sheet_parts()['Output']))['A8']),'KEEP THIS NOTE')

    def test_catalogue_exact_length_never_includes_reserved_blank_choices(self):
        p=self.package()
        info=p.add_table(TABLE_PREFIX+'options_case',('Case',),({'Case':'BASELINE'},{'Case':'DOWN'}))
        self.assertEqual(info.bounds[3]-info.bounds[1],2)

    def test_monthly_cashflow_reserve_uses_asset_times_period_not300rows(self):
        self.run.baseline.cashflows.cashflows=tuple(SimpleNamespace(loan_id='M') for _ in range(120))
        p=self.package()
        info=p.add_table(TABLE_PREFIX+'asset_cashflows',('Asset ID','Period','Payment date'),({'Asset ID':'M','Period':1,'Payment date':date(2026,11,20)},))
        self.assertEqual(info.bounds[3]-info.bounds[1],36000)
        self.assertEqual(p._row_counts[info.name],1)
        self.assertLess(len(p._sheet_cells(p._xml(p._sheet_parts()[info.sheet]))),50)

    def test_actual_records_above_reserve_not_truncated(self):
        p=self.package();info=p.write_table('tbl_trident_ui_output',self.records(350))
        self.assertEqual(info.bounds[3]-info.bounds[1],350)
        self.assertEqual(p._row_counts[info.name],350)

    def test_capacity_registry_covers_every_table_and_itself(self):
        p=self.package();p.write_table('tbl_trident_ui_output',self.records(1));p.refresh_capacity_registry()
        records=[r for r in p._table_records(p.REGISTRY) if r['Table']]
        self.assertEqual({r['Table'] for r in records},set(p.table_inventory()))
        output=next(r for r in records if r['Table']=='tbl_trident_ui_output')
        self.assertEqual((output['Capacity rows'],output['Populated rows']),(300,1))
        registry=next(r for r in records if r['Table']==p.REGISTRY)
        self.assertEqual(registry['Capacity rows'],p.table_inventory()[p.REGISTRY].bounds[3]-p.table_inventory()[p.REGISTRY].bounds[1])
        self.assertEqual(registry['Populated rows'],len(p.table_inventory()))

    def test_empty_merge_bounds_reserve_and_rejects_actual_growth(self):
        from trident.adapters.interface_package import WorkbookPackage
        p=WorkbookPackage(self.source)
        tree=p._xml(p._sheet_parts()['Output'])
        merges=ET.SubElement(tree,_tag('mergeCells'),count='1')
        ET.SubElement(merges,_tag('mergeCell'),ref='B8:C9')
        p._put_xml(p._sheet_parts()['Output'],tree)
        p.save(self.source,overwrite=True)
        p=self.package();info=p.write_table('tbl_trident_ui_output',self.records(2))
        self.assertEqual(info.bounds[3],7)
        with self.assertRaises(InputValidationError):p.write_table(info.name,self.records(8))


    def test_capacity_repeat_avoids_sheet_note_scan_and_metadata_resize(self):
        # Native capacity persists in the saved file, rather than in a Python
        # object. A fresh run may change results but should retain its template.
        p = self.package()
        name = 'tbl_trident_ui_output'
        p.write_table(name, self.records(2), number_formats={'Date': 'dd-mmm-yyyy'})
        p.save(self.source, overwrite=True)
        fresh = self.package()
        info = fresh.table_inventory()[name]
        old_table_xml = ET.tostring(fresh._xml(info.part))
        old_alias = fresh.named_region('trident_ui_output')
        with patch.object(fresh, '_unowned_content_index', side_effect=AssertionError('Unnecessary full sheet scan')):
            fresh.write_table(name, ({'Metric': 'CHANGED', 'Value': 42, 'Date': date(2027, 2, 22)},),
                              number_formats={'Date': 'dd-mmm-yyyy'})
        self.assertEqual(ET.tostring(fresh._xml(info.part)), old_table_xml)
        self.assertEqual(fresh.named_region('trident_ui_output'), old_alias)
        self.assertEqual(fresh._cached_value(fresh._sheet_cells(fresh._xml(fresh._sheet_parts()['Output']))['B2']), 42)
        self.assertIsNone(fresh._sheet_cells(fresh._xml(fresh._sheet_parts()['Output']))['B3'].find(_tag('v')))

    def test_real_growth_still_checks_hidden_note_after_existing_capacity(self):
        from trident.adapters.interface_package import WorkbookPackage
        p = self.package(policy=OutputCapacityPolicy(detail_rows=5))
        name = 'tbl_trident_ui_output'
        p.write_table(name, self.records(2))
        p.save(self.source, overwrite=True)
        base = WorkbookPackage(self.source)
        base.write_cells('Output', {'B8': 'KEEP HIDDEN NOTE'})
        base.save(self.source, overwrite=True)
        grown = self.package(policy=OutputCapacityPolicy(detail_rows=300))
        info = grown.write_table(name, self.records(3))
        self.assertEqual(info.bounds[3], 7)
        self.assertEqual(grown._capacity_modes[name], 'LAYOUT_BOUND_OUTPUT')
        with self.assertRaises(InputValidationError):
            grown.write_table(name, self.records(8))
        self.assertEqual(grown._cached_value(grown._sheet_cells(grown._xml(grown._sheet_parts()['Output']))['B8']),
                         'KEEP HIDDEN NOTE')

    def test_capacity_policy_rejects_noninteger_or_nonpositive_rows(self):
        for value in (True,0,-1,1.5):
            with self.assertRaises(InputValidationError):OutputCapacityPolicy(asset_rows=value)
