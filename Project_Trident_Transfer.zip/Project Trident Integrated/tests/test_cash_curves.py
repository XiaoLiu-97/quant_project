"""Independent no-arbitrage arithmetic for projected collection account returns."""
from datetime import date
from decimal import Decimal, Context, Inexact, localcontext
from fractions import Fraction
import unittest

from trident.conventions.day_count import DayCount
from trident.domain.models import InputValidationError
from trident.domain.numeric import post_currency
from trident.market.cash_accounts import CashCurveRateProvider, DiscountFactorCashCurve, ZeroCompounding, ZeroRatePoint
from trident.market.rates import CurveRangeError, ExtrapolationPolicy, FlatRateProvider, MissingCurveError

D = Decimal


def curve(**kwargs):
    defaults = dict(index="ESTR", valuation_date=date(2026, 1, 1),
                    points=(ZeroRatePoint(D(1), D(".1")), ZeroRatePoint(D(2), D(".2"))),
                    compounding=ZeroCompounding.SIMPLE, day_count=DayCount.ACT_365F)
    defaults.update(kwargs)
    return DiscountFactorCashCurve(**defaults)


class CashCurveTests(unittest.TestCase):
    def test_receipt_forward_uses_discount_ratio_not_zero(self):
        # DF1=1/1.1 and DF2=1/1.4 => forward factor 1.4/1.1 - 1 = 3/11.
        factor = curve().accumulation_factor(date(2027, 1, 1), date(2028, 1, 1), DayCount.ACT_365F)
        self.assertLess(abs(factor - Fraction(3, 11)), Fraction(1, 10**45))
        self.assertEqual(post_currency(100 * factor), D("27.27"))

    def test_zero_spread_floor_and_spread_use_account_basis(self):
        flat = curve(points=(ZeroRatePoint(D(2), D(0)),))
        factor = flat.accumulation_factor(date(2027, 1, 1), date(2028, 1, 1), DayCount.ACT_360, D(100), D(".02"))
        self.assertEqual(factor, Fraction(365, 360) * Fraction(2, 100))
        self.assertEqual(post_currency(100 * factor), D("2.03"))

    def test_log_df_interpolation_has_known_square_root(self):
        c = curve(valuation_date=date(2025, 1, 1), day_count=DayCount.ACT_360,
                  points=(ZeroRatePoint(D(1), D(".21")),))
        # At 180/360 years, DF=sqrt(1/1.21)=1/1.1.
        factor = c.accumulation_factor(date(2025, 1, 1), date(2025, 6, 30), DayCount.ACT_360)
        self.assertLess(abs(factor - Fraction(1, 10)), Fraction(1, 10**45))

    def test_continuous_and_annual_conventions_are_explicit(self):
        annual = curve(points=(ZeroRatePoint(D(2), D(".1")),), compounding=ZeroCompounding.ANNUAL_EFFECTIVE)
        continuous = curve(points=(ZeroRatePoint(D(2), D(".1")),), compounding=ZeroCompounding.CONTINUOUS)
        self.assertLess(abs(Fraction(annual.discount_factor(date(2027, 1, 1))) - Fraction(10, 11)), Fraction(1, 10**45))
        self.assertNotEqual(annual.discount_factor(date(2027, 1, 1)), continuous.discount_factor(date(2027, 1, 1)))

    def test_negative_zero_positive_df_and_all_in_floor(self):
        negative = curve(points=(ZeroRatePoint(D(1), D("-.01")),))
        self.assertGreater(negative.discount_factor(date(2027, 1, 1)), 1)
        self.assertEqual(negative.accumulation_factor(date(2026, 1, 1), date(2027, 1, 1), DayCount.ACT_365F, floor=D(0)), 0)

    def test_historical_and_outside_range_reject(self):
        for start, end in ((date(2025, 1, 1), date(2026, 1, 1)), (date(2027, 1, 1), date(2029, 1, 1))):
            with self.assertRaises(CurveRangeError):
                curve().accumulation_factor(start, end, DayCount.ACT_365F)
        self.assertGreater(curve(extrapolation=ExtrapolationPolicy.FLAT).discount_factor(date(2029, 1, 1)), 0)

    def test_zero_interval_needs_no_future_node(self):
        self.assertEqual(curve().accumulation_factor(date(2035, 1, 1), date(2035, 1, 1), DayCount.ACT_360), 0)

    def test_invalid_nodes_conventions_and_positive_df(self):
        for kwargs in (dict(compounding="SIMPLE"), dict(day_count=DayCount.THIRTY_360_ISDA),
                       dict(points=(ZeroRatePoint(D(1), D("-2")),)),
                       dict(points=(ZeroRatePoint(D(2), D(0)), ZeroRatePoint(D(1), D(0)))),
                       dict(points=(ZeroRatePoint(D(0), D(0)),)), dict(index="EURIBOR_3M")):
            with self.subTest(kwargs=kwargs), self.assertRaises(InputValidationError):
                curve(**kwargs)

    def test_composite_term_and_cash_routes_preserve_separation(self):
        provider = CashCurveRateProvider(FlatRateProvider({"EURIBOR_3M": D(".03")}), {"ESTR": curve()})
        self.assertEqual(provider.rate("EURIBOR_3M", date(2027, 1, 1)), D(".03"))
        with self.assertRaises(MissingCurveError):
            provider.accumulation_factor("SOFR", date(2026, 1, 1), date(2027, 1, 1), DayCount.ACT_365F)
        with self.assertRaises(TypeError):
            provider.cash_curves["SOFR"] = curve(index="SOFR")

    def test_caller_decimal_context_does_not_change_cash_posting(self):
        c = curve()
        expected = post_currency(100 * c.accumulation_factor(date(2027, 1, 1), date(2028, 1, 1), DayCount.ACT_365F))
        with localcontext(Context(prec=2)) as ctx:
            ctx.traps[Inexact] = True
            actual = post_currency(100 * c.accumulation_factor(date(2027, 1, 1), date(2028, 1, 1), DayCount.ACT_365F))
        self.assertEqual(actual, expected)
