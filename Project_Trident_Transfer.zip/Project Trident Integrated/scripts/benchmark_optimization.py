"""Reproducible synthetic LP/MILP and full CLO candidate-search timings.

No Bloomberg access, workbook edits or orders occur. The full-search benchmark
uses the production funding, cashflow, waterfall, quality and XIRR services.
The baseline-only runner uses initial-portfolio-only reuse for an honest
before/after comparison; it does not replace any financial calculation.
Timings depend on the machine and scenario. They are evidence, not an SLA.

Run with PYTHONPATH=src and the project's Python environment. Use --output to
save a JSON record; the default runs 150 holdings, EUR 500m, 40 payment periods
and six debt classes. Full variants intentionally converge to the same pool to
measure repeated-projection removal; --distinct-targets changes the gross
turnover cap for each variant so target pools genuinely differ.
"""

import argparse
from dataclasses import replace
from datetime import date, datetime, timedelta, timezone
from decimal import Decimal
import json
from pathlib import Path
import platform
from statistics import median
from time import perf_counter

from trident.analysis import AssetExposure, FactorMapping
from trident.application.candidate_search import (
    CandidateSearchVariant, ClosingPoolSearchRequest, ClosingPoolSearchService,
)
from trident.application.clo_services import TridentModelRequest, TridentModelService
from trident.application.construction import selected_factor_provenance
from trident.application.services import CashflowRunRequest
from trident.clo.models import CloTerms, NoteTranche
from trident.domain.models import CouponType, LoanPosition, LoanTerms
from trident.funding.engine import AssetPurchase, DebtIssue
from trident.market import FlatRateProvider
from trident.optimization import (
    AssetDescriptor, AssetKind, Holding, OptimizationObjective, OptimizationRequest,
    PortfolioLimits, StaticTradeOptimizer, TradeQuote, TradeSide,
)
from trident.optimization.universe import (
    CandidateAdmissionPolicy, CandidateAssetSnapshot, CandidateCreditStatus,
    CandidateUniverseSnapshot, PriceObservation, PriceSide, QuoteQuality,
    RatingLevel, RatingNature, RatingObservation,
)

D = Decimal
CLOSE = date(2026, 1, 20)
MATURITY = date(2036, 1, 20)
CAPTURE = datetime(2026, 1, 19, 16, 0, tzinfo=timezone.utc)
MAPPING = FactorMapping("TRIDENT_TEST_FACTOR", "1",
                       {"INFRA": D(1000), "OLD": D(4000), "NEW": D(2000)}, is_synthetic=True)


def _position(identifier, par, spread):
    return LoanPosition(LoanTerms(identifier, "EUR", CLOSE, MATURITY, par,
        CouponType.FLOATING, rate_index="EURIBOR_3M", spread_bps=spread), CLOSE, par)


def _exposure(position, kind, bucket, index):
    return AssetExposure(position.terms.loan_id, f"ISSUER_{position.terms.loan_id}", kind.value,
        "TERM_LOAN", ("GB", "DE", "FR", "IT", "NL")[index % 5], f"SECTOR_{index % 10}",
        "EUR", position.opening_balance, position.terms.spread_bps, MATURITY,
        is_senior=True, is_secured=True, is_pik=False, is_revolver=False, is_construction=False,
        test_factor_bucket=bucket)


def _descriptor(exposure, factor):
    return AssetDescriptor(exposure.loan_id, AssetKind(exposure.asset_class), exposure.obligor,
        exposure.country, exposure.sector, exposure.spread_bps, factor)


def _candidate(position, exposure, descriptor, quote):
    identity = f"TRANCHE_{descriptor.asset_id}"
    return CandidateAssetSnapshot(descriptor, identity, f"SYNTHETIC_BBG_{descriptor.asset_id}",
        position, exposure, (RatingObservation("SYNTHETIC_TEST_AGENCY", "TEST", RatingLevel.FACILITY,
            RatingNature.INTERNAL, identity, CAPTURE.date(), "SYNTHETIC_BENCHMARK"),),
        (PriceObservation(quote, PriceSide.ASK if quote.side is TradeSide.BUY else PriceSide.BID,
            QuoteQuality.FIRM, CAPTURE, CLOSE, "SYNTHETIC_BENCHMARK"),),
        "SYNTHETIC_VERIFIED_CONTRACT", "SYNTHETIC_CLASSIFICATION", CandidateCreditStatus.PERFORMING)


def benchmark_request(*, integer=False, variants=8, distinct_targets=False):
    """Build a frozen EUR 500m hybrid pool and 100 side-specific BSL quotes."""
    provenance = selected_factor_provenance(MAPPING)
    positions, exposures, holdings, quotes, candidates = [], [], [], [], []
    for index in range(150):
        infra = index < 100
        kind, bucket, par, spread = ((AssetKind.INFRA, "INFRA", D(3_500_000), D(300))
                                    if infra else (AssetKind.BSL, "OLD", D(3_000_000), D(500)))
        position = _position(f"HELD_{index:03d}", par, spread)
        exposure = _exposure(position, kind, bucket, index)
        descriptor = _descriptor(exposure, MAPPING.factors[bucket])
        positions.append(position)
        exposures.append(exposure)
        holdings.append(Holding(descriptor, par))
        if infra:
            continue
        for side in (TradeSide.SELL, TradeSide.BUY):
            new = side is TradeSide.BUY
            source = _position(f"NEW_{index:03d}", par, D(600)) if new else position
            quality = _exposure(source, AssetKind.BSL, "NEW", index) if new else exposure
            asset = _descriptor(quality, D(2000)) if new else descriptor
            quote = TradeQuote(asset, side, D(100), par,
                lot_size=D(250_000) if integer else None,
                minimum_ticket=D(500_000) if integer else D(0),
                fixed_fee=D(100) if integer else D(0))
            quotes.append(quote)
            candidates.append(_candidate(source, quality, asset, quote))
    note_pars = (D(320_000_000), D(50_000_000), D(35_000_000), D(25_000_000), D(15_000_000), D(5_000_000))
    notes = tuple(NoteTranche(chr(65 + index), index + 1, par, CouponType.FLOATING,
        spread_bps=D(100 + 75 * index), rate_index="EURIBOR_3M",
        oc_minimum=D("1.02"), ic_minimum=D("1.01"), interest_deferrable=index > 1)
        for index, par in enumerate(note_pars))
    baseline = TridentModelRequest(CashflowRunRequest(tuple(positions),
        tuple(AssetPurchase(row.terms.loan_id, row.opening_balance, D(100)) for row in positions),
        tuple(DebtIssue(note.class_id, note.opening_balance, D(100)) for note in notes),
        FlatRateProvider({"EURIBOR_3M": D(".025")}), D(1_000_000), D(0), "SYNTHETIC_BENCHMARK"),
        tuple(exposures), MAPPING, (), CloTerms(CLOSE, MATURITY), notes)
    mandate = OptimizationRequest(tuple(holdings), tuple(quotes), D(10_000_000),
        PortfolioLimits(D(500_000_000), maximum_obligor_share=D(".01"), maximum_country_share=D(".30"),
            maximum_sector_share=D(".20"), maximum_bsl_share=D(".30"), minimum_infra_share=D(".70"),
            maximum_overall_factor=D(2000), maximum_bsl_factor=D(4000), minimum_spread_bps=D(350),
            maximum_trade_par=D(300_000_000)), OptimizationObjective.MIN_FACTOR, provenance, CLOSE,
        solver_time_limit=30.0)
    variant_rows = tuple(CandidateSearchVariant(f"VARIANT_{index:02d}",
        OptimizationObjective.MIN_FACTOR if index % 2 == 0 else OptimizationObjective.MAX_SPREAD,
        maximum_trade_par=D(300_000_000 * (index + 1) // variants) if distinct_targets else None)
        for index in range(variants))
    return ClosingPoolSearchRequest(baseline, mandate,
        CandidateUniverseSnapshot("BENCHMARK", CAPTURE, "SYNTHETIC_FROZEN_VALUES", provenance, tuple(candidates)),
        CandidateAdmissionPolicy(CLOSE, timedelta(0), (QuoteQuality.FIRM,)), variant_rows)


class _MeasuredRunner:
    """Time actual production projections without changing their financial work."""

    def __init__(self):
        self.calls, self.seconds = 0, 0.0
        self.service = TridentModelService()

    def run(self, request):
        started = perf_counter()
        result = self.service.run(request)
        self.calls += 1
        self.seconds += perf_counter() - started
        return result


class _MeasuredOptimizer:
    def __init__(self):
        self.seconds, self.calls = 0.0, 0
        self.service = StaticTradeOptimizer()

    def solve(self, request):
        started = perf_counter()
        result = self.service.solve(request)
        self.seconds += perf_counter() - started
        self.calls += 1
        return result


class _BaselineOnlyCache:
    """The prior baseline-only cache policy, for the benchmark comparison."""

    def __init__(self, service):
        self.service, self.baseline, self.result = service, None, None

    def run(self, request):
        if self.baseline is None:
            self.baseline = request
        if request == self.baseline:
            if self.result is None:
                self.result = self.service.run(request)
            return self.result
        return self.service.run(request)


def _search_measurement(request, *, previous_policy=False):
    # Only the projection-cache strategy changes. Both paths still execute the
    # same production search, static verification, ranking and financial model.
    from unittest.mock import patch
    runner, optimizer = _MeasuredRunner(), _MeasuredOptimizer()
    started = perf_counter()
    if previous_policy:
        with patch("trident.application.candidate_search.ModelProjectionCache", _BaselineOnlyCache):
            result = ClosingPoolSearchService(optimizer=optimizer, service=runner).run(request)
    else:
        result = ClosingPoolSearchService(optimizer=optimizer, service=runner).run(request)
    elapsed = perf_counter() - started
    fingerprint = [(row.candidate_id, row.status, row.eligible, str(row.equity_irr.value),
        str(row.equity_cash_funding), str(row.equity_distributions), str(row.exact_factor), row.rank, row.pareto)
        for row in result.evaluations]
    baseline = result.evaluation("NO_TRADES").replay.baseline_result
    return {"total_seconds": elapsed, "production_projection_calls": runner.calls,
        "production_projection_seconds": runner.seconds, "solver_calls": optimizer.calls,
        "solver_and_exact_verification_seconds": optimizer.seconds,
        "selected_candidate_id": result.selected_candidate_id, "status": result.status.value,
        "periods": len(baseline.clo.periods), "class_periods": len(baseline.clo.tranche_periods),
        "contractual_cashflow_rows": len(baseline.cashflows.cashflows), "economic_fingerprint": fingerprint}


def _static_measurement(request, repeats):
    timings, statuses = [], []
    result = None
    for _ in range(repeats):
        started = perf_counter()
        result = StaticTradeOptimizer().solve(request)
        timings.append(perf_counter() - started)
        statuses.append(result.status.value)
    return {"holdings": len(request.holdings), "quotes": len(request.quotes),
        "repeats": repeats, "seconds": timings, "median_seconds": median(timings),
        "statuses": statuses, "validated": result.validated, "method": result.solver_method,
        "ending_par": str(result.ending_par), "ending_cash": str(result.ending_cash),
        "violations": result.violations, "trades": len(result.trades)}


def _expanded_static(request, quotes):
    """Add distinct new candidates without bypassing real model construction."""
    buy = next(row for row in request.quotes if row.side is TradeSide.BUY)
    extras = tuple(replace(buy, asset=replace(buy.asset, asset_id=f"EXTRA_{index:05d}",
        obligor=f"EXTRA_ISSUER_{index:05d}")) for index in range(quotes - len(request.quotes)))
    return replace(request, quotes=(*request.quotes, *extras))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path)
    parser.add_argument("--variants", type=int, default=8)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--distinct-targets", action="store_true")
    parser.add_argument("--static-only", action="store_true")
    args = parser.parse_args()
    if not 1 <= args.variants <= 100 or args.repeats < 1:
        parser.error("variants must be 1..100 and repeats must be positive")
    import numpy as np
    import scipy
    requests = {"LP": benchmark_request(variants=args.variants, distinct_targets=args.distinct_targets),
                "MILP": benchmark_request(integer=True, variants=args.variants, distinct_targets=args.distinct_targets)}
    # This first-solve timing includes lazy optimizer/HiGHS initialization after
    # Python/application/NumPy/SciPy imports. It does not measure process startup;
    # warm solver timings must not be presented as first-user invocation latency.
    startup = perf_counter()
    warmup = StaticTradeOptimizer().solve(requests["LP"].base_mandate)
    startup_seconds = perf_counter() - startup
    record = {"timestamp_utc": datetime.now(timezone.utc).isoformat(), "python": platform.python_version(),
        "platform": platform.platform(), "numpy": np.__version__, "scipy": scipy.__version__,
        "financial_scope": "SYNTHETIC_CONFIGURED_CLOSING_SEARCH_NO_TRADE_EXECUTION_OR_AGENCY_CERTIFICATION",
        "first_solve_initialization_seconds": startup_seconds, "warmup_validated": warmup.validated,
        "static": {}, "full_search": {}}
    for mode, request in requests.items():
        record["static"][mode] = {str(size): _static_measurement(_expanded_static(request.base_mandate, size), args.repeats)
                                   for size in (100, 500, 1000)}
    if not args.static_only:
        for mode, request in requests.items():
            before = _search_measurement(request, previous_policy=True)
            after = _search_measurement(request)
            equivalent = before["economic_fingerprint"] == after["economic_fingerprint"]
            if not equivalent:
                raise ArithmeticError("Cache strategies produced different economic/search results")
            record["full_search"][mode] = {"holdings": 150, "pool_par_eur": "500000000",
                "quotes": 100, "variants": args.variants, "distinct_target_design": args.distinct_targets,
                "before": before, "after": after, "economic_equivalence": equivalent,
                "speedup": before["total_seconds"] / after["total_seconds"]}
            print(f"{mode}: {before['total_seconds']:.3f}s -> {after['total_seconds']:.3f}s; "
                  f"complete projections {before['production_projection_calls']} -> {after['production_projection_calls']}", flush=True)
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(json.dumps(record, indent=2), encoding="utf-8")
    print(json.dumps(record, indent=2))


if __name__ == "__main__":
    main()
