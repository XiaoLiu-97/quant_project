"""Complete synthetic tape integration and input convention regressions."""

import csv
import unittest
from datetime import date
from decimal import Decimal
from pathlib import Path

from trident.adapters.csv_input import run_synthetic_example
from trident.adapters.records import position_from_record, run_request_from_records
from trident.application.services import CashflowRunService
from trident.cashflows.engine import ContractualCashflowEngine
from trident.conventions.calendar import calendar_from_name
from trident.domain.models import InterestMode
from trident.market.rates import FlatRateProvider

ROOT = Path(__file__).resolve().parents[1]
EXAMPLE = ROOT / "data/examples/hybrid_500m"
D = Decimal


class ExampleIntegrationTests(unittest.TestCase):
    def test_150_loan_contractual_projection_and_funding(self) -> None:
        result = run_synthetic_example(EXAMPLE)
        self.assertEqual(result.asset_count, 150)
        self.assertEqual(len(result.cashflows), 4316)
        self.assertEqual(result.total_principal, D("500000000"))
        self.assertEqual(result.funding.equity_cash_funding, D("53475000"))
        self.assertEqual(result.first_payment_date, date(2027, 2, 22))
        self.assertEqual(result.first_payment_interest, D("7670139.00"))
        first = [row for row in result.cashflows if row.period_number == 1]
        self.assertEqual(sum(row.principal_repayment for row in first), D("7000000"))
        for row in result.cashflows:
            self.assertEqual(row.opening_balance - row.principal_repayment, row.closing_balance)
            self.assertEqual(row.cash_interest + row.principal_repayment, row.total_cash)

    def _example_row(self) -> dict[str, object]:
        with (EXAMPLE / "assets.csv").open(encoding="utf-8", newline="") as stream:
            return next(csv.DictReader(stream))

    def test_day_count_aliases_are_explicit(self) -> None:
        row = self._example_row()
        self.assertEqual(position_from_record(row).terms.day_count.value, "ACT/360")
        row["day_count"] = "ACT/360"
        self.assertEqual(position_from_record(row).terms.day_count.value, "ACT/360")

    def test_linear_eom_validation_uses_actual_schedule(self) -> None:
        row = self._example_row()
        row.update(cashflow_projection_start_date="2026-02-28", par_as_of_date="2026-02-28",
                   maturity_date_unadjusted="2027-02-28", schedule_anchor_day="28",
                   end_of_month=True, amortization_first_date_unadjusted="2026-05-31",
                   amortization_periods_remaining="4", amortization_fraction_initial_par_per_period="0.25")
        self.assertTrue(position_from_record(row).terms.end_of_month)
        row["amortization_first_date_unadjusted"] = "2026-05-28"
        with self.assertRaises(ValueError):
            position_from_record(row)

    def test_unsupported_features_and_missing_ids_fail_explicitly(self) -> None:
        # PIK and London are supported migrations. Retain their negative
        # boundaries: metadata must agree with the contractual cash/PIK mode,
        # mixed fractions must be strictly between 0 and 1, and a typo must
        # never silently fall back to another financial calendar.
        for change in ({"pik": "true", "interest_mode": "CASH"},
                       {"pik": "false", "interest_mode": "PIK"},
                       {"pik": "true", "interest_mode": "MIXED", "pik_fraction": "1"},
                       {"pik": "true", "interest_mode": "MIXED", "pik_fraction": "0"},
                       {"revolver": "true"}, {"credit_status": "DEFAULTED"},
                       {"loan_id": None}, {"holiday_calendar": "LONDN"}, {"current_par": ""}):
            row = self._example_row()
            row.update(change)
            with self.subTest(change=change), self.assertRaises(ValueError):
                position_from_record(row)

    def test_supported_pik_and_regional_calendar_reach_the_shared_engine(self) -> None:
        engine = ContractualCashflowEngine(FlatRateProvider({"EURIBOR_3M": D("0.025")}))
        for change in ({"pik": "true"}, {"holiday_calendar": "LONDON"},
                       {"pik": "true", "holiday_calendar": "LONDON"}):
            with self.subTest(change=change):
                record = self._example_row()
                record.update(change)
                position = position_from_record(record)
                expected_mode = InterestMode.PIK if change.get("pik") == "true" else InterestMode.CASH
                self.assertEqual(position.terms.interest_mode, expected_mode)
                self.assertEqual(position.terms.holiday_calendar.value, record["holiday_calendar"])
                rows = engine.generate(position)
                calendar = calendar_from_name(record["holiday_calendar"])
                self.assertTrue(all(calendar.is_business_day(row.payment_date) for row in rows))
                total_pik = sum((row.pik_interest for row in rows), D(0))
                self.assertEqual(sum((row.principal_repayment for row in rows), D(0)),
                                 position.opening_balance + total_pik)
                self.assertEqual(rows[-1].closing_balance, D(0))
                if expected_mode is InterestMode.PIK:
                    self.assertGreater(total_pik, D(0))
                    self.assertTrue(all(row.cash_interest == D(0) for row in rows))
                else:
                    self.assertEqual(total_pik, D(0))

    def test_duplicate_asset_ids_do_not_double_count(self) -> None:
        row = self._example_row()
        request = run_request_from_records((row, row), (), FlatRateProvider({"EURIBOR_3M": D("0.025")}),
                                         upfront_fees=D(0), cash_reserve=D(0), rate_provenance="TEST")
        with self.assertRaisesRegex(ValueError, "Duplicate loan_id"):
            CashflowRunService().run(request)


if __name__ == "__main__":
    unittest.main()
