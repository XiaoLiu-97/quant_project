# 架构与数据流

金融计算不依赖 worksheet 坐标。Excel transport 按 named owner、Table identity 和 header mapping 读取；application 接收 immutable typed request；domain/cashflow/CLO/analysis/optimization 模块负责金融计算。

```mermaid
flowchart TD
  UI[15个Excel用户页: owning inputs] --> Reader[InterfaceInputReader: joins, units, dates, sources]
  Reader --> Snapshot[Immutable input snapshot + fingerprint + execution profile]
  Snapshot --> Model[TridentModelService: assets, analysis, CLO, returns]
  Snapshot --> Closing[Closing ScenarioRunner]
  Snapshot --> Opening[StaticOpeningScenarioService]
  Snapshot --> Static[StaticTradeOptimizer]
  Snapshot --> Search[ClosingPoolSearchService: finite candidates + full replay]
  Model --> Records[Interface reporting: typed saved case records]
  Closing --> Records
  Opening --> Records
  Static --> Records
  Search --> Records
  Records --> Package[WorkbookPackage: stable template + result values/caches]
  Package --> Capacity[Preserve native Table capacity; guarded growth when needed]
  Capacity --> Verify[Input protection + changed XML + package integrity]
  Verify --> Publish[Atomic output publication]
```

| 所有者 | 实现 | 责任 |
| --- | --- | --- |
| Input transport | `src/trident/adapters/interface_inputs.py` | 共同 Asset Library/Pool join、字段与单位、来源、opening、market、typed scenario 和优化输入 |
| 一次完整运行 | `src/trident/adapters/interface_run.py` | 同一 snapshot，独立 case，当前 run 内 cache，所有选中服务完成后交给 writer |
| 合同与 funding | `application/services.py`、`cashflows/`、`funding/` | original schedules、fixings、posted cash、closing sources/uses；opening 不重购/重发 |
| 全模型 | `application/clo_services.py`、`clo/`、`credit/` | 分开合同 reference 与 actual stressed receipt，账户/claim、coverage、reinvestment、dated equity cash |
| What-if | `application/scenarios.py`、`application/opening_scenarios.py` | immutable case edits、explicit opening valuation、status-aware 全量比较 |
| 优化 | `optimization/`、`application/construction.py`、`candidate_search.py` | static proposals、admission、cent reconciliation、closing replay；不结算真实交易 |
| Presentation | `adapters/interface_reporting.py`、`interface_output.py` | 保存报告和单位，选择已完成 case；不重新定义金融公式 |
| Package transport | `adapters/interface_package.py` | protected inputs、稳定展示公式与样式、批量值/cache更新、变动XML校验、ZIP/relationships、原子保存 |
| 输入容量与目录 | `adapters/interface_capacity.py` | named input grids、blank reserves、paired witnesses、compact live Asset ID options；不生成业务记录 |
| 输出容量策略 | `adapters/interface_output_capacity.py` | 按资产/期数/tranche/case预留native结果Table范围；登记实际记录数与容量类别 |

读入不使用 formula cached result 作为 owning input；原始输入和 execution profile 均纳入 fingerprint。共同 ID 必须唯一，Pool face/currency 必须与资产投影及 analysis exposure 一致。Market Data 不被 writer 改写；原 styles/resources 保留，新增 output style 追加。

## 场景与发布顺序

```mermaid
sequenceDiagram
  participant U as 用户
  participant R as Reader
  participant A as Application
  participant W as Writer
  participant X as Excel
  U->>X: 修改owning inputs，保存，关闭
  U->>R: 运行本项目launcher
  R->>R: 校验schema、identity、units、source
  R->>A: Immutable request + definitions
  A->>A: 全部case输入先校验，再独立投影
  A->>W: 完整typed结果与fingerprint
  W->>W: 复用已验证模板；保护inputs并核对容量
  W->>W: 批量更新值/cache；检查变动XML及完整package invariants
  W->>X: 校验临时ZIP后原子发布完整工作簿
  U->>X: 打开；重算展示lookup和图表；切换已保存case
```

未支持的输入组合必须带原因失败。一次失败不能拼接成功 case 与旧 output。Writer 对 variable output 进行有限 Excel 范围和相邻 input/table 碰撞检查；页面数量不随 lifetime period 或资产记录数量增加。隐藏 `_Lists` 保存选项/输入 witness；隐藏 `_Results` 保存完整 case/audit records。

## 稳定模板与增量写出

一次运行包含三种不同的工作。Python 重新计算启用的资产、CLO、分析及优化，并生成完整真实记录；Excel 的 `INDEX/MATCH/IFERROR` 等公式选择、汇总或格式化这些已保存结果；package transport 将结果保存到工作簿。展示公式不是第二套 waterfall 或信用模型。

Writer 在同一个运行内复用已解析的 worksheet、cell、Table 和 named-owner 索引。对已有单元格先比较实际值、公式及展示语义；完全相同的单元格保留原 XML，避免先创建大量新节点再比较。公式表达式不变而结果改变时，仅更新匹配公式的 cached value，并保留原公式和不相关扩展内容；不能因公式文本不变就继续显示旧 run 的结果。既有特殊公式仅在表达式稳定时保留其原属性；该缓存路径不负责重新构造 shared/array formula group。普通展示公式的表达式、类型或格式确需变化时仍走常规完整更新。样式通过已有 style identity 和语义格式复用；格式变化仍需更新。

Native Table 的最终范围按现有容量与实际记录数一次确定。容量内直接批量更新实际记录，不先缩为实际行数再扩回预留范围；新增空尾不制造业务值或大量公式。超过现有容量才解析和检查扩展区域内的非 Table 内容、相邻 Tables、named inputs 与 merges。选项和 witness 保持各自的精确语义。缩短结果仍清除过期值、公式及缓存，保留可重用的空白格式；case、period 和 Asset ID 选项跟随真实记录更新。

文件校验采用明确的信任边界：读入 source 时完整验证 package，并复用解析树；只有与已验证原始 bytes 完全一致的 part 才复用已解析内容。最终仍检查当前 DOM 中的完整 relationships、names、schema 和公式不变量，新增或变动 XML 还须能合法序列化；输入保护及 Market Data XML 原样要求保留。此优化减少重复解析，不仅检查发生变化的业务字段。临时 ZIP 的条目、内容、metadata 和 comment 与已验证 package 逐一核对，并检查 CRC 后才原子替换目标。

若输出覆盖同一 source 文件，writer 在开始 staging 前和原子发布前分别核对该文件的 ZIP 内容、metadata、comment 与 CRC，必须与载入时的 source 完全一致。用户或其他程序在运行期间修改它时，writer 明确拒绝覆盖，保留较新的文件；已有的不同目的地仍独立完整验证。该流程不凭路径相同就跳过保护。发布失败保留上次完整输出。

图表的旧数据缓存会失效；Excel 在重开时按当前已保存结果重算展示公式与图表。该重算不运行 Python 金融引擎，也不把 Excel cached lookup 当成下一次 owning input。公式/缓存刷新、xlsx 序列化及压缩仍需耗时；结构复用不代表写出变成零成本。实际计时与等价性验证见 [优化运行时间](optimization_runtime.md) 和 [验收说明](readiness.md)。

## 容量与写出职责

容量是 presentation policy，不进入金融计算。12类可增长owning input Tables分别预留：资产身份/条款/详情、Pool、Trade Universe各300行，评级900行，principal schedule与asset events各3,000行，Capital Stack12行、limits100行，Scenario Edits和factor mapping各300行。Reader 忽略完全空白的 owning 记录，非空但不完整的记录仍按 schema 校验。所有变长 aliases、lookup 轴和 paired witnesses 跟随输入范围；单独的 live options helper 生成不含空尾项的 Asset ID 下拉框。Limits与factor mapping扩容只移动已识别的说明/导航到CLO Assumptions右侧独立区域，guard先检查目标没有冲突；业务owner与named navigation保留，任意未知的相邻内容不能自动移动。

所有 Tables 保留明确容量类别。固定账户、费用、枚举和 Market Data 维持相应语义与布局；动态结果的 native Table ref 预留与资产、期数、tranche 和 case 匹配的物理容量，实际记录数独立登记。预留区没有业务记录时保留空白，不预填大量资产-period展示公式。Writer 缓存已解析的 sheet/cell/row 与保护区索引，按受影响区域批量写入；已有 cell styles 和相同 XML 内容复用，容量内记录变化保持最终 Table ref 稳定，超过容量才检查安全扩展。缩短结果时清掉过期内容但保留空白格式。隐藏 `tbl_trident_ui_table_capacity` 保存物理行数、实际记录数、请求容量和容量模式。

更新金融值、case records、fingerprint、运行时间及失效旧图表 cache 仍是每次发布的必要工作。减少重复 worksheet 扫描、节点构造和校验解析不会移除 input protection、namespace/schema 校验、相邻区域碰撞检测或原子保存。容量登记及使用方式见 [Table 容量](table_capacity.md)；实际性能和等价性证据按 [验收说明](readiness.md) 阅读。

`STATIC_NOT_REPLAYED_NOT_EXECUTED` 方案与经 full closing replay 的 case 分开。Readiness 只证明已知输入能进入该 research workflow，不证明 solver 可行、rating calibration、法律 eligibility 或真实成交。


## CLO acquisition：计划、校验与提交

`SyntheticReinvestmentLedger` 是每次运行独立的 mutable ledger；`ReinvestmentPurchase` 是 immutable plan。`plan_purchase()` 只计算实际 cents cost、acquired face及maturity，不创建资产或消耗cohort ID。Engine用该计划构造prospective valuation / coverage，保留当期IC的收入与debt service；STOP拒绝时没有ledger mutation。通过后`commit_purchase()`重新核对policy、当前boundary、金额及身份，再创建cohort。

Engine随实际sale或purchase替换当前OC valuation；PRINCIPAL_GATE与PERIOD_END复用同一资产状态。交易金额、cash用途designation、performing/defaulted face与未来coupon/recovery rights分别维护。该流程属于generic synthetic assumptions，未扩展输入schema或真实交易执行能力；节点及已知答案见[waterfall说明](waterfall_review.md)。
