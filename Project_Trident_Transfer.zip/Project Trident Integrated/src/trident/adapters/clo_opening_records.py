"""Named opening balances become explicit financial state, never inferred history.

The three small input tables group date/valuation, physical accounts and unpaid
claims. Requiring explicit zero rows prevents an accidentally omitted trustee
balance from silently being treated as zero. All business access uses registry
names and column keys; no sheet layout participates in calculation.
"""

from dataclasses import replace
from trident.clo.models import CloNoteCouponClaim, CloOpeningState
from trident.domain.models import InputValidationError
from . import excel_schema as schema
from .records import boolean_value, date_value, decimal_value, text_value

ACCOUNT_FIELDS = {
    'PRINCIPAL': 'principal_cash', 'INTEREST': 'interest_cash', 'RESERVE': 'reserve',
    'PENDING_PRINCIPAL': 'pending_principal_cash', 'PENDING_INTEREST': 'pending_interest_cash',
    'ORIGINAL_PRINCIPAL_REINVESTMENT': 'original_principal_reinvestment_cash',
    'PENDING_ORIGINAL_PRINCIPAL_REINVESTMENT': 'pending_original_principal_reinvestment_cash',
    'HELD_DIVERSION': 'held_diversion_principal',
}
FEE_FIELDS = {
    'SENIOR_EXPENSES': 'expense_arrears', 'SENIOR_MANAGEMENT': 'senior_management_fee_arrears',
    'SUBORDINATED_MANAGEMENT': 'subordinated_management_fee_arrears',
    'DEFERRED_SENIOR_EXPENSES': 'deferred_senior_expense_arrears',
}


def _records(adapter, key):
    return adapter.table_records(schema.TABLE_RANGE_NAMES[key], schema.TABLE_NAMES[key])


def opening_from_workbook(adapter, capital):
    """Parse a complete optional opening profile before running any engine."""
    controls = _records(adapter, 'clo_opening')
    accounts = _records(adapter, 'clo_opening_accounts')
    claims = _records(adapter, 'clo_opening_claims')
    retired = _records(adapter, 'clo_retired_assets')
    if not controls:
        if accounts or claims or retired:
            raise InputValidationError('Opening CLO accounts/claims require one CLO Opening control row')
        return None, None, '', False
    if len(controls) != 1:
        raise InputValidationError('CLO Opening requires exactly one control row')
    row = controls[0]
    if text_value(row.get('timing'), 'opening timing') != 'POST_DISTRIBUTION':
        raise InputValidationError('Only POST_DISTRIBUTION existing CLO opening is supported')
    supplied, seen = {}, set()
    for item in accounts:
        name = text_value(item.get('account'), 'opening account')
        if name not in ACCOUNT_FIELDS or name in seen:
            raise InputValidationError('Unknown or duplicate opening account: ' + name)
        seen.add(name)
        text_value(item.get('source'), 'opening account source')
        supplied[ACCOUNT_FIELDS[name]] = decimal_value(item.get('balance'), name + ' balance')
    if seen != set(ACCOUNT_FIELDS):
        raise InputValidationError('Supply all eight opening account balances, including explicit zeros')
    debt_ids = {text_value(item.get('class_id'), 'debt class') for item in capital if item.get('instrument_type') == 'DEBT'}
    fee_seen, note_seen, coupons = set(), set(), []
    for item in claims:
        kind = text_value(item.get('claim_type'), 'opening claim type')
        text_value(item.get('source'), 'opening claim source')
        amount = decimal_value(item.get('amount'), 'opening unpaid claim')
        identity = item.get('class_id')
        if kind == 'NOTE_COUPON':
            identity = text_value(identity, 'coupon class_id')
            if identity not in debt_ids or identity in note_seen:
                raise InputValidationError('Unknown or duplicate opening coupon class: ' + identity)
            note_seen.add(identity)
            coupons.append(CloNoteCouponClaim(identity, amount))
        elif kind in FEE_FIELDS:
            if identity not in (None, '') or kind in fee_seen:
                raise InputValidationError('Fee claims require a blank class_id and one row per claim type')
            fee_seen.add(kind)
            supplied[FEE_FIELDS[kind]] = amount
        else:
            raise InputValidationError('Unknown opening claim type: ' + kind)
    if note_seen != debt_ids or fee_seen != set(FEE_FIELDS):
        raise InputValidationError('Supply every note coupon claim and all four fee claims, including zeros')
    state = CloOpeningState(
        as_of_date=date_value(row.get('as_of_date'), 'CLO opening date'),
        note_coupon_claims=tuple(coupons), source=text_value(row.get('source'), 'CLO opening source'),
        initial_collateral_par=None if row.get('initial_collateral_par') in (None, '') else
            decimal_value(row.get('initial_collateral_par'), 'original initial collateral par'),
        **supplied)
    value = decimal_value(row.get('forward_equity_value'), 'forward equity value')
    source = text_value(row.get('equity_value_source'), 'equity valuation source')
    linked = boolean_value(row.get('use_ledger_snapshot'), 'use ledger snapshot')
    retired_ids = [text_value(item.get('asset_id'), 'retired asset_id') for item in retired]
    for item in retired:
        text_value(item.get('source'), 'retired asset source')
    if len(set(retired_ids)) != len(retired_ids) or retired and not linked:
        raise InputValidationError('Retired asset IDs must be unique and require a linked ledger snapshot')
    return state, value, source, linked


def bind_ledger_opening(adapter, request):
    """Reconcile settled operational history before the future CLO projection.

    No historical journal cash is injected into future asset collections: only
    the final physical cash and settled par are carried forward. The explicit
    timing attestation identifies the user-supplied post-distribution snapshot.
    """
    from .ledger_records import ledger_request_from_workbook
    from trident.portfolio import HoldingsLedgerService
    from trident.portfolio.clo_bridge import (
        LedgerCloOpeningAttestation, LedgerCloOpeningBridgeRequest, LedgerCloOpeningBridgeService,
    )
    ledger = ledger_request_from_workbook(adapter)
    if ledger is None or ledger.horizon_date != request.clo_opening_state.as_of_date:
        raise InputValidationError('Ledger-linked CLO opening requires Ledger Controls horizon equal to the CLO opening date')
    snapshot = HoldingsLedgerService().replay(ledger).final_snapshot
    bridge = LedgerCloOpeningBridgeService().bind(LedgerCloOpeningBridgeRequest(
        snapshot=snapshot, opening_state=request.clo_opening_state,
        positions=request.cashflow_request.positions,
        attestation=LedgerCloOpeningAttestation(request.clo_opening_state.as_of_date, True, request.clo_opening_state.source),
        known_zero_par_ids=tuple(text_value(row.get('asset_id'), 'retired asset_id')
                                for row in _records(adapter, 'clo_retired_assets'))))
    return replace(request, clo_opening_state=bridge.opening_state)


def opening_audit(adapter, request):
    """Preserve component sources alongside the exact state used by the engine."""
    state = request.clo_opening_state
    if state is None:
        return ()
    def audit(category, identity, amount, source, message=''):
        return dict(category=category, identifier=identity, amount=amount, unit='EUR',
                    as_of_date=state.as_of_date, source=source, message=message)
    rows = [audit('ACCOUNT', item['account'], getattr(state, ACCOUNT_FIELDS[item['account']]), item['source'],
                  'Designation within principal cash; do not add again' if 'REINVESTMENT' in item['account'] or item['account'] == 'HELD_DIVERSION' else '')
            for item in _records(adapter, 'clo_opening_accounts')]
    # Note IDs are user-defined and may equal a fee type. Separate metric
    # namespaces keep those distinct claims from colliding in reconciliation.
    rows.extend(audit('NOTE_COUPON' if item['claim_type'] == 'NOTE_COUPON' else 'FEE_CLAIM',
                      item.get('class_id') or item['claim_type'], item['amount'], item['source'])
                for item in _records(adapter, 'clo_opening_claims'))
    rows.append(audit('FORWARD_EQUITY_VALUE', 'EQUITY', request.forward_equity_value, request.equity_value_source,
                      'Forward return basis at opening; no historic issuance cash or closing fee recharge'))
    if state.initial_collateral_par is not None:
        rows.append(audit('HISTORIC_FEE_BASE', 'INITIAL_COLLATERAL_PAR', state.initial_collateral_par, state.source))
    return tuple(rows)
