# 使用指南

本模型将可编辑输入与金融计算分开。Excel 是工作界面；Python 读取各表和 named owners，构建同一 immutable input snapshot，再计算所有选择的结果。结果页中的 case、scope、日期和 tranche 下拉框只选择已计算的记录。

当前软件为 0.12.3，已通过 SUPPORTED_GENERIC_PROFILE 的完整回归；界面样式及长表配色的实际检查范围见验收记录。稳定入口为 [Project_Trident.xlsx](../outputs/Project_Trident.xlsx)，本轮文件已发布；详情见[验收](readiness.md)。工作簿保留你的最新输入，保存150个资产的BASELINE、A_MARGIN_150和SENIOR_FEE_20三个完整case、各42期；当前BASELINE IRR为3.2916419919%、MOIC为1.21309717214。收益随实际拥有者输入改变，不是固定目标。修改输入后保存关闭，运行本项目launcher，再重开结果。

理解waterfall先读[中文阅读指南](waterfall_guide_cn.md)或[17页流程图PDF](../outputs/Project_Trident_Waterfall_Flowcharts_CN.pdf)：按实际资金路径解释信用调整、账户、费用、IC/OC、补救、再投资、本金及equity回报；每页均有输入和结果位置。

## 页面与输入所有权

| 用户页 | 用途与可编辑内容 |
| --- | --- |
| Home | 工作流、导航、运行提示和最近一次完整计算 |
| Asset Library | 资产身份、合同参数、分类、评级及来源；一项资产可有多条评级 |
| Asset Schedules | 一对多本金计划、coupon step、credit event、seasoned opening claim 和已知 fixing |
| Asset Cashflows | 合同现金流明细；credit stress 下保留为 contractual reference |
| Market Data | 已保存的利率、历史 fixing、曲线与模式；保持可粘贴布局 |
| CLO Assumptions | deal、费用、coverage/diversion、OC policy/mapping、opening accounts 和 fee claims |
| Collateral Pool | 从共同 Asset Library 选择实际持仓、当前 face、成本和该 CLO 的 CCC/discount/OC mark |
| Capital Stack | debt/current face、coupon、coverage 门槛，以及 opening unpaid coupon 与来源 |
| Waterfall | 完整逐期、逐 tranche 瀑布；检查 claim、实际付款和期末余额 |
| CLO Analysis | 结果概览、现金流/摊还/coverage 图、scope 组合分析和 Source details |
| Scenarios | 页面内 Scenario Edits Table：每个 case 的绝对替换；每个 case 都从 BASELINE 独立建立 |
| Trade Universe | 已保存 bid/ask、size、settlement、accrued、费用和来源 |
| Optimization | 静态 mandate、目标、限制、candidate/replay 选择；不自动执行交易 |
| Trades & Comparison | 提议交易和完整 case 的 Base / Proposed / Delta |
| Checks | 输入一致性、计算状态、缺失数据、freshness 和需要 review 的项目 |

支持表可展开分组或取消隐藏以检查。不要将隐藏的计算结果、helper 或 witness 副本当作第二份输入。修改输入应在拥有该字段的用户表进行；公式 lookup、status 和显示字段不是金融输入。

## 预留输入行与新增记录

资产 register、terms、details、Collateral Pool 和 Trade Universe 各预留300条记录空间；Asset ratings预留900条；bespoke principal schedule与asset events各预留3,000条；Capital Stack预留12条、Portfolio limits100条，Scenario Edits与factor mapping各300条。可直接在对应 Table 的空白行填写新增记录。预留数量是整张表的初始空间，不是模型硬上限；一项资产的多期还款仍逐期填写在principal schedule，不能重复填到资产主表。Scenario Edits是一条edit一行，同一case可包含多条edit；未填写的行不创建新case。新增limit或factor mapping仍必须使用当前支持字段、系统和来源，容量增加不自动支持新的金融定义。

空行保持空白，不填占位 Asset ID 或零本金。新资产先在 Asset Library 注册身份并填写必需合同条款，再按用途加入 Pool 或 Trade Universe；Library 中的候选资产不会自动变成实际持仓。保存时 Excel 计算 Asset ID 选项目录，新填的真实 ID 即可用于 Pool、schedule 或交易引用，空尾行不会成为可选项。

固定账户、fee claims、控制项与枚举保持其业务语义数量。结果表预留相应物理容量，但只填写实际计算记录；未使用尾部为空，不生成空资产现金流或额外tranche。容量内复用原有Table范围、格式和不变的展示公式，超过容量时安全扩展。取消隐藏 `_Results` 后，可在 `tbl_trident_ui_table_capacity` 检查每张表的物理行数、实际记录数、请求容量及类别；规则与增长保护见 [Table 容量](table_capacity.md)。

CLO Assumptions的OC ownership说明和导航已移到同页右侧AC列开始的独立区域；可通过原named navigation或Excel名称框输入 `tbl_trident_ui_oc_ownership` 定位。其Table在 `AC10:AE14`，Pool/Credit入口在AC16/AF16，Advanced mapping入口在AC18；factor warning在 `AC22:AH22`。这是说明位置调整，OC policy输入与factor mapping的W:AB输入owner保持原位置。

## 输入单位

| 内容 | 输入单位 | 示例 |
| --- | --- | --- |
| Face、账户、claim、固定费用 | EUR，金额到 cent | `1000000.00` |
| Purchase/issue/bid/ask price | 每100 face 的 price points | `99.50` 表示99.50% |
| Spread / 明确标注的 floor 或 cap | bps | `350` 表示3.50% |
| Fixed coupon (%)、其他百分比字段 | Excel 百分数值 | `8%` 的底层值为0.08 |
| IC/OC minimum | ratio | `1.10` 表示1.10x |
| Accrued / par、费用 / par | EUR 每EUR1 face | `0.02` 表示每100 face 2EUR |
| 日期 | 真正 Excel date | 日期、来源和持仓时点必须一致 |

Scenario Edits 的 `New value` 使用该服务字段的内部单位：`spread_bps` 为bps，`fixed_rate` 为小数，`par` 和 `forward_equity_value` 为EUR，threshold 为ratio。文本或 enum 使用 `New option`。所有 edits 是绝对值；没有隐含 bump、成交、价格刷新或历史重建。

## Closing 与存续开账

Closing 使用实际 asset clean cost、purchased accrued、发行所得、明确费用/其他 sources/uses 和 reserve，计算 equity 实际出资。Equity nominal 不是投资成本。

Existing opening 是完整 distribution 后的 snapshot，必须落在原 payment boundary 且等于下一原 liability accrual start。保留原 Closing Date、first payment、频率、calendar、stub 和 fixing。Pool 的 holding as-of 必须与 opening 相同；贷款仍保留其原 schedule start，并提供必要的 seasoned entitlement 和历史 fixing。源数据不能用推测的零替代。

八个账户/资金 designation 均应有 balance 与 source，包括明确的零：INTEREST、PRINCIPAL、RESERVE、PENDING_INTEREST、PENDING_PRINCIPAL、ORIGINAL_PRINCIPAL_REINVESTMENT、PENDING_ORIGINAL_PRINCIPAL_REINVESTMENT、HELD_DIVERSION。`ORIGINAL_PRINCIPAL_REINVESTMENT` 和 `HELD_DIVERSION` 是 `PRINCIPAL` 内的互不重叠 designation；`PENDING_ORIGINAL_PRINCIPAL_REINVESTMENT` 属于 pending principal。它们不增加现金。每个 retained debt tranche 均有 opening coupon claim，包括零；另有四类 fee claim。当前 face 和 unpaid coupon 分开，避免把已经资本化的 claim 再加一次。

Existing 的初始 equity cashflow 为 opening date 的 `-forward_equity_value`，只加入未来净分配。这是 forward return，不是 since-inception return。历史 acquisition/setup 经济输入不重新收费；模型将其与未来费用区分，保留原输入记录。

## What-if 与结构研究

Closing case 可更改已有持仓/债务的已支持字段，并重算 funding、资产、组合和瀑布。存续 case 可更改未来费用、loan/note coupon、collar 和 coverage 假设。每个 case 保留开账 cash、unpaid claims、原 schedule 和 principal permissions。

存续 case 修改现有 asset 或 note `par` 时，必须在同一 case 中添加两条 CONTROL / DEAL edit：`forward_equity_value` 和 `equity_value_source`。该金额是完整 counterfactual opening snapshot 的 equity value，来源须明确。它不是模型推测的购买资金，也不证明交易已经成交。已有 asset 的 reference、绝对本金/balloon、BESPOKE schedule、seasoned owned claim 和分析 face 一致缩放；BESPOKE dates 不移动并保持 cent 总额。

不能用该路径新增/删除资产或把 face 改为零。已有 receipt-specific principal-accrued restoration 的资产 resizing 要求重新核验余额与 receipt instructions，当前路径明确拒绝。带历史前缀的 `FULL_CURRENT_PERIOD` coupon 不允许用 base-rate edit 重写已赚取历史；需要经核验的 future dated contract。

## 运行与验收

1. 在拥有字段的表中修改输入，检查 units、日期、source 和 lookup identity。新增记录优先填写已预留的 Table 空白行；超过预留行时再正常扩展 Table，并确认 named owner、输入约束及相关范围包含新增行。
2. 保存并关闭 Excel。在 Windows 文件资源管理器中双击本项目的 `Run_Model.cmd`，或使用 README 的 Python 命令；选择 `--output` 可保留输入副本。双击后应出现命令窗口，立即显示项目、工作簿、Python 和检查/计算进度；先等待 SUCCESS，再按键关闭。失败时窗口保留具体错误，按下方排查说明处理。
3. 打开新结果，检查 Home 的 timestamp、Checks 的 input fingerprint、case 列表和 model version。
4. 检查 full Waterfall 的日期、opening/current claims、paid/arrears、coverage GATE 与 period-end；确认 cash residual 为零。
5. 检查 IRR/MOIC 的状态、估值基准、终态债务/现金/default claims，并在 Trades & Comparison 检查经济 delta。

`UNAVAILABLE`、`NOT_CONFIGURED`、`NOT_APPLICABLE`、`BLOCKED` 和 `BREACH` 含义不同。没有达到 junior gate 的记录不能被读为通过；缺失 data 的 limit 不算 pass。输入修改后，saved result 可能过期；freshness 表示与保存的输入一致，不能代替运行、独立 benchmark 或法律 review。

静态 optimization 的 proposal 是研究结果，不结算订单，不产生 lifetime trade P&L。Synthetic reinvestment 由明确的期限、price、WAL、spread、CDR/CPR/recovery 与资金权限生成 projected cohorts。使用真实交易前，仍需核对 executed terms、rating methodology、dealer liquidity 与 trustee state。


## 如何检查 synthetic reinvestment

在CLO Assumptions中启用Reinvestment，并一起核对End Date、Purchase Price、WAL、资金recycling、CDR/CPR/recovery和Test Gate。**Stop on Test Failure**用于正常generic研究：模型不仅检查买前OC/IC与未付coupon，还先计算拟买后的面值、现金和adjusted OC，通过后才提交purchase。Price高于100、long-dated haircut或现金政策都可能使买前通过、买后失败；新cohort的未来coupon不能改善本期IC。

被拒绝的purchase不会创建资产、支出现金或改变designations；普通principal继续按本期priority还本，仍在窗口内的held IDT按原earmark保留。实际买入后，剩余本金的PRO_RATA/sequential判断立即使用新collateral valuation。**Always Reinvest**仅用于明确的coverage/unpaid-coupon override敏感性；它仍受现金/日期/final和long-dated/classification保护，不能作为真实交易合规通过标志。Asset-level OC没有synthetic分类与mark transport时仍明确拒绝该组合。

运行后查看Waterfall的Reinvestment cash/par、principal付款、期末collateral与cash；必要时展开 `_Results` 的reinvestment和coverage明细核对。Purchase前后及PRINCIPAL_GATE是内部决策，不是新的Excelreport stage；既有GATE、POST_DIVERSION及PERIOD_END仍按原定义展示。现金residual为零、PERIOD_END OC通过，都不能单独证明中间本金分配正确。Reinvestment cash为0也可能是拟买后coverage否决，即使可见GATE和PERIOD_END都PASS；当前界面不保存独立purchase-rejection reason。完整节点和两个独立手算例见[waterfall方法](methodology/waterfall.md#synthetic-purchase-的前后状态检查)与[waterfall流程与方法](waterfall_review.md)。

## 为什么 Waterfall 的 Prepayments 可能为零

原始 Collateral Pool 与后来购买的 synthetic reinvestment assets 使用各自的假设。交付示例的 **Credit / Prepayment Overlay = Off、Original Collateral CPR = 0%、Reinvestment Enabled = No**；保留的 **Annual Prepayment Rate = 10%** 只属于 synthetic reinvestment 参数。没有启用原池 overlay，也没有实际 synthetic purchase 时，这个10%不会作用于当前持仓。该示例未另行指定 dated prepayment event，因此 Waterfall 的 Prepayments 为零。

| CLO Assumptions 中的输入 | 输入拥有者与作用范围 | Excel 名称框可直接导航 |
| --- | --- | --- |
| Credit / Prepayment Overlay | 选择 On 才启用原始 collateral 的比例 default/prepayment stress；同时检查该组的 CDR、recovery 和 timing | `trident_ui_credit_prepayment_overlay` |
| Original Collateral CPR | 原始 Collateral Pool 的年化 CPR；只有 overlay 为 On 时生效 | `trident_ui_original_collateral_cpr` |
| Reinvestment Enabled | 选择 Yes 才允许符合日期、资金权限及 purchase gates 的 synthetic purchase | `trident_ui_reinvestment_enabled` |
| Annual Prepayment Rate | synthetic purchase 后生成的 reinvestment cohorts 的年化 CPR；不覆盖原始池 | `trident_ui_reinvestment_annual_prepayment_rate` |

**让原始池采用10%年化 CPR：**在 Excel 左上角的名称框粘贴 `trident_ui_credit_prepayment_overlay` 并按 Enter，选择 On；再导航到 `trident_ui_original_collateral_cpr` 并输入 `10%`。检查同组的 default/recovery 假设：这个开关启用完整原池 credit overlay，不会仅凭你的 CPR 输入替你关闭 CDR。保存并关闭 Excel，运行 `Run_Model.cmd`，看到 SUCCESS 后重开，在 Waterfall 的 Prepayments 行检查逐期实际本金收款。该操作是你选择的 scenario，模型不会自动修改原始输入或默认值。

具体资产的提前还款也可通过 Asset Schedules 的已支持 dated credit event 指定；这是独立路径，不以启用 synthetic reinvestment 为前提。不要为同一资产重复设置不兼容的 explicit event 与比例 overlay；reader 会校验支持的组合。Asset Cashflows 保留合同参考计划，查看 credit stress 后实际收款应使用 Waterfall 或隐藏的 credit collection 明细。

CPR 是年化的条件提前还款率，不是每季度直接还款10%。当前比例 stress 使用 ACT/365F：`p = 1 - (1 - CPR) ** (实际天数 / 365)`；default 及当期 scheduled principal 先处理，再对剩余 performing principal 应用 p，金额按 cent 入账。例如无 default、期初本金100、scheduled principal 20、区间90天、年化 CPR 10%，prepayment 为 `80 × [1 - 0.9 ** (90/365)] = 2.05158...`，入账2.05，期末 performing principal 为77.95。不是在100上直接取10，也不是在80上直接取10%。

条件年化及 scheduled-principal 后余额的逻辑可与 [SEC 公开 trustee report 的 CPR/SMM 定义](https://www.sec.gov/Archives/edgar/data/1561167/000162829726000181/ex99_1.htm)交叉核对。该来源使用月度转换；本模型的 ACT/365F、default/CPR 时点与先后顺序是明确的模型假设，应按实际需求选择，不能理解为所有 CLO 的统一条款。完整路径见 [计算流程图](calculation_flowcharts.md)。

## 输入拥有者与参考字段

当前价格与利息的拥有者是 Collateral Pool：每项实际持仓的 acquisition price 和 purchased accrued 在该表输入。CLO Assumptions 保留的 aggregate purchase price/accrued 和 Reference Curve 是参考字段，不覆盖逐项持仓或贷款 coupon index。债券 Coupon index 与 Day count 由 Capital Stack 拥有；单项资产条款由 Asset Library/Asset Schedules 拥有。Global Day Count 用于 synthetic reinvestment coupon，账户计息和费用 convention 则按明确的 execution policy。保留的 Collateral Cashflow Input Mode 不切换计算来源；当前 compact 流程使用 INTERNAL_ENGINE。请修改真正拥有该输入的表，避免只改变参考字段而以为已修改金融假设。

## 独立资产现金流模式

Home 的 Workflow 选择 `Asset Cashflows` 时，仅运行已声明资产的合同参考现金流与相关组合观察，不投影 CLO 瀑布，也不计算股权 IRR/MOIC。该模式没有股权投资成本或 CLO 分配现金；回报显示 `n.a.`，核心 ReturnResult 以 `UNAVAILABLE` 加“CLO projection was not selected”说明有意未选择，而不是填零。

运行前关闭不适用的 NOTE/CLO/control scenario edits、candidate search 和 static optimizer；若只研究资产合同变更，可使用已支持的 ASSET edits。保留启用的债券 edit 会明确指出 case 与不适用 note；它不会被忽略。Asset Library、Asset Schedules、Market Data 和 Asset Cashflows 是此模式的主要页面。成功运行后，之前的 CLO Waterfall、账户和股权结果须被清空；切回 New Issue 或 Existing CLO 后保存并重新运行才会生成相应 CLO 结果。

## 常用操作示例

### 费用、spread 与 coverage what-if

在 Scenarios 页的 Scenario Edits Table 中为同一 case 填写多条 Enabled edit。例如 `FEES_UP` 使用 CONTROL / DEAL / `senior_management_fee_bps` / `30`；这表示未来费用率替换为30bps，不是增加30bps。示例数值应按实际交易条款选择。`SPREAD_UP` 使用 ASSET / 实际 Asset ID / `spread_bps` / `450`，仅适用于 floating loan。Fixed loan 用 `fixed_rate`，如 `0.08` 表示8%。NOTE 的 `oc_minimum` / `ic_minimum` 使用 ratio；例如1.10x填写 `1.10`。

每个 case 从同一 BASELINE 建立；一个 case 的变更不会传给另一个 case。修改记录但未运行 Python 时，下拉框不会出现新的计算结果。字段的支持范围由 typed parser/service 控制：未知字段、coupon type 不符、遗漏 source 或无法核验历史的组合会明确失败。

### Opening face counterfactual

在同一 case 中更改 ASSET / Asset ID / `par` 或 NOTE / Class ID / `par`，同时声明 CONTROL / DEAL / `forward_equity_value` 和 CONTROL / DEAL / `equity_value_source`。数值放 `New value`；来源文字放 `New option`。声明的是该完整假设 snapshot 下 residual equity 的当前价值，而不是仅增加 face 对应的现金金额。模型不会把 nominal equity 或历史 funding 自动当作该估值。

Opening resize 保留原账户、未付 claims 和 original schedule；已有 asset owned slice 及绝对本金计划按规定一致缩放。已有 note 的 outstanding face 改变不重写原 unpaid coupon claim。本服务不推测成交、现金交换、receipt ownership 重绑定、新增/删除资产或 face 为零的清仓操作。

### 静态优化与 finite closing candidates

在 Trade Universe 填写有来源的 bid/ask、有效 size、settlement 和费用，在 Optimization 填写目标与硬约束。`optimizer_enabled` 决定是否运行静态优化；`candidate_search_enabled` 选择 finite closing candidate replay。这两个路径必须二选一，不能同时启用；其结果含义不同，应按输出 Status 阅读。

静态结果的 `STATIC_NOT_REPLAYED_NOT_EXECUTED` 表示已求解当前 snapshot 的研究 mandate，尚未执行且未证明全 CLO lifecycle return。Closing candidate search 对被接纳的候选重建 funding、持仓和结构并完整 replay；只有 validated replay 才可用于已验证 return ranking。Opening 不支持 closing issuance/candidate search；可使用独立 opening what-if 和静态研究。Solver infeasible、缺失 metric 或 blocked gate 不转换为 PASS。

## 阅读结果与隐藏明细

| 位置或选择项 | 阅读方式 |
| --- | --- |
| CLO Analysis / Case | `BASELINE`、已启用 what-if 和保存的完整 optimizer replay case；每个 case 有自己的完整 projection |
| CLO Analysis / Scope | Whole、BSL、INFRA 的 selected-case opening 组合；它不是重新投影另一个子组合的 CLO |
| CLO Analysis / 日期、Tranche | 选择保存的 waterfall coverage 记录；GATE 是当时实际决策节点，End 是期末诊断 |
| CLO Analysis / Comparison | 选择已保存的 case，查看 available headline return；完整 delta 见 Trades & Comparison |
| Source details | 对齐的 field/value/unit/status/basis 面板；用于理解当前值与数据要求 |
| Asset Cashflows / Cashflow basis | 选择 held-case 的 contract reference，或 `LIBRARY_REFERENCE` 的原合同/reference face；后者不是该 CLO 持仓和收款 |
| Waterfall | Case 跟随 CLO Analysis，Tranche 选择完整逐期明细；检查 coupon、principal、账户和 coverage |
| `_Results` | 完整 case records、dated portfolio metrics/limits、credit collections、par movements、coverage、reinvestment 和其他 audit detail |
| `_Lists` | 选项目录、输入 witness 和显示支持数据；它不是另一份 editable input |

15个用户页保持不变。运行会在隐藏支持表保存全部 selected case 及 Table 容量登记；period 或资产记录增加不会新增用户页。需要深入审阅时可取消隐藏 `_Results` 或展开支持列；审阅后恢复隐藏。不要编辑该处的结果/helper/witness 或容量登记来改变模型。日期字段使用真正的 Excel date，金额、比率、百分比和年数按其 Unit 显示。

### 状态与 freshness

| 状态 | 实际含义 |
| --- | --- |
| AVAILABLE / PASS | 分别表示 metric 可测或该已执行 test 通过；二者不同 |
| UNAVAILABLE / REVIEW | 输入或 measured coverage 不足；检查来源和缺失字段 |
| NOT_CONFIGURED / NOT_SELECTED | 该 test/service 未配置或未选择 |
| NOT_APPLICABLE | 当前 profile 下没有该经济项目，例如 Existing 的新 issuance cash |
| BLOCKED | 尚未到达该 junior 决策节点；不能解释为通过 |
| BREACH / FAIL | 已测量 test 或 runtime check 未满足要求 |
| COMPLETED / CALCULATED | 当前选中的计算服务完成；仍需检查金融终态、limits 和 return status |

Checks 的 freshness 比较拥有者输入与保存计算的 witness。改变输入应产生 dirty 标记；运行成功并重开后应恢复一致。Case、日期或 scope 的纯显示选择不会使输入变脏。Freshness 不能核验数据真实性、法律条款或未进入输入的外部变化，也不能替代重新运行。

## 常见错误与处理

- 双击 launcher 后以为没有运行：正常会打开命令窗口并显示 `[1/2]` 环境检查及 `[2/2]` 计算步骤，计算时会保留当前阶段提示；成功和失败都停在“Press any key”等待你关闭。运行时间取决于资产、合同期数、启用 case、优化路径、输出记录量及电脑配置；预留空行不能免除真实结果刷新，请以阶段提示和 SUCCESS 为准。若始终没有出现窗口，可在本项目文件夹打开终端并执行 `cmd /c Run_Model.cmd`，保留可见的系统错误；具体步骤见 [部署排查](deployment.md#双击启动与排查)。
- 环境检查显示 Python/依赖错误：最低要求为 Python 3.11 和 openpyxl；启用优化另需 numpy/scipy，可选 PDF reporting 另需 reportlab。使用窗口显示的实际 interpreter 安装，不要把其他环境的已安装包当作当前环境；安装命令见 [部署](deployment.md)。
- Prepayments 为零而 Annual Prepayment Rate 非零：先区分原始池 CPR 与 synthetic reinvestment CPR，并检查各自开关。上面的“为什么 Waterfall 的 Prepayments 可能为零”给出字段名称、位置和完整操作。
- Asset ID/Class ID 不存在或重复：在真正拥有该身份的表中修正；不能靠修改 helper 或 lookup 的显示文字解决。
- 日期、opening claims 或 fixing 缺失：提供明确来源，包括经核验的零；不要用未来曲线重建缺失历史。
- Ratio、bps 与百分数混用：按字段 Unit 更正。例如 Scenario `fixed_rate=8` 不是8%；`spread_bps=0.035` 不是350bps。
- 保存结果仍显示旧 timestamp 或 dirty：先保存关闭输入，再运行本项目 launcher；成功后重开结果。
- Table 增长碰撞或超过 Excel 容量：依据错误所指 range 调整 owning layout/数据；模型明确停止，避免覆盖相邻输入。
- `n.a.` 或 incomplete IRR：查看完整状态、终态 liabilities/default claims/现金和所需 source；不使用0补齐回报。
- 工作簿正在 Excel 中打开或目标文件被锁：保存并关闭后再运行；失败不会以部分结果覆盖上一份完整工作簿。

部署与可移植性见 [安装与迁移](deployment.md)，金融口径与 profile 边界见 [模型假设](model_assumptions.md)。

完整计算路径及页面导览见 [计算流程图](calculation_flowcharts.md)。

## 提前还款与违约是否随机

当前不是随机模拟。比例模式按明确的年化 CPR/CDR、日期长度和 timing pattern 计算；dated events 使用用户指定的资产及日期。相同输入产生相同现金流。模型没有随机抽取贷款、Monte Carlo 或违约相关性；输出是特定假设路径下的现金流和 IRR，不能直接当作随机路径的平均 IRR 或收益分布。

## 当前写出方式与运行时间

无需更改操作：保存关闭工作簿，运行 `Run_Model.cmd`，等待 SUCCESS，再重开。Python仍重新计算已启用的全部cases；writer先比较已有内容，只修改变化值/cache，复用不变公式、样式和容量范围。缩短或清空结果会移除旧尾部。若writer载入后源文件又被修改，原路径覆盖会明确拒绝，保存较新输入后重新运行。

本机同一150资产/3cases/40期且优化Off的source=destination实测，总82.31秒降为45.08秒，其中写出60.94秒降为25.67秒。每组1次；不包括后续独立QA和Excel打开重算。模型规模、情景和电脑负载会改变时间。展示lookup和图表仍由Excel重算，金融结果来自Python。完整证据见[运行时间](optimization_runtime.md)及[验收](readiness.md)。依赖包与启动方式均没有新增要求。

Assumptions 的不同业务分区使用同一套 Table 隔行底色；颜色不会区分旧字段或新增字段。蓝色文字表示 owning input，灰色 Value 为保留参考，告警依状态变化。颜色补充修正见[验收](validation/interface_palette.json)。
