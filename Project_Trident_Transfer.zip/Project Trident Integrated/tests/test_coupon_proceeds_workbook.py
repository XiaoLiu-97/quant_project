"""Independent named-input and actual-receipt proceeds classification controls.

The hand loan earns EUR3.03 over Jan-Apr: 100 * 12.12% * 90/360.
At Feb16 its exact historical claim posts to 1.55. A verified principal-funded
part of 1.47 is restored from the received coupon, leaving 1.56 interest proceeds.
Those amounts are independent answers; classification must not change cash,
loan face, closing funding, dates or the raw contractual coupon.
"""

from datetime import date, datetime
from decimal import Decimal as D
from io import BytesIO
from pathlib import Path
import tempfile
from types import SimpleNamespace
import unittest

from openpyxl import Workbook, load_workbook
from trident.adapters import excel_schema as schema
from trident.adapters.coupon_proceeds_records import coupon_proceeds_from_records, coupon_proceeds_from_workbook
from trident.adapters.excel import NamedWorkbook, run_workbook
from trident.adapters.excel_model import execute_model_workbook, read_model_workbook_inputs
from trident.adapters.pilot_workbook import ensure_pilot_interface, input_fingerprint, observed_catalog, check_model_workbook
from trident.domain.models import InputValidationError
from trident.validation import ReconciliationKey
from workbook_fixtures import INPUT_TEMPLATE, put_records, hand_controls, write_controls


OPEN = date(2026, 2, 16)
PAY = date(2026, 4, 1)
BALANCE_KEY = 'principal_accrued_balances'
ALLOCATION_KEY = 'coupon_proceeds_allocations'
AUDIT_KEY = 'coupon_proceeds_audit'


def balance(**updates):
    row = dict(loan_id='L', as_of_date=OPEN, amount='1.47',
               source='Verified settlement accrued balance', legal_reference='Deal proceeds clause 1.1')
    row.update(updates)
    return row


def allocation(**updates):
    row = dict(allocation_id='RESTORE_L', loan_id='L', payment_date=PAY, collection_source='SCHEDULED',
        principal_amount='1.47', original_principal_permission=False,
        source='Trustee receipt allocation', legal_reference='Deal proceeds clause 1.1')
    row.update(updates)
    return row


class CouponProceedsRecordsTests(unittest.TestCase):
    def test_empty_policy_is_an_explicit_unchanged_default(self):
        self.assertEqual(coupon_proceeds_from_records((), ()), ((), ()))

    def test_explicit_decimal_dates_sources_and_false_are_preserved(self):
        opening, instructions = coupon_proceeds_from_records((balance(),), (allocation(),))
        self.assertEqual(opening[0].amount, D('1.47'))
        self.assertEqual(opening[0].as_of_date, OPEN)
        self.assertIs(instructions[0].original_principal_permission, False)
        self.assertEqual(instructions[0].collection_source.value, 'SCHEDULED')
        self.assertEqual(instructions[0].legal_reference, 'Deal proceeds clause 1.1')

    def test_excel_midnight_and_iso_dates_are_calendar_dates(self):
        row = balance()
        row['as_of_date'] = datetime(2026, 2, 16)
        opening, instructions = coupon_proceeds_from_records((row,), (allocation(payment_date='2026-04-01'),))
        self.assertEqual((opening[0].as_of_date, instructions[0].payment_date), (OPEN, PAY))

    def test_money_does_not_accept_missing_zero_negative_fractional_or_boolean(self):
        for value in (None, '', 0, '-1', '.001', 'NaN', 'Infinity', True):
            row = balance()
            row['amount'] = value
            with self.subTest(value=value), self.assertRaises(InputValidationError):
                coupon_proceeds_from_records((row,), (allocation(principal_amount=value),))

    def test_permission_must_be_supplied_as_bool_or_boolean_text(self):
        for value in (None, '', 0, 1, 'YES', ' FALSE '):
            with self.subTest(value=value), self.assertRaises(InputValidationError):
                coupon_proceeds_from_records((balance(),), (allocation(original_principal_permission=value),))
        _, instructions = coupon_proceeds_from_records((balance(),), (allocation(original_principal_permission='TRUE'),))
        self.assertIs(instructions[0].original_principal_permission, True)

    def test_source_and_legal_reference_are_mandatory_unpadded_evidence(self):
        for field in ('source', 'legal_reference', 'loan_id'):
            for value in (None, '', ' padded '):
                with self.subTest(field=field, value=value), self.assertRaises(InputValidationError):
                    row = balance()
                    row[field] = value
                    coupon_proceeds_from_records((row,), (allocation(),))
                with self.subTest(allocation_field=field, value=value), self.assertRaises(InputValidationError):
                    coupon_proceeds_from_records((balance(),), (allocation(**{field: value}),))

    def test_orphan_and_duplicate_loan_rows_are_rejected(self):
        cases = (((balance(),), ()), ((), (allocation(),)),
                 ((balance(), balance()), (allocation(),)),
                 ((balance(),), (allocation(), allocation(allocation_id='OTHER'))),
                 ((balance(),), (allocation(loan_id='UNKNOWN'),)))
        for rows in cases:
            with self.subTest(rows=rows), self.assertRaises(InputValidationError):
                coupon_proceeds_from_records(*rows)

    def test_duplicate_allocation_id_is_not_hidden_by_different_loans(self):
        second = balance()
        second['loan_id'] = 'OTHER'
        with self.assertRaisesRegex(InputValidationError, 'allocation_id'):
            coupon_proceeds_from_records((balance(), second), (allocation(), allocation(loan_id='OTHER')))

    def test_partial_or_excess_restoration_cannot_be_silently_accepted(self):
        for value in ('1.46', '1.48'):
            with self.subTest(value=value), self.assertRaisesRegex(InputValidationError, 'full matching'):
                coupon_proceeds_from_records((balance(),), (allocation(principal_amount=value),))

    def test_unsupported_sources_intraday_and_unknown_fields_are_rejected(self):
        for row in (allocation(collection_source='RECOVERY'), allocation(collection_source='DEFAULT'),
                    allocation(payment_date=datetime(2026, 4, 1, 12)), allocation(extra='ignored')):
            with self.subTest(row=row), self.assertRaises(InputValidationError):
                coupon_proceeds_from_records((balance(),), (row,))


class CouponProceedsNamedTableTests(unittest.TestCase):
    def setUp(self):
        self.book = Workbook()
        self.addCleanup(self.book.close)
        self.adapter = NamedWorkbook(self.book)
        ensure_pilot_interface(self.adapter)

    def test_optional_tables_are_structured_named_empty_and_idempotent(self):
        before = (len(self.book.sheetnames), len(self.book.defined_names))
        for key in (BALANCE_KEY, ALLOCATION_KEY, AUDIT_KEY):
            self.assertEqual(self.book.defined_names[schema.TABLE_RANGE_NAMES[key]].attr_text,
                             schema.TABLE_NAMES[key] + '[#All]')
            self.assertEqual(self.adapter.table_records(schema.TABLE_RANGE_NAMES[key], schema.TABLE_NAMES[key]), ())
        ensure_pilot_interface(self.adapter)
        self.assertEqual((len(self.book.sheetnames), len(self.book.defined_names)), before)

    def test_input_permissions_sources_dates_and_audit_amounts_have_readable_formats(self):
        for key in (BALANCE_KEY, ALLOCATION_KEY, AUDIT_KEY):
            sheet, (left, top, right, _) = self.adapter.region(schema.TABLE_RANGE_NAMES[key])
            fields = schema.TABLE_COLUMNS[key]
            for offset, field in enumerate(fields):
                cell = sheet.cell(top + 1, left + offset)
                self.assertTrue(cell.alignment.wrap_text, field)
                if field in {'amount', 'principal_amount', 'interest_proceeds', 'principal_proceeds'}:
                    self.assertEqual(cell.number_format, '#,##0.00')
                if field.endswith('_date'):
                    self.assertEqual(cell.number_format, 'yyyy-mm-dd')
            if key == AUDIT_KEY:
                self.assertEqual(sheet.row_dimensions[top + 1].height, 54)
                permission = sheet.cell(top + 1, left + fields.index('original_principal_permission'))
                self.assertEqual(permission.number_format, '#,##0.00')
            if key == ALLOCATION_KEY:
                formulas = {item.formula1 for item in sheet.data_validations.dataValidation}
                self.assertIn('"SCHEDULED,PREPAYMENT"', formulas)
                self.assertIn('"TRUE,FALSE"', formulas)

    def test_relocated_tables_are_read_by_names_and_native_growth_remains_visible(self):
        for key, row in ((BALANCE_KEY, balance()), (ALLOCATION_KEY, allocation())):
            sheet, (left, top, right, bottom) = self.adapter.region(schema.TABLE_RANGE_NAMES[key])
            from openpyxl.utils import get_column_letter
            old = f'{get_column_letter(left)}{top}:{get_column_letter(right)}{bottom}'
            sheet.move_range(old, rows=4, cols=2)
            sheet.tables[schema.TABLE_NAMES[key]].ref = f'{get_column_letter(left + 2)}{top + 4}:{get_column_letter(right + 2)}{bottom + 4}'
            put_records(self.adapter, key, (row,))
        opening, instructions = coupon_proceeds_from_workbook(self.adapter,
            dict(mode='CLO_BASELINE', scenario_enabled=False, optimizer_enabled=False, candidate_search_enabled=False))
        self.assertEqual((opening[0].amount, instructions[0].principal_amount), (D('1.47'), D('1.47')))
        sheet, (left, top, right, bottom) = self.adapter.region(schema.TABLE_RANGE_NAMES[BALANCE_KEY])
        second = balance()
        second['loan_id'] = 'OTHER'
        for offset, field in enumerate(schema.TABLE_COLUMNS[BALANCE_KEY]):
            sheet.cell(bottom + 1, left + offset, second[field])
        sheet.tables[schema.TABLE_NAMES[BALANCE_KEY]].ref = f'{get_column_letter(left)}{top}:{get_column_letter(right)}{bottom + 1}'
        self.assertEqual(len(self.adapter.table_records(schema.TABLE_RANGE_NAMES[BALANCE_KEY], schema.TABLE_NAMES[BALANCE_KEY])), 2)

    def test_formula_input_is_rejected_instead_of_using_a_cached_amount(self):
        row = balance()
        row['amount'] = '=1.47'
        put_records(self.adapter, BALANCE_KEY, (row,))
        put_records(self.adapter, ALLOCATION_KEY, (allocation(),))
        with self.assertRaises(InputValidationError):
            coupon_proceeds_from_workbook(self.adapter,
                dict(mode='CLO_BASELINE', scenario_enabled=False, optimizer_enabled=False, candidate_search_enabled=False))

    def test_partial_named_interface_does_not_invent_missing_metadata(self):
        del self.book.defined_names[schema.TABLE_RANGE_NAMES[BALANCE_KEY]]
        with self.assertRaisesRegex(InputValidationError, 'partial'):
            ensure_pilot_interface(self.adapter)


class CouponProceedsWorkbookTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.template = INPUT_TEMPLATE.read_bytes()

    def setUp(self):
        self.book = load_workbook(BytesIO(self.template))
        self.addCleanup(self.book.close)
        self.adapter = NamedWorkbook(self.book)
        ensure_pilot_interface(self.adapter)
        assets = self.rows('assets')
        asset = dict(assets[0])
        asset.update(loan_id='L', initial_par=100, current_par=100,
            cashflow_projection_start_date=date(2026, 1, 1), par_as_of_date=OPEN,
            maturity_date_unadjusted=PAY, schedule_anchor_day=1, frequency_months=3,
            day_count='ACT/360', business_day_convention='UNADJUSTED', accrual_date_basis='UNADJUSTED',
            fixing_lag_target_business_days=0, coupon_type='FIXED', fixed_rate=.1212,
            rate_index=None, spread_bps=0, index_floor_bps=None, reset_frequency_months=None,
            index_cap_bps=None, all_in_floor_bps=None, all_in_cap_bps=None,
            amortization_type='BULLET', amortization_fraction_initial_par_per_period=0,
            amortization_first_date_unadjusted=None, amortization_periods_remaining=None,
            scheduled_principal_amount=None, amortization_growth=None, balloon_amount=None,
            first_payment_date_unadjusted=None, last_regular_payment_date_unadjusted=None,
            acquired_accrued_interest=0, payment_lag_business_days=0)
        capital = self.rows('capital_stack')
        debt = dict(next(row for row in capital if row['instrument_type'] == 'DEBT'))
        debt.update(class_id='A', nominal_amount=80, issue_price_pct=100, coupon_type='FIXED',
            fixed_rate=.06, rate_index=None, spread_bps=0, index_floor_bps=None,
            oc_minimum=None, ic_minimum=3)
        equity = dict(next(row for row in capital if row['instrument_type'] == 'EQUITY'))
        equity.update(class_id='EQUITY', nominal_amount=20)
        for key in schema.INPUT_TABLE_KEYS:
            if key not in {'assets', 'capital_stack', 'factor_mapping'}:
                put_records(self.adapter, key, ())
        put_records(self.adapter, 'assets', (asset,))
        put_records(self.adapter, 'capital_stack', (debt, equity))
        controls = hand_controls((asset,), (debt, equity), closing_date=OPEN,
                                 first_payment_date=PAY, legal_final_date=PAY)
        controls.update(legacy_purchased_accrued_interest=1.47, legacy_payment_date_convention='Unadjusted',
            clo_accrual_date_basis='UNADJUSTED', legacy_rate_fixing_lag=0, legacy_determination_lag=0)
        write_controls(self.adapter, controls)
        put_records(self.adapter, 'seasoned_positions', ({'scope': 'ASSET', 'loan_id': 'L',
            'opening_accrued_interest': 1.55, 'entitlement_policy': 'FULL_CURRENT_PERIOD',
            'source': 'Original fixed coupon and confirmed ownership'},))

    def rows(self, key):
        return self.adapter.table_records(schema.TABLE_RANGE_NAMES[key], schema.TABLE_NAMES[key])

    def activate(self, *, permission=False):
        put_records(self.adapter, BALANCE_KEY, (balance(),))
        put_records(self.adapter, ALLOCATION_KEY, (allocation(original_principal_permission=permission),))

    def test_hand_receipt_split_preserves_raw_cash_par_and_funding(self):
        baseline = execute_model_workbook(self.adapter)
        self.activate()
        classified = execute_model_workbook(self.adapter)
        raw = classified.cashflows.cashflows[0]
        audit = self.rows(AUDIT_KEY)[0]
        self.assertEqual((raw.cash_interest, raw.principal_repayment, raw.total_cash),
                         (D('3.03'), D('100.00'), D('103.03')))
        # Excel numeric transport uses float; re-read its decimal text just as
        # the production parser does, without constructing Decimal(float).
        self.assertEqual(tuple(D(str(audit[key])) for key in
            ('raw_coupon_cash', 'principal_accrued_restored', 'interest_proceeds')),
                         (D('3.03'), D('1.47'), D('1.56')))
        self.assertEqual(D(str(audit['principal_proceeds'])), D('101.47'))
        self.assertEqual(audit['remaining_principal_accrued'], D('0.00'))
        self.assertEqual(classified.cashflows.funding, baseline.cashflows.funding)
        self.assertEqual(classified.clo.periods[0].closing_collateral_par, baseline.clo.periods[0].closing_collateral_par)
        self.assertEqual(classified.clo.total_equity_distributions, baseline.clo.total_equity_distributions)
        self.assertEqual(audit['original_principal_permission'], D('0.00'))

    def test_coverage_uses_classified_eligible_interest_not_raw_coupon(self):
        self.activate()
        result = execute_model_workbook(self.adapter)
        gate = next(row for row in result.clo.coverage_tests if row.class_id == 'A' and row.stage == 'GATE')
        self.assertEqual(gate.ic_numerator, D('1.56'))
        self.assertEqual(gate.ic_denominator, D('.59'))
        self.assertEqual(gate.ic_status.value, 'FAIL')

    def test_original_permission_is_explicit_money_in_output(self):
        self.activate(permission=True)
        execute_model_workbook(self.adapter)
        self.assertEqual(D(str(self.rows(AUDIT_KEY)[0]['original_principal_permission'])), D('1.47'))

    def test_explicit_early_prepayment_routes_received_coupon_once(self):
        self.activate()
        prepay = date(2026, 3, 16)
        put_records(self.adapter, 'credit_events', ({'loan_id': 'L', 'event_type': 'PREPAYMENT', 'event_date': prepay},))
        put_records(self.adapter, ALLOCATION_KEY, (allocation(payment_date=prepay, collection_source='PREPAYMENT'),))
        result = execute_model_workbook(self.adapter)
        audit, = result.clo.coupon_proceeds_audit
        # Original Jan1-Mar16 is 74 ACT/360 days: 2.491333... posts once.
        self.assertEqual((audit.raw_coupon_cash, audit.interest_proceeds, audit.principal_proceeds),
                         (D('2.49'), D('1.02'), D('101.47')))
        self.assertEqual(audit.collection_source.value, 'PREPAYMENT')
        self.assertEqual(audit.payment_date, prepay)
        self.assertEqual(sum(row.principal_collection for row in result.credit_projections[0].collections), D(100))

    def test_existing_opening_uses_remaining_entitlement_without_new_purchase_cost(self):
        from trident.adapters.clo_opening_records import ACCOUNT_FIELDS, FEE_FIELDS
        legal = date(2026, 5, 16)
        for key, value in (('legacy_closing_date', date(2025, 11, 16)),
                ('legacy_first_note_payment_date', OPEN), ('legacy_maturity_date', legal),
                ('legacy_purchased_accrued_interest', 0)):
            self.adapter.write_scalar(schema.SCALAR_NAMES[key], value)
        put_records(self.adapter, 'clo_opening', ({'as_of_date': OPEN, 'timing': 'POST_DISTRIBUTION',
            'forward_equity_value': 20, 'equity_value_source': 'Verified current equity bid',
            'initial_collateral_par': 100, 'use_ledger_snapshot': False, 'source': 'Trustee distribution snapshot'},))
        put_records(self.adapter, 'clo_opening_accounts', tuple({'account': key, 'balance': 0,
            'source': 'Trustee distribution snapshot'} for key in ACCOUNT_FIELDS))
        put_records(self.adapter, 'clo_opening_claims', ({'claim_type': 'NOTE_COUPON', 'class_id': 'A',
            'amount': 0, 'source': 'Trustee distribution snapshot'}, *({'claim_type': key,
            'amount': 0, 'source': 'Trustee distribution snapshot'} for key in FEE_FIELDS)))
        self.activate()
        result = execute_model_workbook(self.adapter)
        self.assertIsNone(result.cashflows.funding)
        self.assertEqual(result.clo.periods[0].period_number, 2)
        audit, = result.clo.coupon_proceeds_audit
        self.assertEqual((audit.raw_coupon_cash, audit.principal_accrued_restored, audit.interest_proceeds),
                         (D('3.03'), D('1.47'), D('1.56')))
        self.assertEqual(result.equity_cashflows[0].amount, D(-20))

    def test_receipt_audit_and_independent_reconciliation_namespace_are_distinct(self):
        self.activate()
        execute_model_workbook(self.adapter)
        entries = self.rows('reconciliation_catalog')
        key = ('PROCEEDS_ALLOCATION', 'RESTORE_L', 'principal_accrued_restored', 'RECEIPT')
        entry = next(row for row in entries if (row['entity_type'], row['entity_id'], row['metric'], row['stage']) == key)
        self.assertEqual((D(str(entry['value'])), entry['unit']), (D('1.47'), 'EUR'))
        put_records(self.adapter, 'benchmarks', ({'observation_date': PAY, 'entity_type': key[0],
            'entity_id': key[1], 'metric': key[2], 'stage': key[3], 'expected': 1.47,
            'tolerance': 0, 'unit': 'EUR', 'source': 'Independent settlement hand answer', 'reference_id': 'HAND_RESTORE'},))
        execute_model_workbook(self.adapter)
        self.assertEqual(self.rows('reconciliation_results')[0]['status'], 'MATCH')

    def test_stale_fingerprint_includes_balance_evidence_and_receipt_allocation(self):
        before = input_fingerprint(self.adapter)
        self.activate()
        active = input_fingerprint(self.adapter)
        self.assertNotEqual(before, active)
        row = balance()
        row['source'] = 'Different settlement evidence'
        put_records(self.adapter, BALANCE_KEY, (row,))
        self.assertNotEqual(input_fingerprint(self.adapter), active)

    def test_incompatible_mode_and_each_redesign_switch_fail_before_projection(self):
        self.activate()
        for key, value in (('mode', 'CASHFLOW_ONLY'), ('scenario_enabled', True),
                           ('optimizer_enabled', True), ('candidate_search_enabled', True)):
            old = self.adapter.scalar(schema.SCALAR_NAMES[key])
            self.adapter.write_scalar(schema.SCALAR_NAMES[key], value)
            with self.subTest(key=key), self.assertRaisesRegex(InputValidationError, 'Proceeds allocations require'):
                read_model_workbook_inputs(self.adapter)
            self.adapter.write_scalar(schema.SCALAR_NAMES[key], old)

    def test_custom_layout_skip_is_visible_as_info_without_changing_financial_status(self):
        if 'Expense Inputs' in self.book.sheetnames:
            # Exercise an independently ungrouped user layout even when the
            # durable fixture already ships with canonical horizontal bands.
            from test_workbook_presentation import registered_table
            sheet = self.book['Expense Inputs']
            del sheet.tables[schema.TABLE_NAMES['recurring_expenses']]
            for merged in tuple(sheet.merged_cells.ranges):
                if merged.min_col > len(schema.TABLE_COLUMNS['closing_costs']):
                    sheet.unmerge_cells(str(merged))
            for cell in tuple(sheet._cells.values()):
                if cell.column > len(schema.TABLE_COLUMNS['closing_costs']):
                    cell.value = None
            sheet.title = 'Closing Costs'
            registered_table(self.book, 'recurring_expenses', 'Recurring Expenses')
        self.book['Closing Costs']['A12'] = 'User expense comparison'
        self.activate()
        result = execute_model_workbook(self.adapter)
        finding = next(row for row in self.rows('readiness_findings') if row['code'] == 'UI_LAYOUT_RETAINED')
        self.assertEqual((finding['severity'], finding['entity_id']), ('INFO', 'Expense Inputs'))
        self.assertIn('user content', finding['message'])
        sheet, (left, top, _, bottom) = self.adapter.region(schema.TABLE_RANGE_NAMES['readiness_findings'])
        self.assertTrue(all(sheet.cell(row, left + 4).alignment.horizontal == 'center'
                            and sheet.cell(row, left + 4).alignment.wrap_text
                            for row in range(top + 1, bottom + 1)))
        self.assertEqual(self.book['Closing Costs']['A12'].value, 'User expense comparison')
        self.assertEqual(self.adapter.scalar(schema.SCALAR_NAMES['result_clo_status']), result.clo.status.value)

    def test_claim_is_not_inferred_from_financed_purchase_cost_or_account(self):
        request = read_model_workbook_inputs(self.adapter).request
        self.assertEqual(request.principal_accrued_balances, ())
        self.assertEqual(request.coupon_proceeds_allocations, ())
        self.assertEqual(request.cashflow_request.purchases[0].accrued_interest, D('1.47'))

    def test_custom_three_dimensional_reference_keeps_order_with_visible_navigation_info(self):
        notes = self.book.create_sheet('User Notes')
        notes['A1'] = "=SUM('Seasoned Inputs:Proceeds Inputs'!A6)"
        self.book.move_sheet(notes, offset=-len(self.book.sheetnames) + 1)
        before = tuple(self.book.sheetnames)
        result = execute_model_workbook(self.adapter)
        self.assertEqual(tuple(self.book.sheetnames), before)
        finding = next(row for row in self.rows('readiness_findings')
                       if row['code'] == 'UI_LAYOUT_RETAINED' and row['entity_id'] == 'WORKBOOK_TAB_ORDER')
        self.assertEqual(finding['severity'], 'INFO')
        self.assertIn('3D sheet interval', finding['message'])
        self.assertEqual(self.adapter.scalar(schema.SCALAR_NAMES['result_clo_status']), result.clo.status.value)

    def test_unknown_loan_asof_and_over_owned_claim_are_rejected(self):
        self.activate()
        for row, instruction in (({**balance(), 'loan_id': 'UNKNOWN'}, allocation(loan_id='UNKNOWN')),
                ({**balance(), 'as_of_date': date(2026, 2, 17)}, allocation()),
                ({**balance(), 'amount': '1.56'}, allocation(principal_amount='1.56'))):
            put_records(self.adapter, BALANCE_KEY, (row,))
            put_records(self.adapter, ALLOCATION_KEY, (instruction,))
            with self.subTest(row=row), self.assertRaises(InputValidationError):
                execute_model_workbook(self.adapter)

    def test_ambiguous_wrong_date_and_wrong_cash_source_do_not_create_receipts(self):
        self.activate()
        for row in (allocation(payment_date=date(2026, 3, 31)), allocation(collection_source='PREPAYMENT')):
            put_records(self.adapter, ALLOCATION_KEY, (row,))
            with self.subTest(row=row), self.assertRaises(InputValidationError):
                execute_model_workbook(self.adapter)

    def test_saved_failure_keeps_existing_file_and_fresh_preflight_is_readonly(self):
        self.activate()
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / 'proceeds.xlsx'
            self.book.save(path)
            run_workbook(path)
            before = path.read_bytes()
            self.assertEqual(check_model_workbook(path)['saved_results'], 'CURRENT')
            self.assertEqual(path.read_bytes(), before)
            book = load_workbook(path)
            try:
                put_records(NamedWorkbook(book), ALLOCATION_KEY, (allocation(legal_reference='Corrected governing clause'),))
                book.save(path)
            finally:
                book.close()
            stale = path.read_bytes()
            self.assertEqual(check_model_workbook(path)['saved_results'], 'STALE_OR_NOT_RUN')
            self.assertEqual(path.read_bytes(), stale)
            book = load_workbook(path)
            try:
                put_records(NamedWorkbook(book), ALLOCATION_KEY, (allocation(payment_date=date(2026, 3, 31)),))
                book.save(path)
            finally:
                book.close()
            invalid = path.read_bytes()
            with self.assertRaises(InputValidationError):
                run_workbook(path)
            self.assertEqual(path.read_bytes(), invalid)


class CouponProceedsCatalogTests(unittest.TestCase):
    def test_receipt_count_and_original_permission_use_distinct_units(self):
        row = dict(allocation_id='A', loan_id='A', payment_date=PAY,
            raw_coupon_cash=D('3.03'), raw_principal_cash=D(100), principal_accrued_restored=D('1.47'),
            interest_proceeds=D('1.56'), principal_proceeds=D('101.47'), remaining_principal_accrued=D(0),
            original_principal_permission=D('1.47'), receipt_rows=2)
        tables = {key: () for key in ('asset_cashflows', 'tranche_cashflows', 'coverage_tests',
                                     'clo_periods', 'portfolio_metrics')}
        tables[AUDIT_KEY] = (row,)
        observed, catalog = observed_catalog(SimpleNamespace(cashflows=SimpleNamespace(projection_start_date=OPEN)), tables, {})
        amount = observed[ReconciliationKey(PAY, 'PROCEEDS_ALLOCATION', 'A', 'original_principal_permission', 'RECEIPT')]
        count = observed[ReconciliationKey(PAY, 'PROCEEDS_ALLOCATION', 'A', 'receipt_rows', 'RECEIPT')]
        self.assertEqual((amount.value, amount.unit, count.value, count.unit), (D('1.47'), 'EUR', D(2), 'COUNT'))
        self.assertEqual(len(catalog), 8)


if __name__ == '__main__':
    unittest.main()
