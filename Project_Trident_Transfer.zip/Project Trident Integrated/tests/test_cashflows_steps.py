"""Independent dated rate-level answers, entitlement boundaries and replay.

All cash expectations are hand calculations on 100 face. The base fixture
uses unadjusted 30E/360 dates so neither calendar nor curve interpolation can
hide an erroneous step policy, extra fixing or repeated monetary rounding.
"""

from dataclasses import replace
from datetime import date, datetime
from decimal import Decimal, Inexact, localcontext
import unittest

from trident.cashflows.coupons import CouponProjector
from trident.cashflows.engine import ContractualCashflowEngine
from trident.conventions.calendar import BusinessDayConvention
from trident.conventions.day_count import DayCount
from trident.conventions.schedule import AccrualDateBasis
from trident.credit import CreditEventCashflowEngine, DefaultEvent, PrepaymentEvent
from trident.credit.overlay import OriginalPoolOverlay
from trident.domain.models import AmortizationType, CouponStep, CouponStepPolicy, CouponType, LoanPosition
from trident.market import FlatRateProvider
from test_cashflows_principal import terms_for, RecordingRates

D = Decimal
JAN, FEB, MID, APR, JUL = (date(2026, 1, 1), date(2026, 2, 1), date(2026, 2, 15),
                          date(2026, 4, 1), date(2026, 7, 1))


def fixed(**changes):
    terms = terms_for(**{'fixed_rate': D('.12'), 'coupon_steps': (CouponStep(MID, fixed_rate=D('.24')),), **changes})
    return LoanPosition(terms, terms.start_date, D(100))


def floating(**changes):
    values = dict(coupon_type=CouponType.FLOATING, fixed_rate=None, rate_index='EURIBOR_3M',
                  spread_bps=D(300), coupon_steps=(CouponStep(MID, spread_bps=D(400)),))
    values.update(changes)
    terms = terms_for(**values)
    return LoanPosition(terms, terms.start_date, D(100))


class CouponStepTests(unittest.TestCase):
    def rows(self, loan):
        return ContractualCashflowEngine(FlatRateProvider({'EURIBOR_3M': D('.01'),
            'EURIBOR_1M': D('.01'), 'EURIBOR_6M': D('.01')})).generate(loan)

    def test_actual_fixed_level_splits_period(self):
        row = self.rows(fixed())[0]
        self.assertEqual(row.cash_interest, D('4.53'))  # 100*(.12*44/360+.24*46/360)
        self.assertEqual([s.all_in_rate for s in row.coupon_segments], [D('.12'), D('.24')])
        self.assertEqual([s.accrual_start for s in row.coupon_segments], [JAN, MID])

    def test_fixed_payment_start_defers_midperiod_level(self):
        loan = fixed(coupon_step_policy=CouponStepPolicy.PAYMENT_START)
        self.assertEqual([r.cash_interest for r in self.rows(loan)], [D(3), D(6), D(6)])
        timeline = CouponProjector.for_terms(loan.terms)
        self.assertEqual(timeline.active_fixed_rate(MID), D('.12'))
        self.assertEqual(timeline.active_fixed_rate(APR), D('.24'))

    def test_floating_actual_margin_reuses_original_reference(self):
        provider = RecordingRates({JAN: D('.01')})
        row = ContractualCashflowEngine(provider).generate(floating(maturity_date=APR))[0]
        self.assertEqual(row.cash_interest, D('1.13'))  # 100*(.04*44/360+.05*46/360)
        self.assertEqual(provider.calls, [JAN])
        self.assertEqual([s.spread_bps for s in row.coupon_segments], [D(300), D(400)])
        self.assertEqual([s.reset_date for s in row.coupon_segments], [JAN, JAN])
        self.assertEqual(row.spread_bps, D('351.1111111111111111111111111111111'))

    def test_monthly_reset_defers_margin_until_march(self):
        loan = floating(reset_frequency_months=1, rate_index='EURIBOR_1M', maturity_date=APR,
                        coupon_step_policy=CouponStepPolicy.RESET_START)
        self.assertEqual(self.rows(loan)[0].cash_interest, D('1.08'))  # (4%+4%+5%)/12*100
        timeline = CouponProjector.for_terms(loan.terms)
        self.assertEqual(timeline.active_spread_bps(MID), D(300))
        self.assertEqual(timeline.active_spread_bps(date(2026, 3, 1)), D(400))

    def test_reset_spans_payments_and_latest_deferred_level_wins(self):
        loan = floating(reset_frequency_months=6, rate_index='EURIBOR_6M',
            coupon_step_policy=CouponStepPolicy.RESET_START,
            coupon_steps=(CouponStep(MID, spread_bps=D(500)), CouponStep(date(2026, 3, 15), spread_bps=D(400))))
        self.assertEqual([r.cash_interest for r in self.rows(loan)], [D(1), D(1), D('1.25')])
        timeline = CouponProjector.for_terms(loan.terms)
        self.assertEqual(timeline.active_spread_bps(APR), D(300))
        self.assertEqual(timeline.active_spread_bps(JUL), D(400))

    def test_reset_and_step_same_date_make_one_boundary(self):
        loan = floating(reset_frequency_months=1, rate_index='EURIBOR_1M', maturity_date=APR,
                        coupon_steps=(CouponStep(FEB, spread_bps=D(400)),))
        row = self.rows(loan)[0]
        self.assertEqual(len(row.coupon_segments), 3)
        self.assertEqual(row.cash_interest, D('1.17'))

    def test_cap_applied_after_each_active_margin(self):
        row = self.rows(floating(maturity_date=APR, all_in_cap=D('.045')))[0]
        self.assertEqual(row.cash_interest, D('1.06'))  # 100*(.04*44+.045*46)/360
        self.assertEqual(row.coupon_segments[1].spread_bps, D(400))  # WAS is raw margin.

    def test_step_date_is_inclusive_and_prepayment_date_exclusive(self):
        provider = FlatRateProvider({'EURIBOR_3M': D('.01')})
        loan = floating(maturity_date=APR)
        engine = CreditEventCashflowEngine(provider)
        self.assertEqual(engine.generate(loan, PrepaymentEvent(loan.terms.loan_id, MID)).total_cash_interest, D('.49'))
        self.assertEqual(engine.generate(loan, PrepaymentEvent(loan.terms.loan_id, date(2026, 2, 16))).total_cash_interest, D('.50'))

    def test_zero_and_negative_are_absolute_not_increments(self):
        loan = fixed(coupon_steps=(CouponStep(FEB, fixed_rate=D(0)),
                                   CouponStep(date(2026, 3, 1), fixed_rate=D('-.12'))), maturity_date=APR)
        row = self.rows(loan)[0]
        self.assertEqual(row.cash_interest, D(0))  # Jan +1, Feb zero, March -1.
        self.assertEqual([s.all_in_rate for s in row.coupon_segments], [D('.12'), D(0), D('-.12')])

    def test_weekend_effective_date_not_automatically_moved(self):
        # Feb 15, 2026 is Sunday; it remains the actual contractual effective date.
        self.assertEqual(self.rows(floating())[0].coupon_segments[1].accrual_start, MID)

    def test_noop_level_has_no_new_segment_or_rounding(self):
        loan = fixed(coupon_steps=(CouponStep(MID, fixed_rate=D('.12')),))
        baseline = replace(loan, terms=replace(loan.terms, coupon_steps=()))
        self.assertEqual(self.rows(loan), self.rows(baseline))

    def test_one_final_posting_under_hostile_decimal_context(self):
        loan = fixed(maturity_date=APR, fixed_rate=D('.0006'),
            coupon_steps=(CouponStep(FEB, fixed_rate=D('.0007')), CouponStep(date(2026, 3, 1), fixed_rate=D('.0008'))))
        # .005+.005833...+.006666...=.0175 -> .02, not three .01 postings.
        with localcontext() as context:
            context.prec = 2
            context.traps[Inexact] = True
            row = self.rows(loan)[0]
        self.assertEqual(row.interest_unrounded, D('.0175'))
        self.assertEqual(row.cash_interest, D('.02'))

    def test_annuity_uses_future_exact_stepped_factors(self):
        loan = fixed(maturity_date=JUL, fixed_rate=D('.12'),
            coupon_steps=(CouponStep(APR, fixed_rate=D('.24')),),
            amortization_type=AmortizationType.ANNUITY, balloon_amount=D(0))
        rows = self.rows(loan)
        self.assertEqual([r.cash_interest for r in rows], [D(3), D(3)])
        self.assertEqual([r.principal_repayment for r in rows], [D(50), D(50)])  # Level payment53.

    def test_credit_replay_rejects_tampered_step_and_summary(self):
        loan = floating(maturity_date=APR)
        rows = self.rows(loan)
        engine = CreditEventCashflowEngine(FlatRateProvider({'EURIBOR_3M': D('.99')}))
        self.assertEqual(engine.apply(loan, rows, None).total_cash_interest, D('1.13'))
        wrong = replace(rows[0].coupon_segments[1], spread_bps=D(999))
        with self.assertRaisesRegex(ValueError, 'segment dates/rate'):
            engine.apply(loan, (replace(rows[0], coupon_segments=(rows[0].coupon_segments[0], wrong)),), None)
        with self.assertRaisesRegex(ValueError, 'margin differs'):
            engine.apply(loan, (replace(rows[0], spread_bps=D(300)),), None)
        with self.assertRaisesRegex(ValueError, 'requires frozen coupon segments'):
            engine.apply(loan, (replace(rows[0], coupon_segments=()),), None)

    def test_default_does_not_collect_unpaid_stepped_coupon(self):
        loan = floating(maturity_date=APR)
        result = CreditEventCashflowEngine(FlatRateProvider({'EURIBOR_3M': D('.01')})).generate(
            loan, DefaultEvent(loan.terms.loan_id, date(2026, 2, 16)))
        self.assertEqual(result.total_cash_interest, D(0))
        self.assertEqual(result.defaulted_exposure, D(100))

    def test_original_overlay_uses_exact_stepped_factor(self):
        loan = floating(maturity_date=APR)
        result = OriginalPoolOverlay(False).project(self.rows(loan), {loan.terms.loan_id: D(100)}, JAN, APR,
            loan_day_counts={loan.terms.loan_id: loan.terms.day_count})
        self.assertEqual(sum(row.cash_interest for row in result.collections), D('1.13'))

    def test_nonadditive_thirty_day_changes_require_boundary_policy(self):
        for basis in (DayCount.THIRTY_360_ISDA, DayCount.THIRTY_U_360_EOM):
            with self.subTest(basis=basis), self.assertRaisesRegex(ValueError, 'additive day count'):
                fixed(day_count=basis)
        # Jan29-Mar1 Bond Basis: 32/360 at12% =>1.07; defer Jan31 change.
        loan = fixed(start_date=date(2026, 1, 29), maturity_date=date(2026, 3, 1),
            day_count=DayCount.THIRTY_360_ISDA, coupon_step_policy=CouponStepPolicy.PAYMENT_START,
            coupon_steps=(CouponStep(date(2026, 1, 31), fixed_rate=D('.24')),))
        self.assertEqual(self.rows(loan)[0].cash_interest, D('1.07'))

    def test_deferred_step_waits_through_initial_holiday_gap(self):
        # TARGET Easter: nominal Apr4 rolls to Apr7. An Apr5 step cannot
        # become effective on Apr5/6 before the first payment/reset boundary.
        for coupon in (CouponType.FIXED, CouponType.FLOATING):
            fields = dict(start_date=date(2026, 4, 4), maturity_date=date(2026, 10, 4),
                business_day_convention=BusinessDayConvention.FOLLOWING,
                accrual_date_basis=AccrualDateBasis.ADJUSTED)
            loan = (fixed(**fields, coupon_step_policy=CouponStepPolicy.PAYMENT_START,
                          coupon_steps=(CouponStep(date(2026, 4, 5), fixed_rate=D('.24')),))
                    if coupon is CouponType.FIXED else floating(**fields,
                          coupon_step_policy=CouponStepPolicy.RESET_START,
                          coupon_steps=(CouponStep(date(2026, 4, 5), spread_bps=D(400)),)))
            timeline = CouponProjector.for_terms(loan.terms)
            active = timeline.active_fixed_rate if coupon is CouponType.FIXED else timeline.active_spread_bps
            base, stepped = (D('.12'), D('.24')) if coupon is CouponType.FIXED else (D(300), D(400))
            self.assertEqual([active(date(2026, 4, day)) for day in (4, 5, 6, 7)], [base, base, base, stepped])

    def test_actual_step_crosses_leap_year_using_each_year_denominator(self):
        loan = fixed(start_date=date(2027, 12, 1), maturity_date=date(2028, 2, 1),
            day_count=DayCount.ACT_ACT_ISDA,
            coupon_steps=(CouponStep(date(2028, 1, 1), fixed_rate=D('.24')),))
        with localcontext() as context:
            context.prec = 2
            context.traps[Inexact] = True
            row = self.rows(loan)[0]
        self.assertEqual(row.cash_interest, D('3.05'))  # 100*(.12*31/365+.24*31/366).

    def test_step_validation_is_strict_about_type_dates_and_scope(self):
        for step in (lambda: CouponStep(MID), lambda: CouponStep(MID, fixed_rate=D(0), spread_bps=D(0)),
                     lambda: CouponStep(MID, fixed_rate=0.12), lambda: CouponStep(datetime(2026, 2, 15), fixed_rate=D('.12'))):
            with self.assertRaises(ValueError):
                step()
        invalid = [dict(coupon_steps=[CouponStep(MID, fixed_rate=D('.24'))]),
            dict(coupon_steps=(CouponStep(JAN, fixed_rate=D('.24')),)),
            dict(coupon_steps=(CouponStep(date(2026, 10, 1), fixed_rate=D('.24')),)),
            dict(coupon_steps=(CouponStep(MID, fixed_rate=D('.24')), CouponStep(MID, fixed_rate=D('.36')))),
            dict(coupon_steps=(CouponStep(MID, fixed_rate=D('.24')), CouponStep(FEB, fixed_rate=D('.36')))),
            dict(coupon_steps=(CouponStep(MID, spread_bps=D(400)),)),
            dict(coupon_step_policy='ACTUAL_DATE'), dict(coupon_step_policy=CouponStepPolicy.RESET_START),
            dict(coupon_steps=(), coupon_step_policy=CouponStepPolicy.PAYMENT_START)]
        for changes in invalid:
            with self.subTest(changes=changes), self.assertRaises(ValueError):
                fixed(**changes)
        with self.assertRaises(ValueError):
            floating(coupon_step_policy=CouponStepPolicy.PAYMENT_START)


if __name__ == '__main__':
    unittest.main()
