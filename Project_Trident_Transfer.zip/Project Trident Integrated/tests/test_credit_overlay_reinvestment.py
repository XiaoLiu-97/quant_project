"""Independent amount, date, entitlement and conservation cases for overlays."""

from dataclasses import replace
from datetime import date, timedelta
from decimal import Context, Decimal, Inexact, localcontext
from fractions import Fraction
import unittest

from trident.clo.reinvestment import ReinvestmentTestGate, SyntheticReinvestmentLedger, SyntheticReinvestmentPolicy
from trident.conventions import DayCount
from trident.credit.models import AssetCashSource
from trident.credit.overlay import DefaultTimingPattern, OriginalPoolOverlay, add_calendar_months, project_fractional_period
from trident.domain.models import InputValidationError, LoanCashflow
from trident.domain.numeric import post_currency
from trident.market.rates import FlatRateProvider
from trident.application.imported_cashflows import (
    CollateralCashflowInputMode, DetailedImportedCashflow, SimplifiedImportedCashflow,
    compile_imported_cashflows,
)


D = Decimal
START = date(2025, 1, 1)


def row(start, end, opening, principal, coupon, *, number=1, loan="L1", payment=None):
    return LoanCashflow(
        loan_id=loan, currency="EUR", period_number=number,
        unadjusted_start=start, unadjusted_end=end, accrual_start=start,
        accrual_end=end, payment_date=payment or end, fixing_date=start,
        opening_balance=D(opening), index_rate=D(0), spread_bps=D(1000),
        all_in_rate=D("0.1"), day_count_fraction=D(1), interest_unrounded=D(coupon),
        cash_interest=D(coupon), principal_repayment=D(principal),
        closing_balance=post_currency(Fraction(D(opening)) - Fraction(D(principal))),
        total_cash=post_currency(Fraction(D(coupon)) + Fraction(D(principal))),
    )


def policy(**values):
    defaults = dict(enabled=True, end_date=date(2035, 1, 1), purchase_price=D(1),
                    bullet_wal_years=D(4), annual_default_rate=D(0), annual_prepayment_rate=D(0),
                    recovery_lag_months=0, spread_bps=D(1000), day_count=DayCount.ACT_365F)
    defaults.update(values)
    return SyntheticReinvestmentPolicy(**defaults)


def ledger(**values):
    return SyntheticReinvestmentLedger(policy(**values), FlatRateProvider({"EURIBOR_3M": D(0), "EURIBOR_1M": D("-0.03"), "EURIBOR_6M": D("0.01")}))


class FractionalPoolTests(unittest.TestCase):
    def test_external_detailed_cash_reference_supports_credit_without_fake_terms(self):
        source = compile_imported_cashflows(
            CollateralCashflowInputMode.DETAILED, START, D(100),
            detailed_rows=(DetailedImportedCashflow("L1", 1, date(2026, 1, 1), D(100), D(10), D(100), D(0), D(110)),),
        )
        result = OriginalPoolOverlay(True, D("0.2"), D(0), D("0.4"), 0).project_external(
            source.collections, source.par_movements, source.loan_opening_par, START, date(2026, 1, 1),
        )
        self.assertEqual(result.total_par_loss, 12)
        self.assertEqual(result.final_performing_par, 0)
        self.assertEqual(sum(r.principal_collection for r in result.collections), 88)
        self.assertEqual(sum(r.cash_interest for r in result.collections), 8)

    def test_external_pik_changes_face_without_manufacturing_cash(self):
        source = compile_imported_cashflows(
            CollateralCashflowInputMode.DETAILED, START, D(100),
            detailed_rows=(
                DetailedImportedCashflow("L1", 1, date(2026, 1, 1), D(100), D(0), D(0), D(110), D(0), D(10)),
                # The frozen principal reference is complete even when this
                # particular projection horizon stops before final repayment.
                DetailedImportedCashflow("L1", 2, date(2027, 1, 1), D(110), D(0), D(110), D(0), D(110)),
            ),
        )
        result = OriginalPoolOverlay(True, D("0.2"), D(0), D(0), 0).project_external(
            source.collections, source.par_movements, source.loan_opening_par, START, date(2026, 1, 1),
        )
        self.assertEqual(result.final_performing_par, 88)
        self.assertEqual(result.total_par_loss, 20)
        self.assertEqual(sum(r.total_cash for r in result.collections), 0)
        pik = next(r for r in result.par_movements if r.source is AssetCashSource.SCHEDULED)
        self.assertEqual(pik.non_cash_par_change, 8)

    def test_external_independent_par_and_cash_reduction_preserved(self):
        source = compile_imported_cashflows(
            CollateralCashflowInputMode.SIMPLIFIED, START, D(100),
            simplified_rows=(SimplifiedImportedCashflow(date(2026, 1, 1), D(10), D(5), performing_par_reduction=D(10)),),
        )
        result = OriginalPoolOverlay(False).project_external(source.collections, source.par_movements, source.loan_opening_par, START, date(2026, 1, 1))
        self.assertEqual(result.final_performing_par, 90)
        self.assertEqual(result.total_par_loss, 0)
        self.assertEqual(sum(r.principal_collection for r in result.collections), 5)
        self.assertEqual(result.par_movements[0].non_cash_par_change, -5)

    def test_default_scheduled_then_cpr_par_bridge(self):
        result = project_fractional_period(
            opening_par=D(100), contractual_opening_par=D(100), contractual_interest=D(10),
            contractual_principal=D(10), default_amount=D(20), prepayment_rate=D("0.5"),
            start_date=START, end_date=START + timedelta(days=365),
        )
        # 100 = default20 + scheduled8 + prepayment36 + survivor36.
        self.assertEqual((result.default_par, result.scheduled_principal, result.prepayment_principal, result.closing_par), (20, 8, 36, 36))
        # Only survivor80 pays its coupon; the unpaid default20 slice is lost.
        # Prepayment takes place at year end and forfeits no surviving coupon.
        self.assertEqual(result.cash_interest, D("8.00"))

    def test_no_prior_default_or_prepayment_slice_reappears(self):
        rows = (
            row(START, date(2026, 1, 1), 100, 0, 10),
            row(date(2026, 1, 1), date(2027, 1, 1), 100, 100, 10, number=2),
        )
        result = OriginalPoolOverlay(True, D("0.2"), D(0), D(0), 0).project(rows, {"L1": D(100)}, START, date(2027, 1, 1))
        scheduled = [r for r in result.collections if r.source is AssetCashSource.SCHEDULED]
        self.assertEqual([r.cash_interest for r in scheduled], [D("8.00"), D("6.40")])
        self.assertEqual([r.principal_collection for r in scheduled], [0, 64])
        self.assertEqual(result.total_par_loss, 36)
        self.assertEqual(result.final_performing_par, 0)
        self.assertEqual(result.final_defaulted_par, 0)

    def test_disabled_overlay_preserves_contractual_cents(self):
        rows = (row(START, date(2026, 1, 1), 100, 100, "10.01"),)
        result = OriginalPoolOverlay(False, D(1), D(1), D(0), 0).project(rows, {"L1": D(100)}, START, date(2026, 1, 1))
        self.assertEqual(result.collections[0].total_cash, D("110.01"))
        self.assertEqual(result.total_par_loss, 0)

    def test_actual_month_lag_is_not_rounded_to_note_frequency(self):
        rows = (row(START, date(2026, 1, 1), 100, 100, 10),)
        result = OriginalPoolOverlay(True, D("0.2"), D(0), D("0.4"), 3).project(rows, {"L1": D(100)}, START, date(2026, 1, 1))
        default = next(r for r in result.par_movements if r.source is AssetCashSource.DEFAULT)
        recovery = next(r for r in result.collections if r.source is AssetCashSource.RECOVERY)
        self.assertEqual(default.event_date, date(2025, 7, 2))
        self.assertEqual(recovery.payment_date, date(2025, 10, 2))
        self.assertEqual(recovery.principal_collection, 8)
        self.assertEqual(result.total_par_loss, 12)
        self.assertEqual(result.final_defaulted_par, 0)

    def test_zero_recovery_and_zero_lag_resolves_claim_without_cash(self):
        result = OriginalPoolOverlay(True, D(1), D(0), D(0), 0).project(
            (row(START, date(2026, 1, 1), 100, 100, 10),), {"L1": D(100)}, START, date(2026, 1, 1),
        )
        self.assertEqual(result.final_defaulted_par, 0)
        self.assertEqual(result.total_par_loss, 100)
        self.assertFalse(any(r.source is AssetCashSource.RECOVERY for r in result.collections))
        self.assertEqual(result.par_movements[0].event_date, result.par_movements[1].event_date)

    def test_pending_recovery_not_silently_received_at_horizon(self):
        result = OriginalPoolOverlay(True, D("0.2"), D(0), D("0.4"), 24).project(
            (row(START, date(2026, 1, 1), 100, 100, 10),), {"L1": D(100)}, START, date(2026, 1, 1),
        )
        self.assertEqual(result.final_defaulted_par, 20)
        self.assertEqual(result.pending_recovery_amount, 8)
        self.assertEqual(result.total_par_loss, 0)

    def test_horizon_inside_unpaid_coupon_records_default_but_no_coupon(self):
        result = OriginalPoolOverlay(True, D(1), D(0), D(0), 0).project(
            (row(START, date(2026, 1, 1), 100, 100, 10),), {"L1": D(100)}, START, date(2025, 4, 1),
        )
        self.assertFalse(result.collections)
        self.assertEqual(result.total_par_loss, 100)
        self.assertEqual(result.final_performing_par, 0)

    def test_all_historical_vectors_preserve_one_fixed_five_year_target(self):
        for pattern in list(DefaultTimingPattern)[1:]:
            with self.subTest(pattern=pattern):
                overlay = OriginalPoolOverlay(True, D("0.1"), D(0), D(0), 0, pattern)
                # 100000*(1-0.9**5)=40951 exactly. No annual rate multipliers.
                self.assertEqual(overlay.fixed_target(D(100000)), D(40951))
                self.assertEqual(overlay.target_through(D(100000), START, date(2030, 1, 1)), D(40951))
                self.assertEqual(overlay.target_through(D(100000), START, date(2040, 1, 1)), D(40951))
        first = OriginalPoolOverlay(True, D("0.1"), D(0), D(0), 0, DefaultTimingPattern.SP_PATTERN_1)
        self.assertEqual(first.target_through(D(100000), START, date(2026, 1, 1)), D("15970.89"))

    def test_vector_origin_uses_anniversary_not_calendar_year(self):
        overlay = OriginalPoolOverlay(True, D("0.1"), D(0), D(0), 0, DefaultTimingPattern.SP_PATTERN_1)
        origin = date(2025, 12, 31)
        self.assertEqual(overlay.target_through(D(100000), origin, date(2026, 12, 31)), D("15970.89"))
        self.assertEqual(overlay.target_through(D(100000), origin, origin), 0)

    def test_vector_capacity_shortfall_after_early_maturity_is_explicit(self):
        overlay = OriginalPoolOverlay(True, D("0.1"), D(0), D(0), 0, DefaultTimingPattern.SP_PATTERN_1)
        result = overlay.project((row(START, date(2026, 1, 1), 100000, 100000, 10000),), {"L1": D(100000)}, START, date(2030, 1, 1))
        self.assertEqual(result.total_par_loss, D("15970.89"))
        self.assertEqual(result.unallocated_default_target, D("24980.11"))
        self.assertEqual(result.total_par_loss + result.unallocated_default_target, 40951)

    def test_multiple_loan_identities_keep_independent_amounts(self):
        rows = (row(START, date(2026, 1, 1), 100, 100, 10), row(START, date(2026, 1, 1), 200, 200, 20, loan="L2"))
        result = OriginalPoolOverlay(True, D("0.2"), D(0), D(0), 0).project(rows, {"L1": D(100), "L2": D(200)}, START, date(2026, 1, 1))
        self.assertEqual([asset.total_par_loss for asset in result.assets], [20, 40])
        self.assertEqual(result.total_par_loss, 60)

    def test_original_overlay_rejects_missing_or_forged_contract_chain(self):
        original = row(START, date(2026, 1, 1), 100, 100, 10)
        for rows, balances in (((original,), {"OTHER": D(100)}), ((replace(original, total_cash=D(111)),), {"L1": D(100)}), ((replace(original, period_number=2),), {"L1": D(100)})):
            with self.subTest(rows=rows):
                with self.assertRaises(InputValidationError):
                    OriginalPoolOverlay().project(rows, balances, START, date(2026, 1, 1))


class SyntheticCohortTests(unittest.TestCase):
    def test_price_discount_creates_par_from_actual_spend(self):
        book = ledger(purchase_price=D("0.99"))
        purchase = book.purchase(START, D(99))
        self.assertEqual(purchase.acquired_par, 100)
        self.assertEqual(purchase.cash_used, 99)
        self.assertEqual(purchase.unused_cash, 0)
        self.assertEqual(book.performing_par, 100)

    def test_premium_par_floor_never_overdraws_cash(self):
        book = ledger(purchase_price=D("1.01"))
        purchase = book.purchase(START, D(100))
        self.assertEqual(purchase.acquired_par, D(99))
        self.assertEqual(purchase.cash_used, D("99.99"))
        self.assertEqual(purchase.unused_cash, D("0.01"))

    def test_no_coupon_before_or_on_purchase_boundary(self):
        book = ledger()
        empty = book.project(START, date(2025, 4, 1), START)
        self.assertEqual(empty.interest_cash, 0)
        book.purchase(date(2025, 4, 1), D(100))
        result = book.project(date(2025, 4, 1), date(2025, 7, 1), date(2025, 4, 1))
        # 100*10%*91/365 = 2.493...; no Jan→April backfilled coupon.
        self.assertEqual(result.interest_cash, D("2.49"))

    def test_independent_term_index_and_reference_floor_before_spread(self):
        book = ledger(reference_curve="EURIBOR 1M", reference_floor=D("0.01"), spread_bps=D(400))
        book.purchase(START, D(100))
        result = book.project(START, date(2026, 1, 1), START)
        self.assertEqual(result.interest_cash, 5)

    def test_default_and_cpr_use_surviving_exposure(self):
        book = ledger(annual_default_rate=D("0.2"), annual_prepayment_rate=D("0.5"), recovery_rate=D("0.4"))
        book.purchase(START, D(100))
        result = book.project(START, date(2026, 1, 1), START)
        self.assertEqual((result.default_par, result.prepayment_principal, result.recovery_cash, result.losses, result.closing_par), (20, 40, 8, 12, 40))
        self.assertEqual(result.interest_cash, 8)
        self.assertEqual(result.principal_cash, 48)
        self.assertEqual(result.defaulted_par, 0)

    def test_synthetic_zero_recovery_workout_does_not_leave_default_claim(self):
        book = ledger(annual_default_rate=D(1), recovery_rate=D(0))
        book.purchase(START, D(100))
        result = book.project(START, date(2026, 1, 1), START)
        self.assertEqual(result.recovery_cash, 0)
        self.assertEqual(result.losses, 100)
        self.assertEqual(book.defaulted_par, 0)
        self.assertEqual(result.interest_cash, 0)

    def test_actual_three_month_recovery_can_arrive_within_same_long_period(self):
        book = ledger(annual_default_rate=D("0.2"), recovery_lag_months=3, recovery_rate=D("0.4"))
        book.purchase(START, D(100))
        result = book.project(START, date(2026, 1, 1), START)
        recovery = next(row for row in result.collections if row.source is AssetCashSource.RECOVERY)
        self.assertEqual(recovery.payment_date, date(2025, 10, 2))
        self.assertEqual(recovery.principal_collection, 8)

    def test_future_recovery_queue_survives_multiple_periods(self):
        book = ledger(annual_default_rate=D(1), recovery_lag_months=24, recovery_rate=D("0.4"))
        book.purchase(START, D(100))
        first = book.project(START, date(2026, 1, 1), START)
        self.assertEqual(first.defaulted_par, 100)
        self.assertEqual(book.pending_recovery_amount, 40)
        book.project(date(2026, 1, 1), date(2027, 1, 1), date(2026, 1, 1))
        final = book.project(date(2027, 1, 1), date(2028, 1, 1), date(2027, 1, 1))
        self.assertEqual((final.recovery_cash, final.losses, final.defaulted_par), (40, 60, 0))

    def test_bullet_maturity_is_actual_date_inside_note_interval(self):
        book = ledger(bullet_wal_years=D("0.25"))
        purchase = book.purchase(START, D(100))
        result = book.project(START, date(2025, 7, 1), START)
        self.assertEqual(purchase.maturity_date, date(2025, 4, 1))
        self.assertEqual(result.scheduled_principal, 100)
        self.assertEqual(result.interest_cash, D("2.47"))
        self.assertEqual(result.collections[0].payment_date, date(2025, 4, 1))

    def test_maturity_months_round_half_up_from_original_anchor(self):
        book = ledger(bullet_wal_years=D("0.125"))
        self.assertEqual(book.policy.maturity_months, 2)
        purchase = book.purchase(date(2025, 1, 31), D(100))
        self.assertEqual(purchase.maturity_date, date(2025, 3, 31))
        self.assertEqual(add_calendar_months(date(2024, 1, 31), 1), date(2024, 2, 29))

    def test_purchase_and_default_par_day_integral(self):
        book = ledger(annual_default_rate=D(1), recovery_rate=D(0))
        book.purchase(START, D(100))
        book.project(START, date(2026, 1, 1), START)
        self.assertEqual(book.par_days(START, date(2026, 1, 1)), Fraction(18200))
        self.assertEqual(book.balance_at(date(2025, 7, 1)), 100)
        self.assertEqual(book.balance_at(date(2025, 7, 2)), 0)

    def test_long_dated_par_and_terminal_claim_sale_cancel_future_rights(self):
        book = ledger(annual_default_rate=D("0.2"), recovery_lag_months=24, recovery_rate=D("0.4"))
        book.purchase(START, D(100))
        book.project(START, date(2026, 1, 1), START)
        self.assertEqual(book.long_dated_par(date(2027, 1, 1)), 80)
        self.assertEqual(book.long_dated_par(date(2027, 1, 1), date=date(2025, 1, 2)), 100)
        disposition = book.dispose()
        self.assertEqual((disposition.performing_par, disposition.defaulted_par, disposition.cancelled_pending_recovery), (80, 20, 8))
        self.assertEqual(book.performing_par, 0)
        self.assertEqual(book.defaulted_par, 0)
        self.assertEqual(book.pending_recovery_amount, 0)
        later = book.project(date(2026, 1, 1), date(2028, 1, 1), date(2026, 1, 1))
        self.assertEqual(later.principal_cash, 0)

    def test_gate_end_inclusive_final_excluded_and_override(self):
        selected = policy(end_date=date(2025, 4, 1))
        self.assertTrue(selected.eligible(date(2025, 4, 1), False, False))
        self.assertFalse(selected.eligible(date(2025, 4, 2), False, False))
        self.assertFalse(selected.eligible(date(2025, 4, 1), True, False))
        self.assertFalse(selected.eligible(date(2025, 4, 1), False, True))
        self.assertTrue(replace(selected, test_gate=ReinvestmentTestGate.ALWAYS_REINVEST).eligible(date(2025, 4, 1), False, True))

    def test_owned_numeric_domain_survives_low_precision_caller(self):
        with localcontext(Context(prec=2)) as ctx:
            ctx.traps[Inexact] = True
            book = ledger(purchase_price=D("0.99"), annual_default_rate=D("0.2"), annual_prepayment_rate=D("0.5"), recovery_rate=D("0.4"))
            purchase = book.purchase(START, D(99))
            result = book.project(START, date(2026, 1, 1), START)
            self.assertEqual(purchase.acquired_par, 100)
            self.assertEqual(result.closing_par, 40)

    def test_invalid_policies_and_nonchronological_calls_rejected(self):
        for values in (dict(enabled=True, end_date=None), dict(purchase_price=D(0)), dict(bullet_wal_years=D("0.01")), dict(annual_default_rate=D("1.01")), dict(recovery_lag_months=-1), dict(recycle_reinvestment_principal="Yes")):
            with self.subTest(values=values):
                with self.assertRaises(InputValidationError):
                    policy(**values)
        book = ledger()
        book.project(START, date(2025, 4, 1), START)
        with self.assertRaises(InputValidationError):
            book.project(date(2025, 4, 2), date(2025, 7, 1), date(2025, 4, 2))
        with self.assertRaises(InputValidationError):
            book.purchase(START, D(100))
        seeded = ledger()
        seeded.purchase(START, D(100))
        with self.assertRaises(InputValidationError):
            seeded.purchase(date(2025, 2, 1), D(100))
        with self.assertRaises(InputValidationError):
            seeded.project(date(2025, 2, 1), date(2025, 4, 1), date(2025, 2, 1))


if __name__ == "__main__":
    unittest.main()
