"""Independent hand examples and contract boundaries for principal policies."""

import unittest
from datetime import date, datetime
from decimal import Decimal, Inexact, ROUND_DOWN, localcontext
from fractions import Fraction

from trident.cashflows.engine import ContractualCashflowEngine
from trident.cashflows.principal import projected_level_payment
from trident.conventions.calendar import BusinessDayConvention
from trident.conventions.day_count import DayCount
from trident.conventions.schedule import AccrualDateBasis, StubConvention
from trident.domain.models import (
    AmortizationType, CouponType, LoanPosition, LoanTerms, PrincipalScheduleEntry,
)
from trident.market.rates import FlatRateProvider

D = Decimal


def terms_for(**changes: object) -> LoanTerms:
    """Nominal 30E/360 quarters make each hand factor exactly one fourth."""
    fields = dict(
        loan_id="CASH_PAY_BULLET", currency="EUR", start_date=date(2026, 1, 1),
        maturity_date=date(2026, 10, 1), reference_principal=D(100),
        coupon_type=CouponType.FIXED, fixed_rate=D("0.4"),
        day_count=DayCount.THIRTY_E_360,
        business_day_convention=BusinessDayConvention.UNADJUSTED,
        accrual_date_basis=AccrualDateBasis.UNADJUSTED,
        fixing_lag_business_days=0,
    )
    fields.update(changes)
    return LoanTerms(**fields)


class RecordingRates:
    """One known-answer rate per nominal fixing; unknown dates fail loudly."""

    def __init__(self, values: dict[date, Decimal]) -> None:
        self.values = values
        self.calls: list[date] = []

    def rate(self, index: str, fixing_date: date) -> Decimal:
        self.calls.append(fixing_date)
        return self.values[fixing_date]


class PrincipalPolicyTests(unittest.TestCase):
    def setUp(self) -> None:
        self.engine = ContractualCashflowEngine(FlatRateProvider({"EURIBOR_3M": D("0.4")}))

    def rows(self, **changes: object):
        terms = terms_for(**changes)
        return self.engine.generate(LoanPosition(terms, terms.start_date, D(100)))

    def test_explicit_linear_amount_and_final_remaining_payoff(self) -> None:
        rows = self.rows(amortization_type=AmortizationType.LINEAR_AMOUNT, scheduled_principal_amount=D(30))
        self.assertEqual([row.principal_repayment for row in rows], [D(30), D(30), D(40)])
        self.assertEqual([row.cash_interest for row in rows], [D(10), D(7), D(4)])

    def test_reference_is_not_inferred_from_held_par(self) -> None:
        terms = terms_for(reference_principal=D(1000), amortization_type=AmortizationType.LINEAR_INITIAL_PAR,
                          amortization_fraction=D("0.02"))
        rows = self.engine.generate(LoanPosition(terms, terms.start_date, D(100)))
        self.assertEqual([row.principal_repayment for row in rows], [D(20), D(20), D(60)])

    def test_growth_is_principal_growth_per_eligible_installment(self) -> None:
        rows = self.rows(amortization_type=AmortizationType.ACCELERATED,
                         scheduled_principal_amount=D(10), amortization_growth=D(1))
        self.assertEqual([row.principal_repayment for row in rows], [D(10), D(20), D(70)])
        self.assertEqual([row.cash_interest for row in rows], [D(10), D(9), D(7)])

    def test_accelerated_growth_starts_after_grace(self) -> None:
        rows = self.rows(amortization_type=AmortizationType.ACCELERATED, scheduled_principal_amount=D(10),
                         amortization_growth=D(1), amortization_start_date=date(2026, 7, 1))
        self.assertEqual([row.principal_repayment for row in rows], [D(0), D(10), D(90)])

    def test_explicit_zero_growth_matches_linear_amount(self) -> None:
        accelerated = self.rows(amortization_type=AmortizationType.ACCELERATED,
                                scheduled_principal_amount=D(40), amortization_growth=D(0))
        linear = self.rows(amortization_type=AmortizationType.LINEAR_AMOUNT, scheduled_principal_amount=D(40))
        self.assertEqual(accelerated, linear)

    def test_balloon_floor_caps_nonfinal_principal(self) -> None:
        rows = self.rows(amortization_type=AmortizationType.LINEAR_AMOUNT,
                         scheduled_principal_amount=D(60), balloon_amount=D(20))
        self.assertEqual([row.principal_repayment for row in rows], [D(60), D(20), D(20)])

    def test_zero_balloon_is_explicit_not_a_missing_value(self) -> None:
        rows = self.rows(amortization_type=AmortizationType.LINEAR_AMOUNT,
                         scheduled_principal_amount=D(40), balloon_amount=D(0))
        self.assertEqual([row.principal_repayment for row in rows], [D(40), D(40), D(20)])

    def test_fixed_schedule_balloon_is_floor_and_maturity_sweeps_full_residual(self) -> None:
        rows = self.rows(amortization_type=AmortizationType.LINEAR_AMOUNT,
            scheduled_principal_amount=D(10), balloon_amount=D(20))
        self.assertEqual([row.principal_repayment for row in rows], [D(10), D(10), D(80)])
        rows = self.rows(amortization_type=AmortizationType.LINEAR_AMOUNT,
            scheduled_principal_amount=D("33.33"), balloon_amount=D(0))
        self.assertEqual([row.principal_repayment for row in rows], [D("33.33"), D("33.33"), D("33.34")])

    def test_cent_tie_in_accelerating_principal(self) -> None:
        rows = self.rows(amortization_type=AmortizationType.ACCELERATED,
                         scheduled_principal_amount=D("0.01"), amortization_growth=D("0.5"))
        self.assertEqual([row.principal_repayment for row in rows], [D("0.01"), D("0.02"), D("99.97")])

    def test_huge_growth_saturates_at_possible_principal(self) -> None:
        rows = self.rows(amortization_type=AmortizationType.ACCELERATED,
                         scheduled_principal_amount=D(1), amortization_growth=D("1e1000"))
        self.assertEqual([row.principal_repayment for row in rows], [D(1), D(99)])

    def test_bespoke_skips_unlisted_boundaries(self) -> None:
        rows = self.rows(amortization_type=AmortizationType.BESPOKE, principal_schedule=(
            PrincipalScheduleEntry(date(2026, 4, 1), D(10)),
            PrincipalScheduleEntry(date(2026, 10, 1), D(90)),
        ))
        self.assertEqual([row.principal_repayment for row in rows], [D(10), D(0), D(90)])
        self.assertEqual([row.cash_interest for row in rows], [D(10), D(9), D(9)])

    def test_bespoke_nominal_boundary_survives_business_day_adjustment(self) -> None:
        rows = self.rows(maturity_date=date(2026, 8, 1), business_day_convention=BusinessDayConvention.FOLLOWING,
                         amortization_type=AmortizationType.BESPOKE, principal_schedule=(
                             PrincipalScheduleEntry(date(2026, 8, 1), D(100)),
                         ))
        self.assertEqual(rows[-1].unadjusted_end, date(2026, 8, 1))
        self.assertEqual(rows[-1].payment_date, date(2026, 8, 3))

    def test_bespoke_total_uses_held_balance_and_cannot_sweep_unknown_residual(self) -> None:
        terms = terms_for(amortization_type=AmortizationType.BESPOKE, principal_schedule=(
            PrincipalScheduleEntry(date(2026, 10, 1), D(99)),
        ))
        with self.assertRaisesRegex(ValueError, "sum exactly"):
            LoanPosition(terms, terms.start_date, D(100))

    def test_bespoke_wrong_boundary_is_not_silently_adjusted(self) -> None:
        with self.assertRaisesRegex(ValueError, "unadjusted accrual boundaries"):
            self.rows(amortization_type=AmortizationType.BESPOKE, principal_schedule=(
                PrincipalScheduleEntry(date(2026, 5, 1), D(10)),
                PrincipalScheduleEntry(date(2026, 10, 1), D(90)),
            ))

    def test_bespoke_early_payoff_with_explicit_zero_maturity(self) -> None:
        rows = self.rows(amortization_type=AmortizationType.BESPOKE, principal_schedule=(
            PrincipalScheduleEntry(date(2026, 4, 1), D(100)),
            PrincipalScheduleEntry(date(2026, 10, 1), D(0)),
        ))
        self.assertEqual(len(rows), 1)
        self.assertEqual(rows[-1].closing_balance, D(0))

    def test_hand_two_period_annuity(self) -> None:
        # 100 = P/1.1 + P/1.1^2, hence P = 1210/21.
        payment = projected_level_payment(D(100), (Fraction(1, 10), Fraction(1, 10)), D(0))
        self.assertEqual(payment, Fraction(1210, 21))
        rows = self.rows(maturity_date=date(2026, 7, 1), amortization_type=AmortizationType.ANNUITY, balloon_amount=D(0))
        self.assertEqual([row.principal_repayment for row in rows], [D("47.62"), D("52.38")])
        self.assertEqual([row.total_cash for row in rows], [D("57.62"), D("57.62")])

    def test_variable_factors_have_independent_hand_solution(self) -> None:
        # q1=.1, q2=.2: 100 = 60/1.1 + 60/(1.1*1.2).
        rates = RecordingRates({date(2026, 1, 1): D("0.4"), date(2026, 4, 1): D("0.8")})
        terms = terms_for(maturity_date=date(2026, 7, 1), coupon_type=CouponType.FLOATING, fixed_rate=None,
                          rate_index="EURIBOR_3M", amortization_type=AmortizationType.ANNUITY, balloon_amount=D(0))
        rows = ContractualCashflowEngine(rates).generate(LoanPosition(terms, terms.start_date, D(100)))
        self.assertEqual([row.principal_repayment for row in rows], [D(50), D(50)])
        self.assertEqual([row.total_cash for row in rows], [D(60), D(60)])
        self.assertEqual(rates.calls, [date(2026, 1, 1), date(2026, 4, 1)])

    def test_annuity_balloon_is_extra_to_last_level_installment(self) -> None:
        rows = self.rows(maturity_date=date(2026, 7, 1), amortization_type=AmortizationType.ANNUITY, balloon_amount=D(50))
        self.assertEqual([row.principal_repayment for row in rows], [D("23.81"), D("76.19")])
        self.assertEqual([row.total_cash for row in rows], [D("33.81"), D("83.81")])

    def test_zero_rate_final_rounding_adjustment(self) -> None:
        rows = self.rows(fixed_rate=D(0), amortization_type=AmortizationType.ANNUITY, balloon_amount=D(0))
        self.assertEqual([row.total_cash for row in rows], [D("33.33"), D("33.33"), D("33.34")])
        self.assertEqual(sum((Fraction(row.principal_repayment) for row in rows)), Fraction(100))

    def test_cent_annuity_cannot_silently_retire_before_maturity(self) -> None:
        terms = terms_for(reference_principal=D("0.02"), fixed_rate=D(0),
                          amortization_type=AmortizationType.ANNUITY, balloon_amount=D(0))
        with self.assertRaisesRegex(ValueError, "before contractual maturity"):
            self.engine.generate(LoanPosition(terms, terms.start_date, D("0.02")))

    def test_annuity_grace_coupon_is_cash_paid_not_capitalized(self) -> None:
        rows = self.rows(amortization_type=AmortizationType.ANNUITY, balloon_amount=D(0),
                         amortization_start_date=date(2026, 7, 1))
        self.assertEqual([row.principal_repayment for row in rows], [D(0), D("47.62"), D("52.38")])
        self.assertEqual([row.total_cash for row in rows], [D(10), D("57.62"), D("57.62")])

    def test_negative_coupon_annuity_can_still_reduce_principal(self) -> None:
        rows = self.rows(maturity_date=date(2026, 7, 1), fixed_rate=D("-0.4"),
                         amortization_type=AmortizationType.ANNUITY, balloon_amount=D(0))
        self.assertEqual([row.principal_repayment for row in rows], [D("52.63"), D("47.37")])
        self.assertEqual([row.cash_interest for row in rows], [D(-10), D("-4.74")])
        self.assertEqual([row.total_cash for row in rows], [D("42.63"), D("42.63")])

    def test_annuity_rejects_negative_amortization_and_nonpositive_growth_factor(self) -> None:
        with self.assertRaisesRegex(ValueError, "negative amortization"):
            projected_level_payment(D(100), (Fraction(10), Fraction()), D(0))
        with self.assertRaisesRegex(ValueError, "1 \\+ rate"):
            projected_level_payment(D(100), (Fraction(-1),), D(0))

    def test_microsoft_pmt_known_answer(self) -> None:
        # Microsoft's published example: 8% annual, 10 monthly payments, 10,000.
        terms = terms_for(reference_principal=D(10000), fixed_rate=D("0.08"), frequency_months=1,
                          maturity_date=date(2026, 11, 1), amortization_type=AmortizationType.ANNUITY, balloon_amount=D(0))
        rows = self.engine.generate(LoanPosition(terms, terms.start_date, D(10000)))
        self.assertEqual(rows[0].total_cash, D("1037.03"))
        self.assertEqual(rows[0].cash_interest, D("66.67"))
        self.assertEqual(len(rows), 10)
        self.assertEqual(rows[-1].closing_balance, D(0))

    def test_early_payoff_does_not_resolve_unused_future_fixings(self) -> None:
        rates = RecordingRates({date(2026, 1, 1): D("0.4")})
        terms = terms_for(coupon_type=CouponType.FLOATING, fixed_rate=None, rate_index="EURIBOR_3M",
                          amortization_type=AmortizationType.LINEAR_AMOUNT, scheduled_principal_amount=D(100))
        rows = ContractualCashflowEngine(rates).generate(LoanPosition(terms, terms.start_date, D(100)))
        self.assertEqual(len(rows), 1)
        self.assertEqual(rates.calls, [date(2026, 1, 1)])

    def test_low_caller_decimal_context_cannot_change_new_policy_results(self) -> None:
        expected = self.rows(amortization_type=AmortizationType.ACCELERATED,
                             scheduled_principal_amount=D("0.01"), amortization_growth=D("0.5"))
        expected_annuity = self.rows(amortization_type=AmortizationType.ANNUITY, balloon_amount=D(0))
        with localcontext() as caller:
            caller.prec = 2
            caller.rounding = ROUND_DOWN
            caller.traps[Inexact] = True
            actual = self.rows(amortization_type=AmortizationType.ACCELERATED,
                               scheduled_principal_amount=D("0.01"), amortization_growth=D("0.5"))
            self.assertEqual(actual, expected)
            self.assertEqual(self.rows(amortization_type=AmortizationType.ANNUITY, balloon_amount=D(0)), expected_annuity)
            self.assertEqual(projected_level_payment(D(100), (Fraction(1, 10), Fraction(1, 10)), D(0)), Fraction(1210, 21))

    def test_irrelevant_missing_or_invalid_parameters_are_rejected(self) -> None:
        invalid = [
            dict(balloon_amount=D(0)),
            dict(amortization_start_date=date(2026, 4, 1)),
            dict(amortization_type=AmortizationType.LINEAR_AMOUNT),
            dict(amortization_type=AmortizationType.LINEAR_AMOUNT, scheduled_principal_amount=D(0)),
            dict(amortization_type=AmortizationType.ACCELERATED, scheduled_principal_amount=D(10)),
            dict(amortization_type=AmortizationType.ACCELERATED, scheduled_principal_amount=D(10), amortization_growth=D(-1)),
            dict(amortization_type=AmortizationType.ANNUITY),
            dict(amortization_type=AmortizationType.ANNUITY, balloon_amount=D(0), scheduled_principal_amount=D(10)),
            dict(amortization_type=AmortizationType.LINEAR_AMOUNT, scheduled_principal_amount=10.0),
            dict(amortization_type=AmortizationType.LINEAR_AMOUNT, scheduled_principal_amount=D("0.001")),
            dict(amortization_type=AmortizationType.LINEAR_AMOUNT, scheduled_principal_amount=D(10), balloon_amount=D("NaN")),
            dict(amortization_type=AmortizationType.LINEAR_AMOUNT, scheduled_principal_amount=D(10), amortization_start_date=datetime(2026, 4, 1)),
            dict(first_payment_date=date(2026, 1, 1)),
        ]
        for fields in invalid:
            with self.subTest(fields=fields), self.assertRaises(ValueError):
                terms_for(**fields)

    def test_schedule_is_immutable_unique_ordered_and_maturity_explicit(self) -> None:
        bad = [[], (PrincipalScheduleEntry(date(2026, 4, 1), D(100)),),
               (PrincipalScheduleEntry(date(2026, 4, 1), D(10)), PrincipalScheduleEntry(date(2026, 4, 1), D(20)),
                PrincipalScheduleEntry(date(2026, 10, 1), D(70)))]
        for schedule in bad:
            with self.subTest(schedule=schedule), self.assertRaises(ValueError):
                terms_for(amortization_type=AmortizationType.BESPOKE, principal_schedule=schedule)
        with self.assertRaises(ValueError):
            PrincipalScheduleEntry(datetime(2026, 4, 1), D(10))
        with self.assertRaises(ValueError):
            PrincipalScheduleEntry(date(2026, 4, 1), D(-1))

    def test_amortization_start_must_be_nominal_boundary(self) -> None:
        with self.assertRaisesRegex(ValueError, "unadjusted accrual boundary"):
            self.rows(amortization_type=AmortizationType.LINEAR_AMOUNT, scheduled_principal_amount=D(10),
                      amortization_start_date=date(2026, 5, 1))

    def test_front_stub_anchor_is_transported_to_schedule_builder(self) -> None:
        rows = self.rows(maturity_date=date(2026, 8, 1), first_payment_date=date(2026, 2, 1),
                         stub_convention=StubConvention.SHORT_FIRST,
                         amortization_type=AmortizationType.LINEAR_AMOUNT, scheduled_principal_amount=D(10))
        self.assertEqual([row.unadjusted_end for row in rows], [date(2026, 2, 1), date(2026, 5, 1), date(2026, 8, 1)])


if __name__ == "__main__":
    unittest.main()
