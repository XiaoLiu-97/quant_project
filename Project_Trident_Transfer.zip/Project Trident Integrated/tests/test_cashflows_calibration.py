"""Independent arithmetic oracles for automatic principal calibration."""

from datetime import date
from decimal import Decimal, Inexact, localcontext
import unittest

from test_cashflows_principal import terms_for
from trident.cashflows.engine import ContractualCashflowEngine
from trident.cashflows.principal import calibrated_principal_amounts
from trident.domain.models import AmortizationType, InputValidationError, LoanPosition
from trident.market import FlatRateProvider

D = Decimal


class CalibratedPrincipalTests(unittest.TestCase):
    def rows(self, kind=AmortizationType.LINEAR_AUTO, *, opening=D(100), **changes):
        terms = terms_for(amortization_type=kind, balloon_amount=D(0), **changes)
        return ContractualCashflowEngine(FlatRateProvider({})).generate(
            LoanPosition(terms, terms.start_date, opening))

    def repayments(self, **changes):
        return [row.principal_repayment for row in self.rows(**changes)]

    def test_equal_calibration_and_maturity_cent_reconciliation(self):
        rows = self.rows()
        self.assertEqual([r.principal_repayment for r in rows], [D('33.33'), D('33.33'), D('33.34')])
        self.assertEqual([r.cash_interest for r in rows], [D(10), D('6.67'), D('3.33')])
        self.assertEqual(sum(r.principal_repayment for r in rows), D(100))

    def test_ten_million_four_quarter_linear(self):
        self.assertEqual(self.repayments(opening=D(10_000_000), reference_principal=D(10_000_000),
                                        maturity_date=date(2027, 1, 1)), [D(2_500_000)] * 4)

    def test_fifteen_million_geometric_known_answer(self):
        self.assertEqual(self.repayments(kind=AmortizationType.ACCELERATED_AUTO,
            opening=D(15_000_000), reference_principal=D(15_000_000), amortization_growth=D(1),
            maturity_date=date(2027, 1, 1)), [D(1_000_000), D(2_000_000), D(4_000_000), D(8_000_000)])

    def test_balloon_and_grace_use_only_eligible_payments(self):
        terms = terms_for(amortization_type=AmortizationType.LINEAR_AUTO, balloon_amount=D(20),
                          amortization_start_date=date(2026, 7, 1))
        rows = ContractualCashflowEngine(FlatRateProvider({})).generate(LoanPosition(terms, terms.start_date, D(100)))
        self.assertEqual([r.principal_repayment for r in rows], [D(0), D(40), D(60)])
        self.assertEqual([r.cash_interest for r in rows], [D(10), D(10), D(6)])

    def test_held_face_not_reference_face(self):
        self.assertEqual(self.repayments(reference_principal=D(1000)), [D('33.33'), D('33.33'), D('33.34')])

    def test_zero_growth_matches_linear(self):
        self.assertEqual(self.rows(), self.rows(AmortizationType.ACCELERATED_AUTO, amortization_growth=D(0)))

    def test_full_balloon_and_one_period(self):
        terms = terms_for(amortization_type=AmortizationType.LINEAR_AUTO, balloon_amount=D(100))
        engine = ContractualCashflowEngine(FlatRateProvider({}))
        self.assertEqual([r.principal_repayment for r in engine.generate(LoanPosition(terms, terms.start_date, D(100)))],
                         [D(0), D(0), D(100)])
        self.assertEqual(self.repayments(maturity_date=date(2026, 4, 1)), [D(100)])

    def test_decimal_context_does_not_change_calibration(self):
        expected = self.rows(AmortizationType.ACCELERATED_AUTO, amortization_growth=D('.2'))
        with localcontext() as context:
            context.prec = 2
            context.traps[Inexact] = True
            self.assertEqual(self.rows(AmortizationType.ACCELERATED_AUTO, amortization_growth=D('.2')), expected)

    def test_tiny_face_does_not_silently_retire_early(self):
        with self.assertRaisesRegex(InputValidationError, 'retire before'):
            self.rows(opening=D('.02'), reference_principal=D('.02'))

    def test_extreme_growth_safe_calculation_and_explicit_numeric_budget(self):
        self.assertEqual(self.repayments(kind=AmortizationType.ACCELERATED_AUTO, amortization_growth=D('1e1000')),
                         [D(0), D(0), D(100)])
        with self.assertRaisesRegex(InputValidationError, 'numeric budget'):
            calibrated_principal_amounts(D(100), D(0), 10000, D('1e1000'))

    def test_invalid_or_ambiguous_calibration_rejected(self):
        for count in (0, -1, True, 1.5):
            with self.subTest(count=count), self.assertRaises(InputValidationError):
                calibrated_principal_amounts(D(100), D(0), count)
        for balloon, growth in ((D(101), D(0)), (D(0), D(-1)), (D(0), D('NaN'))):
            with self.subTest(balloon=balloon, growth=growth), self.assertRaises(InputValidationError):
                calibrated_principal_amounts(D(100), balloon, 3, growth)
        for changes in ({}, {'balloon_amount': D(0), 'scheduled_principal_amount': D(10)}):
            with self.subTest(changes=changes), self.assertRaises(InputValidationError):
                terms_for(amortization_type=AmortizationType.LINEAR_AUTO, **changes)
        with self.assertRaises(InputValidationError):
            terms_for(amortization_type=AmortizationType.ACCELERATED_AUTO, balloon_amount=D(0))
