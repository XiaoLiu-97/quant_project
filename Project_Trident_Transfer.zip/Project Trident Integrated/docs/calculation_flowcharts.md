# 计算流程与页面导览

版本 `0.12.3`。以下流程对应当前支持的 generic EUR profile；实际交易的 priority、OC/IC definition 和 eligibility 仍需按执行条款映射。Excel 保存输入与已计算结果，金融计算在 Python 完成。日期、case 和 scope 的下拉选择只切换已保存的记录。

首次理解waterfall，先看[中文阅读指南](waterfall_guide_cn.md)及[17页流程图PDF](../outputs/Project_Trident_Waterfall_Flowcharts_CN.pdf)。它们按资金实际变化展开，给出步骤、释义、手算与边界；下文保留更详细的模块及数据流程。

## 从输入到一次完整运行

```mermaid
flowchart TD
  A[15个用户页填写拥有者输入] --> B[保存并关闭Excel]
  B --> C[InterfaceInputReader]
  C --> D[按Table identity和named owner读取已填写原始值；跳过完全空白预留行]
  D --> E[检查ID及Table/header覆盖]
  E --> F[转换price points、bps、百分数及日期]
  F --> G[核对来源、持仓、schedule、fixing和opening claims]
  G --> H[Immutable typed request和input fingerprint]
  H --> I[所有case先校验]
  I --> J[BASELINE及独立what-if完整计算]
  H --> K[选择的静态优化或closing candidate replay]
  J --> L[typed saved case records]
  K --> L
  L --> M[保护输入和Market Data]
  M --> N[复用稳定Table容量；批量更新实际output及隐藏Results]
  N --> O[复用样式和不变公式；更新必要值/cache；失效旧chart caches]
  O --> P[变动XML与package invariants校验；核对临时ZIP后原子保存]
  P --> Q[Excel重开：展示lookup和图表重算；交付时做原生检查]
```

读取时不把 cached lookup 当作 owning input。共同 Asset Library 可以保存一项资产的多条评级、本金 schedule 或事件；Collateral Pool 选择实际持仓及该 CLO 的分类/OC mark。Analysis exposures 必须与 projected positions 的 ID、par、currency 和合同属性一致。未知字段或不支持的组合明确失败。

## 写出阶段：哪些变化，哪些复用

```mermaid
flowchart TD
  A[Reader验证原始输入；Python完成全部enabled cases] --> B[完整真实结果记录与input fingerprint]
  B --> C[Source package首次完整校验；保留解析树及已验证bytes]
  C --> D[按names和Tables定位结果区；保护owning inputs及Market Data]
  D --> E{实际记录是否超过已有容量}
  E -->|没有| F[保持Table ref；直接批量更新结果]
  E -->|超过| G[检查增长区域notes/merges/named inputs/相邻Tables]
  G -->|安全| F
  G -->|冲突| Z[失败；保留上次完整输出]
  F --> H{已有cell与本次展示语义是否相同}
  H -->|完全相同| I[复用原cell XML与style]
  H -->|公式表达式相同但结果变化| J[只更新匹配公式cache；保留公式与相关元数据]
  H -->|普通公式或值类型/格式确需改变| K[按普通完整更新路径校验并替换]
  I --> L[清掉过期结果尾部；更新actual rows/options/witness/freshness]
  J --> L
  K --> L
  L --> M[失效旧chart caches；设置Excel展示重算]
  M --> N[校验合法序列化；全体当前DOM的关系/names/schema/公式及输入保护]
  N --> O[仅对bytes完全一致的parts复用已解析内容]
  O --> P[序列化变化parts；写临时完整xlsx ZIP]
  P --> Q[核对ZIP条目/内容/metadata/comment/CRC]
  Q -->|通过| Q2[覆盖source时再核对源文件与load-time ZIP完全一致]
  Q2 -->|未被外部修改| R[原子发布]
  Q2 -->|外部已修改| Z
  Q -->|失败| Z
  R --> S[用户打开Excel；重算展示lookup与图表]
```

这条流程优化的是结果传输，不改变金融算法或投影范围。公式文本不变并不意味着 cached value 可以保留旧结果；既有特殊公式只在表达式稳定时保留原属性，此缓存路径不重新构造 shared/array formula group。容量内复用 Table 范围也不等于忽略新增记录或保留旧尾部。选项目录按真实可选记录更新，不让空预留行进入下拉框。

Source 的首次完整验证、合法 XML 序列化、全体当前 DOM 的关系/命名/公式不变量、输入/Market Data 保护及临时 ZIP 检查分属不同边界；未变 part 必须与已验证 bytes 完全相同才能复用解析树。覆盖同一 source 时，在开始 staging 前和原子发布前均核对 source ZIP 是否仍与载入时完全一致；不同的既有输出目的地则独立完整验证。并发修改会明确阻止覆盖，保留较新文件。Excel 的重开重算仅更新展示，CLO 金融值仍来自 Python。原子发布前失败时，上一份完整工作簿保持不变。职责与安全条件见 [稳定模板与增量写出](architecture.md#稳定模板与增量写出)。

## 预留容量如何进入运行

```mermaid
flowchart TD
  A[各Table的容量类别和原有布局] --> B{Owning input是否需要预留行}
  B -->|需要| C[12类input各自预留；资产300/评级900/明细3000]
  C --> C2[Capital12/limits100/edits300/factor300]
  B -->|固定schema或Market Data| D[保留语义数量及原布局]
  C2 --> E[保留有效输入；新增空白样式与原生validation]
  E --> F[扩展named aliases和paired input witnesses]
  F --> G[已填写Asset ID组成compact live dropdown]
  G --> H[Reader仅消费已填写owning记录]
  D --> H
  H --> I[金融typed request及正常计算]
  I --> J[完整真实结果记录]
  J --> K[按资产/期数/tranche/case预留output Table范围]
  K --> L[只写实际结果；容量内复用范围/格式/不变公式]
  L --> M[记录actual rows和capacity；清掉过期值/formula/cache]
  M --> N[必要扩容检查碰撞；更新freshness；失效旧chart caches；校验原子发布]
```

300是初始资产输入空间，不是所有表统一的最大行数，也不是投影期数。Limits和factor mapping扩容时，把已识别说明/导航移到同页右侧的独立区域；guard拒绝目标冲突，owning inputs不移动。Bespoke principal schedule 的每期还款各占一行；完全空白预留行不会生成资产或现金。所有 Table 的分类、物理行数、实际记录数与请求容量登记在隐藏 `_Results` 的 `tbl_trident_ui_table_capacity`。原始 financial inputs、typed request 与金融算法不因扩容而改变；完整规则见 [Table 容量](table_capacity.md)。

## Closing、opening 与资产收款

```mermaid
flowchart TD
  A[完整typed request] --> B{New Issue还是Existing CLO}
  B -->|New Issue| C[实际clean和accrued cost、发行所得、费用及reserve]
  C --> D[Sources and Uses确定equity funding]
  B -->|Existing CLO| E[原payment boundary和原schedule anchors]
  E --> F[8个sourced账户或designation、4类fee claim、每个debt coupon claim]
  F --> G[当前sourced whole equity value]
  D --> H[原始loan schedule及coupon/reset/fixing]
  G --> H
  H --> I[合同reference cashflow和本金计划]
  I --> J{Explicit credit event或原池stress}
  J -->|没有| K[实际scheduled receipts]
  J -->|有| L[Default或prepay ledger]
  L --> M[明确日期的prepay coupon、recovery和write-off]
  K --> N[actual interest和principal collections]
  M --> N
  I --> O[保留contract reference明细]
  N --> P[CLO收款、cutoff和账户]
```

合同应付与实际收款分开保存。Default 本身不制造 coupon 或 recovery cash；recovery 仅在明确日期收取，write-off 明确结束未收本金 claim。Prepay 按原 accrual/fixing 计算实际 earned coupon。Opening 不重购已持有资产、不重发债务、不重新支付历史 setup；已赚取 coupon 的 ownership 由 seasoned state 证明。

## 原始池 CPR 与 reinvestment CPR 如何进入 Prepayments

```mermaid
flowchart TD
  A[原始 Collateral Pool 合同及持仓] --> B{Credit / Prepayment Overlay 为 On}
  B -->|否| C[不施加原池比例 CDR/CPR]
  B -->|是| D[读取 Original Collateral CPR 及独立 CDR/recovery]
  D --> E[default 后 surviving par；再扣当期 scheduled principal]
  E --> F[按 ACT/365F 将年化 CPR 转为本区间条件概率]
  F --> G[剩余 performing par 乘概率；按 cent 生成 prepayment 收款]
  H[Asset Schedules explicit dated credit events] --> I[按已声明事件生成实际收款；独立校验兼容性]
  J{Reinvestment Enabled 为 Yes且purchase gates允许} -->|否| K[没有新 synthetic cohort 使用 reinvestment CPR]
  J -->|是| L[waterfall 实际 synthetic purchase；读取 Annual Prepayment Rate]
  L --> M[从 purchase 后的区间投影该 cohort 的未来 prepayment]
  G --> N[actual date credit collection / principal ledger]
  I --> N
  M --> N
  C --> O[普通合同 scheduled receipts]
  N --> P[按收款日期、cutoff和现金权限分配到 CLO period]
  O --> P
  P --> Q[Waterfall：Scheduled principal、Prepayments与Recoveries 分行显示]
```

这两个 CPR 不相互覆盖。交付示例的原池 overlay 为 Off、原池 CPR 为0%、reinvestment 为 No；reinvestment Annual Prepayment Rate 的10%保留为该未启用模块的输入，不能据此推断当前 collateral 每期必有提前还款。Reinvestment 先有实际 synthetic purchase，之后该 cohort 才使用其 CPR；单独改 rate 不会生成 purchase 或还款。

本比例 stress 的区间概率为 `1 - (1 - CPR) ** (days / 365)`，day count 固定 ACT/365F，与 coupon day count 分开。Default、当期 scheduled principal 与 prepayment 的先后顺序由本模型明确规定；提前还款实际 coupon 按 applicable accrual/fixing 和事件时点计算，不能把本金退出等同于整期利息消失。无 default、本金100、scheduled20、90天、CPR10%的例子，对余下80计算得2.05 prepayment，期末77.95。CPR年化及 scheduled 后余额的定义可对照 [SEC 公开 CPR/SMM 说明](https://www.sec.gov/Archives/edgar/data/1561167/000162829726000181/ex99_1.htm)；本模型的 ACT/365F 和事件时点是假设，不是该来源给出的所有 CLO 通用政策。

启用原池 CPR 的 named-owner 操作，以及为何 Asset Cashflows 仍保留 contractual reference，见 [用户指南](user_guide.md#为什么-waterfall-的-prepayments-可能为零)。

## 每个 payment date 的 interest / principal waterfall

```mermaid
flowchart TD
  A[期初cash、face、coupon和fee claims] --> B[收到actual collections及synthetic cohorts收款]
  B --> C[cutoff释放eligible cash；晚收款留pending]
  C --> D[明确cash-account remuneration]
  D --> E[费用按所选fee basis及DCF；note coupon按期初face及original schedule]
  E --> F[contractual PIK与cash claim分开]
  F --> G[senior expenses及senior management fee；允许reserve补付]
  G --> H[按seniority支付本级coupon并运行本级GATE]
  H --> I{OC或IC失败}
  I -->|是| J[按policy用interest赎回至tested class]
  J --> K[重新测试POST DIVERSION]
  K --> L{允许cure后继续且已修复}
  L -->|是| H
  L -->|否| M[下级interest gate保持BLOCKED]
  I -->|否| N[下一级coupon和gate]
  N --> H
  H -->|最后一级通过| O[deferred expense及subordinate management fee]
  O --> P[独立IDT诊断；blocked时仍可记录]
  M --> P
  P --> P1{window有效、未blocked且IDT失败?}
  P1 -->|是| P2[按cap和shortfall转interest至principal designation]
  P1 -->|否| Q[允许的call或final sale；实际proceeds入账并清除售出OC]
  P2 --> Q
  Q --> R[principal补付senior claims及被允许的note coupon]
  R --> S[现金用途权限与只读synthetic purchase plan]
  S --> S1[拟买后adjusted OC及当前IC；long-dated与资金guards]
  S1 --> S2{STOP通过或明确ALWAYS敏感性}
  S2 -->|否决| S3[不提交；普通现金继续使用，active IDT保留]
  S2 -->|允许| S4[提交purchase一次；立即更新collateral valuation]
  S3 --> T[实时PRINCIPAL GATE决定sequential或PRO_RATA债务赎回]
  S4 --> T
  T --> U[优先claims清偿后付junior fee及gross equity principal]
  U --> RF[允许的refi：以实际equity contribution支付fee；margin下期生效]
  RF --> CL[判断assets和claims是否settled；符合才释放reserve]
  CL --> IFEE[在I、P及released reserve的gross residual上计算incentive]
  IFEE --> V[net equity、PERIOD END diagnostics和各项守恒]
  V --> W[下一期；或完整性与终态检查]
```

上图的循环表示逐级流程，不表示不停重复支付同一 claim。模型保留每个 class 的 GATE、POST_DIVERSION 和 PERIOD_END trace；只有实际到达的 gate 才有 measured headroom。IC 的 generic 实现保留本期适用 claims，不能因 coupon 已支付而降低 denominator。OC 跟随实际剩余 face 及配置允许计入的 claims/cash。

Interest-funded OC cure 的目标为 `D-N/k`。当 principal payment 同时减少 numerator 和 denominator、且 `k>1` 时，理论 cure 为 `(kD-N)/(k-1)`；该式用于理解直接还本的作用，当前 ordinary principal 的失败分支仍按 sequential 支付 available cash，并非另行求最小本金 cure。Interest-funded cure 金额向上到 cent，受真实现金及 priority 限制。IC failure 不以 OC 公式伪装修复。IDT 是按配置转移 excess interest 到 principal 的独立机制；转账不会产生收入。

每期分别核对 physical cash、performing/defaulted collateral par、debt face、coupon claim 和 fee claim。Designation 是相关 cash account 的子集。Terminal 时仍有未清 liabilities/default claims 或未确认价值，模型保留 incomplete 状态，不假造 terminal distribution。

## Synthetic reinvestment 的来源与循环

```mermaid
flowchart TD
  A[Original principal permission和held diversion cash] --> B[实际principal account余额]
  B --> C{日期、买前gate、claims和policy允许}
  C -->|否| D[保留active IDT cash；普通本金按priority使用]
  C -->|是| E[只读purchase plan：明确price、cent face/cash及maturity]
  E --> F[拟买后adjusted OC；当前IC不加入未来coupon]
  F --> F2{STOP通过或明确ALWAYS敏感性}
  F2 -->|否决| D
  F2 -->|允许且guards通过| F3[提交cohort及cash一次；立即刷新valuation]
  F3 --> G[bullet template：WAL、spread、currency及credit assumptions]
  G --> H[下一期开始赚取coupon及未来本金]
  H --> I[CDR、CPR、recovery及actual date ledger]
  I --> J[未来actual cash回到账户]
  J --> K{允许recycle synthetic principal}
  K -->|是| B
  K -->|否| L[按独立original permission及debt priority使用]
```

只读计划不创建cohort，不扣现金或designation；STOP的拟买后检查使用acquired face、adjusted valuation和扣除posted consideration后的principal cash，pending及deferred claims仍遵从原OC policy。被否决后普通cash进入正常本金流程，active IDT保留其earmark。提交后PRINCIPAL_GATE即时使用新valuation，不能用PERIOD_END通过来倒推earlier gate。三个purchase/principal gate为内部决策节点，不是Excel新增report stage。ALWAYS是明确的coverage/unpaid-coupon sensitivity override；即使选择ALWAYS，日期/资金/final、禁止long-dated及asset-level synthetic classification guards仍生效。

Cohort maturity来自明确bullet WAL，不自动裁切至legal final；允许long-dated时，拟买后OC按其真实maturity应用相应haircut。禁止long-dated collateral的profile会拒绝不符合条件的purchase。Synthetic acquisition是研究假设，不是dealer execution，不证明完整法律质量测试，也不代表动态lifetime trading optimum。节点手算例见[waterfall方法](methodology/waterfall.md#synthetic-purchase-的前后状态检查)。

## Equity returns、dated analysis 与比较

```mermaid
flowchart TD
  A[Closing funding或Existing current equity value] --> B[起始日期negative investor cash]
  C[waterfall实际equity distributions] --> D[实际分配日期positive cash]
  E[明确refinancing或其他equity contribution] --> F[真实日期negative cash]
  B --> G[完整dated net investor cashflow]
  D --> G
  F --> G
  G --> H[IRR按真实日期及365年化；MOIC按真实净cash]
  I[实际par、credit events、native coupon timeline和synthetic inventory] --> J[dated portfolio observations]
  J --> K[WAS、WAC、WAL、ratings/factors和concentrations]
  K --> L[applicable limits、coverage和缺失数据status]
  H --> M[独立case：Base、Proposed和Delta]
  L --> M
  M --> N[保存完整Results及紧凑可见视图]
```

WAS 分母为 floating par，WAC 分母为 fixed par；Collateral WAL 使用本金收款日期和金额。Missing-data coverage 与 status 一并保留。Synthetic TEST factor 和真实 agency WARF 分别报告；TEST factor 不构成 agency calibration。Whole / BSL / INFRA 显示 selected case 的 opening snapshot，完整 dated observations 保存在 `_Results`。

```mermaid
flowchart TD
  A[当前snapshot及sourced quotes] --> B{所选优化路径}
  B -->|静态研究| C[线性或discrete mandate、tickets及limits]
  C --> D[HiGHS求解及cent reconciliation]
  D --> E[STATIC NOT REPLAYED NOT EXECUTED]
  B -->|Closing finite candidate search| F[有限mandate和structuring variants]
  F --> G[construct pool及capital；重算funding]
  G --> H[完整asset、portfolio、CLO及return replay]
  H --> I[limits、cash、typed admission及return completeness]
  I --> J[validated candidate才进入return ranking]
  E --> K[研究proposal和audit findings]
  J --> K
```

静态 Existing 研究可运行，但不执行交易、不做 closing issuance 或 IRR candidate replay。Opening face what-if 是另外的 counterfactual snapshot：现有 asset/note `par` 变更必须声明 whole `forward_equity_value` 与 `equity_value_source`，保留原 cash、claims 和 schedule。所有 case 独立从 BASELINE 建立。

## 15个用户页的最短路径

| 顺序 | 页面 | 目的 |
| --- | --- | --- |
| 1 | Home | 查看工作流、运行状态和导航 |
| 2 | Asset Library | 合同、分类、评级和共同 asset identity |
| 3 | Asset Schedules | 一对多本金、coupon/event、opening entitlement 与 fixing |
| 4 | Asset Cashflows | 合同reference；选择 held case 或 LIBRARY_REFERENCE |
| 5 | Market Data | 利率与模式，保持原粘贴布局 |
| 6 | CLO Assumptions | 费用、coverage、OC policy、opening accounts 和 fee claims |
| 7 | Collateral Pool | 实际持仓、current face、cost 与 deal-specific mark |
| 8 | Capital Stack | debt/current face、coupon、threshold 与 unpaid claim |
| 9 | Waterfall | 完整逐期、逐 tranche cash 和 claims |
| 10 | CLO Analysis | returns、charts、scope、coverage 和 Source details |
| 11 | Scenarios | case 的绝对 edits；页面内使用 Scenario Edits Table |
| 12 | Trade Universe | 当前 sourced quotes、size、settlement 和费用 |
| 13 | Optimization | static enable、mandate 和 finite replay controls |
| 14 | Trades & Comparison | proposal 及完整 case 的经济 delta |
| 15 | Checks | freshness、unavailable data、financial status 和核对 |

`_Lists` 与 `_Results` 是隐藏支持页，分别保存选项/witness 和完整计算记录。用户页数量不随 asset 或 lifetime period 增长。使用步骤见 [用户指南](user_guide.md)，安装见 [部署](deployment.md)，实际实现边界见 [架构](architecture.md) 和 [模型假设](model_assumptions.md)。
