"""Named interface, class-period reporting and full candidate replay acceptance."""

from datetime import date
from decimal import Decimal
from pathlib import Path
import tempfile
import unittest

from openpyxl import load_workbook
from workbook_fixtures import copy_input_template
from trident.adapters import excel_schema as schema
from trident.adapters.excel import NamedWorkbook, run_workbook
from workbook_fixtures import hand_controls, put_records, write_controls


ROOT = Path(__file__).resolve().parents[1]
D = Decimal


class ExcelInterfaceTests(unittest.TestCase):
    def setUp(self):
        self.folder = tempfile.TemporaryDirectory()
        self.addCleanup(self.folder.cleanup)
        self.path = Path(self.folder.name) / "model.xlsx"
        copy_input_template(self.path)

    def access(self, callback, *, save=False):
        book = load_workbook(self.path)
        try:
            result = callback(NamedWorkbook(book))
            if save:
                book.save(self.path)
            return result
        finally:
            book.close()

    def test_complete_named_candidate_search_with_generated_quality_profile(self):
        """A complete pool may settle, without inventing missing agency factors.

        Mapping factors below are explicit arithmetic fixtures, not certified
        agency data. All seven generated quality controls remain enabled.
        """
        self.small(candidate=True)
        def edit(adapter):
            for key, bucket in (('assets', 'OLD_BUCKET'), ('candidate_assets', 'NEW_BUCKET')):
                records = [dict(row) for row in self.table(adapter, key)]
                for row in records:
                    row.update(agency_rating=bucket)
                put_records(adapter, key, records)
            # Exercise the general WARF mapping path with declared hand inputs.
            # is_synthetic=False selects that path; it is no certification of
            # these plainly named test factors or their agency provenance.
            put_records(adapter, 'factor_mapping', (
                dict(system='EXPLICIT_HAND_FACTOR', version='1', bucket='OLD_BUCKET', factor=4000, is_synthetic=False),
                dict(system='EXPLICIT_HAND_FACTOR', version='1', bucket='NEW_BUCKET', factor=2000, is_synthetic=False)))
            for key, value in (('legacy_minimum_collateral_warr', .3),
                               ('legacy_minimum_collateral_was', .04),
                               ('legacy_maximum_portfolio_warf', 5000)):
                adapter.write_scalar(schema.SCALAR_NAMES[key], value)
        self.access(edit, save=True)
        result = run_workbook(self.path)
        from trident.analysis import LimitStatus
        self.assertTrue(all(row.status is LimitStatus.PASS for row in result.opening_portfolio.limits))
        self.assertEqual(result.portfolio_snapshots[-1].phase, 'TERMINATED')
        rows = self.access(lambda adapter: self.table(adapter, 'candidate_results'))
        self.assertTrue(any(row.get('eligible') is True for row in rows), rows)

    @staticmethod
    def table(adapter, key):
        return adapter.table_records(schema.TABLE_RANGE_NAMES[key], schema.TABLE_NAMES[key])

    def small(self, *, candidate=False):
        """Independent 90-day closing example with explicit quote evidence."""
        def edit(a):
            old = dict(self.table(a, "assets")[0])
            old.update(loan_id="OLD",asset_class="BSL",financing_type="TERM_LOAN",obligor_id="ISSUER_OLD",
                country_code="GB",sector="SECTOR_OLD",initial_par=10000,current_par=10000,purchase_price_pct=100,
                cashflow_projection_start_date=date(2026,1,20),par_as_of_date=date(2026,1,20),maturity_date_unadjusted=date(2026,4,20),
                spread_bps=500,rate_index="EURIBOR_3M",index_floor_bps=0,coupon_type="FLOATING",amortization_type="BULLET",
                amortization_fraction_initial_par_per_period=0,amortization_first_date_unadjusted=None,amortization_periods_remaining=None,
                acquired_accrued_interest=0,test_factor_bucket="OLD_BUCKET",test_factor_system="TRIDENT_TEST_FACTOR",
                first_payment_date_unadjusted=None,last_regular_payment_date_unadjusted=None,scheduled_principal_amount=None,
                amortization_growth=None,balloon_amount=None,recovery_rate=.4,recovery_rate_source="SYNTHETIC_RECOVERY")
            capital = self.table(a,"capital_stack")
            debt = dict(next(row for row in capital if row["instrument_type"]=="DEBT"))
            debt.update(nominal_amount=8000,issue_price_pct=100,schedule_anchor_day=20,coupon_type="FIXED",fixed_rate=.02,
                        rate_index=None,index_floor_bps=None,spread_bps=0,oc_minimum=None,ic_minimum=None)
            equity = dict(next(row for row in capital if row["instrument_type"]=="EQUITY"))
            equity.update(nominal_amount=2000,issue_price_pct=100)
            a.write_table(schema.TABLE_RANGE_NAMES["assets"],schema.TABLE_NAMES["assets"],(old,))
            a.write_table(schema.TABLE_RANGE_NAMES["capital_stack"],schema.TABLE_NAMES["capital_stack"],(debt,equity))
            a.write_table(schema.TABLE_RANGE_NAMES["portfolio_limits"],schema.TABLE_NAMES["portfolio_limits"],())
            factors=({"system":"TRIDENT_TEST_FACTOR","version":"1","bucket":"OLD_BUCKET","factor":4000,"is_synthetic":True},
                     {"system":"TRIDENT_TEST_FACTOR","version":"1","bucket":"NEW_BUCKET","factor":2000,"is_synthetic":True})
            a.write_table(schema.TABLE_RANGE_NAMES["factor_mapping"],schema.TABLE_NAMES["factor_mapping"],factors)
            values=hand_controls((old,), (debt,equity), closing_date=date(2026,1,20),
                first_payment_date=date(2026,4,20), legal_final_date=date(2026,10,20), upfront_fees=7)
            values.update(synthetic_rate=0, legacy_reinvestment_end_date=date(2026,5,20),
                optimizer_enabled=False,candidate_search_enabled=candidate,
                optimizer_settlement_date=date(2026,1,20),optimizer_starting_cash=1000,optimizer_target_par=10000,
                optimizer_maximum_trade_par=20000,optimizer_maximum_obligor_share=1,optimizer_maximum_country_share=1,
                optimizer_maximum_sector_share=1,optimizer_maximum_bsl_share=1,optimizer_minimum_infra_share=0,
                optimizer_maximum_overall_factor=5000,optimizer_maximum_bsl_factor=5000,optimizer_minimum_spread_bps=None,
                candidate_snapshot_id="HAND_SNAPSHOT",candidate_snapshot_captured_at="2026-01-19T16:00:00+00:00",
                candidate_snapshot_source="SYNTHETIC_NOT_LIVE_BLOOMBERG")
            write_controls(a, values)
            if candidate:
                new=dict(old,loan_id="NEW",obligor_id="ISSUER_NEW",sector="SECTOR_NEW",spread_bps=800,test_factor_bucket="NEW_BUCKET")
                sheet,(left,top,right,_) = a.region(schema.TABLE_RANGE_NAMES["candidate_assets"])
                headers=tuple(sheet.cell(top,col).value for col in range(left,right+1))
                a.write_table(schema.TABLE_RANGE_NAMES["candidate_assets"],schema.TABLE_NAMES["candidate_assets"],
                              ({field:new[field] for field in headers},))
                a.write_table(schema.TABLE_RANGE_NAMES["candidate_metadata"],schema.TABLE_NAMES["candidate_metadata"],tuple(
                    {"loan_id":key,"facility_id":f"FACILITY_{key}","bloomberg_security":f"SYNTHETIC_BBG_{key}",
                     "contract_provenance":"VERIFIED_TEST_CONTRACT","classification_provenance":"VERIFIED_TEST_CLASSIFICATION","credit_status":"PERFORMING"}
                    for key in ("OLD","NEW")))
                a.write_table(schema.TABLE_RANGE_NAMES["candidate_ratings"],schema.TABLE_NAMES["candidate_ratings"],tuple(
                    {"loan_id":key,"agency":"SYNTHETIC_TEST_AGENCY","rating":"TEST_RATING","level":"FACILITY","nature":"INTERNAL",
                     "subject_id":f"FACILITY_{key}","as_of_date":date(2026,1,19),"source":"EXPLICIT_TEST_RATING"}
                    for key in ("OLD","NEW")))
                common=dict(asset_class="BSL",country_code="GB",currency="EUR",maximum_par=10000,accrued_per_par=0,
                    proportional_fee_per_par=0,lot_size=None,minimum_ticket=0,fixed_fee=0)
                quotes=tuple(dict(common,asset_id=key,side=side,obligor_id=f"ISSUER_{key}",sector=f"SECTOR_{key}",
                    spread_bps=spread,factor_bucket=f"{key}_BUCKET",clean_price_pct=price)
                    for key,side,spread,price in (("OLD","SELL",500,99),("NEW","BUY",800,101)))
                a.write_table(schema.TABLE_RANGE_NAMES["trade_candidates"],schema.TABLE_NAMES["trade_candidates"],quotes)
                a.write_table(schema.TABLE_RANGE_NAMES["quote_observations"],schema.TABLE_NAMES["quote_observations"],tuple(
                    {"asset_id":row["asset_id"],"side":row["side"],"price_side":"ASK" if row["side"]=="BUY" else "BID",
                     "quality":"FIRM","observed_at":"2026-01-19T16:00:00+00:00","settlement_date":date(2026,1,20),"source":"HAND_TEST_QUOTE"}
                    for row in quotes))
        self.access(edit,save=True)


    def test_every_class_period_waterfall_reconciles_to_engine(self):
        self.small()
        result=run_workbook(self.path)
        def check(a):
            rows=self.table(a,"tranche_waterfall")
            self.assertEqual(a.region(schema.TABLE_RANGE_NAMES["tranche_waterfall"])[0].title,"CLO Waterfall")
            self.assertEqual(a.region(schema.TABLE_RANGE_NAMES["clo_periods"])[0].title,"CLO Accounts")
            capital=self.table(a,"capital_stack")
            self.assertEqual(len(rows),len(result.clo.periods)*len(capital))
            self.assertEqual({(r["period_number"],r["class_id"]) for r in rows},
                {(period.period_number,r["class_id"]) for period in result.clo.periods for r in capital})
            self.assertEqual(rows[0]["current_coupon_due"],40)
            self.assertEqual(rows[0]["total_principal_paid"],8000)
            self.assertEqual(rows[0]["total_cash_paid"],8040)
            self.assertEqual(rows[0]["closing_balance"],0)
            residual=next(r for r in rows if r["period_number"]==1 and r["instrument_type"]=="EQUITY")
            self.assertEqual(residual["equity_from_interest"],85)
            self.assertEqual(residual["equity_from_principal"],2000)
            self.assertEqual(residual["total_cash_paid"],2085)
            self.assertEqual(residual["equity_cash_funding"],2007)
            self.assertAlmostEqual(residual["cumulative_equity_distribution_multiple"],2085/2007,places=14)
            for field in ("opening_balance","current_coupon_due","gate_oc_ratio","period_end_ic_status","all_in_rate"):
                self.assertIsNone(residual[field])
            funding={r["name"]:r["value"] for r in self.table(a,"funding_summary")}
            self.assertEqual(funding["equity_cash_funding"],2007)
        self.access(check)

    def test_itemized_costs_and_sources_change_actual_equity_funding(self):
        self.small()
        def edit(a):
            for key,value in dict(legacy_other_upfront_costs=0,
                legacy_upfront_arrangement_fee=.0075,legacy_other_initial_uses=10,
                legacy_other_initial_sources=5,other_initial_source_type="EXTERNAL_CONTRIBUTION").items():
                a.write_scalar(schema.SCALAR_NAMES[key],value)
            a.write_table(schema.TABLE_RANGE_NAMES["closing_costs"],schema.TABLE_NAMES["closing_costs"],({"cost_id":"LEGAL","amount":20},))
        self.access(edit,save=True)
        result=run_workbook(self.path)
        self.assertEqual(result.cashflows.funding.arrangement_fee,D(75))
        self.assertEqual(result.cashflows.funding.upfront_fees,D(95))
        self.assertEqual(result.cashflows.funding.equity_cash_funding,D(2100))
        self.assertEqual(result.cashflows.funding.total_uses,result.cashflows.funding.total_sources)

    def test_duplicate_canonical_closing_cost_fails_without_any_writeback(self):
        self.small()
        self.access(lambda a:a.write_table(schema.TABLE_RANGE_NAMES["closing_costs"],schema.TABLE_NAMES["closing_costs"],
                                         ({"cost_id":"other_upfront_costs","amount":20},)),save=True)
        before=self.path.read_bytes()
        with self.assertRaisesRegex(ValueError,"Duplicate"):
            run_workbook(self.path)
        self.assertEqual(self.path.read_bytes(),before)

    def test_full_search_reports_irr_but_rejects_synthetic_rating_quality(self):
        self.small(candidate=True)
        run_workbook(self.path)
        def check(a):
            rows=self.table(a,"candidate_results")
            self.assertEqual(len(rows),3)
            self.assertIsNone(a.scalar(schema.SCALAR_NAMES["result_selected_candidate"]))
            baseline=next(r for r in rows if r["candidate_id"]=="NO_TRADES")
            proposal=next(r for r in rows if r["candidate_id"]=="FACTOR_PROPOSAL")
            # Mandatory production WARF has no synthetic substitute. Independent
            # funding/IRR bridges remain visible even for an excluded candidate.
            self.assertFalse(baseline["eligible"])
            self.assertFalse(proposal["eligible"])
            self.assertIn("WARF", proposal["failure_message"])
            self.assertEqual(proposal["equity_cash_funding"],2107)
            self.assertEqual(proposal["equity_distributions"],2160)
            self.assertEqual(proposal["factor"],2000)
            self.assertLess(proposal["equity_irr"],baseline["equity_irr"])
            self.assertAlmostEqual(baseline["equity_irr"],(2085/2007)**(365/90)-1,places=12)
            self.assertEqual(len(self.table(a,"candidate_trades")),4)
        self.access(check)

    def test_factor_first_policy_preserves_quality_rejection_and_disabling_clears_outputs(self):
        self.small(candidate=True)
        self.access(lambda a:a.write_scalar(schema.SCALAR_NAMES["candidate_selection_policy"],"MIN_FACTOR_THEN_IRR"),save=True)
        run_workbook(self.path)
        self.access(lambda a:self.assertIsNone(a.scalar(schema.SCALAR_NAMES["result_selected_candidate"])))
        self.access(lambda a:self.assertEqual(a.scalar(schema.SCALAR_NAMES["result_candidate_search_status"]),"NO_ELIGIBLE_CANDIDATE"))
        self.access(lambda a:a.write_scalar(schema.SCALAR_NAMES["candidate_search_enabled"],False),save=True)
        run_workbook(self.path)
        self.access(lambda a:self.assertEqual(self.table(a,"candidate_results"),()))
        self.access(lambda a:self.assertEqual(self.table(a,"candidate_trades"),()))
        self.access(lambda a:self.assertEqual(a.scalar(schema.SCALAR_NAMES["result_candidate_search_status"]),"DISABLED"))

    def test_timezone_missing_snapshot_fail_is_atomic(self):
        self.small(candidate=True)
        self.access(lambda a:a.write_scalar(schema.SCALAR_NAMES["candidate_snapshot_captured_at"],"2026-01-19T16:00:00"),save=True)
        before=self.path.read_bytes()
        with self.assertRaisesRegex(ValueError,"UTC offset"):
            run_workbook(self.path)
        self.assertEqual(before,self.path.read_bytes())



if __name__=="__main__":
    unittest.main()
