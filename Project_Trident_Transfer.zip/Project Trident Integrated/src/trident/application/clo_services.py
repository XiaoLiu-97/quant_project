"""One typed model run combines funding, cashflows, CLO and portfolio analysis."""

from dataclasses import dataclass, replace
from datetime import date
from decimal import Decimal
from typing import Protocol

from trident.analysis import (
    AssetExposure, DatedCashflow, FactorMapping, LimitSpec, PortfolioAnalyzer,
    PortfolioReport, ReturnResult, ReturnStatus, moic, xirr,
)
from trident.clo.models import CloProjection, CloRunRequest, CloTerms, NoteTranche, CloOpeningState
from trident.clo.engine import DeterministicCloEngine
from trident.clo.economics import CloEconomicsMetric, report_clo_economics
from trident.clo.lifecycle import OcAssetData
from trident.clo.proceeds import PrincipalAccruedBalance, CouponProceedsAllocation, validate_coupon_proceeds_inputs
from trident.domain.models import CouponType, InterestMode, InputValidationError, OpeningCouponEntitlement, require_date, require_money
from trident.credit import CreditEventCashflowEngine, DefaultEvent, PrepaymentEvent, AssetCreditProjection

from .services import CashflowRunRequest, CashflowRunService, ProjectionResult
from .coupon_timeline import CouponTimeline


@dataclass(frozen=True)
class TridentModelRequest:
    """Model input is independent of workbook layout and external schemas.

    Monitoring phases control limit applicability. Synthetic reinvestment is
    separately authorized by its explicit policy; neither monitoring nor an
    optimization proposal commits or settles a real asset trade.
    """

    cashflow_request: CashflowRunRequest
    exposures: tuple[AssetExposure, ...]
    factor_mapping: FactorMapping | None = None
    limits: tuple[LimitSpec, ...] = ()
    clo_terms: CloTerms | None = None
    notes: tuple[NoteTranche, ...] = ()
    reinvestment_end_date: date | None = None
    credit_events: tuple[DefaultEvent | PrepaymentEvent, ...] = ()
    oc_asset_data: tuple[OcAssetData, ...] = ()
    imported_collateral: object | None = None
    portfolio_observation_dates: tuple[date, ...] = ()
    clo_opening_state: CloOpeningState | None = None
    forward_equity_value: Decimal | None = None
    equity_value_source: str = ""

    principal_accrued_balances: tuple[PrincipalAccruedBalance, ...] = ()
    coupon_proceeds_allocations: tuple[CouponProceedsAllocation, ...] = ()

    def __post_init__(self) -> None:
        if not isinstance(self.cashflow_request, CashflowRunRequest):
            raise InputValidationError("cashflow_request must be CashflowRunRequest")
        if not isinstance(self.exposures, tuple) or any(not isinstance(item, AssetExposure) for item in self.exposures):
            raise InputValidationError("exposures must be an immutable tuple of AssetExposure")
        if self.factor_mapping is not None and not isinstance(self.factor_mapping, FactorMapping):
            raise InputValidationError("factor_mapping must be FactorMapping or None")
        if not isinstance(self.limits, tuple) or any(not isinstance(item, LimitSpec) for item in self.limits):
            raise InputValidationError("limits must be an immutable tuple of LimitSpec")
        if not isinstance(self.notes, tuple) or any(not isinstance(item, NoteTranche) for item in self.notes):
            raise InputValidationError("notes must be an immutable tuple of NoteTranche")
        if self.clo_terms is not None and not isinstance(self.clo_terms, CloTerms):
            raise InputValidationError("clo_terms must be CloTerms")
        if self.reinvestment_end_date is not None:
            require_date(self.reinvestment_end_date, "reinvestment_end_date")
        if type(self.credit_events) is not tuple or any(not isinstance(row, (DefaultEvent, PrepaymentEvent)) for row in self.credit_events):
            raise InputValidationError("credit_events must be an immutable tuple of explicit dated events")
        if len({row.loan_id for row in self.credit_events}) != len(self.credit_events):
            raise InputValidationError("Only one terminating credit/prepayment event per loan is supported")
        if type(self.oc_asset_data) is not tuple or any(not isinstance(row, OcAssetData) for row in self.oc_asset_data):
            raise InputValidationError("oc_asset_data must be an immutable tuple of OcAssetData")
        if type(self.portfolio_observation_dates) is not tuple:
            raise InputValidationError("portfolio_observation_dates must be an immutable tuple of dates")
        for observation in self.portfolio_observation_dates:
            require_date(observation, "portfolio observation date")
        if self.portfolio_observation_dates and self.clo_terms is None:
            raise InputValidationError("Additional portfolio observation dates require a CLO projection")
        if self.clo_opening_state is not None:
            if not isinstance(self.clo_opening_state, CloOpeningState) or self.clo_terms is None:
                raise InputValidationError("Existing CLO opening requires typed state and original CloTerms")
            require_money(self.forward_equity_value, "forward_equity_value", positive=True)
            if not isinstance(self.equity_value_source, str) or not self.equity_value_source.strip():
                raise InputValidationError("Existing CLO forward equity valuation source is required")
            if self.imported_collateral is not None:
                raise InputValidationError("Existing CLO opening currently requires native identified assets")
            if self.clo_terms.incentive_fee_enabled:
                raise InputValidationError("Existing incentive fees require an explicit historical hurdle account; not yet supported")
        elif self.forward_equity_value is not None or self.equity_value_source:
            raise InputValidationError("Forward equity valuation requires an existing CLO opening state")
        # Purchased accrued cost, opening coupon ownership, and principal
        # funding are separate inputs. Classification is activated explicitly
        # and must be supported by the same identified holding, not inferred
        # from purchase price or a ledger account chosen for settlement.
        if self.principal_accrued_balances or self.coupon_proceeds_allocations:
            if self.clo_terms is None or self.imported_collateral is not None:
                raise InputValidationError("Coupon proceeds classification requires native identified assets and CloTerms")
            positions = self.cashflow_request.positions
            dates = {row.par_as_of_date for row in positions}
            if len(dates) != 1:
                raise InputValidationError("Coupon proceeds classification requires one common nonempty opening snapshot")
            opening_date = next(iter(dates))
        else:
            # Validate empty collections too: malformed lists or orphan
            # allocation types cannot silently disappear in a cashflow-only run.
            opening_date = (self.clo_opening_state.as_of_date if self.clo_opening_state is not None
                            else self.cashflow_request.positions[0].par_as_of_date
                            if self.cashflow_request.positions else date.min)
        validate_coupon_proceeds_inputs(
            self.principal_accrued_balances, self.coupon_proceeds_allocations,
            as_of_date=opening_date,
        )
        held = {row.terms.loan_id: row for row in self.cashflow_request.positions}
        paid = {row.loan_id: row.accrued_interest for row in self.cashflow_request.purchases}
        for balance in self.principal_accrued_balances:
            if balance.loan_id not in held:
                raise InputValidationError("Principal accrued balance identifies an unknown opening loan")
            position = held[balance.loan_id]
            if self.clo_opening_state is None:
                cap = paid.get(balance.loan_id, Decimal(0))
                if balance.amount > cap:
                    raise InputValidationError("Principal accrued balance exceeds the identified closing purchased accrued cost")
            else:
                state = position.seasoned_state
                if (state is None or state.entitlement_policy is OpeningCouponEntitlement.POST_ASOF_ONLY
                        or balance.amount > state.opening_accrued_interest):
                    raise InputValidationError("Existing principal accrued balance requires a sufficient positive sourced opening coupon entitlement")
        claimed_ids = {balance.loan_id for balance in self.principal_accrued_balances}
        if any(isinstance(row, DefaultEvent) and row.loan_id in claimed_ids for row in self.credit_events):
            raise InputValidationError("Default allocation for a principal-accrued claimed loan requires an explicit loss/recovery policy")


@dataclass(frozen=True)
class TridentModelResult:
    """Complete run evidence, keeping contractual and stressed receipts apart.

    ``cashflows`` remains the contractual reference even under credit stress;
    the CLO and credit projections contain actual scenario receipts. Investor
    returns use actual equity funding/distributions, not stated equity nominal.
    """
    cashflows: ProjectionResult
    opening_portfolio: PortfolioReport
    portfolio_snapshots: tuple[PortfolioReport, ...]
    clo: CloProjection | None
    equity_cashflows: tuple[DatedCashflow, ...]
    equity_irr: ReturnResult
    equity_moic: ReturnResult
    credit_projections: tuple[AssetCreditProjection, ...] = ()
    portfolio_observations: tuple[PortfolioReport, ...] = ()
    clo_opening_state: CloOpeningState | None = None
    equity_value_source: str = ""
    economics: tuple[CloEconomicsMetric, ...] = ()


class ModelProjectionRunner(Protocol):
    """Minimal full-model boundary shared by scenarios and candidate searches.

    Normal, measured and safely cached runners compose through this interface;
    consumers need no inheritance or access to each runner's internal state.
    """

    def run(self, request: TridentModelRequest) -> TridentModelResult:
        """Compute funding, contractual cashflows, CLO accounts and returns."""
        ...


class TridentModelService:
    """Shared orchestration for Excel, examples, structuring and future scenarios."""

    def run(self, request: TridentModelRequest) -> TridentModelResult:
        """Project funding/loans, bind analytics, apply credit, distribute cash.

        Native exposure coefficients must match the projected contracts before
        they enter tests or reports. Imported sources have an explicit separate
        validation path. A complete terminal state is required for equity IRR;
        outstanding claims cannot become an assumed terminal liquidation.
        """
        if not isinstance(request, TridentModelRequest):
            raise TypeError("request must be TridentModelRequest")
        # One identity index serves both ownership validation and receipt
        # transport. Re-scanning every holding for every purchase is quadratic
        # and obscures that both decisions use the same seasoned-state evidence.
        seasoned_ids = {position.terms.loan_id for position in request.cashflow_request.positions
                        if position.seasoned_state is not None}
        if (request.clo_terms is not None and request.clo_terms.adjusted_oc_policy is None
                and any(row.accrued_interest != 0 and row.loan_id not in seasoned_ids
                    for row in request.cashflow_request.purchases)):
            raise InputValidationError(
                "Full CLO projection requires zero acquired accrued interest at its opening accrual boundary; "
                "nonzero accrued needs an explicit inherited-coupon receivable/entitlement state. "
                "Standalone funding and cashflow-only cost calculations remain supported."
            )
        existing = request.clo_opening_state is not None
        projection = CashflowRunService().run(request.cashflow_request, existing_clo=existing)
        positions = request.cashflow_request.positions
        # Bind analytical labels to the same economic holdings used by the
        # engine. Otherwise a plausible WAS or concentration could describe a
        # different pool from the one whose cash funds the waterfall.
        held = {position.terms.loan_id: (position.opening_balance, position.terms.currency) for position in positions}
        exposed = {asset.loan_id: (asset.par, asset.currency) for asset in request.exposures}
        if len(exposed) != len(request.exposures) or exposed != held:
            raise InputValidationError("Analysis exposure identities/par/currencies must match the opening positions")
        by_id = {asset.loan_id: asset for asset in request.exposures}
        verified_exposures = []
        for position in positions:
            loan, exposure = position.terms, by_id[position.terms.loan_id]
            expected_spread = loan.spread_bps if loan.coupon_type is CouponType.FLOATING else None
            if exposure.maturity_date != loan.maturity_date or exposure.spread_bps != expected_spread:
                raise InputValidationError("Analysis maturity/spread must match projected loan terms")
            if exposure.coupon_type is not None and exposure.coupon_type is not loan.coupon_type:
                raise InputValidationError("Analysis coupon type must match projected loan terms")
            expected_fixed = loan.fixed_rate if loan.coupon_type is CouponType.FIXED else None
            if exposure.fixed_coupon_rate is not None and exposure.fixed_coupon_rate != expected_fixed:
                raise InputValidationError("Analysis fixed coupon must match projected loan terms")
            contractual_pik = loan.interest_mode is not InterestMode.CASH
            if request.imported_collateral is None and exposure.is_pik is not None and exposure.is_pik != contractual_pik:
                raise InputValidationError("Analysis PIK classification must match projected native loan terms")
            # Native contracts establish coupon scope independently of metadata.
            # Active external sources must establish their own coupon attributes.
            verified_exposures.append(replace(exposure, coupon_type=loan.coupon_type,
                                             fixed_coupon_rate=expected_fixed,
                                             is_pik=contractual_pik if request.imported_collateral is None else exposure.is_pik))
        request = replace(request, exposures=tuple(verified_exposures))
        # Opening coefficients remain bound to the base contract above. Native
        # dated quality then follows the same step policy/schedule as coupon
        # entitlement; imported active sources cannot inherit dormant terms.
        coupon_timeline = (CouponTimeline(positions)
                           if request.imported_collateral is None else None)
        analyzer = PortfolioAnalyzer()
        if request.imported_collateral is not None:
            from .portfolio_snapshots import build_opening_portfolio
            opening = build_opening_portfolio(request.exposures, projection.cashflows, projection.projection_start_date,
                factor_mapping=request.factor_mapping, limits=request.limits,
                imported_collateral=request.imported_collateral,
                legal_final_date=None if request.clo_terms is None else request.clo_terms.legal_final_date)
        else:
            opening_exposures = (coupon_timeline.at(request.exposures, projection.projection_start_date)
                                 if coupon_timeline is not None else request.exposures)
            opening = analyzer.analyze(opening_exposures, projection.projection_start_date,
                projection.cashflows, request.factor_mapping, request.limits, "CLOSING",
                legal_final_date=(request.clo_terms.legal_final_date if request.clo_terms is not None
                    and request.clo_terms.adjusted_oc_policy is not None else None))
        # Preserve contractual rows for diagnosis. Explicit default/prepayment
        # creates scenario receipts/par movements; it never rewrites the loan
        # contract or adds hypothetical defaulted coupon to available cash.
        credit_projections = ()
        if request.credit_events:
            events_by_id = {row.loan_id: row for row in request.credit_events}
            if not events_by_id.keys() <= held.keys():
                raise InputValidationError("Credit event refers to an unknown loan_id")
            grouped = {position.terms.loan_id: [] for position in positions}
            for row in projection.cashflows:
                grouped[row.loan_id].append(row)
            engine = CreditEventCashflowEngine(request.cashflow_request.rate_provider)
            credit_projections = tuple(engine.apply(position, tuple(grouped[position.terms.loan_id]),
                                                    events_by_id.get(position.terms.loan_id)) for position in positions)
            opening = replace(opening, metrics=tuple(
                replace(metric, message=f"Contractual reference before credit events. {metric.message}".rstrip())
                if metric.name == "WAL_YEARS" else metric for metric in opening.metrics
            ))
        unavailable = ReturnResult(ReturnStatus.UNAVAILABLE, None, "CLO projection was not selected")
        if request.clo_terms is None:
            if request.notes:
                raise InputValidationError("notes require explicit clo_terms")
            return TridentModelResult(projection, opening, (), None, (), unavailable, unavailable, credit_projections)
        terms = request.clo_terms
        if terms.incentive_fee_enabled:
            terms = replace(terms, incentive_initial_equity_funding=projection.funding.equity_cash_funding)
        if any(position.terms.currency != "EUR" for position in positions):
            raise InputValidationError("EUR CLO requires EUR assets; standalone cashflow mode supports single-currency USD/GBP")
        opening_date = request.clo_opening_state.as_of_date if existing else terms.closing_date
        if opening_date != projection.projection_start_date:
            raise InputValidationError("CLO closing date must equal the common opening portfolio snapshot")
        expected_reserve = request.clo_opening_state.reserve if existing else terms.initial_reserve
        if expected_reserve != request.cashflow_request.cash_reserve:
            raise InputValidationError("CLO reserve must reconcile to funded closing reserve")
        note_balances = {note.class_id: note.opening_balance for note in request.notes if note.opening_balance != 0}
        issue_balances = {issue.class_id: issue.par for issue in request.cashflow_request.issues}
        if note_balances != issue_balances or (not existing and len(note_balances) != len(request.notes)):
            raise InputValidationError("CLO notes must reconcile to funded debt issues")
        if request.reinvestment_end_date is not None and request.reinvestment_end_date <= terms.closing_date:
            raise InputValidationError("reinvestment_end_date must follow closing_date")
        clo_request = CloRunRequest(
            () if request.imported_collateral is not None else projection.cashflows,
            projection.opening_collateral_par, request.notes, terms, credit_projections,
            oc_asset_data=request.oc_asset_data, imported_collateral=request.imported_collateral,
            acquired_accrued_by_loan={row.loan_id: row.accrued_interest for row in request.cashflow_request.purchases
                if row.accrued_interest != 0 and row.loan_id not in seasoned_ids} if request.clo_terms.adjusted_oc_policy is not None
                    and request.imported_collateral is None else None,
            asset_day_counts={position.terms.loan_id: position.terms.day_count for position in positions}
                if request.imported_collateral is None else None,
            opening_state=request.clo_opening_state,
            principal_accrued_balances=request.principal_accrued_balances,
            coupon_proceeds_allocations=request.coupon_proceeds_allocations,
        )
        clo = DeterministicCloEngine(request.cashflow_request.rate_provider).run(clo_request)
        # Existing equity is valued at the opening snapshot. This is a forward
        # return from an explicit mark, not since-inception IRR or new issuance.
        initial_value = request.forward_equity_value if existing else projection.funding.equity_cash_funding
        investor = (DatedCashflow(opening_date, initial_value.copy_negate()),
                    *(DatedCashflow(row.payment_date, row.amount) for row in clo.equity_cashflows),
                    *(DatedCashflow(row.payment_date, row.amount.copy_negate()) for row in clo.equity_contributions))
        if clo.terminal_value_available:
            irr, multiple = xirr(investor), moic(investor)
        else:
            message = f"Unresolved CLO state: {clo.status.value}; no assumed terminal liquidation"
            irr = multiple = ReturnResult(ReturnStatus.UNAVAILABLE, None, message)
        # One dated holding ledger serves native, credit, overlay, imported and
        # synthetic sources. Extra quality dates never create a distribution
        # or another OC/IC waterfall gate. This removes two subtly different
        # implementations of the same held-par monitoring responsibility.
        from .portfolio_observations import build_portfolio_observations
        observations = build_portfolio_observations(
            request.exposures, projection.cashflows, clo,
            closing_date=opening_date,
            additional_dates=request.portfolio_observation_dates,
            factor_mapping=request.factor_mapping, limits=request.limits,
            reinvestment_end_date=request.reinvestment_end_date,
            credit_projections=credit_projections,
            original_overlay_projection=clo.original_overlay_projection,
            reinvestment_policy=terms.synthetic_reinvestment_policy,
            imported_collateral=request.imported_collateral,
            legal_final_date=terms.legal_final_date,
            coupon_timeline=coupon_timeline,
        )
        # Preserve payment-date consumers as a subset of those same reports,
        # rather than projecting or reconstructing the holdings a second time.
        payment_dates = {period.payment_date for period in clo.periods}
        snapshots = tuple(report for report in observations if report.as_of_date in payment_dates)
        return TridentModelResult(projection, opening, snapshots, clo, investor,
                                  irr, multiple, credit_projections, observations,
                                  request.clo_opening_state, request.equity_value_source,
                                  report_clo_economics(clo_request, clo, projection.funding))
