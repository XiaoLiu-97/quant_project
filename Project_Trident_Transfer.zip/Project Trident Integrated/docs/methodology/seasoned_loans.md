# Seasoned cash-pay loans

Project Trident can project a verified performing loan held part-way through its original coupon period. This supports standalone asset cashflows, collateral bought for a newly closing CLO, and closing-pool redesign with seasoned candidate BSLs. Loan state alone does not initialize an already operating CLO's debt, arrears, cash accounts or unsettled trades; the separate [post-distribution CLO opening profile](existing_clo_opening.md) explicitly supplies that supported state.

## Original contract time axis

`LoanTerms.start_date` remains the original known schedule anchor. It is not moved to the trade or settlement date. `LoanPosition.par_as_of_date` identifies the opening held-par snapshot; `opening_balance` is the performing principal actually held at that snapshot. When as-of follows the original start, `SeasonedLoanState` is mandatory.

The model builds the original cash/reset schedules once, selects actual payments strictly after as-of, and clips only the first forward accrual start. Original nominal boundaries, fixing dates, reset intervals and principal installment indices remain intact. A semiannual reset may therefore remain binding after an intervening quarterly coupon has already been paid. The as-of state is post-settlement: scheduled receipts on that date have already occurred and are excluded.

```mermaid
flowchart LR
    A[Original contract and schedule anchor] --> B[Original payment and reset grids]
    C[Opening held par and as-of] --> D[Future payments and clipped first accrual]
    B --> D
    E[Verified entitlement policy and carried fixings] --> F[Exact unpaid opening claim]
    B --> F
    D --> G[Exact forward coupon factors]
    F --> H[One combined monetary posting]
    G --> H
    H --> I[Contractual receipts and original principal strategy]
    I --> J[Credit scenarios and CLO waterfall]
```

## First unpaid coupon ownership

The coupon received from the borrower and the accrued price paid to a seller are separate inputs. The entitlement policy must match the verified agent statement or allocation agreement. Its Python default is `FULL_CURRENT_PERIOD`; this default is a modeling choice, not a claim that every loan trade uses the same settlement convention.

| Policy | Opening claim | First unpaid coupon |
| --- | --- | --- |
| `FULL_CURRENT_PERIOD` | Posted amount must equal the exact original-period earned prefix rounded to cents | Exact historical prefix plus exact forward accrual, posted once |
| `POST_ASOF_ONLY` | Explicit zero | Forward accrual only; historical coupon ownership is excluded |
| `EXPLICIT_CASH_CLAIM` | Verified signed cent amount from an allocation agreement | Agreed cent claim plus exact forward accrual, posted once |

Under `FULL_CURRENT_PERIOD`, the input posted amount is an audit check. It is not the monetary amount added to future interest. Even an input of `0.00` can represent a positive exact sub-cent historical entitlement. Under `POST_ASOF_ONLY`, zero means no historical entitlement. Under `EXPLICIT_CASH_CLAIM`, zero is the actual agreed cash allocation.

`SeasonedLoanState.provenance` must identify the source of the entitlement. A string records the source but does not independently prove ownership. Verification of the statement and settlement agreement remains necessary before using a real portfolio.

### One posting avoids a one-cent error

For 100 par, fixed 12%, ACT/360, an original Apr 1–Jul 1 coupon and May 15 as-of:

- Historical prefix: 44 days, `100 × 12% × 44/360 = 22/15`, posted audit claim **1.47**.
- Forward remainder: 47 days, `100 × 12% × 47/360 = 47/30`.
- Full ownership: `22/15 + 47/30 = 91/30`, posted once to **3.03**.

Adding the rounded historical component 1.47 instead would post 3.04. `FULL_CURRENT_PERIOD` prevents that error. `EXPLICIT_CASH_CLAIM` deliberately produces 3.04 if the verified agreement grants an exact 1.47 cash claim. `POST_ASOF_ONLY` produces 1.57. These are different ownership instructions.

### Holding resizing also uses the exact source

For the same loan resized from 100 to 50 par, the exact historical prefix is `11/15`, so its posted audit claim is **0.73** and its full coupon is **1.52**. Scaling the previous posted 1.47 by 50% would incorrectly create a 0.74 claim. `resize_seasoned_state(position, ratio)` recalculates the exact original claim before scaling; it requests no market observations.

An explicit agreed 1.47 cash claim instead scales to 0.74 under `EXPLICIT_CASH_CLAIM`. Scenario and closing-redesign resizes create independent target portfolios. They are not a settlement ledger for dividing the same executed trade into retained and sold lots; a later executed-lot ledger must conserve any allocation residual across both sides.

## Carried fixing requirements

`OpeningFixing(fixing_date, index_rate)` contains the original contractual fixing date and the raw annual reference rate. Margin and all reference/all-in floors and caps remain in `LoanTerms`. Zero and negative raw observations are valid. Fixed-rate loans have no opening reference fixings.

For floating loans, the supplied tuple must contain exactly the known original fixing dates needed by the remaining entitlement. Missing, duplicate, mutable or irrelevant observations are rejected. A future reset can already have fixed by as-of because of its fixing lag; that known observation must also be supplied. The curve provider supplies only genuinely future observations, lazily and once per loan/fixing.

`FULL_CURRENT_PERIOD` additionally requires all historical reset observations inside the first unpaid original coupon period, including resets whose accrual segments have already ended. For monthly resets in a quarterly coupon, supplying only the currently active monthly fixing is insufficient. `POST_ASOF_ONLY` and an explicit cash claim need only the carried fixing history actually used by forward accrual.

Hand control: 100 par, Jan 1–Apr 1, as-of Mar 15, ACT/360, raw monthly reference rates 2%, 3%, 4%, each plus 300 bps:

- Full quarter: `100 × (31 × 5% + 28 × 6% + 31 × 7%)/360 = 1.50`.
- Exact historical prefix: `100 × (31 × 5% + 28 × 6% + 14 × 7%)/360 = 421/360`; audit claim **1.17**.
- Full ownership needs Jan 1, Feb 1 and Mar 1 observations. Post-as-of ownership needs only Mar 1 for the first unpaid coupon and earns **0.33** for its remaining 17 days.

Candidate-universe observations may not be later than the frozen snapshot's capture calendar date. A prior-day frozen snapshot cannot contain an actual settlement-day fixing. Date-only observation metadata does not establish an intraday publication cutoff.

## Principal, credit and funding

Original fixed and accelerating principal installments retain their source indices after past receipts are removed. They are not restarted at period one. `BESPOKE` requires an explicit remaining schedule summing exactly to current held par; positive installments on already settled dates are rejected. Bullet principal remains due on the original final actual payment date.

A prepayment before the first scheduled receipt collects the retained exact opening claim plus earned forward coupon once, subject to the selected ownership policy. Default forfeits unpaid opening and forward coupon; neither is manufactured as cash or principal recovery. Fractional credit scenarios scale the same combined exact entitlement by the surviving slice before one coupon posting. Same-day scheduled actual receipts execute before a terminating credit event acts on the remaining principal.

`AssetPurchase.accrued_interest` is settlement funding cost. It does not reset the borrower coupon, prove ownership, or create another receipt for an explicitly seasoned position. The funding amount may differ from the retained claim. Equity returns include the actual initial acquisition cost and the independently verified future coupon entitlement.

### Borrower coupon and CLO proceeds classification

Native coupon defaults to interest proceeds when no explicit classification records are supplied. The [principal-funded coupon proceeds profile](coupon_proceeds.md) can instead restore one verified remaining principal-accrued balance from its unique first positive native coupon. It preserves full borrower ownership and raw cash, assigns the supplied cent restoration to principal, and leaves the gross-coupon residual as interest. With gross3.03 and a verified1.47 restoration, that residual is1.56; the engine does not independently repost forward-earned coupon and create another cent. Cost, retained entitlement and classified balance remain separate sourced facts.

Both closing and [existing opening](existing_clo_opening.md) can use this explicit profile, subject to its scope and matching controls. The settlement ledger's accrued funding permission still does not activate receipt classification. Partial/default/sale-accrued and future lot policies remain unsupported; affected IC/OC and account stages need transaction benchmarks. Active sourced instructions reject automatic what-if/optimization resizing rather than silently rebinding a legal receipt.

## Supported profile and explicit boundaries

The current native profile assumes a verified performing cash-pay holding with constant surviving slice principal during the active original coupon period. It does not infer earlier repayments, defaults, PIK, ownership changes or unsettled receivables from a clean price. As-of must be before nominal maturity.

- Supported principal policies: `BULLET`, explicit scheduled/fixed principal, `LINEAR_INITIAL_PAR`, `ACCELERATED`, and a reconciled remaining `BESPOKE` schedule.
- `ANNUITY`, `LINEAR_AUTO` and `ACCELERATED_AUTO` are rejected for seasoned positions; current held par cannot safely reconstruct an original recast or calibration.
- An ended but unpaid first coupon requires a separate receivable profile and is rejected. A lagged payment cannot silently be treated as a new active accrual interval.
- Mid-period splits support additive ACT/360, ACT/365F, ACT/ACT.ISDA and 30E/360. Non-additive 30/360.ISDA and 30U/360.EOM need a contract-specific allocation rule and are rejected mid-period.
- Historical coupon steps with `effective_date <= as_of` are rejected for this profile. Future verified steps remain supported, using their original actual-date or deferred-boundary policy. Historical steps need a fuller current-quote and period-history binding before admission; moving their dates or blindly rebasing margin is not a valid workaround.
- `FULL_CURRENT_PERIOD` what-if permits clean-price changes and independent par resizing. Replacing base rate, bounds or maturity/schedule history is rejected, even if the revised earned prefix happens to round to the same cent. Future rate changes belong in verified future dated coupon steps. Day count, reset frequency and original anchors remain original contract inputs.
- Initial defaulted collateral, overdue coupon recovery and an existing CLO's initial account/liability state remain separate workflows; this extension establishes none of those states.

## Code and validation

Public inputs are in `trident.domain.models`: `SeasonedLoanState`, `OpeningFixing`, `OpeningCouponEntitlement`, and `LoanPosition.seasoned_state`. The shared resolver in `trident.cashflows.seasoned` builds the original/projected schedules, seeds carried fixings, resolves exact claims and resizes holdings. Contractual and credit engines consume the same resolver. Closing-redesign and what-if resizes call the same exact claim helper.

The first `LoanCashflow` retains `opening_accrued_interest` as its posted audit amount and `opening_accrued_exact` as a `Fraction`; later rows contain zero for both. Rate/DCF diagnostics describe forward accrual, while the cash receipt can also contain retained history. A formula multiplying only displayed forward rate, DCF and par therefore does not reproduce a full-ownership first coupon. The exact claim is added before monetary posting.

Independent tests in `tests/test_seasoned_cashflows.py` and `tests/test_seasoned_clo_integration.py` control exact/posted rounding, monthly and carried future fixings, source chronology, original installments, same-day settlement, credit forfeiture/prepayment, hostile Decimal contexts, par resizing, funding and first equity distributions. These are reproducible hand controls, rather than validation against the implementation's own generated outputs.

## Primary references and interpretation

The [Disney credit agreement](https://www.sec.gov/Archives/edgar/data/1744489/000119312524057958/d759203dex102.htm), sections 2.06(a)(iii) and 2.13(a)–(c), distinguishes an existing EURIBOR interest period, coupon payment timing, assignment-effective-date payments and direct adjustments between assignor and assignee. It also supplies an actual-day start-inclusive/end-exclusive convention and business-day payment adjustment. This is a contract example supporting separation of the time axes and ownership allocation, not evidence of a universal BSL convention.

The [SEC-filed assignment agreement](https://www.sec.gov/Archives/edgar/data/1005286/000143774912004220/ex10-1.htm), section 6, explicitly allocates amounts accrued before and after the effective date. The exact borrower receipt and the cash exchanged between trading parties therefore need separate contract verification. [FpML's loan-trading accrual settlement field](https://www.fpml.org/spec/fpml-5-11-3-lcwd-1/html/confirmation/schemaDocumentation/schemas/fpml-loan-5-11_xsd/groups/LoanTradingCounterpartyCashSettlementRules.model/accrualSettlementType.html) also distinguishes accrued-settlement instructions. Project Trident exposes ownership policies so those instructions are supplied explicitly rather than inferred from market price.

The engineering rule to retain exact factors until final currency posting is independently illustrated by the hand controls above. It preserves the original borrower coupon under full-period ownership; it does not assert that every legal settlement agreement uses the same rounding or allocation rule.
