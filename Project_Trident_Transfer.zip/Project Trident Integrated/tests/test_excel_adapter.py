"""Named-range boundaries, relocation and safe variable-length writeback."""

import unittest
from decimal import Decimal

from openpyxl import Workbook
from openpyxl.workbook.defined_name import DefinedName
from openpyxl.worksheet.table import Table

from trident.adapters.excel import NamedWorkbook


class NamedWorkbookTests(unittest.TestCase):
    def test_optional_columns_extend_named_table_idempotently(self):
        added = self.adapter.ensure_optional_columns("trident_values", "tbl_values", {"index_cap_bps": "0.00"})
        self.assertEqual(added, ("index_cap_bps",))
        self.assertEqual(self.sheet.tables["tbl_values"].ref, "B12:D13")
        self.assertEqual(self.adapter.table_records("trident_values", "tbl_values"),
                         ({"loan_id": "L1", "cash_interest": 1.25, "index_cap_bps": None},))
        self.sheet["D13"] = 0
        self.assertEqual(self.adapter.ensure_optional_columns("trident_values", "tbl_values", {"index_cap_bps": "0.00"}), ())
        self.assertEqual(self.sheet["D13"].value, 0)
        self.assertEqual(self.sheet["D7"].value, 25)

    def test_optional_columns_preserve_structured_name_and_empty_table(self):
        self.adapter.write_table("trident_values", "tbl_values", ())
        self.workbook.defined_names["trident_values"].attr_text = "tbl_values[#All]"
        self.adapter.ensure_optional_columns("trident_values", "tbl_values", {"all_in_cap_bps": "0.00"})
        self.assertEqual(self.workbook.defined_names["trident_values"].attr_text, "tbl_values[#All]")
        self.assertEqual(self.adapter.table_records("trident_values", "tbl_values"), ())

    def test_optional_columns_reject_adjacent_data_and_metadata_conflicts(self):
        self.sheet["D13"] = "user note"
        with self.assertRaisesRegex(ValueError, "adjacent"):
            self.adapter.ensure_optional_columns("trident_values", "tbl_values", {"all_in_cap_bps": "0.00"})
        self.assertEqual(self.sheet.tables["tbl_values"].ref, "B12:C13")
        self.assertEqual(self.sheet["D13"].value, "user note")
        self.sheet["D13"] = None
        with self.assertRaisesRegex(ValueError, "casing"):
            self.adapter.ensure_optional_columns("trident_values", "tbl_values", {"LOAN_ID": "0.00"})
        self.sheet.tables["tbl_values"].tableColumns[0].name = "wrong"
        with self.assertRaisesRegex(ValueError, "metadata"):
            self.adapter.ensure_optional_columns("trident_values", "tbl_values", {"all_in_cap_bps": "0.00"})

    def test_optional_columns_reject_protected_regions_and_merges(self):
        self.workbook.defined_names.add(DefinedName("neighbour", attr_text="'Flexible Layout'!$D$13"))
        with self.assertRaisesRegex(ValueError, "protected"):
            self.adapter.ensure_optional_columns("trident_values", "tbl_values", {"all_in_cap_bps": "0.00"}, protected_names=("neighbour",))
        self.sheet.merge_cells("D12:D13")
        with self.assertRaisesRegex(ValueError, "merged"):
            self.adapter.ensure_optional_columns("trident_values", "tbl_values", {"all_in_cap_bps": "0.00"})

    def setUp(self) -> None:
        self.workbook = Workbook()
        self.sheet = self.workbook.active
        self.sheet.title = "Flexible Layout"
        self.sheet["D7"] = 25
        self.workbook.defined_names.add(DefinedName("trident_parameter", attr_text="'Flexible Layout'!$D$7"))
        self.sheet.append([])
        self.sheet["B12"] = "loan_id"
        self.sheet["C12"] = "cash_interest"
        self.sheet["B13"] = "L1"
        self.sheet["C13"] = 1.25
        table = Table(displayName="tbl_values", ref="B12:C13")
        table._initialise_columns()
        for column, name in zip(table.tableColumns, ("loan_id", "cash_interest")):
            column.name = name
        self.sheet.add_table(table)
        self.workbook.defined_names.add(DefinedName("trident_values", attr_text="'Flexible Layout'!$B$12:$C$13"))
        self.adapter = NamedWorkbook(self.workbook)

    def test_scalar_uses_name_after_relocation(self) -> None:
        self.assertEqual(self.adapter.scalar("trident_parameter"), 25)
        self.sheet["F19"] = 36
        self.workbook.defined_names["trident_parameter"].attr_text = "'Flexible Layout'!$F$19"
        self.assertEqual(self.adapter.scalar("trident_parameter"), 36)
        self.adapter.write_scalar("trident_parameter", Decimal("42.5"))
        self.assertEqual(self.sheet["F19"].value, 42.5)
        self.assertEqual(self.sheet["D7"].value, 25)

    def test_missing_invalid_and_local_shadow_fail(self) -> None:
        with self.assertRaises(ValueError):
            self.adapter.scalar("missing")
        self.sheet.defined_names.add(DefinedName("TRIDENT_PARAMETER", attr_text="'Flexible Layout'!$A$1"))
        with self.assertRaises(ValueError):
            self.adapter.scalar("trident_parameter")
        self.sheet.defined_names.clear()
        self.workbook.defined_names["trident_parameter"].attr_text = "#REF!"
        with self.assertRaises(ValueError):
            self.adapter.scalar("trident_parameter")

    def test_formulas_and_multicell_scalars_are_not_inputs(self) -> None:
        self.sheet["D7"] = "=1+2"
        with self.assertRaisesRegex(ValueError, "paste input values"):
            self.adapter.scalar("trident_parameter")
        self.workbook.defined_names["trident_parameter"].attr_text = "'Flexible Layout'!$D$7:$D$8"
        with self.assertRaises(ValueError):
            self.adapter.scalar("trident_parameter")

    def test_table_records_use_headers_and_registered_rectangle(self) -> None:
        records = self.adapter.table_records("trident_values", "tbl_values")
        self.assertEqual(records, ({"loan_id": "L1", "cash_interest": 1.25},))
        self.workbook.defined_names["trident_values"].attr_text = "tbl_values[#All]"
        self.assertEqual(self.adapter.table_records("trident_values", "tbl_values"), records)
        self.workbook.defined_names["trident_values"].attr_text = "'Flexible Layout'!$B$12:$C$15"
        with self.assertRaisesRegex(ValueError, "out of sync"):
            self.adapter.table_records("trident_values", "tbl_values")

    def test_resize_then_shrink_clears_stale_results_and_syncs_names(self) -> None:
        records = tuple({"loan_id": f"L{i}", "cash_interest": Decimal(i)} for i in range(4))
        self.adapter.write_table("trident_values", "tbl_values", records)
        self.assertEqual(self.sheet.tables["tbl_values"].ref, "B12:C16")
        self.assertEqual(len(self.adapter.table_records("trident_values", "tbl_values")), 4)
        self.adapter.write_table("trident_values", "tbl_values", records[:1])
        self.assertEqual(self.sheet.tables["tbl_values"].ref, "B12:C13")
        self.assertIsNone(self.sheet["B16"].value)

    def test_blank_table_and_formula_like_identifier(self) -> None:
        self.adapter.write_table("trident_values", "tbl_values", ())
        self.assertEqual(self.adapter.table_records("trident_values", "tbl_values"), ())
        self.adapter.write_table("trident_values", "tbl_values", ({"loan_id": "=NOT_A_FORMULA()", "cash_interest": 0},))
        self.assertEqual(self.sheet["B13"].data_type, "s")

    def test_expansion_rejects_overwriting_neighbour_and_schema_mismatch(self) -> None:
        self.sheet["C14"] = "keep"
        records = ({"loan_id": "L1", "cash_interest": 1}, {"loan_id": "L2", "cash_interest": 2})
        with self.assertRaisesRegex(ValueError, "overwrite"):
            self.adapter.write_table("trident_values", "tbl_values", records)
        self.assertEqual(self.sheet["C14"].value, "keep")
        with self.assertRaisesRegex(ValueError, "schema"):
            self.adapter.write_table("trident_values", "tbl_values", ({"loan_id": "L1"},))


if __name__ == "__main__":
    unittest.main()
