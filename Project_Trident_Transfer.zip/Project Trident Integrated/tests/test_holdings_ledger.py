"""Independent operating cash/face ledgers, not optimizer-generated expectations.

Numbers are small hand ledgers: clean consideration, accrued and fees post to
separate accounts, commitments move no cash, and claims cannot self-pay. Tests
also exercise hostile Decimal contexts, same-day ordering and opening history.
"""

from dataclasses import FrozenInstanceError, replace
from datetime import date, datetime
from decimal import Decimal, Inexact, localcontext
from fractions import Fraction
import unittest

from trident.domain.models import InputValidationError
from trident.portfolio import (
    CashAccount, CashBalances, CashReceivable, HoldingStatus, HoldingsLedgerRequest,
    HoldingsLedgerService, LedgerEvent, LedgerEventKind, LedgerPermissions,
    OpeningHolding, TradeCommitment, TradeSide,
)

D = Decimal
A = date(2026, 1, 1)
B = date(2026, 1, 2)
C = date(2026, 1, 3)
E = date(2026, 1, 5)


def trade(side=TradeSide.BUY, *, trade_id="T", asset_id="X", trade_date=B, settlement_date=C, **changes):
    return TradeCommitment(trade_id, asset_id, side, trade_date, settlement_date, D("100"), D("99"), **changes)


def request(*, holdings=(), cash=None, trades=(), events=(), **changes):
    return HoldingsLedgerRequest(A, E, "EUR", cash or CashBalances(D("100"), D("10")), holdings,
                                trades=trades, events=events, **changes)


def run(**kwargs):
    return HoldingsLedgerService().replay(request(**kwargs))


def event(kind, day=B, *, event_id="E", asset_id="X", **changes):
    return LedgerEvent(event_id, day, kind, "VERIFIED_ACTUAL_RECEIPT", asset_id=asset_id, **changes)


class HoldingsLedgerTests(unittest.TestCase):
    def test_actual_cash_payments_reduce_accounts_without_changing_holdings(self):
        payment = LedgerEvent("PAY", B, LedgerEventKind.CASH_PAYMENT, "ACTUAL_TRUSTEE_PAYMENTS", principal_cash=D("20"), interest_cash=D("3"))
        result = run(holdings=(OpeningHolding("X", "EUR", D("100")),), events=(payment,))
        self.assertEqual(result.final_snapshot.cash, CashBalances(D("80"), D("7")))
        self.assertEqual(result.final_snapshot.settled_par, 100)
        self.assertEqual(result.journal[0].principal_cash_change, -20)

    def test_collections_precede_same_day_actual_payment_and_commitments(self):
        receipt = event(LedgerEventKind.CASH_COLLECTION, principal_cash=D("110"), par_reduction=D("100"))
        payment = LedgerEvent("PAY", B, LedgerEventKind.CASH_PAYMENT, "ACTUAL_DEBT_PAYMENTS", principal_cash=D("11"))
        result = run(holdings=(OpeningHolding("X", "EUR", D("100")),), cash=CashBalances(),
                     events=(payment, receipt), trades=(trade(asset_id="Y"),))
        self.assertEqual(result.final_snapshot.cash.principal, 0)
        self.assertEqual([row.kind for row in result.journal][:3], ["CASH_COLLECTION", "CASH_PAYMENT", "COMMIT"])

    def test_payments_cannot_spend_other_account_or_encumbered_cash(self):
        payment = LedgerEvent("PAY", C, LedgerEventKind.CASH_PAYMENT, "ACTUAL_PAYMENT", principal_cash=D("2"))
        with self.assertRaisesRegex(InputValidationError, "encumbered"):
            run(trades=(trade(settlement_date=E),), events=(payment,))
        with self.assertRaisesRegex(InputValidationError, "specified account"):
            run(cash=CashBalances(D("0"), D("100")), events=(payment,))

    def test_buy_commits_then_settles_clean_accrued_and_fees(self):
        result = run(trades=(trade(accrued_cash=D("2"), fees_cash=D("0.50")),))
        before = next(row for row in result.snapshots if row.as_of_date == B)
        self.assertEqual(before.settled_par, 0)
        self.assertEqual(before.trade_date_par, 100)
        self.assertEqual(before.cash, CashBalances(D("100"), D("10")))
        self.assertEqual(before.reserved_cash, CashBalances(D("99"), D("2.50")))
        self.assertEqual(before.available_cash, CashBalances(D("1"), D("7.50")))
        self.assertEqual(result.final_snapshot.cash, CashBalances(D("1"), D("7.50")))
        self.assertEqual(result.final_snapshot.settled_par, 100)
        settled = next(row for row in result.journal if row.kind == "SETTLE")
        self.assertEqual((settled.clean_cash, settled.accrued_cash, settled.fee_cash), (D("-99"), D("-2"), D("-.50")))

    def test_sale_creates_claim_but_no_spendable_cash_until_settlement(self):
        result = run(holdings=(OpeningHolding("X", "EUR", D("100")),), cash=CashBalances(),
                     trades=(trade(TradeSide.SELL, accrued_cash=D("2"), fees_cash=D(".50")),))
        before = next(row for row in result.snapshots if row.as_of_date == B)
        self.assertEqual(before.cash, CashBalances())
        self.assertEqual(before.available_to_sell("X"), 0)
        self.assertEqual(before.settled_par, 100)
        self.assertEqual(before.trade_date_par, 0)
        self.assertEqual(before.pending_trades[0].settlement_receivable, CashBalances(D("99"), D("1.50")))
        self.assertEqual(result.final_snapshot.cash, CashBalances(D("99"), D("1.50")))
        self.assertEqual(result.final_snapshot.settled_par, 0)

    def test_unsettled_sale_cannot_finance_purchase(self):
        sell = trade(TradeSide.SELL, trade_id="SELL")
        buy = trade(trade_id="BUY", asset_id="Y")
        for trades in ((sell, buy), (buy, sell)):
            with self.subTest(trades=trades), self.assertRaisesRegex(InputValidationError, "unsettled sale"):
                run(holdings=(OpeningHolding("X", "EUR", D("100")),), cash=CashBalances(), trades=trades)

    def test_same_day_new_sale_and_buy_does_not_invent_dvp_netting(self):
        trades = (trade(TradeSide.SELL, trade_id="S", settlement_date=B), trade(asset_id="Y", trade_id="P", settlement_date=B))
        with self.assertRaisesRegex(InputValidationError, "Insufficient"):
            run(holdings=(OpeningHolding("X", "EUR", D("100")),), cash=CashBalances(), trades=trades)

    def test_prior_settled_sale_can_fund_new_trade_that_day(self):
        trades = (trade(TradeSide.SELL, trade_id="S"), trade(asset_id="Y", trade_id="P", trade_date=C, settlement_date=E))
        result = run(holdings=(OpeningHolding("X", "EUR", D("100")),), cash=CashBalances(), trades=trades)
        self.assertEqual(result.final_snapshot.cash, CashBalances())
        self.assertEqual(result.final_snapshot.settled_par, 100)
        self.assertEqual([row.kind for row in result.journal if row.event_date == C], ["SETTLE", "COMMIT"])

    def test_opening_commitment_reserves_without_fake_history(self):
        old = trade(trade_date=date(2025, 12, 20), settlement_date=C)
        result = run(opening_commitments=(old,))
        self.assertEqual(result.opening_snapshot.reserved_cash.principal, 99)
        self.assertEqual(result.opening_snapshot.cash.principal, 100)
        self.assertEqual([row.kind for row in result.journal], ["SETTLE"])
        self.assertEqual(result.final_snapshot.cash.principal, 1)

    def test_opening_unsettled_sale_does_not_add_historic_cash_or_remove_face(self):
        old = trade(TradeSide.SELL, trade_date=date(2025, 12, 20))
        result = run(holdings=(OpeningHolding("X", "EUR", D("100")),), cash=CashBalances(), opening_commitments=(old,))
        self.assertEqual(result.opening_snapshot.cash.principal, 0)
        self.assertEqual(result.opening_snapshot.settled_par, 100)
        self.assertEqual(result.opening_snapshot.available_to_sell("X"), 0)

    def test_opening_commitment_requires_cash_and_deliverable_face(self):
        old = trade(trade_date=date(2025, 12, 20))
        with self.assertRaisesRegex(InputValidationError, "Insufficient"):
            run(cash=CashBalances(), opening_commitments=(old,))
        with self.assertRaisesRegex(InputValidationError, "oversell"):
            run(opening_commitments=(replace(old, side=TradeSide.SELL),))

    def test_interest_cash_cannot_silently_pay_clean_purchase(self):
        with self.assertRaisesRegex(InputValidationError, "PRINCIPAL"):
            run(cash=CashBalances(D("0"), D("1000")), trades=(trade(),))

    def test_principal_accrued_and_fee_permissions_are_separate(self):
        t = trade(accrued_cash=D("2"), fees_cash=D("1"), accrued_account=CashAccount.PRINCIPAL, fee_account=CashAccount.PRINCIPAL)
        with self.assertRaisesRegex(InputValidationError, "accrued"):
            run(cash=CashBalances(D("110")), trades=(t,))
        with self.assertRaisesRegex(InputValidationError, "fees"):
            run(cash=CashBalances(D("110")), trades=(t,), permissions=LedgerPermissions(True, False))
        result = run(cash=CashBalances(D("110")), trades=(t,), permissions=LedgerPermissions(True, True))
        self.assertEqual(result.final_snapshot.cash, CashBalances(D("8")))

    def test_same_trade_same_account_fees_net_from_sale_consideration(self):
        t = trade(TradeSide.SELL, fees_cash=D("1"), fee_account=CashAccount.PRINCIPAL)
        result = run(holdings=(OpeningHolding("X", "EUR", D("100")),), cash=CashBalances(), trades=(t,), permissions=LedgerPermissions(False, True))
        self.assertEqual(result.final_snapshot.cash.principal, 98)

    def test_signed_verified_accrued_rebate_is_not_par(self):
        t = trade(accrued_cash=D("-2"))
        result = run(cash=CashBalances(D("99")), trades=(t,))
        self.assertEqual(result.final_snapshot.cash, CashBalances(D("0"), D("2")))
        self.assertEqual(result.final_snapshot.settled_par, 100)

    def test_cancel_releases_cash_and_has_no_settlement_posting(self):
        cancel = LedgerEvent("CANCEL", C, LedgerEventKind.TRADE_CANCEL, "COUNTERPARTY_CANCEL_CONFIRMED", trade_id="T")
        result = run(trades=(trade(settlement_date=E),), events=(cancel,))
        self.assertEqual(result.final_snapshot.cash, CashBalances(D("100"), D("10")))
        self.assertEqual(result.final_snapshot.reserved_cash, CashBalances())
        self.assertEqual(result.final_snapshot.settled_par, 0)
        self.assertEqual([row.kind for row in result.journal], ["COMMIT", "TRADE_CANCEL"])

    def test_cancel_on_settlement_date_precedes_dvp(self):
        cancel = LedgerEvent("CANCEL", C, LedgerEventKind.TRADE_CANCEL, "CONFIRMED", trade_id="T")
        result = run(trades=(trade(),), events=(cancel,))
        self.assertFalse(any(row.kind == "SETTLE" for row in result.journal))

    def test_same_day_new_trade_cancel_is_ambiguous_and_rejected(self):
        cancel = LedgerEvent("CANCEL", B, LedgerEventKind.TRADE_CANCEL, "CONFIRMED", trade_id="T")
        with self.assertRaisesRegex(InputValidationError, "intraday"):
            run(trades=(trade(),), events=(cancel,))

    def test_unknown_and_post_settlement_cancels_reject(self):
        for cancel in (LedgerEvent("C", B, LedgerEventKind.TRADE_CANCEL, "CONFIRMED", trade_id="MISSING"),
                       LedgerEvent("C", E, LedgerEventKind.TRADE_CANCEL, "CONFIRMED", trade_id="T")):
            with self.subTest(cancel=cancel), self.assertRaises(InputValidationError):
                run(trades=(trade(),), events=(cancel,))

    def test_multiple_sales_cannot_oversell_and_pending_buy_cannot_be_delivered(self):
        for trades in ((trade(TradeSide.SELL, trade_id="1"), trade(TradeSide.SELL, trade_id="2")),
                       (trade(asset_id="Y", trade_id="BUY"), trade(TradeSide.SELL, asset_id="Y", trade_id="SELL"))):
            with self.subTest(trades=trades), self.assertRaisesRegex(InputValidationError, "oversell"):
                run(holdings=(OpeningHolding("X", "EUR", D("100")),), trades=trades)

    def test_principal_collection_between_trade_and_settlement_requires_amendment(self):
        receipt = event(LedgerEventKind.CASH_COLLECTION, C, principal_cash=D("20"), par_reduction=D("20"))
        with self.assertRaisesRegex(InputValidationError, "pending sale unavailable"):
            run(holdings=(OpeningHolding("X", "EUR", D("100")),), trades=(trade(TradeSide.SELL, settlement_date=E),), events=(receipt,))

    def test_same_day_cancel_can_resolve_amortised_pending_sale(self):
        receipt = event(LedgerEventKind.CASH_COLLECTION, C, principal_cash=D("20"), par_reduction=D("20"))
        cancel = LedgerEvent("CANCEL", C, LedgerEventKind.TRADE_CANCEL, "CONFIRMED", trade_id="T")
        result = run(holdings=(OpeningHolding("X", "EUR", D("100")),), trades=(trade(TradeSide.SELL, settlement_date=E),), events=(cancel, receipt))
        self.assertEqual(result.final_snapshot.settled_par, 80)
        self.assertEqual(result.final_snapshot.cash.principal, 120)

    def test_receipts_precede_same_day_default_without_default_cash(self):
        receipt = event(LedgerEventKind.CASH_COLLECTION, principal_cash=D("20"), interest_cash=D("1"), par_reduction=D("20"))
        default = event(LedgerEventKind.DEFAULT, event_id="D")
        result = run(holdings=(OpeningHolding("X", "EUR", D("100")),), events=(default, receipt))
        self.assertEqual(result.final_snapshot.defaulted_par, 80)
        self.assertEqual(result.final_snapshot.performing_par, 0)
        self.assertEqual(result.final_snapshot.cash, CashBalances(D("120"), D("11")))
        self.assertEqual([row.kind for row in result.journal], ["CASH_COLLECTION", "DEFAULT"])

    def test_defaulted_trade_needs_explicit_reconfirmation(self):
        holding = OpeningHolding("X", "EUR", D("100"), HoldingStatus.DEFAULTED)
        with self.assertRaisesRegex(InputValidationError, "defaulted asset"):
            run(holdings=(holding,), trades=(trade(TradeSide.SELL),))
        result = run(holdings=(holding,), trades=(replace(trade(TradeSide.SELL), allow_defaulted_asset=True),))
        self.assertEqual(result.final_snapshot.settled_par, 0)

    def test_default_after_buy_commitment_blocks_unreconfirmed_execution(self):
        with self.assertRaisesRegex(InputValidationError, "defaulted asset"):
            run(trades=(trade(settlement_date=E),), events=(event(LedgerEventKind.DEFAULT, C),))

    def test_writeoff_recovery_cash_and_claim_are_separate(self):
        holding = OpeningHolding("X", "EUR", D("100"), HoldingStatus.DEFAULTED)
        claim = CashReceivable("R", "X", A, C, D("50"), D("0"), "RECOVERY_RIGHT")
        writeoff = event(LedgerEventKind.WRITE_OFF, B, par_reduction=D("100"))
        receipt = event(LedgerEventKind.RECEIVABLE_COLLECTION, E, event_id="RECOVERY", receivable_id="R", principal_cash=D("50"))
        result = run(holdings=(holding,), cash=CashBalances(), opening_receivables=(claim,), events=(receipt, writeoff))
        due = next(row for row in result.snapshots if row.as_of_date == C)
        self.assertEqual(due.cash, CashBalances())
        self.assertEqual(due.receivables[0].principal_cash, 50)
        self.assertEqual(result.final_snapshot.settled_par, 0)
        self.assertEqual(result.final_snapshot.cash.principal, 50)
        self.assertEqual(result.final_snapshot.receivables, ())

    def test_overdue_receivable_does_not_pay_or_default_itself(self):
        claim = CashReceivable("R", "X", date(2025, 12, 1), date(2025, 12, 20), D("0"), D("3"), "SERVICER")
        result = run(holdings=(OpeningHolding("X", "EUR", D("0")),), cash=CashBalances(), opening_receivables=(claim,))
        self.assertEqual(result.final_snapshot.cash, CashBalances())
        self.assertEqual(result.final_snapshot.receivables, (claim,))

    def test_partial_receivable_collection_tracks_components_and_rejects_double_collect(self):
        claim = CashReceivable("R", "X", A, B, D("2"), D("3"), "SERVICER")
        one = event(LedgerEventKind.RECEIVABLE_COLLECTION, B, receivable_id="R", principal_cash=D("1"), interest_cash=D("2"))
        result = run(holdings=(OpeningHolding("X", "EUR", D("0")),), opening_receivables=(claim,), events=(one,))
        self.assertEqual((result.final_snapshot.receivables[0].principal_cash, result.final_snapshot.receivables[0].interest_cash), (D("1"), D("1")))
        with self.assertRaisesRegex(InputValidationError, "exceeds"):
            run(holdings=(OpeningHolding("X", "EUR", D("0")),), opening_receivables=(claim,), events=(one, replace(one, event_id="AGAIN", event_date=C)))

    def test_lots_tickets_and_availability_are_exact(self):
        for changes in ({"lot_size": D("30")}, {"minimum_ticket": D("101")}, {"maximum_par": D("99")}, {"lot_size": D("0")}):
            with self.subTest(changes=changes), self.assertRaises(InputValidationError):
                trade(**changes)
        self.assertEqual(trade(lot_size=D("25"), minimum_ticket=D("100"), maximum_par=D("100")).par, 100)

    def test_clean_half_cent_posts_once_under_hostile_context(self):
        with localcontext() as context:
            context.prec = 2
            context.traps[Inexact] = True
            t = replace(trade(), par=D("0.01"), clean_price_pct=D("50"), accrued_cash=D(".01"), fees_cash=D(".01"))
            result = run(cash=CashBalances(D(".01"), D(".02")), trades=(t,))
        self.assertEqual(t.clean_cash, D(".01"))
        self.assertEqual(result.final_snapshot.cash, CashBalances())
        self.assertEqual(result.final_snapshot.settled_par, D(".01"))

    def test_sorted_replay_is_input_order_independent_and_repeatable(self):
        e1 = event(LedgerEventKind.CASH_COLLECTION, B, event_id="A", interest_cash=D("1"))
        e2 = event(LedgerEventKind.CASH_COLLECTION, C, event_id="B", principal_cash=D("10"), par_reduction=D("10"))
        r1 = run(holdings=(OpeningHolding("X", "EUR", D("100")),), events=(e2, e1))
        r2 = run(holdings=(OpeningHolding("X", "EUR", D("100")),), events=(e1, e2))
        self.assertEqual(r1, r2)
        with self.assertRaises(FrozenInstanceError):
            r1.source = "CHANGE"
        self.assertEqual([row.as_of_date for row in r1.snapshots], [A, B, C, E])

    def test_pending_horizon_and_empty_ledger_do_not_invent_settlement(self):
        r = HoldingsLedgerRequest(A, B, "EUR", CashBalances(D("100")), (), trades=(trade(),))
        result = HoldingsLedgerService().replay(r)
        self.assertEqual(result.final_snapshot.cash.principal, 100)
        self.assertEqual(result.final_snapshot.settled_par, 0)
        self.assertEqual(len(result.final_snapshot.pending_trades), 1)
        empty = HoldingsLedgerService().replay(HoldingsLedgerRequest(A, A, "EUR", CashBalances(), ()))
        self.assertEqual(len(empty.snapshots), 1)

    def test_input_contracts_reject_wrong_types_duplicates_currency_and_payload(self):
        invalid = (
            lambda: request(holdings=[OpeningHolding("X", "EUR", D("1"))]),
            lambda: request(holdings=(OpeningHolding("X", "USD", D("1")),)),
            lambda: request(trades=(trade(), trade())),
            lambda: request(opening_commitments=(trade(),)),
            lambda: request(trades=(replace(trade(), trade_date=date(2025, 12, 20)),)),
            lambda: request(events=(event(LedgerEventKind.DEFAULT, date(2025, 12, 20)),)),
            lambda: trade(accrued_cash=D(".001")),
            lambda: replace(trade(), clean_price_pct=99.0),
            lambda: replace(trade(), trade_date=datetime(2026, 1, 2)),
            lambda: LedgerPermissions(1, False),
            lambda: event(LedgerEventKind.DEFAULT, principal_cash=D("1")),
            lambda: event(LedgerEventKind.CASH_COLLECTION, interest_cash=D("1"), par_reduction=D("1")),
        )
        for build in invalid:
            with self.subTest(build=build), self.assertRaises(InputValidationError):
                build()

    def test_full_cash_and_par_bridges_have_independent_expected_amounts(self):
        buy = trade(asset_id="Y", accrued_cash=D("2"), fees_cash=D("1"))
        sell = replace(trade(TradeSide.SELL, trade_id="SELL", trade_date=C, settlement_date=E), par=D("50"), clean_price_pct=D("102"))
        receipt = event(LedgerEventKind.CASH_COLLECTION, B, principal_cash=D("10"), interest_cash=D("3"), par_reduction=D("10"))
        result = run(holdings=(OpeningHolding("X", "EUR", D("100")),), trades=(sell, buy), events=(receipt,))
        # Principal: 100+10-99+51=62; interest:10+3-2-1=10;
        # face:100-10+100-50=140. No investment P&L is inferred.
        self.assertEqual(result.final_snapshot.cash, CashBalances(D("62"), D("10")))
        self.assertEqual(result.final_snapshot.settled_par, 140)
        self.assertEqual(sum((Fraction(row.par_change) for row in result.journal), Fraction()), 40)


if __name__ == "__main__":
    unittest.main()
