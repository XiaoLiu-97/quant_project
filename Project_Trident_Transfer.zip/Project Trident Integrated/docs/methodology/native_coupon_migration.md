# Native Cash / PIK / Mixed 与 projected overnight coupon

本文说明 Cashflow Generator 契约能力迁移后的计算规则。CLO liability 的 legal deferral、mandatory note PIK 和 collateral default policy 是独立模块；asset PIK 不是拖欠 cash coupon。对应源码为 [domain contracts](../../src/trident/domain/models.py)、[cashflow engine](../../src/trident/cashflows/engine.py)、[coupon projector](../../src/trident/cashflows/coupons.py) 和 [discount-factor curves](../../src/trident/market/cash_accounts.py)。

## 输入与单位

`LoanTerms.interest_mode` 是 `CASH`、`PIK` 或 `MIXED`；`pik_fraction` 是总 coupon 的资本化比例，使用 decimal fraction。CASH 必须为 0，PIK 必须为 1，MIXED 必须严格处于 0 与 1 之间。不能把非法比例截断成合法值。`coupon_type` 仍独立选择 FIXED / FLOATING；固定或浮动 coupon 都可以采用 PIK 或 Mixed。旧生成器不支持 PIK annuity，当前保留这个边界；annuity 仅限 Cash。

金额是 local currency units；gross coupon、cash coupon、PIK 和 principal 均逐 asset、逐 coupon boundary 向 cents posting，HALF_UP。实际 spread 为 bps；margin 与 index 不共用金额单位。

## Cash、PIK 和 principal 的顺序

每期先以 opening face 和 exact coupon factor 计算总 earned coupon，再拆分 Cash / PIK。本 profile 在 `min(accrual_end, payment_date)` 增加 PIK face：普通 settlement lag 保留 accrual boundary；PRECEDING 提前现金日先资本化再赎回，nominal coupon factor 不变。当前模型不在 coupon period 内逐日资本化 PIK。

```text
earned_coupon_exact = opening_face × exact_coupon_factor
gross_coupon_posted = round_to_cent(earned_coupon_exact + explicit_opening_cash_claim)
pik_posted = round_to_cent(earned_coupon_exact × pik_fraction)
cash_coupon_posted = gross_coupon_posted − pik_posted
ending_face = opening_face + pik_posted − principal_repayment
total_cash = cash_coupon_posted + principal_repayment
```

Cash 是已 posted gross 扣除已 posted PIK 的残额，避免两个各自 rounded 的比例相加偏离 gross。比例非常接近 cent tie 时，cash / PIK 的独立四舍五入可能合计多一分或少一分；残额分类给出一个明确可对账的规则。它是本模型的 posting assumption，并非所有 loan agent 的唯一规则；真实合同采用其他 allocation convention 时应提供 explicit detailed stream 或经核验的新 profile。

负的 exact PIK 被拒绝，不能以“negative PIK”默默减少贷款本金。Cash 的负利率逻辑保留原有支持。

本金策略保留 initial/reference-face amortization：Linear percentage 的分母是明确的 amortization reference，不随资本化 face 自动增加；固定金额和 accelerated instalment 也不因 PIK 更改合同计划。Interim scheduled principal 使用 capitalization 前的 opening face，随后 PIK 进入 closing face。Auto Linear / Accelerated 的初始校准仍针对明确的 opening face 和 balloon；PIK 增量在 final redemption 结清。

Scheduled 与 BESPOKE 的 `balloon_amount` 是到期前最低剩余 face，不能解读为必然达到的最终 residual。Scheduled 到期偿清全部 face；BESPOKE Cash 按完整显式金额表还本，不隐含补足遗漏金额的 sweep。LINEAR_AUTO / ACCELERATED_AUTO / ANNUITY 的 balloon 则参与校准，regular payments 后的目标 residual 在 maturity 额外偿清，并结清 cent rounding residual。PIK 增加的 face 在 final redemption 额外结清。

### Maturity 与守恒

当前 native profile 明确假定：**当期 PIK 在 `min(accrual_end, payment_date)` 资本化，到 actual cash date 以 full face redemption 偿清**。

```text
final_principal_repayment = opening_face + current_period_pik
final_ending_face = 0
final_total_cash = final_cash_coupon + final_principal_repayment
```

因此，不再出现“principal=100、PIK=10、cash total=110、ending=0”却无法满足 face bridge 的接口矛盾。新规则将 principal 记录为 110，PIK 增量为 10，现金本金也是 110。不能额外把相同 PIK 再加到 cash interest 或 total cash。

验收例：opening 100、12% fixed、30E/360 quarterly、四期、100% PIK，逐期资本化 3.00、3.09、3.18、3.28，final principal / cash 为 112.55。所有 row 满足 `opening + PIK − principal = ending` 和 `total cash = cash interest + principal`；全生命周期满足 `sum(principal − PIK) = opening`。

PIK 资本化与到期结算需要合同依据，不能把示例当作 EUR BSL 通用条款。公开 [SEC-filed loan agreement](https://www.sec.gov/Archives/edgar/data/1605888/000091228225000542/exhibit10_1.pdf) 明确使用 payment-date capitalization，随后对 enlarged principal 计息并在 maturity 支付。另一份 [SEC-filed promissory note](https://www.sec.gov/Archives/edgar/data/21212/000002121210000029/ex4304052010.htm) 说明资本化 coupon 加入 principal。这些资料支持分类和余额设计，不规定本项目每份资产合同的日期、比例或 rounding。

## Seasoned opening 与历史 PIK

已发生并已资本化的 PIK 必须包含于 explicit held opening face；对于 noncash contracts，held face 可以高于原始 amortization reference。不能从现有 face 倒推历史 capitalizations。

Seasoned `POST_ASOF_ONLY` 在 as-of 之后重新计算 forward entitlement；历史已经资本化的余额保留，历史未资本化 PIK 不推测。`EXPLICIT_CASH_CLAIM` 的已核验 opening cash claim 仍是 cash，first forward coupon 仅添加一次，不改成 PIK。非零 `FULL_CURRENT_PERIOD` PIK opening claim 被拒绝，原因是该字段原本表示 cash ownership，无法同时证明历史 uncapitalized PIK 及 cash allocation。应提供 explicit state / detailed stream。Historical coupon steps 和 projected auto recast 的原有 seasoned guards 仍存在。

## ESTR / SOFR / SONIA 的 projected O/N coupon

这是旧模型的 **forward-compounded overnight projection**，不是实际日度 RFR replay。Asset currency 必须对应 ESTR→EUR、SOFR→USD、SONIA→GBP。Coupon convention 使用 ESTR/SOFR ACT/360、SONIA ACT/365F；curve 的 zero compounding 与 curve day count 是独立、显式输入。

输入 zero curve 经明确的 compounding 转换为 discount factors，按 log DF 插值。Forward earnings factor 是：

```text
reference_factor = DF(accrual_start) / DF(accrual_end) − 1
reference_equivalent_rate = reference_factor / coupon_DCF
bounded_reference = apply_reference_floor_cap(reference_equivalent_rate)
all_in_equivalent_rate = apply_all_in_floor_cap(bounded_reference + spread_bps/10000)
coupon_factor = all_in_equivalent_rate × coupon_DCF
```

未触发 bounds 且 spread 为零时，cash math 直接保留 exact rational DF ratio，不使用显示为 34 digits 的年化 rate。完整 accrual interval 只有一次 compounded reference factor；spread 在 compounding 外 simple accrual，不将 margin 日度复利。`RESET_START` spread step 在原 payment period start 生效，与旧生成器一致。`ACTUAL_DATE` 将 margin 切成 additive exact DCF pieces，reference 仍只计算一次整期 factor。

没有 separate 1M / 3M / 6M term reset；payment frequency 可为 1、3、6 或 12 月。O/N 显示的 observation start 是 original accrual start，term fixing lag 不应用于这个 DF-forward profile。原来 EURIBOR 的 carried actual fixing 和 historical-fixing validation 不变。

独立验收例：curve valuation 后 90 天的 DF 为 `1/1.01`，180 天的 DF 为 `1/1.04`，则后面 90 天 factor 为 `3/101`。持有 10,100 时 projected coupon 为 300；加 100bps margin、ACT/360 的 90 天，coupon 为 325.25。这与直接使用任一输入 zero rate 有实质差别。

### Frozen replay 和 partial prepayment assumption

`CouponSegment.exact_factor` 和 `exact_index_factor` 保存每个 native O/N segment 的 unposted factor。信用模型或源校验不能用显示的年化 equivalent rate 恢复原始金额；dates、margin、bounds 和 exact factor 必须共同匹配。

如果信用事件在原 coupon boundary 之前发生，当前 projected O/N replay 将已经冻结的整期 equivalent factor 按 exact partial DCF prorate。这是**冻结的 projected period-rate assumption**，并不意味着提前退出的实际 coupon 等于原曲线在新退出日期上的 DF ratio。Loan contract 如果要求实际 daily fixing、lookback、lockout、observation shift 或重新观测 partial compounded rate，需要对应 observed-RFR profile；它们不是旧生成器已有能力，也不能由 zero curve证明。

实际 compounded RFR 的日度观察和 non-business-day 权重，可交叉参考 [New York Fed SOFR methodology](https://www.newyorkfed.org/markets/reference-rates/additional-information-about-reference-rates) 和 [ECB compounded €STR rules](https://www.ecb.europa.eu/stats/euro-short-term-rates/interest_rate_benchmarks/WG_euro_risk-free_rates/shared/pdf/ecb.Compounded_euro_short-term_rate_calculation_rules.ro.pdf)。它们说明实际日度 compounding 的来源要求；这里的 DF-forward projection 与其区分。

## Market calendar 与 payment lag

`LoanTerms.holiday_calendar` 选择每份合同的 named calendar；显式 API calendar override 优先，便于带特殊 holidays 的真实业务 calendar 注入。Coupon projector、seasoned entitlement 和 resizing 使用同一合同 calendar，不能在其中某一步恢复为 TARGET 默认值。

Payment lag 应用于 business-day-adjusted payment date；本金的 coupon-effective boundary 仍是 accrual end。一个 amortizing loan 可以先发生 contractual principal reduction，数个 business days 后才收款。下期 coupon 的 opening face 已扣除前期 effective principal；不会因 settlement lag 多计 coupon。Cashflow row 同时保留 accrual end 和 payment date。统一 CLO 的 collateral ledger 在 `min(accrual_end, payment_date)` 增加 PIK，在 actual cash date 收取 principal；在普通 lag 的两日期之间，reported collateral face 可包含等待收取的 principal entitlement。这与 contract 下一期的 interest-earning face 是不同的 accounting view，不额外让该 receivable 赚取 loan coupon。Calendar/actual-source-date 桥接不能制造提前收款。PRECEDING 可以将现金日期提前到 nominal accrual end 之前；此时 PIK 在该现金日先资本化再赎回，coupon 仍按原 nominal interval 计算。这是明确的 projected policy，不推断额外合同 entitlement。

Explicit full-exit credit profile仍要求zero paymentlag；PIK还要求accrualend与cashdate一致，不能忽略Unadjusted accrual与Following现金调整产生的gap。它不能从单一face状态推断ended-unpaid coupons的default/ownership条款。Legacy annual CDR/CPR overlay的nativePIK+lag组合通过独立source movements重放，CPR只在actualcashdates应用，并以完整cash-to-cash interval计算hazard；capitalization-only date不增设CPR退出。额外约定和信用守恒见[credit方法](credit.md)。

Native PIK资产的funded-principal WAL需要明确区分原始fundedface和资本化coupon的本金回款分配；当前analytics不把全部enlarged redemption机械除以openingface，并对该部分保留INCOMPLETE/UNAVAILABLE。这里不能从完整Cashflow projection推导所有legalWAL和评级availability。

## 测试与边界

[Native migration tests](../../tests/test_native_coupon_migration.py) 覆盖 compound PIK、Mixed、cent residual、maturity cash/par identities、linear / auto schedule、seasoned carried face / cash claim、negative PIK rejection、dated steps、per-loan calendar、O/N currency/day-count / annual frequency、simple spread、bounds、frozen replay 和 independent two-node DF forward。Existing cashflow、principal、reset、bounds 和 seasoned suites 同时回归。Separate calendar、CLO liability、adapter、legacy export 和端到端 golden reference tests由相应模块负责。

本页不把 native projection 支持等同于所有法律现金流、所有历史状态、全部信用组合或 live-deal 验收。Source-compatible legacy outputs 必须通过完整 row-level cash/par bridge，以及 financial benchmark comparison，而不是只检查 workbook 能否成功保存。
