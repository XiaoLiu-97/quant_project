"""Apply native contractual coupon steps to dated portfolio-quality inputs.

WAS measures a floating loan's quoted margin and WAC measures a fixed loan's
contractual rate at the observation date. Neither is the weighted full-payment
coupon shown in cashflow output. One schedule-aware resolver per stepped loan
preserves deferred PAYMENT_START/RESET_START policies and does not query rates.
"""

from dataclasses import replace
from datetime import date

from trident.analysis import AssetExposure
from trident.cashflows.coupons import CouponProjector
from trident.domain.models import CouponType, LoanPosition, require_date


class CouponTimeline:
    """Own reusable native step schedules for one immutable application run.

    Only stepped contracts need a resolver; constant-coupon portfolios incur
    no extra schedule builds. Synthetic acquisitions retain their own explicit
    template margin and active imported sources retain their own evidential
    semantics. The caller must therefore create this object only for native
    contracts and apply it only to the original native holdings.
    """

    def __init__(self, positions: tuple[LoanPosition, ...]) -> None:
        self._projectors = {
            position.terms.loan_id: CouponProjector.for_terms(position.terms)
            for position in positions if position.terms.coupon_steps
        }

    @property
    def effective_change_dates(self) -> tuple[date, ...]:
        """Dates on which a native raw coupon level actually changes.

        The projector owns the original adjusted payment/reset schedules, so
        this calendar cannot drift from the entitlement used for cash and WAS.
        Superseded deferred steps and replacements that preserve the level
        create no observation. Resolving dates never requests a market fixing.
        """
        return tuple(sorted({day for projector in self._projectors.values()
                             for day in projector.effective_change_dates()}))

    def at(self, exposures: tuple[AssetExposure, ...], as_of: date) -> tuple[AssetExposure, ...]:
        """Resolve effective raw margin/fixed rate, retaining held par/metadata.

        Date equality applies an ACTUAL_DATE step immediately. Deferred step
        policies use the original native schedule boundaries inside the shared
        projector. Bounds on reference/all-in rates affect cash entitlement,
        not raw quoted WAS. No asset fixing or provider observation is needed.
        """
        require_date(as_of, "coupon snapshot as_of")
        if not self._projectors:
            return exposures
        result = []
        for exposure in exposures:
            projector = self._projectors.get(exposure.loan_id)
            if projector is None:
                result.append(exposure)
            elif projector.terms.coupon_type is CouponType.FLOATING:
                result.append(replace(exposure, spread_bps=projector.active_spread_bps(as_of)))
            else:
                result.append(replace(exposure, fixed_coupon_rate=projector.active_fixed_rate(as_of)))
        return tuple(result)
