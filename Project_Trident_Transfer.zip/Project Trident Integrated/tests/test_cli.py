"""Public launcher output and strict boundaries of the labelled H00 example.

The full synthetic CLO is computed once. CLI formatting tests reuse that real
result while mocking only dispatch, avoiding repeated financial calculations.
Rejected JSON fixtures omit CSV files: unsupported settings must fail before
an attempt to load or calculate an apparently valid portfolio.
"""

from contextlib import redirect_stderr, redirect_stdout
from decimal import Decimal
from io import StringIO
import json
from pathlib import Path
from tempfile import TemporaryDirectory
from types import SimpleNamespace
import unittest
from unittest.mock import patch


from trident.adapters.clo_example import run_synthetic_clo_example
from trident.adapters import excel_schema as schema
from trident.adapters.excel_schema import SCALAR_NAMES
from trident.adapters.excel import NamedWorkbook
from openpyxl import load_workbook
from workbook_fixtures import copy_input_template
from trident.cli import main
from trident import __version__
from trident.domain.models import InputValidationError


EXAMPLE = Path(__file__).resolve().parents[1] / "data/examples/hybrid_500m"
D = Decimal


def launch(arguments):
    stdout, stderr = StringIO(), StringIO()
    with redirect_stdout(stdout), redirect_stderr(stderr):
        status = main(arguments)
    return status, stdout.getvalue(), stderr.getvalue()


class CliTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.result = run_synthetic_clo_example(EXAMPLE)

    def test_example_clo_emits_actual_dated_return_and_complete_state_json(self):
        with patch("trident.adapters.clo_example.run_synthetic_clo_example", return_value=self.result) as runner:
            status, output, errors = launch(["example-clo", "--directory", str(EXAMPLE)])
        runner.assert_called_once_with(EXAMPLE)
        self.assertEqual(status, 0)
        self.assertEqual(errors, "")
        payload = json.loads(output)
        self.assertEqual(payload["version"], __version__)
        self.assertEqual(payload["mode"], "CLO_BASELINE")
        self.assertEqual(payload["clo_waterfall_and_equity_irr"], "COMPLETED")
        self.assertEqual(payload["asset_count"], 150)
        self.assertEqual(payload["cashflow_row_count"], 4316)
        self.assertEqual(D(payload["collateral_par_eur"]), D("500000000"))
        self.assertEqual(D(payload["equity_cash_funding_eur"]), D("53475000"))
        self.assertEqual(payload["projection_start_date"], "2026-11-20")
        self.assertEqual(payload["clo_period_count"], 40)
        self.assertIs(payload["terminal_value_available"], True)
        self.assertEqual(D(payload["final_debt_par_eur"]), D(0))
        self.assertEqual(D(payload["equity_distributions_eur"]), D("96115867.54"))
        self.assertEqual(payload["equity_irr_status"], "AVAILABLE")
        self.assertLess(abs(D(payload["equity_irr"]) - D("0.0998082779271915")), D("1e-14"))
        self.assertEqual(payload["portfolio_metrics"]["WARF"]["status"], "UNAVAILABLE")
        self.assertIsNone(payload["portfolio_metrics"]["WARF"]["value"])
        for name, value in (("TEST_FACTOR_AVERAGE", "2120"), ("BSL_TEST_FACTOR_AVERAGE", "3100"),
                            ("INFRA_TEST_FACTOR_AVERAGE", "1700")):
            self.assertEqual(D(payload["portfolio_metrics"][name]["value"]), D(value))
        self.assertEqual(len(payload["opening_limit_statuses"]), 13)
        self.assertEqual(set(payload["opening_limit_statuses"].values()), {"PASS"})

    def test_workbook_dispatch_formats_unified_result_without_attribute_error(self):
        path, destination = Path("input.xlsx"), Path("result.xlsx")
        with patch("trident.cli._compact_interface", return_value=False), patch("trident.adapters.excel.run_workbook", return_value=self.result) as runner:
            status, output, errors = launch(["workbook", str(path), "--output", str(destination)])
        runner.assert_called_once_with(path, destination)
        self.assertEqual(status, 0)
        self.assertEqual(errors, "")
        payload = json.loads(output)
        self.assertEqual(payload["mode"], "CLO_BASELINE")
        self.assertEqual(payload["clo_period_count"], 40)
        self.assertIsInstance(payload["equity_irr"], str)

    def test_compact_workbook_routes_to_integrated_runner_and_reports_all_cases(self):
        # The marker probe is routing, not finance. Reuse a known-answer CLO
        # result while asserting the independent compact adapter is selected.
        path, destination = Path("compact.xlsx"), Path("calculated.xlsx")
        run = SimpleNamespace(baseline=self.result,
            inputs=SimpleNamespace(input_fingerprint="frozen-inputs", warnings=()),
            cases=(SimpleNamespace(case_id="BASELINE"), SimpleNamespace(case_id="WHAT_IF")),
            library_projection=SimpleNamespace(cashflows=self.result.cashflows.cashflows))
        with patch("trident.cli._compact_interface", return_value=True), patch(
            "trident.adapters.interface_run.run_interface_workbook", return_value=run
        ) as runner, patch("trident.adapters.excel.run_workbook") as canonical:
            status, output, errors = launch(["workbook", str(path), "--output", str(destination)])
        runner.assert_called_once_with(path, destination)
        canonical.assert_not_called()
        self.assertEqual((status, errors), (0, ""))
        payload = json.loads(output)
        self.assertEqual(payload["interface_schema"], "1.0")
        self.assertEqual(payload["input_fingerprint"], "frozen-inputs")
        self.assertEqual(payload["complete_cases"], ["BASELINE", "WHAT_IF"])
        self.assertEqual(payload["clo_period_count"], 40)

    def test_existing_example_remains_cashflow_only_and_uses_current_version(self):
        with patch("trident.cli.run_synthetic_example", return_value=self.result.cashflows) as runner:
            status, output, errors = launch(["example", "--directory", str(EXAMPLE)])
        runner.assert_called_once_with(EXAMPLE)
        self.assertEqual(status, 0)
        self.assertEqual(errors, "")
        payload = json.loads(output)
        self.assertEqual(payload["mode"], "CASHFLOW_ONLY")
        self.assertEqual(payload["version"], __version__)
        self.assertEqual(payload["asset_count"], 150)
        self.assertEqual(D(payload["total_principal_eur"]), D("500000000"))
        self.assertEqual(payload["clo_waterfall_and_equity_irr"], "NOT_SELECTED")
        self.assertNotIn("equity_irr", payload)
        self.assertNotIn("clo_period_count", payload)

    def test_invalid_workbook_mode_returns_two_without_mutation_or_traceback(self):
        with TemporaryDirectory() as temporary:
            path = Path(temporary) / "invalid_mode.xlsx"
            copy_input_template(path)
            book = load_workbook(path)
            # The complete named contract lets the CLI expose the invalid run
            # mode, rather than first rejecting missing unrelated output names.
            NamedWorkbook(book).write_scalar(SCALAR_NAMES["mode"], "UNSUPPORTED_MODE")
            book.save(path)
            book.close()
            previous = path.read_bytes()
            status, output, errors = launch(["workbook", str(path)])
            self.assertEqual(status, 2)
            self.assertEqual(output, "")
            self.assertIn("Trident input/run error", errors)
            self.assertIn("CASHFLOW_ONLY", errors)
            self.assertNotIn("Traceback", errors)
            self.assertEqual(path.read_bytes(), previous)

    def test_unknown_command_has_argparse_exit_two_without_traceback(self):
        errors = StringIO()
        with redirect_stderr(errors), self.assertRaises(SystemExit) as captured:
            main(["unrecognised-command"])
        self.assertEqual(captured.exception.code, 2)
        self.assertNotIn("Traceback", errors.getvalue())

    def test_corrupt_workbook_is_clean_input_error_without_mutation(self):
        with TemporaryDirectory() as temporary:
            path = Path(temporary) / "corrupt.xlsx"
            original = b"not an Excel ZIP package"
            path.write_bytes(original)
            status, output, errors = launch(["workbook", str(path)])
            self.assertEqual(path.read_bytes(), original)
        self.assertEqual(status, 2)
        self.assertEqual(output, "")
        self.assertIn("readable Excel workbook package", errors)
        self.assertNotIn("Traceback", errors)

    def test_missing_input_path_is_clean_error(self):
        with TemporaryDirectory() as temporary:
            missing = Path(temporary) / "missing"
            status, output, errors = launch(["example-clo", "--directory", str(missing)])
        self.assertEqual(status, 2)
        self.assertEqual(output, "")
        self.assertIn("Trident input/run error", errors)
        self.assertNotIn("Traceback", errors)


class H00ExampleBoundaryTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.original = json.loads((EXAMPLE / "deal_terms.json").read_text(encoding="utf-8"))

    def reject_changed(self, section, key, value, message):
        # Deep-copy JSON semantics through serialisation without sharing nested
        # objects. No CSVs are copied; rejection must happen before CSV loading.
        terms = json.loads(json.dumps(self.original))
        if section is None:
            terms[key] = value
        else:
            terms[section][key] = value
        with TemporaryDirectory() as temporary:
            directory = Path(temporary)
            (directory / "deal_terms.json").write_text(json.dumps(terms), encoding="utf-8")
            with self.assertRaisesRegex(InputValidationError, message):
                run_synthetic_clo_example(directory)
            status, output, errors = launch(["example-clo", "--directory", str(directory)])
        self.assertEqual(status, 2)
        self.assertEqual(output, "")
        self.assertIn("Trident input/run error", errors)
        self.assertNotIn("Traceback", errors)

    def test_production_or_live_market_provenance_denied(self):
        for section, key, value, message in (
            ("provenance", "classification", "PRODUCTION", "labelled EUR H00"),
            ("market_data", "provenance", "LIVE_MARKET_DATA", "synthetic flat EURIBOR"),
            (None, "fixture_version", "2.0", "labelled EUR H00"),
            (None, "currency", "USD", "labelled EUR H00"),
        ):
            with self.subTest(section=section, key=key):
                self.reject_changed(section, key, value, message)

    def test_non_object_json_has_a_clean_cli_validation_error(self):
        self.reject_changed(None, "provenance", [], "must be JSON objects")
        for terms in ([], None, "unexpected"):
            with self.subTest(terms=terms), TemporaryDirectory() as temporary:
                directory = Path(temporary)
                (directory / "deal_terms.json").write_text(json.dumps(terms), encoding="utf-8")
                status, output, errors = launch(["example-clo", "--directory", str(directory)])
                self.assertEqual(status, 2)
                self.assertEqual(output, "")
                self.assertIn("must be JSON objects", errors)
                self.assertNotIn("Traceback", errors)

    def test_credit_events_or_recovery_assumptions_are_not_silently_ignored(self):
        for field in ("default_events", "prepayment_events", "rating_migration_events"):
            with self.subTest(field=field):
                self.reject_changed("credit_baseline", field,
                                    [{"loan_id": "SYN_BSL_LOAN_001", "date": "2027-01-01"}], "without credit events/calls")
        self.reject_changed("credit_baseline", "recovery_assumption", {"recovery_fraction": "0.6"}, "without credit events/calls")

    def test_contradictory_provenance_flags_do_not_override_synthetic_classification(self):
        for field in ("is_actual_deal", "is_market_quote", "is_rating_agency_model"):
            for value in (True, 0, "false", None):
                with self.subTest(field=field, value=value):
                    self.reject_changed("provenance", field, value, "labelled EUR H00")

    def test_fee_daycount_and_cash_pay_type_must_match_supported_h00_semantics(self):
        for section, field, value in (
            ("recurring_fees", "management_fee_day_count", "ACT_365F"),
            ("recurring_fees", "fixed_expenses_day_count", "ACT_360"),
            ("capital_stack", "interest_payment_type", "OPTIONAL_DEFERRAL"),
        ):
            with self.subTest(section=section, field=field):
                self.reject_changed(section, field, value, "explicit ACT/360 management fees")

    def test_calls_refinancing_liquidation_and_optional_pik_denied(self):
        for field in ("optional_call_enabled", "refinancing_enabled", "eod_liquidation_defined"):
            with self.subTest(field=field):
                self.reject_changed("waterfall", field, True, "without credit events/calls")
        self.reject_changed("capital_stack", "optional_interest_deferral_or_pik", True, "cash-pay notes")

    def test_unimplemented_fee_opening_state_and_candidate_trades_denied(self):
        for field in ("incentive_fee_bps", "opening_arrears_eur"):
            with self.subTest(field=field):
                self.reject_changed("recurring_fees", field, 1, "zero opening arrears")
        self.reject_changed("trading_scope", "candidate_trade_universe", "bsl_candidates.csv", "NO_TRADES")


if __name__ == "__main__":
    unittest.main()
