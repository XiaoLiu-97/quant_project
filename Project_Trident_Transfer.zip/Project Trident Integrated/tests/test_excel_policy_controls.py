"""Named UI controls, output availability and policy relocation regression."""

from datetime import datetime
from pathlib import Path
import tempfile
import unittest

from openpyxl import load_workbook
from workbook_fixtures import copy_input_template

from trident.adapters import excel_schema as schema
from trident.adapters.excel import NamedWorkbook, run_workbook
from test_policy_transport import audited_inputs

ROOT = Path(__file__).resolve().parents[1]


class ExcelInterfaceTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.path = Path(self.temp.name) / "audit.xlsx"
        copy_input_template(self.path)

    def access(self, action, save=False):
        book = load_workbook(self.path)
        try:
            result = action(NamedWorkbook(book))
            if save:
                book.save(self.path)
            return result
        finally:
            book.close()

    @staticmethod
    def put(adapter, key, records):
        sheet, (left, top, right, _) = adapter.region(schema.TABLE_RANGE_NAMES[key])
        headers = tuple(sheet.cell(top, column).value for column in range(left, right+1))
        adapter.write_table(schema.TABLE_RANGE_NAMES[key], schema.TABLE_NAMES[key],
            tuple({field: row.get(field) for field in headers} for row in records))

    def small(self, **overrides):
        assets, capital, controls, factors, _ = audited_inputs(**overrides)
        def edit(adapter):
            for key, rows in (("assets",assets),("capital_stack",capital),("factor_mapping",factors),("portfolio_limits",())):
                self.put(adapter,key,rows)
            for key in schema.READ_INPUT_KEYS:
                if key in controls:
                    adapter.write_scalar(schema.SCALAR_NAMES[key],controls[key])
            adapter.write_scalar(schema.SCALAR_NAMES["scenario_enabled"],False)
        self.access(edit,True)

    def test_financial_policy_controls_are_editable_and_precede_aliases(self):
        def check(adapter):
            for key in ("include_deferred_interest_in_ic", "include_deferred_interest_in_oc",
                        "principal_coupon_policy", "interest_diversion_test_enabled",
                        "interest_diversion_test_class_id", "interest_diversion_test_oc_minimum",
                        "interest_diversion_test_max_fraction", "interest_diversion_test_end_date"):
                value=adapter.scalar(schema.SCALAR_NAMES[key])
                self.assertNotEqual(value,"Controlled in CLO Controls",key)
                sheet, (_, row, _, _) = adapter.region(schema.SCALAR_NAMES[key])
                self.assertEqual(sheet.title,"Advanced Controls")
                self.assertLessEqual(row,24)
            for key in ("result_was_status", "result_wac_rate", "result_wac_status",
                        "result_opening_limit_unavailable_count", "result_last_calculated_at"):
                adapter.scalar(schema.SCALAR_NAMES[key])
            self.assertEqual(adapter.scalar(schema.SCALAR_NAMES["schema_version"]),"0.7")
        self.access(check)

    def test_named_policy_relocation_drives_calculation_and_explicit_status_outputs(self):
        self.small(interest_diversion_test_enabled=True,interest_diversion_test_class_id="A",
                   interest_diversion_test_oc_minimum=2)
        def move(adapter):
            name=schema.SCALAR_NAMES["interest_diversion_test_max_fraction"]
            sheet,(left,top,_,_)=adapter.region(name)
            new=adapter.workbook.create_sheet("Moved Policy")
            new["G9"]=.25
            sheet.cell(top,left).value=None
            adapter.workbook.defined_names[name].attr_text="'Moved Policy'!$G$9"
        self.access(move,True)
        result=run_workbook(self.path)
        self.assertTrue(any(row.interest_diversion_test_transferred>0 for row in result.clo.periods))
        def check(adapter):
            self.assertEqual(adapter.scalar(schema.SCALAR_NAMES["result_was_status"]),"AVAILABLE")
            self.assertEqual(adapter.scalar(schema.SCALAR_NAMES["result_wac_status"]),"UNAVAILABLE")
            self.assertIsNone(adapter.scalar(schema.SCALAR_NAMES["result_wac_rate"]))
            self.assertGreaterEqual(adapter.scalar(schema.SCALAR_NAMES["result_opening_limit_unavailable_count"]),1)
            stamp=adapter.scalar(schema.SCALAR_NAMES["result_last_calculated_at"])
            self.assertIsNotNone(datetime.fromisoformat(stamp).tzinfo)
            rows=adapter.table_records(schema.TABLE_RANGE_NAMES["clo_periods"],schema.TABLE_NAMES["clo_periods"])
            self.assertTrue(any(row["interest_diversion_test_transferred"]>0 for row in rows))
        self.access(check)

