"""Input/output adapters for the independent Project Trident calculation engines."""
