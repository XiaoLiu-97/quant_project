"""Deterministic full-default/full-prepayment overlays on contractual cashflows.

The overlay never changes LoanCashflow rows into pretend credit receipts. A
collection ledger and two principal subledgers record each economic operation.
An explicit horizon truncates actual receipts, never a scheduled recovery's
date or an unresolved default claim. This increment has no CDR/CPR estimator.
"""

from collections.abc import Iterable
from datetime import date
from decimal import Decimal
from fractions import Fraction

from trident.cashflows.engine import ContractualCashflowEngine
from trident.cashflows.coupons import cashflow_coupon_factor
from trident.domain.models import CouponSegment
from trident.cashflows.principal import build_principal_policy
from trident.cashflows.seasoned import build_position_coupon_projector, build_position_schedule, opening_coupon_claim_exact
from trident.conventions.calendar import TargetCalendar, calendar_from_name
from trident.conventions.day_count import accrual_fraction
from trident.domain.models import AmortizationType, InterestMode, InputValidationError, LoanCashflow, LoanPosition, require_date, require_decimal, require_money
from trident.domain.numeric import decimal_fraction, post_currency
from trident.market.rates import RateProvider

from .models import (
    AssetCashSource, AssetCollection, AssetCreditEvent, AssetCreditProjection,
    AssetParMovement, CreditProjectionStatus, DefaultEvent, PrepaymentEvent,
)


def _sum_money(values: Iterable[Decimal]) -> Decimal:
    """Cent ledger aggregation independent of the caller's Decimal context."""
    return post_currency(sum((Fraction(value) for value in values), Fraction()))


class CreditEventCashflowEngine:
    """Compose contractual cash/PIK coupons with explicit dated credit events.

    apply() reuses an existing complete contractual projection. generate() is
    convenient when it has not been generated yet; it resolves the full original
    contractual schedule, including future annuity inputs, before the overlay.
    Actual scheduled cash on the event date executes first; after that exit,
    later contractual cash is cancelled except explicitly specified recoveries.
    """

    def __init__(self, rate_provider: RateProvider, calendar: TargetCalendar | None = None) -> None:
        self._calendar = calendar or TargetCalendar()
        self._calendar_override = calendar
        self._contractual = ContractualCashflowEngine(rate_provider, calendar)

    def generate(
        self, position: LoanPosition, event: AssetCreditEvent | None = None, *,
        horizon_date: date | None = None,
    ) -> AssetCreditProjection:
        """Generate the unchanged contract reference, then apply one scenario."""
        return self.apply(position, self._contractual.generate(position), event, horizon_date=horizon_date)

    def apply(
        self, position: LoanPosition, contractual_cashflows: tuple[LoanCashflow, ...],
        event: AssetCreditEvent | None = None, *, horizon_date: date | None = None,
    ) -> AssetCreditProjection:
        """Overlay one full exit/default; no partial default or opening default.

        A credit event must strictly follow projection_start. For a mid-period
        prepayment, event_date must lie in the selected original coupon's actual
        accrual interval. Gaps caused by unadjusted accrual and adjusted cash
        dates are rejected when they would require an unpaid-receivable policy.
        Default collects no accrued coupon and therefore has no such ambiguity.
        """
        self._validate_reference(position, contractual_cashflows, event)
        if horizon_date is None:
            dates = [contractual_cashflows[-1].payment_date]
            if event is not None:
                dates.append(event.event_date)
            if isinstance(event, DefaultEvent):
                dates.extend(row.recovery_date for row in event.recoveries)
                if event.writeoff_date is not None:
                    dates.append(event.writeoff_date)
            horizon_date = max(dates)
        require_date(horizon_date, "horizon_date")
        if horizon_date < position.par_as_of_date:
            raise InputValidationError("horizon_date cannot precede projection_start")

        scheduled_through_event = tuple(
            row for row in contractual_cashflows
            if event is None or row.payment_date <= event.event_date
        )
        event_balance = post_currency(
            Fraction(position.opening_balance) - sum(
                (Fraction(row.principal_repayment) - Fraction(row.pik_interest) for row in scheduled_through_event), Fraction(),
            )
        )
        if event is not None and event_balance == 0:
            raise InputValidationError("Credit event is on or after full contractual repayment; no remaining exposure")
        # Resolve an event's economics even if a shorter horizon has not reached
        # it yet, so invalid future scenarios do not become silently accepted.
        prepayment_interest, prepayment_pik = (
            self._prepayment_coupon(position, contractual_cashflows, event, event_balance)
            if isinstance(event, PrepaymentEvent) else (Decimal(0), Decimal(0))
        )
        collections: list[AssetCollection] = []
        movements: list[AssetParMovement] = []
        performing, defaulted = position.opening_balance, Decimal(0)

        # Scheduled coupon, PIK and principal execute first on a shared date.
        # The event acts on remaining capitalized face; unpaid future coupons
        # are not silently collected or used as recovery consideration.
        for row in scheduled_through_event:
            if row.payment_date > horizon_date:
                break
            after = post_currency(Fraction(performing) + Fraction(row.pik_interest) - Fraction(row.principal_repayment))
            collections.append(AssetCollection(
                position.terms.loan_id, position.terms.currency, row.payment_date,
                AssetCashSource.SCHEDULED, row.cash_interest, row.principal_repayment,
                row.total_cash, row.period_number,
            ))
            movements.append(AssetParMovement(
                position.terms.loan_id, row.payment_date, AssetCashSource.SCHEDULED,
                performing, after, defaulted, defaulted, row.principal_repayment, Decimal(0), row.pik_interest,
            ))
            performing = after

        applied = event is not None and event.event_date <= horizon_date
        defaulted_exposure = Decimal(0)
        pending_recovery = Decimal(0)
        if applied and isinstance(event, PrepaymentEvent):
            redemption = post_currency(Fraction(performing) + Fraction(prepayment_pik))
            collections.append(AssetCollection(
                position.terms.loan_id, position.terms.currency, event.event_date,
                AssetCashSource.PREPAYMENT, prepayment_interest, redemption,
                post_currency(Fraction(prepayment_interest) + Fraction(redemption)),
            ))
            movements.append(AssetParMovement(
                position.terms.loan_id, event.event_date, AssetCashSource.PREPAYMENT,
                performing, Decimal(0), defaulted, defaulted, redemption, Decimal(0), prepayment_pik,
            ))
            performing = Decimal(0)
        elif applied and isinstance(event, DefaultEvent):
            defaulted_exposure = performing
            defaulted = performing
            movements.append(AssetParMovement(
                position.terms.loan_id, event.event_date, AssetCashSource.DEFAULT,
                performing, Decimal(0), Decimal(0), defaulted, Decimal(0), Decimal(0),
            ))
            performing = Decimal(0)
            cumulative_fraction, recovered = Fraction(), Decimal(0)
            future_recoveries: list[Decimal] = []
            for recovery in event.recoveries:
                # Recovery percentages reference original defaulted exposure.
                # Difference cumulative cent targets, rather than round each
                # slice independently, so split recoveries conserve that target.
                cumulative_fraction += Fraction(recovery.recovery_fraction)
                cumulative_target = post_currency(Fraction(defaulted_exposure) * cumulative_fraction)
                amount = post_currency(Fraction(cumulative_target) - Fraction(recovered))
                recovered = cumulative_target
                if recovery.recovery_date > horizon_date:
                    future_recoveries.append(amount)
                    continue
                after = post_currency(Fraction(defaulted) - Fraction(amount))
                collections.append(AssetCollection(
                    position.terms.loan_id, position.terms.currency, recovery.recovery_date,
                    AssetCashSource.RECOVERY, Decimal(0), amount, amount,
                ))
                movements.append(AssetParMovement(
                    position.terms.loan_id, recovery.recovery_date, AssetCashSource.RECOVERY,
                    performing, performing, defaulted, after, amount, Decimal(0),
                ))
                defaulted = after
            pending_recovery = _sum_money(future_recoveries)
            if event.writeoff_date is not None and event.writeoff_date <= horizon_date:
                movements.append(AssetParMovement(
                    position.terms.loan_id, event.writeoff_date, AssetCashSource.WRITE_OFF,
                    performing, performing, defaulted, Decimal(0), Decimal(0), defaulted,
                ))
                defaulted = Decimal(0)

        if applied and isinstance(event, DefaultEvent):
            status = CreditProjectionStatus.DEFAULT_UNRESOLVED if defaulted else CreditProjectionStatus.DEFAULT_RESOLVED
        elif applied:
            status = CreditProjectionStatus.PREPAID
        else:
            status = CreditProjectionStatus.PERFORMING if performing else CreditProjectionStatus.REPAID
        return AssetCreditProjection(
            loan_id=position.terms.loan_id, currency=position.terms.currency,
            projection_start=position.par_as_of_date, opening_par=position.opening_balance,
            horizon_date=horizon_date, contractual_cashflows=contractual_cashflows,
            collections=tuple(collections), par_movements=tuple(movements), event=event,
            status=status, credit_event_applied=applied, defaulted_exposure=defaulted_exposure,
            final_performing_par=performing, final_defaulted_par=defaulted,
            total_scheduled_principal=_sum_money(row.principal_collection for row in collections if row.source is AssetCashSource.SCHEDULED),
            total_prepayment_principal=_sum_money(row.principal_collection for row in collections if row.source is AssetCashSource.PREPAYMENT),
            total_recovery_principal=_sum_money(row.principal_collection for row in collections if row.source is AssetCashSource.RECOVERY),
            total_principal_collections=_sum_money(row.principal_collection for row in collections),
            total_cash_interest=_sum_money(row.cash_interest for row in collections),
            total_par_loss=_sum_money(row.par_loss for row in movements),
            pending_recovery_amount=pending_recovery,
            # Carry the actual contract convention, never a rule inferred from
            # a displayed full-period DCF. The immutable public result can then
            # independently verify its partial prepayment coupon on replay.
            contractual_day_count=position.terms.day_count,
        )

    def _validate_reference(
        self, position: LoanPosition, rows: tuple[LoanCashflow, ...], event: AssetCreditEvent | None,
    ) -> None:
        """Validate contract economics as well as an internally balanced ledger.

        A caller-supplied reference could conserve par/cash yet use the wrong
        coupon, fixing date or principal strategy. Rebuild date conventions and
        verify frozen reset metadata without querying the provider again. One
        carried fixing must have consistent observations across cash periods.
        Multi-reset factors are integrated segment by segment; weighted display
        rates cannot reconstruct partial coupons or exact half-cent amounts. That
        makes credit replay reproducible even if a market source later changes.
        """
        if not isinstance(position, LoanPosition):
            raise InputValidationError("position must be LoanPosition")
        if position.terms.payment_lag_business_days:
            raise InputValidationError("Credit events require zero contractual payment lag")
        if type(rows) is not tuple or not rows or any(not isinstance(row, LoanCashflow) for row in rows):
            raise InputValidationError("A full immutable tuple of contractual LoanCashflow is required")
        terms = position.terms
        if terms.interest_mode is not InterestMode.CASH and any(row.payment_date != row.accrual_end for row in rows):
            # Even with a zero explicit lag, UNADJUSTED accrual plus an adjusted
            # business-day cash date can leave a capitalized-but-uncollected
            # coupon/principal entitlement. This full-exit profile cannot bind
            # those rights from one scalar face, so do not shift PIK/default
            # exposure silently from its contractual boundary to its cash date.
            raise InputValidationError("Explicit PIK credit requires coincident accrual and cash dates; separated coupon receivable rights need a dated profile")
        calendar = self._calendar_override or calendar_from_name(terms.holiday_calendar)
        schedule = build_position_schedule(position, calendar)
        periods = schedule.projection_periods
        if len(rows) > len(periods):
            raise InputValidationError("Contractual reference contains more periods than the supplied terms")
        coupons = build_position_coupon_projector(position, schedule, calendar)
        balance, previous_payment = position.opening_balance, position.par_as_of_date
        coupon_factors: list[Fraction] = []
        for period_number, row in enumerate(rows, 1):
            if type(row.period_number) is not int or row.period_number != period_number:
                raise InputValidationError("Contractual periods must be consecutive positive integers")
            for name in ("payment_date", "accrual_start", "accrual_end", "unadjusted_start", "unadjusted_end"):
                require_date(getattr(row, name), f"contractual {name}")
            if row.accrual_start >= row.accrual_end or row.unadjusted_start >= row.unadjusted_end:
                raise InputValidationError("Contractual accrual intervals must have positive length")
            expected = periods[period_number - 1]
            if any(getattr(row, name) != getattr(expected, name) for name in (
                "payment_date", "accrual_start", "accrual_end", "unadjusted_start", "unadjusted_end",
            )):
                raise InputValidationError("Contractual reference dates do not match the supplied contract schedule")
            for name in ("opening_balance", "principal_repayment", "closing_balance"):
                require_money(getattr(row, name), f"contractual {name}")
            for name in ("cash_interest", "total_cash"):
                value = require_decimal(getattr(row, name), f"contractual {name}")
                if post_currency(Fraction(value)) != value:
                    raise InputValidationError(f"Contractual {name} must have cent precision")
            require_decimal(row.all_in_rate, "contractual all_in_rate")
            for name in ("spread_bps", "day_count_fraction", "interest_unrounded"):
                require_decimal(getattr(row, name), f"contractual {name}")
            if row.loan_id != position.terms.loan_id or row.currency != position.terms.currency:
                raise InputValidationError("Contractual reference loan/currency does not match position")
            if row.payment_date < previous_payment or row.opening_balance != balance:
                raise InputValidationError("Contractual reference dates/par do not form a continuous schedule")
            if Fraction(row.closing_balance) != Fraction(row.opening_balance) + Fraction(row.pik_interest) - Fraction(row.principal_repayment):
                raise InputValidationError("Contractual reference does not conserve principal")
            if row.principal_repayment < 0 or row.closing_balance < 0:
                raise InputValidationError("Contractual reference has negative principal")
            if Fraction(row.total_cash) != Fraction(row.cash_interest) + Fraction(row.principal_repayment):
                raise InputValidationError("Contractual reference does not conserve cash")
            # apply() is a public API. An internally balanced ledger is not
            # evidence that its coupons or repayment policy follow the contract.
            # Check supplied fixing economics without querying rates again, so
            # the frozen reference remains reproducible and historical inputs
            # cannot silently change during credit replay.
            frozen = row.coupon_segments
            if not frozen:
                layout = coupons.layout(expected)
                if len(layout) != 1:
                    raise InputValidationError("Multi-reset credit reference requires frozen coupon segments")
                start, end, reset, fixing = layout[0]
                frozen = (CouponSegment(start, end, reset, row.fixing_date,
                                        row.index_rate, row.spread_bps, row.all_in_rate),)
            coupon = coupons.project(expected, frozen)
            if row.spread_bps != coupon.spread_bps:
                raise InputValidationError("Contractual reference margin differs from supplied terms")
            if (row.fixing_date != coupon.fixing_date or row.index_rate != coupon.index_rate
                    or row.all_in_rate != coupon.all_in_rate):
                raise InputValidationError("Contractual coupon summary differs from frozen reset economics")
            exact_dcf = accrual_fraction(row.accrual_start, row.accrual_end, terms.day_count)
            opening_claim = (position.seasoned_state.opening_accrued_interest
                if position.seasoned_state is not None and period_number == 1 else Decimal(0))
            if row.opening_accrued_interest != opening_claim:
                raise InputValidationError("Contractual reference opening coupon claim differs from the explicit position state")
            opening_exact = opening_coupon_claim_exact(position, schedule, coupons) if period_number == 1 else Fraction()
            if row.opening_accrued_exact != opening_exact:
                raise InputValidationError("Contractual reference exact opening claim differs from the position entitlement")
            exact_interest = Fraction(row.opening_balance) * coupon.exact_factor + opening_exact
            exact_pik = (exact_interest - opening_exact) * Fraction(terms.pik_fraction)
            posted_pik = post_currency(exact_pik)
            cash = post_currency(Fraction(post_currency(exact_interest)) - Fraction(posted_pik))
            if (exact_pik < 0 or row.pik_interest != posted_pik
                    or row.interest_mode is not terms.interest_mode or row.pik_fraction != terms.pik_fraction
                    or row.day_count_fraction != decimal_fraction(exact_dcf)
                    or row.interest_unrounded != decimal_fraction(exact_interest)
                    or row.cash_interest != cash):
                raise InputValidationError("Contractual reference coupon differs from exact rate/day-count economics")
            coupon_factors.append(coupon.exact_factor)
            balance, previous_payment = row.closing_balance, row.payment_date
        if balance != 0:
            raise InputValidationError("Contractual reference must include complete principal repayment")
        if terms.amortization_type is AmortizationType.ANNUITY and len(rows) != len(periods):
            raise InputValidationError("Contractual annuity reference must include every projected coupon")
        principal_policy = build_principal_policy(
            position, schedule.contractual_periods,
            tuple(coupon_factors) if terms.amortization_type is AmortizationType.ANNUITY else None,
        )
        for period_index, row in enumerate(rows):
            final = schedule.original_indices[period_index] == len(schedule.contractual_periods) - 1
            expected_principal = (post_currency(Fraction(row.opening_balance) + Fraction(row.pik_interest))
                if final and terms.interest_mode is not InterestMode.CASH else
                principal_policy.repayment(schedule.original_indices[period_index], row.opening_balance, row.cash_interest))
            if row.principal_repayment != expected_principal:
                raise InputValidationError("Contractual reference principal differs from supplied repayment policy")
        if event is not None:
            if not isinstance(event, (DefaultEvent, PrepaymentEvent)):
                raise InputValidationError("event must be DefaultEvent, PrepaymentEvent or None")
            if event.loan_id != position.terms.loan_id:
                raise InputValidationError("Credit event loan_id does not match position")
            if event.event_date <= position.par_as_of_date:
                raise InputValidationError("Credit event must strictly follow projection_start; opening defaults are unsupported")

    @staticmethod
    def _prepayment_coupon(
        position: LoanPosition, rows: tuple[LoanCashflow, ...], event: PrepaymentEvent,
        remaining_par: Decimal,
    ) -> tuple[Decimal, Decimal]:
        """Post current cash/PIK entitlement through actual prepayment date.

        Already received coupon cash is preserved. The event must lie in the
        unpaid original accrual interval; a calendar gap requiring receivable
        entitlement is rejected instead of collecting an invented full coupon.
        """
        row = next((row for row in rows if row.payment_date > event.event_date), None)
        if row is None or not row.accrual_start <= event.event_date <= row.accrual_end:
            raise InputValidationError(
                "Prepayment date lies outside the unpaid coupon's accrual interval; "
                "adjusted/unadjusted boundary gaps require an explicit unpaid-receivable policy"
            )
        if row.opening_balance != remaining_par:
            raise InputValidationError("Prepayment outstanding par does not match the current unpaid coupon")
        earned = Fraction(remaining_par) * cashflow_coupon_factor(row, position.terms.day_count, event.event_date)
        pik = post_currency(earned * Fraction(position.terms.pik_fraction))
        gross = post_currency(earned + row.opening_accrued_exact)
        return post_currency(Fraction(gross) - Fraction(pik)), pik
