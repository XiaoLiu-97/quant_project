"""Stable input fixtures and small named-interface authoring helpers.

Financial expected values live in the test cases, not in this uncomputed Excel
file. Only these authoring helpers know physical placement; tests identify
business fields by the same semantic registry as the workbook adapter.
"""

from datetime import date
from dataclasses import replace
from decimal import Decimal
from pathlib import Path
import shutil
from typing import Mapping

from trident.adapters import excel_schema as schema
from trident.adapters.excel import NamedWorkbook
from trident.adapters.legacy_model_records import CLOSING_COMPONENTS, RECURRING_COMPONENTS

ROOT = Path(__file__).resolve().parents[1]
INPUT_TEMPLATE = ROOT / "tests/fixtures/Project_Trident_inputs.xlsx"
EXAMPLE = ROOT / "data/examples/hybrid_500m"


def copy_input_template(destination: Path) -> None:
    """Give each test an isolated current-schema input workbook."""
    shutil.copyfile(INPUT_TEMPLATE, destination)


def put_records(adapter: NamedWorkbook, key: str, records) -> None:
    """Populate optional columns explicitly while retaining the named schema."""
    sheet, (left, top, right, _) = adapter.region(schema.TABLE_RANGE_NAMES[key])
    headers = tuple(sheet.cell(top, column).value for column in range(left, right + 1))
    rows = []
    for source in records:
        row = {field: source.get(field) for field in headers}
        if key in {"assets", "candidate_assets"}:
            for field, default in (("stub_convention", "SHORT_LAST"), ("end_of_month", False),
                                   ("payment_lag_business_days", 0)):
                if row.get(field) is None:
                    row[field] = default
        if key == "capital_stack" and row.get("interest_deferrable") is None:
            row["interest_deferrable"] = False
        rows.append(row)
    adapter.write_table(schema.TABLE_RANGE_NAMES[key], schema.TABLE_NAMES[key], tuple(rows))


def hand_controls(
    assets, capital, *, closing_date: date, first_payment_date: date,
    legal_final_date: date, upfront_fees=0, reserve=0,
) -> dict[str, object]:
    """Zero optional charges and reconcile canonical controls for a hand case.

    All 107 required deal inputs remain explicit. The old UI's aggregate fee
    alias is deliberately not used; a fixed hand-case fee belongs in the
    canonical itemized cost component. Tests then edit only the policy they
    intend to exercise.
    """
    values = dict(schema.INPUT_DEFAULTS)
    values.update(
        schema_version=schema.SCHEMA_VERSION, mode="CLO_BASELINE",
        synthetic_rate=0,
        valuation_date=date(2026, 1, 1), legacy_pricing_date=date(2026, 1, 1),
        legacy_closing_date=closing_date, legacy_first_note_payment_date=first_payment_date,
        legacy_maturity_date=legal_final_date,
        legacy_clo_size=sum(Decimal(str(row["nominal_amount"])) for row in capital),
        legacy_opening_collateral_par=sum(Decimal(str(row["current_par"])) for row in assets),
        legacy_collateral_purchase_price=1, legacy_purchased_accrued_interest=0,
        legacy_initial_reserve_funding=reserve, legacy_upfront_arrangement_fee=0,
        legacy_senior_management_fee=0, legacy_subordinated_management_fee=0,
        legacy_senior_expense_cap_fixed=0, legacy_cash_accrual_curve="EURIBOR 3M",
        legacy_other_initial_uses=0, legacy_other_initial_sources=0,
        legacy_maximum_single_obligor=1, legacy_maximum_industry=1,
        legacy_reinvestment_enabled="No", legacy_credit_prepayment_overlay="Off",
        scenario_enabled=False, optimizer_enabled=False, candidate_search_enabled=False,
        interest_diversion_test_enabled=False,
        interest_diversion_test_end_date=None,
    )
    for key in (*CLOSING_COMPONENTS, *RECURRING_COMPONENTS):
        values[f"legacy_{key}"] = 0
    values["legacy_other_upfront_costs"] = upfront_fees
    return values


def write_controls(adapter: NamedWorkbook, controls: Mapping[str, object]) -> None:
    """Write registered inputs, excluding formula displays and output fields."""
    for key in schema.READ_INPUT_KEYS:
        if key in controls:
            adapter.write_scalar(schema.SCALAR_NAMES[key], controls[key])


def assert_h00_projection_matches(test_case, actual, reference) -> None:
    """Compare all H00 financial rows allowing the current nonbinding fee cap.

    The CSV H00 example has no senior-expense priority cap; the complete current
    controls have an explicit EUR1m annual cap. This remains nonbinding in H00,
    so cash/par/coupon/coverage outputs must match, while the cap diagnostic
    correctly differs. No financial amount is removed from this comparison.
    """
    for period in actual.periods:
        test_case.assertGreaterEqual(period.senior_expense_priority_cap,
                                     period.newly_incurred_senior_expenses)
    comparable = replace(actual, periods=tuple(replace(period, senior_expense_priority_cap=None)
                                               for period in actual.periods))
    test_case.assertEqual(comparable, reference)
