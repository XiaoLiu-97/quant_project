"""Explicit principal-funded accrued restoration on a native coupon receipt.

Borrower coupon ownership, the price paid to a seller, and legal proceeds
classification are different facts. This module receives verified opening
balances and receipt instructions; it never reconstructs a trade or creates
coupon/default/recovery cash. Its cent markers relabel part of an existing
receipt while the raw contractual principal and cash remain unchanged.

The supported profile restores one entire loan-level balance at its unique
first positive coupon receipt. Partial collections, sale/default allocations,
and future acquisition lots need separately specified ownership/loss rules.
"""

from dataclasses import dataclass
from datetime import date
from decimal import Decimal
from fractions import Fraction
from typing import Protocol

from trident.credit.models import AssetCashSource
from trident.domain.models import InputValidationError, require_date, require_money
from trident.domain.numeric import post_currency


ZERO = Decimal(0)
_COUPON_SOURCES = {AssetCashSource.SCHEDULED, AssetCashSource.PREPAYMENT}


def _text(value: object, label: str) -> None:
    """A frozen source/reference is mandatory, never synthesized by the model."""
    if not isinstance(value, str) or not value or value != value.strip():
        raise InputValidationError(f"{label} must be nonblank unpadded text")


@dataclass(frozen=True)
class PrincipalAccruedBalance:
    """Verified remaining principal-funded accrued cash balance at as-of.

    This is a classification balance, not performing loan face, physical cash,
    or a new coupon entitlement. ``amount`` is a supplied cent amount and does
    not have to equal a historical exact borrower-accrual factor or purchase
    price. The operator must independently verify entitlement to its receipt.
    """

    loan_id: str
    as_of_date: date
    amount: Decimal
    source: str
    legal_reference: str

    def __post_init__(self) -> None:
        for name in ("loan_id", "source", "legal_reference"):
            _text(getattr(self, name), f"Principal accrued {name}")
        require_date(self.as_of_date, "Principal accrued as_of_date")
        require_money(self.amount, "Principal accrued amount", positive=True)


@dataclass(frozen=True)
class CouponProceedsAllocation:
    """A sourced instruction to restore principal inside a known coupon cash.

    ``original_principal_permission`` explicitly grants or withholds the
    existing synthetic original-principal reinvestment permission. Principal
    account routing itself does not imply that permission. No receipt amount,
    historical entitlement or transaction document is inferred from this flag.
    """

    allocation_id: str
    loan_id: str
    payment_date: date
    collection_source: AssetCashSource
    principal_amount: Decimal
    original_principal_permission: bool
    source: str
    legal_reference: str

    def __post_init__(self) -> None:
        for name in ("allocation_id", "loan_id", "source", "legal_reference"):
            _text(getattr(self, name), f"Coupon proceeds {name}")
        require_date(self.payment_date, "Coupon proceeds payment_date")
        if not isinstance(self.collection_source, AssetCashSource) or self.collection_source not in _COUPON_SOURCES:
            raise InputValidationError("Coupon proceeds require typed SCHEDULED or PREPAYMENT source; sale/default/recovery allocation is unsupported")
        require_money(self.principal_amount, "Coupon proceeds principal_amount", positive=True)
        if type(self.original_principal_permission) is not bool:
            raise InputValidationError("Coupon proceeds original_principal_permission must be bool")


@dataclass(frozen=True)
class CouponProceedsAudit:
    """One grouped physical receipt and its conserved legal account allocation.

    Original receipt rows remain untouched. A source can contain separate
    forward-coupon and inherited-entitlement rows on this same physical cash
    date; ``receipt_rows`` makes that coalescing visible. Permission is a subset
    of restored principal proceeds, not another cash source or loan repayment.
    """

    allocation_id: str
    loan_id: str
    payment_date: date
    collection_source: AssetCashSource
    raw_coupon_cash: Decimal
    raw_principal_cash: Decimal
    principal_accrued_restored: Decimal
    interest_proceeds: Decimal
    principal_proceeds: Decimal
    remaining_principal_accrued: Decimal
    original_principal_permission: Decimal
    receipt_rows: int
    balance_source: str
    allocation_source: str
    legal_reference: str


class CouponProceedsReceipt(Protocol):
    """Normalized raw receipt contract; no CLO engine import or mutable state."""

    loan_id: str
    payment_date: date
    cash_interest: Decimal
    principal_repayment: Decimal
    source: AssetCashSource


@dataclass(frozen=True)
class CouponProceedsResult:
    """Cent markers aligned to unchanged source rows, plus grouped audit rows."""

    restored_by_index: tuple[Decimal, ...]
    permission_by_index: tuple[Decimal, ...]
    audit_rows: tuple[CouponProceedsAudit, ...]


def validate_coupon_proceeds_inputs(
    balances: tuple[PrincipalAccruedBalance, ...],
    allocations: tuple[CouponProceedsAllocation, ...], *, as_of_date: date,
) -> None:
    """Validate the shared typed opening contract before any source is compiled.

    One entire known balance and one instruction per loan keep this initial
    profile explicit. A mismatch cannot be treated as a partial recovery or
    filled from another loan's coupon. Receipt matching remains the compiler's
    responsibility because credit scenarios determine which cash really exists.
    """
    require_date(as_of_date, "Coupon proceeds as_of_date")
    for values, expected, label in (
        (balances, PrincipalAccruedBalance, "principal_accrued_balances"),
        (allocations, CouponProceedsAllocation, "coupon_proceeds_allocations"),
    ):
        if type(values) is not tuple or any(not isinstance(row, expected) for row in values):
            raise InputValidationError(f"{label} must be an immutable tuple of {expected.__name__}")
        if len({row.loan_id for row in values}) != len(values):
            raise InputValidationError(f"{label} supports one unique row per loan")
    if len({row.allocation_id for row in allocations}) != len(allocations):
        raise InputValidationError("Coupon proceeds allocation_id must be unique")
    balance_by_loan = {row.loan_id: row for row in balances}
    if balance_by_loan.keys() != {row.loan_id for row in allocations}:
        raise InputValidationError("Principal accrued balances and coupon proceeds allocations must identify exactly the same loans")
    if any(row.as_of_date != as_of_date for row in balances):
        raise InputValidationError("Principal accrued balance as-of must equal the actual projection opening date")
    for row in allocations:
        if row.payment_date <= as_of_date:
            raise InputValidationError("Coupon proceeds allocation receipt must strictly follow its opening as-of")
        if row.principal_amount != balance_by_loan[row.loan_id].amount:
            raise InputValidationError("Coupon proceeds principal amount must restore the entire verified opening balance; partial collections are unsupported")


@dataclass
class _ReceiptGroup:
    """Exact private accumulator, compiled once for a claimed physical receipt."""

    indices: list[int]
    coupon: Fraction = Fraction()
    principal: Fraction = Fraction()


def classify_coupon_proceeds(
    receipts: tuple[CouponProceedsReceipt, ...],
    balances: tuple[PrincipalAccruedBalance, ...],
    allocations: tuple[CouponProceedsAllocation, ...], *, as_of_date: date,
) -> CouponProceedsResult:
    """Relabel verified coupon cents without changing source cash or face.

    Groups use loan/date/source, so separate same-day components can represent
    one physical coupon. The instruction must identify the UNIQUE first positive
    coupon group. Distinct positive sources on its earliest date are ambiguous
    and reject. There is no FIFO search across dates or fallback to later cash.

    The principal target already has cent precision. Assign that exact target
    once, then leave the gross-coupon residual to interest. Splitting markers in
    stable source-index order only bridges component rows of this same grouped
    receipt; it does not invent intraday ownership or separately round account
    cash. Fraction arithmetic avoids caller-context or large-money cent loss.
    """
    if type(receipts) is not tuple:
        raise InputValidationError("Coupon proceeds receipts must be an immutable tuple")
    validate_coupon_proceeds_inputs(balances, allocations, as_of_date=as_of_date)
    restored, permissions = [ZERO] * len(receipts), [ZERO] * len(receipts)
    if not balances:
        # Existing unconfigured models preserve their raw receipt contract.
        return CouponProceedsResult(tuple(restored), tuple(permissions), ())
    balance_by_loan = {row.loan_id: row for row in balances}
    groups: dict[tuple[str, date, AssetCashSource], _ReceiptGroup] = {}
    for index, row in enumerate(receipts):
        identity = getattr(row, "loan_id", None)
        _text(identity, "Coupon receipt loan_id")
        if identity not in balance_by_loan:
            continue
        day, source = getattr(row, "payment_date", None), getattr(row, "source", None)
        require_date(day, "Coupon receipt payment_date")
        if day <= as_of_date:
            raise InputValidationError("A claimed native coupon receipt must follow the opening as-of")
        if not isinstance(source, AssetCashSource):
            raise InputValidationError("Coupon receipt source must be AssetCashSource")
        coupon = require_money(getattr(row, "cash_interest", None), "Native coupon cash")
        principal = require_money(getattr(row, "principal_repayment", None), "Native principal repayment")
        group = groups.setdefault((identity, day, source), _ReceiptGroup([]))
        group.indices.append(index)
        group.coupon += Fraction(coupon)
        group.principal += Fraction(principal)

    # An independent loan index prevents an allocation-by-full-stream nested
    # scan. Source compilation is linear; sorting only the audit identities
    # provides deterministic reporting independent of input instruction order.
    positive_by_loan: dict[str, list[tuple[str, date, AssetCashSource]]] = {}
    for key, group in groups.items():
        if group.coupon > 0:
            positive_by_loan.setdefault(key[0], []).append(key)
    audit = []
    for instruction in sorted(allocations, key=lambda row: row.loan_id):
        candidates = positive_by_loan.get(instruction.loan_id, [])
        if not candidates:
            raise InputValidationError(f"Loan {instruction.loan_id}: no positive native coupon receipt can restore the verified balance")
        first_day = min(key[1] for key in candidates)
        first = [key for key in candidates if key[1] == first_day]
        if len(first) != 1:
            raise InputValidationError(f"Loan {instruction.loan_id}: ambiguous earliest positive coupon sources require a separately specified policy")
        target = (instruction.loan_id, instruction.payment_date, instruction.collection_source)
        if first[0] != target:
            raise InputValidationError(f"Loan {instruction.loan_id}: allocation must match the unique first positive native coupon receipt group")
        group = groups[target]
        remaining = Fraction(instruction.principal_amount)
        if remaining > group.coupon:
            raise InputValidationError(f"Loan {instruction.loan_id}: first coupon cash is insufficient to restore the entire principal accrued balance")
        for index in group.indices:
            part = min(remaining, Fraction(receipts[index].cash_interest))
            restored[index] = post_currency(part)
            permissions[index] = restored[index] if instruction.original_principal_permission else ZERO
            remaining -= part
        if remaining:
            raise ArithmeticError("Coupon proceeds component markers did not conserve the principal target")
        target_amount = Fraction(instruction.principal_amount)
        audit.append(CouponProceedsAudit(
            instruction.allocation_id, instruction.loan_id, instruction.payment_date,
            instruction.collection_source, post_currency(group.coupon), post_currency(group.principal),
            instruction.principal_amount, post_currency(group.coupon - target_amount),
            post_currency(group.principal + target_amount), ZERO,
            instruction.principal_amount if instruction.original_principal_permission else ZERO,
            len(group.indices), balance_by_loan[instruction.loan_id].source,
            instruction.source, instruction.legal_reference,
        ))
    return CouponProceedsResult(tuple(restored), tuple(permissions), tuple(audit))
