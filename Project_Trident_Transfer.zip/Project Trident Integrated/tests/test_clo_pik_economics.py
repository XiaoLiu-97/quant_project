"""Independent face/cash/coverage ledgers for mandatory PIK and economics.

Hand-authored borrower receipts isolate the liability mechanics; rates and
cash calculations below are independently computed from stated face and days.
The cases intentionally combine PIK, optional deferral, IC/OC, terminal cash,
reinvestment, fees and missing-data states instead of mirroring engine loops.
"""

import unittest
from dataclasses import replace
from datetime import date
from decimal import Decimal, localcontext

from trident.clo import (CloRunRequest, CloTerms, CoverageStatus, DeterministicCloEngine,
    EconomicsStatus, NoteTranche, ProjectionStatus, DefaultedAssetOcTreatment,
    report_clo_economics, report_tranche_periods)
from trident.clo.lifecycle import ShortfallAccrualMethod
from trident.clo.reinvestment import SyntheticReinvestmentPolicy
from trident.credit.overlay import OriginalPoolOverlay
from trident.credit import CreditEventCashflowEngine, DefaultEvent, PrepaymentEvent, RecoveryEvent
from trident.conventions import AccrualDateBasis, BusinessDayConvention, DayCount, StubConvention
from trident.domain.models import CouponType, InputValidationError, InterestMode, LoanCashflow, LoanPosition, LoanTerms
from trident.cashflows.engine import ContractualCashflowEngine
from trident.analysis import AssetExposure
from trident.application.portfolio_snapshots import PortfolioStateScanner
from trident.funding import AssetPurchase, DebtIssue, FundingEngine
from trident.market.rates import FlatRateProvider


D = Decimal
CLOSE, FIRST, FINAL = date(2026, 1, 20), date(2026, 4, 20), date(2026, 7, 20)


def cashflow(number, start, end, opening, principal, interest, *, pik="0", paid=None):
    """Receipts are specified independently of any asset generator."""
    par, redemption, coupon, capitalized = map(D, (opening, principal, interest, pik))
    return LoanCashflow("L", "EUR", number, start, end, start, end, paid or end, None,
        par, None, D(0), D(0), D(".25"), coupon + capitalized, coupon, redemption,
        par + capitalized - redemption, coupon + redemption, pik_interest=capitalized,
        interest_mode=InterestMode.PIK if capitalized else InterestMode.CASH,
        pik_fraction=D(1) if capitalized else D(0))


def tranche(par="100", rate=".10", pik="1", **kwargs):
    return NoteTranche("A", 1, D(par), CouponType.FIXED, fixed_rate=D(rate),
                       pik_rate_fraction=D(pik), **kwargs)


def project(rows, notes, par="200", **kwargs):
    request = CloRunRequest(tuple(rows), D(par), tuple(notes), CloTerms(CLOSE, FINAL, **kwargs))
    return request, DeterministicCloEngine(FlatRateProvider({"EURIBOR_3M": D(".025")})).run(request)


class MandatoryNotePikTests(unittest.TestCase):
    def test_full_pik_compounds_then_cash_redeems_at_final(self):
        request, projection = project((cashflow(1, CLOSE, FIRST, "200", "0", "0"),
            cashflow(2, FIRST, FINAL, "200", "200", "0")), (tranche(),))
        rows = report_tranche_periods(projection)
        # 100 * 10% * 90/360 = 2.50; 102.50 * 10% * 91/360 = 2.59.
        self.assertEqual([row.pik_interest_capitalized for row in rows], [D("2.50"), D("2.59")])
        self.assertEqual([row.closing_balance for row in rows], [D("102.50"), D("0")])
        self.assertEqual(rows[1].total_principal_paid, D("105.09"))
        self.assertEqual(rows[1].cumulative_pik_interest_capitalized, D("5.09"))
        self.assertTrue(all(row.total_coupon_paid == row.closing_coupon_arrears == 0 for row in rows))
        self.assertEqual(projection.total_equity_distributions, D("94.91"))
        self.assertEqual(projection.status, ProjectionStatus.COMPLETED)
        self.assertTrue(all(period.cash_conservation_residual == 0 for period in projection.periods))

    def test_mixed_coupon_cent_split_and_cash_ic(self):
        _, projection = project((cashflow(1, CLOSE, FIRST, "200", "0", "5"),
            cashflow(2, FIRST, FINAL, "200", "200", "5")),
            (tranche(pik=".5", ic_minimum=D("4"), oc_minimum=D("1.9")),))
        first = report_tranche_periods(projection)[0]
        self.assertEqual((first.current_coupon_due, first.pik_interest_capitalized), (D("1.25"), D("1.25")))
        self.assertEqual((first.gate_ic_denominator, first.gate_ic_ratio), (D("1.25"), D("4")))
        self.assertEqual(first.gate_ic_status, CoverageStatus.PASS)
        # Capitalized face enters coverage once; it is not another claim.
        self.assertEqual(first.gate_oc_denominator, D("101.25"))
        self.assertEqual(first.gate_oc_status, CoverageStatus.PASS)
        self.assertEqual(first.closing_coupon_arrears, D(0))

    def test_oc_failure_sees_pik_and_cure_redeems_enlarged_face(self):
        _, projection = project((cashflow(1, CLOSE, FIRST, "200", "0", "5"),
            cashflow(2, FIRST, FINAL, "200", "200", "0")),
            (tranche(oc_minimum=D("2")),))
        first = report_tranche_periods(projection)[0]
        self.assertEqual(first.gate_oc_denominator, D("102.50"))
        self.assertEqual(first.gate_oc_status, CoverageStatus.FAIL)
        self.assertEqual(first.principal_from_interest, D("5"))
        self.assertEqual(first.closing_balance, D("97.50"))
        self.assertEqual(first.closing_coupon_arrears, D(0))

    def test_capitalization_occurs_even_behind_blocked_senior_gate(self):
        senior = NoteTranche("A", 1, D("100"), CouponType.FIXED, fixed_rate=D(0), oc_minimum=D("3"))
        junior = NoteTranche("B", 2, D("20"), CouponType.FIXED, fixed_rate=D(".10"), pik_rate_fraction=D(1))
        _, projection = project((cashflow(1, CLOSE, FIRST, "200", "0", "0"),
            cashflow(2, FIRST, FINAL, "200", "200", "0")), (senior, junior))
        junior_first = report_tranche_periods(projection)[1]
        self.assertTrue(junior_first.interest_gate_blocked)
        self.assertEqual(junior_first.pik_interest_capitalized, D(".50"))
        self.assertEqual(junior_first.closing_balance, D("20.50"))
        self.assertEqual(junior_first.closing_coupon_arrears, D(0))

    def test_pik_not_subject_to_optional_cash_shortfall_waiver(self):
        _, projection = project((cashflow(1, CLOSE, FIRST, "200", "0", "0"),
            cashflow(2, FIRST, FINAL, "200", "200", "0")), (tranche(),), interest_shortfall_carry=False)
        self.assertEqual(projection.periods[0].note_pik_capitalized, D("2.50"))
        self.assertEqual(projection.periods[0].waived_note_coupon_shortfall, D(0))

    def test_no_fictional_terminal_principal_cash(self):
        _, projection = project((cashflow(1, CLOSE, FIRST, "100", "0", "0"),
            cashflow(2, FIRST, FINAL, "100", "100", "0")), (tranche(),), par="100")
        self.assertEqual(projection.status, ProjectionStatus.LEGAL_FINAL_UNRESOLVED)
        self.assertFalse(projection.terminal_value_available)
        self.assertEqual(projection.final_debt_par, D("5.09"))
        self.assertEqual(projection.final_note_coupon_arrears, D(0))

    def test_note_pik_input_validation(self):
        for value in (D("-.01"), D("1.01"), D("NaN"), 1.0, True):
            with self.subTest(value=value), self.assertRaises(InputValidationError):
                replace(tranche(), pik_rate_fraction=value)

    def test_optional_deferral_remains_claim_without_pik_face(self):
        _, projection = project((cashflow(1, CLOSE, FIRST, "200", "0", "0"),
            cashflow(2, FIRST, FINAL, "200", "200", "0")),
            (tranche(pik="0", interest_deferrable=True),))
        first = report_tranche_periods(projection)[0]
        self.assertEqual(first.closing_balance, D("100"))
        self.assertEqual(first.closing_coupon_arrears, D("2.50"))
        self.assertEqual(first.pik_interest_capitalized, D(0))
        self.assertEqual(first.period_end_oc_denominator, D("102.50"))


class NativeCollateralPikTests(unittest.TestCase):
    def test_preceding_maturity_cash_capitalizes_current_pik_before_redemption(self):
        """Nominal Saturday coupon is payable Friday without losing its PIK.

        Independently: first 100*12%*90/360=3; next coupon covers 88
        30E/360 days, so 103*12%*88/360=3.021333..., posted 3.02.
        Final face/cash is 106.02 on Friday; it cannot be redeemed then
        re-capitalized on Saturday or become a negative holding in between.
        """
        nominal, paid = date(2026, 7, 18), date(2026, 7, 17)
        terms = LoanTerms("L", "EUR", CLOSE, nominal, D(100), CouponType.FIXED,
            fixed_rate=D(".12"), frequency_months=3, day_count=DayCount.THIRTY_E_360,
            business_day_convention=BusinessDayConvention.PRECEDING,
            accrual_date_basis=AccrualDateBasis.UNADJUSTED, stub_convention=StubConvention.SHORT_LAST,
            interest_mode=InterestMode.PIK, pik_fraction=D(1))
        reference = ContractualCashflowEngine(FlatRateProvider({"EURIBOR_3M": D(".025")})).generate(
            LoanPosition(terms, CLOSE, D(100)))
        self.assertEqual(reference[-1].accrual_end, nominal)
        self.assertEqual(reference[-1].payment_date, paid)
        self.assertEqual(reference[-1].pik_capitalization_date, paid)
        self.assertEqual([row.pik_interest for row in reference], [D(3), D("3.02")])
        self.assertEqual(reference[-1].principal_repayment, D("106.02"))
        exposure = AssetExposure("L", None, None, None, None, None, "EUR", D(100), None,
            nominal, is_pik=True, coupon_type=CouponType.FIXED, fixed_coupon_rate=D(".12"))
        for overlay in (None, OriginalPoolOverlay(True, annual_default_rate=D(0), annual_prepayment_rate=D(0))):
            with self.subTest(overlay=overlay is not None):
                _, result = project(reference, (tranche(par="80", rate="0", pik="0"),),
                    par="100", original_pool_overlay=overlay)
                self.assertEqual(result.total_equity_distributions, D("26.02"))
                self.assertEqual(result.final_collateral_par, 0)
                self.assertEqual(sum(p.collateral_non_cash_par_change for p in result.periods), D("6.02"))
                scanner = PortfolioStateScanner((exposure,), reference, result)
                self.assertNotIn(nominal, scanner.event_dates)
                before, after, final = scanner.scan((date(2026, 7, 16), paid, FINAL))
                self.assertEqual([r.total_par for r in (before, after, final)], [D(103), D(0), D(0)])

    def test_native_pik_enlarges_par_and_redemption_cash_once(self):
        _, projection = project((cashflow(1, CLOSE, FIRST, "100", "0", "0", pik="10"),
            cashflow(2, FIRST, FINAL, "110", "121", "0", pik="11")),
            (tranche(par="80", rate="0", pik="0"),), par="100")
        self.assertEqual(projection.periods[0].closing_collateral_par, D("110"))
        self.assertEqual(projection.periods[0].collateral_non_cash_par_change, D("10"))
        self.assertEqual(projection.periods[1].received_asset_principal, D("121"))
        self.assertEqual(projection.periods[1].collateral_non_cash_par_change, D("11"))
        self.assertEqual(projection.total_equity_distributions, D("41"))
        self.assertEqual(projection.status, ProjectionStatus.COMPLETED)

    def test_pik_date_precedes_lagged_principal_settlement(self):
        # Capitalization at April 20 precedes principal cash on April 22.
        # A quarterly note pays April 20, then receives the 110 in July.
        _, projection = project((cashflow(1, CLOSE, FIRST, "100", "110", "0", pik="10", paid=date(2026, 4, 22)),),
            (tranche(par="80", rate="0", pik="0"),), par="100")
        first, second = projection.periods
        self.assertEqual((first.closing_collateral_par, first.received_asset_principal), (D("110"), D(0)))
        self.assertEqual((second.closing_collateral_par, second.received_asset_principal), (D(0), D("110")))
        self.assertEqual(projection.total_equity_distributions, D("30"))

    def test_lagged_pik_overlay_keeps_capitalization_date_without_early_cpr(self):
        overlay = OriginalPoolOverlay(True, annual_default_rate=D(0), annual_prepayment_rate=D(1))
        _, projection = project((cashflow(1, CLOSE, FIRST, "100", "110", "0", pik="10", paid=date(2026, 4, 22)),),
            (tranche(par="80", rate="0", pik="0"),), par="100", original_pool_overlay=overlay)
        first, second = projection.periods
        self.assertEqual((first.closing_collateral_par, first.received_asset_principal), (D("110"), D(0)))
        self.assertEqual(first.collateral_non_cash_par_change, D("10"))
        self.assertEqual((second.closing_collateral_par, second.received_asset_principal), (D(0), D("110")))
        self.assertEqual(second.scheduled_principal_received, D("110"))
        self.assertEqual(second.prepayment_principal_received, D(0))
        self.assertEqual(projection.total_equity_distributions, D("30"))

    def test_overlay_full_default_forfeits_unposted_pik(self):
        overlay = OriginalPoolOverlay(True, annual_default_rate=D(1), annual_prepayment_rate=D(0),
                                      recovery_rate=D(".6"), recovery_lag_months=0)
        _, projection = project((cashflow(1, CLOSE, FIRST, "100", "110", "0", pik="10", paid=date(2026, 4, 22)),),
            (tranche(par="80", rate="0", pik="0"),), par="100", original_pool_overlay=overlay,
            defaulted_asset_oc_treatment=DefaultedAssetOcTreatment.EXCLUDE)
        self.assertEqual(projection.total_defaulted_exposure, D("100"))
        self.assertEqual(projection.total_recovery_collections, D("60"))
        self.assertEqual(projection.total_recognized_par_loss, D("40"))
        self.assertTrue(all(row.collateral_non_cash_par_change == 0 for row in projection.periods))
        self.assertTrue(all(row.cash_conservation_residual == 0 for row in projection.periods))

    def test_explicit_default_carries_previous_capitalized_pik_to_recovery(self):
        from test_clo_credit import position, PROVIDER
        from trident.cashflows.engine import ContractualCashflowEngine
        held = position(interest_mode=InterestMode.PIK, pik_fraction=D(1))
        contractual = ContractualCashflowEngine(PROVIDER).generate(held)
        event = DefaultEvent("L", date(2026, 4, 21), (RecoveryEvent(date(2026, 8, 20), D(".8")),), date(2026, 8, 20))
        stressed = CreditEventCashflowEngine(PROVIDER).apply(held, contractual, event)
        request = CloRunRequest(contractual, D("100"), (tranche(par="60", rate="0", pik="0"),),
            CloTerms(CLOSE, date(2028, 1, 20), defaulted_asset_oc_treatment=DefaultedAssetOcTreatment.EXCLUDE),
            (stressed,))
        projection = DeterministicCloEngine(PROVIDER).run(request)
        self.assertEqual(projection.periods[0].closing_collateral_par, D("101"))
        self.assertEqual(projection.periods[0].collateral_non_cash_par_change, D("1"))
        self.assertEqual(projection.total_defaulted_exposure, D("101"))
        self.assertEqual(projection.total_recovery_collections, D("80.80"))
        self.assertEqual(projection.total_equity_distributions, D("20.80"))
        self.assertEqual(projection.status, ProjectionStatus.COMPLETED)

    def test_explicit_prepayment_capitalizes_current_pik_and_redeems_once(self):
        from test_clo_credit import position, PROVIDER
        from trident.cashflows.engine import ContractualCashflowEngine
        held = position(interest_mode=InterestMode.PIK, pik_fraction=D(1))
        contractual = ContractualCashflowEngine(PROVIDER).generate(held)
        stressed = CreditEventCashflowEngine(PROVIDER).apply(held, contractual, PrepaymentEvent("L", date(2026, 2, 15)))
        request = CloRunRequest(contractual, D("100"), (tranche(par="60", rate="0", pik="0"),), CloTerms(CLOSE, FINAL), (stressed,))
        projection = DeterministicCloEngine(PROVIDER).run(request)
        self.assertEqual(projection.periods[0].collateral_non_cash_par_change, D(".29"))
        self.assertEqual(projection.periods[0].prepayment_principal_received, D("100.29"))
        self.assertEqual(projection.periods[0].received_asset_interest, D(0))
        self.assertEqual(projection.total_equity_distributions, D("40.29"))
        self.assertEqual(projection.status, ProjectionStatus.COMPLETED)


class CloEconomicsTests(unittest.TestCase):
    def test_closing_leverage_fees_actual_cash_and_terminal_return(self):
        request, projection = project((cashflow(1, CLOSE, FIRST, "100", "0", "5"),
            cashflow(2, FIRST, FINAL, "100", "100", "5")),
            (tranche(par="80", rate=".04", pik="0"),), par="100", annual_senior_expenses=D("3.65"))
        funding = FundingEngine().calculate((AssetPurchase("L", D("100"), D("98")),),
            (DebtIssue("A", D("80"), D("100")),), upfront_fees=D("2"), cash_reserve=D(0))
        metrics = {row.metric_id: row for row in report_clo_economics(request, projection, funding)}
        self.assertEqual(funding.equity_cash_funding, D("20"))
        self.assertEqual(metrics["DEBT_TO_EQUITY_CASH"].value, D("4"))
        self.assertEqual(metrics["COLLATERAL_TO_EQUITY_CASH"].value, D("5"))
        self.assertEqual(metrics["TOTAL_FEES_PAID"].value, D("3.81"))
        self.assertEqual(metrics["CASH_DEBT_COST"].numerator, D("1.61"))
        self.assertEqual(metrics["EQUITY_MOIC"].status, EconomicsStatus.AVAILABLE)
        self.assertEqual(metrics["EQUITY_XIRR"].status, EconomicsStatus.AVAILABLE)
        self.assertEqual(metrics["ORIGINAL_REALIZED_CASH_YIELD"].numerator, D("10"))
        self.assertAlmostEqual(metrics["ORIGINAL_REALIZED_CASH_YIELD"].denominator, D("100") * D(181) / D(365), places=24)

    def test_pik_cash_cost_zero_accrued_cost_positive(self):
        request, projection = project((cashflow(1, CLOSE, FIRST, "200", "0", "0"),
            cashflow(2, FIRST, FINAL, "200", "200", "0")), (tranche(),))
        metrics = {row.metric_id: row for row in report_clo_economics(request, projection)}
        self.assertEqual(metrics["CASH_DEBT_COST"].value, D(0))
        self.assertEqual(metrics["ACCRUED_DEBT_COST"].numerator, D("5.09"))
        self.assertEqual(metrics["TOTAL_NOTE_PIK_CAPITALIZED"].value, D("5.09"))
        self.assertEqual(metrics["EQUITY_XIRR"].status, EconomicsStatus.UNAVAILABLE)
        self.assertEqual(metrics["REINVESTMENT_REALIZED_CASH_YIELD"].status, EconomicsStatus.UNAVAILABLE)

    def test_floating_spread_population_excludes_fixed_notes(self):
        fixed = tranche(par="20", rate=".04", pik="0")
        floating = NoteTranche("B", 2, D("80"), CouponType.FLOATING, rate_index="EURIBOR_3M", spread_bps=D("300"))
        request, projection = project((cashflow(1, CLOSE, FIRST, "200", "0", "10"),
            cashflow(2, FIRST, FINAL, "200", "200", "10")), (fixed, floating))
        metrics = {row.metric_id: row for row in report_clo_economics(request, projection)}
        self.assertEqual(metrics["WEIGHTED_FLOATING_DEBT_SPREAD_BPS"].value, D("300"))
        self.assertEqual(metrics["WEIGHTED_FIXED_DEBT_COUPON"].value, D(".04"))

    def test_reinvestment_reference_spread_add_to_actual_cash(self):
        policy = SyntheticReinvestmentPolicy(enabled=True, end_date=FIRST, purchase_price=D(1),
            bullet_wal_years=D(".25"), annual_prepayment_rate=D(0), annual_default_rate=D(0), spread_bps=D("400"))
        request, projection = project((cashflow(1, CLOSE, FIRST, "200", "100", "0"),
            cashflow(2, FIRST, FINAL, "100", "100", "0")), (tranche(par="80", rate="0", pik="0"),),
            synthetic_reinvestment_policy=policy)
        metrics = {row.metric_id: row for row in report_clo_economics(request, projection)}
        self.assertEqual(metrics["REINVESTMENT_REALIZED_CASH_YIELD"].numerator,
            metrics["REINVESTMENT_REFERENCE_CASH_YIELD"].numerator + metrics["REINVESTMENT_SPREAD_CASH_YIELD"].numerator)
        self.assertEqual(metrics["TOTAL_REINVESTMENT_PAR_ACQUIRED"].value, D("100"))
        self.assertGreater(metrics["REINVESTMENT_REALIZED_CASH_YIELD"].value, D(0))

    def test_native_contractual_coupon_uses_its_unstressed_matching_exposure(self):
        from test_clo_credit import position, PROVIDER
        from trident.cashflows.engine import ContractualCashflowEngine
        held = position()
        contractual = ContractualCashflowEngine(PROVIDER).generate(held)
        overlay = OriginalPoolOverlay(True, annual_default_rate=D(1), annual_prepayment_rate=D(0),
                                      recovery_rate=D(".6"), recovery_lag_months=0)
        request = CloRunRequest(contractual, D("100"), (tranche(par="60", rate="0", pik="0"),),
            CloTerms(CLOSE, date(2028, 1, 20), original_pool_overlay=overlay,
                     defaulted_asset_oc_treatment=DefaultedAssetOcTreatment.EXCLUDE),
            asset_day_counts={"L": held.terms.day_count})
        projection = DeterministicCloEngine(PROVIDER).run(request)
        metrics = {row.metric_id: row for row in report_clo_economics(request, projection)}
        self.assertEqual(metrics["ORIGINAL_REALIZED_CASH_YIELD"].value, D(0))
        self.assertAlmostEqual(metrics["ORIGINAL_CONTRACTUAL_COUPON_YIELD"].value, D(".04"), places=24)
        self.assertAlmostEqual(metrics["ORIGINAL_CONTRACTUAL_FIXED_COUPON_YIELD"].value, D(".04"), places=24)
        self.assertEqual(metrics["ORIGINAL_CONTRACTUAL_REFERENCE_YIELD"].value, D(0))

    def test_equity_one_year_twenty_percent_known_answer(self):
        third, final = date(2026, 10, 20), date(2027, 1, 20)
        request = CloRunRequest((cashflow(1, CLOSE, FIRST, "100", "0", "0"),
            cashflow(2, FIRST, FINAL, "100", "0", "0"),
            cashflow(3, FINAL, third, "100", "0", "0"),
            cashflow(4, third, final, "100", "100", "4")), D("100"),
            (tranche(par="80", rate="0", pik="0"),), CloTerms(CLOSE, final))
        projection = DeterministicCloEngine(FlatRateProvider({"EURIBOR_3M": D(".025")})).run(request)
        funding = FundingEngine().calculate((AssetPurchase("L", D("100"), D("98")),),
            (DebtIssue("A", D("80"), D("100")),), upfront_fees=D("2"), cash_reserve=D(0))
        metrics = {row.metric_id: row for row in report_clo_economics(request, projection, funding)}
        self.assertEqual(metrics["EQUITY_MOIC"].value, D("1.2"))
        self.assertAlmostEqual(metrics["EQUITY_XIRR"].value, D(".20"), places=11)
        # Deliberately narrow caller precision cannot alter posted sums or
        # quotient values: reporting must not depend on global Decimal state.
        with localcontext() as context:
            context.prec = 6
            narrowed = {row.metric_id: row for row in report_clo_economics(request, projection, funding)}
        self.assertEqual(narrowed, metrics)


if __name__ == "__main__":
    unittest.main()
