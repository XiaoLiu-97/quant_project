"""Transfer artifact-authored guidance text without round-tripping financial data.

The artifact builder owns the text and row heights. Its full-workbook export
can normalize unrelated strings/styles, so this packaging step transfers only
twenty known presentation cells. All other package parts remain byte-identical.
These layout addresses never identify financial inputs or calculation fields.
"""

import argparse
from copy import deepcopy
import os
from pathlib import Path
import posixpath
import re
import tempfile
from xml.etree import ElementTree as ET
from zipfile import ZipFile

ROOT = Path(__file__).resolve().parents[1]
NS = 'http://schemas.openxmlformats.org/spreadsheetml/2006/main'
REL = 'http://schemas.openxmlformats.org/officeDocument/2006/relationships'
def Q(name: str) -> str:
    """Qualify an OpenXML worksheet element."""
    return f'{{{NS}}}{name}'
CELLS = {'A3': 'A3', 'B14': 'B14', 'B17': 'B14', 'B18': 'B14', 'B58': 'B14',
         'B34': 'B34', 'A66': 'A34', 'B66': 'B34',
         'A68': 'A34', 'B68': 'B34', 'A70': 'A34', 'B70': 'B34', 'A72': 'A34', 'B72': 'B34',
         'A74': 'A34', 'B74': 'B34', 'A76': 'A34', 'B76': 'B34',
         'A78': 'A34', 'B78': 'B34', 'A80': 'A34', 'B80': 'B34', 'A82': 'A34', 'B82': 'B34'}
OWNED_HEIGHTS = {14, 17, 18, 34, 58, 66, 68, 70, 72, 74, 76, 78, 80, 82}


def guidance_part(package: ZipFile) -> str:
    """Resolve the sheet by title and relationship, never worksheet numbering."""
    workbook = ET.fromstring(package.read('xl/workbook.xml'))
    sheets = [sheet for sheet in workbook.find(Q('sheets')) if sheet.get('name') == 'Guidance']
    if len(sheets) != 1:
        raise ValueError('Exactly one Guidance sheet is required')
    identity = sheets[0].get(f'{{{REL}}}id')
    links = ET.fromstring(package.read('xl/_rels/workbook.xml.rels'))
    targets = [link.get('Target') for link in links if link.get('Id') == identity
               and link.get('TargetMode') != 'External']
    if len(targets) != 1:
        raise ValueError('Guidance must have an internal worksheet relationship')
    return posixpath.normpath(targets[0].lstrip('/') if targets[0].startswith('/') else 'xl/' + targets[0])


def apply_guidance_patch(original: Path, authored: Path) -> None:
    """Atomic text-only merge; retain original style IDs and package features.

    Shared strings become inline strings only in the whitelisted transferred cells,
    avoiding foreign shared-string indices. Original cell style IDs are used;
    new cells inherit the adjacent existing guidance style. Only the authored
    heights for the owned instruction rows transfer. Formula/number donors fail.
    """
    destination, source = original.resolve(strict=True), authored.resolve(strict=True)
    if destination == source or any(not p.is_relative_to(ROOT) or p.suffix.lower() != '.xlsx'
                                    for p in (destination, source)):
        raise ValueError('Distinct .xlsx guidance packages must stay within the workspace')
    with ZipFile(destination) as base, ZipFile(source) as donor:
        if len(base.namelist()) != len(set(base.namelist())):
            raise ValueError('Duplicate original package parts')
        part = guidance_part(base)
        sheet, edited = ET.fromstring(base.read(part)), ET.fromstring(donor.read(guidance_part(donor)))
        data, donated_data = sheet.find(Q('sheetData')), edited.find(Q('sheetData'))
        cells = {cell.get('r'): cell for cell in data.iter(Q('c'))}
        donated = {cell.get('r'): cell for cell in donated_data.iter(Q('c'))}
        strings = (list(ET.fromstring(donor.read('xl/sharedStrings.xml')))
                   if 'xl/sharedStrings.xml' in donor.namelist() else [])
        for address, template in CELLS.items():
            cell = donated[address]
            if cell.find(Q('f')) is not None or cell.get('t') not in {'s', 'inlineStr', 'str'}:
                raise ValueError('Guidance donor cells must contain literal text')
            if cell.get('t') == 'str':
                text = ET.Element(Q('is'))
                ET.SubElement(text, Q('t')).text = cell.find(Q('v')).text
            else:
                text = (strings[int(cell.find(Q('v')).text)] if cell.get('t') == 's' else cell.find(Q('is')))
            replacement = ET.Element(Q('c'), {'r': address, 't': 'inlineStr'})
            if cells[template].get('s') is not None:
                replacement.set('s', cells[template].get('s'))
            inline = deepcopy(text)
            inline.tag = Q('is')
            replacement.append(inline)
            number = int(''.join(char for char in address if char.isdigit()))
            row = next((item for item in data if int(item.get('r')) == number), None)
            if row is None:
                row = ET.Element(Q('row'), {'r': str(number)})
                index = next((i for i, item in enumerate(data) if int(item.get('r')) > number), len(data))
                data.insert(index, row)
            old = cells.get(address)
            if old is not None:
                index = list(row).index(old)
                row.remove(old)
                row.insert(index, replacement)
            else:
                row.append(replacement)
            if number in OWNED_HEIGHTS:
                donor_row = next(item for item in donated_data if int(item.get('r')) == number)
                if donor_row.get('ht') is not None:
                    row.set('ht', donor_row.get('ht'))
                    row.set('customHeight', '1')
        dimension = sheet.find(Q('dimension'))
        if dimension is not None:
            reference = dimension.get('ref')
            end_row = int(re.search(r'(\d+)$', reference).group(1))
            dimension.set('ref', re.sub(r'\d+$', str(max(OWNED_HEIGHTS | {end_row})), reference))
        ET.register_namespace('', NS)
        descriptor, name = tempfile.mkstemp(dir=destination.parent, prefix='.guidance-', suffix='.xlsx')
        os.close(descriptor)
        temporary = Path(name)
        try:
            with ZipFile(temporary, 'w') as output:
                output.comment = base.comment
                for entry in base.infolist():
                    output.writestr(entry, ET.tostring(sheet, encoding='utf-8', xml_declaration=True)
                                    if entry.filename == part else base.read(entry))
        except BaseException:
            temporary.unlink(missing_ok=True)
            raise
    try:
        os.replace(temporary, destination)
    finally:
        temporary.unlink(missing_ok=True)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--original', type=Path, required=True)
    parser.add_argument('--authored', type=Path, required=True)
    options = parser.parse_args()
    apply_guidance_patch(options.original, options.authored)
