"""Frozen candidate data admission and exact static proposal reconciliation.

Bloomberg formula cells are transport, never live financial inputs here. The
caller freezes values, records their actual observation times and supplies a
verified contract. Ratings retain their agency and level; this module does not
invent an agency factor or infer a complete loan contract from a spread/price.
"""

from dataclasses import dataclass
from datetime import date, datetime, timedelta
from decimal import Decimal
from enum import Enum
from fractions import Fraction

from trident.analysis.models import AssetExposure
from trident.domain.models import (
    CouponType, InputValidationError, LoanPosition, require_date, require_decimal, require_money,
)
from trident.domain.numeric import post_currency
from trident.optimization.linear import verify_static_amounts
from trident.optimization.models import (
    AssetDescriptor, AssetKind, Holding, OptimizationRequest, OptimizationResult,
    ProposedTrade, TradeQuote, TradeSide,
)


def _text(value: object, label: str) -> None:
    if not isinstance(value, str) or not value or value != value.strip():
        raise InputValidationError(f"{label} must be nonempty, unpadded text")


def _timestamp(value: object, label: str) -> None:
    if type(value) is not datetime or value.tzinfo is None or value.utcoffset() is None:
        raise InputValidationError(f"{label} must be a timezone-aware datetime")


class RatingLevel(str, Enum):
    ISSUER = "ISSUER"
    FACILITY = "FACILITY"


class RatingNature(str, Enum):
    PUBLIC = "PUBLIC"
    CREDIT_ESTIMATE = "CREDIT_ESTIMATE"
    INTERNAL = "INTERNAL"


class PriceSide(str, Enum):
    BID = "BID"
    ASK = "ASK"
    MID = "MID"
    LAST = "LAST"


class QuoteQuality(str, Enum):
    FIRM = "FIRM"
    INDICATIVE = "INDICATIVE"
    EVALUATED = "EVALUATED"


class CandidateCreditStatus(str, Enum):
    PERFORMING = "PERFORMING"
    DEFAULTED = "DEFAULTED"
    DISTRESSED = "DISTRESSED"
    UNKNOWN = "UNKNOWN"


@dataclass(frozen=True)
class RatingObservation:
    """One sourced agency/entity or agency/facility rating, without notching.

    ``as_of_date`` is the rating effective/observation date from the source,
    not the time that Excel refreshed. A missing public rating is not an
    implicit internal rating. Credit estimates and internal ratings stay apart.
    """

    agency: str
    rating: str
    level: RatingLevel
    nature: RatingNature
    subject_id: str
    as_of_date: date
    source: str

    def __post_init__(self) -> None:
        for label in ("agency", "rating", "subject_id", "source"):
            _text(getattr(self, label), label)
        if not isinstance(self.level, RatingLevel) or not isinstance(self.nature, RatingNature):
            raise InputValidationError("Rating level/nature have incorrect types")
        require_date(self.as_of_date, "rating as_of_date")


@dataclass(frozen=True)
class PriceObservation:
    """Sourced side-specific clean quote and explicit settlement economics.

    Quote availability, lots, accrued per par and fees are supplied separately
    in TradeQuote. An indicative/evaluated quote can only enter research when
    the admission policy expressly permits that quality. It remains labelled.
    """

    quote: TradeQuote
    price_side: PriceSide
    quality: QuoteQuality
    observed_at: datetime
    settlement_date: date
    source: str

    def __post_init__(self) -> None:
        if not isinstance(self.quote, TradeQuote):
            raise InputValidationError("quote must be TradeQuote")
        if not isinstance(self.price_side, PriceSide) or not isinstance(self.quality, QuoteQuality):
            raise InputValidationError("Price side/quality have incorrect types")
        _timestamp(self.observed_at, "price observed_at")
        require_date(self.settlement_date, "quote settlement_date")
        _text(self.source, "price source")


@dataclass(frozen=True)
class CandidateAssetSnapshot:
    """Frozen facility identity, static metrics, contract and price observations.

    A missing contract/provenance/rating can be represented and quarantined.
    LoanPosition's opening balance is a contract sizing reference; it is not an
    assertion that the CLO owns that par. Quotes carry available trade amounts.
    Existing positions remain independently supplied in OptimizationRequest.

    ``facility_id`` retains the published field name but means a canonical
    tradable loan tranche identity. It is not an umbrella deal/facility FIGI
    grouping several independently tradable tranches. Source aliases and
    repriced/refinanced tranche identifiers need explicit reconciliation before
    a snapshot is admitted; Bloomberg/OpenFIGI symbols are not economic IDs.
    """

    asset: AssetDescriptor
    facility_id: str
    bloomberg_security: str
    position: LoanPosition | None
    exposure: AssetExposure | None
    ratings: tuple[RatingObservation, ...]
    prices: tuple[PriceObservation, ...]
    contract_provenance: str | None
    classification_provenance: str | None
    credit_status: CandidateCreditStatus | None = None

    def __post_init__(self) -> None:
        if not isinstance(self.asset, AssetDescriptor):
            raise InputValidationError("candidate asset must be AssetDescriptor")
        _text(self.facility_id, "facility_id")
        _text(self.bloomberg_security, "bloomberg_security")
        if self.position is not None and not isinstance(self.position, LoanPosition):
            raise InputValidationError("candidate position must be LoanPosition or None")
        if self.exposure is not None and not isinstance(self.exposure, AssetExposure):
            raise InputValidationError("candidate exposure must be AssetExposure or None")
        if self.credit_status is not None and not isinstance(self.credit_status, CandidateCreditStatus):
            raise InputValidationError("candidate credit_status must be CandidateCreditStatus or None")
        for label in ("contract_provenance", "classification_provenance"):
            value = getattr(self, label)
            if value is not None:
                _text(value, label)
        for label, item_type in (("ratings", RatingObservation), ("prices", PriceObservation)):
            values = getattr(self, label)
            if type(values) is not tuple or any(not isinstance(item, item_type) for item in values):
                raise InputValidationError(f"candidate {label} must be an immutable tuple of {item_type.__name__}")
        keys = tuple((r.agency, r.level, r.nature, r.subject_id) for r in self.ratings)
        if len(set(keys)) != len(keys):
            raise InputValidationError("Duplicate rating observation; select one observation per rating identity")
        sides = tuple(p.quote.side for p in self.prices)
        if len(set(sides)) != len(sides):
            raise InputValidationError("Only one price observation per trade side is supported")

    @property
    def asset_id(self) -> str:
        return self.asset.asset_id


@dataclass(frozen=True)
class CandidateUniverseSnapshot:
    """Versioned frozen values, independent of asynchronously refreshing Excel.

    Asset IDs and canonical tradable tranche IDs (published ``facility_id``)
    are both unique; aliases for one tranche cannot become two economic assets.
    Different tranches must not share an umbrella parent ID here.
    ``factor_provenance`` names
    the explicitly selected mapping/version for the static descriptor factors.
    It never implies that agency ratings were mapped correctly by Bloomberg.
    """

    snapshot_id: str
    captured_at: datetime
    source: str
    factor_provenance: str
    candidates: tuple[CandidateAssetSnapshot, ...]

    def __post_init__(self) -> None:
        for label in ("snapshot_id", "source", "factor_provenance"):
            _text(getattr(self, label), label)
        _timestamp(self.captured_at, "snapshot captured_at")
        if type(self.candidates) is not tuple or any(not isinstance(c, CandidateAssetSnapshot) for c in self.candidates):
            raise InputValidationError("candidates must be a tuple of CandidateAssetSnapshot")
        for label in ("asset_id", "facility_id"):
            values = tuple(getattr(c, label) for c in self.candidates)
            if len(set(values)) != len(values):
                raise InputValidationError(f"Duplicate candidate {label}; aliases must be reconciled before admission")


@dataclass(frozen=True)
class CandidateAdmissionPolicy:
    """Explicit research mandate; age is measured at snapshot capture time.

    Snapshot capture must be on or before settlement in the timestamp's
    explicitly supplied offset calendar date. Settlement has no intraday
    timestamp/timezone in this interface, so this is a day-level chronology
    check, not an assertion about same-day quote availability at closing.
    The current full cashflow replay supports EUR performing floating BSLs from
    a known opening accrual boundary. This gate deliberately does not stand in
    for an indenture eligibility opinion or an agency rating methodology.
    """

    settlement_date: date
    maximum_quote_age: timedelta
    allowed_quote_qualities: tuple[QuoteQuality, ...]

    def __post_init__(self) -> None:
        require_date(self.settlement_date, "admission settlement_date")
        if type(self.maximum_quote_age) is not timedelta or self.maximum_quote_age < timedelta(0):
            raise InputValidationError("maximum_quote_age must be an explicit nonnegative timedelta")
        if type(self.allowed_quote_qualities) is not tuple or not self.allowed_quote_qualities or any(
            not isinstance(q, QuoteQuality) for q in self.allowed_quote_qualities
        ) or len(set(self.allowed_quote_qualities)) != len(self.allowed_quote_qualities):
            raise InputValidationError("allowed_quote_qualities must be a nonempty unique tuple of QuoteQuality")


@dataclass(frozen=True)
class QuarantinedCandidate:
    asset_id: str
    reasons: tuple[str, ...]


@dataclass(frozen=True)
class CandidateAdmissionResult:
    snapshot_id: str
    factor_provenance: str
    admitted: tuple[CandidateAssetSnapshot, ...]
    quarantined: tuple[QuarantinedCandidate, ...]
    validation_scope: str = "DATA_AND_OPENING_REPLAY_ADMISSION"


class CandidateUniverseValidator:
    """Classify each well-formed frozen candidate without silently filling gaps."""

    def validate(self, snapshot: CandidateUniverseSnapshot, policy: CandidateAdmissionPolicy) -> CandidateAdmissionResult:
        """Quarantine per-facility gaps; reject inconsistent common chronology.

        Validation is linear in observations apart from stable asset-ID sorting.
        Missing data remains an explicit reason instead of a guessed convention,
        so downstream optimizers cannot favor unsupported cheap/risky assets.
        """
        if not isinstance(snapshot, CandidateUniverseSnapshot) or not isinstance(policy, CandidateAdmissionPolicy):
            raise InputValidationError("snapshot/policy have incorrect types")
        # A stale opening contract must not admit a later market snapshot as
        # though its quotes/ratings were available at the historical closing.
        # This is a common request error, not a candidate-specific quarantine.
        # Preserve the supplied offset: a date-only settlement cannot support
        # an inferred timezone or an unprovided same-day closing time.
        if snapshot.captured_at.date() > policy.settlement_date:
            raise InputValidationError("Candidate snapshot capture calendar date must not lie after settlement date; closing replay cannot use future market information")
        admitted, quarantined = [], []
        for candidate in sorted(snapshot.candidates, key=lambda c: c.asset_id):
            reasons = self._reasons(candidate, snapshot, policy)
            if reasons:
                quarantined.append(QuarantinedCandidate(candidate.asset_id, tuple(reasons)))
            else:
                admitted.append(candidate)
        return CandidateAdmissionResult(snapshot.snapshot_id, snapshot.factor_provenance,
                                        tuple(admitted), tuple(quarantined))

    @staticmethod
    def _reasons(candidate: CandidateAssetSnapshot, snapshot: CandidateUniverseSnapshot,
                 policy: CandidateAdmissionPolicy) -> list[str]:
        reasons: list[str] = []
        if candidate.asset.kind is not AssetKind.BSL:
            reasons.append("Candidate universe permits BSL trading only")
        if candidate.credit_status is not CandidateCreditStatus.PERFORMING:
            reasons.append("Explicit current PERFORMING status is required; rating is not performance state")
        if candidate.contract_provenance is None:
            reasons.append("Verified contract provenance is missing")
        if candidate.classification_provenance is None:
            reasons.append("Obligor/country/sector classification provenance is missing")
        if not candidate.ratings:
            reasons.append("Explicit agency/level/nature rating observations are missing")
        for rating in candidate.ratings:
            # A facility and its issuer may have different ratings. Subject
            # identity is preserved; no issuer-to-loan notching is invented.
            if rating.as_of_date > snapshot.captured_at.date():
                reasons.append(f"{rating.agency}: rating observation lies after snapshot capture")
            if rating.level is RatingLevel.FACILITY and rating.subject_id != candidate.facility_id:
                reasons.append(f"{rating.agency}: facility rating subject does not match facility_id")
            if rating.level is RatingLevel.ISSUER and rating.subject_id != candidate.asset.obligor:
                reasons.append(f"{rating.agency}: issuer rating subject does not match obligor")
        position = candidate.position
        if position is None:
            reasons.append("Complete typed loan contract is missing")
        else:
            terms = position.terms
            if terms.loan_id != candidate.asset_id:
                reasons.append("Contract loan_id differs from economic asset_id")
            if terms.currency != "EUR":
                reasons.append("Opening replay currently supports EUR collateral only")
            if (position.par_as_of_date != policy.settlement_date
                    or (terms.start_date != policy.settlement_date and position.seasoned_state is None)):
                reasons.append("Contract held-par snapshot does not match settlement date")
            if position.seasoned_state is not None and any(
                    fixing.fixing_date > snapshot.captured_at.date()
                    for fixing in position.seasoned_state.fixing_observations):
                # Carried fixings are actual observations, unlike a projected
                # curve or an earned coupon claim computed from known rates.
                # A previous-day frozen universe cannot know settlement-day
                # observations. Date-only metadata proves no intraday cutoff.
                reasons.append("Opening fixing observation lies after frozen candidate snapshot capture")
            if terms.coupon_type is not CouponType.FLOATING:
                reasons.append("Static spread objective admission currently requires floating BSLs")
            elif terms.spread_bps != candidate.asset.spread_bps:
                # Static LP/MILP coefficients describe the opening quoted
                # margin, even for a stepped contract. Complete LoanTerms and
                # its dated policy stay attached to the admitted position;
                # full CLO replay assesses future cash and dated WAS limits.
                reasons.append("Static spread_bps differs from contractual quoted margin")
        exposure = candidate.exposure
        if exposure is None:
            reasons.append("Complete typed portfolio quality exposure is missing")
        else:
            descriptor_fields = ((exposure.loan_id, candidate.asset_id),
                                 (exposure.obligor, candidate.asset.obligor),
                                 (exposure.country, candidate.asset.country),
                                 (exposure.sector, candidate.asset.sector),
                                 (exposure.asset_class, candidate.asset.kind.value))
            if any(actual != expected for actual, expected in descriptor_fields):
                reasons.append("Quality exposure identity/classification differs from static descriptor")
            if exposure.financing_type is None or any(getattr(exposure, name) is None for name in (
                "is_senior", "is_secured", "is_pik", "is_revolver", "is_construction",
            )):
                reasons.append("Explicit financing type and all quality flags are required; missing is not False")
            if exposure.is_pik is True:
                reasons.append("Opening replay does not support PIK collateral")
            if exposure.is_revolver is True or exposure.is_construction is True:
                reasons.append("Opening replay currently requires funded loans without contingent revolver/construction commitments")
            if position is not None and (
                exposure.par != position.opening_balance or exposure.currency != position.terms.currency
                or exposure.maturity_date != position.terms.maturity_date
                or exposure.spread_bps != position.terms.spread_bps
            ):
                reasons.append("Quality exposure par/currency/maturity/margin differs from complete contract")
            if position is not None and exposure.coupon_type is not None and exposure.coupon_type is not position.terms.coupon_type:
                reasons.append("Explicit quality coupon type differs from verified contract")
            if position is not None and exposure.fixed_coupon_rate is not None:
                expected_fixed = (position.terms.fixed_rate
                                  if position.terms.coupon_type is CouponType.FIXED else None)
                if exposure.fixed_coupon_rate != expected_fixed:
                    reasons.append("Explicit quality fixed coupon differs from verified contract")
        if not candidate.prices:
            reasons.append("Side-specific trade price/availability is missing")
        for price in candidate.prices:
            quote = price.quote
            prefix = quote.side.value
            if quote.asset != candidate.asset:
                reasons.append(f"{prefix}: quote metadata differs from candidate descriptor")
            if price.settlement_date != policy.settlement_date:
                reasons.append(f"{prefix}: quote economics settlement date differs from mandate")
            expected = PriceSide.ASK if quote.side is TradeSide.BUY else PriceSide.BID
            if price.price_side is not expected:
                reasons.append(f"{prefix}: requires {expected.value}, not {price.price_side.value}")
            # Age is based on the actual market observation, not formula refresh
            # time. A freshly refreshed stale bid remains stale; a future price
            # is look-ahead information even if settlement is the same date.
            age = snapshot.captured_at - price.observed_at
            if age < timedelta(0):
                reasons.append(f"{prefix}: price observation lies after snapshot capture")
            elif age > policy.maximum_quote_age:
                reasons.append(f"{prefix}: price observation exceeds maximum_quote_age")
            if price.quality not in policy.allowed_quote_qualities:
                reasons.append(f"{prefix}: {price.quality.value} quote quality is outside the research mandate")
            if position is not None and quote.maximum_par > position.opening_balance:
                reasons.append(f"{prefix}: quoted availability exceeds verified contract sizing reference")
        return reasons


@dataclass(frozen=True)
class HoldingChange:
    asset_id: str
    asset: AssetDescriptor
    baseline_par: Decimal
    target_par: Decimal
    signed_trade_par: Decimal


@dataclass(frozen=True)
class TargetPoolPlan:
    """Exact target holdings/trade bridge for a validated static proposal.

    This is a proposal, not an executed trade or prospective CLO compliance
    certificate. The application layer must classify proceeds and rerun the
    full cashflow/waterfall/scenario services before using investor returns.
    """

    settlement_date: date
    factor_provenance: str
    starting_cash: Decimal
    ending_cash: Decimal
    ending_par: Decimal
    holdings: tuple[Holding, ...]
    trades: tuple[ProposedTrade, ...]
    changes: tuple[HoldingChange, ...]
    validation_scope: str = "STATIC_PROPOSAL_RECONCILED"


def reconcile_proposal(request: OptimizationRequest, result: OptimizationResult) -> TargetPoolPlan:
    """Independently reconcile signed quantities and posted settlement amounts.

    O((holdings + quotes + trades) log n), including stable asset-ID output
    sorting. This boundary reconstructs the permitted posted trade ledger and
    rechecks every exact mandate inequality. Solver status and self-reported
    diagnostics alone do not establish feasibility, including for injected
    optimizers or externally reconstructed proposals.
    """
    if not isinstance(request, OptimizationRequest) or not isinstance(result, OptimizationResult):
        raise InputValidationError("request/result have incorrect types")
    if not result.validated or result.validation_scope != "STATIC_ONLY":
        raise InputValidationError("Only a validated STATIC_ONLY proposal can be reconciled")
    if result.factor_provenance != request.factor_provenance:
        raise InputValidationError("Proposal factor provenance differs from request")
    if type(result.ending_holdings) is not tuple or type(result.trades) is not tuple:
        raise InputValidationError("Proposal holdings/trades must be immutable tuples")
    require_money(result.ending_par, "proposal ending_par", positive=True)
    require_money(result.ending_cash, "proposal ending_cash")
    baseline = {h.asset.asset_id: h for h in request.holdings}
    quotes = {q.asset.asset_id: q for q in request.quotes}
    targets: dict[str, Holding] = {}
    for holding in result.ending_holdings:
        if not isinstance(holding, Holding) or holding.asset.asset_id in targets:
            raise InputValidationError("Proposal contains invalid/duplicate ending holdings")
        asset_id = holding.asset.asset_id
        descriptor = baseline[asset_id].asset if asset_id in baseline else quotes.get(asset_id, None)
        if isinstance(descriptor, TradeQuote):
            descriptor = descriptor.asset
        if descriptor != holding.asset:
            raise InputValidationError(f"{asset_id}: ending descriptor is not a request asset")
        targets[asset_id] = holding
    trades: dict[str, ProposedTrade] = {}
    cash = Fraction(request.starting_cash)
    for trade in result.trades:
        if not isinstance(trade, ProposedTrade) or trade.asset_id in trades:
            raise InputValidationError("Proposal contains invalid/duplicate trades")
        quote = quotes.get(trade.asset_id)
        if quote is None or trade.side is not quote.side:
            raise InputValidationError(f"{trade.asset_id}: trade has no matching permitted side quote")
        require_money(trade.par, "proposed trade par", positive=True)
        for label in ("clean_cash", "accrued_cash", "fee_cash"):
            require_money(getattr(trade, label), f"proposed trade {label}")
        require_decimal(trade.cash_change, "proposed trade cash_change")
        if post_currency(Fraction(trade.cash_change)) != trade.cash_change:
            raise InputValidationError("proposed trade cash_change must have cent precision")
        if trade.par > quote.maximum_par or trade.par < quote.minimum_ticket:
            raise InputValidationError(f"{trade.asset_id}: proposed trade quantity is outside quoted availability/ticket")
        if quote.lot_size is not None and (Fraction(trade.par) / Fraction(quote.lot_size)).denominator != 1:
            raise InputValidationError(f"{trade.asset_id}: proposed trade violates lot size")
        clean = post_currency(Fraction(trade.par) * Fraction(quote.clean_price_pct) / 100)
        accrued = post_currency(Fraction(trade.par) * Fraction(quote.accrued_per_par))
        proportional = post_currency(Fraction(trade.par) * Fraction(quote.proportional_fee_per_par))
        fee = post_currency(Fraction(proportional) + Fraction(quote.fixed_fee))
        change = post_currency((Fraction(clean) + Fraction(accrued)) * (
            -1 if quote.side is TradeSide.BUY else 1) - Fraction(fee))
        if (trade.clean_cash, trade.accrued_cash, trade.fee_cash, trade.cash_change) != (clean, accrued, fee, change):
            raise InputValidationError(f"{trade.asset_id}: posted clean/accrued/fee/cash economics do not reconcile")
        trades[trade.asset_id] = trade
        cash += Fraction(change)
    changes: list[HoldingChange] = []
    for asset_id in sorted(baseline.keys() | targets.keys() | trades.keys()):
        before = baseline[asset_id].par if asset_id in baseline else Decimal(0)
        after = targets[asset_id].par if asset_id in targets else Decimal(0)
        trade = trades.get(asset_id)
        signed = Fraction(0) if trade is None else Fraction(trade.par) * (1 if trade.side is TradeSide.BUY else -1)
        if Fraction(after) - Fraction(before) != signed:
            raise InputValidationError(f"{asset_id}: target minus baseline par differs from proposed signed trade")
        asset = baseline[asset_id].asset if asset_id in baseline else targets[asset_id].asset
        changes.append(HoldingChange(asset_id, asset, before, after, post_currency(signed)))
    ending_par = post_currency(sum((Fraction(h.par) for h in targets.values()), Fraction(0)))
    ending_cash = post_currency(cash)
    if ending_par != result.ending_par or ending_par != request.limits.target_par:
        raise InputValidationError("Proposal ending par does not reconcile to target par")
    if ending_cash != result.ending_cash or ending_cash < request.limits.minimum_cash:
        raise InputValidationError("Proposal ending cash does not reconcile to posted ledger/minimum cash")
    verified = verify_static_amounts(request, tuple(
        # Rebuild all permitted quote quantities, including inactive zero rows,
        # to apply every risk mandate at this independent trust boundary.
        trades[quote.asset.asset_id].par if quote.asset.asset_id in trades else Decimal(0)
        for quote in request.quotes
    ))
    if verified.violations:
        raise InputValidationError("Proposal breaches static mandate: " + "; ".join(verified.violations))
    if (result.overall_factor, result.bsl_factor, result.spread_bps) != (
        verified.overall_factor, verified.bsl_factor, verified.spread_bps
    ):
        raise InputValidationError("Proposal reported factor/spread diagnostics do not reconcile to target holdings")
    return TargetPoolPlan(request.settlement_date, request.factor_provenance, request.starting_cash,
                          ending_cash, ending_par, tuple(targets[key] for key in sorted(targets)),
                          tuple(trades[key] for key in sorted(trades)), tuple(changes))
