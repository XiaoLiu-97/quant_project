# CLO waterfall、IC/OC、cure、IDT与生命周期

更新：2026-10-08。当前为explicit generic payment-day profile；不是任意交易indenture自动配置。旧位置保留用于input mapping，旧VBA/旧test预期不是正确性oracle。Capital Stack每debt class显式interest_deferrable，Advanced新增政策与旧107inputs分别登记。

支持[原付款日分配后开账](existing_clo_opening.md)。原closing和liability schedule不改，opening face、coupon-origin claims、fee arrears及各账户分别输入；pending释放是账户转移，不是新增receipt。原first-stub override不会再用于resumed regular period。OC分母为零但仍有有效未付coupon claim时，IC按其自身live debt-service判断，不能因OC排除该claim而默许NOT_APPLICABLE。所有结果继续按每class、每原period、每coverage stage输出。

## 当前执行公式与单位

所有金额为EUR cent，rate/valuation/price为decimal fractions，OC/IC阈值为multiples。例如125%=1.25、price99%=.99。Fee bps有独立换算；现金、债务par、default claims、unpaid coupon及valuation不互相替代。

设 `N` 为adjusted collateral＋纳入的全部actual principal cash，`D` 为tested class及其senior notes的actual remaining face par，加上默认资本化profile下实际剩余的deferrable coupon claims，`k`为OC threshold：

- **Interest-funded OC repayment**：interest转为debt redemption时N不变，最少还本 `max(0,D−N/k)`，**向上**取可执行cent，不能HALF_UP低于cure金额。
- **Principal-funded OC repayment**：cash和debt同时减少；对k>1，连续理论解为 `max(0,(kD−N)/(k−1))`。这不是interest cure。当前normal principal cash先按权限支付claims，再在失败状态下sequential分配并记录end状态；没有把interest公式用于principal资金。
- **Principal-numerator IDT transfer**：interest转principal cash时D不变，最少转 `max(0,kD−N)`；required cure向上取cent，residual比例cap向下取cent，以较小者为实际transfer。
- **IC**：realized eligible interest＋opening available interest＋bank cash earnings＋实际授权reserve draw−当期senior expense/fee claims；denominator包括tested stack的current coupon、interest on opening arrears及应包含的cash-pay arrears。Deferrable opening principal是否包括由typed policy控制。

例如OC N100、D80、k1.5：13.33的interest repayment后，66.67×1.5=100.005，仍fail；实际需要13.34。IDT N100、D100、k1.1，则transfer10增加N到110；不能用9.09的debt-repayment解替代。

Asset-level CCC例：A20、clean acquisition95%、current mark50%；B20、clean60%、mark90%；C60正常，CCC limit10%。CCC excess30选A20＋B10，以current marks计值，haircut11、adjusted89。Acquisition排序会选错。重叠例：A50为CCC/Discount/long-dated，clean60%、mark50%、long value70%，limit10%；A的excess40按50%计值，余10按60%，B正常50，合计76；不会把三项haircut简单相加。

## Synthetic purchase 的前后状态检查

Synthetic acquisition 分为**只读计划、prospective coverage、提交**三步。`plan_purchase` 先以实际可支配资金和明确price计算cent面值、posted consideration、unused cash及contractual maturity；不创建cohort，不消耗现金或designation。取得一个计划不代表已买入，也不增加本期利息。

`STOP_ON_TEST_FAILURE` 先要求当日 `PURCHASE_GATE` 的所有适用OC/IC通过、没有remaining unpaid coupon，再核验拟购买后的 `POST_PURCHASE_GATE`。Prospective状态同时包括取得的新performing face、相应top-down/long-dated valuation，以及扣除actual consideration后的principal cash；pending principal仍按原OC policy处理。Defaulted claims、原始collateral inventory、债务face与deferred claims不因计划而变化。新cohort当天没有已赚取coupon，当前IC numerator/denominator不能加入未来收入来通过测试。

只有通过允许的计划才由 `commit_purchase` 创建cohort并支出一次cash。随后立即更新collateral valuation；`PRINCIPAL_GATE` 使用这个新状态来判断ordinary PRO_RATA还是coverage-driven sequential，不等到 `PERIOD_END` 才刷新。已实际exercise的call / maturity disposition也先更新为处置后的inventory再进入本金gate；未exercise的call保留原资产。PURCHASE_GATE、POST_PURCHASE_GATE及PRINCIPAL_GATE是内部决策节点，不是Excel新增可选report stage；既有GATE、POST_DIVERSION和PERIOD_END输出继续保留。

被coverage否决的计划不改变cohort编号、ledger、现金或designation。普通unspent principal按正常本金priority使用；仍在授权窗口内的held IDT保留earmark，窗口结束或call/final时按既有规则释放。拒绝购买本身不创造额外现金，也不强制解锁所有IDT。

`ALWAYS_REINVEST` 仍是明确的sensitivity override：绕过本generic profile的coverage/unpaid-coupon acquisition veto，不表示通过了交易条款。它不能绕过启用/日期/final/call条件、可支配资金/不超支、禁止long-dated collateral或asset-level synthetic classification guard。两种模式提交后均使用实时更新的collateral valuation处理剩余本金。Coverage tests全局关闭时，新检查保留该显式sensitivity，不私自重新开启测试。

Cent与边界使用同一purchase plan：face按cash/price向下至cent，consideration按规定posting，unused cash保留；maturity按独立WAL月数确定，long-dated haircut按该真实日期纳入prospective valuation。Asset-level OC缺少新cohort的分类/mark transport时仍明确拒绝，不默认non-CCC或par credit。该修复只实现本模型已有generic OC/IC；不声称完整执行真实deal的§12.2质量测试、maintained/improved条款或未来交易许可。

独立手算例说明为什么必须核验中间节点：

- 原资产100收到本金10后，collateral90＋cash10、debt80、OC minimum1.25，买前通过。Price1.01拟用10cash买9.90par，买后N99.90、OC1.24875x，STOP应不提交；普通cash继续按本金priority分配。
- Supported Existing opening的collateral100＋cash20，其中original reinvestment permission10；A/B debt50/40、minimum1.30、PRO_RATA、price1、recycle=False。买10par后N=110collateral＋10cash=120，仍通过，余下10本金应还A5.56/B4.44。读取旧collateral100会错误测得N110而变成sequential。现金守恒或最终OC通过都不能替代这个节点的已知答案。

## 独立IDT的可配置范围

`CloTerms.interest_diversion_test_*`包含enabled、tested class、OC minimum、max residual fraction、end date；enabled要求全部有效且tested class存在。默认Off；没有把测试设计值当成production deal条款。可配置50%等cap，实际stage为post-subordinated-fee、pre-incentive。

IDT转入本金的现金作为principal cash的**earmarked subbalance**显示，已经包含在总principal account中，不能再加一次。允许的synthetic purchase可使用它，包括关闭synthetic-cohort recycling的情况；没有可授权purchase时保留actual cash。窗口结束释放到ordinary principal distribution，call/final也释放。Transfer并不是cash receipt、income、par purchase或投资者出资。

该实现是明确的generic routing选择，不自动模拟某交易的early effective date、50%条款、manager“不适合reinvestment”的判断、special redemption election、consent或其他legal condition。IDT status记录**transfer前**测量，period-end coverage记录实际transfer/purchase/paydown后的状态。

```mermaid
flowchart TD
    A[Actual receipts and cash pending cutoff] --> B[Fee claims and authorized reserve draws]
    B --> C[Current note coupons and explicit arrears]
    C --> D[Rated-class OC and IC gates]
    D --> E[Senior coverage paydown or capped OC cure]
    E --> F[Junior fees when allowed]
    F --> G[Independent junior IDT: actual interest to earmarked principal]
    G --> H[Call/final: protect debt claims before equity]
    H --> I[Principal coupon permissions and controlling-class sequence]
    I --> J[Retest after principal-paid claims]
    J --> K[Read-only acquisition plan and prospective OC/IC]
    K --> K2{STOP passes or explicit ALWAYS sensitivity}
    K2 -->|Purchase permitted| K3[Commit once and refresh collateral valuation]
    K2 -->|Veto| K4[Unspent cash unchanged; retain active IDT earmark]
    K3 --> L[Retest current principal gate; sequential cure or normal principal policy]
    K4 --> L
    L --> M[Actual equity funding hurdle and distributions]
    M --> N[Cash/par/coupon conservation and class-period reports]
```

## 原始reference与适用边界

[OCP Euro CLO 2017-1 January 2026 Offering Circular](https://ise-prodnr-eu-west-1-data-integration.s3-eu-west-1.amazonaws.com/202601/07d64e17-e59d-4980-b089-0096b0ee4bc1.pdf)：printed pp130–131包括principal-account余额及重叠最低adjusted value，p137包含CCC选择，pp138–140说明IC债务服务中的deferred principal与interest on it，pp165–167定义incentive/IC金额，pp201–206分别列coverage cure、IDT和controlling-class principal权限。它提供真实条款的交叉核验，generic模型并不采用其全部deal条款。

[Carlyle Direct Lending CLO 2024-1 Indenture](https://www.sec.gov/Archives/edgar/data/1702510/000170251024000079/indenture-clo2024x1.htm)：§1.1的IC定义排除Deferred Interest本金但包括其interest；§11.1分别列coverage及junior IDT，principal payments有controlling-class权限；§9.2/9.4要求完整redemption资金和具体条件。这是美国direct-lending交易，不能将其exact priorities/thresholds当作EUR BSL通用条款。

当前仍是显式generic cashflow-policy engine，**不是任意真实CLO indenture已经自动配置完成**。主要边界：

- unique class priorities，不支持同seniority多个pari passu classes的契约分组；应给每个实际deal提供validated profile，而不是把A–E字母当法律定义。
- IC是realized-cash projection口径；不完整覆盖determination-date expected receivables、hedges、smoothing或税。显式[principal-funded coupon proceeds](coupon_proceeds.md)可将native首笔正coupon中的已核实accrued余额恢复为principal，IC只使用分类后的eligible interest；raw coupon和asset face不变。未配置classification时仍按普通native coupon进入interest，不能由purchase cost或settlement账户推断法律归属。Current accrued coupon不会在redemption后静默变小；没有把future interest节省伪装成已经cure的current IC。
- Top-down CCC/Discount/default/long-dated valuations保留explicit underwriting sensitivities；actual asset-level current marks与分类才可核验真实集合。Defaulted OC value不是sale/recovery cash。CCC-limit denominator当前按performing pool定义，actual deal若以更广collateral principal amount计限，须配置相应profile。
- Incentive保留已文档化的paid-capital marginal hurdle经济机制；真实交易可能在IRR threshold达成后按全部residual计费、使用contractual initial capital或catch-up tiers，不可未经条款映射就当成同一机制。
- Refinancing是原debt par/priority/maturity不变的margin amendment＋actual equity-funded fee；并非完整new-issue financing。Call日期按payment day处理，不推断notice、noncall、consent或任意日settlement。
- Contractual reserve、expense priority cap与manager deferral选择只覆盖已经explicit实现的权限。没有可用的最新完整agency calibration即不能自称S&P/Moody's认证。

## 已实现资本化 profile：Deferred Interest 与 OC denominator

`CloTerms.include_deferred_interest_in_oc=True` 为显式默认值：OC和独立IDT的 `D` 包含tested stack的face par＋实际未付deferrable coupon claims。False为非资本化敏感性；不能默认为已核实的真实合同。Nondeferrable cash-pay arrears不计入该本金base。此OC政策独立于默认False的 `include_deferred_interest_in_ic`，后者决定IC是否包含opening deferred principal，不改变本期coupon及interest on arrears。

[OCP EUR 2026 offering circular](https://ise-prodnr-eu-west-1-data-integration.s3-eu-west-1.amazonaws.com/202601/07d64e17-e59d-4980-b089-0096b0ee4bc1.pdf) 的 printed p178 定义 Principal Amount Outstanding 包含 C/D/E/F 已资本化 Deferred Interest；pp138–139 的 OC/par-value denominator 使用该定义，voting/quorum 例外不能移用到 OC。[Carlyle 2024-1 indenture](https://www.sec.gov/Archives/edgar/data/1702510/000170251024000079/indenture-clo2024x1.htm) §1.1 printed p8 的 Aggregate Outstanding Amount 同样包含尚未支付的已资本化 Deferred Interest，p57 的 OC 使用该金额；§2.7 规定资本化。两份文件均不能作为“par-only 是通用市场约定”的依据。

独立动态反例：N100、face90、本期实际未付deferrable coupon10、k1.10。False为100/90＝1.1111x PASS；默认True为100/100＝1.0000x FAIL，interest-funded理论cure为ceil-cent(100−100/1.1)＝9.10。独立IDT shortfall为1.1×100−100＝10；没有residual interest时实际transfer仍为0，不制造现金。Face为0但剩余deferred claims10时D仍为10，不能NO_DEBT；同样10的cash-pay arrears不作为资本化本金。

时点为明确generic payment-day profile：本期coupon、opening arrears及适用interest-on-arrears应计后，实际支付逐项扣减。每类GATE在其interest coupon node后测量；coverage paydown/retest、IDT、purchase/principal gate及period-end读取同一实际未付claims列表。Full-stack retest还包含被senior gate阻挡、没有得到支付的junior当期应计，本profile将其在同日资本化；**不声称复制所有交易法律上的capitalization date**。不能使用仍描述opening state的私有arrears值替代实际余额。

例如从principal20支付B的capitalized claim10、再赎回A face10：N100→80、D100→80、face90→80、arrears10→0。Coupon payment减少现金及资本化coverage claims一次，face redemption再减少face一次，不重复赎本。若从interest支付claims，N中的principal cash不变，D按实际claims清偿下降。

Reporting中的tranche `opening_balance`/`closing_balance`及deal `debt_par`始终是**face principal**，`closing_coupon_arrears`另列未付coupon，付款列仍分类为coupon payment。因此face balance不直接等于合同的Aggregate Outstanding Amount；开启资本化profile时需加上该class的remaining deferrable claims，再按tested seniority聚合到 `oc_denominator`。现金、face与coupon claims分别守恒，不通过虚构face增长实现资本化。真实交易仍需核对current/arrears支付顺序、capitalization日期及contractual IC定义；generic claims支付政策不是完整indenture配置。

资本化coverage政策不自动决定deferred claims的interest-on-interest。上述公开文件分别在OCP Condition6(c)及Carlyle§2.7要求相关coupon-rate accrual；实际deal应将独立 `shortfall_accrual_method` 等条款配套核实。True的OC资本化政策配合 `NONE` 仍只是非复利敏感性，不能声称完整复现这两份文件；应计与支付金额由显式shortfall policy决定，不由OC开关制造。

当前 `COUPON_RATE` 分别将face coupon和interest-on-arrears posting到cent。若真实合同以aggregate outstanding统一posting，边界cent可能不同：face1、deferred1、年率2%、90天ACT/360，两项各0.005分别HALF_UP合计0.02，而aggregate2一次posting为0.01。Carlyle§2.7的aggregate-outstanding accrual应在deal profile中配套实现其posting口径，不能仅开启OC资本化即称金额完全一致；本次OC分母使用实际已posting claims，不重复补计假设性的rounded coupon。

## Legacy输入在当前政策中的执行


| 旧来源 | Python / 经济口径 |
| --- | --- |
| B39–41 Incentive Fee / Rate / Hurdle | `incentive_fee_enabled/rate/hurdle_rate`；开立 actual-equity-funding hurdle account，实际日期 ACT/365 年有效复利；总 residual 上超过 accrued hurdle 的部分乘 fee rate，先扣 interest、再 principal、最后 reserve residual。实际出资由 funding service 注入，不用 equity nominal。 |
| B66–68 CCC % / Limit / Valuation | `AdjustedCollateralValuePolicy`；top-down 超限 CCC par ×(1−valuation)。asset-level 按明确 CCC flag，超限部分从最低current market mark资产选取；不默认把 rating 字符串当成已验证 agency recovery。 |
| B69 Maturity Liquidation % | `maturity_liquidation_price`：法定最后一期，剩余 performing par 按显式 fraction 出售；现金进入 principal waterfall，出售面值独立退出 ledger。`None`选择不假设清算的政策，0 表示确实清算为零，而非关闭。 |
| B84 Use Asset-Level Test Data | `use_asset_level_test_data`：True 必须有每个资产的完整 `OcAssetData`；False 明确选 top-down proxy。资产分析仍使用 actual holdings；此开关只控制 OC valuation 的输入来源。 |
| B85–87 Discount % / Valuation / Defaulted Valuation | top-down discounted share 和 valuation；未清偿 default claim 按明确 valuation 计 OC credit。default credit 不是 physical receipt，不恢复 performing par。 |
| B88 Include Principal Cash in OC | 既有开关继续使用；包含全部实际收到的principal cash，包括pending；支付权限仍受cutoff限制。 |
| B89–90 Interest Shortfall Carry / Accrual Method | carry enabled：未付 coupon 独立债权；NONE 不生息，COUPON_RATE 按 opening arrears ×本期 note all-in rate×note DCF 入账，再与本期 coupon 一起付款。carry disabled：剩余债权记 `waived_coupon_shortfall`，没有对应现金。 |
| B98–100 Allow / Limit / Long-Dated OC Valuation | forbid 时拒绝最后本金日期晚于 legal final 的输入或 synthetic purchase；long-dated par 用每资产实际 remaining par，不把已 default/prepaid 资产静态缩放回来。OC 按 valuation haircut；limit 在 portfolio analysis 中独立显示。 |
| B117–120 Optional Call | 在 requested date 起第一个 actual payment date 尝试一次完整处置；足够 discharge 所有债务/费用/arrears 才 exercise。call costs 基于本期 ordinary principal 付款后剩余 debt par。不足时 `INSUFFICIENT_PROCEEDS` 并保留资产，继续 hold 投影；没有新用户 election 时不在以后付款日自动重试。 |
| B121–124 Refinancing | 在首个 actual payment date ≥ requested date、正常还本后，以当期ordinary还本后remaining face debt par×fee fraction 记 dated equity contribution 和费用；从下一期起 floating spread 降为 max(0,old spread−reduction)。完整重跑 coupon、IC/OC、diversion、equity，替代旧 VBA 的 estimated savings。 |
| B134 Discount Price Threshold | asset-level 分类 explicit flag OR clean acquisition price <threshold；采用 acquisition price（capped at par）估值。top-down proxy 使用 B85/86，threshold 是 inactive asset-level 参数，不悄悄改变 top-down share。 |

新增 `defaulted_collateral_sale_price` 是现金处置假设，默认0；它与 B87 **OC valuation** 分开。不能用一个 OC 百分比凭空增加 call 或 maturity 的现金。处置未解决 default rights 后，不再收这些债权的未来 recovery。

## Lifecycle、费用与equity现金

Call在requested date起首个actual payment date尝试一次，足额discharge debt/coupon/fees才exercise；拒绝继续hold，不自动在下期重试。Refi是same par/seniority/maturity的margin amendment，normal principal后按remaining face debt收fee，实际equity追加资金支付，next period起spread=max(0,old−reduction)。Call/refi通用fee base不含capitalized coupon；真实Aggregate Outstanding Amount基数需独立profile。

Maturity liquidation用显式fraction出售剩余performing par，0是出售零值而非关闭；None不造terminal sale。Default OC valuation不是cash sale price，出售claim必须取消future recovery。金额不足时保留unsettled debt/claims和terminal unavailable，不能直接把gross sale加进IRR。

Incentive用actual paid capital的effective ACT/365 hurdle及超过accrued hurdle的residual，按fee rate付款；不是所有合同IRR-trigger/all-residual/catch-up tiers。Equity输出保留dated contribution、net investor cashflow和gross cumulative funding：closing40、distribution4.32、refi追加.60时netflow3.72、funding40.60。Carry关闭是waiver sensitivity，不等同合法免付。

Top-down CCC/discount/default/longdated是有界additive proxy，没有joint classifications；asset-level取每par slice最低认可值一次。Asset-level OC与synthetic新cohort/new BUY缺classification transport时明确拒绝，不能自动设置nonCCC/nonDiscount或给par credit。真实quoted marks在当前projection冻结，不自动更新未来价格。

Recurring expense输入为EUR p.a.，按显式expense DCF折算，priority cap未支付部分仍留claim，不把cap当作expense减免。初始closing费用与annual费用分开，额外明细不重复Controls组件。Cash/par/claims及追加funding各自守恒。


## 输出与独立核验

CLO Waterfall按每class×每actual emitted period输出，含equity；notes face/coupon/现金来源分列，equity只显示实际funding/distribution。GATE、POST_DIVERSION、PERIOD_END不得互相替代；blocked junior未执行gate保留空值。逐class cash/coupon/face桥及deal conservation有独立小账回归；关键反例和最新完整验收见 [审查记录](../readiness.md)。
