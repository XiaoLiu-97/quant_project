# Regional business calendars and date adjustment

Reviewed: 2026-10-06. Implementation: `src/trident/conventions/calendar.py`. Independent tests: `tests/test_regional_calendars.py` and the official Japanese holiday fixture in `tests/fixtures/tokyo_national_holidays.json`. The calculation has no additional package dependency or online runtime requirement.

## Choose the contractual business centre

A city name alone does not identify every market's operating days. A bank, stock exchange, government office and payment system in the same city can close on different dates. Project Trident therefore assigns one documented financial profile to each calendar input. Confirm that profile against the actual loan or note documentation before selecting it.

| Canonical value | Accepted display label | Financial profile | Supported date range |
| --- | --- | --- | --- |
| `TARGET` | TARGET | Modern euro TARGET recurring closures | 1900–2199 |
| `WEEKENDS_ONLY` | Weekends Only | Monday–Friday with no inferred public holidays | Python date range |
| `LONDON` | London | England and Wales bank holidays | 2000–2099 |
| `NEW_YORK` | New York | Federal Reserve standard settlement-day observance | 2000–2099 |
| `TOKYO` | Tokyo | Japanese national holidays plus Bank of Japan bank closures | 2000–2099 |
| `SYDNEY` | Sydney | NSW public and banking holidays, including the August bank holiday | 2000–2099 |
| `TORONTO` | Toronto | Canadian banking/bond-market closures, including Ontario Family Day and Civic Holiday | 2000–2099 |
| `ZURICH` | Zurich | CHF currency settlement holidays | 2000–2099 |

Canonical values are stored as uppercase identifiers. Historical display labels, with spaces where applicable, resolve to those identifiers; `WeekendsOnly` is also accepted for the weekends-only profile. Unknown names are rejected; there is no fallback to TARGET or weekends only. Regional dates outside the stated range are rejected even under `UNADJUSTED`, rather than silently applying modern laws to earlier history.

The Toronto profile includes Ontario financial-office closures in addition to national Canadian clearing holidays. It is deliberately more restrictive than the Payments Canada system calendar alone. The Sydney profile includes the NSW bank holiday; it is not a claim that every Australian payment system or exempt retail branch closes that day. These choices are explicit model assumptions.

## Adjustment, lag and accrual are separate operations

The contractual roll generates **unadjusted** period boundaries first. A business-day convention adjusts the relevant date without changing the underlying schedule anchor. A payment lag then counts open days from the adjusted payment date, excluding that date. A fixing lag counts backwards from its independently selected anchor. A determination lag similarly uses its selected determination calendar. Calendar selection does not change day-count conventions or automatically select adjusted accrual dates.

| Convention | Rule |
| --- | --- |
| `UNADJUSTED` | Keep the supplied date; still validate the profile's supported range |
| `FOLLOWING` | First open day on or after the date |
| `MODIFIED_FOLLOWING` | Following, unless it crosses the calendar month; then use preceding |
| `PRECEDING` | First open day on or before the date |
| `MODIFIED_PRECEDING` | Preceding, unless it crosses the calendar month; then use following |

For a nonbusiness start, a lag does not first normalize that start. Saturday minus one business day is Friday, not Thursday. Zero lag keeps the date unchanged. Positive and negative lags use the same selected holiday profile. Range crossings raise an explicit error.

Example: Saturday **2026-08-29** with Following and one payment business day of lag pays on **2026-09-02** under London: Monday 31 August is a bank holiday, adjustment gives Tuesday 1 September, and lag gives Wednesday 2 September. Under New York, adjustment gives Monday 31 August and lag gives Tuesday 1 September. Modified Following under London instead gives Friday 28 August because the forward adjustment crossed the month. These dates are covered by independent tests.

[FpML business-day conventions](https://www.fpml.org/spec/2002/wd-fpml-3-0-2002-04-17/html/schemeDefinitions.html) support these adjustment definitions. Contractual payment and fixing rules remain authoritative where they specify a different sequence or joint-business-centre requirement.

## Profile rules and primary references

### London

Recurring closures are New Year, Good Friday, Easter Monday, early May, spring and summer bank holidays, Christmas and Boxing Day. Weekend New Year moves to Monday. Christmas and Boxing Day receive **distinct** substitutes, so Christmas on Sunday and Boxing Day on Monday also close Tuesday. Known replacements and additional days are included for the 2002/2012/2022 jubilees, 2011 royal wedding, 2020 VE Day move, 2022 state funeral and 2023 coronation. A moved May bank holiday is removed from its original date.

Sources: [GOV.UK bank holidays](https://www.gov.uk/bank-holidays), [2002 proclamation](https://www.thegazette.co.uk/notice/L-56043-1001), [2012 Jubilee impact assessment](https://assets.publishing.service.gov.uk/government/uploads/system/uploads/attachment_data/file/77574/2011-diamond-jubilee-bank-holiday-impact-assessment.pdf), [2011 wedding announcement](https://www.gov.uk/government/news/pm-welcomes-announcement-of-date-for-royal-wedding), [2020 VE Day replacement](https://www.gov.uk/government/news/2020-may-bank-holiday-will-be-moved-to-mark-75th-anniversary-of-ve-day), [2022 Jubilee announcement](https://www.gov.uk/government/news/extra-bank-holiday-to-mark-the-queens-platinum-jubilee-in-2022), [2022 funeral bank holiday](https://www.gov.uk/government/news/bank-holiday-announced-for-her-majesty-queen-elizabeth-iis-state-funeral-on-monday-19-september), and [2023 coronation bank holiday](https://www.lancaster.gov.uk/the-council-and-democracy/civic-and-ceremonial/coronation-of-king-charles-iii).

### New York

The profile includes New Year, Martin Luther King Jr. Day, Washington's Birthday, Memorial Day, Juneteenth from 2021, Independence Day, Labour Day, Columbus Day, Veterans Day, Thanksgiving and Christmas. A Sunday holiday closes Monday; a Saturday holiday **does not close the preceding Friday**. Good Friday is open for this profile. NYSE trading closures, SIFMA recommendations and federal-employee leave are separate conventions.

The distinction matters numerically: **2026-07-03**, **2021-06-18**, **2021-12-24** and **2021-12-31** remain open settlement days. Sources: [New York Fed holiday schedule](https://www.newyorkfed.org/aboutthefed/holiday_schedule.html), [Federal Reserve Financial Services Saturday observance](https://www.frbservices.org/about/holiday-schedules/2026-stlouis-schedule/), and [Federal Reserve 2021 Juneteenth operational notice](https://www.federalreserve.gov/newsevents/pressreleases/other20210617b.htm).

### Tokyo

The profile includes Japanese national holidays, Sunday substitutes, weekday citizens' holidays between two national holidays, and bank-only **2/3 January and 31 December** closures. Bank-only closures do not themselves create substitutes. National-holiday transitions include Marine Day and Respect for the Aged Day changes in 2003, Greenery Day and the substitution-rule change in 2007, Mountain Day from 2016, the Emperor's Birthday transition, 2019 enthronement and the moved 2020/2021 Olympic holidays. Moved dates are removed from the normal calendar.

All **10,227 calendar days from 2000 through 2027** have been compared with the Cabinet Office national-holiday CSV plus the BOJ bank-only closure rule, with no mismatches. The test fixture contains 486 published national-holiday dates and source SHA-256 `cec37a743c96995cdb9cb52b685c9003634682a9b0e1a640a6b9b96881fe964a`.

Sources: [Bank of Japan holiday schedule](https://www.boj.or.jp/en/about/outline/holi.htm), [Cabinet Office holiday law, published dates and Olympic moves](https://www8.cao.go.jp/chosei/shukujitsu/gaiyou.html), [Cabinet Office official CSV](https://www8.cao.go.jp/chosei/shukujitsu/syukujitsu.csv), [2019 enthronement and birthday changes](https://www8.cao.go.jp/chosei/shukujitsu/about/gaiyou/20190405gaiyouchirashi.pdf), and [NAOJ calendar and ephemeris](https://eco.mtk.nao.ac.jp/koyomi/cande/index.html.en).

### Sydney

The NSW profile includes New Year, Australia Day, Good Friday, Easter Monday, Anzac Day, the June King's Birthday holiday, the first Monday in August bank holiday, October Labour Day, Christmas and Boxing Day. Weekend New Year/Australia Day use Monday observance; Christmas/Boxing Day substitutes cannot collide. Normally Anzac Day has no weekend substitute. Additional closures on **2026-04-27 and 2027-04-26** are explicitly included from the NSW announcement; a permanent rule after those years is not inferred. The 2011 Easter Monday/Anzac collision closes 26 April as well, and 22 September 2022 is included for the national day of mourning.

Sources: [NSW published public/bank holidays](https://www.nsw.gov.au/about-nsw/public-holidays), [NSW 2026/2027 Anzac additional-holiday announcement](https://www.nsw.gov.au/ministerial-releases/minns-labor-government-announces-extra-public-holiday-year), [Public Holidays Act 2010, including 2011 transition](https://legislation.nsw.gov.au/view/whole/pdf/inforce/2022-09-13/act-2010-115), and [2022 national mourning closure](https://dcj.nsw.gov.au/content/dcj/ctsd/irc/irc/announcements/arrangements-for-national-day-of-mourning.html).

### Toronto

The profile includes New Year, Good Friday, Victoria Day, Canada Day, Civic Holiday, Labour Day, Thanksgiving, Remembrance Day, Christmas and Boxing Day. Family Day starts in 2008; National Day for Truth and Reconciliation starts in 2021. Weekend fixed holidays move to the following Monday, with distinct Christmas/Boxing Day substitutes. Easter Monday remains open. The Canadian day of mourning on 19 September 2022 is not inferred to close financial settlement.

Sources: [Canadian Forum for Financial Markets 2026 bond/money-market closure schedule](https://cffim-fcmfi.ca/wp-content/uploads/2025/11/2026-Schedule-of-Recommended-Domestic-Bond-and-Money-Market-Closures.pdf), [Payments Canada system closures](https://www.payments.ca/system-closure-schedule), [Ontario introduction of Family Day](https://news.ontario.ca/mnr/en/2014/02/theres-no-place-like-ontario-for-family-day.html), [Bank of Canada Family Day](https://www.bankofcanada.ca/2026/02/family-day/), and [Bank of Canada Civic Holiday](https://www.bankofcanada.ca/2026/08/civic-holiday/).

### Zurich

The CHF currency profile includes New Year, Berchtold's Day, Good Friday, Easter Monday, Labour Day, Ascension, Whit Monday, Swiss National Day, Christmas and St Stephen's Day. Weekend dates create no Monday substitute. **24 December and 31 December remain open currency-settlement dates** even when the Swiss stock exchange has no trading. Local half-day events and office-specific bridge closures are excluded.

Source: [SIX CHF/EUR Currency Holiday Calendar 2026](https://www.six-group.com/dam/download/securities-services/digital-assets/post-trade/2026-chf-and-eur-currency-calendar.pdf). This currency calendar, rather than the stock-exchange trading calendar, is the reference for this profile.

### TARGET

Recurring closures are 1 January, Good Friday, Easter Monday, 1 May, 25 December and 26 December. Weekends create no substitute holiday. The broad supported range projects modern euro rules and does not claim to reconstruct historical TARGET system operations.

Sources: [ECB TARGET Information Guide, section 2.6](https://www.ecb.europa.eu/paym/target/consolidation/profuse/shared/pdf/2025.APR_p1_fundamentals.en.pdf) and [ECB working-hours calendar](https://www.ecb.europa.eu/ecb/contacts/working-hours/html/index.en.html).

## Explicit assumptions and maintenance

1. **Future recurring holidays use current legal rules.** New proclamations, emergency closures and legal changes require an update or explicit caller-supplied closure. A supported year is a calculation horizon, not an official publication horizon.
2. **Japanese equinox dates after the published 2027 schedule are projected.** The bounded standard equinox approximation is calculated with integer microdays to avoid floating-point threshold errors. The Cabinet Office confirms that legal equinox dates are gazetted by NAOJ annually. Future projections must be reconciled when each official calendar is published. Published 2000–2027 dates are independently verified.
3. **Only full-day openness is modelled.** Early closing hours, intraday settlement cutoffs, daylight saving and emergency-service uptime are outside a date-only contract calendar. Half-day trading closures do not remove a business day.
4. **A single selected profile is used per date role.** A contract requiring simultaneous London and TARGET business days needs an explicitly supplied joint-calendar implementation of `BusinessCalendar`. It must not be represented by choosing either city alone.
5. **Additional closures are Python API overrides.** They are supplied as immutable `frozenset[date]` values; a separate Excel exceptional-holiday table is not introduced by this change. Standard holidays cannot be reopened through the override.

Example API usage:

```python
from datetime import date
from trident.conventions.calendar import calendar_from_name

london = calendar_from_name("LONDON")
contract_calendar = calendar_from_name(
    "LONDON", extra_holidays=frozenset({date(2028, 6, 9)})
)
```

The factory returns an immutable `TargetCalendar`, `WeekendCalendar` or `RegionalCalendar`. Small yearly holiday sets use bounded shared caching. Custom closures stay on the individual calendar instance and never contaminate another loan's cached standard rules. Recurring dates are computed directly from weekday/date arithmetic, avoiding a daily scan in production holiday generation. Business-day lags necessarily count open days and use the common interface, so schedule building, fixing and determination calculations share the same verified behavior.

The focused regression suite checks exact 2026 weekday closure sets for all six profiles, the complete official Tokyo 2000–2027 range, known historical exceptions, false exchange/employee closures, holiday introduction dates, substitute collisions, all five business-day conventions, both lag directions, payment adjustment followed by lag, invalid inputs, range edges and isolation of custom closures. Existing TARGET/day-count/schedule regressions must continue to pass when the complete test suite is run.
