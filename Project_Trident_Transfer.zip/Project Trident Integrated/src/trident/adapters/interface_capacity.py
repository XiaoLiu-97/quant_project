"""Preallocate named input grids without manufacturing business records.

Capacity is a presentation concern: blank reserved rows carry native styles
and validations, while the input reader continues to consume only populated
owning fields. The operations below are deliberately narrower than an output
write: they may extend a declared input rectangle, but never replace existing
input values, formulas, header metadata or native Table identity.
"""
from __future__ import annotations

from dataclasses import dataclass
from copy import deepcopy
from typing import Mapping
import xml.etree.ElementTree as ET

from trident.domain.models import InputValidationError
from .interface_package import (
    FormulaCell, TableInfo, WorkbookPackage, TABLE_PREFIX, UI_PREFIX,
    _column, _coordinate, _overlap, _reference, _sheet_reference, _tag, _bounds,
)


@dataclass(frozen=True)
class InputCapacityPolicy:
    """Initial usable rows, never hard limits on assets or contractual events.

    Ratings and schedules are one-to-many records. Giving them their own row
    budgets avoids conflating 300 assets with 300 repayments or agency views.
    Already larger user grids are retained; collision checks govern growth.
    """
    asset_rows: int = 300
    rating_rows: int = 900
    principal_schedule_rows: int = 3000
    asset_event_rows: int = 3000
    tranche_rows: int = 12
    limit_rows: int = 100
    scenario_edit_rows: int = 300
    factor_mapping_rows: int = 300

    def __post_init__(self) -> None:
        for label, value in vars(self).items():
            if isinstance(value, bool) or not isinstance(value, int) or not 1 <= value <= 1_048_575:
                raise InputValidationError(f"{label}: capacity must be a positive Excel row count")

    @property
    def table_rows(self) -> Mapping[str, int]:
        return {
            "assets": self.asset_rows,
            "asset_terms": self.asset_rows,
            "asset_details": self.asset_rows,
            "pool": self.asset_rows,
            "trade_universe": self.asset_rows,
            "asset_ratings": self.rating_rows,
            "principal_schedule": self.principal_schedule_rows,
            "asset_events": self.asset_event_rows,
            "stack": self.tranche_rows,
            "limits": self.limit_rows,
            "scenario_edits": self.scenario_edit_rows,
            "factor_mapping": self.factor_mapping_rows,
        }


DEFAULT_INPUT_CAPACITY_POLICY = InputCapacityPolicy()
ASSET_OPTIONS_TABLE = TABLE_PREFIX + "asset_id_options"
ASSET_OPTIONS_NAME = UI_PREFIX + "asset_id_options"


def _growth_bounds(info: TableInfo, minimum_rows: int):
    left, top, right, bottom = info.bounds
    required = top + minimum_rows
    if required > 1_048_576:
        raise InputValidationError(f"{info.name}: reserved input capacity exceeds Excel rows")
    return (left, top, right, max(bottom, required))


def _check_growth(package: WorkbookPackage, info: TableInfo, bounds, *,
                  relocating_tables: frozenset[str] = frozenset(),
                  relocating_regions: tuple = ()) -> None:
    """Check only newly owned rows, including otherwise invisible occupants.

    The existing input Table is exempt solely because no cell in its original
    rectangle is rewritten. All other Tables, named input owners, merges and
    populated worksheet cells remain protected, including hidden regions.
    """
    left, _, right, bottom = bounds
    old_bottom = info.bounds[3]
    if bottom == old_bottom:
        return
    if info.sheet == "Market Data":
        raise InputValidationError("Capacity allocation cannot change Market Data")
    table = package._xml(info.part)
    if table.attrib.get("totalsRowCount", "0") != "0" or table.attrib.get("totalsRowShown") in {"1", "true"}:
        raise InputValidationError("Reserved input capacity does not relocate totals-row Tables")
    extension = (left, old_bottom + 1, right, bottom)
    for other in package._table_intersections(info.sheet, extension):
        if other.name != info.name and other.name not in relocating_tables:
            raise InputValidationError(f"Input capacity overlaps native Table: {other.name}")
    for name in package.protected_names:
        sheet, region = package.named_region(name)
        if sheet == info.sheet and _overlap(extension, region):
            raise InputValidationError(f"Input capacity overlaps protected name: {name}")
    tree = package._xml(package._sheet_parts()[info.sheet])
    merged = tree.find(_tag("mergeCells"))
    for merge in merged if merged is not None else ():
        region = _bounds(merge.attrib["ref"])
        relocated = any(sheet == info.sheet and _contains(area, region)
                        for sheet, area in relocating_regions)
        if _overlap(extension, region) and not relocated:
            raise InputValidationError("Input capacity overlaps merged worksheet content")
    for address, cell in package._sheet_cells(tree).items():
        column, row = _coordinate(address)
        if left <= column <= right and old_bottom < row <= bottom:
            relocated = any(sheet == info.sheet and _contains(area, (column, row, column, row))
                            for sheet, area in relocating_regions)
            if not relocated and any(cell.find(_tag(kind)) is not None for kind in ("v", "is", "f")):
                raise InputValidationError(f"Input capacity would overwrite worksheet content: {address}")


def _contains(outer, inner) -> bool:
    a, b, c, d = outer
    e, f, g, h = inner
    return a <= e <= g <= c and b <= f <= h <= d


def _display_moves(package: WorkbookPackage, planned) -> tuple:
    """Free two known display panels without relocating business inputs.

    The compact template puts OC guidance beneath limits and an explanatory
    factor note beneath its coefficient table. Only these identified panels
    may move to the unused right-hand display lane; arbitrary neighbouring
    cells still cause rejection instead of being silently pushed elsewhere.
    """
    inventory = package.table_inventory()
    result = []
    for info, bounds in planned:
        if info.name == TABLE_PREFIX + "limits":
            summary = inventory.get(TABLE_PREFIX + "oc_ownership")
            if summary and summary.sheet == info.sheet and _overlap(bounds, summary.bounds):
                left, top, right, bottom = summary.bounds
                panel = (left, top - 1, max(info.bounds[2], right), bottom + 6)
                destination = (29, 9, 29 + panel[2] - panel[0], 9 + panel[3] - panel[1])
                result.append((info.sheet, panel, destination, summary.name))
        elif info.name == TABLE_PREFIX + "factor_mapping":
            left, _, right, old_bottom = info.bounds
            note = (left, old_bottom + 2, right, old_bottom + 2)
            cells = package._sheet_cells(package._xml(package._sheet_parts()[info.sheet]))
            text = package._cached_value(cells.get(f"{_column(left)}{old_bottom + 2}"))
            if isinstance(text, str) and text.startswith("Blank agency mapping is unavailable.") and _overlap(bounds, note):
                result.append((info.sheet, note, (29, 22, 29 + right - left, 22), None))
    return tuple(result)


def _check_display_move(package: WorkbookPackage, sheet: str, source, destination,
                        table_name: str | None) -> None:
    """Require an empty destination and a purely presentational source."""
    package._guard(sheet, destination, own_table=table_name)
    for info in package._table_intersections(sheet, source):
        if info.name != table_name or not _contains(source, info.bounds):
            raise InputValidationError("Capacity guidance relocation intersects another Table")
    for name in package.protected_names:
        owner_sheet, bounds = package.named_region(name)
        if owner_sheet == sheet and _overlap(source, bounds):
            raise InputValidationError(f"Capacity guidance relocation intersects input owner: {name}")
    tree = package._xml(package._sheet_parts()[sheet])
    merges = tree.find(_tag("mergeCells"))
    for merge in merges if merges is not None else ():
        bounds = _bounds(merge.attrib["ref"])
        if _overlap(destination, bounds) or _overlap(source, bounds) and not _contains(source, bounds):
            raise InputValidationError("Capacity guidance relocation conflicts with a merge")
    for address, cell in package._sheet_cells(tree).items():
        column, row = _coordinate(address)
        if _contains(destination, (column, row, column, row)):
            if any(cell.find(_tag(kind)) is not None for kind in ("v", "is", "f")):
                raise InputValidationError(f"Capacity guidance destination is occupied: {address}")


def _move_display_region(package: WorkbookPackage, sheet: str, source, destination,
                         table_name: str | None) -> None:
    """Retain the native OC summary and all surrounding guidance links/styles."""
    left, top, _, _ = source
    x, y, _, _ = destination
    shift_column, shift_row = x - left, y - top
    part = package._sheet_parts()[sheet]
    tree = package._xml(part)
    original = {}
    for address, cell in package._sheet_cells(tree).items():
        column, row = _coordinate(address)
        if _contains(source, (column, row, column, row)):
            original[address] = deepcopy(cell)
    if table_name:
        info = package.table_inventory()[table_name]
        a, b, _, _ = info.bounds
        package.move_table(table_name, sheet=sheet,
            start_cell=f"{_column(a + shift_column)}{b + shift_row}")
    updates = {}
    for address, cell in original.items():
        column, row = _coordinate(address)
        target = f"{_column(column + shift_column)}{row + shift_row}"
        cell.set("r", target)
        updates[target] = cell
    package._replace_cells(sheet, updates, clear=original)
    def shifted(bounds):
        a, b, c, d = bounds
        return (a + shift_column, b + shift_row, c + shift_column, d + shift_row)
    for container_name, attribute in (("mergeCells", "ref"), ("hyperlinks", "ref")):
        container = tree.find(_tag(container_name))
        for item in container if container is not None else ():
            bounds = _bounds(item.attrib[attribute])
            if _contains(source, bounds):
                moved = shifted(bounds)
                reference = _reference(moved)
                if container_name == "hyperlinks" and moved[0] == moved[2] and moved[1] == moved[3]:
                    reference = reference.split(":", 1)[0]
                item.set(attribute, reference)
    workbook = package._xml("xl/workbook.xml")
    names = workbook.find(_tag("definedNames"))
    for name in names if names is not None else ():
        key = name.attrib["name"]
        if not key.startswith(UI_PREFIX) or "!" not in (name.text or ""):
            continue
        try:
            owner_sheet, bounds = package.named_region(key)
        except InputValidationError:
            continue
        if owner_sheet == sheet and _contains(source, bounds):
            name.text = _sheet_reference(sheet, shifted(bounds))
    package._put_xml("xl/workbook.xml", workbook)
    package._put_xml(part, tree)
    # This is a visible explanatory lane. Source Table cell styles preserve
    # wrapping; give the relocated labels and descriptions readable widths.
    package._set_column_widths(sheet, {x: 26, x + 1: 24, x + 2: 42})


def _extend_table(package: WorkbookPackage, info: TableInfo, bounds) -> None:
    """Extend table metadata and add only genuinely blank styled input cells."""
    left, top, right, old_bottom = info.bounds
    bottom = bounds[3]
    if bottom == old_bottom:
        return
    tree = package._xml(package._sheet_parts()[info.sheet])
    cells = package._sheet_cells(tree)
    # Retain each owning column's existing style, including its input fill,
    # date/number format and protection attributes. Pre-existing blank styles
    # below the Table may express local formatting and are kept verbatim.
    styles = {
        column: cells.get(f"{_column(column)}{top + 1}").attrib.get("s", "0")
        if cells.get(f"{_column(column)}{top + 1}") is not None else "0"
        for column in range(left, right + 1)
    }
    updates = {}
    for row in range(old_bottom + 1, bottom + 1):
        for column in range(left, right + 1):
            address = f"{_column(column)}{row}"
            if address not in cells:
                style = styles[column]
                # Mixed inputs have no universal column unit. A first-row bps
                # edit must not make a future fixed-coupon fraction look like
                # 0.0, nor turn a new WARF threshold into a percent. Only new
                # *blank* capacity cells use General; existing date/numeric
                # inputs and their typed-reading formats remain untouched.
                mixed = ((info.name == TABLE_PREFIX + "scenario_edits"
                          and info.headers[column-left] == "New value")
                         or (info.name == TABLE_PREFIX + "limits"
                             and info.headers[column-left] == "Threshold"))
                if mixed:
                    style = str(package._style(int(style), "General", output=False))
                updates[address] = ET.Element(_tag("c"), r=address, s=style)
    if updates:
        package._replace_cells(info.sheet, updates)
    table = package._xml(info.part)
    table.set("ref", _reference(bounds))
    filtering = table.find(_tag("autoFilter"))
    if filtering is not None:
        filtering.set("ref", _reference(bounds))
    package._put_xml(info.part, table)
    _extend_validations(package, info, bounds)


def _extend_validations(package: WorkbookPackage, info: TableInfo, bounds) -> None:
    """Follow larger reserved grids without replacing Stop checks or prompts."""
    left, top, right, old_bottom = info.bounds
    bottom = bounds[3]
    tree = package._xml(package._sheet_parts()[info.sheet])
    validations = tree.find(_tag("dataValidations"))
    changed = False
    for validation in validations if validations is not None else ():
        references = []
        for reference in validation.attrib.get("sqref", "").split():
            a, b, c, d = _bounds(reference)
            if left <= a <= c <= right and b == top + 1 and old_bottom <= d < bottom:
                reference = _reference((a, b, c, bottom))
                changed = True
            references.append(reference)
        validation.set("sqref", " ".join(references))
    if changed:
        package._put_xml(package._sheet_parts()[info.sheet], tree)


def _extend_aliases(package: WorkbookPackage, info: TableInfo, bounds) -> None:
    """Move full owning aliases and paired witnesses without moving scalars.

    Finite full-body aliases follow the reserved Table. Partial subsections
    retain their original meaning. The saved witness range grows by the same
    number of rows; refresh_input_witnesses then freezes the current raw types
    and values, including true blanks, at the normal publication boundary.
    """
    workbook = package._xml("xl/workbook.xml")
    names = workbook.find(_tag("definedNames"))
    if names is None:
        return
    old_left, old_top, old_right, old_bottom = info.bounds
    new_bottom = bounds[3]
    if new_bottom == old_bottom:
        return
    definitions = {item.attrib["name"]: item for item in names}
    # Collect before changing XML: resolving one structured alias after Table
    # growth returns the new bounds, whereas finite aliases retain old bounds.
    for name, item in definitions.items():
        if not name.startswith(UI_PREFIX) or "!" not in (item.text or ""):
            continue
        try:
            sheet, region = package.named_region(name)
        except InputValidationError:
            continue
        left, top, right, bottom = region
        if name in package.protected_names and left == right and top == bottom:
            continue  # A scalar owner must remain a scalar after reserve growth.
        if sheet != info.sheet or not (old_left <= left <= right <= old_right):
            continue
        partial_coupon_claims = (
            info.name == TABLE_PREFIX + "stack"
            and name.startswith(UI_PREFIX + "fresh_current_opening_debt_coupon_claims_")
            and top == old_top + 1 and bottom <= old_bottom
        )
        if not partial_coupon_claims and (bottom != old_bottom or top not in {old_top, old_top + 1}):
            continue
        if name.startswith(UI_PREFIX + "fresh_saved_"):
            continue
        item.text = _sheet_reference(sheet, (left, top, right, new_bottom))
        if name.startswith(UI_PREFIX + "fresh_current_"):
            saved = definitions.get(name.replace("fresh_current_", "fresh_saved_", 1))
            if saved is None:
                raise InputValidationError(f"Missing saved freshness counterpart: {name}")
            saved_sheet, saved_region = package.named_region(saved.attrib["name"])
            a, b, c, d = saved_region
            if c - a != right - left or d - b != bottom - top:
                raise InputValidationError(f"Freshness capacity dimensions disagree: {name}")
            saved.text = _sheet_reference(saved_sheet, (a, b, c, d + new_bottom - bottom))
    package._put_xml("xl/workbook.xml", workbook)
    # Named input protection is cached independently of Table rectangles.
    # Force the next output guard to use the expanded owning ranges.
    package._protected_regions = None
    package._protected_sheet_index = None


def prepare_input_capacity(
    package: WorkbookPackage,
    policy: InputCapacityPolicy = DEFAULT_INPUT_CAPACITY_POLICY,
) -> tuple[str, ...]:
    """Reserve input capacity and retain all current business inputs exactly.

    The package is still in memory; its normal atomic save and namespace checks
    remain authoritative. Every planned rectangle is checked before mutation,
    so an unrelated hidden Table or note prevents the whole allocation. The
    return value records expanded owning Tables, excluding support witnesses.
    """
    inventory = package.table_inventory()
    planned = []
    expanded = []
    for suffix, minimum_rows in policy.table_rows.items():
        name = TABLE_PREFIX + suffix
        info = inventory.get(name)
        if info is None:
            continue
        bounds = _growth_bounds(info, minimum_rows)
        if bounds == info.bounds:
            continue
        planned.append((info, bounds))
        expanded.append(name)
        frozen = inventory.get(TABLE_PREFIX + "frozen_" + suffix)
        if frozen is not None:
            if frozen.headers != info.headers:
                raise InputValidationError(f"Input capacity witness headers differ: {name}")
            planned.append((frozen, _growth_bounds(frozen, bounds[3] - bounds[1])))
    moves = _display_moves(package, planned)
    # Each target may be empty in the current worksheet yet collide with
    # another future move. Check the complete destination plan before moving
    # any native Table, links or guidance cells into their reserved lanes.
    for index, (sheet, _, destination, _) in enumerate(moves):
        for other_sheet, _, other_destination, _ in moves[index + 1:]:
            if sheet == other_sheet and _overlap(destination, other_destination):
                raise InputValidationError("Capacity guidance destinations overlap")
    relocating_tables = frozenset(name for _, _, _, name in moves if name)
    relocating_regions = tuple((sheet, source) for sheet, source, _, _ in moves)
    for sheet, source, destination, table_name in moves:
        _check_display_move(package, sheet, source, destination, table_name)
        for info, bounds in planned:
            if info.sheet == sheet and _overlap(destination, bounds):
                raise InputValidationError("Capacity guidance destination overlaps reserved input")
    for info, bounds in planned:
        _check_growth(package, info, bounds, relocating_tables=relocating_tables,
                      relocating_regions=relocating_regions)
    # Planned Tables themselves might be vertically adjacent; checking only
    # their original inventory would miss overlapping future rectangles.
    for index, (info, bounds) in enumerate(planned):
        for other, other_bounds in planned[index + 1:]:
            if info.sheet == other.sheet and _overlap(bounds, other_bounds):
                raise InputValidationError(f"Reserved input Tables overlap: {info.name}, {other.name}")
    for sheet, source, destination, table_name in moves:
        _move_display_region(package, sheet, source, destination, table_name)
    for info, bounds in planned:
        _extend_aliases(package, info, bounds)
        _extend_table(package, info, bounds)
    refresh_asset_id_options(package)
    return tuple(expanded)


def refresh_asset_id_options(package: WorkbookPackage) -> TableInfo | None:
    """Create a compact live dropdown without shortening lookup axes.

    The three helper columns use ordinary scalar INDEX/COUNTIF/MATCH formulas,
    supported by older desktop Excel without spill arrays. Sequence numbers
    omit blank source rows, so an Asset ID entered into any reserved row is
    immediately selectable after Excel recalculates. The canonical asset_ids
    name still spans the full Table, matching other lookup/COUNTIFS axes.
    """
    info = package.table_inventory().get(TABLE_PREFIX + "assets")
    if info is None:
        return None
    if "Asset ID" not in info.headers:
        raise InputValidationError("Asset ID dropdown requires its declared owning column")
    left, top, _, bottom = info.bounds
    column = left + info.headers.index("Asset ID")
    cells = package._sheet_cells(package._xml(package._sheet_parts()[info.sheet]))
    source = [package._cached_value(cells.get(f"{_column(column)}{row}")) for row in range(top + 1, bottom + 1)]
    compact = [value for value in source if isinstance(value, str) and value]
    axis = f"{TABLE_PREFIX}assets[Asset ID]"
    helper_source = f"{ASSET_OPTIONS_TABLE}[Source Asset ID]"
    helper_sequence = f"{ASSET_OPTIONS_TABLE}[Active sequence]"
    records = []
    sequence = 0
    for ordinal, value in enumerate(source, 1):
        active = isinstance(value, str) and bool(value)
        if active:
            sequence += 1
        lookup = f"INDEX({axis},{ordinal})"
        source_formula = f'IFERROR(IF({lookup}="","",{lookup}),"")'
        helper_value = f"INDEX({helper_source},{ordinal})"
        sequence_formula = f'IF({helper_value}="","",COUNTIF(INDEX({helper_source},1):INDEX({helper_source},{ordinal}),"?*"))'
        compact_formula = f'IFERROR(INDEX({helper_source},MATCH({ordinal},{helper_sequence},0)),"")'
        records.append({
            "Source Asset ID": FormulaCell(source_formula, value if active else ""),
            "Active sequence": FormulaCell(sequence_formula, sequence if active else ""),
            "Asset ID": FormulaCell(compact_formula, compact[ordinal - 1] if ordinal <= len(compact) else ""),
        })
    updated = package.add_table(ASSET_OPTIONS_TABLE, ("Source Asset ID", "Active sequence", "Asset ID"), records)
    workbook = package._xml("xl/workbook.xml")
    names = workbook.find(_tag("definedNames"))
    if names is None:
        raise InputValidationError("Compact interface names are missing")
    item = next((item for item in names if item.attrib["name"] == ASSET_OPTIONS_NAME), None)
    if item is None:
        item = ET.SubElement(names, _tag("definedName"), name=ASSET_OPTIONS_NAME)
    if ASSET_OPTIONS_NAME in package.protected_names:
        raise InputValidationError("Asset ID options cannot replace an input owner")
    # COUNTIF('?*') excludes both physical blanks and formula-empty strings.
    # MAX(1, ...) keeps a valid one-cell blank list when no IDs are registered;
    # it never creates a synthetic selectable asset.
    option_axis = f"{ASSET_OPTIONS_TABLE}[Asset ID]"
    item.text = f'INDEX({option_axis},1):INDEX({option_axis},MAX(1,COUNTIF({axis},"?*")))'
    package._put_xml("xl/workbook.xml", workbook)
    for sheet, part in package._sheet_parts().items():
        if sheet == "Market Data":
            continue
        tree = package._xml(part)
        validations = tree.find(_tag("dataValidations"))
        changed = False
        for validation in validations if validations is not None else ():
            formula = validation.find(_tag("formula1"))
            if formula is not None and (formula.text or "").lstrip("=") == UI_PREFIX + "asset_ids":
                formula.text = ASSET_OPTIONS_NAME
                changed = True
        if changed:
            package._put_xml(part, tree)
    return updated
