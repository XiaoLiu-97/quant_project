"""Frozen-data admission and independently hand-sized trade bridge checks."""

from dataclasses import FrozenInstanceError, replace
from datetime import date, datetime, timedelta, timezone
from decimal import Decimal, Inexact, localcontext
import unittest

from trident.analysis.models import AssetExposure
from trident.domain.models import CouponType, InputValidationError, LoanPosition, LoanTerms
from trident.optimization import (
    AssetDescriptor, AssetKind, Holding, OptimizationObjective, OptimizationRequest,
    OptimizationStatus, PortfolioLimits, StaticTradeOptimizer, TradeQuote, TradeSide,
)
from trident.optimization.universe import (
    CandidateAdmissionPolicy, CandidateAssetSnapshot, CandidateCreditStatus, CandidateUniverseSnapshot,
    CandidateUniverseValidator, PriceObservation, PriceSide, QuoteQuality,
    RatingLevel, RatingNature, RatingObservation, reconcile_proposal,
)

D = Decimal
SETTLEMENT = date(2026, 11, 20)
CAPTURE = datetime(2026, 11, 19, 16, 0, tzinfo=timezone.utc)


def descriptor(name="NEW", *, factor="2000"):
    return AssetDescriptor(name, AssetKind.BSL, "ISSUER_1", "GB", "SOFTWARE", D(500), D(factor))


def candidate(name="NEW"):
    asset = descriptor(name)
    position = LoanPosition(LoanTerms(name, "EUR", SETTLEMENT, date(2031, 11, 20), D(10000),
                                     CouponType.FLOATING, rate_index="EURIBOR_3M", spread_bps=D(500)),
                            SETTLEMENT, D(10000))
    exposure = AssetExposure(name, asset.obligor, "BSL", "TERM_LOAN", asset.country, asset.sector,
                             "EUR", D(10000), D(500), position.terms.maturity_date,
                             is_senior=True, is_secured=True, is_pik=False, is_revolver=False,
                             is_construction=False, test_factor_bucket="TEST_B")
    rating = RatingObservation("MOODYS", "B2", RatingLevel.FACILITY, RatingNature.PUBLIC,
                               f"FACILITY_{name}", date(2026, 10, 1), "SYNTHETIC_RATING_FIXTURE")
    price = PriceObservation(TradeQuote(asset, TradeSide.BUY, D(101), D(10000)), PriceSide.ASK,
                             QuoteQuality.FIRM, CAPTURE - timedelta(hours=1), SETTLEMENT,
                             "SYNTHETIC_ASK_FIXTURE")
    return CandidateAssetSnapshot(asset, f"FACILITY_{name}", f"SYNTHETIC_SECURITY_{name}", position,
                                  exposure, (rating,), (price,), "VERIFIED_FIXTURE_TERMS", "FIXTURE_TAXONOMY",
                                  CandidateCreditStatus.PERFORMING)


def snapshot(*candidates):
    return CandidateUniverseSnapshot("SYNTHETIC_SNAPSHOT_1", CAPTURE, "EXCEL_FROZEN_FIXTURE",
                                     "TRIDENT_SYNTHETIC_TEST_FACTOR_V1", tuple(candidates))


def policy(**kwargs):
    return CandidateAdmissionPolicy(**dict(settlement_date=SETTLEMENT, maximum_quote_age=timedelta(hours=1),
        allowed_quote_qualities=(QuoteQuality.FIRM,), **kwargs))


class UniverseAdmissionTests(unittest.TestCase):
    def test_complete_contract_admitted_boundary_age_and_immutable_snapshot(self):
        item = candidate()
        result = CandidateUniverseValidator().validate(snapshot(item), policy())
        self.assertEqual(result.admitted, (item,))
        self.assertEqual(result.quarantined, ())
        self.assertEqual(result.validation_scope, "DATA_AND_OPENING_REPLAY_ADMISSION")
        with self.assertRaises(FrozenInstanceError):
            item.position = None

    def test_empty_universe_valid_and_stable_id_order(self):
        validator = CandidateUniverseValidator()
        self.assertEqual(validator.validate(snapshot(), policy()).admitted, ())
        result = validator.validate(snapshot(candidate("Z"), candidate("A")), policy())
        self.assertEqual(tuple(c.asset_id for c in result.admitted), ("A", "Z"))

    def test_missing_contract_exposure_provenance_and_ratings_quarantined(self):
        item = replace(candidate(), position=None, exposure=None, ratings=(), contract_provenance=None,
                       classification_provenance=None, prices=())
        result = CandidateUniverseValidator().validate(snapshot(item), policy())
        self.assertEqual(result.admitted, ())
        reasons = result.quarantined[0].reasons
        self.assertEqual(len(reasons), 6)
        self.assertTrue(any("contract" in text.lower() for text in reasons))

    def test_stale_and_future_quotes_quarantined_without_refresh_time_substitution(self):
        item = candidate()
        for observed in (CAPTURE - timedelta(hours=1, microseconds=1), CAPTURE + timedelta(microseconds=1)):
            with self.subTest(observed=observed):
                edited = replace(item, prices=(replace(item.prices[0], observed_at=observed),))
                self.assertFalse(CandidateUniverseValidator().validate(snapshot(edited), policy()).admitted)

    def test_mid_last_and_buy_bid_do_not_replace_ask(self):
        item = candidate()
        for side in (PriceSide.BID, PriceSide.MID, PriceSide.LAST):
            with self.subTest(side=side):
                edited = replace(item, prices=(replace(item.prices[0], price_side=side),))
                result = CandidateUniverseValidator().validate(snapshot(edited), policy())
                self.assertIn("requires ASK", result.quarantined[0].reasons[0])

    def test_indicative_and_evaluated_require_explicit_research_policy(self):
        item = candidate()
        for quality in (QuoteQuality.INDICATIVE, QuoteQuality.EVALUATED):
            edited = replace(item, prices=(replace(item.prices[0], quality=quality),))
            self.assertFalse(CandidateUniverseValidator().validate(snapshot(edited), policy()).admitted)
            permissive = CandidateAdmissionPolicy(SETTLEMENT, timedelta(hours=1), (quality,))
            result = CandidateUniverseValidator().validate(snapshot(edited), permissive)
            self.assertEqual(result.admitted[0].prices[0].quality, quality)

    def test_quote_settlement_and_verified_sizing_reference_checked(self):
        item = candidate()
        for price in (replace(item.prices[0], settlement_date=date(2026, 11, 21)),
                      replace(item.prices[0], quote=replace(item.prices[0].quote, maximum_par=D(10001)))):
            result = CandidateUniverseValidator().validate(snapshot(replace(item, prices=(price,))), policy())
            self.assertFalse(result.admitted)

    def test_margin_currency_and_opening_boundary_not_inferred(self):
        item = candidate()
        for asset in (replace(item.asset, spread_bps=D(600)), replace(item.asset, kind=AssetKind.INFRA)):
            result = CandidateUniverseValidator().validate(snapshot(replace(item, asset=asset)), policy())
            self.assertFalse(result.admitted)
        changed_policy = replace(policy(), settlement_date=date(2026, 11, 21))
        self.assertFalse(CandidateUniverseValidator().validate(snapshot(item), changed_policy).admitted)

    def test_quality_flags_do_not_gain_compliant_defaults(self):
        item = candidate()
        for field in ("is_senior", "is_secured", "is_pik", "is_revolver", "is_construction"):
            with self.subTest(field=field):
                edited = replace(item, exposure=replace(item.exposure, **{field: None}))
                self.assertFalse(CandidateUniverseValidator().validate(snapshot(edited), policy()).admitted)
        for field in ("is_pik", "is_revolver", "is_construction"):
            edited = replace(item, exposure=replace(item.exposure, **{field: True}))
            self.assertFalse(CandidateUniverseValidator().validate(snapshot(edited), policy()).admitted)

    def test_old_public_rating_does_not_imply_current_performing_state(self):
        item = candidate()
        for credit_status in (None, CandidateCreditStatus.UNKNOWN, CandidateCreditStatus.DEFAULTED,
                              CandidateCreditStatus.DISTRESSED):
            with self.subTest(credit_status=credit_status):
                edited = replace(item, credit_status=credit_status)
                result = CandidateUniverseValidator().validate(snapshot(edited), policy())
                self.assertFalse(result.admitted)
                self.assertIn("rating is not performance state", result.quarantined[0].reasons[0])

    def test_complete_exposure_must_match_contract_and_descriptor(self):
        item = candidate()
        for changes in ({"par": D(9000)}, {"currency": "USD"}, {"spread_bps": D(499)},
                        {"maturity_date": date(2031, 11, 19)}, {"asset_class": "INFRA"},
                        {"obligor": "OTHER"}, {"country": "US"}, {"sector": "OTHER"}, {"loan_id": "OTHER"}):
            with self.subTest(changes=changes):
                edited = replace(item, exposure=replace(item.exposure, **changes))
                self.assertFalse(CandidateUniverseValidator().validate(snapshot(edited), policy()).admitted)

    def test_rating_subject_and_date_retained_not_auto_notched(self):
        item = candidate()
        issuer = replace(item.ratings[0], level=RatingLevel.ISSUER, subject_id=item.asset.obligor)
        estimate = replace(item.ratings[0], nature=RatingNature.CREDIT_ESTIMATE)
        valid = replace(item, ratings=(issuer, estimate))
        self.assertEqual(CandidateUniverseValidator().validate(snapshot(valid), policy()).admitted, (valid,))
        for rating in (replace(issuer, subject_id="WRONG_ISSUER"), replace(estimate, subject_id="WRONG_FACILITY"),
                       replace(issuer, as_of_date=date(2026, 11, 20))):
            self.assertFalse(CandidateUniverseValidator().validate(snapshot(replace(item, ratings=(rating,))), policy()).admitted)

    def test_duplicate_facility_alias_or_asset_id_rejected(self):
        item = candidate()
        with self.assertRaisesRegex(InputValidationError, "asset_id"):
            snapshot(item, item)
        alias = replace(candidate("ALIAS"), facility_id=item.facility_id)
        with self.assertRaisesRegex(InputValidationError, "facility_id"):
            snapshot(item, alias)

    def test_naive_times_lists_duplicate_observations_and_untyped_policy_rejected(self):
        item = candidate()
        bad_operations = (
            lambda: replace(snapshot(item), captured_at=CAPTURE.replace(tzinfo=None)),
            lambda: replace(item.prices[0], observed_at=CAPTURE.replace(tzinfo=None)),
            lambda: replace(item, ratings=list(item.ratings)),
            lambda: replace(item, ratings=item.ratings * 2),
            lambda: replace(item, prices=item.prices * 2),
            lambda: replace(policy(), maximum_quote_age=1),
            lambda: replace(policy(), allowed_quote_qualities=()),
            lambda: replace(policy(), allowed_quote_qualities=(QuoteQuality.FIRM,) * 2),
        )
        for operation in bad_operations:
            with self.subTest(operation=operation), self.assertRaises(InputValidationError):
                operation()


def proposal_fixture():
    old, new = descriptor("OLD", factor="4000"), descriptor("NEW")
    request = OptimizationRequest((Holding(old, D(100)),),
        (TradeQuote(old, TradeSide.SELL, D(99), D(100), accrued_per_par=D(".02"),
                    proportional_fee_per_par=D(".005"), fixed_fee=D(".01")),
         TradeQuote(new, TradeSide.BUY, D(101), D(100), accrued_per_par=D(".01"),
                    proportional_fee_per_par=D(".005"), fixed_fee=D(".01"))),
        D(10), PortfolioLimits(D(100)), OptimizationObjective.MIN_FACTOR,
        "TRIDENT_SYNTHETIC_TEST_FACTOR_V1", SETTLEMENT)
    return request, StaticTradeOptimizer().solve(request)


class ProposalReconciliationTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.request, cls.result = proposal_fixture()

    def test_hand_calculated_target_trade_and_cash_bridge(self):
        plan = reconcile_proposal(self.request, self.result)
        # Sell: 99+2-.50-.01=100.49. Buy: -101-1-.50-.01=-102.51.
        self.assertEqual(plan.ending_cash, D("7.98"))
        self.assertEqual(plan.ending_par, D(100))
        self.assertEqual(tuple(h.asset.asset_id for h in plan.holdings), ("NEW",))
        self.assertEqual([(c.asset_id, c.baseline_par, c.target_par, c.signed_trade_par) for c in plan.changes],
                         [("NEW", D(0), D(100), D(100)), ("OLD", D(100), D(0), D(-100))])
        self.assertEqual(plan.validation_scope, "STATIC_PROPOSAL_RECONCILED")

    def test_baseline_no_trade_and_low_decimal_context(self):
        request = replace(self.request, quotes=())
        result = StaticTradeOptimizer().solve(request)
        with localcontext() as context:
            context.prec = 2
            context.traps[Inexact] = True
            baseline = reconcile_proposal(request, result)
            traded = reconcile_proposal(self.request, self.result)
        self.assertEqual(baseline.trades, ())
        self.assertEqual(baseline.changes[0].signed_trade_par, D(0))
        self.assertEqual(traded.ending_cash, D("7.98"))

    def test_stable_output_order_for_reordered_evidence(self):
        reordered = replace(self.result, trades=self.result.trades[::-1])
        self.assertEqual(reconcile_proposal(self.request, reordered), reconcile_proposal(self.request, self.result))

    def test_unvalidated_or_wrong_scope_provenance_rejected(self):
        for result in (replace(self.result, status=OptimizationStatus.INFEASIBLE),
                       replace(self.result, validation_scope="FUTURE"),
                       replace(self.result, factor_provenance="UNKNOWN"),
                       replace(self.result, violations=("BREACH",))):
            with self.subTest(result=result), self.assertRaises(InputValidationError):
                reconcile_proposal(self.request, result)

    def test_tampered_trade_cash_quantity_side_or_target_rejected(self):
        trade = self.result.trades[0]
        bad_trades = (replace(trade, clean_cash=D(98)), replace(trade, accrued_cash=D(0)),
                      replace(trade, fee_cash=D(0)), replace(trade, cash_change=D(100)),
                      replace(trade, par=D(99)), replace(trade, side=TradeSide.BUY),
                      replace(trade, asset_id="UNKNOWN"), replace(trade, clean_cash=99.0))
        bad_results = tuple(replace(self.result, trades=(bad,) + self.result.trades[1:]) for bad in bad_trades)
        bad_results += (replace(self.result, trades=self.result.trades * 2),
                        replace(self.result, ending_holdings=self.result.ending_holdings * 2),
                        replace(self.result, ending_cash=D("7.99")), replace(self.result, ending_par=D(99)),
                        replace(self.result, ending_holdings=(replace(self.result.ending_holdings[0], par=D(99)),)),
                        replace(self.result, ending_holdings=()), replace(self.result, trades=()))
        for result in bad_results:
            with self.subTest(result=result), self.assertRaises(InputValidationError):
                reconcile_proposal(self.request, result)


if __name__ == "__main__":
    unittest.main()
