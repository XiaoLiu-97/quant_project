"""Validated, immutable class-by-payment-date waterfall presentation records.

The execution engine retains its original cash and coverage snapshots.  This
module joins them once for reporting; it does not recalculate coverage ratios
or treat a junior gate that was never reached as a passing gate.
"""

from dataclasses import dataclass, fields
from datetime import date
from decimal import Decimal
from enum import Enum
from fractions import Fraction

from trident.domain.models import InputValidationError, require_money
from trident.domain.numeric import post_currency, decimal_fraction

from .models import CloProjection, CoverageStatus, CoverageTestResult


class TranchePeriodStatus(str, Enum):
    """A class state at this payment date, distinct from final deal status."""

    ACTIVE = "ACTIVE"
    REDEEMED = "REDEEMED"
    COUPON_ARREARS = "COUPON_ARREARS"


@dataclass(frozen=True)
class TranchePeriodReport:
    """One row per emitted payment period and rated class; cash is EUR cents.

    A ``None`` gate status with ``gate_evaluated=False`` means the allocation
    stopped at a more senior failed gate.  PERIOD_END is always a diagnostic,
    never evidence that an earlier gate passed.  OC/IC ratios are unitless
    decimal multiples; rate and DCF values retain the engine's diagnostics.
    """

    period_number: int
    payment_date: date
    class_id: str
    payment_priority: int
    accrual_start: date
    accrual_end: date
    opening_balance: Decimal
    closing_balance: Decimal
    opening_coupon_arrears: Decimal
    current_coupon_due: Decimal
    total_coupon_claim: Decimal
    coupon_paid_from_interest: Decimal
    coupon_paid_from_principal: Decimal
    total_coupon_paid: Decimal
    closing_coupon_arrears: Decimal
    principal_from_interest: Decimal
    principal_from_principal: Decimal
    total_principal_paid: Decimal
    total_cash_paid: Decimal
    cumulative_coupon_paid: Decimal
    cumulative_principal_paid: Decimal
    cumulative_cash_paid: Decimal
    fixing_date: date | None
    index_rate: Decimal | None
    all_in_rate: Decimal
    day_count_fraction: Decimal
    interest_gate_blocked: bool
    class_status: TranchePeriodStatus
    oc_minimum: Decimal | None
    ic_minimum: Decimal | None
    gate_evaluated: bool
    gate_oc_numerator: Decimal | None
    gate_oc_denominator: Decimal | None
    gate_oc_ratio: Decimal | None
    gate_oc_status: CoverageStatus | None
    gate_ic_numerator: Decimal | None
    gate_ic_denominator: Decimal | None
    gate_ic_ratio: Decimal | None
    gate_ic_status: CoverageStatus | None
    gate_minimum_interest_repayment_for_oc: Decimal | None
    post_diversion_evaluated: bool
    post_diversion_oc_numerator: Decimal | None
    post_diversion_oc_denominator: Decimal | None
    post_diversion_oc_ratio: Decimal | None
    post_diversion_oc_status: CoverageStatus | None
    post_diversion_ic_numerator: Decimal | None
    post_diversion_ic_denominator: Decimal | None
    post_diversion_ic_ratio: Decimal | None
    post_diversion_ic_status: CoverageStatus | None
    post_diversion_minimum_interest_repayment_for_oc: Decimal | None
    period_end_oc_numerator: Decimal
    period_end_oc_denominator: Decimal
    period_end_oc_ratio: Decimal | None
    period_end_oc_status: CoverageStatus
    period_end_ic_numerator: Decimal
    period_end_ic_denominator: Decimal
    period_end_ic_ratio: Decimal | None
    period_end_ic_status: CoverageStatus
    period_end_minimum_interest_repayment_for_oc: Decimal | None
    coupon_shortfall_interest: Decimal = Decimal(0)
    waived_coupon_shortfall: Decimal = Decimal(0)
    pik_interest_capitalized: Decimal = Decimal(0)
    total_current_coupon_accrued: Decimal = Decimal(0)
    cumulative_pik_interest_capitalized: Decimal = Decimal(0)


@dataclass(frozen=True)
class ResidualEquityPeriodReport:
    """One residual equity row per emitted period, without fictitious debt par.

    ``equity_cash_funding`` is metadata describing the closing investor cash
    outlay, not another payment on this distribution date. The cumulative
    distribution multiple is realised distributions / actual cumulative funding,
    not a terminal value or an annualised return. Equity has no note coupon,
    debt-par balance, or rated-class IC/OC coverage test.
    """

    period_number: int
    payment_date: date
    class_id: str
    payment_priority: int
    accrual_start: date
    accrual_end: date
    equity_from_interest: Decimal
    equity_from_principal: Decimal
    equity_from_reserve: Decimal
    total_cash_paid: Decimal
    cumulative_cash_paid: Decimal
    equity_cash_funding: Decimal
    cumulative_equity_distribution_multiple: Decimal | None
    class_status: str = "RESIDUAL"
    instrument_type: str = "EQUITY"
    equity_capital_contribution: Decimal = Decimal(0)
    net_investor_cashflow: Decimal = Decimal(0)
    cumulative_equity_cash_funding: Decimal = Decimal(0)


_STAGES = {"GATE", "POST_DIVERSION", "PERIOD_END"}


def _cash_sum(*values: Decimal) -> Decimal:
    """Sum posted cash exactly, independent of the caller's Decimal context."""
    return post_currency(sum((Fraction(value) for value in values), Fraction(0)))


def _stage_fields(prefix: str, test: CoverageTestResult | None) -> dict[str, object]:
    """Preserve an absent gate as None; never replace a missing trace with PASS."""
    return {
        f"{prefix}_{name}": getattr(test, name) if test is not None else None
        for name in (
            "oc_numerator", "oc_denominator", "oc_ratio", "oc_status",
            "ic_numerator", "ic_denominator", "ic_ratio", "ic_status",
            "minimum_interest_repayment_for_oc",
        )
    }


def report_tranche_periods(projection: CloProjection) -> tuple[TranchePeriodReport, ...]:
    """Join complete class-period snapshots and enforce their financial bridges.

    Reject duplicate/missing/orphan snapshots and incompatible coverage traces
    rather than silently showing incomplete rows.  Complexity is O(n) apart
    from the small final ordering by period and payment priority.  Source records
    are never mutated; no payment dates are fabricated beyond engine output.

    The join key is (period, class), not just class or deal totals. Gate traces
    retain their actual measurement node; final face balances and coupon-origin
    claims remain separate even when a coverage policy capitalizes those claims.
    """
    if not isinstance(projection, CloProjection):
        raise InputValidationError("projection must be CloProjection")
    periods = {row.period_number: row for row in projection.periods}
    if not periods or len(periods) != len(projection.periods):
        raise InputValidationError("Waterfall report requires unique nonempty periods")
    first_number = projection.first_projected_period_number
    # A resumed projection retains the original legal-period identity. Its
    # explicit start comes from the engine; holes within the emitted tail are
    # still errors, and ordinary closing projections must still begin at one.
    if (type(first_number) is not int or first_number < 1
            or sorted(periods) != list(range(first_number, first_number + len(periods)))):
        raise InputValidationError("Waterfall periods must be complete and sequential")
    snapshots = {}
    identities = {}
    for row in projection.tranche_periods:
        key = (row.period_number, row.class_id)
        if key in snapshots or row.period_number not in periods:
            raise InputValidationError("Duplicate or orphan tranche-period snapshot")
        if row.payment_date != periods[row.period_number].payment_date:
            raise InputValidationError("Tranche payment date differs from deal period")
        if row.class_id in identities and identities[row.class_id] != row.payment_priority:
            raise InputValidationError("Class payment priority changes across periods")
        identities[row.class_id] = row.payment_priority
        snapshots[key] = row
    if not identities or len(set(identities.values())) != len(identities):
        raise InputValidationError("Waterfall classes require unique payment priorities")
    expected = {(number, class_id) for number in periods for class_id in identities}
    if set(snapshots) != expected:
        raise InputValidationError("Waterfall requires every class in every emitted period")
    tests = {}
    for test in projection.coverage_tests:
        key = (test.period_number, test.class_id, test.stage)
        snapshot = snapshots.get(key[:2])
        if key in tests or snapshot is None or test.stage not in _STAGES:
            raise InputValidationError("Duplicate, unknown, or orphan coverage snapshot")
        if (test.payment_date != snapshot.payment_date
                or test.payment_priority != snapshot.payment_priority):
            raise InputValidationError("Coverage identity/date differs from tranche snapshot")
        tests[key] = test
    # Once identities/coverage traces are complete, build rows and independently
    # reconcile each class's face/coupon bridge and its cross-period continuity.
    reports, cumulative, prior_rows = [], {}, {}
    money_fields = (
        "opening_balance", "closing_balance", "opening_coupon_arrears",
        "current_coupon_due", "coupon_paid_from_interest", "coupon_paid_from_principal",
        "closing_coupon_arrears", "principal_from_interest", "principal_from_principal",
        "coupon_shortfall_interest", "waived_coupon_shortfall",
        "pik_interest_capitalized",
    )
    for key in sorted(snapshots, key=lambda key: (key[0], identities[key[1]])):
        row = snapshots[key]
        period = periods[row.period_number]
        for name in money_fields:
            require_money(getattr(row, name), f"waterfall {name}")
        current_due = _cash_sum(row.opening_coupon_arrears, row.current_coupon_due, row.coupon_shortfall_interest)
        coupon_paid = _cash_sum(row.coupon_paid_from_interest, row.coupon_paid_from_principal)
        principal_paid = _cash_sum(row.principal_from_interest, row.principal_from_principal)
        total_paid = _cash_sum(coupon_paid, principal_paid)
        if Fraction(row.opening_balance) + Fraction(row.pik_interest_capitalized) - Fraction(principal_paid) != Fraction(row.closing_balance):
            raise InputValidationError("Tranche principal bridge fails in waterfall report")
        if Fraction(current_due) - Fraction(coupon_paid) - Fraction(row.waived_coupon_shortfall) != Fraction(row.closing_coupon_arrears):
            raise InputValidationError("Tranche coupon bridge fails in waterfall report")
        prior = prior_rows.get(row.class_id)
        if prior is not None and (row.opening_balance != prior.closing_balance
                                  or row.opening_coupon_arrears != prior.closing_coupon_arrears):
            raise InputValidationError("Tranche balance/arrears chain fails across periods")
        prior_rows[row.class_id] = row
        end = tests.get((*key, "PERIOD_END"))
        gate = tests.get((*key, "GATE"))
        post = tests.get((*key, "POST_DIVERSION"))
        if end is None:
            raise InputValidationError("Missing mandatory period-end class coverage diagnostic")
        if row.interest_gate_blocked == (gate is not None):
            raise InputValidationError("Gate trace conflicts with blocked class allocation")
        for test in (gate, post):
            if test is not None and (test.oc_minimum != end.oc_minimum or test.ic_minimum != end.ic_minimum):
                raise InputValidationError("Coverage thresholds change within one class-period")
        totals = cumulative.get(row.class_id, (Decimal(0), Decimal(0), Decimal(0), Decimal(0)))
        totals = tuple(_cash_sum(previous, current) for previous, current in zip(
            totals, (coupon_paid, principal_paid, total_paid, row.pik_interest_capitalized), strict=True))
        cumulative[row.class_id] = totals
        status = (TranchePeriodStatus.COUPON_ARREARS if row.closing_coupon_arrears else
                  TranchePeriodStatus.REDEEMED if not row.closing_balance else TranchePeriodStatus.ACTIVE)
        reports.append(TranchePeriodReport(
            **{field.name: getattr(row, field.name) for field in fields(row)},
            accrual_start=period.accrual_start, accrual_end=period.accrual_end,
            total_coupon_claim=current_due, total_coupon_paid=coupon_paid,
            total_principal_paid=principal_paid, total_cash_paid=total_paid,
            cumulative_coupon_paid=totals[0], cumulative_principal_paid=totals[1],
            cumulative_cash_paid=totals[2], class_status=status,
            total_current_coupon_accrued=_cash_sum(row.current_coupon_due, row.pik_interest_capitalized),
            cumulative_pik_interest_capitalized=totals[3],
            oc_minimum=end.oc_minimum, ic_minimum=end.ic_minimum,
            gate_evaluated=gate is not None, post_diversion_evaluated=post is not None,
            **_stage_fields("gate", gate), **_stage_fields("post_diversion", post),
            **_stage_fields("period_end", end),
        ))
    # Independent class totals must agree with the aggregate accounting ledger.
    grouped = {}
    for row in reports:
        grouped.setdefault(row.period_number, []).append(row)
    for number, rows in grouped.items():
        period = periods[number]
        pairs = (
            ("opening_balance", "opening_debt_par"), ("closing_balance", "closing_debt_par"),
            ("total_coupon_claim", "note_coupon_due"), ("total_coupon_paid", "note_coupon_paid"),
            ("closing_coupon_arrears", "note_coupon_unpaid"),
            ("principal_from_interest", "debt_principal_from_interest"),
            ("principal_from_principal", "debt_principal_from_principal"),
            ("coupon_shortfall_interest", "note_shortfall_interest"),
            ("waived_coupon_shortfall", "waived_note_coupon_shortfall"),
            ("pik_interest_capitalized", "note_pik_capitalized"),
        )
        for class_field, deal_field in pairs:
            if _cash_sum(*(getattr(row, class_field) for row in rows)) != getattr(period, deal_field):
                raise InputValidationError(f"Class waterfall totals disagree with {deal_field}")
    return tuple(reports)


def report_equity_periods(
    projection: CloProjection, *, class_id: str, payment_priority: int,
    equity_cash_funding: Decimal,
) -> tuple[ResidualEquityPeriodReport, ...]:
    """Report the combined residual class, reconciling the dated equity ledger.

    The engine supports one residual equity investor class. Real transaction
    sub-classes and holder allocations require their own state. Explicit funded
    refinancing contributions are included; no rated-class ratios are assigned.
    Zero distribution periods are included. Unresolved projections retain only
    their actual emitted periods and never manufacture a terminal payoff.
    """
    if not isinstance(projection, CloProjection) or not projection.periods:
        raise InputValidationError("Equity report requires a nonempty CloProjection")
    if not isinstance(class_id, str) or not class_id or class_id != class_id.strip():
        raise InputValidationError("Residual class_id must be a nonblank unpadded string")
    require_money(equity_cash_funding, "equity_cash_funding")
    if type(payment_priority) is not int or payment_priority < 1:
        raise InputValidationError("Residual payment_priority must be a positive integer")
    note_classes = {row.class_id for row in projection.tranche_periods}
    note_priorities = {row.payment_priority for row in projection.tranche_periods}
    if class_id in note_classes or (note_priorities and payment_priority <= max(note_priorities)):
        raise InputValidationError("Residual equity must have a distinct class and junior payment priority")
    expected, rows, cumulative = {}, [], Decimal(0)
    contributions = {}
    payment_dates = {row.payment_date for row in projection.periods}
    for contribution in projection.equity_contributions:
        amount = require_money(contribution.amount, "equity capital contribution")
        if contribution.payment_date not in payment_dates:
            raise InputValidationError("Equity contribution must reconcile to an emitted CLO event date")
        contributions[contribution.payment_date] = _cash_sum(contributions.get(contribution.payment_date, Decimal(0)), amount)
    cumulative_funding = equity_cash_funding
    source_fields = {
        "INTEREST_RESIDUAL": "equity_from_interest",
        "PRINCIPAL_RESIDUAL": "equity_from_principal",
        "FINAL_RESERVE_RELEASE": "equity_from_reserve",
    }
    first_number = projection.first_projected_period_number
    if (type(first_number) is not int or first_number < 1
            or [row.period_number for row in projection.periods] != list(range(first_number, first_number + len(projection.periods)))):
        raise InputValidationError("Equity periods must be sequential and complete")
    if len({row.payment_date for row in projection.periods}) != len(projection.periods):
        raise InputValidationError("Equity periods must have unique payment dates")
    for period in projection.periods:
        for source, field in source_fields.items():
            amount = require_money(getattr(period, field), f"equity {field}")
            if amount:
                expected[(period.payment_date, source)] = amount
        current = _cash_sum(*(getattr(period, field) for field in source_fields.values()))
        cumulative = _cash_sum(cumulative, current)
        contribution = contributions.get(period.payment_date, Decimal(0))
        cumulative_funding = _cash_sum(cumulative_funding, contribution)
        multiple = (decimal_fraction(Fraction(cumulative) / Fraction(cumulative_funding))
                    if cumulative_funding else None)
        rows.append(ResidualEquityPeriodReport(
            period.period_number, period.payment_date, class_id, payment_priority,
            period.accrual_start, period.accrual_end,
            period.equity_from_interest, period.equity_from_principal, period.equity_from_reserve,
            current, cumulative, equity_cash_funding, multiple,
            equity_capital_contribution=contribution,
            net_investor_cashflow=post_currency(Fraction(current) - Fraction(contribution)),
            cumulative_equity_cash_funding=cumulative_funding,
        ))
    actual = {}
    for distribution in projection.equity_cashflows:
        amount = require_money(distribution.amount, "dated equity distribution")
        if distribution.source not in source_fields:
            raise InputValidationError("Unknown source in dated equity distribution ledger")
        if amount:
            key = (distribution.payment_date, distribution.source)
            actual[key] = _cash_sum(actual.get(key, Decimal(0)), amount)
    if actual != expected or cumulative != projection.total_equity_distributions:
        raise InputValidationError("Equity class report does not reconcile to dated/aggregate distributions")
    return tuple(rows)
