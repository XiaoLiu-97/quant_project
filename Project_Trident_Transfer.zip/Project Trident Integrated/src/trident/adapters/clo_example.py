"""Explicit H00 design-fixture adapter, separate from production model schemas."""

import json
from pathlib import Path

from trident.application.clo_services import TridentModelResult, TridentModelService
from trident.domain.models import InputValidationError
from trident.market.rates import FlatRateProvider
from .csv_input import read_csv_records
from .model_records import model_request_from_records
from .records import decimal_value


def run_synthetic_clo_example(directory: Path) -> TridentModelResult:
    """Run labelled H00 cash-pay/no-trades economics, not arbitrary JSON deals.

    This JSON also contains narrative future requirements. Only the explicit
    numerical fields below are consumed. Unsupported event/fee/call switches
    are rejected; production integrations should use typed TridentModelRequest.
    """
    directory = directory.resolve(strict=True)
    terms = json.loads((directory / "deal_terms.json").read_text(encoding="utf-8"))
    if not isinstance(terms, dict) or not isinstance(terms.get("provenance"), dict):
        raise InputValidationError("H00 design terms and provenance must be JSON objects")
    provenance = terms.get("provenance", {})
    if (terms.get("fixture_id") != "TRIDENT_HYBRID_500M_V1" or terms.get("fixture_version") != "1.0"
            or provenance.get("classification") != "SYNTHETIC_ONLY"
            or any(provenance.get(key) is not False for key in ("is_actual_deal", "is_market_quote", "is_rating_agency_model"))
            or terms.get("currency") != "EUR"):
        raise InputValidationError("CLO example requires the labelled EUR H00 version-1.0 design fixture")
    credit, fees, waterfall = terms["credit_baseline"], terms["recurring_fees"], terms["waterfall"]
    if (fees["management_fee_day_count"] != "ACT_360" or fees["fixed_expenses_day_count"] != "ACT_365F"
            or terms["capital_stack"]["interest_payment_type"] != "CASH_PAY_ALL_DEBT_CLASSES"):
        raise InputValidationError("H00 runner requires explicit ACT/360 management fees, ACT/365F expenses and cash-pay notes")
    if (any(credit[key] for key in ("default_events", "prepayment_events", "rating_migration_events"))
            or credit["recovery_assumption"] is not None
            or any(waterfall[key] for key in ("optional_call_enabled", "refinancing_enabled", "eod_liquidation_defined"))
            or terms["capital_stack"]["optional_interest_deferral_or_pik"]
            or decimal_value(fees["incentive_fee_bps"], "incentive_fee_bps") != 0
            or decimal_value(fees["opening_arrears_eur"], "opening_arrears_eur") != 0
            or terms["trading_scope"]["candidate_trade_universe"] is not None):
        raise InputValidationError("H00 runner supports cash-pay notes, zero opening arrears and NO_TRADES without credit events/calls")
    market = terms["market_data"]
    if market["provenance"] != "SYNTHETIC_FLAT_RATE_NOT_LIVE_DATA":
        raise InputValidationError("H00 runner requires explicitly synthetic flat EURIBOR")
    index = decimal_value(market["index_rate_fraction"], "synthetic index rate")
    provider = FlatRateProvider({f"EURIBOR_{tenor}M": index for tenor in (1, 3, 6)})
    assets, capital = read_csv_records(directory / "assets.csv"), read_csv_records(directory / "capital_stack.csv")
    for row in capital:
        if row["instrument_type"] == "DEBT":
            row["oc_minimum"] = terms["coverage"]["oc_minimum_fraction_by_class"][row["class_id"]]
            row["ic_minimum"] = terms["coverage"]["ic_minimum_fraction_by_class"][row["class_id"]]
    schedule, funding = terms["schedule_conventions"], terms["closing_sources_and_uses"]
    controls = {
        "mode": "CLO_BASELINE", "upfront_fees": funding["upfront_fees"], "cash_reserve": funding["cash_reserve_funding"],
        "legal_final_date": terms["capital_stack"]["note_legal_maturity_date_unadjusted"],
        "clo_frequency_months": schedule["coupon_frequency_months"],
        "senior_management_fee_bps": fees["senior_management_fee_bps"],
        "subordinated_management_fee_bps": fees["subordinated_management_fee_bps"],
        "annual_senior_expenses": fees["fixed_expenses_eur_per_year"],
        "clo_business_day_convention": schedule["business_day_convention"],
        "clo_accrual_date_basis": schedule["accrual_date_basis"],
        "clo_fixing_lag_business_days": schedule["fixing_lag_target_business_days"],
        "clo_end_of_month": False, "clo_stub_convention": "SHORT_LAST", "collection_cutoff_business_days": 0,
        "reinvestment_strategy": "NO_TRADES", "reinvestment_end_date": terms["trading_scope"]["reinvestment_end_date_exclusive"],
    }
    factors = tuple({"system": row["test_factor_system"], "version": row["fixture_version"],
                     "bucket": row["test_factor_bucket"], "factor": row["synthetic_test_factor"], "is_synthetic": True}
                    for row in read_csv_records(directory / "test_factor_mapping.csv"))
    gates = terms["quality_and_concentration_gates"]
    specs = (
        ("INFRA_MIN", "concentration:asset_class:INFRA", "MINIMUM", gates["infra_minimum_fraction"]),
        ("BSL_MAX", "concentration:asset_class:BSL", "MAXIMUM", gates["bsl_maximum_fraction"]),
        ("OBLIGOR_MAX", "LARGEST_OBLIGOR_FRACTION", "MAXIMUM", gates["single_obligor_maximum_fraction"]),
        ("COUNTRY_MAX", "LARGEST_COUNTRY_FRACTION", "MAXIMUM", gates["single_country_maximum_fraction"]),
        ("SECTOR_MAX", "LARGEST_SECTOR_FRACTION", "MAXIMUM", gates["single_sector_maximum_fraction"]),
        ("SENIOR_MIN", "SENIOR_FRACTION", "MINIMUM", 1), ("SECURED_MIN", "SECURED_FRACTION", "MINIMUM", 1),
        ("PIK_MAX", "PIK_FRACTION", "MAXIMUM", 0), ("REVOLVER_MAX", "REVOLVER_FRACTION", "MAXIMUM", 0),
        ("CONSTRUCTION_MAX", "CONSTRUCTION_FRACTION", "MAXIMUM", 0),
        ("TEST_FACTOR_MAX", "TEST_FACTOR_AVERAGE", "MAXIMUM", gates["combined_synthetic_test_factor_maximum"]),
        ("BSL_TEST_FACTOR_MAX", "BSL_TEST_FACTOR_AVERAGE", "MAXIMUM", gates["bsl_synthetic_test_factor_maximum"]),
        ("TEST_06_MAX", "concentration:test_factor_bucket:TEST_06", "MAXIMUM", gates["test_06_maximum_fraction"]),
    )
    limits = tuple({"limit_id": key, "metric": metric, "direction": direction, "threshold": value,
                    "phases": "CLOSING,REINVESTMENT", "enabled": True} for key, metric, direction, value in specs)
    request = model_request_from_records(assets, capital, provider, controls=controls,
        factors=factors, limits=limits, provenance=market["provenance"])
    return TridentModelService().run(request)
