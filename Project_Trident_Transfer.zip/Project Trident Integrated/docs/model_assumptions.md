# 模型假设与金融口径

本项目复用 generic EUR CLO engine。具体交易应以 executed agreement/indenture、有效 amendment、agent/trustee snapshot 和适用 rating methodology 为准。选用 generic policy 或 synthetic TEST mapping 不代表已复制一个真实交易或获得 agency calibration。

## 金额、日期与利息

金额使用 Decimal/精确分数并在规定的货币 posting 节点舍入到EUR cent；显示格式不改变数值。Spread 与明确 bps 字段在边界转换一次。Purchase/issue price 是每100 face 的 price points；dirty accrued、owned coupon entitlement、资金来源和 proceeds classification 为不同输入。

简单 coupon 按 applicable reference fixing、index floor/cap、spread、all-in floor/cap 和 day count 计算。每段 coupon 保留原 reset/fixing/accrual dates；loan payment、accrual boundary 和 fixing lag 不混用。复杂 RFR、coupon steps、PIK 和 amortization 使用其独立已支持规则。Seasoned 持仓保留原 schedule，未核验的历史 fixing 或 coupon ownership 不由未来曲线推测。

Closing equity cost 来自 Sources & Uses：实际 asset clean/accrued cost、明确费用/其他uses/reserve，减实际 debt proceeds/明确sources。当前 opening 使用 sourced equity mark，历史 acquisition、issuance 和 setup cash 不再记一遍。IRR 使用真实日期及365年化；MOIC 使用净 investor cash，不以 residual nominal 替代成本。

## 收款、违约与再投资

合同应付现金保留为 reference。Explicit default/prepayment 和 proportional original-pool stress 生成 actual collection/par ledger；瀑布使用该实际收款。Default 时不制造未收 borrower coupon，recovery cash 只在其明确日期入账；未解决 default claim 不被假定已回收。CPR、CDR、recovery 与时间模式为用户选择的 deterministic assumptions，不是对未来随机路径或评级损失分布的认证。

Synthetic reinvestment 是 bullet template cohort：在授权 waterfall date 支付一次 purchase cash，按明确price取得face，purchase 前不计coupon；maturity来自明确的bullet WAL（月数舍入），不因legal final自动缩短。Original-principal permission 和 held IDT cash 是 principal cash 的子集。资金回收政策明确决定 recovery/synthetic principal 是否可继续购买。STOP模式先检查买前coverage/coupon权限，再以只读purchase plan检查拟买后的generic OC/IC；不以未来coupon改善本期IC。否决计划保持ledger/现金/designations不变，普通本金继续正常分配，active held IDT按现有窗口保留。提交后立即刷新valuation供principal gate使用。ALWAYS仅作为明确的coverage/coupon敏感性override，不绕过资金/日期/final、禁止long-dated或asset-level classification保护；也不是完整法律eligibility证明。它不执行 dealer quote、不模拟未来交易策略，也不求动态lifetime optimum。细节与中间节点手算见[waterfall方法](methodology/waterfall.md#synthetic-purchase-的前后状态检查)。

## Waterfall 与 coverage

Interest、principal、reserve 和 cutoff pending balances 分开。Coupon、fee claims、face 和 PIK capitalization 分开；现金、collateral、default claim、debt face 及coupon claim每期均有独立守恒。Current coupon按期初face计提，再依条款支付/递延；principal付息遵从明确permission与seniority。

Generic OC 使用 adjusted collateral value 和配置允许的 principal cash；current CCC market mark 与 discount acquisition price不同，不能静默互补。Capitalized deferred coupon 是否计入 OC 与是否计入 IC 分别选择。IC 的 generic实现采用该节点的可用 realized cash与适用senior claims；真实交易可能采用expected/scheduled income、hedge/tax/smoothing等定义，必须另行映射。

Interest-funded OC cure 的简单目标为 `D - N/k`；当principal payment同时减少numerator和denominator且`k>1`时，目标为`(kD-N)/(k-1)`。需要的金额向上到cent，支付受实际可用现金和seniority限制，并在执行节点重新测试。没有达到的junior GATE保持BLOCKED；PERIOD_END是最终状态诊断，不能证明早先gate通过。

独立 IDT 与coverage failure diversion不是同一个开关。IDT有自己的tested class、threshold、可转比例和window；interest→principal转账不产生收入或新资产。OCP Euro CLO 2017-1 的2026 offering circular提供独立交易例子：IDT位于其特定priority，threshold106%，remaining-interest上限50%，并在reinvestment period适用。该文本只作条款参照；本项目generic stage未声称复制其完整priorities。[原始offering circular](https://ise-prodnr-eu-west-1-data-integration.s3-eu-west-1.amazonaws.com/202601/07d64e17-e59d-4980-b089-0096b0ee4bc1.pdf)，printed pp.167、202–203。

Default collections与purchase eligibility也应按交易文本核验；Carlyle Direct Lending CLO 2024-1的indenture §1.1与§12.2明确规定default collections分类及购买后的coverage条件。本模型的synthetic policy不是完整法律eligibility引擎。[SEC原始indenture](https://www.sec.gov/Archives/edgar/data/1702510/000170251024000079/indenture-clo2024x1.htm)。

## Opening what-if

未来费用、coupon/coverage edits保留开账accounts、claims、原dates/fixings和permissions。现有持仓/face resize只是一份counterfactual opening snapshot；必须明确声明完整equity value及source。Asset owned slice按原exact entitlement缩放，BESPOKE本金用largest remainders分配cent并保留dates；不按已经rounded的历史coupon再乘比例。

带历史前缀的FULL_CURRENT_PERIOD无法用base coupon edit重写历史；原accrual start等于as-of且claim明确0时没有历史前缀，未来coupon可修改。Receipt-specific principal-accrued instructions不能自动rebind到resize后资产。ADD/REMOVE、realized trade cash/P&L或中途交易执行不由该服务推测。

## 完整性与有限范围

缺失rating/factor/metadata时保留coverage与UNAVAILABLE，不缩小denominator假装完整。WAS以floating par加权，WAC以fixed par加权；synthetic factor与agency WARF分别报告。WAL由本金日期/金额计算，不能用final maturity替代。

终态仍有debt、cash、default inventory、unpaid claims或未确认terminal value时，model不凭空分配terminal cash或声称完整IRR。Opening支持post-distribution liability boundary，不支持mid-period liability history、缺失historical incentive hurdle、positive defaulted opening inventory或pending real trades。更多细节见本项目各[methodology文档](methodology/financial_validation.md)与[readiness](readiness.md)。


## 当前界面的输入拥有者

当前价格与利息的拥有者是 Collateral Pool：每项实际持仓的 acquisition price 和 purchased accrued 在该表输入。CLO Assumptions 保留的 aggregate purchase price/accrued 和 Reference Curve 是参考字段，不覆盖逐项持仓或贷款 coupon index。债券 Coupon index 与 Day count 由 Capital Stack 拥有；单项资产条款由 Asset Library/Asset Schedules 拥有。Global Day Count 用于 synthetic reinvestment coupon，账户计息和费用 convention 则按明确的 execution policy。保留的 Collateral Cashflow Input Mode 不切换计算来源；当前 compact 流程使用 INTERNAL_ENGINE。请修改真正拥有该输入的表，避免只改变参考字段而以为已修改金融假设。
