# 解压后的环境设置、迁移与运行

当前软件版本为 **0.12.3**。本项目包含独立源码、输入、测试和文档。邮件迁移包不包含 Python 解释器、`.venv` 或第三方 packages；在公司电脑完成下面的设置后才能运行。

## 最短操作路径

完整解压 → 进入含 `pyproject.toml` 的项目根目录 → 确认 Python 3.12、64-bit → 创建 `.venv` → 安装项目和 packages → 检查环境 → 测试 → 计算工作簿。

以下命令在 **Windows PowerShell** 或 VS Code 的 PowerShell Terminal 中执行。不要在 Excel、Python 的 `>>>` 窗口或压缩包预览里执行。每条命令成功后再执行下一条。

## 1. 解压并找到项目根目录

完整解压 `Project_Trident_Transfer.zip`，将其中的 `Project Trident Integrated` 文件夹放在公司允许、你有写权限的目录。不要只复制 Excel 或 `src`，也不要在 ZIP 内直接运行。项目的安装和 launcher 都需要完整的文件夹结构。

在资源管理器打开这个文件夹，可在地址栏输入 `powershell` 后回车，或选择“在终端中打开”。若 Terminal 使用其他 shell，切换到 PowerShell。

```powershell
Get-Location
Test-Path -LiteralPath '.\pyproject.toml'
Test-Path -LiteralPath '.\Run_Model.cmd'
Test-Path -LiteralPath '.\outputs\Project_Trident.xlsx'
```

后三项都应输出 `True`。如果为 `False`，通常停在解压后的外层文件夹，或解压不完整。进入包含这些文件的那一层。

需要手动切换目录时，把下面的示例路径替换为公司电脑上的真实解压路径：

```powershell
Set-Location -LiteralPath 'C:\Work\Project Trident Integrated'
```

## 2. 确认 Python

推荐 **Python 3.12、64-bit（Windows AMD64）**，对应本项目当前验证基准。本机核实的解释器为 Python 3.12.14；不要求 patch version 必须完全相同，但更换环境后要完成下面的验证。

```powershell
py -3.12 --version
py -3.12 -c "import sys, struct; print(sys.executable); print('Architecture:', struct.calcsize('P') * 8, 'bit')"
```

预期显示 Python `3.12.x` 和 `64 bit`。如果没有已批准的 Python 3.12 安装，请由公司软件中心或 IT 提供。

如果 `py` 不存在，但已安装的 `python` 确实是 Python 3.12、64-bit，可以改用：

```powershell
python --version
python -c "import sys, struct; print(sys.executable); print('Architecture:', struct.calcsize('P') * 8, 'bit')"
python -m venv .venv
```

也可以使用 IT 提供的解释器绝对路径；PowerShell 对带空格的可执行路径使用 `&`：

```powershell
& 'C:\CompanyPython\Python312\python.exe' -m venv .venv
```

**注意版本区别。** 源码声明支持 Python >=3.11，但当前固定的 `scipy==1.18.1` 的 package metadata 要求 Python >=3.12。Python 3.11 不能直接使用下面这套固定版本安装命令。如果公司只能提供 3.11，使用文末的兼容环境分支，不要强行安装不兼容的 wheel。

## 3. 创建项目自己的环境

确认当前目录是项目根目录，执行：

```powershell
py -3.12 -m venv .venv
.\.venv\Scripts\python.exe --version
.\.venv\Scripts\python.exe -m pip --version
```

该命令创建 `.venv` 文件夹，将模型的 packages 与其他项目隔离。正常的新环境不使用 `--system-site-packages`。迁移包没有旧 `.venv`；如果自行复制了旧环境，请先将它移出项目，再创建新环境。

**无需运行 `Activate.ps1`，也无需为了本流程修改 PowerShell execution policy。** 后续显式调用 `.venv\Scripts\python.exe`，确保安装和运行使用同一解释器。项目目录之后如果再次移动，要在最终位置重新创建环境。

## 4. 安装项目与主要 packages

公司允许通过 pip 使用 PyPI 或内部 package 源时，执行：

```powershell
.\.venv\Scripts\python.exe -m pip install -e ".[excel,optimization]" "openpyxl==3.1.5" "numpy==2.3.5" "scipy==1.18.1"
.\.venv\Scripts\python.exe -m pip check
```

成功时第一条显示安装完成；第二条通常显示 `No broken requirements found.`。

| 项目 | 当前核实版本 | 作用 |
|---|---|---|
| Python | 3.12.14、64-bit | 当前验证基准；安装建议选 3.12.x、64-bit |
| openpyxl | 3.1.5 | Excel 输入输出 |
| numpy | 2.3.5 | 优化数组与矩阵 |
| scipy | 1.18.1 | HiGHS LP / MILP 求解接口 |
| reportlab | 4.4.9 | 可选 PDF reporting；正常 Excel 运行不要求 |

`-e` 把当前目录里的 `trident` 项目安装到该环境，源码保留在 `src`，适合当前带源码的使用和 review。`[excel,optimization]` 选择 Excel 和优化依赖。三个 `==` 固定主要依赖到当前核实版本；间接依赖由 pip 自动解析。这不是整个 Python 环境的完整 lockfile。

只执行 `pip install -r requirements.txt` 会安装其中的外部依赖，但不会注册本项目本身；不能替代上面的项目安装命令。HiGHS 随当前 SciPy 接口使用，不要求另装 `highspy`；现有测试使用标准库 unittest，不要求 pytest。

安装项目时 pip 还需取得 `pyproject.toml` 指定的 `setuptools>=68` 构建依赖。公司内部 package 源也要能提供它。

如果需要生成支持的 PDF 报告，另执行：

```powershell
.\.venv\Scripts\python.exe -m pip install -e ".[reporting]" "reportlab==4.4.9"
.\.venv\Scripts\python.exe scripts/check_environment.py --profile reporting
```

阅读已有 PDF 不需要该包。重新生成中文流程图及 PNG 视觉检查属于另一个文档工具流程，涉及 Windows YaHei/Arial 字体及渲染工具，不是 Excel 模型的运行依赖。

## 5. 检查安装

```powershell
.\.venv\Scripts\python.exe scripts/check_environment.py --profile model
.\.venv\Scripts\python.exe -c "import sys, trident; print(sys.executable); print(trident.__version__); print(trident.__file__)"
```

第一条总体 `status` 应为 `PASS`，包含 Python/import、独立 EUR3 coupon 手算、Excel named-range 内存读写，以及 HiGHS LP/MILP 独立小例子的检查。第二条应显示公司电脑的项目 `.venv`、版本 `0.12.3` 和当前项目 `src\trident\__init__.py`，不应指向另一份项目。

环境 `PASS` 证明安装及小型计算可用，不等于完整模型或某笔真实交易已经审核通过。版本与验证基准不一致时会给出 warnings，应完成完整测试。

## 6. 测试与首次模型计算

首次安装或改变 Python / packages 后，运行完整回归：

```powershell
.\.venv\Scripts\python.exe -m unittest discover -s tests
```

应以本次实际结果为准；检查 failed / errors / skipped 的说明，不能以原电脑的 PASS 代替。

随后只读检查输入并计算已选择服务：

```powershell
.\.venv\Scripts\python.exe -m trident check-model outputs/Project_Trident.xlsx
.\.venv\Scripts\python.exe -m trident check-model outputs/Project_Trident.xlsx --project
```

第一条成功状态为 `INPUTS_VALIDATED`；第二条为 `CALCULATED`。两条均不写出工作簿。检查 warnings、CLO status 和 unavailable / breached limits；计算成功不表示所有 limits 都通过。示例资产和 TEST factor 是明确的研究输入；替换为真实数据后还需核实单位、来源、日期和身份。

保存并关闭 `outputs/Project_Trident.xlsx`，双击根目录 `Run_Model.cmd`。它优先使用本项目 `.venv`，显示所选 Python 和阶段进度，计算成功后显示 `SUCCESS`，窗口保留供查看。

也可以在 PowerShell 中直接运行：

```powershell
.\.venv\Scripts\python.exe -m trident workbook outputs/Project_Trident.xlsx
```

在全部所选服务完成后，模型验证并原子更新结果；失败保留上一份完整工作簿。重新打开 Excel，查看 Home 的运行时间、Checks、CLO Analysis 和每期 Waterfall，检查下拉框和图表；正常打开、保存、关闭并重开应没有修复提示。新电脑先用同一输入核对迁移前后的 IRR 和主要现金流。

## 7. 公司电脑不能联网安装时

优先使用公司内部 package 源，按 IT 提供的 pip 配置安装。若必须完全离线，迁移 ZIP 本身并不够：还需要适配目标电脑的 wheel 安装包和构建依赖。

在能够取得批准 packages、且同样使用 **Windows AMD64 / Python 3.12** 的电脑上准备 `wheelhouse`：

```powershell
py -3.12 -m pip download --only-binary=:all: --dest .\wheelhouse "openpyxl==3.1.5" "numpy==2.3.5" "scipy==1.18.1" "setuptools==84.0.0"
```

该命令同时取得依赖，例如 `et-xmlfile`。Python 3.12 新建 venv 不自带 setuptools，因此不能遗漏它。使用上面的 setuptools 84 后端，这个项目不要求额外的 wheel package。

将 `wheelhouse` 按公司允许的方式传输，并放在解压项目根目录下。公司电脑先执行第 1–3 步，再执行：

```powershell
.\.venv\Scripts\python.exe -m pip install --no-index --find-links .\wheelhouse -e ".[excel,optimization]" "openpyxl==3.1.5" "numpy==2.3.5" "scipy==1.18.1"
.\.venv\Scripts\python.exe -m pip check
.\.venv\Scripts\python.exe scripts/check_environment.py --profile model
```

继续第 6 步的测试和运行。保留 pip 默认 build isolation；本地包目录也用于安装隔离构建环境的依赖。若提示缺少 setuptools，先补全 wheelhouse，不以关闭 isolation 绕过准备工作。

SciPy/NumPy wheels 可能超过单封邮件允许的附件容量，应由 IT 提供内部软件源或安排合规的分批传输；本项目约 8 MB 的迁移 ZIP 不包含这些 wheels。不要将来自其他 Python minor version、OS 或架构的 wheel 当成兼容包。若下载电脑不同于目标电脑，应由安装人员明确指定 `--platform win_amd64 --python-version 3.12 --implementation cp --abi cp312` 并核对完整依赖。

## 8. VS Code 设置（可选）

1. 打开解压项目中的 `Project Trident Integrated.code-workspace`。
2. 如公司允许，安装 Microsoft 的 Python 扩展。
3. 按 `Ctrl+Shift+P`，运行 `Python: Select Interpreter`。
4. 选择当前项目 `.venv\Scripts\python.exe`；未列出时选择输入 interpreter path。
5. 在 Terminal 中确认 `Get-Location` 指向项目根目录，并继续使用本文的显式 `.venv` 命令。

Workspace 使用相对项目目录和 `.venv` 路径，不需要保留源电脑用户名或路径。VS Code 不会替代 Python/packages 安装；只使用 Excel 和 launcher 时无需 VS Code。

## 9. 常见错误

| 现象 | 检查与处理 |
|---|---|
| `py` 无法识别或找不到 3.12 | 确认 IT 已提供 Python 3.12；可使用已确认版本的 `python` 或解释器绝对路径 |
| `pyproject.toml` 找不到 | 进入含根目录文件的那一层，而非外层解压文件夹 |
| `No module named trident` | 在项目根目录，用同一 `.venv` 解释器执行项目安装命令 |
| 缺少 openpyxl / numpy / scipy | 用 `.venv\Scripts\python.exe -m pip` 安装所需 extras，避免装到其他环境 |
| 固定 SciPy 版本无法安装 | 确认 Python 3.12、64-bit 和内部软件源版本；SciPy 1.18.1 不支持 3.11 |
| timeout、proxy 或 certificate 错误 | 使用 IT 批准的内部源、代理或 CA 配置；完全离线时按第 7 步准备 wheels |
| 双击 launcher 没有窗口 | 在项目根目录运行 `cmd /c Run_Model.cmd` 查看启动消息，或直接运行 Python workbook 命令 |
| 文件占用或 permission error | 保存关闭 Excel，确认目标项目目录可写；保留具体错误以区分文件锁和目录权限 |
| selector 不切换、图表没刷新 | 使用桌面 Excel，确认允许正常公式重算；selector 只筛选已保存结果，不启动新的金融计算 |

## 10. 公司只能使用其他 Python 版本

如果只能使用 **Python 3.11、64-bit**，可以在新 `.venv` 中执行兼容范围安装，由 pip 根据 package metadata 选择可用版本：

```powershell
py -3.11 -m venv .venv
.\.venv\Scripts\python.exe -m pip install -e ".[excel,optimization]"
```

这不是当前固定依赖组合；必须重新进行环境检查、完整测试及相同输入对账。离线 wheels 也要重新按目标 Python 版本准备，不能复用上面的 cp312 包。Python 低于 3.11 不在源码支持范围内；其他较新解释器也不等于当前环境已经验证。

## 日常操作与参考

日常只需：编辑 owning inputs → 保存关闭 Excel → 运行 `Run_Model.cmd` → 看到 SUCCESS 后重开 Excel → 查看 Checks、CLO Analysis 和 Waterfall。已有结果的下拉框只做显示切换。

- [用户指南](user_guide.md)：输入位置、单位和输出阅读。
- [使用边界](readiness.md)：模型及真实交易适用范围。
- [环境检查脚本](../scripts/check_environment.py)：已实现的安装检查。
- [当前回归记录](validation/current.json)：对应代码/输入快照的回归证据；新电脑仍需重新验证。
- [Python venv 官方说明](https://docs.python.org/3.12/library/venv.html)：环境隔离、直接调用解释器及移动后的重建。
- [pip 本地项目安装](https://pip.pypa.io/en/stable/topics/local-project-installs/)：editable 安装含义。
- [pip 离线安装](https://pip.pypa.io/en/stable/user_guide/#installing-from-local-packages)：下载、find-links 和 no-index。
- [VS Code Python 环境](https://code.visualstudio.com/docs/python/environments)：解释器选择。
