"""Dated quality and candidate replay follow native contractual coupon steps.

Small par-only fixtures separate current quoted WAS/WAC from weighted coupon
receipts. Explicit expected margins/rates and hand coupon totals catch stale
opening metadata without treating a second projection as a correctness oracle.
"""

from dataclasses import replace
from datetime import date
from decimal import Decimal
import unittest
from unittest.mock import patch

from trident.analysis import AssetExposure, LimitDirection, LimitSpec, LimitStatus, MetricStatus
from trident.application.clo_services import TridentModelRequest, TridentModelService
from trident.application.construction import ClosingPoolRedesignService, ConstructionStatus, _resize_position
from trident.application.coupon_timeline import CouponTimeline
from trident.application.imported_cashflows import (
    CollateralCashflowInputMode, DetailedImportedCashflow, compile_imported_cashflows,
)
from trident.application.portfolio_snapshots import build_portfolio_snapshots
from trident.application.services import CashflowRunRequest
from trident.cashflows.coupons import CouponProjector
from trident.clo.models import CloTerms, DefaultedAssetOcTreatment, NoteTranche
from trident.clo.reinvestment import SyntheticReinvestmentLedger, SyntheticReinvestmentPolicy
from trident.conventions import AccrualDateBasis, BusinessDayConvention, DayCount
from trident.credit.overlay import OriginalPoolOverlay
from trident.credit.models import PrepaymentEvent
from trident.domain.models import CouponStep, CouponStepPolicy, CouponType, LoanPosition, LoanTerms
from trident.funding import AssetPurchase, DebtIssue
from trident.market import FlatRateProvider
from trident.optimization.universe import CandidateUniverseValidator

from test_construction import CLOSE, FIRST, SECOND, fixture, replace_candidate


D = Decimal
START, END = date(2026, 1, 20), date(2027, 1, 20)
FEB, MARCH, APRIL = date(2026, 2, 20), date(2026, 3, 20), date(2026, 4, 20)


def model_request(*, floating=True, policy=CouponStepPolicy.ACTUAL_DATE,
                  step_date=date(2026, 2, 1), stepped=True):
    """One native bullet; monthly monitoring observes quarterly entitlement."""
    steps = ((CouponStep(step_date, spread_bps=D(200)) if floating else
              CouponStep(step_date, fixed_rate=D(".06"))),) if stepped else ()
    loan = LoanTerms("L", "EUR", START, END, D(10000),
        CouponType.FLOATING if floating else CouponType.FIXED,
        fixed_rate=None if floating else D(".04"),
        rate_index="EURIBOR_3M" if floating else None,
        spread_bps=D(500) if floating else D(0), day_count=DayCount.ACT_360,
        business_day_convention=BusinessDayConvention.UNADJUSTED,
        accrual_date_basis=AccrualDateBasis.UNADJUSTED,
        coupon_steps=steps, coupon_step_policy=policy)
    position = LoanPosition(loan, START, D(10000))
    exposure = AssetExposure("L", "O", "BSL", "TERM_LOAN", "FR", "S", "EUR", D(10000),
        D(500) if floating else None, END, coupon_type=loan.coupon_type,
        fixed_coupon_rate=None if floating else loan.fixed_rate)
    cash = CashflowRunRequest((position,), (AssetPurchase("L", D(10000), D(100)),),
        (DebtIssue("A", D(8000), D(100)),), FlatRateProvider({"EURIBOR_3M": D(0)}),
        D(0), D(0), "HAND_TEST_FLAT")
    terms = CloTerms(START, END, frequency_months=1,
        business_day_convention=BusinessDayConvention.UNADJUSTED,
        accrual_date_basis=AccrualDateBasis.UNADJUSTED)
    return TridentModelRequest(cash, (exposure,), clo_terms=terms,
        notes=(NoteTranche("A", 1, D(8000), CouponType.FIXED, fixed_rate=D(0)),))


class DatedCouponSnapshotTests(unittest.TestCase):
    def test_current_was_is_raw_dated_margin_not_weighted_full_payment_coupon(self):
        result = TridentModelService().run(model_request())
        self.assertEqual(result.opening_portfolio.metric("WAS_BPS").value, D(500))
        # Jan20-Feb1 has12days at5%; Feb1-Apr20 has78days at2%.
        # 10000*(.05*12+.02*78)/360 =60.00; summary rate2.4% is
        # distinct from February's current raw200bps quoted margin.
        first = result.cashflows.cashflows[0]
        self.assertEqual(first.cash_interest, D(60))
        self.assertEqual(first.all_in_rate, D(".024"))
        self.assertEqual(result.portfolio_snapshots[0].as_of_date, FEB)
        self.assertEqual(result.portfolio_snapshots[0].metric("WAS_BPS").value, D(200))
        self.assertEqual(result.portfolio_snapshots[-1].total_par, D(0))

    def test_actual_date_equality_immediately_changes_snapshot_margin(self):
        result = TridentModelService().run(model_request(step_date=FEB))
        self.assertEqual(result.portfolio_snapshots[0].metric("WAS_BPS").value, D(200))

    def test_reset_start_defers_was_until_original_reset_boundary(self):
        result = TridentModelService().run(model_request(policy=CouponStepPolicy.RESET_START))
        self.assertEqual([row.metric("WAS_BPS").value for row in result.portfolio_snapshots[:3]],
                         [D(500), D(500), D(200)])
        self.assertEqual(result.cashflows.cashflows[0].cash_interest, D(125))

    def test_carried_semiannual_reset_controls_dated_was_across_quarter_payments(self):
        request = model_request(policy=CouponStepPolicy.RESET_START)
        position = request.cashflow_request.positions[0]
        position = replace(position, terms=replace(position.terms,
            rate_index="EURIBOR_6M", reset_frequency_months=6))
        cash = replace(request.cashflow_request, positions=(position,),
                       rate_provider=FlatRateProvider({"EURIBOR_6M": D(0)}))
        result = TridentModelService().run(replace(request, cashflow_request=cash))
        self.assertEqual([row.metric("WAS_BPS").value for row in result.portfolio_snapshots[:6]],
                         [D(500)] * 5 + [D(200)])
        self.assertEqual([row.cash_interest for row in result.cashflows.cashflows[:2]],
                         [D(125), D("126.39")])

    def test_actual_and_payment_start_fixed_wac_keep_distinct_timing(self):
        for policy, values in ((CouponStepPolicy.ACTUAL_DATE, [D(".06")] * 3),
                (CouponStepPolicy.PAYMENT_START, [D(".04"), D(".04"), D(".06")])):
            with self.subTest(policy=policy):
                result = TridentModelService().run(model_request(floating=False, policy=policy))
                self.assertEqual(result.opening_portfolio.metric("WAC_RATE").value, D(".04"))
                self.assertEqual([row.metric("WAC_RATE").value for row in result.portfolio_snapshots[:3]], values)
                self.assertIs(result.portfolio_snapshots[0].metric("WAS_BPS").status, MetricStatus.UNAVAILABLE)

    def test_dated_minimum_was_limit_detects_breach_after_opening_pass(self):
        request = model_request()
        limit = LimitSpec("WAS", "WAS_BPS", D(400), LimitDirection.MINIMUM)
        result = TridentModelService().run(replace(request, limits=(limit,)))
        self.assertIs(result.opening_portfolio.limits[0].status, LimitStatus.PASS)
        self.assertIs(result.portfolio_snapshots[0].limits[0].status, LimitStatus.BREACH)

    def test_mixed_native_pool_uses_separate_dated_was_and_wac_denominators(self):
        request = model_request()
        floating = request.cashflow_request.positions[0]
        constant = replace(floating, terms=replace(floating.terms, loan_id="C",
            reference_principal=D(5000), spread_bps=D(800), coupon_steps=()), opening_balance=D(5000))
        fixed = model_request(floating=False).cashflow_request.positions[0]
        fixed = replace(fixed, terms=replace(fixed.terms, loan_id="F", reference_principal=D(4000)),
                        opening_balance=D(4000))
        cash = replace(request.cashflow_request, positions=(floating, constant, fixed),
            purchases=(AssetPurchase("L", D(10000), D(100)), AssetPurchase("C", D(5000), D(100)),
                       AssetPurchase("F", D(4000), D(100))))
        exposures = (request.exposures[0], replace(request.exposures[0], loan_id="C", par=D(5000), spread_bps=D(800)),
                     replace(model_request(floating=False).exposures[0], loan_id="F", par=D(4000)))
        result = TridentModelService().run(replace(request, cashflow_request=cash, exposures=exposures))
        snapshot = result.portfolio_snapshots[0]
        self.assertEqual(snapshot.total_par, D(19000))
        # WAS uses only15000floating par; WAC uses only4000fixed par.
        self.assertEqual(snapshot.metric("WAS_BPS").value, D(400))
        self.assertEqual(snapshot.metric("WAC_RATE").value, D(".06"))
        # Full prepayment removes the lower-margin stepped asset before March
        # monitoring; surviving WAS is the constant800bps facility's margin.
        credit = TridentModelService().run(replace(request, cashflow_request=cash, exposures=exposures,
                                                   credit_events=(PrepaymentEvent("L", MARCH),)))
        self.assertEqual(credit.portfolio_snapshots[1].metric("WAS_BPS").value, D(800))
        self.assertEqual(credit.portfolio_snapshots[1].metric("WAC_RATE").value, D(".06"))

    def test_original_overlay_snapshot_uses_dated_margin_for_surviving_slice(self):
        request = model_request()
        terms = replace(request.clo_terms,
            defaulted_asset_oc_treatment=DefaultedAssetOcTreatment.EXCLUDE,
            original_pool_overlay=OriginalPoolOverlay(True, D(".2"), D(0), D(0), 0))
        result = TridentModelService().run(replace(request, clo_terms=terms))
        self.assertIsNotNone(result.clo.original_overlay_projection)
        # Fractional credit is posted at the loan's quarterly entitlement
        # boundary, so the first surviving-par reduction is April20.
        self.assertLess(result.portfolio_snapshots[2].total_par, D(10000))
        self.assertEqual(result.portfolio_snapshots[0].metric("WAS_BPS").value, D(200))
        self.assertEqual([row.total_par for row in result.portfolio_snapshots],
                         [row.closing_collateral_par for row in result.clo.periods])

    def test_synthetic_cohort_keeps_own_margin_while_original_step_changes(self):
        request = model_request()
        result = TridentModelService().run(request)
        policy = SyntheticReinvestmentPolicy(True, APRIL, spread_bps=D(600), purchase_price=D(1),
            annual_default_rate=D(0), annual_prepayment_rate=D(0))
        cohort = SyntheticReinvestmentLedger(policy, request.cashflow_request.rate_provider).purchase(FEB, D(10000))
        period = replace(result.clo.periods[0], closing_collateral_par=D(20000),
            reinvestment_par_acquired=D(10000), reinvestment_cash_used=D(10000))
        clo = replace(result.clo, periods=(period,), reinvestment_purchases=(cohort,),
                      reinvestment_par_movements=())
        snapshot = build_portfolio_snapshots(request.exposures, result.cashflows.cashflows, clo,
            reinvestment_policy=policy, coupon_timeline=CouponTimeline(request.cashflow_request.positions))[0]
        # Equal original par at200bps and synthetic par at600bps ->400bps.
        self.assertEqual(snapshot.metric("WAS_BPS").value, D(400))

    def test_imported_source_does_not_inherit_dormant_native_steps(self):
        request = model_request()
        source = compile_imported_cashflows(CollateralCashflowInputMode.DETAILED, START, D(10000),
            detailed_rows=(DetailedImportedCashflow("L", 1, APRIL, D(10000), D(100), D(0), D(10000), D(100)),
                DetailedImportedCashflow("L", 2, END, D(10000), D(100), D(10000), D(0), D(10100))))
        result = TridentModelService().run(replace(request, imported_collateral=source))
        self.assertIs(result.opening_portfolio.metric("WAS_BPS").status, MetricStatus.UNAVAILABLE)
        self.assertIs(result.portfolio_snapshots[0].metric("WAS_BPS").status, MetricStatus.UNAVAILABLE)

    def test_timeline_builds_stepped_schedule_once_and_queries_no_rates(self):
        stepped = model_request().cashflow_request.positions[0]
        constant = replace(model_request(stepped=False).cashflow_request.positions[0],
                           terms=replace(model_request(stepped=False).cashflow_request.positions[0].terms, loan_id="C"))
        with patch.object(CouponProjector, "for_terms", wraps=CouponProjector.for_terms) as build:
            timeline = CouponTimeline((stepped, constant))
            first = timeline.at(model_request().exposures, FEB)
            second = timeline.at(model_request().exposures, MARCH)
        self.assertEqual(build.call_count, 1)
        self.assertEqual(first[0].spread_bps, D(200))
        self.assertEqual(second[0].spread_bps, D(200))

    def test_opening_exposure_must_not_use_future_step_value(self):
        request = model_request()
        with self.assertRaisesRegex(ValueError, "maturity/spread"):
            TridentModelService().run(replace(request, exposures=(replace(request.exposures[0], spread_bps=D(200)),)))


class DatedCandidateReplayTests(unittest.TestCase):
    @staticmethod
    def stepped_redesign(*, limits=()):
        request = fixture(old_maturity=SECOND, new_maturity=SECOND, limits=limits)
        candidate = next(row for row in request.candidate_snapshot.candidates if row.asset_id == "NEW")
        position = replace(candidate.position, terms=replace(candidate.position.terms,
            coupon_steps=(CouponStep(date(2026, 2, 20), spread_bps=D(200)),)))
        return replace_candidate(request, "NEW", position=position)

    def test_admission_and_resizing_retain_complete_dated_contract(self):
        request = self.stepped_redesign()
        admission = CandidateUniverseValidator().validate(request.candidate_snapshot, request.admission_policy)
        self.assertFalse(admission.quarantined)
        new = next(row for row in admission.admitted if row.asset_id == "NEW")
        self.assertEqual(new.asset.spread_bps, D(800))
        self.assertEqual(_resize_position(new.position, D(5000)).terms.coupon_steps, new.position.terms.coupon_steps)
        result = ClosingPoolRedesignService().run(request)
        self.assertTrue(result.validated, result.findings)
        self.assertEqual(result.optimization.spread_bps, D(800))
        self.assertEqual(result.target_request.cashflow_request.positions[0].terms.coupon_steps,
                         new.position.terms.coupon_steps)
        self.assertEqual(result.target_result.opening_portfolio.metric("WAS_BPS").value, D(800))
        self.assertEqual(result.target_result.portfolio_snapshots[0].metric("WAS_BPS").value, D(200))
        # 31days8% +59days2%, then91days2%, posted once per payment.
        self.assertEqual(result.target_result.cashflows.total_interest, D("152.23"))

    def test_static_proxy_pass_does_not_hide_dated_full_replay_limit_breach(self):
        limit = LimitSpec("MIN_WAS", "WAS_BPS", D(400), LimitDirection.MINIMUM)
        result = ClosingPoolRedesignService().run(self.stepped_redesign(limits=(limit,)))
        self.assertTrue(result.optimization.validated)
        self.assertIs(result.target_result.opening_portfolio.limits[0].status, LimitStatus.PASS)
        self.assertEqual(result.status, ConstructionStatus.REPLAY_REJECTED)
        self.assertTrue(any(row.code == "PORTFOLIO_LIMIT_BREACH" and row.source == "TARGET"
                            and row.payment_date == FIRST for row in result.findings))

    def test_admission_rejects_future_margin_as_opening_descriptor(self):
        request = self.stepped_redesign()
        new = next(row for row in request.candidate_snapshot.candidates if row.asset_id == "NEW")
        request = replace_candidate(request, "NEW", asset=replace(new.asset, spread_bps=D(200)))
        result = CandidateUniverseValidator().validate(request.candidate_snapshot, request.admission_policy)
        reasons = next(row.reasons for row in result.quarantined if row.asset_id == "NEW")
        self.assertTrue(any("Static spread_bps differs" in reason for reason in reasons))


if __name__ == "__main__":
    unittest.main()
