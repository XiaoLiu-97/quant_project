"""Composable cash-pay principal policies, independent of rates and Excel.

Amounts are currency units. Nominal accrual ends identify principal dates.
Annuity is a *projected* end-period level-payment policy, not a contractual
floating-rate recast convention. Its exact varying-factor extension follows
the balance recurrence and reduces to the standard PMT formula at equal rates:
https://support.microsoft.com/en-us/Excel/functions/pmt-function
"""

from dataclasses import dataclass
from decimal import Decimal
from fractions import Fraction
from typing import Protocol

from trident.conventions.schedule import AccrualPeriod
from trident.domain.models import AmortizationType, InputValidationError, LoanPosition, require_decimal, require_money
from trident.domain.numeric import post_currency


class PrincipalPolicy(Protocol):
    """Return one cent principal posting, never implicitly capitalize interest."""

    def repayment(self, period_index: int, balance: Decimal, cash_interest: Decimal) -> Decimal:
        """Calculate principal using a zero-based schedule index and posted cash."""
        ...


def projected_level_payment(
    opening_balance: Decimal,
    period_factors: tuple[Fraction, ...],
    balloon_amount: Decimal,
) -> Fraction:
    """Exact O(n) projected P&I payment with a final extra balloon.

    For ``q_t = annual_rate_t * DCF_t``, ``d_t = product(1+q_i)^(-1)``:
    ``P = (opening_balance - balloon_amount*d_n) / sum(d_t)``.
    The balloon is the unrounded residual *after* the last level payment; it is
    additionally settled at maturity. Grace-period interest is paid separately.
    This does not infer an original loan amount or capitalize unpaid interest.
    """
    require_money(opening_balance, "annuity opening_balance", positive=True)
    require_money(balloon_amount, "annuity balloon_amount")
    if balloon_amount > opening_balance:
        raise InputValidationError("Annuity balloon cannot exceed held opening_balance")
    if type(period_factors) is not tuple or not period_factors:
        raise InputValidationError("Annuity requires at least one explicit accrual factor")
    discount = Fraction(1)
    discount_sum = Fraction()
    for factor in period_factors:
        if not isinstance(factor, Fraction) or 1 + factor <= 0:
            raise InputValidationError("Annuity requires exact factors with 1 + rate * DCF > 0")
        discount /= 1 + factor
        discount_sum += discount
    payment = (Fraction(opening_balance) - Fraction(balloon_amount) * discount) / discount_sum
    # Independently enforce the economic cash-pay boundary on the exact path.
    balance = Fraction(opening_balance)
    for factor in period_factors:
        principal = payment - balance * factor
        if principal < 0:
            raise InputValidationError("Projected annuity would cause negative amortization; capitalization is unsupported")
        balance -= principal
        if balance < Fraction(balloon_amount):
            raise InputValidationError("Projected annuity would invade its explicit balloon balance")
    if balance != Fraction(balloon_amount):
        raise ArithmeticError("Exact annuity residual failed to equal its target")
    return payment


@dataclass(frozen=True)
class BulletPrincipalPolicy:
    """Repay all remaining held face only at the contractual final period."""

    final_index: int

    def repayment(self, period_index: int, balance: Decimal, cash_interest: Decimal) -> Decimal:
        """Return no interim principal; the final period settles remaining face."""
        return balance if period_index == self.final_index else Decimal(0)


@dataclass(frozen=True)
class ScheduledPrincipalPolicy:
    """Explicit fixed/accelerating instalments, optionally protecting a balloon.

    Without an explicit balloon the final remaining principal is settled.
    An explicit balloon is a pre-maturity minimum residual floor, as in the
    source generator. It is not a promise that regular installments reach that
    exact residual. Final maturity redeems all remaining face, including any
    under-amortized residual. Automatic/annuity target balloons are different.
    """

    amounts: tuple[Decimal, ...]
    balloon_amount: Decimal | None

    def repayment(self, period_index: int, balance: Decimal, cash_interest: Decimal) -> Decimal:
        """Apply the compiled instalment without invading an explicit balloon."""
        scheduled = self.amounts[period_index]
        if period_index == len(self.amounts) - 1:
            return balance
        available = Fraction(balance) - Fraction(self.balloon_amount or 0)
        if available < 0:
            raise InputValidationError("Posted principal invaded the explicit balloon balance")
        return min(scheduled, post_currency(available))


@dataclass(frozen=True)
class CalibratedPrincipalPolicy:
    """Rounded calibrated instalments with an explicit final residual payment.

    Calibration uses held opening face, never an inferred historical loan size.
    Regular instalments post individually to cents and cannot invade balloon.
    Maturity pays remaining regular face plus balloon, absorbing rounding drift.
    An unintended early full retirement from coarse cent rounding is rejected;
    the caller must supply an explicit schedule for that contractual outcome.
    """

    amounts: tuple[Decimal, ...]
    balloon_amount: Decimal

    def repayment(self, period_index: int, balance: Decimal, cash_interest: Decimal) -> Decimal:
        """Coupon is paid separately; automatic calibration targets principal."""
        if period_index == len(self.amounts) - 1:
            return balance
        available = Fraction(balance) - Fraction(self.balloon_amount)
        if available < 0:
            raise ArithmeticError("Calibrated principal invaded its balloon")
        amount = min(self.amounts[period_index], post_currency(available))
        if amount == balance:
            raise InputValidationError("Cent-posted calibrated schedule would retire before contractual maturity; use BESPOKE")
        return amount


def calibrated_principal_amounts(
    opening_balance: Decimal, balloon_amount: Decimal, count: int,
    growth: Decimal = Decimal(0),
) -> tuple[Decimal, ...]:
    """Calibrate equal or geometric regular principal in exact rational units.

    For n eligible payments and multiplier m=1+growth, the first unrounded
    instalment is (held face - balloon) / (1 + m + ... + m**(n-1)). No coupon
    projection or root search is necessary. This is a modeling instruction,
    not evidence that a contract permits recomputing its instalments at as-of.
    The final cash posting is reconciled by CalibratedPrincipalPolicy.

    A disclosed bit budget prevents pathological growth/tenor inputs from
    allocating enormous exact integers. We reject them rather than silently
    approximating the financial schedule or depending on Decimal context.
    """
    require_money(opening_balance, "calibration opening_balance", positive=True)
    require_money(balloon_amount, "calibration balloon_amount")
    require_decimal(growth, "calibration growth", minimum=Decimal(0))
    if balloon_amount > opening_balance or type(count) is not int or count <= 0:
        raise InputValidationError("Calibration needs a positive payment count and balloon <= held face")
    multiplier = 1 + Fraction(growth)
    if multiplier == 1:
        weights = Fraction(count)
    else:
        if count * max(multiplier.numerator.bit_length(), multiplier.denominator.bit_length()) > 500_000:
            raise InputValidationError("Exact calibration exceeds the supported 500000-bit numeric budget")
        weights = (multiplier ** count - 1) / (multiplier - 1)
    amount = (Fraction(opening_balance) - Fraction(balloon_amount)) / weights
    result = []
    for _ in range(count):
        result.append(post_currency(amount))
        amount *= multiplier
    return tuple(result)


@dataclass(frozen=True)
class BespokePrincipalPolicy:
    """Pay exactly the immutable supplied principal amounts, without a sweep."""

    amounts: tuple[Decimal, ...]
    balloon_amount: Decimal | None = None

    def repayment(self, period_index: int, balance: Decimal, cash_interest: Decimal) -> Decimal:
        """Return the supplied posting; an excess cannot silently be capped."""
        amount = self.amounts[period_index]
        if amount > balance:
            raise InputValidationError("BESPOKE principal exceeds outstanding held par")
        if (period_index != len(self.amounts) - 1 and self.balloon_amount is not None
                and Fraction(balance) - Fraction(amount) < Fraction(self.balloon_amount)):
            raise InputValidationError("BESPOKE supplied principal invades the explicit pre-maturity balloon floor")
        return amount


@dataclass(frozen=True)
class AnnuityPrincipalPolicy:
    """Level posted P&I before maturity; final cash absorbs rounding drift.

    Each nonfinal principal is posted payment minus posted interest on posted
    opening par. A final principal sweep settles regular principal, the explicit
    balloon and cent rounding adjustment. Negative posted principal and a
    pre-maturity balloon invasion are rejected, never silently capitalized.
    """

    eligible: tuple[bool, ...]
    posted_payment: Decimal
    balloon_amount: Decimal

    def repayment(self, period_index: int, balance: Decimal, cash_interest: Decimal) -> Decimal:
        """Pay posted P&I less coupon, with final face and rounding settlement."""
        if not self.eligible[period_index]:
            return Decimal(0)
        principal = post_currency(Fraction(self.posted_payment) - Fraction(cash_interest))
        if principal < 0:
            raise InputValidationError("Cent-posted annuity would cause negative amortization")
        if period_index == len(self.eligible) - 1:
            return balance
        if Fraction(principal) > Fraction(balance) - Fraction(self.balloon_amount):
            raise InputValidationError("Cent-posted annuity would invade its explicit balloon before maturity")
        if principal == balance:
            raise InputValidationError("Cent-posted annuity would retire before contractual maturity; use an explicit principal schedule")
        return principal


def build_principal_policy(
    position: LoanPosition,
    periods: tuple[AccrualPeriod, ...],
    period_factors: tuple[Fraction, ...] | None = None,
) -> PrincipalPolicy:
    """Compile one principal strategy against the original nominal schedule.

    User principal dates must identify unadjusted accrual boundaries, even when
    cash moves on an adjusted business date. Grace eligibility is compiled once,
    as are bespoke/scheduled amounts. The held balance limits repayments; the
    reference principal supplies linear percentages and is not newly borrowed
    cash. Only annuity consumes future rate factors, preventing unnecessary
    fixing queries for a bullet or a schedule that repays early.
    """
    terms = position.terms
    if not periods:
        raise InputValidationError("A principal policy requires a nonempty schedule")
    boundaries = frozenset(period.unadjusted_end for period in periods)
    start = terms.amortization_start_date or terms.start_date
    if start != terms.start_date and start not in boundaries:
        raise InputValidationError("amortization_start_date must be an unadjusted accrual boundary")
    eligible = tuple(period.unadjusted_end >= start for period in periods)
    kind = terms.amortization_type
    if kind is AmortizationType.BULLET:
        return BulletPrincipalPolicy(len(periods) - 1)
    if kind is AmortizationType.BESPOKE:
        entries = {entry.payment_date: entry.amount for entry in terms.principal_schedule}
        if not entries.keys() <= boundaries:
            raise InputValidationError("BESPOKE dates must match unadjusted accrual boundaries")
        return BespokePrincipalPolicy(tuple(entries.get(period.unadjusted_end, Decimal(0)) for period in periods), terms.balloon_amount)
    if kind is AmortizationType.ANNUITY:
        if period_factors is None or len(period_factors) != len(periods):
            raise InputValidationError("ANNUITY requires a projected rate factor for every period")
        active_factors = tuple(factor for factor, active in zip(period_factors, eligible, strict=True) if active)
        payment = projected_level_payment(position.opening_balance, active_factors, terms.balloon_amount)
        return AnnuityPrincipalPolicy(eligible, post_currency(payment), terms.balloon_amount)
    if period_factors is not None:
        raise InputValidationError("Only ANNUITY consumes projected payment factors")
    if kind in (AmortizationType.LINEAR_AUTO, AmortizationType.ACCELERATED_AUTO):
        # Grace coupon periods are preserved but not counted as amortisation
        # instalments. The final nominal period remains part of calibration.
        active_amounts = iter(calibrated_principal_amounts(
            position.opening_balance, terms.balloon_amount, sum(eligible),
            terms.amortization_growth if kind is AmortizationType.ACCELERATED_AUTO else Decimal(0),
        ))
        return CalibratedPrincipalPolicy(
            tuple(next(active_amounts) if active else Decimal(0) for active in eligible),
            terms.balloon_amount,
        )
    scheduled = (
        Fraction(terms.reference_principal) * Fraction(terms.amortization_fraction)
        if kind is AmortizationType.LINEAR_INITIAL_PAR
        else Fraction(terms.scheduled_principal_amount)
    )
    multiplier = 1 + Fraction(terms.amortization_growth or 0)
    amounts: list[Decimal] = []
    for active in eligible:
        amounts.append(post_currency(scheduled) if active else Decimal(0))
        if active and kind is AmortizationType.ACCELERATED:
            # Repayment can never exceed reference par. Saturating the growth
            # avoids exponential integers after every possible balance is met.
            scheduled = min(Fraction(terms.reference_principal), scheduled * multiplier)
    return ScheduledPrincipalPolicy(tuple(amounts), terms.balloon_amount)
