"""Independent credit known answers and dated principal-conservation corners."""

import unittest
from dataclasses import FrozenInstanceError, replace
from datetime import date, datetime
from decimal import Decimal, Inexact, ROUND_DOWN, localcontext
from fractions import Fraction

from trident.cashflows.engine import ContractualCashflowEngine
from trident.conventions.calendar import BusinessDayConvention
from trident.conventions.day_count import DayCount
from trident.conventions.schedule import AccrualDateBasis
from trident.credit import (
    AssetCashSource, AssetCollection, AssetParMovement, CreditEventCashflowEngine,
    CreditProjectionStatus, DefaultEvent, PrepaymentEvent, RecoveryEvent,
)
from trident.domain.models import AmortizationType, CouponType, InputValidationError, LoanPosition, LoanTerms
from trident.market.rates import FlatRateProvider

D = Decimal


def held_loan(**changes: object) -> LoanPosition:
    """100 par, 40% coupon and exact 30E/360 quarterly coupons of 10."""
    fields = dict(
        loan_id="CREDIT_1", currency="EUR", start_date=date(2026, 1, 1),
        maturity_date=date(2026, 10, 1), reference_principal=D(100),
        coupon_type=CouponType.FIXED, fixed_rate=D("0.4"),
        day_count=DayCount.THIRTY_E_360,
        business_day_convention=BusinessDayConvention.UNADJUSTED,
        accrual_date_basis=AccrualDateBasis.UNADJUSTED,
        fixing_lag_business_days=0,
    )
    fields.update(changes)
    terms = LoanTerms(**fields)
    return LoanPosition(terms, terms.start_date, terms.reference_principal)


def amortizing_loan(**changes: object) -> LoanPosition:
    return held_loan(amortization_type=AmortizationType.LINEAR_AMOUNT,
                     scheduled_principal_amount=D(30), **changes)


class CreditEventKnownAnswerTests(unittest.TestCase):
    def setUp(self) -> None:
        self.provider = FlatRateProvider({"EURIBOR_3M": D("0.025")})
        self.engine = CreditEventCashflowEngine(self.provider)

    def test_no_event_is_identical_to_contractual_collections(self) -> None:
        position = amortizing_loan()
        contractual = ContractualCashflowEngine(self.provider).generate(position)
        result = self.engine.apply(position, contractual)
        self.assertIs(result.contractual_cashflows, contractual)
        self.assertEqual([r.cash_interest for r in result.collections], [D(10), D(7), D(4)])
        self.assertEqual([r.principal_collection for r in result.collections], [D(30), D(30), D(40)])
        self.assertEqual(result.total_scheduled_principal, D(100))
        self.assertEqual(result.total_cash_interest, D(21))
        self.assertEqual(result.final_performing_par, 0)
        self.assertEqual(result.final_defaulted_par, 0)
        self.assertEqual(result.total_par_loss, 0)
        self.assertIs(result.status, CreditProjectionStatus.REPAID)

    def test_midperiod_default_cancels_interest_and_repayment(self) -> None:
        event = DefaultEvent("CREDIT_1", date(2026, 2, 15), (
            RecoveryEvent(date(2026, 5, 15), D("0.6")),
        ), date(2026, 6, 15))
        result = self.engine.generate(held_loan(), event)
        self.assertEqual(result.total_cash_interest, 0)
        self.assertEqual(result.total_scheduled_principal, 0)
        self.assertEqual(result.defaulted_exposure, D(100))
        self.assertEqual(result.total_recovery_principal, D(60))
        self.assertEqual(result.total_par_loss, D(40))
        self.assertEqual(len(result.collections), 1)
        self.assertEqual(result.collections[0].payment_date, date(2026, 5, 15))
        self.assertEqual(result.final_performing_par, 0)
        self.assertEqual(result.final_defaulted_par, 0)
        self.assertIs(result.status, CreditProjectionStatus.DEFAULT_RESOLVED)
        # The reference retains all ORIGINAL contractual receivables; it is not
        # altered to pretend the recovery was a normal 60-par bullet repayment.
        self.assertEqual(result.contractual_cashflows[-1].principal_repayment, D(100))

    def test_default_exposure_is_after_actual_prior_amortization(self) -> None:
        event = DefaultEvent("CREDIT_1", date(2026, 5, 15), (
            RecoveryEvent(date(2026, 8, 15), D("0.6")),
        ), date(2026, 9, 15))
        result = self.engine.generate(amortizing_loan(), event)
        self.assertEqual(result.total_scheduled_principal, D(30))
        self.assertEqual(result.total_cash_interest, D(10))
        self.assertEqual(result.defaulted_exposure, D(70))
        self.assertEqual(result.total_recovery_principal, D(42))
        self.assertEqual(result.total_par_loss, D(28))
        self.assertEqual(result.total_principal_collections, D(72))

    def test_same_day_schedule_then_default_then_recovery_then_writeoff(self) -> None:
        same_day = date(2026, 4, 1)
        event = DefaultEvent("CREDIT_1", same_day, (RecoveryEvent(same_day, D("0.5")),), same_day)
        result = self.engine.generate(amortizing_loan(), event)
        self.assertEqual([row.source for row in result.par_movements], [
            AssetCashSource.SCHEDULED, AssetCashSource.DEFAULT,
            AssetCashSource.RECOVERY, AssetCashSource.WRITE_OFF,
        ])
        self.assertEqual(result.defaulted_exposure, D(70))
        self.assertEqual(result.total_scheduled_principal, D(30))
        self.assertEqual(result.total_recovery_principal, D(35))
        self.assertEqual(result.total_par_loss, D(35))
        self.assertEqual(result.total_cash_interest, D(10))

    def test_midperiod_prepayment_known_actual_day_coupon(self) -> None:
        position = held_loan(reference_principal=D(1000), fixed_rate=D("0.08"), day_count=DayCount.ACT_360)
        result = self.engine.generate(position, PrepaymentEvent("CREDIT_1", date(2026, 2, 15)))
        # Jan 1 to Feb 15 is 45 days. 1000 * .08 * 45/360 = 10 exactly.
        self.assertEqual(result.total_cash_interest, D(10))
        self.assertEqual(result.total_prepayment_principal, D(1000))
        self.assertEqual(result.collections[0].total_cash, D(1010))
        self.assertIs(result.status, CreditProjectionStatus.PREPAID)
        self.assertEqual(result.final_performing_par, 0)

    def test_prepay_after_amortization_accrues_remaining_par_only(self) -> None:
        result = self.engine.generate(amortizing_loan(), PrepaymentEvent("CREDIT_1", date(2026, 5, 15)))
        # Scheduled first coupon = 10, principal = 30. Apr 1--May 15 gives
        # 44 synthetic days: 70 * .4 * 44/360 = 3.42222..., posted 3.42.
        self.assertEqual(result.total_scheduled_principal, D(30))
        self.assertEqual(result.total_prepayment_principal, D(70))
        self.assertEqual(result.total_cash_interest, D("13.42"))
        self.assertEqual(result.collections[-1].cash_interest, D("3.42"))
        self.assertEqual(result.total_principal_collections, D(100))

    def test_same_day_scheduled_and_prepayment_do_not_double_count_coupon(self) -> None:
        result = self.engine.generate(amortizing_loan(), PrepaymentEvent("CREDIT_1", date(2026, 4, 1)))
        self.assertEqual([row.source for row in result.collections], [AssetCashSource.SCHEDULED, AssetCashSource.PREPAYMENT])
        self.assertEqual([row.principal_collection for row in result.collections], [D(30), D(70)])
        self.assertEqual([row.cash_interest for row in result.collections], [D(10), D(0)])
        self.assertEqual(result.total_cash_interest, D(10))

    def test_prepayment_uses_current_fixing_and_index_floor(self) -> None:
        class KnownRates:
            def rate(self, index: str, fixing_date: date) -> Decimal:
                return {date(2026, 1, 1): D("0.02"), date(2026, 4, 1): D("0.04")}[fixing_date]

        position = held_loan(
            reference_principal=D(1000), maturity_date=date(2026, 7, 1),
            coupon_type=CouponType.FLOATING, fixed_rate=None, rate_index="EURIBOR_3M",
            spread_bps=D(300), index_floor=D("0.025"), day_count=DayCount.ACT_360,
        )
        result = CreditEventCashflowEngine(KnownRates()).generate(position, PrepaymentEvent("CREDIT_1", date(2026, 3, 1)))
        # The Jan 1 fixing supplies max(.02,.025)+.03 = .055, not the later
        # .04 fixing. 59 actual days gives 9.013888..., posted 9.01.
        self.assertEqual(result.total_cash_interest, D("9.01"))
        self.assertEqual(result.contractual_cashflows[0].all_in_rate, D("0.055"))

    def test_recovery_installments_post_cumulative_fraction_targets(self) -> None:
        position = held_loan(reference_principal=D("0.02"), fixed_rate=D(0))
        event = DefaultEvent("CREDIT_1", date(2026, 2, 1), (
            RecoveryEvent(date(2026, 3, 1), D("0.2")),
            RecoveryEvent(date(2026, 4, 1), D("0.2")),
            RecoveryEvent(date(2026, 5, 1), D("0.6")),
        ))
        result = self.engine.generate(position, event)
        # Cumulative targets are .004 -> .00, .008 -> .01, .020 -> .02.
        # Independently rounding each recovery would instead produce .01 total.
        self.assertEqual([row.principal_collection for row in result.collections], [D(0), D("0.01"), D("0.01")])
        self.assertEqual(result.total_recovery_principal, D("0.02"))
        self.assertEqual(result.final_defaulted_par, 0)
        self.assertEqual(result.total_par_loss, 0)

    def test_half_cent_recovery_never_exceeds_original_claim(self) -> None:
        event = DefaultEvent("CREDIT_1", date(2026, 2, 1), (
            RecoveryEvent(date(2026, 3, 1), D("0.5")),
            RecoveryEvent(date(2026, 4, 1), D("0.5")),
        ))
        result = self.engine.generate(held_loan(reference_principal=D("0.01"), fixed_rate=D(0)), event)
        self.assertEqual([row.principal_collection for row in result.collections], [D("0.01"), D(0)])
        self.assertEqual(result.total_recovery_principal, D("0.01"))
        self.assertEqual(result.final_defaulted_par, 0)

    def test_explicit_zero_recovery_and_writeoff_recognizes_full_loss(self) -> None:
        event = DefaultEvent("CREDIT_1", date(2026, 2, 1), (), date(2026, 2, 1))
        result = self.engine.generate(held_loan(), event)
        self.assertEqual(result.collections, ())
        self.assertEqual(result.total_principal_collections, 0)
        self.assertEqual(result.total_par_loss, D(100))
        self.assertEqual(result.final_defaulted_par, 0)
        self.assertIs(result.status, CreditProjectionStatus.DEFAULT_RESOLVED)

    def test_zero_recovery_without_writeoff_remains_unresolved(self) -> None:
        event = DefaultEvent("CREDIT_1", date(2026, 2, 1), (RecoveryEvent(date(2026, 3, 1), D(0)),))
        result = self.engine.generate(held_loan(), event)
        self.assertEqual(result.collections[0].principal_collection, 0)
        self.assertEqual(result.final_defaulted_par, D(100))
        self.assertEqual(result.pending_recovery_amount, 0)
        self.assertEqual(result.total_par_loss, 0)
        self.assertIs(result.status, CreditProjectionStatus.DEFAULT_UNRESOLVED)

    def test_last_recovery_is_not_implicit_remaining_writeoff(self) -> None:
        event = DefaultEvent("CREDIT_1", date(2026, 2, 1), (RecoveryEvent(date(2026, 3, 1), D("0.6")),))
        result = self.engine.generate(held_loan(), event)
        self.assertEqual(result.total_recovery_principal, D(60))
        self.assertEqual(result.final_defaulted_par, D(40))
        self.assertEqual(result.total_par_loss, 0)
        self.assertIs(result.status, CreditProjectionStatus.DEFAULT_UNRESOLVED)

    def test_complete_recovery_resolves_without_writeoff(self) -> None:
        event = DefaultEvent("CREDIT_1", date(2026, 2, 1), (RecoveryEvent(date(2026, 3, 1), D(1)),))
        result = self.engine.generate(held_loan(), event)
        self.assertEqual(result.total_recovery_principal, D(100))
        self.assertEqual(result.final_defaulted_par, 0)
        self.assertEqual(result.total_par_loss, 0)
        self.assertIs(result.status, CreditProjectionStatus.DEFAULT_RESOLVED)

    def test_horizon_before_event_retains_current_performing_balance(self) -> None:
        event = DefaultEvent("CREDIT_1", date(2026, 5, 15), (RecoveryEvent(date(2026, 8, 15), D("0.6")),))
        result = self.engine.generate(amortizing_loan(), event, horizon_date=date(2026, 4, 10))
        self.assertFalse(result.credit_event_applied)
        self.assertEqual(result.total_scheduled_principal, D(30))
        self.assertEqual(result.final_performing_par, D(70))
        self.assertEqual(result.final_defaulted_par, 0)
        self.assertEqual(result.defaulted_exposure, 0)
        self.assertEqual(result.pending_recovery_amount, 0)
        self.assertIs(result.status, CreditProjectionStatus.PERFORMING)

    def test_horizon_after_default_retains_explicit_future_recovery(self) -> None:
        event = DefaultEvent("CREDIT_1", date(2026, 5, 15), (RecoveryEvent(date(2026, 8, 15), D("0.6")),), date(2026, 9, 15))
        result = self.engine.generate(amortizing_loan(), event, horizon_date=date(2026, 6, 1))
        self.assertTrue(result.credit_event_applied)
        self.assertEqual(result.final_performing_par, 0)
        self.assertEqual(result.final_defaulted_par, D(70))
        self.assertEqual(result.pending_recovery_amount, D(42))
        self.assertEqual(result.total_recovery_principal, 0)
        self.assertEqual(result.total_par_loss, 0)

    def test_horizon_between_recoveries_does_not_recognize_future_cash(self) -> None:
        event = DefaultEvent("CREDIT_1", date(2026, 5, 15), (
            RecoveryEvent(date(2026, 6, 15), D("0.25")),
            RecoveryEvent(date(2026, 8, 15), D("0.35")),
        ), date(2026, 9, 15))
        result = self.engine.generate(amortizing_loan(), event, horizon_date=date(2026, 7, 1))
        self.assertEqual(result.total_recovery_principal, D("17.50"))
        self.assertEqual(result.final_defaulted_par, D("52.50"))
        self.assertEqual(result.pending_recovery_amount, D("24.50"))
        self.assertEqual(result.total_par_loss, 0)

    def test_default_horizon_covers_recovery_after_contract_maturity(self) -> None:
        event = DefaultEvent("CREDIT_1", date(2026, 2, 1), (
            RecoveryEvent(date(2027, 2, 1), D("0.6")),
        ), date(2027, 3, 1))
        result = self.engine.generate(held_loan(), event)
        self.assertEqual(result.horizon_date, date(2027, 3, 1))
        self.assertEqual(result.pending_recovery_amount, 0)
        self.assertEqual(result.total_recovery_principal, D(60))
        self.assertEqual(result.total_par_loss, D(40))

    def test_noevent_short_horizon_and_start_horizon_are_explicit(self) -> None:
        result = self.engine.generate(amortizing_loan(), horizon_date=date(2026, 4, 1))
        self.assertEqual(result.total_scheduled_principal, D(30))
        self.assertEqual(result.final_performing_par, D(70))
        result = self.engine.generate(amortizing_loan(), horizon_date=date(2026, 1, 1))
        self.assertEqual(result.collections, ())
        self.assertEqual(result.final_performing_par, D(100))

    def test_caller_decimal_context_cannot_change_default_or_prepayment(self) -> None:
        with localcontext() as caller:
            caller.prec = 2
            caller.rounding = ROUND_DOWN
            caller.traps[Inexact] = True
            event = DefaultEvent("CREDIT_1", date(2026, 5, 15), (RecoveryEvent(date(2026, 8, 15), D("0.6")),), date(2026, 9, 15))
            result = self.engine.generate(amortizing_loan(), event)
            self.assertEqual(result.total_recovery_principal, D(42))
            self.assertEqual(result.total_par_loss, D(28))
            prepay = self.engine.generate(amortizing_loan(), PrepaymentEvent("CREDIT_1", date(2026, 5, 15)))
            self.assertEqual(prepay.total_cash_interest, D("13.42"))

    def test_negative_coupon_prepayment_remains_signed_cash(self) -> None:
        position = held_loan(reference_principal=D(1000), fixed_rate=D("-0.08"), day_count=DayCount.ACT_360)
        result = self.engine.generate(position, PrepaymentEvent("CREDIT_1", date(2026, 2, 15)))
        self.assertEqual(result.total_cash_interest, D(-10))
        self.assertEqual(result.total_prepayment_principal, D(1000))
        self.assertEqual(result.collections[0].total_cash, D(990))

    def test_bespoke_default_exposure_uses_actual_repayments(self) -> None:
        from trident.domain.models import PrincipalScheduleEntry
        position = held_loan(amortization_type=AmortizationType.BESPOKE, principal_schedule=(
            PrincipalScheduleEntry(date(2026, 4, 1), D("12.34")),
            PrincipalScheduleEntry(date(2026, 10, 1), D("87.66")),
        ))
        event = DefaultEvent("CREDIT_1", date(2026, 5, 15), (RecoveryEvent(date(2026, 8, 15), D("0.5")),), date(2026, 9, 15))
        result = self.engine.generate(position, event)
        self.assertEqual(result.defaulted_exposure, D("87.66"))
        self.assertEqual(result.total_recovery_principal, D("43.83"))
        self.assertEqual(result.total_par_loss, D("43.83"))


class CreditEventBoundaryTests(unittest.TestCase):
    def setUp(self) -> None:
        self.provider = FlatRateProvider({"EURIBOR_3M": D("0.025")})
        self.engine = CreditEventCashflowEngine(self.provider)

    def test_event_inputs_reject_invalid_types_and_fractions(self) -> None:
        invalid_recoveries = [
            (datetime(2026, 3, 1), D("0.5")),
            (date(2026, 3, 1), 0.5),
            (date(2026, 3, 1), D("NaN")),
            (date(2026, 3, 1), D("-0.1")),
            (date(2026, 3, 1), D("1.01")),
        ]
        for args in invalid_recoveries:
            with self.subTest(args=args), self.assertRaises(InputValidationError):
                RecoveryEvent(*args)
        with self.assertRaises(InputValidationError):
            PrepaymentEvent(" CREDIT_1", date(2026, 2, 1))
        with self.assertRaises(InputValidationError):
            DefaultEvent("CREDIT_1", datetime(2026, 2, 1))

    def test_recovery_schedule_cannot_precede_default_or_overrecover(self) -> None:
        schedules = [
            (RecoveryEvent(date(2026, 1, 15), D("0.5")),),
            (RecoveryEvent(date(2026, 3, 1), D("0.5")), RecoveryEvent(date(2026, 3, 1), D("0.5"))),
            (RecoveryEvent(date(2026, 4, 1), D("0.5")), RecoveryEvent(date(2026, 3, 1), D("0.5"))),
            (RecoveryEvent(date(2026, 3, 1), D("0.6")), RecoveryEvent(date(2026, 4, 1), D("0.40001"))),
        ]
        for recoveries in schedules:
            with self.subTest(recoveries=recoveries), self.assertRaises(InputValidationError):
                DefaultEvent("CREDIT_1", date(2026, 2, 1), recoveries)
        with self.assertRaises(InputValidationError):
            DefaultEvent("CREDIT_1", date(2026, 2, 1), [RecoveryEvent(date(2026, 3, 1), D("0.5"))])

    def test_writeoff_cannot_precede_default_or_future_recovery(self) -> None:
        with self.assertRaises(InputValidationError):
            DefaultEvent("CREDIT_1", date(2026, 2, 1), (), date(2026, 1, 31))
        with self.assertRaises(InputValidationError):
            DefaultEvent("CREDIT_1", date(2026, 2, 1), (RecoveryEvent(date(2026, 3, 1), D("0.5")),), date(2026, 2, 28))

    def test_opening_or_mismatched_event_is_rejected(self) -> None:
        events = [DefaultEvent("OTHER", date(2026, 2, 1)), DefaultEvent("CREDIT_1", date(2026, 1, 1)), PrepaymentEvent("CREDIT_1", date(2025, 12, 31))]
        for event in events:
            with self.subTest(event=event), self.assertRaises(InputValidationError):
                self.engine.generate(held_loan(), event)

    def test_event_on_or_after_full_payoff_is_rejected(self) -> None:
        position = held_loan(amortization_type=AmortizationType.LINEAR_AMOUNT, scheduled_principal_amount=D(50))
        for event in (DefaultEvent("CREDIT_1", date(2026, 7, 1)), PrepaymentEvent("CREDIT_1", date(2026, 8, 1))):
            with self.subTest(event=event), self.assertRaisesRegex(InputValidationError, "no remaining exposure"):
                self.engine.generate(position, event)
        with self.assertRaisesRegex(InputValidationError, "no remaining exposure"):
            self.engine.generate(held_loan(), DefaultEvent("CREDIT_1", date(2026, 10, 1)))

    def test_nonzero_payment_lag_rejects_credit_overlay(self) -> None:
        with self.assertRaisesRegex(InputValidationError, "zero contractual payment lag"):
            self.engine.generate(held_loan(payment_lag_business_days=2), DefaultEvent("CREDIT_1", date(2026, 2, 1)))

    def test_adjusted_cash_unadjusted_accrual_gap_prepay_rejects(self) -> None:
        position = held_loan(start_date=date(2026, 5, 1), maturity_date=date(2026, 8, 1),
                             business_day_convention=BusinessDayConvention.FOLLOWING)
        # Nominal maturity Saturday Aug 1; actual cash Monday Aug 3. A Sunday
        # prepay would require defining both unpaid old coupon and new accrual.
        with self.assertRaisesRegex(InputValidationError, "boundary gaps"):
            self.engine.generate(position, PrepaymentEvent("CREDIT_1", date(2026, 8, 2)))
        # Default is unambiguous: neither the unpaid coupon nor maturity par is
        # automatically received on the following day after the supplied default.
        result = self.engine.generate(position, DefaultEvent("CREDIT_1", date(2026, 8, 2), (), date(2026, 8, 2)))
        self.assertEqual(result.total_cash_interest, 0)
        self.assertEqual(result.total_par_loss, D(100))

    def test_invalid_future_prepay_is_not_hidden_by_early_horizon(self) -> None:
        position = held_loan(start_date=date(2026, 5, 1), maturity_date=date(2026, 8, 1),
                             business_day_convention=BusinessDayConvention.FOLLOWING)
        with self.assertRaisesRegex(InputValidationError, "boundary gaps"):
            self.engine.generate(position, PrepaymentEvent("CREDIT_1", date(2026, 8, 2)), horizon_date=date(2026, 6, 1))

    def test_horizon_date_type_and_range_are_validated(self) -> None:
        for horizon in (date(2025, 12, 31), datetime(2026, 3, 1)):
            with self.subTest(horizon=horizon), self.assertRaises(InputValidationError):
                self.engine.generate(held_loan(), horizon_date=horizon)

    def test_contractual_reference_must_be_complete_and_consistent(self) -> None:
        position = amortizing_loan()
        rows = ContractualCashflowEngine(self.provider).generate(position)
        invalid = [
            rows[:-1],
            [*rows],
            (replace(rows[0], loan_id="OTHER"), *rows[1:]),
            (replace(rows[0], closing_balance=D(71)), *rows[1:]),
            (replace(rows[0], total_cash=D(41)), *rows[1:]),
            (replace(rows[0], cash_interest=10.0), *rows[1:]),
            (replace(rows[0], period_number=True), *rows[1:]),
            (replace(rows[0], accrual_start=date(2026, 1, 2)), *rows[1:]),
            (replace(rows[1], unadjusted_start=date(2026, 4, 2)), rows[0], rows[2]),
            (rows[1], rows[0], rows[2]),
        ]
        for reference in invalid:
            with self.subTest(reference=reference), self.assertRaises(InputValidationError):
                self.engine.apply(position, reference)

    def test_public_ledger_rejects_impossible_principal_movements(self) -> None:
        with self.assertRaises(InputValidationError):
            AssetParMovement("CREDIT_1", date(2026, 2, 1), AssetCashSource.RECOVERY,
                             D(0), D(10), D(100), D(90), D(10), D(0))
        with self.assertRaises(InputValidationError):
            AssetCollection("CREDIT_1", "EUR", date(2026, 2, 1), AssetCashSource.RECOVERY,
                            D(5), D(50), D(55))
        with self.assertRaises(InputValidationError):
            AssetCollection("CREDIT_1", "EUR", date(2026, 2, 1), AssetCashSource.DEFAULT,
                            D(0), D(0), D(0))

    def test_public_projection_rechecks_tampered_total_and_balance(self) -> None:
        result = self.engine.generate(amortizing_loan())
        for changes in (dict(total_scheduled_principal=D(99)), dict(final_performing_par=D(1)),
                        dict(total_cash_interest=D(20)), dict(total_par_loss=D(1)),
                        dict(pending_recovery_amount=D(1))):
            with self.subTest(changes=changes), self.assertRaises(InputValidationError):
                replace(result, **changes)

    def test_declared_default_cannot_preserve_future_contract_receipts(self) -> None:
        result = self.engine.generate(held_loan())
        with self.assertRaisesRegex(InputValidationError, "contractual prefix"):
            replace(result, event=DefaultEvent("CREDIT_1", date(2026, 2, 1)),
                    credit_event_applied=True, status=CreditProjectionStatus.DEFAULT_RESOLVED)

    def test_declared_recovery_future_queue_cannot_be_understated(self) -> None:
        event = DefaultEvent("CREDIT_1", date(2026, 2, 1), (RecoveryEvent(date(2026, 8, 1), D("0.6")),))
        result = self.engine.generate(held_loan(), event, horizon_date=date(2026, 4, 1))
        with self.assertRaisesRegex(InputValidationError, "future queue"):
            replace(result, pending_recovery_amount=D(59))

    def test_partial_default_or_partial_prepay_is_outside_this_increment(self) -> None:
        for source in (AssetCashSource.DEFAULT, AssetCashSource.PREPAYMENT):
            with self.subTest(source=source), self.assertRaises(InputValidationError):
                AssetParMovement("CREDIT_1", date(2026, 2, 1), source,
                                 D(100), D(50), D(0), D(50) if source is AssetCashSource.DEFAULT else D(0),
                                 D(50) if source is AssetCashSource.PREPAYMENT else D(0), D(0))

    def test_collection_source_must_use_enum_including_unhashable_inputs(self) -> None:
        for source in ("RECOVERY", [], None):
            with self.subTest(source=source), self.assertRaises(InputValidationError):
                AssetCollection("CREDIT_1", "EUR", date(2026, 2, 1), source, D(0), D(10), D(10))

    def test_events_and_results_are_immutable(self) -> None:
        event = DefaultEvent("CREDIT_1", date(2026, 2, 1))
        result = self.engine.generate(held_loan(), event)
        with self.assertRaises(FrozenInstanceError):
            event.event_date = date(2026, 3, 1)
        with self.assertRaises(FrozenInstanceError):
            result.final_performing_par = D(100)

    def test_every_operation_preserves_global_par_bridge(self) -> None:
        event = DefaultEvent("CREDIT_1", date(2026, 5, 15), (
            RecoveryEvent(date(2026, 6, 15), D("0.25")), RecoveryEvent(date(2026, 8, 15), D("0.35")),
        ), date(2026, 9, 15))
        result = self.engine.generate(amortizing_loan(), event)
        cash = loss = Fraction()
        for row in result.par_movements:
            cash += Fraction(row.principal_receipt)
            loss += Fraction(row.par_loss)
            self.assertEqual(Fraction(100), Fraction(row.performing_par_after) + Fraction(row.defaulted_par_after) + cash + loss)


if __name__ == "__main__":
    unittest.main()
