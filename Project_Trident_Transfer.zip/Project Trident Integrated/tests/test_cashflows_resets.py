"""Independent term reset/payment clocks and exact partial coupon answers."""

from dataclasses import replace
from datetime import date, timedelta
from decimal import Decimal, Inexact, localcontext
import unittest

from trident.cashflows.engine import ContractualCashflowEngine
from trident.conventions.schedule import StubConvention
from trident.conventions.calendar import BusinessDayConvention
from trident.conventions.schedule import AccrualDateBasis
from trident.credit import CreditEventCashflowEngine, DefaultEvent, PrepaymentEvent
from trident.credit.overlay import OriginalPoolOverlay
from trident.domain.models import AmortizationType, CouponType, LoanPosition
from trident.market import FlatRateProvider
from test_cashflows_principal import terms_for

D = Decimal


def position(**changes):
    """100 face, nominal 30E/360, quarterly cash and monthly EURIBOR resets."""
    values = dict(coupon_type=CouponType.FLOATING, fixed_rate=None,
                  rate_index='EURIBOR_1M', reset_frequency_months=1, spread_bps=D(0))
    values.update(changes)
    terms = terms_for(**values)
    return LoanPosition(terms, terms.start_date, D(100))


class ObservedRates:
    def __init__(self, rates):
        self.rates, self.calls = rates, []

    def rate(self, index, fixing):
        self.calls.append((index, fixing))
        return self.rates[fixing]


class IndependentResetTests(unittest.TestCase):
    def test_three_monthly_resets_in_one_quarter(self):
        provider = ObservedRates({date(2026, m, 1): D(m) / 100 for m in (1, 2, 3)})
        rows = ContractualCashflowEngine(provider).generate(position(maturity_date=date(2026, 4, 1)))
        self.assertEqual(rows[0].cash_interest, D('.50'))  # 100*(1%+2%+3%)/12
        self.assertEqual(rows[0].all_in_rate, D('.02'))
        self.assertEqual(rows[0].fixing_date, date(2026, 1, 1))
        self.assertEqual(len(rows[0].coupon_segments), 3)
        self.assertEqual(len(provider.calls), 3)

    def test_one_quarter_reset_spans_three_monthly_cash_payments(self):
        provider = ObservedRates({date(2026, 1, 1): D('.12')})
        rows = ContractualCashflowEngine(provider).generate(position(frequency_months=1,
            reset_frequency_months=3, rate_index='EURIBOR_3M', maturity_date=date(2026, 4, 1)))
        self.assertEqual([r.cash_interest for r in rows], [D(1)] * 3)
        self.assertEqual([r.fixing_date for r in rows], [date(2026, 1, 1)] * 3)
        self.assertEqual([r.coupon_segments[0].reset_date for r in rows], [date(2026, 1, 1)] * 3)
        self.assertEqual(len(provider.calls), 1)

    def test_six_month_reset_with_quarterly_cash(self):
        provider = ObservedRates({date(2026, 1, 1): D('.06'), date(2026, 7, 1): D('.12')})
        rows = ContractualCashflowEngine(provider).generate(position(reset_frequency_months=6, rate_index='EURIBOR_6M'))
        self.assertEqual([r.cash_interest for r in rows], [D('1.50'), D('1.50'), D(3)])
        self.assertEqual(len(provider.calls), 2)

    def test_annual_cash_with_supported_quarterly_reset_tenor(self):
        rates = {date(2026, m, 1): D(i) / 25 for i, m in enumerate((1, 4, 7, 10), 1)}
        rows = ContractualCashflowEngine(ObservedRates(rates)).generate(position(frequency_months=12,
            reset_frequency_months=3, rate_index='EURIBOR_3M', maturity_date=date(2027, 1, 1)))
        self.assertEqual(rows[0].cash_interest, D(10))  # 100*(4%+8%+12%+16%)/4
        self.assertEqual(len(rows[0].coupon_segments), 4)

    def test_bounds_apply_to_each_reset_before_aggregation(self):
        provider = ObservedRates({date(2026, 1, 1): D(0), date(2026, 2, 1): D('.10'), date(2026, 3, 1): D(0)})
        row = ContractualCashflowEngine(provider).generate(position(maturity_date=date(2026, 4, 1), all_in_cap=D('.03')))[0]
        self.assertEqual(row.cash_interest, D('.25'))
        self.assertEqual(row.all_in_rate, D('.01'))
        self.assertNotEqual(row.all_in_rate, D('.03'))  # Capping averaged raw rates gives a different answer.

    def test_partial_prepayment_integrates_only_elapsed_reset_segments(self):
        loan = position(maturity_date=date(2026, 4, 1))
        rates = {date(2026, m, 1): D(m) * D('.12') for m in (1, 2, 3)}
        engine = CreditEventCashflowEngine(ObservedRates(rates))
        result = engine.generate(loan, PrepaymentEvent(loan.terms.loan_id, date(2026, 2, 15)))
        self.assertEqual(result.total_cash_interest, D('1.93'))  # 100*.12/12 + 100*.24*14/360
        self.assertEqual(result.total_prepayment_principal, D(100))
        boundary = engine.generate(loan, PrepaymentEvent(loan.terms.loan_id, date(2026, 2, 1)))
        self.assertEqual(boundary.total_cash_interest, D(1))

    def test_credit_replay_uses_frozen_observations_without_provider_queries(self):
        loan = position(maturity_date=date(2026, 4, 1))
        provider = ObservedRates({date(2026, m, 1): D('.12') for m in (1, 2, 3)})
        rows = ContractualCashflowEngine(provider).generate(loan)
        provider.rates.clear()
        result = CreditEventCashflowEngine(provider).apply(loan, rows)
        self.assertEqual(result.total_cash_interest, D(3))
        self.assertEqual(len(provider.calls), 3)

    def test_missing_and_forged_multi_reset_metadata_rejected(self):
        loan = position(maturity_date=date(2026, 4, 1))
        provider = FlatRateProvider({'EURIBOR_1M': D('.12')})
        rows = ContractualCashflowEngine(provider).generate(loan)
        with self.assertRaisesRegex(ValueError, 'requires frozen'):
            CreditEventCashflowEngine(provider).apply(loan, (replace(rows[0], coupon_segments=()),))
        segments = rows[0].coupon_segments
        gap = replace(segments[1], accrual_start=segments[1].accrual_start + timedelta(days=1))
        with self.assertRaisesRegex(ValueError, 'segment dates/rate'):
            CreditEventCashflowEngine(provider).apply(loan, (replace(rows[0], coupon_segments=(segments[0], gap, segments[2])),))

    def test_reused_fixing_observation_must_be_consistent(self):
        loan = position(frequency_months=1, reset_frequency_months=3, rate_index='EURIBOR_3M', maturity_date=date(2026, 4, 1))
        provider = FlatRateProvider({'EURIBOR_3M': D('.12')})
        rows = ContractualCashflowEngine(provider).generate(loan)
        altered = replace(rows[1].coupon_segments[0], index_rate=D('.24'), all_in_rate=D('.24'))
        with self.assertRaisesRegex(ValueError, 'inconsistent frozen'):
            CreditEventCashflowEngine(provider).apply(loan, (rows[0], replace(rows[1], coupon_segments=(altered,)), rows[2]))

    def test_round_once_per_payment_and_hostile_context(self):
        loan = position(maturity_date=date(2026, 4, 1))
        with localcontext() as context:
            context.prec = 2
            context.traps[Inexact] = True
            row = ContractualCashflowEngine(FlatRateProvider({'EURIBOR_1M': D('.0006')})).generate(loan)[0]
        self.assertEqual(row.cash_interest, D('.02'))  # 3 * .005 = .015, not three posted .01 coupons.

    def test_annuity_uses_exact_sum_of_reset_factors(self):
        rates = {date(2026, m, 1): value for m, value in enumerate(map(D, ('0', '.12', '.24', '.12', '.24', '.36')), 1)}
        loan = position(maturity_date=date(2026, 7, 1), amortization_type=AmortizationType.ANNUITY, balloon_amount=D(0))
        rows = ContractualCashflowEngine(ObservedRates(rates)).generate(loan)
        # Factors .03/.06 give payment 100*1.03*1.06/(1+1.06) = 53.
        self.assertEqual([r.cash_interest for r in rows], [D(3), D(3)])
        self.assertEqual([r.principal_repayment for r in rows], [D(50), D(50)])

    def test_short_final_stub_and_early_contractual_payoff(self):
        provider = FlatRateProvider({'EURIBOR_1M': D('.12')})
        rows = ContractualCashflowEngine(provider).generate(position(maturity_date=date(2026, 4, 15)))
        self.assertEqual([r.cash_interest for r in rows], [D(3), D('.47')])
        self.assertEqual(len(rows[-1].coupon_segments), 1)
        spy = ObservedRates({date(2026, m, 1): D('.12') for m in (1, 2, 3)})
        early = ContractualCashflowEngine(spy).generate(position(amortization_type=AmortizationType.LINEAR_AMOUNT,
                                                                scheduled_principal_amount=D(100)))
        self.assertEqual(len(early), 1)
        self.assertEqual(len(spy.calls), 3)  # No fixings after actual scheduled retirement.

    def test_short_first_cash_stub_does_not_restart_reset_grid(self):
        loan = position(start_date=date(2026, 1, 15), maturity_date=date(2026, 5, 1),
                        stub_convention=StubConvention.SHORT_FIRST, first_payment_date=date(2026, 2, 1))
        rows = ContractualCashflowEngine(FlatRateProvider({'EURIBOR_1M': D('.12')})).generate(loan)
        self.assertEqual(rows[1].coupon_segments[0].reset_date, date(2026, 1, 15))
        self.assertEqual(rows[1].coupon_segments[1].reset_date, date(2026, 2, 15))
        self.assertEqual(sum(r.principal_repayment for r in rows), D(100))

    def test_default_cancels_all_unpaid_segment_interest(self):
        loan = position(maturity_date=date(2026, 4, 1))
        result = CreditEventCashflowEngine(FlatRateProvider({'EURIBOR_1M': D('.12')})).generate(loan,
            DefaultEvent(loan.terms.loan_id, date(2026, 2, 15)))
        self.assertEqual(result.total_cash_interest, D(0))
        self.assertEqual(result.defaulted_exposure, D(100))

    def test_original_overlay_consumes_exact_segment_factor(self):
        loan = position(maturity_date=date(2026, 4, 1))
        rows = ContractualCashflowEngine(FlatRateProvider({'EURIBOR_1M': D('.12')})).generate(loan)
        result = OriginalPoolOverlay(False).project(rows, {loan.terms.loan_id: D(100)}, loan.par_as_of_date, date(2026, 4, 1),
            loan_day_counts={loan.terms.loan_id: loan.terms.day_count})
        self.assertEqual(sum(r.cash_interest for r in result.collections), D(3))

    def test_invalid_reset_tenors_fixed_fields_and_types(self):
        for reset in (0, 2, 12, True, D(1)):
            with self.subTest(reset=reset), self.assertRaises(ValueError):
                position(reset_frequency_months=reset)
        with self.assertRaisesRegex(ValueError, 'matching reset'):
            position(rate_index='EURIBOR_3M')
        with self.assertRaisesRegex(ValueError, 'Fixed loans'):
            terms_for(reset_frequency_months=3)

    def test_adjusted_eom_resets_preserve_anchor_and_fixing_lag(self):
        loan = position(start_date=date(2026, 1, 31), maturity_date=date(2026, 7, 31),
            end_of_month=True, business_day_convention=BusinessDayConvention.MODIFIED_FOLLOWING,
            accrual_date_basis=AccrualDateBasis.ADJUSTED, fixing_lag_business_days=2)
        rows = ContractualCashflowEngine(FlatRateProvider({'EURIBOR_1M': D('.12')})).generate(loan)
        self.assertEqual([s.reset_date for s in rows[0].coupon_segments],
                         [date(2026, 1, 30), date(2026, 2, 27), date(2026, 3, 31)])
        self.assertEqual([s.fixing_date for s in rows[0].coupon_segments],
                         [date(2026, 1, 28), date(2026, 2, 25), date(2026, 3, 27)])
        self.assertEqual(rows[1].coupon_segments[0].reset_date, date(2026, 4, 30))

    def test_blank_and_equal_reset_frequencies_preserve_cash_and_segments(self):
        implicit = position(reset_frequency_months=None, rate_index='EURIBOR_3M')
        explicit = replace(implicit, terms=replace(implicit.terms, reset_frequency_months=3))
        engine = ContractualCashflowEngine(FlatRateProvider({'EURIBOR_3M': D('.12')}))
        self.assertEqual(engine.generate(implicit), engine.generate(explicit))

    def test_segment_collections_cannot_be_mutable(self):
        row = ContractualCashflowEngine(FlatRateProvider({'EURIBOR_1M': D('.12')})).generate(position())[0]
        with self.assertRaisesRegex(ValueError, 'immutable tuple'):
            replace(row, coupon_segments=list(row.coupon_segments))


if __name__ == '__main__':
    unittest.main()
