"""One chronological sweep of actual receipts, commitments and settlements.

Conservative same-day ordering is explicit: actual collections/payments, default/
write-off, cancellations, prior commitments' settlement, all new commitments,
then their same-day settlement. New trades are reserved as a batch before any
of them settle, so an unsettled sale cannot fund a simultaneous purchase.
This is a modeled ordering policy, not an asserted universal market convention.

Reservations net components of the SAME trade/account (contractual settlement
consideration), never unrelated trades or claims. Cash and face move only at
settlement/explicit receipt; due dates merely observe uncollected claims. No
order is routed and a simulated full fill is not proof of agent consent/fill.
"""

from collections import defaultdict
from dataclasses import replace
from datetime import date
from fractions import Fraction

from trident.domain.models import InputValidationError
from trident.domain.numeric import post_currency
from .models import (
    CashAccount, CashBalances, CashReceivable, HoldingStatus, HoldingsLedgerRequest,
    HoldingsLedgerResult, HoldingsLedgerSnapshot, LedgerEvent, LedgerEventKind,
    LedgerJournalEntry, LedgerPermissions, OpeningHolding, PendingTrade, TradeCommitment, TradeSide,
)


def _cash_changes(trade: TradeCommitment, permissions: LedgerPermissions) -> tuple[Fraction, Fraction]:
    """Signed account settlement legs, preserving explicit purchased-accrued rules."""
    if trade.accrued_cash and trade.accrued_account is CashAccount.PRINCIPAL and not permissions.allow_principal_for_accrued:
        raise InputValidationError(f"Trade {trade.trade_id}: principal-funded accrued requires explicit permission")
    if trade.fees_cash and trade.fee_account is CashAccount.PRINCIPAL and not permissions.allow_principal_for_fees:
        raise InputValidationError(f"Trade {trade.trade_id}: principal-funded fees require explicit permission")
    sign = -1 if trade.side is TradeSide.BUY else 1
    amounts = {CashAccount.PRINCIPAL: sign * Fraction(trade.clean_cash), CashAccount.INTEREST: Fraction()}
    amounts[trade.accrued_account] += sign * Fraction(trade.accrued_cash)
    amounts[trade.fee_account] -= Fraction(trade.fees_cash)
    return amounts[CashAccount.PRINCIPAL], amounts[CashAccount.INTEREST]


def _pending(trade: TradeCommitment, permissions: LedgerPermissions) -> PendingTrade:
    """A positive settlement claim is not available cash before settlement."""
    principal, interest = _cash_changes(trade, permissions)
    return PendingTrade(
        trade,
        CashBalances(post_currency(max(-principal, Fraction())), post_currency(max(-interest, Fraction()))),
        CashBalances(post_currency(max(principal, Fraction())), post_currency(max(interest, Fraction()))),
    )


class _LedgerState:
    """Private mutable sweep state; all public inputs/results remain frozen.

    Aggregate reservations and per-asset reserved sales update in O(1) per
    trade; validation never scans a daily calendar or replays past events.
    Snapshot materialisation copies references to immutable rows, not histories.
    """
    def __init__(self, request: HoldingsLedgerRequest) -> None:
        self.request = request
        self.cash = [Fraction(request.opening_cash.principal), Fraction(request.opening_cash.interest)]
        self.reserved = [Fraction(), Fraction()]
        self.holdings = {item.asset_id: item for item in request.opening_holdings}
        self.ever_owned = set(self.holdings)
        for trade in request.opening_commitments + request.trades:
            self.holdings.setdefault(trade.asset_id, OpeningHolding(trade.asset_id, request.currency, post_currency(Fraction())))
        self.active: dict[str, PendingTrade] = {}
        self.seen_trades: set[str] = set()
        self.reserved_sales: dict[str, Fraction] = defaultdict(Fraction)
        self.claims = {item.receivable_id: item for item in request.opening_receivables}
        self.journal: list[LedgerJournalEntry] = []

    def _trade_status(self, trade: TradeCommitment) -> None:
        if self.holdings[trade.asset_id].status is HoldingStatus.DEFAULTED and not trade.allow_defaulted_asset:
            raise InputValidationError(f"Trade {trade.trade_id}: defaulted asset requires explicit reconfirmation/allow_defaulted_asset")

    def reserve(self, trades: tuple[TradeCommitment, ...], day: date, *, opening: bool = False) -> None:
        """Validate the whole commitment batch before publishing any reservation."""
        rows = tuple(_pending(trade, self.request.permissions) for trade in trades)
        needed = [Fraction(), Fraction()]
        sales: dict[str, Fraction] = defaultdict(Fraction)
        for row in rows:
            trade = row.trade
            if trade.trade_id in self.seen_trades:
                raise InputValidationError(f"Trade {trade.trade_id} was already committed")
            self._trade_status(trade)
            needed[0] += Fraction(row.reserved_cash.principal)
            needed[1] += Fraction(row.reserved_cash.interest)
            if trade.side is TradeSide.SELL:
                sales[trade.asset_id] += Fraction(trade.par)
        for index, account in enumerate(("PRINCIPAL", "INTEREST")):
            if self.cash[index] - self.reserved[index] < needed[index]:
                raise InputValidationError(f"Insufficient unencumbered {account} cash for commitments on {day}; unsettled sale/receivable cash is unavailable")
        for asset_id, amount in sales.items():
            if Fraction(self.holdings[asset_id].settled_par) - self.reserved_sales[asset_id] < amount:
                raise InputValidationError(f"Asset {asset_id}: commitments oversell available settled par; pending buys are unavailable")
        for row in rows:
            trade = row.trade
            self.active[trade.trade_id] = row
            self.seen_trades.add(trade.trade_id)
            self.reserved[0] += Fraction(row.reserved_cash.principal)
            self.reserved[1] += Fraction(row.reserved_cash.interest)
            if trade.side is TradeSide.SELL:
                self.reserved_sales[trade.asset_id] += Fraction(trade.par)
            # Historical opening commitments have no fabricated trade-day
            # posting. Their explicitly supplied opening reservations suffice.
            if not opening:
                self.journal.append(LedgerJournalEntry(day, f"COMMIT:{trade.trade_id}", "COMMIT", trade.asset_id, trade.trade_id))

    def release(self, trade_id: str) -> PendingTrade:
        row = self.active.pop(trade_id)
        self.reserved[0] -= Fraction(row.reserved_cash.principal)
        self.reserved[1] -= Fraction(row.reserved_cash.interest)
        if row.trade.side is TradeSide.SELL:
            self.reserved_sales[row.trade.asset_id] -= Fraction(row.trade.par)
        return row

    def assert_available(self) -> None:
        """Source amortisation/default cannot silently leave executable oversells."""
        if any(reserve < 0 for reserve in self.reserved):
            raise ArithmeticError("Cash reservation bridge became negative")
        if any(amount < reserve for amount, reserve in zip(self.cash, self.reserved)):
            raise InputValidationError("Actual cash payments conflict with encumbered cash commitments")
        for asset_id, amount in self.reserved_sales.items():
            if amount < 0 or amount > Fraction(self.holdings[asset_id].settled_par):
                raise InputValidationError(f"Asset {asset_id}: principal movement makes pending sale unavailable; cancel/amend explicitly")
        for row in self.active.values():
            self._trade_status(row.trade)

    def event(self, item: LedgerEvent) -> None:
        """Recognise only supplied actual cash; outstanding claims never auto-pay."""
        if item.kind is LedgerEventKind.CASH_PAYMENT:
            principal = Fraction(item.principal_cash)
            interest = Fraction(item.interest_cash)
            if principal > self.cash[0] or interest > self.cash[1]:
                raise InputValidationError(f"Payment {item.event_id}: insufficient actual cash in the specified account")
            # Enforce liquidity at the payment phase itself. A cancellation or
            # settlement later today cannot retrospectively release funds for
            # an earlier payment; the end-of-day invariant alone would miss
            # that temporary use of cash reserved for a binding commitment.
            if principal > self.cash[0] - self.reserved[0] or interest > self.cash[1] - self.reserved[1]:
                raise InputValidationError(f"Payment {item.event_id}: actual cash payment conflicts with encumbered cash commitments")
            if item.asset_id is not None and item.asset_id not in self.holdings:
                raise InputValidationError(f"Payment {item.event_id}: unknown asset identity")
            self.cash[0] -= principal
            self.cash[1] -= interest
            self.journal.append(LedgerJournalEntry(
                item.event_date, item.event_id, item.kind.value, item.asset_id, None,
                post_currency(-principal), post_currency(-interest),
            ))
            return
        if item.kind is LedgerEventKind.TRADE_CANCEL:
            if item.trade_id not in self.active:
                raise InputValidationError(f"Cancel {item.event_id}: trade is not an unsettled active commitment")
            row = self.release(item.trade_id)
            self.journal.append(LedgerJournalEntry(item.event_date, item.event_id, item.kind.value, row.trade.asset_id, item.trade_id))
            return
        if item.asset_id not in self.holdings:
            raise InputValidationError(f"Event {item.event_id}: unknown asset_id {item.asset_id}")
        holding = self.holdings[item.asset_id]
        if item.par_reduction > holding.settled_par:
            raise InputValidationError(f"Event {item.event_id}: par_reduction exceeds actual settled face")
        if item.kind is LedgerEventKind.DEFAULT:
            if holding.status is HoldingStatus.DEFAULTED:
                raise InputValidationError(f"Event {item.event_id}: asset already defaulted")
            self.holdings[item.asset_id] = replace(holding, status=HoldingStatus.DEFAULTED)
        else:
            if item.kind is LedgerEventKind.RECEIVABLE_COLLECTION:
                claim = self.claims.get(item.receivable_id)
                if claim is None or claim.asset_id != item.asset_id:
                    raise InputValidationError(f"Event {item.event_id}: missing/mismatched outstanding receivable")
                p, i = Fraction(claim.principal_cash) - Fraction(item.principal_cash), Fraction(claim.interest_cash) - Fraction(item.interest_cash)
                if p < 0 or i < 0:
                    raise InputValidationError(f"Event {item.event_id}: collection exceeds explicitly classified receivable")
                if p or i:
                    self.claims[item.receivable_id] = replace(claim, principal_cash=post_currency(p), interest_cash=post_currency(i))
                else:
                    del self.claims[item.receivable_id]
            if item.kind is LedgerEventKind.WRITE_OFF and holding.status is not HoldingStatus.DEFAULTED:
                raise InputValidationError("WRITE_OFF requires a defaulted holding; performing forgiveness needs an explicit separate contract policy")
            self.cash[0] += Fraction(item.principal_cash)
            self.cash[1] += Fraction(item.interest_cash)
            self.holdings[item.asset_id] = replace(holding, settled_par=post_currency(Fraction(holding.settled_par) - Fraction(item.par_reduction)))
        self.journal.append(LedgerJournalEntry(
            item.event_date, item.event_id, item.kind.value, item.asset_id, None,
            item.principal_cash, item.interest_cash, post_currency(-Fraction(item.par_reduction)),
        ))

    def settle(self, trade_ids: tuple[str, ...], day: date) -> None:
        """DVP-like modeled full settlement; no cross-trade liquidity netting.

        Prior reservation already proves each account debit is funded and each
        sale deliverable. Recheck after source/cancellation events, then post
        cash and par together. A canceled trade has no settlement posting.
        """
        self.assert_available()
        for trade_id in trade_ids:
            if trade_id not in self.active:
                continue
            row = self.release(trade_id)
            trade = row.trade
            principal, interest = _cash_changes(trade, self.request.permissions)
            delta = Fraction(trade.par) * (1 if trade.side is TradeSide.BUY else -1)
            holding = self.holdings[trade.asset_id]
            self.cash[0] += principal
            self.cash[1] += interest
            self.holdings[trade.asset_id] = replace(holding, settled_par=post_currency(Fraction(holding.settled_par) + delta))
            self.ever_owned.add(trade.asset_id)
            sign = -1 if trade.side is TradeSide.BUY else 1
            self.journal.append(LedgerJournalEntry(
                day, f"SETTLE:{trade_id}", "SETTLE", trade.asset_id, trade_id,
                post_currency(principal), post_currency(interest), post_currency(delta),
                post_currency(sign * Fraction(trade.clean_cash)), post_currency(sign * Fraction(trade.accrued_cash)), post_currency(-Fraction(trade.fees_cash)),
            ))
        self.assert_available()

    def snapshot(self, day: date) -> HoldingsLedgerSnapshot:
        self.assert_available()
        return HoldingsLedgerSnapshot(
            day, self.request.currency,
            tuple(self.holdings[key] for key in sorted(self.ever_owned)),
            CashBalances(*(post_currency(value) for value in self.cash)),
            CashBalances(*(post_currency(value) for value in self.reserved)),
            CashBalances(*(post_currency(value - reserve) for value, reserve in zip(self.cash, self.reserved))),
            tuple(self.active[key] for key in sorted(self.active)),
            tuple(self.claims[key] for key in sorted(self.claims)),
        )


class HoldingsLedgerService:
    """Replay one frozen opening ledger without touching a workbook or market API."""
    def replay(self, request: HoldingsLedgerRequest) -> HoldingsLedgerResult:
        """Return deterministic post-day snapshots and cash/par bridge evidence.

        Only dates containing events, trades, settlements or claim due dates
        are visited; explicit horizon always has a final snapshot. Source cash
        executes before same-day credit changes. Cancellations execute before
        settlement, but same-day new-trade cancellation without timestamps is
        rejected rather than silently choosing a profitable event order.
        """
        if not isinstance(request, HoldingsLedgerRequest):
            raise TypeError("request must be HoldingsLedgerRequest")
        state = _LedgerState(request)
        all_trades = {item.trade_id: item for item in request.opening_commitments + request.trades}
        opening_ids = {item.trade_id for item in request.opening_commitments}
        for event in request.events:
            if event.kind is LedgerEventKind.TRADE_CANCEL:
                trade = all_trades.get(event.trade_id)
                if trade is None or event.event_date > trade.settlement_date or event.event_date < trade.trade_date:
                    raise InputValidationError("Cancellation must reference a known unsettled trade before/on settlement")
                if event.event_date == trade.trade_date and event.trade_id not in opening_ids:
                    raise InputValidationError("Same-day new trade/cancellation ordering requires explicit intraday timestamps and is unsupported")
        state.reserve(tuple(sorted(request.opening_commitments, key=lambda item: item.trade_id)), request.as_of_date, opening=True)
        opening = state.snapshot(request.as_of_date)
        events: dict[date, list[LedgerEvent]] = defaultdict(list)
        trades: dict[date, list[TradeCommitment]] = defaultdict(list)
        settlements: dict[date, list[str]] = defaultdict(list)
        dates = {request.as_of_date, request.horizon_date}
        for event in request.events:
            events[event.event_date].append(event)
            dates.add(event.event_date)
        for trade in request.trades:
            if trade.trade_date <= request.horizon_date:
                trades[trade.trade_date].append(trade)
                dates.add(trade.trade_date)
        for trade in all_trades.values():
            if request.as_of_date <= trade.settlement_date <= request.horizon_date:
                settlements[trade.settlement_date].append(trade.trade_id)
                dates.add(trade.settlement_date)
        for claim in request.opening_receivables:
            if request.as_of_date <= claim.due_date <= request.horizon_date:
                dates.add(claim.due_date)
        phases = {
            LedgerEventKind.CASH_COLLECTION: 0, LedgerEventKind.RECEIVABLE_COLLECTION: 0,
            LedgerEventKind.CASH_PAYMENT: 1, LedgerEventKind.DEFAULT: 2,
            LedgerEventKind.WRITE_OFF: 3, LedgerEventKind.TRADE_CANCEL: 4,
        }
        snapshots = []
        for day in sorted(dates):
            for event in sorted(events[day], key=lambda item: (phases[item.kind], item.event_id)):
                state.event(event)
            # Prior settlements can fund a new commitment TODAY after receipt,
            # whereas a NEW same-day sale cannot finance its same-batch buy.
            due = tuple(sorted(settlements[day]))
            state.settle(tuple(key for key in due if all_trades[key].trade_date < day or key in opening_ids), day)
            state.reserve(tuple(sorted(trades[day], key=lambda item: item.trade_id)), day)
            state.settle(tuple(key for key in due if all_trades[key].trade_date == day and key not in opening_ids), day)
            snapshots.append(state.snapshot(day))
        result = HoldingsLedgerResult(opening, tuple(snapshots), tuple(state.journal), request.source)
        final = result.final_snapshot
        # Independent aggregate bridges verify actual postings, never reserve
        # movements/receivable balances or inferred investment P&L.
        for name, initial, ending in (("principal", request.opening_cash.principal, final.cash.principal),
                                     ("interest", request.opening_cash.interest, final.cash.interest)):
            changes = sum((Fraction(getattr(row, name + "_cash_change")) for row in result.journal), Fraction())
            if Fraction(initial) + changes != Fraction(ending):
                raise ArithmeticError(f"Ledger {name} cash bridge failed")
        if Fraction(opening.settled_par) + sum((Fraction(row.par_change) for row in result.journal), Fraction()) != Fraction(final.settled_par):
            raise ArithmeticError("Ledger settled par bridge failed")
        return result
