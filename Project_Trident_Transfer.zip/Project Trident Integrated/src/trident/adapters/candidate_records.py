"""Frozen Excel values to bounded closing-pool search, without Bloomberg I/O.

Timestamps require an explicit UTC offset in ISO text. Excel date values have
no timezone and cannot stand in for quote observation/capture timestamps.
"""

from datetime import datetime, timedelta
from enum import Enum
from fractions import Fraction
from typing import Mapping, TypeVar

from trident.application.candidate_search import CandidateSearchVariant, CandidateSelectionPolicy, ClosingPoolSearchRequest
from trident.application.clo_services import TridentModelRequest, TridentModelResult
from trident.domain.models import InputValidationError, PrincipalScheduleEntry
from trident.optimization import OptimizationObjective
from trident.optimization.universe import (CandidateAdmissionPolicy, CandidateAssetSnapshot, CandidateCreditStatus,
    CandidateUniverseSnapshot, PriceObservation, PriceSide, QuoteQuality, RatingLevel, RatingNature, RatingObservation)
from .model_records import exposures_from_records, optional_decimal, optional_text
from .optimization_records import (
    OptimizationBudgetScope, optimization_request_from_records, optimization_snapshot_from_records,
)
from .records import (_validate_fields, boolean_value, coupon_steps_from_records, date_value,
    decimal_value, position_from_record, text_value)


_TABLE_FIELDS = {
    "Candidate Metadata": frozenset({"loan_id", "facility_id", "bloomberg_security", "contract_provenance", "classification_provenance", "credit_status"}),
    "Candidate Ratings": frozenset({"loan_id", "agency", "rating", "level", "nature", "subject_id", "as_of_date", "source"}),
    "Quote Observations": frozenset({"asset_id", "side", "price_side", "quality", "observed_at", "settlement_date", "source"}),
    "Candidate Variants": frozenset({"candidate_id", "objective", "maximum_overall_factor", "maximum_bsl_factor", "minimum_spread_bps", "maximum_trade_par", "enabled"}),
}
_EnumType = TypeVar("_EnumType", bound=Enum)


def _enum_value(enum_type: type[_EnumType], value: object, label: str) -> _EnumType:
    """Report the semantic field for invalid enum text, including bool/list input."""
    try:
        return enum_type(text_value(value, label))
    except ValueError as exc:
        raise InputValidationError(f"{label}: invalid {enum_type.__name__} value {value!r}") from exc


def timestamp_value(value: object, field: str) -> datetime:
    """Require timezone-aware ISO text, or an already typed aware timestamp."""
    try:
        result = value if type(value) is datetime else datetime.fromisoformat(value) if isinstance(value, str) else None
    except ValueError as exc:
        raise InputValidationError(f"{field}: requires ISO timestamp with UTC offset") from exc
    if result is None or result.tzinfo is None or result.utcoffset() is None:
        raise InputValidationError(f"{field}: requires ISO timestamp with UTC offset")
    return result


def _indexed(rows, key_fields, label):
    indexed = {}
    for row in rows:
        key = tuple(text_value(row.get(name), name) for name in key_fields)
        if key in indexed:
            raise InputValidationError(f"Duplicate {label} identity: {key}")
        indexed[key] = row
    return indexed


def candidate_search_from_records(
    baseline: TridentModelRequest, result: TridentModelResult | None, held_records: tuple[Mapping[str, object], ...],
    quote_records: tuple[Mapping[str, object], ...], controls: Mapping[str, object], *,
    candidate_assets: tuple[Mapping[str, object], ...], candidate_metadata: tuple[Mapping[str, object], ...],
    candidate_ratings: tuple[Mapping[str, object], ...], quote_observations: tuple[Mapping[str, object], ...],
    candidate_variants: tuple[Mapping[str, object], ...],
    coupon_step_records: tuple[Mapping[str, object], ...] = (),
    seasoned_state_records: tuple[Mapping[str, object], ...] = (),
    opening_fixing_records: tuple[Mapping[str, object], ...] = (),
    principal_schedule_records: tuple[Mapping[str, object], ...] = (),
) -> ClosingPoolSearchRequest:
    """Build full loan/rating/price evidence independently from static descriptors.

    Metadata is required for every quoted facility. Existing SELLs reuse exact
    baseline contracts/exposures; Candidate Assets contains new BUY facilities.
    Missing contract/provenance/rating remains an explicit quarantine condition.
    Candidate Assets supplies contract/quality information; its optional legacy
    purchase_price_pct is a sizing reference, never acquisition pricing. The
    admitted BUY ASK and its fees are the sole target acquisition economics.
    Quote accrued belongs in Trade Candidates as EUR per EUR1 par. Closing
    redesign permits it only with the supported inherited-entitlement path;
    Candidate Assets is contract-only and must not duplicate acquisition cash.
    A None result is allowed solely to build read-only preflight inputs: no
    projected baseline status or candidate eligibility is established by it.
    """
    for label, rows in (("Candidate Metadata", candidate_metadata), ("Candidate Ratings", candidate_ratings),
                        ("Quote Observations", quote_observations), ("Candidate Variants", candidate_variants)):
        for row in rows:
            if not isinstance(row, Mapping):
                raise InputValidationError(f"{label}: rows must be semantic field mappings")
            _validate_fields(row, _TABLE_FIELDS[label], label)
    # Full closing redesign is an economic funding comparison, distinct from
    # the static principal-account tool. It never spends real sale accrued or
    # deposits a trade into the actual CLO accounts.
    has_quote_accrued = any(decimal_value(row.get("accrued_per_par"), "accrued_per_par") != 0 for row in quote_records)
    if has_quote_accrued and (baseline.clo_terms is None or baseline.clo_terms.adjusted_oc_policy is None):
        raise InputValidationError("Closing quote requires zero accrued unless the explicit supported inherited-coupon entitlement policy is present")
    if result is None:
        if not baseline.cashflow_request.positions:
            raise InputValidationError("Candidate preflight requires nonempty opening positions")
        mandate = optimization_snapshot_from_records(held_records, quote_records, controls, baseline.factor_mapping,
            opening_date=baseline.cashflow_request.positions[0].par_as_of_date,
            budget_scope=OptimizationBudgetScope.CLOSING_ECONOMIC_BUDGET)
    else:
        mandate = optimization_request_from_records(held_records, quote_records, controls, baseline.factor_mapping, result,
            budget_scope=OptimizationBudgetScope.CLOSING_ECONOMIC_BUDGET)
    held_positions = {p.terms.loan_id: p for p in baseline.cashflow_request.positions}
    held_exposures = {e.loan_id: e for e in baseline.exposures}
    held_steps = coupon_steps_from_records(coupon_step_records, held_records, scope="ASSET")
    for identifier, (steps, policy) in held_steps.items():
        if identifier not in held_positions:
            raise InputValidationError(f"Coupon Steps ASSET refers to a loan absent from the supplied baseline: {identifier}")
        terms = held_positions[identifier].terms
        if terms.coupon_steps != steps or terms.coupon_step_policy is not policy:
            raise InputValidationError(f"Coupon Steps ASSET terms differ from the supplied baseline: {identifier}")
    step_groups = coupon_steps_from_records(coupon_step_records, candidate_assets, scope="CANDIDATE")
    from .pilot_workbook import seasoned_states_from_records
    candidate_states = seasoned_states_from_records(seasoned_state_records, opening_fixing_records, candidate_assets, scope='CANDIDATE')
    # Candidate contracts use the same explicit dated principal transport as
    # held assets. No installment is inferred from quotation price or size.
    known_candidates = {text_value(row.get("loan_id"), "candidate loan_id") for row in candidate_assets}
    principal_schedules = {}
    for row in principal_schedule_records:
        _validate_fields(row, frozenset({"loan_id", "payment_date_unadjusted", "amount"}), "Candidate Principal Schedule")
        identifier = text_value(row.get("loan_id"), "candidate principal loan_id")
        if identifier not in known_candidates:
            raise InputValidationError(f"Candidate Principal Schedule refers to unknown candidate loan_id: {identifier}")
        principal_schedules.setdefault(identifier, []).append(PrincipalScheduleEntry(
            date_value(row.get("payment_date_unadjusted"), "candidate principal date"),
            decimal_value(row.get("amount"), "candidate principal amount")))
    new_positions, new_exposures = {}, {}
    for row in candidate_assets:
        identifier = text_value(row.get("loan_id"), "candidate loan_id")
        if identifier in held_positions or identifier in new_positions:
            raise InputValidationError(f"Candidate Assets must contain unique new facilities, not held loan_id: {identifier}")
        if optional_decimal(row.get("acquired_accrued_interest"), "candidate acquired_accrued_interest") not in (None, 0):
            raise InputValidationError("Candidate Assets must not supply acquired accrued: put accrued_per_par in Trade Candidates, not acquired_accrued_interest here")
        # The contract-only Excel table omits acquisition fields. A neutral
        # reference position supplies the existing DTO's required fields;
        # redesign funding always replaces its price with the admitted ASK.
        step_options = {} if identifier not in step_groups else dict(
            coupon_steps=step_groups[identifier][0], coupon_step_policy=step_groups[identifier][1])
        new_positions[identifier] = position_from_record({"purchase_price_pct": 100,
            "acquired_accrued_interest": 0, **row}, seasoned_state=candidate_states.get(identifier),
            principal_schedule=tuple(sorted(principal_schedules.get(identifier, ()), key=lambda item: item.payment_date)), **step_options)
        new_exposures[identifier] = exposures_from_records((row,), baseline.factor_mapping)[0]
    metadata = _indexed(candidate_metadata, ("loan_id",), "candidate metadata")
    observations = _indexed(quote_observations, ("asset_id", "side"), "quote observation")
    descriptors, quotes = {}, {}
    for quote in mandate.quotes:
        identifier = quote.asset.asset_id
        if identifier in descriptors and descriptors[identifier] != quote.asset:
            raise InputValidationError(f"Conflicting candidate descriptor: {identifier}")
        descriptors[identifier] = quote.asset
        quotes.setdefault(identifier, []).append(quote)
    expected_quote_ids = {(q.asset.asset_id, q.side.value) for q in mandate.quotes}
    if set(observations) != expected_quote_ids:
        raise InputValidationError("Quote Observations must match all Trade Candidates by asset_id and side")
    universe_ids = set(descriptors) | set(new_positions) | {key[0] for key in metadata}
    if any(key[0] not in held_positions and key[0] not in descriptors for key in metadata):
        raise InputValidationError("Candidate metadata requires a held or quoted facility descriptor")
    if set(new_positions) - set(descriptors):
        raise InputValidationError("New Candidate Assets require explicit matching Trade Candidates")
    rating_rows = {}
    for row in candidate_ratings:
        identifier = text_value(row.get("loan_id"), "rating loan_id")
        if identifier not in universe_ids:
            raise InputValidationError(f"Rating refers to unknown candidate: {identifier}")
        rating_rows.setdefault(identifier, []).append(RatingObservation(
            text_value(row.get("agency"), "agency"), text_value(row.get("rating"), "rating"),
            _enum_value(RatingLevel, row.get("level"), "rating level"), _enum_value(RatingNature, row.get("nature"), "rating nature"), text_value(row.get("subject_id"), "subject_id"),
            date_value(row.get("as_of_date"), "rating as_of_date"), text_value(row.get("source"), "rating source")))
    frozen = []
    for identifier, descriptor in sorted(descriptors.items()):
        row = metadata.get((identifier,))
        if row is None:
            raise InputValidationError(f"Missing facility identity in Candidate Metadata: {identifier}")
        prices = []
        for quote in quotes[identifier]:
            observation = observations[(identifier, quote.side.value)]
            prices.append(PriceObservation(quote, _enum_value(PriceSide, observation.get("price_side"), "price_side"), _enum_value(QuoteQuality, observation.get("quality"), "quote quality"),
                timestamp_value(observation.get("observed_at"), "quote observed_at"),
                date_value(observation.get("settlement_date"), "quote settlement_date"), text_value(observation.get("source"), "quote source")))
        credit_status = optional_text(row.get("credit_status"), "credit_status")
        frozen.append(CandidateAssetSnapshot(descriptor, text_value(row.get("facility_id"), "facility_id"),
            text_value(row.get("bloomberg_security"), "bloomberg_security"),
            held_positions.get(identifier, new_positions.get(identifier)), held_exposures.get(identifier, new_exposures.get(identifier)),
            tuple(rating_rows.get(identifier, ())), tuple(prices), optional_text(row.get("contract_provenance"), "contract_provenance"),
            optional_text(row.get("classification_provenance"), "classification_provenance"),
            None if credit_status is None else _enum_value(CandidateCreditStatus, credit_status, "credit_status")))
    age = Fraction(decimal_value(controls["candidate_maximum_quote_age_hours"], "candidate_maximum_quote_age_hours")) * 3600 * 1_000_000
    if age < 0 or age.denominator != 1:
        raise InputValidationError("maximum quote age must be nonnegative and expressible in whole microseconds")
    quality_text = text_value(controls["candidate_allowed_quote_qualities"], "candidate_allowed_quote_qualities")
    quality = tuple(_enum_value(QuoteQuality, item.strip(), "allowed quote quality") for item in quality_text.split(","))
    snapshot = CandidateUniverseSnapshot(text_value(controls["candidate_snapshot_id"], "candidate_snapshot_id"),
        timestamp_value(controls["candidate_snapshot_captured_at"], "candidate_snapshot_captured_at"),
        text_value(controls["candidate_snapshot_source"], "candidate_snapshot_source"), mandate.factor_provenance, tuple(frozen))
    variants = tuple(CandidateSearchVariant(text_value(row.get("candidate_id"), "candidate_id"), _enum_value(OptimizationObjective, row.get("objective"), "candidate objective"),
        *(optional_decimal(row.get(name), name) for name in ("maximum_overall_factor", "maximum_bsl_factor", "minimum_spread_bps", "maximum_trade_par")))
        for row in candidate_variants if boolean_value(row.get("enabled"), "candidate variant enabled"))
    try:
        maximum_age = timedelta(microseconds=int(age))
    except OverflowError as exc:
        raise InputValidationError("maximum quote age exceeds supported timedelta range") from exc
    return ClosingPoolSearchRequest(baseline, mandate, snapshot,
        CandidateAdmissionPolicy(mandate.settlement_date, maximum_age, quality), variants,
        _enum_value(CandidateSelectionPolicy, controls["candidate_selection_policy"], "candidate_selection_policy"),
        optional_decimal(controls.get("candidate_minimum_equity_irr"), "candidate_minimum_equity_irr"))


def candidate_result_record(evaluation, selected_id: str | None) -> dict[str, object]:
    """Scalar-only reporting, without copying the nested full CLO projections."""
    row = {key: getattr(evaluation, key) for key in ("candidate_id", "status", "eligible", "factor_metric", "equity_irr_delta", "factor_delta",
        "equity_cash_funding", "equity_distributions", "gross_trade_par", "static_ending_cash", "rank", "pareto", "failure_message")}
    row.update(equity_irr=evaluation.equity_irr.value, equity_irr_status=evaluation.equity_irr.status.value,
               equity_moic=evaluation.equity_moic.value, factor=evaluation.factor.value, factor_status=evaluation.factor.status.value,
               selected=evaluation.candidate_id == selected_id)
    return row
