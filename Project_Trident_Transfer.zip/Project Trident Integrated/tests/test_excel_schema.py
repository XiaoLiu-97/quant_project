"""Current named Excel contract, independently of cached financial results."""
from datetime import datetime
import json
import unittest

from openpyxl import load_workbook
from openpyxl.utils.cell import range_boundaries

from trident.adapters import excel_schema as schema
from trident.adapters import pilot_schema
from trident.adapters.workbook_presentation import HORIZONTAL_INPUT_GROUPS
from trident.adapters.excel import NamedWorkbook
from trident.adapters.records import ASSET_FIELDS
from trident.adapters.records import boolean_value
from trident.domain.models import InputValidationError
from workbook_fixtures import INPUT_TEMPLATE, ROOT


class SchemaMetadataTests(unittest.TestCase):
    def test_column_order_retains_metadata_and_puts_contract_first(self):
        self.assertEqual(schema.ordered_columns(('provenance', 'loan_id', 'current_par', 'user_note'),
                         schema.ASSET_PRIORITY_COLUMNS), ('loan_id', 'current_par', 'provenance', 'user_note'))

    def test_duplicate_headers_case_insensitive_rejected(self):
        with self.assertRaisesRegex(ValueError, 'unique'):
            schema.ordered_columns(('loan_id', 'LOAN_ID'), ('loan_id',))

    def test_term_region_has_semantic_rate_headers(self):
        self.assertEqual(schema.CURVE_BLOCKS[0].columns,
            ('Curve Date', 'EURIBOR 1M Projected Forward Fixing Rate',
             'EURIBOR 3M Projected Forward Fixing Rate',
             'EURIBOR 6M Projected Forward Fixing Rate', 'Source / Note'))

    def test_only_current_schema_is_accepted(self):
        schema.require_current_schema(schema.SCHEMA_VERSION)
        for version in ('0.1', '0.2', '0.3', '0.4', '0.5', '0.6', '../untrusted', ''):
            with self.subTest(version=version), self.assertRaises(InputValidationError):
                schema.require_current_schema(version)


class InputTemplateContractTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        # Missing persistent fixture fails instead of silently skipping audits.
        cls.workbook = load_workbook(INPUT_TEMPLATE)
        cls.adapter = NamedWorkbook(cls.workbook)

    @classmethod
    def tearDownClass(cls):
        cls.workbook.close()

    def scalar(self, key):
        return self.adapter.scalar(schema.SCALAR_NAMES[key])

    def table(self, key):
        return self.adapter.table_records(schema.TABLE_RANGE_NAMES[key], schema.TABLE_NAMES[key])

    def test_current_version_all_names_scoped_complete_and_single_rectangles(self):
        self.assertEqual(self.scalar('schema_version'), schema.SCHEMA_VERSION)
        self.assertEqual(len(self.workbook.sheetnames),
                         53 + len(pilot_schema.DESCRIPTORS) - len(HORIZONTAL_INPUT_GROUPS))
        names = (*schema.SCALAR_NAMES.values(), *schema.TABLE_RANGE_NAMES.values(),
                 *(block.range_name for block in schema.CURVE_BLOCKS))
        self.assertEqual(len({name.casefold() for name in names}), len(names))
        self.assertEqual(set(self.workbook.defined_names), set(names))
        for name in names:
            with self.subTest(name=name):
                definition = self.workbook.defined_names[name]
                self.assertIsNone(definition.localSheetId)
                self.assertNotIn('#REF!', definition.attr_text)
                structured = {schema.TABLE_RANGE_NAMES[key]: schema.TABLE_NAMES[key]
                              for key in ('coupon_steps', *pilot_schema.DESCRIPTORS,
                                          *(key for group in HORIZONTAL_INPUT_GROUPS for key in group.table_keys))}
                if name in structured:
                    self.assertEqual(definition.attr_text, f"{structured[name]}[#All]")
                    # Structured names are resolved through the native Table,
                    # rather than openpyxl's explicit-rectangle destinations.
                    self.adapter.region(name)
                else:
                    self.assertEqual(len(tuple(definition.destinations)), 1)
        self.assertTrue(all(not dict(sheet.defined_names) for sheet in self.workbook))

    def test_named_variable_regions_match_tables_and_exact_semantic_headers(self):
        for key, table_name in schema.TABLE_NAMES.items():
            with self.subTest(table=key):
                sheet, bounds = self.adapter.region(schema.TABLE_RANGE_NAMES[key])
                table = sheet.tables[table_name]
                self.assertEqual(bounds, range_boundaries(table.ref))
                left, top, right, _ = bounds
                headings = tuple(sheet.cell(top, col).value for col in range(left, right + 1))
                self.assertEqual(headings, tuple(col.name for col in table.tableColumns))
                self.assertEqual(len({heading.casefold() for heading in headings}), len(headings))
                if key in schema.TABLE_COLUMNS:
                    self.assertEqual(headings, schema.TABLE_COLUMNS[key])

    def test_market_data_keeps_source_typed_values_formats_and_paste_positions(self):
        # Snapshot was read from the original reference workbook, not Trident outputs.
        source = json.loads((ROOT / 'data/reference/market_data.json').read_text(encoding='utf-8'))
        sheet = self.workbook['Market Data']
        for record in source['cells']:
            with self.subTest(cell=record['address']):
                value = record['value']
                if record['type'] == 'd':
                    value = datetime.fromisoformat(value)
                if isinstance(value, float):
                    self.assertAlmostEqual(sheet[record['address']].value, value, delta=1e-15)
                else:
                    self.assertEqual(sheet[record['address']].value, value)
                self.assertEqual(sheet[record['address']].number_format, record['number_format'])
        self.assertEqual(set(map(str, sheet.merged_cells.ranges)), set(source['merged_ranges']))
        for name, expected in (('trident_md_term_curves', 'A5:E245'),
                               ('trident_md_ois_curves', 'G5:J25'), ('trident_md_as_of', 'B3')):
            sheet, bounds = self.adapter.region(name)
            self.assertEqual((sheet.title, bounds), ('Market Data', range_boundaries(expected)))

    def test_contract_columns_include_fixed_rate_principal_and_accrued_inputs(self):
        sheet, (left, top, right, _) = self.adapter.region(schema.TABLE_RANGE_NAMES['assets'])
        headers = tuple(sheet.cell(top, column).value for column in range(left, right + 1))
        self.assertEqual(headers[:3], ('loan_id', 'asset_class', 'financing_type'))
        self.assertTrue(set(headers).issubset(set(ASSET_FIELDS) | {'is_ccc', 'is_discount', 'oc_market_price_fraction'}))
        for field in ('fixed_rate', 'payment_lag_business_days', 'acquired_accrued_interest',
                      'amortization_first_date_unadjusted', 'amortization_periods_remaining',
                      *schema.ASSET_EXTENSION_COLUMNS):
            self.assertIn(field, headers)
        self.assertEqual(len(self.table('assets')), 150)

    def test_optimizer_requires_explicit_enablement_cash_and_quotes(self):
        self.assertIs(boolean_value(self.scalar('optimizer_enabled'), 'optimizer_enabled'), False)
        self.assertEqual(self.scalar('optimizer_starting_cash'), 0)
        self.assertEqual(self.scalar('legacy_initial_reserve_funding'), 2500000)
        self.assertEqual(self.table('trade_candidates'), ())
        self.assertNotEqual(schema.SCALAR_NAMES['optimizer_starting_cash'],
                            schema.SCALAR_NAMES['legacy_initial_reserve_funding'])

    def test_factor_mapping_versions_are_text_with_explicit_synthetic_provenance(self):
        rows = self.table('factor_mapping')
        self.assertEqual(len(rows), 6)
        self.assertTrue(all(row['version'] == '1.0' for row in rows))
        self.assertTrue(all(row['is_synthetic'] is True for row in rows))
        self.assertTrue(all(row['system'] == 'TRIDENT_SYNTHETIC_TEST_FACTOR_V1' for row in rows))

    def test_baseline_cash_pay_thresholds_and_reinvestment_policy_explicit(self):
        self.assertEqual(self.scalar('mode'), 'CLO_BASELINE')
        self.assertEqual(self.scalar('legacy_reinvestment_enabled'), 'No')
        debt = {row['class_id']: row for row in self.table('capital_stack') if row['instrument_type'] == 'DEBT'}
        expected = {'A': (1.5, 1.5), 'B': (1.3, 1.4), 'C': (1.2, 1.3), 'D': (1.12, 1.2), 'E': (1.06, 1.1)}
        self.assertEqual(set(debt), set(expected))
        for class_id, (oc, ic) in expected.items():
            with self.subTest(class_id=class_id):
                self.assertEqual((debt[class_id]['oc_minimum'], debt[class_id]['ic_minimum']), (oc, ic))
                self.assertIs(boolean_value(debt[class_id]['interest_deferrable'], 'interest_deferrable'),
                              class_id in {'C', 'D', 'E'})

    def test_scenario_panel_is_separate_from_comparison_table(self):
        table_sheet, (left, top, right, bottom) = self.adapter.region(schema.TABLE_RANGE_NAMES['scenario_comparisons'])
        for key in ('scenario_enabled', 'result_scenario_status', 'result_scenario_count'):
            sheet, (column, row, _, _) = self.adapter.region(schema.SCALAR_NAMES[key])
            self.assertEqual(sheet.title, table_sheet.title)
            self.assertFalse(left <= column <= right and top <= row <= bottom)

    def test_default_scenarios_are_independent_absolute_replacements(self):
        self.assertIs(self.scalar('scenario_enabled'), True)
        self.assertEqual(self.table('scenario_edits'), (
            {'scenario_id': 'A_MARGIN_150', 'target': 'NOTE', 'identifier': 'A',
             'field': 'spread_bps', 'value': 150, 'enabled': True},
            {'scenario_id': 'SENIOR_FEE_20', 'target': 'CONTROL', 'identifier': 'DEAL',
             'field': 'senior_management_fee_bps', 'value': 20, 'enabled': True},
        ))
        self.assertEqual(self.table('principal_schedule'), ())

    def test_initial_outputs_do_not_claim_a_completed_financial_run(self):
        self.assertEqual(self.scalar('output_status'), 'NOT_RUN')
        for key in schema.OUTPUT_TABLE_KEYS:
            with self.subTest(table=key):
                self.assertEqual(self.table(key), ())


if __name__ == '__main__':
    unittest.main()
