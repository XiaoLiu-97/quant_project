"""Bind a completely settled ledger to an explicitly attested CLO opening.

The ledger's closing-day cash is a physical balance, not a collection to replay
in the next waterfall period. An operator must attest that the chosen snapshot
is after the same distribution represented by the CLO opening state. Dates
alone cannot establish that intraday ordering or ownership of future coupons.

This boundary deliberately does not project trades, create loan contracts,
allocate purchased accrued interest, initialize claims or approve legal tests.
The core opening engine separately validates the original distribution boundary,
note claims and account designations. No application service is imported here.
"""

from dataclasses import dataclass, replace
from datetime import date
from typing import TYPE_CHECKING

from trident.domain.models import InputValidationError, LoanPosition, require_date, require_money
from .models import CashBalances, HoldingStatus, HoldingsLedgerSnapshot, OpeningHolding

if TYPE_CHECKING:
    from trident.clo.models import CloOpeningState


def _source(value: object, label: str) -> None:
    """Evidence locators must be intentional text, never an inferred default."""
    if not isinstance(value, str) or not value or value != value.strip():
        raise InputValidationError(f"{label} must be nonempty unpadded text")


@dataclass(frozen=True)
class LedgerCloOpeningAttestation:
    """User-confirmed timing of one settled post-distribution ledger snapshot.

    ``post_distribution`` is mandatory and must explicitly be True. ``source``
    identifies the reconciled cash/holdings statement and distribution boundary;
    the bridge does not authenticate that statement or derive a cash cutoff.
    """

    as_of_date: date
    post_distribution: bool
    source: str

    def __post_init__(self) -> None:
        require_date(self.as_of_date, "ledger opening attestation as_of_date")
        if type(self.post_distribution) is not bool or not self.post_distribution:
            raise InputValidationError("Ledger-to-CLO bridge requires an explicit post-distribution attestation")
        _source(self.source, "ledger opening attestation source")


@dataclass(frozen=True)
class LedgerCloOpeningBridgeRequest:
    """Verified opening contracts and optional explicitly known retired IDs.

    Positive ledger holdings and ``positions`` must match one to one. A retired
    zero-par identity has no LoanPosition because that model requires positive
    par; it can remain only through ``known_zero_par_ids``. The allowlist never
    permits an unknown active asset or invents its future cashflow entitlement.
    """

    snapshot: HoldingsLedgerSnapshot
    opening_state: "CloOpeningState"
    positions: tuple[LoanPosition, ...]
    attestation: LedgerCloOpeningAttestation
    known_zero_par_ids: tuple[str, ...] = ()

    def __post_init__(self) -> None:
        # Keep the CLO import at call time so exporting this bridge from the
        # portfolio package cannot introduce an application/import cycle.
        from trident.clo.models import CloOpeningState

        if not isinstance(self.snapshot, HoldingsLedgerSnapshot):
            raise InputValidationError("Bridge snapshot must be HoldingsLedgerSnapshot")
        if not isinstance(self.opening_state, CloOpeningState):
            raise InputValidationError("Bridge opening_state must be CloOpeningState")
        if not isinstance(self.attestation, LedgerCloOpeningAttestation):
            raise InputValidationError("Bridge requires a typed post-distribution attestation")
        if type(self.positions) is not tuple or any(not isinstance(row, LoanPosition) for row in self.positions):
            raise InputValidationError("Bridge positions must be an immutable tuple of LoanPosition")
        if type(self.known_zero_par_ids) is not tuple:
            raise InputValidationError("known_zero_par_ids must be an immutable tuple")
        for identity in self.known_zero_par_ids:
            _source(identity, "known zero-par collateral identity")
        if len(set(self.known_zero_par_ids)) != len(self.known_zero_par_ids):
            raise InputValidationError("Known zero-par collateral identities must be unique")


@dataclass(frozen=True)
class LedgerCloOpeningBridgeResult:
    """An opening state plus unchanged contracts and explicit bridge evidence.

    Physical opening cash is carried once into state. There are no synthetic
    AssetCollection rows or journal receipts, and no fabricated debt funding.
    ``cash_imported`` distinguishes strict reconciliation from the deliberately
    invoked import method; neither path changes the supplied immutable objects.
    """

    opening_state: "CloOpeningState"
    positions: tuple[LoanPosition, ...]
    attestation_source: str
    cash_imported: bool


class LedgerCloOpeningBridgeService:
    """Require settled ownership and liquidity before connecting two engines."""

    def bind(self, request: LedgerCloOpeningBridgeRequest) -> LedgerCloOpeningBridgeResult:
        """Strictly reconcile authoritative CLO cash controls to the snapshot.

        Excel uses this path: a cash mismatch rejects instead of silently
        overwriting the user's opening controls or double-counting collections.
        """
        self._validate(request)
        state, cash = request.opening_state, request.snapshot.cash
        if state.principal_cash != cash.principal or state.interest_cash != cash.interest:
            raise InputValidationError("Opening CLO principal/interest cash differs from the attested settled ledger snapshot")
        return self._result(request, state, cash_imported=False)

    def import_cash(self, request: LedgerCloOpeningBridgeRequest) -> LedgerCloOpeningBridgeResult:
        """Explicitly import only physical principal and interest cash balances.

        A caller selecting this API authorizes replacement of those two fields.
        Reserve, arrears, coupon claims and within-account designations remain
        supplied facts. The opening state's own validation rejects an imported
        balance insufficient to support its preserved restricted designations.
        """
        self._validate(request)
        cash = request.snapshot.cash
        state = replace(request.opening_state, principal_cash=cash.principal, interest_cash=cash.interest)
        return self._result(request, state, cash_imported=True)

    @staticmethod
    def _result(request: LedgerCloOpeningBridgeRequest, state: "CloOpeningState", *, cash_imported: bool) -> LedgerCloOpeningBridgeResult:
        return LedgerCloOpeningBridgeResult(state, request.positions, request.attestation.source, cash_imported)

    @staticmethod
    def _validate(request: LedgerCloOpeningBridgeRequest) -> None:
        if not isinstance(request, LedgerCloOpeningBridgeRequest):
            raise TypeError("request must be LedgerCloOpeningBridgeRequest")
        snapshot, state = request.snapshot, request.opening_state
        require_date(snapshot.as_of_date, "bridge snapshot as_of_date")
        if snapshot.as_of_date != state.as_of_date or snapshot.as_of_date != request.attestation.as_of_date:
            raise InputValidationError("Ledger snapshot, post-distribution attestation and CLO opening dates must match")
        if snapshot.currency != "EUR":
            raise InputValidationError("The CLO opening bridge requires an EUR ledger; no FX conversion is inferred")

        # Snapshot records are public dataclasses. Validate their container and
        # account invariants here as well as accepting service-generated rows,
        # so a manually assembled snapshot cannot bypass the settled-only gate.
        if type(snapshot.holdings) is not tuple or any(not isinstance(row, OpeningHolding) for row in snapshot.holdings):
            raise InputValidationError("Bridge holdings must be an immutable tuple of OpeningHolding")
        if type(snapshot.pending_trades) is not tuple or snapshot.pending_trades:
            raise InputValidationError("Unsettled commitments cannot enter the CLO opening bridge")
        if type(snapshot.receivables) is not tuple or snapshot.receivables:
            raise InputValidationError("Uncollected receivables cannot enter the CLO opening bridge")
        for name in ("cash", "reserved_cash", "available_cash"):
            amounts = getattr(snapshot, name)
            if not isinstance(amounts, CashBalances):
                raise InputValidationError(f"Bridge snapshot {name} must be CashBalances")
            require_money(amounts.principal, f"bridge {name} principal")
            require_money(amounts.interest, f"bridge {name} interest")
        if snapshot.reserved_cash.principal or snapshot.reserved_cash.interest:
            raise InputValidationError("Reserved ledger cash cannot enter the CLO opening bridge")
        if snapshot.available_cash != snapshot.cash:
            raise InputValidationError("A settled bridge snapshot must have available cash equal to actual cash")
        if state.pending_interest_cash or state.pending_principal_cash or state.pending_original_principal_reinvestment_cash:
            raise InputValidationError("Pending opening CLO collection accounts require an explicit separate receipt/cutoff bridge")

        holdings = {row.asset_id: row for row in snapshot.holdings}
        positions = {row.terms.loan_id: row for row in request.positions}
        if len(holdings) != len(snapshot.holdings):
            raise InputValidationError("Bridge ledger collateral identities must be unique")
        if len(positions) != len(request.positions):
            raise InputValidationError("Bridge opening LoanPosition identities must be unique")
        retired = set(request.known_zero_par_ids)
        if retired & positions.keys():
            raise InputValidationError("An active opening position cannot also be a known zero-par identity")
        for identity, holding in holdings.items():
            if holding.currency != "EUR":
                raise InputValidationError(f"Collateral {identity}: bridge holding currency must be EUR")
            if not holding.settled_par:
                if identity not in retired:
                    raise InputValidationError(f"Collateral {identity}: zero-par identity requires an explicit known_zero_par_ids entry")
                continue
            if holding.status is HoldingStatus.DEFAULTED:
                raise InputValidationError(f"Collateral {identity}: defaulted inventory requires a separate opening credit/OC profile")
            if identity not in positions:
                raise InputValidationError(f"Collateral {identity}: unknown active ledger identity has no verified LoanPosition")
            position = positions[identity]
            if position.terms.currency != "EUR" or position.par_as_of_date != snapshot.as_of_date:
                raise InputValidationError(f"Collateral {identity}: opening loan currency/date differs from the ledger snapshot")
            if holding.settled_par != position.opening_balance:
                raise InputValidationError(f"Collateral {identity}: ledger settled par differs from opening LoanPosition par")
        active = {identity for identity, holding in holdings.items() if holding.settled_par}
        if active != positions.keys():
            raise InputValidationError("Active settled holdings and opening LoanPositions must match one to one")
