"""Independent dated bank-cash balances, floors, posting, and cut-off cases."""

import unittest
from datetime import date
from decimal import Decimal, Inexact, localcontext

from trident.clo import CashAccountAccrualMode, CloRunRequest, CloTerms, DeterministicCloEngine
from trident.conventions import DayCount
from trident.domain.models import InputValidationError
from trident.market.rates import FlatRateProvider, MissingCurveError
from test_clo import CLOSE, FIRST, SECOND, note, receipt, run


D = Decimal


class CashAccountTests(unittest.TestCase):
    def setUp(self) -> None:
        self.mid = date(2026, 2, 19)
        self.rows = (receipt("L", 1, CLOSE, self.mid, "100", "40", "2"),
                     receipt("L", 2, self.mid, FIRST, "60", "60", "5"))

    def test_receipts_earn_only_from_actual_receipt_until_distribution(self) -> None:
        projection = run(self.rows, (note(par="50"),), cash_account_accrual_mode=CashAccountAccrualMode.FIXED_SIMPLE,
                         cash_account_fixed_rate=D("0.036"))
        first = projection.periods[0]
        # Feb19 receives40 principal+2 interest, held60 actualdays.
        # Apr20 receives60principal+5interest, held0days before distribution.
        self.assertEqual(first.cash_account_interest, D("0.25"))
        self.assertEqual(first.received_asset_interest, D("7"))
        self.assertEqual(first.received_asset_principal, D("100"))
        self.assertEqual(first.equity_from_interest, D("7.25"))
        self.assertEqual(first.cash_conservation_residual, D(0))
        self.assertEqual(projection.total_cash_account_interest, D("0.25"))
        self.assertEqual(first.cash_account_all_in_rate, D("0.036"))
        self.assertIsNone(first.cash_account_fixing_date)

    def test_exact_half_cent_term_coupon_posts_away_from_zero(self) -> None:
        projection = run(self.rows, (note(par="50"),),
                         cash_account_accrual_mode=CashAccountAccrualMode.PROJECTED_TERM_SIMPLE,
                         cash_account_rate_index="EURIBOR_3M", cash_account_spread_bps=D("100"))
        # 42 ×60/360 ×(.025 +.01) =.245 exactly, therefore .25.
        first = projection.periods[0]
        self.assertEqual(first.cash_account_all_in_rate, D("0.035"))
        self.assertEqual(first.cash_account_interest, D("0.25"))
        self.assertEqual(first.cash_account_fixing_date, CLOSE)

    def test_term_fixing_uses_its_own_explicit_business_lag(self) -> None:
        projection = run(self.rows, (note(par="50"),),
                         cash_account_accrual_mode=CashAccountAccrualMode.PROJECTED_TERM_SIMPLE,
                         cash_account_rate_index="EURIBOR_3M", cash_account_fixing_lag_business_days=2)
        self.assertEqual(projection.periods[0].cash_account_fixing_date, date(2026, 1, 16))

    def test_account_floor_applies_after_spread_not_to_index_alone(self) -> None:
        terms = CloTerms(CLOSE, SECOND,
                         cash_account_accrual_mode=CashAccountAccrualMode.PROJECTED_TERM_SIMPLE,
                         cash_account_rate_index="EURIBOR_3M", cash_account_spread_bps=D("100"), cash_account_rate_floor=D(0))
        projection = DeterministicCloEngine(FlatRateProvider({"EURIBOR_3M": D("-0.05")})).run(
            CloRunRequest(self.rows, D("100"), (note(par="50"),), terms))
        self.assertEqual(projection.periods[0].cash_account_all_in_rate, D(0))
        self.assertEqual(projection.total_cash_account_interest, D(0))

    def test_negative_effective_account_rate_requires_debit_policy(self) -> None:
        terms = CloTerms(CLOSE, SECOND, cash_account_accrual_mode=CashAccountAccrualMode.FIXED_SIMPLE,
                         cash_account_fixed_rate=D("-0.01"), cash_account_rate_floor=None)
        with self.assertRaisesRegex(InputValidationError, "all-in rate"):
            DeterministicCloEngine(FlatRateProvider({})).run(CloRunRequest(self.rows, D("100"), (note(par="50"),), terms))

    def test_cash_dcf_can_differ_from_fee_and_note_dcf(self) -> None:
        projection = run(self.rows, (note(par="50"),), cash_account_accrual_mode=CashAccountAccrualMode.FIXED_SIMPLE,
                         cash_account_fixed_rate=D("0.036"), cash_account_day_count=DayCount.ACT_365F)
        # 42×.036×60/365=.24854... still .25, use a higher rate to distinguish.
        alternate = run(self.rows, (note(par="50"),), cash_account_accrual_mode=CashAccountAccrualMode.FIXED_SIMPLE,
                        cash_account_fixed_rate=D("0.36"), cash_account_day_count=DayCount.ACT_365F)
        self.assertEqual(projection.periods[0].cash_account_interest, D("0.25"))
        self.assertEqual(alternate.periods[0].cash_account_interest, D("2.49"))

    def test_restricted_reserve_never_earns_collection_account_remuneration(self) -> None:
        projection = run((receipt("L", 1, CLOSE, FIRST, "100", "100", "5"),), (note(),),
                         initial_reserve=D("100"), cash_account_accrual_mode=CashAccountAccrualMode.FIXED_SIMPLE,
                         cash_account_fixed_rate=D("0.036"))
        self.assertEqual(projection.total_cash_account_interest, D(0))
        self.assertEqual(projection.periods[0].equity_from_reserve, D("100"))

    def test_pending_post_cutoff_cash_earns_and_credit_is_available_today(self) -> None:
        friday = date(2026, 4, 17)
        projection = run((receipt("L", 1, CLOSE, friday, "100", "100", "0"),), (note(),),
                         collection_cutoff_business_days=2, cash_account_accrual_mode=CashAccountAccrualMode.FIXED_SIMPLE,
                         cash_account_fixed_rate=D("0.036"))
        first, second = projection.periods
        self.assertEqual(first.pending_principal_cash, D("100"))
        self.assertEqual(first.eligible_asset_principal, D(0))
        self.assertEqual(first.cash_account_interest, D("0.03"))
        self.assertEqual(first.equity_from_interest, D("0.03"))
        self.assertEqual(second.cash_account_interest, D("0.91"))
        self.assertEqual(second.equity_from_interest, D("0.91"))
        self.assertEqual(projection.total_cash_account_interest, D("0.94"))
        self.assertEqual(first.cash_conservation_residual, D(0))
        self.assertEqual(second.cash_conservation_residual, D(0))

    def test_retained_interest_cash_earns_on_opening_physical_balance(self) -> None:
        projection = run(
            (receipt("L", 1, CLOSE, FIRST, "100", "0.20", "40"),
             receipt("L", 2, FIRST, SECOND, "99.80", "99.80", "5")),
            (note("A", 1, "80", "0.04", oc_minimum=D("1.5")), note("B", 2, "20", "0.04")),
            interest_diversion_enabled=False, cash_account_accrual_mode=CashAccountAccrualMode.FIXED_SIMPLE,
            cash_account_fixed_rate=D("0.036"),
        )
        self.assertEqual(projection.periods[0].closing_interest_cash, D("39.20"))
        self.assertEqual(projection.periods[1].cash_account_interest, D("0.36"))

    def test_account_earning_is_in_ic_numerator_without_relabeling_asset_interest(self) -> None:
        projection = run(self.rows, (note(par="50", rate="0.04", ic_minimum=D(1)),),
                         cash_account_accrual_mode=CashAccountAccrualMode.FIXED_SIMPLE,
                         cash_account_fixed_rate=D("0.036"))
        gate = next(test for test in projection.coverage_tests if test.stage == "GATE")
        self.assertEqual(gate.ic_numerator, D("7.25"))
        self.assertEqual(projection.periods[0].eligible_asset_interest, D("7"))

    def test_no_holding_time_does_not_require_an_unneeded_curve(self) -> None:
        terms = CloTerms(CLOSE, SECOND, cash_account_accrual_mode=CashAccountAccrualMode.PROJECTED_TERM_SIMPLE,
                         cash_account_rate_index="EURIBOR_1M")
        projection = DeterministicCloEngine(FlatRateProvider({})).run(CloRunRequest(
            (receipt("L", 1, CLOSE, FIRST, "100", "100", "5"),), D("100"), (note(),), terms))
        self.assertEqual(projection.total_cash_account_interest, D(0))
        self.assertIsNone(projection.periods[0].cash_account_fixing_date)

    def test_held_cash_requires_selected_index_data(self) -> None:
        terms = CloTerms(CLOSE, SECOND, cash_account_accrual_mode=CashAccountAccrualMode.PROJECTED_TERM_SIMPLE,
                         cash_account_rate_index="EURIBOR_1M")
        with self.assertRaises(MissingCurveError):
            DeterministicCloEngine(FlatRateProvider({})).run(CloRunRequest(self.rows, D("100"), (note(),), terms))

    def test_cash_account_ignores_caller_precision_and_traps(self) -> None:
        kwargs = dict(cash_account_accrual_mode=CashAccountAccrualMode.FIXED_SIMPLE, cash_account_fixed_rate=D("0.035"))
        high = run(self.rows, (note(par="50"),), **kwargs)
        with localcontext() as context:
            context.prec = 2
            context.traps[Inexact] = True
            self.assertEqual(run(self.rows, (note(par="50"),), **kwargs), high)


class CashAccountValidationTests(unittest.TestCase):
    def test_inactive_or_incompatible_inputs_are_rejected(self) -> None:
        for kwargs in (
            {"cash_account_accrual_mode": "FIXED_SIMPLE"},
            {"cash_account_fixed_rate": D(0)}, {"cash_account_spread_bps": D(1)},
            {"cash_account_rate_floor": D(1)}, {"cash_account_fixing_lag_business_days": 1},
            {"cash_account_accrual_mode": CashAccountAccrualMode.FIXED_SIMPLE},
            {"cash_account_accrual_mode": CashAccountAccrualMode.FIXED_SIMPLE, "cash_account_fixed_rate": D(0), "cash_account_rate_index": "EURIBOR_3M"},
            {"cash_account_accrual_mode": CashAccountAccrualMode.FIXED_SIMPLE, "cash_account_fixed_rate": D(0), "cash_account_fixing_lag_business_days": 1},
            {"cash_account_accrual_mode": CashAccountAccrualMode.PROJECTED_TERM_SIMPLE, "cash_account_rate_index": "EURIBOR_3M", "cash_account_fixed_rate": D(0)},
            {"cash_account_accrual_mode": CashAccountAccrualMode.PROJECTED_TERM_SIMPLE, "cash_account_rate_index": "ESTR"},
            {"cash_account_day_count": "ACT/360"}, {"cash_account_fixing_lag_business_days": True},
        ):
            with self.subTest(kwargs=kwargs), self.assertRaises(InputValidationError):
                CloTerms(CLOSE, SECOND, **kwargs)


if __name__ == "__main__":
    unittest.main()
