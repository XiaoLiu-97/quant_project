"""Reproducible 100-par credit hand ledger, explicitly not a market deal.

Debt is 60, equity funds 40, and the entire loan defaults before its first
coupon. An actual 80 recovery redeems debt and pays 20 to equity; the remaining
20 claim is explicitly written off. No terminal asset value is invented.
"""

from datetime import date
from decimal import Decimal

from trident.analysis import AssetExposure
from trident.application.clo_services import TridentModelRequest, TridentModelResult, TridentModelService
from trident.application.services import CashflowRunRequest
from trident.clo import CloTerms, DefaultedAssetOcTreatment, NoteTranche
from trident.conventions import AccrualDateBasis, BusinessDayConvention
from trident.credit import DefaultEvent, RecoveryEvent
from trident.domain.models import CouponType, LoanPosition, LoanTerms
from trident.funding.engine import AssetPurchase, DebtIssue
from trident.market import FlatRateProvider


def credit_example_request() -> TridentModelRequest:
    """Return the explicit synthetic input so callers can inspect assumptions."""
    d, opening, recovery = Decimal, date(2026, 1, 20), date(2026, 8, 20)
    maturity = date(2027, 1, 20)
    loan = LoanTerms(
        "SYN_CREDIT_100", "EUR", opening, maturity, d(100), CouponType.FIXED,
        fixed_rate=d("0.04"), business_day_convention=BusinessDayConvention.UNADJUSTED,
        accrual_date_basis=AccrualDateBasis.UNADJUSTED,
    )
    position = LoanPosition(loan, opening, d(100))
    exposure = AssetExposure(
        loan.loan_id, "SYN_OBLIGOR", "BSL", "CORPORATE", "SYN_COUNTRY", "SYN_SECTOR",
        "EUR", d(100), None, maturity, is_senior=True, is_secured=True,
        is_pik=False, is_revolver=False, is_construction=False,
    )
    cash = CashflowRunRequest(
        (position,), (AssetPurchase(loan.loan_id, d(100), d(100)),),
        (DebtIssue("A", d(60), d(100)),), FlatRateProvider({"EURIBOR_3M": d("0.025")}),
        d(0), d(0), "SYNTHETIC_CREDIT_HAND_LEDGER_NOT_MARKET_OR_AGENCY",
    )
    terms = CloTerms(
        opening, date(2028, 1, 20), business_day_convention=BusinessDayConvention.UNADJUSTED,
        accrual_date_basis=AccrualDateBasis.UNADJUSTED,
        defaulted_asset_oc_treatment=DefaultedAssetOcTreatment.EXCLUDE,
    )
    return TridentModelRequest(
        cash, (exposure,), clo_terms=terms,
        notes=(NoteTranche("A", 1, d(60), CouponType.FIXED, fixed_rate=d(0), oc_minimum=d(1)),),
        credit_events=(DefaultEvent(loan.loan_id, date(2026, 3, 5),
                                   (RecoveryEvent(recovery, d("0.8")),), recovery),),
    )


def run_credit_example() -> TridentModelResult:
    """Run the shared application, including actual equity funding and dates."""
    return TridentModelService().run(credit_example_request())
