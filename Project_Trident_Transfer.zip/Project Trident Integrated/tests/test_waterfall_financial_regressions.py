"""Independent small cash ledgers for the CLO financial audit.

Expected monetary answers are hand specified, not obtained by calling coverage
or fee helpers from the implementation under test. Contract choices are explicit.
"""

import unittest
from dataclasses import replace
from datetime import date
from decimal import Decimal, Inexact, localcontext
from fractions import Fraction

from trident.clo import (
    CloRunRequest, CloTerms, CoverageStatus, DeterministicCloEngine,
    InterestDiversionMode, PrincipalCouponPolicy, PrincipalRepaymentMode,
    ProjectionStatus, ShortfallAccrualMethod, report_tranche_periods,
)
from trident.clo.lifecycle import EquityHurdleAccount
from trident.clo.lifecycle import AdjustedCollateralValuePolicy, OcAssetBalance, OcAssetData
from trident.clo.reinvestment import SyntheticReinvestmentPolicy
from trident.clo.engine import _NoteState
from trident.conventions import AccrualPeriod
from trident.domain.models import InputValidationError
from trident.market.rates import FlatRateProvider
from test_clo import CLOSE, FIRST, SECOND, note, receipt, run


D = Decimal
THIRD = date(2026, 10, 20)


class WaterfallFinancialAuditTests(unittest.TestCase):
    def assert_ledger(self, result):
        self.assertTrue(all(row.cash_conservation_residual == 0 for row in result.periods))
        report_tranche_periods(result)

    def test_postcutoff_par_to_cash_exchange_does_not_destroy_oc(self):
        result = run((receipt("L", 1, CLOSE, FIRST, "100", "100", "5"),),
                     (note(par="80", oc_minimum=D("1.25")),),
                     collection_cutoff_business_days=2)
        first = result.periods[0]
        gate = result.coverage_tests[0]
        self.assertEqual(first.closing_collateral_par, D(0))
        self.assertEqual(first.pending_principal_cash, D(100))
        self.assertEqual(first.eligible_asset_principal, D(0))
        self.assertEqual(gate.oc_numerator, D(100))
        self.assertIs(gate.oc_status, CoverageStatus.PASS)
        self.assertEqual(first.debt_principal_from_principal, D(0))
        self.assert_ledger(result)

    def test_pending_cash_excluded_only_when_explicit_oc_cash_switch_off(self):
        result = run((receipt("L", 1, CLOSE, FIRST, "100", "100", "5"),),
                     (note(par="80", oc_minimum=D("1.25")),),
                     collection_cutoff_business_days=2, include_principal_cash_in_oc=False)
        self.assertEqual(result.coverage_tests[0].oc_numerator, D(0))
        self.assertIs(result.coverage_tests[0].oc_status, CoverageStatus.FAIL)

    def test_call_uses_interest_residual_before_equity_is_distributed(self):
        rows = (receipt("L", 1, CLOSE, FIRST, "100", "0", "20"),
                receipt("L", 2, FIRST, SECOND, "100", "100", "0"))
        result = run(rows, (note(par="90"),), optional_call_enabled=True,
                     optional_call_date=FIRST, optional_call_collateral_sale_price=D("0.8"))
        # Actual20 interest +80 sale: debt90, equity10, no future receipt.
        self.assertEqual(len(result.periods), 1)
        self.assertEqual(result.periods[0].optional_call_status, "EXERCISED")
        self.assertEqual(result.periods[0].collateral_sale_proceeds, D(80))
        self.assertEqual(result.final_debt_par, D(0))
        self.assertEqual(result.total_equity_distributions, D(10))
        self.assert_ledger(result)

    def test_failed_call_restores_ordinary_interest_distribution(self):
        rows = (receipt("L", 1, CLOSE, FIRST, "100", "0", "5"),
                receipt("L", 2, FIRST, SECOND, "100", "100", "0"))
        result = run(rows, (note(par="90"),), optional_call_enabled=True,
                     optional_call_date=FIRST, optional_call_collateral_sale_price=D("0.8"))
        self.assertEqual(result.periods[0].optional_call_status, "INSUFFICIENT_PROCEEDS")
        self.assertEqual(result.periods[0].equity_from_interest, D(5))
        self.assertEqual(result.periods[0].collateral_sale_proceeds, D(0))
        self.assertEqual(result.total_equity_distributions, D(15))
        self.assert_ledger(result)

    def test_final_received_interest_cures_debt_without_invented_sale(self):
        result = run((receipt("L", 1, CLOSE, FIRST, "100", "100", "20"),),
                     (note(par="110"),), final=FIRST)
        # Genuinecash120 settles110 mandatory finaldebt; equity10.
        self.assertEqual(result.periods[0].debt_principal_from_interest, D(10))
        self.assertEqual(result.periods[0].debt_principal_from_principal, D(100))
        self.assertEqual(result.periods[0].collateral_sale_proceeds, D(0))
        self.assertEqual(result.total_equity_distributions, D(10))
        self.assertIs(result.status, ProjectionStatus.COMPLETED)
        self.assert_ledger(result)

    def test_final_loss_does_not_pay_equity_while_senior_debt_unpaid(self):
        rows = (receipt("L", 1, CLOSE, FIRST, "100", "0", "20"),
                receipt("L", 2, FIRST, SECOND, "100", "100", "0"))
        result = run(rows, (note(par="110"),), final=FIRST, maturity_liquidation_price=D("0.8"))
        self.assertEqual(result.final_debt_par, D(10))
        self.assertEqual(result.total_equity_distributions, D(0))
        self.assertFalse(result.terminal_value_available)
        self.assert_ledger(result)

    def test_deferrable_arrears_excluded_but_interest_on_arrears_in_ic(self):
        rows = (receipt("L", 1, CLOSE, FIRST, "100", "0", "0"),
                receipt("L", 2, FIRST, SECOND, "100", "100", "3"))
        result = run(rows, (note(par="60", rate="0.08", interest_deferrable=True, ic_minimum=D(1)),),
                     shortfall_accrual_method=ShortfallAccrualMethod.COUPON_RATE)
        self.assertFalse(result.periods[0].cash_pay_failure)
        self.assertEqual(result.tranche_periods[0].closing_coupon_arrears, D("1.20"))
        second = next(test for test in result.coverage_tests if test.period_number == 2 and test.stage == "GATE")
        # Current1.21 +intereston1.20 arrears .02; exclude deferredprincipal1.20.
        self.assertEqual(second.ic_denominator, D("1.23"))
        self.assertEqual(result.tranche_periods[1].coupon_paid_from_interest, D("2.43"))
        self.assert_ledger(result)

    def test_cash_pay_arrears_stay_in_ic_and_failure_is_not_deferral(self):
        rows = (receipt("L", 1, CLOSE, FIRST, "100", "0", "0"),
                receipt("L", 2, FIRST, SECOND, "100", "100", "3"))
        result = run(rows, (note(par="60", rate="0.08", ic_minimum=D(1)),),
                     continue_after_coupon_shortfall=True, shortfall_accrual_method=ShortfallAccrualMethod.COUPON_RATE)
        self.assertTrue(result.periods[0].cash_pay_failure)
        second = next(test for test in result.coverage_tests if test.period_number == 2 and test.stage == "GATE")
        self.assertEqual(second.ic_denominator, D("2.43"))
        self.assert_ledger(result)

    def test_explicit_legacy_ic_policy_includes_deferred_coupon_principal(self):
        rows = (receipt("L", 1, CLOSE, FIRST, "100", "0", "0"),
                receipt("L", 2, FIRST, SECOND, "100", "100", "3"))
        result = run(rows, (note(par="60", rate="0.08", interest_deferrable=True),),
                     include_deferred_interest_in_ic=True)
        second = next(test for test in result.coverage_tests if test.period_number == 2 and test.stage == "GATE")
        self.assertEqual(second.ic_denominator, D("2.41"))

    def test_junior_deferrable_coupon_cannot_deplete_senior_principal(self):
        rows = (receipt("L", 1, CLOSE, FIRST, "100", "50", "0"),
                receipt("L", 2, FIRST, SECOND, "50", "50", "3"))
        tranches = (note("A", 1, "80"), note("B", 2, "20", "0.4", interest_deferrable=True))
        result = run(rows, tranches)
        a, b = result.tranche_periods[:2]
        self.assertEqual(a.principal_from_principal, D(50))
        self.assertEqual(a.closing_balance, D(30))
        self.assertEqual(b.coupon_paid_from_principal, D(0))
        self.assertEqual(b.closing_coupon_arrears, D(2))
        self.assertFalse(result.periods[0].cash_pay_failure)
        self.assert_ledger(result)
        legacy = run(rows, tranches, principal_coupon_policy=PrincipalCouponPolicy.ALL_CLASSES)
        self.assertEqual(legacy.tranche_periods[0].principal_from_principal, D(48))
        self.assertEqual(legacy.tranche_periods[1].coupon_paid_from_principal, D(2))

    def test_controlling_deferrable_coupon_precedes_own_principal(self):
        rows = (receipt("L", 1, CLOSE, FIRST, "100", "85", "0"),
                receipt("L", 2, FIRST, SECOND, "15", "15", "5"))
        result = run(rows, (note("A", 1, "80"), note("B", 2, "20", "0.4", interest_deferrable=True)))
        a, b = result.tranche_periods[:2]
        self.assertEqual(a.principal_from_principal, D(80))
        self.assertEqual(b.coupon_paid_from_principal, D(2))
        self.assertEqual(b.principal_from_principal, D(3))
        self.assert_ledger(result)

    def test_unresolved_coverage_principal_repayment_stays_sequential(self):
        rows = (receipt("L", 1, CLOSE, FIRST, "100", "20", "1"),
                receipt("L", 2, FIRST, SECOND, "80", "80", "5"))
        result = run(rows, (note("A", 1, "80", "0.04", oc_minimum=D("1.5")), note("B", 2, "20", "0.04")),
                     principal_repayment_mode=PrincipalRepaymentMode.PRO_RATA)
        a, b = result.tranche_periods[:2]
        # Interest1 paysA .80/diverts .20; principal20 paysB .20,
        # then19.80 goes toA coveragepaydown, never to juniorB principal.
        self.assertEqual(a.principal_from_interest, D("0.20"))
        self.assertEqual(a.principal_from_principal, D("19.80"))
        self.assertEqual(b.principal_from_principal, D(0))
        self.assert_ledger(result)

    def test_authorized_reserve_fee_draw_is_in_realized_ic_numerator(self):
        rows = (receipt("L", 1, CLOSE, FIRST, "100", "100", "1"),)
        result = run(rows, (note(par="100", rate="0.04", ic_minimum=D(1)),),
                     annual_senior_expenses=D("7.3"), initial_reserve=D("1.8"))
        #90daysfee1.80, interest1 paysfees1, reserve .80, principalpayscoupon1.
        # IC1 -fee1.80 +authorizeddraw .80 =0, not negative .80.
        self.assertEqual(result.periods[0].reserve_draw, D("0.80"))
        self.assertEqual(result.coverage_tests[0].ic_numerator, D(0))
        self.assert_ledger(result)

    def test_held_interest_is_not_lost_from_next_period_ic(self):
        rows = (receipt("L", 1, CLOSE, FIRST, "100", "0", "10"),
                receipt("L", 2, FIRST, SECOND, "100", "100", "1"))
        result = run(rows, (note(par="80", rate="0.04", oc_minimum=D(2)),),
                     interest_diversion_enabled=False)
        self.assertEqual(result.periods[0].closing_interest_cash, D("9.20"))
        second = next(test for test in result.coverage_tests if test.period_number == 2 and test.stage == "GATE")
        self.assertEqual(second.ic_numerator, D("10.20"))
        self.assert_ledger(result)

    def test_minimum_interest_cure_ceil_cent_independent_fraction(self):
        rows = (receipt("L", 1, CLOSE, FIRST, "100", "0", "40"),
                receipt("L", 2, FIRST, SECOND, "100", "100", "0"))
        result = run(rows, (note(par="80", oc_minimum=D("1.5")),),
                     interest_diversion_mode=InterestDiversionMode.CURE_OC_AND_CONTINUE)
        #13.33 leaves66.67*1.5=100.005>100;13.34 leaves66.66 andpasses.
        self.assertEqual(result.coverage_tests[0].minimum_interest_repayment_for_oc, D("13.34"))
        self.assertEqual(result.periods[0].debt_principal_from_interest, D("13.34"))
        self.assert_ledger(result)

    def test_hurdle_public_methods_reject_negative_noncent_funding_and_cash(self):
        account = EquityHurdleAccount(D(100), CLOSE, D("0.1"), D("0.2"))
        for value in (D(-1), D("0.001"), D("NaN")):
            with self.subTest(value=value):
                with self.assertRaises(InputValidationError):
                    account.accrue(FIRST, value)
                with self.assertRaises(InputValidationError):
                    account.charge(value)

    def test_hurdle_charge_preserves_cent_under_low_caller_precision(self):
        account = EquityHurdleAccount(D("1e80"), CLOSE, D(0), D("0.2"))
        with localcontext() as context:
            context.prec = 5
            context.traps[Inexact] = True
            self.assertEqual(account.charge(D("0.01")), D(0))
        self.assertEqual(Fraction(account.balance), Fraction(D("1e80")) - Fraction(1, 100))

    def test_retired_class_ic_is_inactive_while_period_coupon_stays_visible(self):
        result = run((receipt("L", 1, CLOSE, FIRST, "100", "100", "1"),),
                     (note(par="80", rate="0.04", ic_minimum=D(2)),))
        end = next(test for test in result.coverage_tests if test.stage == "PERIOD_END")
        self.assertEqual(end.oc_denominator, D(0))
        self.assertEqual(end.ic_denominator, D("0.80"))
        self.assertIs(end.ic_status, CoverageStatus.NOT_APPLICABLE)


class InterestDiversionTestAuditTests(unittest.TestCase):
    def project(self, *, threshold="1.1", fraction="0.5", end=FIRST, interest="20", **kwargs):
        rows = (receipt("L", 1, CLOSE, FIRST, "100", "0", interest),
                receipt("L", 2, FIRST, SECOND, "100", "0", "0"),
                receipt("L", 3, SECOND, THIRD, "100", "100", "0"))
        return run(rows, (note(par="100"),), final=THIRD,
                   interest_diversion_test_enabled=True, interest_diversion_test_class_id="A",
                   interest_diversion_test_oc_minimum=D(threshold), interest_diversion_test_max_fraction=D(fraction),
                   interest_diversion_test_end_date=end, **kwargs)

    def test_idt_transfers_minimum_cash_to_principal_and_preserves_debt(self):
        result = self.project()
        first = result.periods[0]
        #110target -100actual =10cashnumerator increase. This is NOT
        # debtredemption100-100/1.1=9.09...; debt remains100, cash10.
        self.assertIs(first.interest_diversion_test_status, CoverageStatus.FAIL)
        self.assertEqual(first.interest_diversion_test_transferred, D(10))
        self.assertEqual(first.interest_diversion_test_held_principal, D(10))
        self.assertEqual(first.closing_principal_cash, D(10))
        self.assertEqual(first.closing_debt_par, D(100))
        self.assertEqual(first.equity_from_interest, D(10))
        self.assertEqual(first.debt_principal_from_interest + first.debt_principal_from_principal, D(0))
        self.assertEqual(result.periods[1].debt_principal_from_principal, D(10))
        self.assertTrue(all(row.cash_conservation_residual == 0 for row in result.periods))
        report_tranche_periods(result)

    def test_idt_cap_cannot_round_up_beyond_contractual_cash_fraction(self):
        result = self.project(interest="0.01", threshold="2")
        first = result.periods[0]
        #50% of onecent is halfcent, no executablecent fits the cap.
        self.assertEqual(first.interest_diversion_test_transferred, D(0))
        self.assertEqual(first.equity_from_interest, D("0.01"))

    def test_idt_cash_is_eligible_for_purchase_with_recycling_disabled(self):
        policy = SyntheticReinvestmentPolicy(True, FIRST, purchase_price=D(1),
            bullet_wal_years=D("0.25"), annual_default_rate=D(0), annual_prepayment_rate=D(0),
            recycle_reinvestment_principal=False)
        result = self.project(synthetic_reinvestment_policy=policy)
        # No original scheduled/prepaid principal exists inperiod1. Genuine
        # IDT10 nevertheless funds the explicitlyauthorized collateralpurchase.
        first = result.periods[0]
        self.assertEqual(first.interest_diversion_test_transferred, D(10))
        self.assertEqual(first.reinvestment_cash_used, D(10))
        self.assertEqual(first.reinvestment_par_acquired, D(10))
        self.assertEqual(first.interest_diversion_test_held_principal, D(0))
        self.assertEqual(first.closing_collateral_par, D(110))
        self.assertTrue(all(row.cash_conservation_residual == 0 for row in result.periods))
        report_tranche_periods(result)

    def test_idt_cure_rounds_up_and_does_not_overdivert_full_residual(self):
        result = self.project(threshold="1.10001", interest="50")
        #110.001target needs10.001, executable10.01 within25 cap.
        self.assertEqual(result.periods[0].interest_diversion_test_transferred, D("10.01"))
        self.assertEqual(result.periods[0].equity_from_interest, D("39.99"))

    def test_idt_window_and_terminal_are_not_applicable(self):
        result = self.project(end=THIRD)
        self.assertIs(result.periods[2].interest_diversion_test_status, CoverageStatus.NOT_APPLICABLE)
        self.assertEqual(result.periods[2].interest_diversion_test_held_principal, D(0))
        expired = self.project(end=FIRST)
        self.assertIs(expired.periods[1].interest_diversion_test_status, CoverageStatus.NOT_APPLICABLE)
        self.assertEqual(expired.periods[1].interest_diversion_test_held_principal, D(0))

    def test_disabled_idt_does_not_trigger_from_coverage_switch(self):
        rows = (receipt("L", 1, CLOSE, FIRST, "100", "0", "20"),
                receipt("L", 2, FIRST, SECOND, "100", "100", "0"))
        result = run(rows, (note(par="100"),), interest_diversion_enabled=True)
        self.assertIs(result.periods[0].interest_diversion_test_status, CoverageStatus.NOT_CONFIGURED)
        self.assertEqual(result.periods[0].interest_diversion_test_transferred, D(0))
        self.assertEqual(result.periods[0].equity_from_interest, D(20))

    def test_idt_invalid_terms_and_unknown_class_rejected(self):
        for fields in (
            {"interest_diversion_test_enabled": True},
            {"interest_diversion_test_max_fraction": D("1.01")},
            {"interest_diversion_test_oc_minimum": D(0)},
            {"interest_diversion_test_end_date": CLOSE},
        ):
            with self.subTest(fields=fields), self.assertRaises(InputValidationError):
                CloTerms(CLOSE, SECOND, **fields)
        with self.assertRaisesRegex(InputValidationError, "must exist"):
            terms = CloTerms(CLOSE, SECOND, interest_diversion_test_enabled=True,
                             interest_diversion_test_class_id="UNKNOWN", interest_diversion_test_oc_minimum=D("1.1"),
                             interest_diversion_test_end_date=FIRST)
            CloRunRequest((receipt("L", 1, CLOSE, FIRST, "100", "100", "0"),), D(100), (note(),), terms)


class CapitalizedDeferredInterestAuditTests(unittest.TestCase):
    """Hand ledgers isolate capitalization from face-par/cash conservation."""

    @staticmethod
    def rows(*, first_principal="0", second_interest="0", first_interest="0"):
        remaining = str(D(100) - D(first_principal))
        return (
            receipt("L", 1, CLOSE, FIRST, "100", first_principal, first_interest),
            receipt("L", 2, FIRST, SECOND, remaining, "0", second_interest),
            receipt("L", 3, SECOND, THIRD, remaining, remaining, "0"),
        )

    @staticmethod
    def tranches(*, deferrable=True):
        # Synthetic 100% annual B coupon gives exactly10 on40 over90/360.
        return (note("A", 1, "50", oc_minimum=D("1.1")),
                note("B", 2, "40", "1", interest_deferrable=deferrable, oc_minimum=D("1.1")))

    @staticmethod
    def coverage(result, *, period=1, stage="GATE", class_id="B"):
        return next(row for row in result.coverage_tests
                    if row.period_number == period and row.stage == stage and row.class_id == class_id)

    def test_current_deferral_enters_own_gate_and_minimum_cure_rounds_up(self):
        result = run(self.rows(), self.tranches(), final=THIRD)
        senior = self.coverage(result, class_id="A")
        junior = self.coverage(result)
        # N100 / (par90 + deferred10) =1, not100/90=1.111...PASS.
        self.assertEqual(senior.oc_denominator, D(50))
        self.assertEqual(junior.oc_numerator, D(100))
        self.assertEqual(junior.oc_denominator, D(100))
        self.assertEqual(junior.oc_ratio, D(1))
        self.assertIs(junior.oc_status, CoverageStatus.FAIL)
        # Debt reduction: 100 -100/1.1 =9.0909...; required executable9.10.
        self.assertEqual(junior.minimum_interest_repayment_for_oc, D("9.10"))
        self.assertEqual(result.periods[0].closing_debt_par, D(90))
        self.assertEqual(result.periods[0].note_coupon_unpaid, D(10))
        self.assertEqual(result.periods[0].debt_principal_from_interest, D(0))
        self.assertTrue(all(row.cash_conservation_residual == 0 for row in result.periods))
        report_tranche_periods(result)

    def test_explicit_noncapitalizing_sensitivity_preserves_par_only(self):
        result = run(self.rows(), self.tranches(), final=THIRD,
                     include_deferred_interest_in_oc=False)
        gate = self.coverage(result)
        self.assertEqual(gate.oc_denominator, D(90))
        self.assertIs(gate.oc_status, CoverageStatus.PASS)
        self.assertEqual(gate.minimum_interest_repayment_for_oc, D(0))
        self.assertEqual(result.periods[0].closing_debt_par, D(90))
        self.assertEqual(result.periods[0].note_coupon_unpaid, D(10))

    def test_cash_pay_delinquency_is_not_capitalized_deferrable_principal(self):
        result = run(self.rows(), self.tranches(deferrable=False), final=THIRD,
                     continue_after_coupon_shortfall=True)
        self.assertEqual(self.coverage(result).oc_denominator, D(90))
        self.assertIs(self.coverage(result).oc_status, CoverageStatus.PASS)
        self.assertTrue(result.periods[0].cash_pay_failure)
        self.assertEqual(result.periods[0].note_coupon_unpaid, D(10))

    def test_interest_payment_removes_opening_and_current_deferred_claim_once(self):
        result = run(self.rows(second_interest="20.11"), self.tranches(), final=THIRD)
        second = self.coverage(result, period=2)
        # Opening10 + secondcoupon10.11 paid20.11: face90, no capitalizedclaim.
        self.assertEqual(result.tranche_periods[3].coupon_paid_from_interest, D("20.11"))
        self.assertEqual(result.tranche_periods[3].closing_coupon_arrears, D(0))
        self.assertEqual(second.oc_denominator, D(90))
        self.assertEqual(second.ic_denominator, D("10.11"))
        self.assertIs(second.oc_status, CoverageStatus.PASS)
        report_tranche_periods(result)

    def test_partial_interest_payment_uses_actual_updated_deferred_claim(self):
        result = run(self.rows(second_interest="5"), self.tranches(), final=THIRD)
        second = self.coverage(result, period=2)
        # Opening10 + current10.11 - actualpayment5 =15.11, not opening10.
        self.assertEqual(result.tranche_periods[3].closing_coupon_arrears, D("15.11"))
        self.assertEqual(second.oc_denominator, D("105.11"))
        self.assertEqual(second.minimum_interest_repayment_for_oc, D("14.21"))
        self.assertEqual(second.ic_denominator, D("10.11"))

    def test_principal_paid_deferral_reduces_cash_and_coverage_debt_not_face_twice(self):
        result = run(self.rows(first_principal="20"), self.tranches(), final=THIRD,
                     principal_coupon_policy=PrincipalCouponPolicy.ALL_CLASSES)
        gate, end = self.coverage(result), self.coverage(result, stage="PERIOD_END")
        self.assertEqual(gate.oc_numerator, D(100))
        self.assertEqual(gate.oc_denominator, D(100))
        # Principal20 pays Bclaim10 + Aface10; asset80/cash0 and face80/claims0.
        self.assertEqual(result.tranche_periods[1].coupon_paid_from_principal, D(10))
        self.assertEqual(result.tranche_periods[0].principal_from_principal, D(10))
        self.assertEqual(result.periods[0].closing_debt_par, D(80))
        self.assertEqual(end.oc_numerator, D(80))
        self.assertEqual(end.oc_denominator, D(80))
        self.assertEqual(result.periods[0].note_coupon_unpaid, D(0))
        self.assertTrue(all(row.cash_conservation_residual == 0 for row in result.periods))
        report_tranche_periods(result)

    def test_post_diversion_snapshot_includes_blocked_deferrable_claims(self):
        tranches = (note("A", 1, "50", oc_minimum=D("2.2")), self.tranches()[1])
        result = run(self.rows(first_interest="10"), tranches, final=THIRD)
        # A gatefails, interest10 repays Aface; blocked Bcoupon10 remains owed.
        self.assertEqual(result.tranche_periods[0].principal_from_interest, D(10))
        self.assertEqual(result.tranche_periods[1].closing_coupon_arrears, D(10))
        self.assertEqual(self.coverage(result, stage="POST_DIVERSION").oc_denominator, D(90))
        self.assertEqual(self.coverage(result, stage="PERIOD_END").oc_denominator, D(90))

    def test_independent_idt_uses_capitalized_amount_and_no_fabricated_transfer(self):
        for capitalizing, denominator, status in (
            (True, D(100), CoverageStatus.FAIL),
            (False, D(90), CoverageStatus.PASS),
        ):
            with self.subTest(capitalizing=capitalizing):
                result = run(self.rows(), self.tranches(), final=THIRD,
                             coverage_tests_enabled=False,
                             include_deferred_interest_in_oc=capitalizing,
                             interest_diversion_test_enabled=True,
                             interest_diversion_test_class_id="B",
                             interest_diversion_test_oc_minimum=D("1.1"),
                             interest_diversion_test_end_date=FIRST)
                row = result.periods[0]
                self.assertEqual(row.interest_diversion_test_oc_numerator, D(100))
                self.assertEqual(row.interest_diversion_test_oc_denominator, denominator)
                self.assertIs(row.interest_diversion_test_status, status)
                self.assertEqual(row.interest_diversion_test_transferred, D(0))
                if capitalizing:
                    self.assertEqual(row.interest_diversion_test_oc_ratio, D(1))
                    # Gap10 remains unfunded because no residual interest exists.
                    self.assertEqual(row.interest_diversion_test_oc_minimum, D("1.1"))

    def test_zero_face_with_deferred_claim_has_live_coverage_outstanding(self):
        # Direct component state covers outstanding claims at zero face, which
        # the current new-issue interface cannot supply as opening coupon debt.
        state = _NoteState(note(par="10", interest_deferrable=True,
                                oc_minimum=D("1.1"), ic_minimum=D(1)), D(0), D(10))
        period = AccrualPeriod(1, CLOSE, FIRST, CLOSE, FIRST, FIRST, CLOSE)
        for capitalizing, expected in ((True, D(10)), (False, D(0))):
            with self.subTest(capitalizing=capitalizing):
                outstanding = DeterministicCloEngine._oc_outstanding([state], 0, [D(10)],
                    include_deferred_interest=capitalizing)
                self.assertEqual(outstanding, expected)  # Same base used by IDT.
                result = DeterministicCloEngine._coverage([state], 0, period, "GATE",
                    D(5), D(0), D(3), (D("2.50"),), unpaid_coupon_claims=[D(10)],
                    include_deferred_interest=capitalizing)
                self.assertEqual(result.oc_denominator, expected)
                if capitalizing:
                    self.assertIs(result.oc_status, CoverageStatus.FAIL)
                    self.assertEqual(result.minimum_interest_repayment_for_oc, D("5.46"))
                    self.assertIs(result.ic_status, CoverageStatus.PASS)
                else:
                    self.assertIs(result.oc_status, CoverageStatus.NOT_APPLICABLE)

        cash_pay_state = _NoteState(note(par="10", interest_deferrable=False), D(0), D(10))
        self.assertEqual(DeterministicCloEngine._oc_outstanding([cash_pay_state], 0, [D(10)],
            include_deferred_interest=True), D(0))

    def test_capitalization_switch_rejects_untyped_values(self):
        self.assertTrue(CloTerms(CLOSE, SECOND).include_deferred_interest_in_oc)
        for invalid in (None, 0, 1, "TRUE"):
            with self.subTest(invalid=invalid), self.assertRaises(InputValidationError):
                CloTerms(CLOSE, SECOND, include_deferred_interest_in_oc=invalid)


class AdjustedOcFinancialAuditTests(unittest.TestCase):
    def test_ccc_selection_uses_current_market_and_not_acquisition_price(self):
        policy = AdjustedCollateralValuePolicy(True, ccc_limit_fraction=D("0.1"), ccc_valuation=D("0.99"))
        assets = (
            OcAssetBalance("A", D(20), FIRST, OcAssetData("A", True, False, D("0.95"), D("0.5"))),
            OcAssetBalance("B", D(20), FIRST, OcAssetData("B", True, False, D("0.6"), D("0.9"))),
            OcAssetBalance("C", D(60), FIRST, OcAssetData("C")),
        )
        value = policy.value(assets, D(100), D(0), SECOND)
        #CCCexcess30: allA20@50% +B10@90%; Bother10@par +C60@par=89.
        # Acquisition prices reverse the ranking and cannot establish CCCvalue.
        self.assertEqual(value.ccc_haircut, D(11))
        self.assertEqual(value.collateral_value, D(89))

    def test_ccc_missing_current_mark_fails_instead_of_using_acquisition(self):
        policy = AdjustedCollateralValuePolicy(True, ccc_limit_fraction=D("0.1"))
        assets = (OcAssetBalance("A", D(100), FIRST, OcAssetData("A", True, False, D("0.5"))),)
        with self.assertRaisesRegex(InputValidationError, "current market_price_fraction"):
            policy.value(assets, D(100), D(0), SECOND)

    def test_ccc_with_no_excess_needs_no_inactive_market_mark(self):
        policy = AdjustedCollateralValuePolicy(True, ccc_limit_fraction=D(1))
        assets = (OcAssetBalance("A", D(100), FIRST, OcAssetData("A", True)),)
        self.assertEqual(policy.value(assets, D(100), D(0), SECOND).collateral_value, D(100))

    def test_ccc_discount_longdated_overlap_takes_lowest_value_once(self):
        policy = AdjustedCollateralValuePolicy(True, ccc_limit_fraction=D("0.1"), long_dated_valuation=D("0.7"))
        assets = (
            OcAssetBalance("A", D(50), THIRD, OcAssetData("A", True, True, D("0.6"), D("0.5"))),
            OcAssetBalance("B", D(50), FIRST, OcAssetData("B")),
        )
        value = policy.value(assets, D(100), D(0), SECOND)
        #SelectedA40@.50 +unselectedA10@.60 +ordinaryB50=76.
        self.assertEqual(value.collateral_value, D(76))
        self.assertEqual(value.ccc_haircut, D(20))
        self.assertEqual(value.discount_haircut, D(20))
        self.assertEqual(value.long_dated_haircut, D(15))
        self.assertEqual(value.overlap_credit, D(31))


if __name__ == "__main__":
    unittest.main()
