"""Independent named-Excel controls for a post-distribution existing CLO.

Original Jan-Apr coupons have already been distributed. The next 91-day asset
coupon is 100*12%*91/360=3.03 and the note coupon is 80*6%*91/360=1.21.
Opening cash is 5 principal, 2 interest and 1 reserve. After paying .40 historic
coupon and .38 fees, final equity receives 29.04. These amounts are hand ledger
controls, not numbers copied from model output.
"""

from datetime import date
from decimal import Decimal as D
from pathlib import Path
import tempfile
import unittest

from openpyxl import load_workbook
from trident.adapters.excel import NamedWorkbook, run_workbook
from trident.adapters.excel_model import execute_model_workbook, read_model_workbook_inputs
from trident.adapters.pilot_workbook import ensure_pilot_interface, check_model_workbook
from trident.adapters.clo_opening_records import ACCOUNT_FIELDS, FEE_FIELDS
from trident.adapters import excel_schema as schema
from trident.domain.models import InputValidationError
from workbook_fixtures import copy_input_template, put_records, hand_controls, write_controls

OPEN = date(2026, 4, 1)
PAY = date(2026, 7, 1)
SOURCE = 'Independent trustee post-distribution hand control'


class ExistingCloWorkbookTests(unittest.TestCase):
    def setUp(self):
        folder = tempfile.TemporaryDirectory()
        self.addCleanup(folder.cleanup)
        self.path = Path(folder.name) / 'existing.xlsx'
        copy_input_template(self.path)
        book = load_workbook(self.path)
        try:
            adapter = NamedWorkbook(book)
            ensure_pilot_interface(adapter)
            asset = dict(self.table(adapter, 'assets')[0])
            asset.update(loan_id='L', initial_par=100, current_par=100,
                cashflow_projection_start_date=date(2026, 1, 1), par_as_of_date=OPEN,
                maturity_date_unadjusted=PAY, schedule_anchor_day=1,
                frequency_months=3, day_count='ACT/360', business_day_convention='UNADJUSTED',
                accrual_date_basis='UNADJUSTED', fixing_lag_target_business_days=0,
                coupon_type='FIXED', fixed_rate=.12, rate_index=None, spread_bps=0,
                index_floor_bps=None, reset_frequency_months=None, index_cap_bps=None,
                all_in_floor_bps=None, all_in_cap_bps=None, amortization_type='BULLET',
                amortization_fraction_initial_par_per_period=0,
                amortization_first_date_unadjusted=None, amortization_periods_remaining=None,
                scheduled_principal_amount=None, amortization_growth=None, balloon_amount=None,
                first_payment_date_unadjusted=None, last_regular_payment_date_unadjusted=None,
                acquired_accrued_interest=0, payment_lag_business_days=0)
            capital = self.table(adapter, 'capital_stack')
            debt = dict(next(row for row in capital if row['instrument_type'] == 'DEBT'))
            debt.update(class_id='A', nominal_amount=80, issue_price_pct=100,
                coupon_type='FIXED', fixed_rate=.06, rate_index=None, spread_bps=0,
                index_floor_bps=None, oc_minimum=None, ic_minimum=None)
            equity = dict(next(row for row in capital if row['instrument_type'] == 'EQUITY'))
            equity.update(class_id='EQUITY', nominal_amount=20)
            for key in schema.INPUT_TABLE_KEYS:
                if key not in {'assets', 'capital_stack', 'factor_mapping'}:
                    put_records(adapter, key, ())
            put_records(adapter, 'assets', (asset,))
            put_records(adapter, 'capital_stack', (debt, equity))
            controls = hand_controls((asset,), (debt, equity), closing_date=date(2026, 1, 1),
                first_payment_date=OPEN, legal_final_date=PAY, reserve=1)
            controls.update(legacy_payment_date_convention='Unadjusted', clo_accrual_date_basis='UNADJUSTED',
                legacy_rate_fixing_lag=0, legacy_determination_lag=0)
            write_controls(adapter, controls)
            put_records(adapter, 'seasoned_positions', ({'scope': 'ASSET', 'loan_id': 'L',
                'opening_accrued_interest': 0, 'entitlement_policy': 'FULL_CURRENT_PERIOD', 'source': SOURCE},))
            put_records(adapter, 'clo_opening', ({'as_of_date': OPEN, 'timing': 'POST_DISTRIBUTION',
                'forward_equity_value': 20, 'equity_value_source': 'Independent equity bid value',
                'use_ledger_snapshot': False, 'source': SOURCE},))
            cash = {'PRINCIPAL': 5, 'INTEREST': 2, 'RESERVE': 1}
            put_records(adapter, 'clo_opening_accounts', tuple({'account': key, 'balance': cash.get(key, 0),
                'source': SOURCE} for key in ACCOUNT_FIELDS))
            fees = {'SENIOR_EXPENSES': .20, 'SENIOR_MANAGEMENT': .10,
                    'SUBORDINATED_MANAGEMENT': .05, 'DEFERRED_SENIOR_EXPENSES': .03}
            put_records(adapter, 'clo_opening_claims', (
                {'claim_type': 'NOTE_COUPON', 'class_id': 'A', 'amount': .40, 'source': SOURCE},
                *({'claim_type': key, 'amount': fees[key], 'source': SOURCE} for key in FEE_FIELDS)))
            book.save(self.path)
        finally:
            book.close()

    @staticmethod
    def table(adapter, key):
        return adapter.table_records(schema.TABLE_RANGE_NAMES[key], schema.TABLE_NAMES[key])

    def access(self, function, *, save=False):
        book = load_workbook(self.path)
        try:
            value = function(NamedWorkbook(book))
            if save:
                book.save(self.path)
            return value
        finally:
            book.close()

    def edit_row(self, key, **updates):
        self.access(lambda adapter: put_records(adapter, key, (
            {**self.table(adapter, key)[0], **updates}, *self.table(adapter, key)[1:])), save=True)

    def test_original_grid_claims_cash_and_forward_value(self):
        result = self.access(execute_model_workbook)
        self.assertIsNone(result.cashflows.funding)
        self.assertEqual(len(result.clo.periods), 1)
        self.assertEqual(result.clo.periods[0].period_number, 2)
        note = result.clo.tranche_periods[0]
        self.assertEqual((note.current_coupon_due, note.opening_coupon_arrears), (D('1.21'), D('.40')))
        self.assertEqual(result.clo.total_equity_distributions, D('29.04'))
        self.assertEqual(result.equity_cashflows[0].payment_date, OPEN)
        self.assertEqual(result.equity_cashflows[0].amount, D('-20'))
        self.assertEqual(result.equity_moic.value, D('1.452'))

    def test_named_reports_saved_fresh_and_readonly(self):
        run_workbook(self.path)
        def assertions(adapter):
            self.assertEqual(self.table(adapter, 'funding_summary'), ())
            self.assertEqual(self.table(adapter, 'equity_cashflows')[0]['source'], 'CURRENT_EQUITY_VALUE')
            self.assertEqual(self.table(adapter, 'run_audit')[0]['scope'], 'EXISTING_CLO_POST_DISTRIBUTION')
            self.assertEqual(len(self.table(adapter, 'clo_opening_audit')), 14)
            self.assertIsNone(adapter.scalar(schema.SCALAR_NAMES['result_debt_proceeds']))
        self.access(assertions)
        before = self.path.read_bytes()
        self.assertEqual(check_model_workbook(self.path)['saved_results'], 'CURRENT')
        self.assertEqual(self.path.read_bytes(), before)

    def test_missing_zero_account_rejected_atomically(self):
        self.access(lambda adapter: put_records(adapter, 'clo_opening_accounts',
            self.table(adapter, 'clo_opening_accounts')[:-1]), save=True)
        before = self.path.read_bytes()
        with self.assertRaises(InputValidationError):
            run_workbook(self.path)
        self.assertEqual(self.path.read_bytes(), before)

    def test_unknown_coupon_class_rejected_before_projection(self):
        self.edit_row('clo_opening_claims', class_id='UNKNOWN')
        with self.assertRaisesRegex(InputValidationError, 'coupon class'):
            self.access(read_model_workbook_inputs)

    def test_closing_cost_not_recharged(self):
        self.access(lambda adapter: adapter.write_scalar(schema.SCALAR_NAMES['legacy_other_upfront_costs'], 1), save=True)
        with self.assertRaisesRegex(InputValidationError, 'closing costs'):
            self.access(execute_model_workbook)

    def test_zero_face_live_claim_preserved(self):
        self.edit_row('capital_stack', nominal_amount=0)
        self.access(lambda adapter: adapter.write_scalar(schema.SCALAR_NAMES['legacy_clo_size'], 20), save=True)
        result = self.access(execute_model_workbook)
        self.assertEqual(result.clo.tranche_periods[0].opening_balance, D(0))
        self.assertEqual(result.clo.tranche_periods[0].current_coupon_due, D(0))
        self.assertEqual(result.clo.total_equity_distributions, D('110.25'))

    def test_forward_valuation_required(self):
        self.edit_row('clo_opening', forward_equity_value=None)
        with self.assertRaises(InputValidationError):
            self.access(read_model_workbook_inputs)

    def test_midperiod_rejected_atomically(self):
        self.edit_row('clo_opening', as_of_date=date(2026, 4, 2))
        before = self.path.read_bytes()
        with self.assertRaises(InputValidationError):
            run_workbook(self.path)
        self.assertEqual(self.path.read_bytes(), before)

    def test_closing_optimizer_rejected_before_projection(self):
        self.access(lambda adapter: adapter.write_scalar(schema.SCALAR_NAMES['optimizer_enabled'], True), save=True)
        with self.assertRaisesRegex(InputValidationError, 'disabled'):
            self.access(read_model_workbook_inputs)

    def test_independent_opening_and_forward_benchmarks(self):
        rows = (
            dict(observation_date=OPEN, entity_type='CLO_OPENING', entity_id='PRINCIPAL',
                 metric='ACCOUNT', stage='POST_DISTRIBUTION', expected=5, tolerance=0,
                 unit='EUR', source=SOURCE, reference_id='BANK_PRINCIPAL'),
            dict(observation_date=OPEN, entity_type='SCALAR', entity_id='DEAL',
                 metric='result_equity_distributions', stage='BASELINE', expected=29.04, tolerance=0,
                 unit='EUR', source=SOURCE, reference_id='FINAL_CASH_HAND_LEDGER'),
        )
        self.access(lambda adapter: put_records(adapter, 'benchmarks', rows), save=True)
        before = self.path.read_bytes()
        report = check_model_workbook(self.path, project=True, require_reconciliation=True)
        self.assertEqual(report['reconciliation'], 'MATCH')
        self.assertEqual(self.path.read_bytes(), before)

    def test_ledger_settled_snapshot_initializes_same_waterfall(self):
        def edit(adapter):
            put_records(adapter, 'ledger_controls', ({'as_of_date': OPEN, 'horizon_date': OPEN,
                'currency': 'EUR', 'principal_cash': 5, 'interest_cash': 2,
                'allow_principal_for_accrued': False, 'allow_principal_for_fees': False, 'source': SOURCE},))
            put_records(adapter, 'opening_holdings', ({'asset_id': 'L', 'currency': 'EUR', 'settled_par': 100,
                'status': 'PERFORMING'},))
        self.access(edit, save=True)
        self.edit_row('clo_opening', use_ledger_snapshot=True)
        result = self.access(execute_model_workbook)
        self.assertEqual(result.clo.total_equity_distributions, D('29.04'))
        self.access(lambda adapter: put_records(adapter, 'opening_holdings', ({'asset_id': 'L',
            'currency': 'EUR', 'settled_par': 99, 'status': 'PERFORMING'},)), save=True)
        with self.assertRaises(InputValidationError):
            self.access(read_model_workbook_inputs)

    def test_actual_settled_buy_becomes_opening_holdings_once(self):
        def edit(adapter):
            put_records(adapter, 'ledger_controls', ({'as_of_date': OPEN, 'horizon_date': OPEN,
                'currency': 'EUR', 'principal_cash': 105, 'interest_cash': 2,
                'allow_principal_for_accrued': False, 'allow_principal_for_fees': False, 'source': SOURCE},))
            put_records(adapter, 'opening_holdings', ())
            put_records(adapter, 'trade_ledger', ({'trade_id': 'SETTLED_BUY', 'asset_id': 'L',
                'side': 'BUY', 'trade_date': OPEN, 'settlement_date': OPEN, 'par': 100,
                'clean_price_pct': 100, 'accrued_cash': 0, 'fees_cash': 0,
                'accrued_account': 'INTEREST', 'fee_account': 'INTEREST', 'minimum_ticket': 0},))
        self.access(edit, save=True)
        self.edit_row('clo_opening', use_ledger_snapshot=True)
        result = self.access(execute_model_workbook)
        self.assertEqual(result.clo.periods[0].opening_principal_cash, D(5))
        self.assertEqual(result.clo.total_equity_distributions, D('29.04'))


if __name__ == '__main__':
    unittest.main()
