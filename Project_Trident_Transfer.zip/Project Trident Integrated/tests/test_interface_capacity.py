"""Capacity reserves preserve input identity, blank semantics and live catalogues.

Small synthetic Tables isolate presentation changes from CLO assumptions.
Input fingerprints are checked through the ordinary reader, rather than an
implementation-specific capacity counter. Collision fixtures exercise hidden
regions as well as visible cells before any source file is published.
"""
from copy import deepcopy
from pathlib import Path
from tempfile import TemporaryDirectory
import unittest
import xml.etree.ElementTree as ET

from openpyxl import Workbook, load_workbook
from openpyxl.styles import Alignment, Font, PatternFill
from openpyxl.worksheet.table import Table, TableColumn
from openpyxl.worksheet.datavalidation import DataValidation
from openpyxl.workbook.defined_name import DefinedName

from trident.adapters.interface_capacity import (
    ASSET_OPTIONS_NAME, ASSET_OPTIONS_TABLE, InputCapacityPolicy,
    prepare_input_capacity, refresh_asset_id_options,
)
from trident.adapters.interface_inputs import read_interface_inputs
from trident.adapters.interface_package import WorkbookPackage, TABLE_PREFIX, UI_PREFIX, _tag
from trident.domain.models import InputValidationError
from test_interface_inputs import workbook_fixture


class InterfaceCapacityTests(unittest.TestCase):
    def setUp(self):
        self.temporary = TemporaryDirectory()
        self.addCleanup(self.temporary.cleanup)
        self.root = Path(self.temporary.name)
        self.source = self.root / "input.xlsx"
        self.policy = InputCapacityPolicy(asset_rows=4, rating_rows=8,
            principal_schedule_rows=9, asset_event_rows=10)

    def _fixture(self, *, witness=False):
        workbook = workbook_fixture()
        workbook.defined_names.add(DefinedName(UI_PREFIX + "asset_ids", attr_text=TABLE_PREFIX + "assets[Asset ID]"))
        workbook.defined_names.add(DefinedName(UI_PREFIX + "asset_obligors", attr_text=TABLE_PREFIX + "assets[Obligor ID]"))
        # The input style deliberately differs from an output style: expansion
        # must preserve it, including the numeric/date format and input fill.
        table = workbook["asset_terms"].tables[TABLE_PREFIX + "asset_terms"]
        column = [c.name for c in table.tableColumns].index("Spread (bps)") + 1
        cell = workbook["asset_terms"].cell(2, column)
        cell.font = Font(name="Arial", color="0000FF")
        cell.alignment = Alignment(horizontal="center", vertical="center")
        cell.number_format = "0.0"
        cell.fill = PatternFill("solid", fgColor="EAF2F8")
        validation = DataValidation(type="list", formula1=UI_PREFIX + "asset_ids",
            errorStyle="stop", showErrorMessage=True, allow_blank=True)
        validation.add("A2:A2000")
        workbook["asset_terms"].add_data_validation(validation)
        if witness:
            source = workbook["assets"]
            frozen = workbook.create_sheet("_Lists")
            frozen.sheet_state = "hidden"
            headers = [cell.value for cell in source[1]]
            for row in source.iter_rows(min_row=1, max_row=3, max_col=len(headers)):
                frozen.append([cell.value for cell in row])
            ftable = Table(displayName=TABLE_PREFIX + "frozen_assets", ref=source.tables[TABLE_PREFIX + "assets"].ref)
            ftable.tableColumns = [TableColumn(id=i, name=header) for i, header in enumerate(headers, 1)]
            frozen.add_table(ftable)
            workbook.defined_names.add(DefinedName(UI_PREFIX + "fresh_current_asset_identity_1", attr_text="'assets'!$A$2:$B$3"))
            workbook.defined_names.add(DefinedName(UI_PREFIX + "fresh_saved_asset_identity_1", attr_text="'_Lists'!$A$2:$B$3"))
        workbook.save(self.source)
        workbook.close()
        return WorkbookPackage(self.source, protected_tables=tuple(TABLE_PREFIX + name for name in self.policy.table_rows))

    def test_blank_capacity_preserves_typed_snapshot_and_financial_input_fingerprint(self):
        package = self._fixture()
        before = read_interface_inputs(self.source)
        expanded = prepare_input_capacity(package, self.policy)
        target = package.save(self.root / "reserved.xlsx")
        after = read_interface_inputs(target)
        self.assertEqual(before.input_snapshot, after.input_snapshot)
        self.assertEqual(before.input_fingerprint, after.input_fingerprint)
        self.assertEqual(len(after.request.cashflow_request.positions), 2)
        self.assertIn(TABLE_PREFIX + "assets", expanded)
        self.assertEqual(package.table_inventory()[TABLE_PREFIX + "assets"].bounds[3], 5)
        self.assertEqual(package.table_inventory()[TABLE_PREFIX + "asset_ratings"].bounds[3], 9)
        self.assertEqual(package.table_inventory()[TABLE_PREFIX + "principal_schedule"].bounds[3], 10)
        self.assertEqual(package.table_inventory()[TABLE_PREFIX + "asset_events"].bounds[3], 11)

    def test_new_rows_are_styles_only_and_original_input_cells_are_identical(self):
        package = self._fixture()
        info = package.table_inventory()[TABLE_PREFIX + "asset_terms"]
        cells = package._sheet_cells(package._xml(package._sheet_parts()[info.sheet]))
        original = {address: ET.tostring(cell) for address, cell in cells.items()}
        original_metadata = deepcopy(package._xml(info.part))
        prepare_input_capacity(package, self.policy)
        after = package._sheet_cells(package._xml(package._sheet_parts()[info.sheet]))
        for address, xml in original.items():
            self.assertEqual(ET.tostring(after[address]), xml)
        for address, cell in after.items():
            if address not in original:
                self.assertFalse(list(cell), address)
        spread = info.headers.index("Spread (bps)") + 1
        from openpyxl.utils.cell import get_column_letter
        col = get_column_letter(spread)
        self.assertEqual(after[col + "4"].attrib["s"], after[col + "2"].attrib["s"])
        current_metadata = deepcopy(package._xml(info.part))
        current_metadata.set("ref", original_metadata.attrib["ref"])
        for child in current_metadata:
            if child.tag == _tag("autoFilter"):
                child.set("ref", original_metadata.attrib["ref"])
        self.assertEqual(ET.tostring(original_metadata), ET.tostring(current_metadata))

    def test_second_preparation_retains_same_shapes_values_and_formulae(self):
        package = self._fixture()
        prepare_input_capacity(package, self.policy)
        once = {name: info.ref for name, info in package.table_inventory().items()}
        inputs = ET.tostring(package._xml(package._sheet_parts()["assets"]))
        options = package._table_records(ASSET_OPTIONS_TABLE)
        self.assertEqual(prepare_input_capacity(package, self.policy), ())
        self.assertEqual({name: info.ref for name, info in package.table_inventory().items()}, once)
        self.assertEqual(ET.tostring(package._xml(package._sheet_parts()["assets"])), inputs)
        self.assertEqual(package._table_records(ASSET_OPTIONS_TABLE), options)

    def test_full_aliases_and_witness_shapes_follow_reserve_but_input_axes_match(self):
        package = self._fixture(witness=True)
        original_axis = package._names()[UI_PREFIX + "asset_ids"].text
        prepare_input_capacity(package, self.policy)
        self.assertEqual(package.named_region(UI_PREFIX + "assets")[1], (1, 1, 11, 5))
        self.assertEqual(package.named_region(UI_PREFIX + "fresh_current_asset_identity_1")[1], (1, 2, 2, 5))
        self.assertEqual(package.named_region(UI_PREFIX + "fresh_saved_asset_identity_1")[1], (1, 2, 2, 5))
        self.assertEqual(package.table_inventory()[TABLE_PREFIX + "frozen_assets"].bounds[3], 5)
        self.assertEqual(package._names()[UI_PREFIX + "asset_ids"].text, original_axis)
        ids = package.named_region(UI_PREFIX + "asset_ids")[1]
        obligors = package.named_region(UI_PREFIX + "asset_obligors")[1]
        self.assertEqual(ids[3] - ids[1], obligors[3] - obligors[1])

    def test_live_id_catalogue_is_compact_across_gaps_and_keeps_stop_validation(self):
        package = self._fixture()
        prepare_input_capacity(package, self.policy)
        # A new identity in a later reserved row is live in the catalogue;
        # blanks in the source axis must never hide a later valid identifier.
        package._replace_cells("assets", {"A5": package._cell("A5", "NEW_ASSET", 0)})
        info = refresh_asset_id_options(package)
        rows = package._table_records(info.name)
        self.assertEqual([r["Asset ID"] for r in rows], ["I", "B", "NEW_ASSET", ""])
        self.assertEqual([r["Active sequence"] for r in rows], [1.0, 2.0, "", 3.0])
        definition = package._names()[ASSET_OPTIONS_NAME].text
        self.assertIn('COUNTIF(tbl_trident_ui_assets[Asset ID],"?*")', definition)
        self.assertNotIn("FILTER(", definition)
        tree = package._xml(package._sheet_parts()["asset_terms"])
        validation = tree.find(_tag("dataValidations"))[0]
        self.assertEqual(validation.findtext(_tag("formula1")), ASSET_OPTIONS_NAME)
        self.assertEqual(validation.attrib["errorStyle"], "stop")
        self.assertEqual(validation.attrib["sqref"], "A2:A2000")

    def test_empty_id_catalogue_contains_only_blank_real_choices(self):
        package = self._fixture()
        prepare_input_capacity(package, self.policy)
        package._replace_cells("assets", {"A2": package._cell("A2", None, 0), "A3": package._cell("A3", None, 0)})
        refresh_asset_id_options(package)
        self.assertTrue(all(r["Asset ID"] == "" for r in package._table_records(ASSET_OPTIONS_TABLE)))
        self.assertIn("MAX(1,COUNTIF(", package._names()[ASSET_OPTIONS_NAME].text)

    def test_existing_capacity_larger_than_policy_is_never_shrunk(self):
        package = self._fixture()
        prepare_input_capacity(package, InputCapacityPolicy(asset_rows=6, rating_rows=8, principal_schedule_rows=9, asset_event_rows=10))
        prepare_input_capacity(package, self.policy)
        self.assertEqual(package.table_inventory()[TABLE_PREFIX + "assets"].bounds[3], 7)
        self.assertEqual(len(package._table_records(ASSET_OPTIONS_TABLE)), 6)

    def test_nonempty_hidden_growth_cell_rejects_before_any_table_mutation(self):
        package = self._fixture()
        tree = package._xml(package._sheet_parts()["asset_events"])
        package._replace_cells("asset_events", {"A8": package._cell("A8", "HIDDEN_NOTE", 0)})
        before = {name: info.ref for name, info in package.table_inventory().items()}
        original = self.source.read_bytes()
        with self.assertRaisesRegex(InputValidationError, "overwrite worksheet content"):
            prepare_input_capacity(package, self.policy)
        self.assertEqual({name: info.ref for name, info in package.table_inventory().items()}, before)
        self.assertEqual(self.source.read_bytes(), original)

    def test_adjacent_table_growth_and_protected_name_are_rejected(self):
        package = self._fixture()
        package.add_table(TABLE_PREFIX + "reserved_note", ("Comment",), ({"Comment": "KEEP"},), sheet="assets", start_cell="A5")
        with self.assertRaisesRegex(InputValidationError, "overlaps native Table"):
            prepare_input_capacity(package, self.policy)
        package = self._fixture()
        package.define_name(UI_PREFIX + "reserved_input", "assets", "A5")
        package.protected_names = frozenset({UI_PREFIX + "reserved_input"})
        with self.assertRaisesRegex(InputValidationError, "overlaps protected name"):
            prepare_input_capacity(package, self.policy)

    def test_market_data_and_existing_validation_metadata_are_preserved(self):
        package = self._fixture()
        market_part = package._sheet_parts()["Market Data"]
        market = package.parts[market_part]
        prepare_input_capacity(package, self.policy)
        target = package.save(self.root / "capacity.xlsx")
        import zipfile
        with zipfile.ZipFile(target) as archive:
            self.assertEqual(archive.read(market_part), market)
        workbook = load_workbook(target)
        self.addCleanup(workbook.close)
        self.assertEqual(workbook["asset_terms"].data_validations.dataValidation[0].formula1, ASSET_OPTIONS_NAME)
        self.assertEqual(workbook["assets"].tables[TABLE_PREFIX + "assets"].id,
            package.table_inventory()[TABLE_PREFIX + "assets"].identifier)

    def test_validation_reserve_extends_beyond_original_range_with_metadata_preserved(self):
        package = self._fixture()
        tree = package._xml(package._sheet_parts()["asset_terms"])
        validation = tree.find(_tag("dataValidations"))[0]
        validation.set("sqref", "A2:A3")
        validation.set("promptTitle", "Choose registered ID")
        validation.set("prompt", "Keep this input guidance.")
        prepare_input_capacity(package, self.policy)
        self.assertEqual(validation.attrib["sqref"], "A2:A5")
        self.assertEqual(validation.attrib["errorStyle"], "stop")
        self.assertEqual(validation.attrib["promptTitle"], "Choose registered ID")
        self.assertEqual(validation.attrib["prompt"], "Keep this input guidance.")

    def test_multiple_agency_records_remain_distinct_from_asset_capacity(self):
        self._fixture()
        workbook = load_workbook(self.source)
        table = workbook["asset_ratings"].tables[TABLE_PREFIX + "asset_ratings"]
        headers = [column.name for column in table.tableColumns]
        for field, value in {"Asset ID": "I", "Agency": "MOODYS", "Rating": "B2", "Use for model": False}.items():
            workbook["asset_ratings"].cell(4, headers.index(field) + 1, value)
        from openpyxl.utils.cell import get_column_letter
        table.ref = f"A1:{get_column_letter(len(headers))}4"
        workbook.defined_names[UI_PREFIX + "asset_ratings"].attr_text = table.ref.join(["'asset_ratings'!", ""])
        workbook.save(self.source)
        workbook.close()
        before = read_interface_inputs(self.source)
        package = WorkbookPackage(self.source)
        prepare_input_capacity(package, self.policy)
        target = package.save(self.root / "multi_agency.xlsx")
        after = read_interface_inputs(target)
        self.assertEqual(len(after.input_snapshot["table:asset_ratings"]), 3)
        self.assertEqual(len(after.request.cashflow_request.positions), 2)
        self.assertEqual(after.input_fingerprint, before.input_fingerprint)

    def test_totals_row_input_is_rejected_before_its_claim_can_become_a_data_record(self):
        package = self._fixture()
        info = package.table_inventory()[TABLE_PREFIX + "assets"]
        package._xml(info.part).set("totalsRowCount", "1")
        before = info.ref
        with self.assertRaisesRegex(InputValidationError, "totals-row"):
            prepare_input_capacity(package, self.policy)
        self.assertEqual(package.table_inventory()[info.name].ref, before)

    def _layout_fixture(self):
        self._fixture()
        workbook = load_workbook(self.source)
        layout = workbook.create_sheet("CLO Assumptions")
        # Match the native compact template's adjacent display lane. Values
        # remain ordinary owning Tables; the navigation panel is not input.
        for suffix, left, top, rows in (("limits", 8, 10, 13), ("factor_mapping", 23, 10, 8)):
            original = workbook[suffix]
            table = original.tables[TABLE_PREFIX + suffix]
            headers = [column.name for column in table.tableColumns]
            for offset, header in enumerate(headers):
                layout.cell(top, left + offset, header)
            for ordinal in range(1, rows + 1):
                for offset in range(len(headers)):
                    value = original.cell(2, offset + 1).value
                    if suffix == "limits" and offset == 0:
                        value = "COUNTRY_" + str(ordinal)
                    layout.cell(top + ordinal, left + offset, value)
            del original.tables[TABLE_PREFIX + suffix]
            from openpyxl.utils.cell import get_column_letter
            ref = f"{get_column_letter(left)}{top}:{get_column_letter(left + len(headers) - 1)}{top + rows}"
            table.ref = ref
            if table.autoFilter is not None:
                table.autoFilter.ref = ref
            layout.add_table(table)
            workbook.defined_names[UI_PREFIX + suffix].attr_text = f"'CLO Assumptions'!{ref}"
        panel = (("Input family", "Owner", "Navigation / requirement"),
            ("Deal OC policy", "CLO Assumptions", "Use coverage valuation rows."),
            ("Ratings / factor", "Asset Library", "Reusable sourced credit data."),
            ("CCC / discount", "Collateral Pool", "Current mark is separate."),
            ("Factor coefficients", "Advanced mapping", "Declare methodology."))
        for row, values in enumerate(panel, 26):
            for col, value in enumerate(values, 8):
                layout.cell(row, col, value).font = Font(name="Arial")
        summary = Table(displayName=TABLE_PREFIX + "oc_ownership", ref="H26:J30")
        summary.tableColumns = [TableColumn(id=i, name=h) for i, h in enumerate(panel[0], 1)]
        layout.add_table(summary)
        workbook.defined_names.add(DefinedName(UI_PREFIX + "oc_ownership", attr_text="'CLO Assumptions'!$H$26:$J$30"))
        workbook.defined_names.add(DefinedName(UI_PREFIX + "nav_oc_guidance", attr_text="'CLO Assumptions'!$H$25:$M$25"))
        layout["H25"] = "OC input ownership"
        layout["H32"] = "Pool classifications / marks"
        layout["H32"].hyperlink = "#trident_ui_pool"
        layout["K32"] = "Asset credit data"
        layout["K32"].hyperlink = "#trident_ui_assets"
        layout["H34"] = "Advanced factor mapping"
        layout["H36"] = "Expand grouped columns W:AB to enter sourced factor coefficients."
        layout["W20"] = "Blank agency mapping is unavailable. The saved TEST factor is synthetic and cannot be relabelled WARF."
        for ref in ("H25:M25", "H32:J32", "K32:M32", "H34:M34", "H36:M36", "W20:AB20"):
            layout.merge_cells(ref)
        workbook.save(self.source)
        workbook.close()
        return WorkbookPackage(self.source, protected_tables=tuple(TABLE_PREFIX + name for name in self.policy.table_rows))

    def test_adjacent_oc_panel_moves_with_native_identity_links_merges_and_names(self):
        package = self._layout_fixture()
        before = read_interface_inputs(self.source)
        summary = package.table_inventory()[TABLE_PREFIX + "oc_ownership"]
        prepare_input_capacity(package, self.policy)
        moved = package.table_inventory()[summary.name]
        self.assertEqual(moved.identifier, summary.identifier)
        self.assertEqual(moved.part, summary.part)
        self.assertEqual(moved.ref, "AC10:AE14")
        self.assertEqual(package.table_inventory()[TABLE_PREFIX + "limits"].ref, "H10:M110")
        self.assertEqual(package.table_inventory()[TABLE_PREFIX + "factor_mapping"].ref, "W10:AB310")
        self.assertEqual(package.named_region(UI_PREFIX + "nav_oc_guidance"), ("CLO Assumptions", (29, 9, 34, 9)))
        tree = package._xml(package._sheet_parts()["CLO Assumptions"])
        cells = package._sheet_cells(tree)
        self.assertEqual(package._cached_value(cells["AC9"]), "OC input ownership")
        self.assertIn("cannot be relabelled WARF", package._cached_value(cells["AC22"]))
        self.assertFalse(list(cells["H25"]))
        merges = {item.attrib["ref"] for item in tree.find(_tag("mergeCells"))}
        self.assertIn("AC9:AH9", merges)
        self.assertIn("AC22:AH22", merges)
        self.assertNotIn("H25:M25", merges)
        links = {item.attrib["ref"] for item in tree.find(_tag("hyperlinks"))}
        self.assertEqual(links, {"AC16", "AF16"})
        target = package.save(self.root / "expanded_layout.xlsx")
        self.assertEqual(read_interface_inputs(target).input_fingerprint, before.input_fingerprint)

    def test_occupied_guidance_destination_rejects_before_any_input_or_summary_moves(self):
        package = self._layout_fixture()
        package._replace_cells("CLO Assumptions", {"AC9": package._cell("AC9", "USER_NOTE", 0)})
        before = {name: info.ref for name, info in package.table_inventory().items()}
        with self.assertRaisesRegex(InputValidationError, "destination is occupied"):
            prepare_input_capacity(package, self.policy)
        self.assertEqual({name: info.ref for name, info in package.table_inventory().items()}, before)

    def test_future_guidance_destinations_cannot_overlap_before_any_source_mutation(self):
        from unittest.mock import patch
        package = self._layout_fixture()
        original_file = self.source.read_bytes()
        original_parts = dict(package.parts)
        original_tables = {name: info.ref for name, info in package.table_inventory().items()}
        original_names = {name: item.text for name, item in package._names().items()}
        original_sheet = ET.tostring(package._xml(package._sheet_parts()["CLO Assumptions"]))
        future_moves = (
            ("CLO Assumptions", (8, 25, 13, 36), (29, 9, 34, 20), TABLE_PREFIX + "oc_ownership"),
            ("CLO Assumptions", (23, 20, 28, 20), (29, 18, 34, 18), None),
        )
        with patch("trident.adapters.interface_capacity._display_moves", return_value=future_moves):
            with self.assertRaisesRegex(InputValidationError, "guidance destinations overlap"):
                prepare_input_capacity(package, self.policy)
        self.assertEqual(package.parts, original_parts)
        self.assertEqual({name: info.ref for name, info in package.table_inventory().items()}, original_tables)
        self.assertEqual({name: item.text for name, item in package._names().items()}, original_names)
        self.assertEqual(ET.tostring(package._xml(package._sheet_parts()["CLO Assumptions"])), original_sheet)
        self.assertEqual(self.source.read_bytes(), original_file)
        self.assertFalse(package.changed_parts)

    def test_partial_opening_coupon_witness_expands_to_all_reserved_tranche_rows(self):
        self._fixture()
        workbook = load_workbook(self.source)
        source = workbook["stack"]
        headers = [column.name for column in source.tables[TABLE_PREFIX + "stack"].tableColumns]
        unpaid_col = headers.index("Opening unpaid coupon (EUR)") + 1
        source_col = headers.index("Claim source") + 1
        saved = workbook.create_sheet("_Lists")
        saved.sheet_state = "hidden"
        for row in source.iter_rows(min_row=1, max_row=3, max_col=len(headers)):
            saved.append([cell.value for cell in row])
        table = Table(displayName=TABLE_PREFIX + "frozen_stack", ref=source.tables[TABLE_PREFIX + "stack"].ref)
        table.tableColumns = [TableColumn(id=i, name=h) for i, h in enumerate(headers, 1)]
        saved.add_table(table)
        from openpyxl.utils.cell import get_column_letter
        reference = f"${get_column_letter(unpaid_col)}$2:${get_column_letter(source_col)}$2"
        for state, sheet in (("current", "stack"), ("saved", "_Lists")):
            workbook.defined_names.add(DefinedName(UI_PREFIX + f"fresh_{state}_opening_debt_coupon_claims_1", attr_text=f"'{sheet}'!{reference}"))
        workbook.save(self.source)
        workbook.close()
        package = WorkbookPackage(self.source)
        prepare_input_capacity(package, self.policy)
        current = package.named_region(UI_PREFIX + "fresh_current_opening_debt_coupon_claims_1")[1]
        frozen = package.named_region(UI_PREFIX + "fresh_saved_opening_debt_coupon_claims_1")[1]
        self.assertEqual(current, (unpaid_col, 2, source_col, 13))
        self.assertEqual(frozen, current)
        self.assertEqual(package.table_inventory()[TABLE_PREFIX + "frozen_stack"].bounds[3], 13)

    def test_policy_validates_counts_and_does_not_equate_ratings_or_events_to_assets(self):
        defaults = InputCapacityPolicy()
        self.assertEqual(defaults.table_rows["assets"], 300)
        self.assertEqual(defaults.table_rows["asset_ratings"], 900)
        self.assertEqual(defaults.table_rows["principal_schedule"], 3000)
        self.assertEqual(defaults.table_rows["stack"], 12)
        self.assertEqual(defaults.table_rows["limits"], 100)
        self.assertEqual(defaults.table_rows["scenario_edits"], 300)
        self.assertEqual(defaults.table_rows["factor_mapping"], 300)
        for bad in (0, -1, True, 1.5, 1_048_576):
            with self.assertRaises(InputValidationError):
                InputCapacityPolicy(asset_rows=bad)


if __name__ == "__main__":
    unittest.main()


