"""Reviewable per-input execution trace, including conditional activation."""

from .legacy_inputs import LEGACY_INPUTS
from .legacy_model_records import legacy_values, RECURRING_COMPONENTS, CLOSING_COMPONENTS


def execution_for(field_id: str) -> tuple[str, str]:
    """The inventory is exhaustive; missing classification fails, never says done."""
    conditional = {
        "oc_ic_tests": ("Coverage gates -> class OC/IC failure and retests", "Configured class coverage gates only; independent junior IDT has its own separate enabled policy"),
        "interest_diversion": ("Coverage-failure interest -> tested senior debt redemption", "OC/IC failure only; No retains blocked residual interest. Independent junior IDT uses separate controls"),
        "principal_waterfall": ("Normal principal -> sequential or pro-rata debt repayment", "Ordinary distribution; failed coverage cures remain sequential regardless of normal policy"),
        "include_principal_cash_in_oc": ("OC numerator -> actual available and pending principal cash", "Enabled includes actual held principal cash including post-cutoff pending collections; restricted reserve remains excluded"),
        "rate_fixing_lag": ("Independent note fixing date -> business-day lag", "Every floating note period; measured using the selected fixing calendar and anchor"),
        "fixing_calendar": ("Independent note fixing date -> holiday calendar", "Every floating note period; independent of payment and determination calendars"),
        "fixing_date_anchor": ("Independent note fixing date -> Period Start or Payment Date", "Every floating note period; apply business-day lag after selecting the anchor"),
        "first_stub_rate_method": ("first_stub_reference_rate -> selected/interpolated/overridden reference", "First floating-note stub only; fixed notes are unaffected"),
        "first_stub_rate_override": ("first_stub_reference_rate -> explicit reference override", "User Override first floating stub only; floor and spread apply afterwards"),
        "collateral_purchase_price": ("AssetPurchase -> global clean acquisition cost", "Closing; fraction overrides the original asset-tape purchase-price inputs"),
        "purchased_accrued_interest": ("FundingEngine and inherited accrued entitlement", "Closing cost; internal claim collected once; imported full coupon must already include it"),
        "initial_reserve_funding": ("FundingEngine -> restricted reserve account", "Closing; reserve supports configured senior claims and is released only when settled"),
        "other_initial_uses": ("FundingEngine -> additional closing uses", "Closing; additional to explicitly identified closing fees and reserve"),
        "other_initial_sources": ("FundingEngine -> classified external contribution", "Closing; nonzero source requires explicit nonrepayable EXTERNAL_CONTRIBUTION"),
        "ccc_fraction": ("AdjustedCollateralValuePolicy -> top-down excess CCC haircut", "Top-down OC mode only; asset-level mode uses explicit flags"),
        "ccc_valuation_fraction": ("AdjustedCollateralValuePolicy -> top-down excess CCC valuation", "Top-down proxy only; asset-level CCC excess uses explicit current oc_market_price_fraction and lowest-mark selection"),
        "discount_obligation_fraction": ("AdjustedCollateralValuePolicy -> top-down discounted share", "Top-down OC mode only"),
        "discount_obligation_valuation_fraction": ("AdjustedCollateralValuePolicy -> top-down discounted valuation", "Top-down OC mode only"),
        "discount_obligation_price_threshold": ("AdjustedCollateralValuePolicy -> asset-level discounted classification", "Asset-level OC mode only; clean price below threshold or explicit discount flag"),
        "defaulted_asset_valuation_fraction": ("AdjustedCollateralValuePolicy -> unresolved default-claim OC credit", "Existing unresolved default claims only; never actual recovery or sale cash"),
        "simplified_cashflows_include_credit_prepayment_effects": ("compile_imported_cashflows -> prevent duplicate credit overlay", "IMPORTED Simplified/Mixed only; inactive for Detailed"),
        "simplified_pool_opening_performing_par": ("compile_imported_cashflows -> explicit simplified subpool opening", "IMPORTED Mixed subpool; required with Ending Performing Par; Detailed requires zero"),
    }
    if field_id in conditional:
        return conditional[field_id]
    if field_id in RECURRING_COMPONENTS:
        return "CloTerms.recurring_senior_expenses -> incurred/deferred expense ledger", "Every distribution; additional named components are additive"
    if field_id in CLOSING_COMPONENTS or field_id in {"upfront_arrangement_fee", "clo_size"}:
        return "ClosingCostBudget -> FundingEngine sources/uses", "Closing; CLO Size also reconciles capital nominal"
    groups = (
        ({"pricing_date", "base_currency", "opening_collateral_par", "closing_date"},
         "Named pricing/currency/opening identity validation -> funding and projection start", "Every run"),
        ({"first_note_payment_date", "maturity_date", "payment_frequency", "payment_date_convention", "payment_calendar"},
         "CloTerms -> anchored independent note schedule", "CLO projection; source first payment is unadjusted"),
        ({"reference_curve", "day_count", "liability_reference_floor"},
         "NoteTranche -> coupon reference/day-count/reference floor", "Global note defaults; asset contracts remain asset-specific"),
        ({"rate_fixing_lag", "fixing_calendar", "fixing_date_anchor", "first_stub_rate_method", "first_stub_rate_override"},
         "Independent fixing_date_for_period / first_stub_reference_rate", "Override used only for User Override first stub"),
        ({"determination_lag", "determination_calendar"},
         "Collection cutoff -> eligible vs pending cash", "Every distribution; final cutoff includes final cash"),
        ({"cash_accrual_curve", "cash_account_spread", "cash_account_rate_floor"},
         "DF_FORWARD_SIMPLE or PROJECTED_TERM_SIMPLE -> dated collection cash earnings", "Zero curves require explicit compounding/basis; reserve excluded"),
        ({"senior_management_fee", "subordinated_management_fee", "fee_base"},
         "Management fee par-day/opening-par basis -> waterfall fee claims", "Every distribution"),
        ({"expected_senior_expenses_variable", "senior_expense_cap_fixed", "senior_expense_cap_variable"},
         "Expense expected spend and priority cap -> deferred claims", "Every distribution; excess incurred expenses remain owed"),
        ({"incentive_management_fee_enabled", "incentive_fee_rate", "equity_irr_hurdle"},
         "EquityHurdleAccount -> residual incentive fee", "Enabled only; actual equity funding and ACT/365 effective hurdle"),
        ({"oc_ic_tests", "interest_diversion", "principal_waterfall", "include_principal_cash_in_oc"},
         "Coverage gates / interest diversion / sequential-or-pro-rata principal", "CLO waterfall; disabled tests explicitly NOT_CONFIGURED"),
        ({"credit_prepayment_overlay", "original_annual_default_rate", "original_recovery_rate", "original_recovery_lag_months", "original_collateral_cpr", "default_timing_pattern"},
         "OriginalPoolOverlay -> partial performing/defaulted/cash/loss ledger", "Overlay On; historical S&P-labelled vectors are economic scenarios, not agency calibration"),
        ({"ccc_fraction", "ccc_limit_fraction", "ccc_valuation_fraction", "use_asset_level_test_data", "discount_obligation_fraction", "discount_obligation_valuation_fraction", "defaulted_asset_valuation_fraction", "long_dated_oc_valuation_fraction", "discount_obligation_price_threshold"},
         "AdjustedCollateralValuePolicy -> OC numerator and separate haircut audit", "Asset-level mode uses lowest adjusted category once; top-down mode uses aggregate proxy"),
        ({"reinvestment_end_date", "reinvestment_enabled", "reinvestment_reference_curve", "reinvestment_asset_spread", "reinvestment_purchase_price", "reinvestment_wal", "reinvestment_annual_prepayment_rate", "reinvestment_annual_default_rate", "reinvestment_recovery_rate", "reinvestment_recovery_lag_months", "recycle_reinvestment_principal", "reinvestment_test_gate", "reinvestment_asset_reference_floor"},
         "SyntheticReinvestmentPolicy -> dated cohort purchases and cash/par ledger", "Enabled; on/before reinvestment end, outside terminal period; no live trades"),
        ({"interest_shortfall_carry", "shortfall_accrual_method"},
         "Coupon arrears / shortfall interest / explicit waived-shortfall ledger", "Every distribution; Coupon Rate accrues arrears only when carried"),
        ({"allow_long_dated_assets", "long_dated_asset_limit_fraction", "maturity_liquidation_fraction"},
         "Long-dated eligibility/limit diagnostics and legal-final liquidation", "Identified asset final principal after legal final; liquidation value is explicit"),
        ({"collateral_purchase_price", "purchased_accrued_interest", "initial_reserve_funding", "other_initial_uses", "other_initial_sources"},
         "AssetPurchase / inherited accrued entitlement / FundingEngine", "Closing; other sources require explicit nonrepayable contribution classification"),
        ({"optional_call_enabled", "call_date", "call_collateral_sale_price", "call_costs_of_debt_fraction"},
         "Optional-call actual liquidation and redemption -> dated investor returns", "Enabled; first actual payment on/after date, exercise only when fully funded"),
        ({"refinancing_enabled", "refinancing_date", "refi_spread_reduction", "refi_fee_of_debt_fraction"},
         "Refinancing -> equity contribution fee and subsequent note spreads", "Enabled; first actual payment on/after date, spread cannot fall below zero"),
        ({"minimum_collateral_was", "minimum_collateral_warr", "maximum_collateral_wal", "maximum_portfolio_warf", "maximum_single_obligor", "maximum_industry"},
         "PortfolioAnalyzer -> explicit quality/concentration LimitSpec", "Every available snapshot; missing inputs produce UNAVAILABLE, never fabricated pass"),
        ({"collateral_cashflow_input_mode", "simplified_cashflows_include_credit_prepayment_effects", "simplified_pool_opening_performing_par"},
         "compile_imported_cashflows -> Detailed/Simplified/Mixed dated cash and separate par", "Projection source IMPORTED; credit effects cannot be overlaid twice"),
    )
    for ids, path, condition in groups:
        if field_id in ids:
            return path, condition
    raise RuntimeError(f"Unclassified assumption execution: {field_id}")


def assumption_execution_records(controls):
    values = legacy_values(controls)
    return tuple({"source_input": field.source_coordinate, "field_id": field.field_id, "label": field.label,
        "value": values[field.field_id], "execution_path": execution_for(field.field_id)[0],
        "condition": execution_for(field.field_id)[1]} for field in LEGACY_INPUTS)


for _field in LEGACY_INPUTS:
    execution_for(_field.field_id)
