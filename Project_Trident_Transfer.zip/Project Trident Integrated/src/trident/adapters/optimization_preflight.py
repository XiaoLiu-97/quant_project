"""Named workbook input snapshot to a read-only optimization readiness report."""

from dataclasses import asdict, replace
from pathlib import Path

from trident.application.optimization_readiness import OptimizationReadinessService, ReadinessIssue
from trident.domain.models import InputValidationError

from .candidate_records import candidate_search_from_records
from .excel import NamedWorkbook, SCALAR_NAMES, load_workbook
from .excel_model import _read_table, read_model_workbook_inputs
from .optimization_records import optimization_snapshot_from_records
from .records import boolean_value
from . import excel_schema as schema


def check_optimization_workbook(path: Path, *, mode: str = "candidate") -> dict[str, object]:
    """Read current values without saving, refreshing, projecting or solving.

    Output ranges need not be populated. The shared reader enforces the same
    input contract as execution; admission is applied to the exact frozen rows.
    Workbook switches are reported so a prepared search cannot be mistaken for
    a selected run. Excel remains the data-entry surface.
    """
    if mode not in {"candidate", "static"}:
        raise InputValidationError("optimization mode must be candidate or static")
    path = Path(path)
    if path.suffix.lower() != ".xlsx":
        raise InputValidationError("Optimization checks require the named-interface .xlsx workbook")
    book = load_workbook(path, data_only=False, keep_links=True)
    try:
        if book._external_links:
            raise InputValidationError("External workbook links are not frozen model inputs")
        adapter = NamedWorkbook(book)
        version = str(adapter.scalar(SCALAR_NAMES["schema_version"]))
        schema.require_current_schema(version)
        inputs = read_model_workbook_inputs(adapter)
        controls, baseline = inputs.controls, inputs.request
        opening_dates = {row.par_as_of_date for row in baseline.cashflow_request.positions}
        if len(opening_dates) != 1:
            raise InputValidationError("Optimization preflight requires nonempty holdings at one common opening date")
        opening_date = next(iter(opening_dates))
        if mode == "candidate":
            keys = ("candidate_assets", "candidate_metadata", "candidate_ratings", "quote_observations", "candidate_variants")
            request = candidate_search_from_records(baseline, None, inputs.assets, inputs.quotes, controls,
                coupon_step_records=inputs.coupon_step_records,
                seasoned_state_records=inputs.seasoned_state_records, opening_fixing_records=inputs.opening_fixing_records,
                **{key: _read_table(adapter, key) for key in keys})
        else:
            request = optimization_snapshot_from_records(inputs.assets, inputs.quotes, controls, baseline.factor_mapping,
                opening_date=opening_date)
        report = OptimizationReadinessService().check(request)
        static_enabled = boolean_value(controls["optimizer_enabled"], "optimizer_enabled")
        candidate_enabled = boolean_value(controls.get("candidate_search_enabled", False), "candidate_search_enabled")
        if mode == "candidate" and static_enabled and any(row.accrued_per_par != 0 for row in request.base_mandate.quotes):
            issue = ReadinessIssue("ERROR", "STATIC_ACCRUED_CONFLICT",
                "Disable the static principal-account optimizer for these closing quotes: nonzero accrued requires the separate closing economic budget.")
            report = replace(report, issues=(*report.issues, issue))
        return {"workbook": str(path.resolve()), "schema_version": version, "status": report.status,
                **asdict(report), "static_run_enabled": static_enabled, "candidate_run_enabled": candidate_enabled,
                "scope": "FROZEN_INPUT_DATA_ONLY", "execution_status": "NOT_EXECUTED"}
    finally:
        book.close()
