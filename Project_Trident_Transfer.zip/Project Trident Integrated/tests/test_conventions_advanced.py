"""Independent calendar-boundary and 30-day convention checks.

Expected dates/day numerators are stated literally, not produced by another
copy of the schedule/day-count implementation. Official reference algorithms:
https://strata.opengamma.io/day_counts/
https://strata.opengamma.io/schedules/
"""

from datetime import date, datetime
from decimal import Decimal, Inexact, ROUND_DOWN, localcontext
from fractions import Fraction
import unittest

from trident.conventions import (
    AccrualDateBasis,
    BusinessDayConvention,
    DayCount,
    ScheduleBuilder,
    StubConvention,
    TargetCalendar,
    WeekendCalendar,
    accrual_fraction,
    year_fraction,
)


class ThirtyDayCountTests(unittest.TestCase):
    def test_bond_basis_and_eurobond_31st_rules_differ(self) -> None:
        # Jan 29--Mar 31: Bond Basis retains31 (60+2=62), Eurobond clips31 (61).
        self.assertEqual(accrual_fraction(date(2026, 1, 29), date(2026, 3, 31), DayCount.THIRTY_360_ISDA), Fraction(62, 360))
        self.assertEqual(accrual_fraction(date(2026, 1, 29), date(2026, 3, 31), DayCount.THIRTY_E_360), Fraction(61, 360))
        # Jan30/31--Mar31: adjusted start30 makes both end31 ->30: exactly60.
        for start_day in (30, 31):
            for convention in (DayCount.THIRTY_360_ISDA, DayCount.THIRTY_E_360, DayCount.THIRTY_U_360_EOM):
                with self.subTest(start_day=start_day, convention=convention):
                    self.assertEqual(accrual_fraction(date(2026, 1, start_day), date(2026, 3, 31), convention), Fraction(1, 6))

    def test_us_february_eom_is_distinct_from_bond_and_eurobond(self) -> None:
        # Leap-Feb29--Mar31: US-EOM maps29->30 then31->30:30.
        # Bond Basis keeps29 and31:32. Eurobond keeps29, clips31:31.
        first, last = date(2024, 2, 29), date(2024, 3, 31)
        self.assertEqual(accrual_fraction(first, last, DayCount.THIRTY_U_360_EOM), Fraction(30, 360))
        self.assertEqual(accrual_fraction(first, last, DayCount.THIRTY_360_ISDA), Fraction(32, 360))
        self.assertEqual(accrual_fraction(first, last, DayCount.THIRTY_E_360), Fraction(31, 360))
        # Non-leap Feb28--Mar31 has US30/Bond33/Euro32.
        self.assertEqual(accrual_fraction(date(2023, 2, 28), date(2023, 3, 31), DayCount.THIRTY_U_360_EOM), Fraction(30, 360))
        self.assertEqual(accrual_fraction(date(2023, 2, 28), date(2023, 3, 31), DayCount.THIRTY_360_ISDA), Fraction(33, 360))
        self.assertEqual(accrual_fraction(date(2023, 2, 28), date(2023, 3, 31), DayCount.THIRTY_E_360), Fraction(32, 360))

    def test_us_both_february_ends_and_no_end_only_adjustment(self) -> None:
        # Each February-EOM anniversary is exactly360; other variants differ.
        self.assertEqual(accrual_fraction(date(2023, 2, 28), date(2024, 2, 29), DayCount.THIRTY_U_360_EOM), Fraction(1))
        self.assertEqual(accrual_fraction(date(2024, 2, 29), date(2025, 2, 28), DayCount.THIRTY_U_360_EOM), Fraction(1))
        self.assertEqual(accrual_fraction(date(2023, 2, 28), date(2024, 2, 29), DayCount.THIRTY_360_ISDA), Fraction(361, 360))
        # Jan31--Feb29: only start31 ->30; terminal Feb29 stays29:29.
        for convention in (DayCount.THIRTY_360_ISDA, DayCount.THIRTY_E_360, DayCount.THIRTY_U_360_EOM):
            self.assertEqual(accrual_fraction(date(2024, 1, 31), date(2024, 2, 29), convention), Fraction(29, 360))
        # Feb28 is not month end in2024: must not activate US-EOM rules.
        self.assertEqual(accrual_fraction(date(2024, 2, 28), date(2024, 3, 31), DayCount.THIRTY_U_360_EOM), Fraction(33, 360))

    def test_thirty_day_counts_zero_cross_year_and_exact_half_cent(self) -> None:
        for convention in (DayCount.THIRTY_360_ISDA, DayCount.THIRTY_E_360, DayCount.THIRTY_U_360_EOM):
            with self.subTest(convention=convention):
                self.assertEqual(accrual_fraction(date(2024, 2, 29), date(2024, 2, 29), convention), Fraction(0))
                self.assertEqual(accrual_fraction(date(2025, 12, 31), date(2026, 1, 31), convention), Fraction(1, 12))
                self.assertEqual(accrual_fraction(date(2026, 1, 30), date(2026, 1, 31), convention), Fraction(0))
                exact_interest = Fraction(10) * Fraction(Decimal("0.0015")) * accrual_fraction(date(2026, 1, 1), date(2026, 5, 1), convention)
                self.assertEqual(exact_interest, Fraction(1, 200))

    def test_30e_has_no_isda_february_maturity_exception(self) -> None:
        # Plain2006 Eurobond clips only31: Aug31--Feb29 =180+(29-30)=179.
        self.assertEqual(accrual_fraction(date(2023, 8, 31), date(2024, 2, 29), DayCount.THIRTY_E_360), Fraction(179, 360))
        with self.assertRaises(ValueError):
            DayCount("30E/360.ISDA")
        with self.assertRaises(ValueError):
            DayCount("30/360")
        with self.assertRaises(ValueError):
            DayCount("30US/360")

    def test_thirty_reporting_context_and_strict_inputs(self) -> None:
        with localcontext() as context:
            context.prec = 3
            context.rounding = ROUND_DOWN
            context.traps[Inexact] = True
            self.assertEqual(year_fraction(date(2026, 1, 1), date(2026, 5, 1), DayCount.THIRTY_E_360), Decimal("0.3333333333333333333333333333333333"))
            self.assertEqual(context.prec, 3)
        for convention in (DayCount.THIRTY_360_ISDA, DayCount.THIRTY_E_360, DayCount.THIRTY_U_360_EOM):
            with self.assertRaises(ValueError):
                accrual_fraction(date(2026, 2, 1), date(2026, 1, 1), convention)
            with self.assertRaises(TypeError):
                accrual_fraction(datetime(2026, 1, 1), date(2026, 2, 1), convention)


class StubScheduleTests(unittest.TestCase):
    def setUp(self) -> None:
        self.builder = ScheduleBuilder(TargetCalendar())

    def nominal_ends(self, start: date, end: date, convention: StubConvention, **kwargs: object) -> tuple[date, ...]:
        return tuple(period.unadjusted_end for period in self.builder.build(start, end, 3, stub_convention=convention, **kwargs))

    def test_each_stub_places_the_same_residual_on_the_requested_side(self) -> None:
        first, last = date(2026, 1, 20), date(2026, 8, 10)
        self.assertEqual(self.nominal_ends(first, last, StubConvention.SHORT_LAST), (date(2026, 4, 20), date(2026, 7, 20), last))
        self.assertEqual(self.nominal_ends(first, last, StubConvention.LONG_LAST), (date(2026, 4, 20), last))
        self.assertEqual(self.nominal_ends(first, last, StubConvention.SHORT_FIRST), (date(2026, 2, 10), date(2026, 5, 10), last))
        self.assertEqual(self.nominal_ends(first, last, StubConvention.LONG_FIRST), (date(2026, 5, 10), last))

    def test_aligned_dates_never_manufacture_a_long_stub(self) -> None:
        for convention in StubConvention:
            with self.subTest(convention=convention):
                self.assertEqual(self.nominal_ends(date(2026, 1, 20), date(2026, 10, 20), convention), (date(2026, 4, 20), date(2026, 7, 20), date(2026, 10, 20)))

    def test_explicit_first_and_last_boundaries_confirm_final_stubs(self) -> None:
        self.assertEqual(
            self.nominal_ends(date(2026, 1, 20), date(2026, 8, 10), StubConvention.SHORT_LAST,
                              first_payment_date=date(2026, 4, 20), last_regular_payment_date=date(2026, 7, 20)),
            (date(2026, 4, 20), date(2026, 7, 20), date(2026, 8, 10)),
        )
        self.assertEqual(
            self.nominal_ends(date(2026, 1, 20), date(2026, 8, 10), StubConvention.LONG_LAST,
                              first_payment_date=date(2026, 4, 20), last_regular_payment_date=date(2026, 4, 20)),
            (date(2026, 4, 20), date(2026, 8, 10)),
        )
        self.assertEqual(
            self.nominal_ends(date(2026, 1, 20), date(2026, 10, 20), StubConvention.NONE,
                              first_payment_date=date(2026, 4, 20), last_regular_payment_date=date(2026, 10, 20)),
            (date(2026, 4, 20), date(2026, 7, 20), date(2026, 10, 20)),
        )

    def test_explicit_initial_short_and_long_boundaries_lock_regular_phase(self) -> None:
        start, maturity = date(2026, 1, 20), date(2026, 8, 10)
        self.assertEqual(self.nominal_ends(start, maturity, StubConvention.SHORT_FIRST,
                         first_payment_date=date(2026, 2, 10), last_regular_payment_date=maturity),
                         (date(2026, 2, 10), date(2026, 5, 10), maturity))
        self.assertEqual(self.nominal_ends(start, maturity, StubConvention.LONG_FIRST,
                         first_payment_date=date(2026, 5, 10), last_regular_payment_date=maturity),
                         (date(2026, 5, 10), maturity))

    def test_explicit_front_anchor_retains_day31_after_clipped_maturity(self) -> None:
        # EndFeb28 alone implies day28; explicit firstJan31 preserves day31.
        args = dict(start_date=date(2025, 12, 20), maturity_date=date(2026, 2, 28), frequency_months=1,
                    stub_convention=StubConvention.SHORT_FIRST)
        implicit = self.builder.build(**args)
        explicit = self.builder.build(**args, first_payment_date=date(2025, 12, 31))
        self.assertEqual(tuple(period.unadjusted_end for period in implicit), (date(2025, 12, 28), date(2026, 1, 28), date(2026, 2, 28)))
        self.assertEqual(tuple(period.unadjusted_end for period in explicit), (date(2025, 12, 31), date(2026, 1, 31), date(2026, 2, 28)))

    def test_front_eom_validates_regular_anchor_and_allows_irregular_start(self) -> None:
        periods = self.builder.build(date(2026, 1, 20), date(2026, 4, 30), 1,
                    end_of_month=True, stub_convention=StubConvention.SHORT_FIRST)
        self.assertEqual(tuple(period.unadjusted_end for period in periods), (date(2026, 1, 31), date(2026, 2, 28), date(2026, 3, 31), date(2026, 4, 30)))
        anchored = self.builder.build(date(2026, 1, 20), date(2026, 4, 30), 1,
                    end_of_month=True, stub_convention=StubConvention.LONG_FIRST,
                    first_payment_date=date(2026, 2, 28))
        self.assertEqual(tuple(period.unadjusted_end for period in anchored), (date(2026, 2, 28), date(2026, 3, 31), date(2026, 4, 30)))
        with self.assertRaisesRegex(ValueError, "regular schedule anchor"):
            self.builder.build(date(2026, 1, 20), date(2026, 4, 29), 1,
                end_of_month=True, stub_convention=StubConvention.SHORT_FIRST)
        with self.assertRaisesRegex(ValueError, "regular schedule anchor"):
            self.builder.build(date(2026, 1, 20), date(2026, 4, 30), 1,
                end_of_month=True, stub_convention=StubConvention.SHORT_FIRST, first_payment_date=date(2026, 1, 30))

    def test_nominal_front_boundary_is_independent_of_adjustment_and_lag(self) -> None:
        periods = self.builder.build(date(2026, 1, 20), date(2026, 8, 28), 3,
            stub_convention=StubConvention.SHORT_FIRST, first_payment_date=date(2026, 2, 28),
            accrual_date_basis=AccrualDateBasis.UNADJUSTED, payment_lag_business_days=2)
        self.assertEqual(periods[0].unadjusted_end, date(2026, 2, 28))
        self.assertEqual(periods[0].accrual_end, date(2026, 2, 28))
        self.assertEqual(periods[0].payment_date, date(2026, 3, 3))
        self.assertEqual(periods[1].unadjusted_end, date(2026, 5, 28))
        # Adjusted Feb27 then +two TARGET days: Mar2,Mar3.

    def test_stubs_form_a_contiguous_partition_before_and_after_adjustment(self) -> None:
        for convention in (StubConvention.SHORT_FIRST, StubConvention.LONG_FIRST, StubConvention.SHORT_LAST, StubConvention.LONG_LAST):
            for basis in AccrualDateBasis:
                with self.subTest(convention=convention, basis=basis):
                    periods = self.builder.build(date(2026, 1, 20), date(2027, 8, 28), 3,
                                                stub_convention=convention, accrual_date_basis=basis)
                    self.assertEqual(periods[0].unadjusted_start, date(2026, 1, 20))
                    self.assertEqual(periods[-1].unadjusted_end, date(2027, 8, 28))
                    self.assertEqual(tuple(period.period_number for period in periods), tuple(range(1, len(periods) + 1)))
                    for left, right in zip(periods, periods[1:]):
                        self.assertEqual(left.unadjusted_end, right.unadjusted_start)
                        self.assertEqual(left.accrual_end, right.accrual_start)
                    self.assertEqual(sum((period.unadjusted_end - period.unadjusted_start).days for period in periods), 585)

    def test_short_whole_schedule_is_supported_but_long_mislabel_is_rejected(self) -> None:
        for convention in (StubConvention.SHORT_FIRST, StubConvention.SHORT_LAST):
            self.assertEqual(self.nominal_ends(date(2026, 1, 20), date(2026, 2, 10), convention), (date(2026, 2, 10),))
        for convention in (StubConvention.LONG_FIRST, StubConvention.LONG_LAST):
            with self.assertRaisesRegex(ValueError, "regular period to merge"):
                self.nominal_ends(date(2026, 1, 20), date(2026, 2, 10), convention)

    def test_wrong_length_side_and_dual_stubs_reject(self) -> None:
        cases = (
            (StubConvention.SHORT_FIRST, {"first_payment_date": date(2026, 5, 10)}),
            (StubConvention.LONG_FIRST, {"first_payment_date": date(2026, 2, 10)}),
            (StubConvention.LONG_FIRST, {"first_payment_date": date(2026, 8, 10)}),
            (StubConvention.SHORT_FIRST, {"first_payment_date": date(2026, 2, 11)}),
            (StubConvention.SHORT_FIRST, {"last_regular_payment_date": date(2026, 5, 10)}),
            (StubConvention.SHORT_LAST, {"first_payment_date": date(2026, 4, 21)}),
            (StubConvention.SHORT_LAST, {"last_regular_payment_date": date(2026, 4, 20)}),
            (StubConvention.LONG_LAST, {"last_regular_payment_date": date(2026, 7, 20)}),
        )
        for convention, fields in cases:
            with self.subTest(convention=convention, fields=fields), self.assertRaises(ValueError):
                self.nominal_ends(date(2026, 1, 20), date(2026, 8, 10), convention, **fields)

    def test_explicit_dates_reject_invalid_types_and_range(self) -> None:
        for field_name in ("first_payment_date", "last_regular_payment_date"):
            for invalid in (datetime(2026, 4, 20), "2026-04-20", True):
                with self.subTest(field=field_name, value=invalid), self.assertRaises(TypeError):
                    self.nominal_ends(date(2026, 1, 20), date(2026, 8, 10), StubConvention.SHORT_LAST, **{field_name: invalid})
            for invalid in (date(2026, 1, 20), date(2025, 12, 20), date(2026, 8, 11)):
                with self.subTest(field=field_name, value=invalid), self.assertRaises(ValueError):
                    self.nominal_ends(date(2026, 1, 20), date(2026, 8, 10), StubConvention.SHORT_LAST, **{field_name: invalid})

    def test_initial_schedule_at_date_min_does_not_underflow(self) -> None:
        builder = ScheduleBuilder(WeekendCalendar())
        periods = builder.build(date.min, date(1, 2, 20), 3,
            stub_convention=StubConvention.SHORT_FIRST, fixing_lag_business_days=0,
            business_day_convention=BusinessDayConvention.UNADJUSTED,
            accrual_date_basis=AccrualDateBasis.UNADJUSTED)
        self.assertEqual(len(periods), 1)
        self.assertEqual(periods[0].unadjusted_start, date.min)
        self.assertEqual(periods[0].unadjusted_end, date(1, 2, 20))


if __name__ == "__main__":
    unittest.main()
