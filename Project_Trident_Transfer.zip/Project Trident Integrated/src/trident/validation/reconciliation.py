"""Compare independent benchmarks against explicit generated observations.

The adapter supplies a canonical key-to-number mapping; this module performs
no model projection, lookup by cell, unit conversion, financial defaulting or
reference generation. It therefore works for closing funding, asset cashflows,
class-period waterfall and stage-specific IC/OC without depending on Excel or
the CLO engine. Every expected value remains attached to its input provenance.
"""

from collections.abc import Iterable, Mapping
from decimal import Context, Decimal, Inexact, MAX_EMAX, MIN_EMIN, localcontext
from types import MappingProxyType

from trident.domain.models import InputValidationError

from .models import (
    BenchmarkRecord, ObservedMetric, ReconciliationKey, ReconciliationReport,
    ReconciliationResult, ReconciliationStatus,
)


def index_observations(
    pairs: Iterable[tuple[ReconciliationKey, ObservedMetric]],
) -> Mapping[ReconciliationKey, ObservedMetric]:
    """Freeze observations while rejecting duplicate or malformed identities.

    Reporting adapters should use this helper instead of a dictionary
    comprehension: an overwritten duplicate cannot be detected once a plain
    dictionary has been built. A generator is consumed exactly once. Empty
    observations are allowed, so comparisons can report every missing metric
    rather than discarding the user's benchmark set.
    """
    indexed: dict[ReconciliationKey, ObservedMetric] = {}
    try:
        iterator = iter(pairs)
    except TypeError as exc:
        raise InputValidationError("Observed metrics require iterable key/value pairs") from exc
    for pair in iterator:
        if type(pair) is not tuple or len(pair) != 2:
            raise InputValidationError("Each observed metric must be a key/value tuple")
        key, metric = pair
        if not isinstance(key, ReconciliationKey) or not isinstance(metric, ObservedMetric):
            raise InputValidationError("Observed metric pairs require ReconciliationKey and ObservedMetric")
        if key in indexed:
            raise InputValidationError(f"Duplicate generated reconciliation metric: {key}")
        indexed[key] = metric
    return MappingProxyType(indexed)


def _exact_difference(actual: Decimal, expected: Decimal) -> Decimal:
    """Subtract all finite input digits, independently of caller precision.

    Finite Decimal values have terminating base-10 expansions. Aligning their
    full coefficients and reserving carry digits makes subtraction exact;
    Inexact is trapped as an invariant. No cents quantization or displayed
    ratio precision can loosen a boundary chosen by the benchmark author.
    """
    precision = max(actual.adjusted(), expected.adjusted()) - min(
        actual.as_tuple().exponent, expected.as_tuple().exponent,
    ) + 3
    with localcontext(Context(prec=max(34, precision), Emax=MAX_EMAX, Emin=MIN_EMIN)) as context:
        context.traps[Inexact] = True
        return actual - expected


class ReconciliationService:
    """Produce deterministic finite numerical evidence for review.

    Configurable tolerances are absolute, expressed in the benchmark's unit,
    and inclusive. MATCH is not a certification of source independence, legal
    definitions, complete transaction coverage or production fitness. A caller
    must separately approve the reference coverage and explain any differences.
    """

    def compare(
        self, benchmarks: tuple[BenchmarkRecord, ...],
        observed: Mapping[ReconciliationKey, ObservedMetric],
    ) -> ReconciliationReport:
        """Compare only supplied benchmark keys, preserving caller row order.

        Empty or duplicate benchmarks and malformed mappings are explicit input
        errors, never an empty PASS. Missing values and incompatible units are
        UNAVAILABLE rows. Unreferenced observations do not affect the requested
        reconciliation and must not be interpreted as separately checked.
        """
        if type(benchmarks) is not tuple or not benchmarks:
            raise InputValidationError("Benchmarks must be a nonempty immutable tuple")
        if any(not isinstance(row, BenchmarkRecord) for row in benchmarks):
            raise InputValidationError("Benchmarks must contain BenchmarkRecord objects")
        if len({row.key for row in benchmarks}) != len(benchmarks):
            raise InputValidationError("Duplicate benchmark reconciliation identity")
        if not isinstance(observed, Mapping):
            raise InputValidationError("Observed metrics must be a canonical key/value mapping")
        # Copy/freeze the boundary once, including validation of observations
        # outside the requested benchmark set. Later caller mutation cannot
        # change a partially constructed report.
        actual = index_observations(observed.items())
        results = []
        for benchmark in benchmarks:
            metric = actual.get(benchmark.key)
            if metric is None:
                results.append(ReconciliationResult(benchmark, None, ReconciliationStatus.UNAVAILABLE,
                    None, None, "No generated observation exists for this exact date/entity/metric/stage"))
                continue
            if metric.unit != benchmark.unit:
                results.append(ReconciliationResult(benchmark, metric, ReconciliationStatus.UNAVAILABLE,
                    None, None, f"Unit mismatch: expected {benchmark.unit}, observed {metric.unit}; no conversion applied"))
                continue
            if metric.value is None:
                results.append(ReconciliationResult(benchmark, metric, ReconciliationStatus.UNAVAILABLE,
                    None, None, metric.unavailable_reason or "The current model observation is unavailable"))
                continue
            difference = _exact_difference(metric.value, benchmark.expected)
            absolute = difference.copy_abs()
            matched = absolute <= benchmark.tolerance
            status = ReconciliationStatus.MATCH if matched else ReconciliationStatus.MISMATCH
            results.append(ReconciliationResult(benchmark, metric, status, difference, absolute,
                "Within explicit absolute tolerance" if matched else "Exceeds explicit absolute tolerance"))
        return ReconciliationReport(tuple(results))
