"""Engineering audit regressions using the real solver/CLO orchestration.

Independent cash expectations distinguish a projection cache hit from a
dangerous approximate-pool match; malformed discrete incumbents are supplied
directly so the solver cannot also manufacture their expected validity.
"""

from dataclasses import replace
from datetime import date
from decimal import Decimal
from types import SimpleNamespace
import unittest
from unittest.mock import patch

from trident.application.candidate_search import (
    CandidateSearchVariant, ClosingPoolSearchService, ModelProjectionCache,
)
from trident.application.clo_services import TridentModelService
from trident.domain.models import InputValidationError
from trident.market import FlatRateProvider
from trident.market.cash_accounts import CashCurveRateProvider
from trident.market.rates import CurveRateProvider, ExtrapolationPolicy, ProjectedRateCurve, RatePoint
from trident.optimization import OptimizationObjective, OptimizationStatus, StaticTradeOptimizer
from test_candidate_search import search_request
from test_construction import fixture

D = Decimal


class _CountingRunner:
    """Count actual complete model runs, while retaining real financial output."""

    def __init__(self):
        self.calls = []
        self.delegate = TridentModelService()

    def run(self, request):
        self.calls.append(request)
        return self.delegate.run(request)


class ProjectionReuseTests(unittest.TestCase):
    def test_distinct_objectives_with_identical_pool_replay_only_once(self):
        request = search_request(variants=(
            CandidateSearchVariant("FACTOR", OptimizationObjective.MIN_FACTOR),
            CandidateSearchVariant("SPREAD", OptimizationObjective.MAX_SPREAD),
            CandidateSearchVariant("FACTOR_CAP", OptimizationObjective.MIN_FACTOR,
                                   maximum_overall_factor=D(2000)),
        ))
        runner = _CountingRunner()
        result = ClosingPoolSearchService(service=runner).run(request)
        self.assertEqual(len(runner.calls), 2)  # original and one distinct target
        targets = [result.evaluation(name) for name in ("FACTOR", "SPREAD", "FACTOR_CAP")]
        self.assertTrue(all(row.eligible for row in targets))
        self.assertIs(targets[0].replay.target_result, targets[1].replay.target_result)
        self.assertIs(targets[1].replay.target_result, targets[2].replay.target_result)
        self.assertEqual({row.candidate_id for row in targets}, {"FACTOR", "SPREAD", "FACTOR_CAP"})
        self.assertEqual(targets[0].equity_cash_funding, D(2107))
        self.assertEqual(targets[0].equity_distributions, D(2160))
        self.assertEqual(result.selected_candidate_id, "NO_TRADES")

    def test_workbook_baseline_reuse_has_exact_bound_request(self):
        request = search_request(variants=(CandidateSearchVariant("FULL", OptimizationObjective.MIN_FACTOR),))
        runner = _CountingRunner()
        cache = ModelProjectionCache(runner)
        original = cache.run(request.baseline)
        result = ClosingPoolSearchService(service=cache).run(request)
        self.assertEqual(len(runner.calls), 2)
        self.assertIs(result.evaluation("NO_TRADES").replay.baseline_result, original)
        # A separate invocation receives a fresh cache, so a new calculation
        # cannot inherit a stale result from a prior frozen-data snapshot.
        ClosingPoolSearchService(service=runner).run(request)
        self.assertEqual(len(runner.calls), 4)

    def test_same_par_key_with_changed_cost_or_contract_does_not_collide(self):
        baseline = fixture().baseline
        runner = _CountingRunner()
        cache = ModelProjectionCache(runner)
        first = cache.run(baseline)
        cost = replace(baseline, cashflow_request=replace(baseline.cashflow_request, upfront_fees=D(8)))
        second = cache.run(cost)
        position = baseline.cashflow_request.positions[0]
        higher = replace(position, terms=replace(position.terms, spread_bps=D(600)))
        contract = replace(baseline,
            cashflow_request=replace(baseline.cashflow_request, positions=(higher,)),
            exposures=(replace(baseline.exposures[0], spread_bps=D(600)),))
        third = cache.run(contract)
        self.assertEqual(len(runner.calls), 3)
        self.assertEqual(first.cashflows.funding.equity_cash_funding, D(2007))
        self.assertEqual(second.cashflows.funding.equity_cash_funding, D(2008))
        self.assertEqual(third.clo.total_equity_distributions, D(2110))
        self.assertIs(cache.run(cost), second)

    def test_failed_projection_not_retained_and_bad_request_rejected(self):
        baseline = fixture().baseline

        class FailingRunner:
            calls = 0

            def run(self, request):
                self.calls += 1
                raise InputValidationError("unavailable frozen contract")

        runner = FailingRunner()
        cache = ModelProjectionCache(runner)
        for _ in range(2):
            with self.assertRaisesRegex(InputValidationError, "unavailable"):
                cache.run(baseline)
        self.assertEqual(runner.calls, 2)
        with self.assertRaisesRegex(InputValidationError, "TridentModelRequest"):
            cache.run(None)

    def test_mutable_custom_rates_recompute_same_request_after_market_change(self):
        class ChangingProvider:
            value = D(0)

            def rate(self, index, fixing_date):
                return self.value

        provider = ChangingProvider()
        original = fixture().baseline
        for wrapped in (provider, CashCurveRateProvider(provider, {})):
            with self.subTest(wrapped=type(wrapped).__name__):
                provider.value = D(0)
                baseline = replace(original,
                    cashflow_request=replace(original.cashflow_request, rate_provider=wrapped))
                runner = _CountingRunner()
                cache = ModelProjectionCache(runner)
                first = cache.run(baseline)
                provider.value = D(".01")
                second = cache.run(baseline)
                self.assertEqual(len(runner.calls), 2)
                self.assertEqual(first.clo.total_equity_distributions, D(2085))
                self.assertEqual(second.clo.total_equity_distributions, D(2110))

    def test_provider_subclass_is_not_mistaken_for_frozen_snapshot(self):
        class OverriddenFlat(FlatRateProvider):
            def rate(self, index, fixing_date):
                return D(0)

        baseline = fixture().baseline
        baseline = replace(baseline,
            cashflow_request=replace(baseline.cashflow_request,
                                     rate_provider=OverriddenFlat({"EURIBOR_3M": D(0)})))
        runner = _CountingRunner()
        cache = ModelProjectionCache(runner)
        cache.run(baseline)
        cache.run(baseline)
        self.assertEqual(len(runner.calls), 2)

    def test_known_frozen_curve_and_composite_are_reused(self):
        original = fixture().baseline
        curve = ProjectedRateCurve("EURIBOR_3M", (
            RatePoint(date(2025, 1, 1), D(0)), RatePoint(date(2030, 1, 1), D(0)),
        ), ExtrapolationPolicy.ERROR)
        provider = CurveRateProvider({"EURIBOR_3M": curve}, date(2025, 1, 1))
        for frozen in (provider, CashCurveRateProvider(provider, {})):
            with self.subTest(provider=type(frozen).__name__):
                baseline = replace(original,
                    cashflow_request=replace(original.cashflow_request, rate_provider=frozen))
                runner = _CountingRunner()
                cache = ModelProjectionCache(runner)
                first = cache.run(baseline)
                self.assertIs(cache.run(baseline), first)
                self.assertEqual(len(runner.calls), 1)

    def test_static_rejection_keeps_named_evidence_despite_target_cache(self):
        request = search_request(variants=(
            CandidateSearchVariant("VALID", OptimizationObjective.MIN_FACTOR),
            CandidateSearchVariant("IMPOSSIBLE", OptimizationObjective.MIN_FACTOR,
                                   maximum_overall_factor=D(1999)),
            CandidateSearchVariant("DUPLICATE", OptimizationObjective.MAX_SPREAD),
        ))
        runner = _CountingRunner()
        result = ClosingPoolSearchService(service=runner).run(request)
        self.assertEqual(len(runner.calls), 2)
        self.assertTrue(result.evaluation("VALID").eligible)
        self.assertTrue(result.evaluation("DUPLICATE").eligible)
        rejected = result.evaluation("IMPOSSIBLE")
        self.assertFalse(rejected.eligible)
        self.assertEqual(rejected.status, "STATIC_REJECTED")
        self.assertIsNone(rejected.equity_irr.value)


class DiscreteSolverEvidenceTests(unittest.TestCase):
    def test_positive_trade_requires_binary_activation_even_when_cash_affordable(self):
        request = fixture(fees=True, accrued=False).optimization_request
        # Two EUR-m quote variables then SELL/BUY activation flags. Full swap
        # satisfies exact par and cash, but z=0 cannot authorize a positive sale.
        fake = SimpleNamespace(status=0, message="malformed incumbent",
                               x=[.01, .01, 0, 1], fun=-2000)
        with patch("scipy.optimize.milp", return_value=fake):
            result = StaticTradeOptimizer().solve(request)
        self.assertEqual(result.status, OptimizationStatus.REJECTED_POST_VALIDATION)
        self.assertFalse(result.validated)
        self.assertEqual(result.ending_par, D(10000))
        self.assertIn("OLD: positive trade lacks solver activation", result.violations)

    def test_integral_binary_two_is_rejected_not_rounded_into_valid_trade(self):
        request = fixture(fees=True, accrued=False).optimization_request
        fake = SimpleNamespace(status=0, message="malformed incumbent",
                               x=[.01, .01, 2, 1], fun=-2000)
        with patch("scipy.optimize.milp", return_value=fake):
            result = StaticTradeOptimizer().solve(request)
        self.assertFalse(result.validated)
        self.assertTrue(any("decision bounds" in message for message in result.violations))


if __name__ == "__main__":
    unittest.main()
