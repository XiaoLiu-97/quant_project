# Existing CLO opening at a post-distribution boundary

Project Trident Integrated 0.12.0 supports an explicit existing-CLO opening with identified performing EUR cash-pay collateral, current note face, unpaid coupon/fee claims and account balances. It projects the future tail of the original deal schedule through the same waterfall used for closing runs. It does not reconstruct missing history, execute future real trades or certify a transaction's legal profile.

The executable boundaries are [opening state](../../src/trident/clo/models.py), [original-period selection](../../src/trident/clo/opening.py), [application orchestration](../../src/trident/application/clo_services.py), [named Excel transport](../../src/trident/adapters/clo_opening_records.py) and [settled-ledger bridge](../../src/trident/portfolio/clo_bridge.py). Use [pilot acceptance](../user_guide.md) and the [user guide](../user_guide.md) for operation.

## Time and ownership boundary

`as_of_date` is **after the entire distribution on that date**. The original Closing Date, first note payment, distribution frequency, calendar, business-day convention, accrual basis, stubs and legal final remain contractual inputs. The opening must be an original actual adjusted payment date, and the next original liability accrual must start exactly on that date. The core also permits the original closing boundary when the next original accrual starts there. A mid-period valuation, or a payment/accrual gap caused by different adjusted and unadjusted boundaries, requires another opening profile and rejects.

Future liability periods are selected without rebuilding or renumbering the original schedule. For example, an opening after original period 3 starts with original period 4; the first future coupon uses that original period's dates, day count and fixing. `CloProjection.first_projected_period_number` preserves that starting ID for reports. A first-stub override applies only to the original first stub, rather than every newly selected first future period. Asset schedules separately retain original loan anchors and their explicit seasoned entitlement; forward asset row numbers can start at 1.

A floating note's first future fixing can precede as-of through its fixing lag. Supply the actual raw EURIBOR observation through the existing Fixings/Market Data provider history for the exact index/date. A current projected curve is not a substitute. Loan observations in Opening Fixings belong to the separate ASSET/CANDIDATE seasoned-loan interface and must not be used as an implicit note-fixing map.

No collection on or before the attested opening is replayed as a future receipt. Loan par, coupon entitlement, account cash and debt claims must describe the same post-distribution state.

## Named opening inputs

Exactly one CLO Opening row activates this profile. Its columns are:

| Field | Meaning |
| --- | --- |
| `as_of_date` | Verified post-distribution opening date |
| `timing` | Explicit `POST_DISTRIBUTION` |
| `forward_equity_value` | Positive current EUR value of the modeled equity interest; forward return basis |
| `equity_value_source` | Independent source/date/record locator for that value |
| `use_ledger_snapshot` | Explicit Boolean selecting strict settled-ledger reconciliation |
| `initial_collateral_par` | Verified original fee-base par when an INITIAL_COLLATERAL_PAR fee policy needs it beyond original closing; not automatically today's smaller pool |
| `source` | Source and attestation for the opening distribution/state |

Opening CLO Accounts requires all eight rows, each with `account`, cent `balance` and `source`, including explicit zeros:

| Account | Core field | Interpretation |
| --- | --- | --- |
| `PRINCIPAL` | `principal_cash` | Eligible physical principal cash already carried at opening |
| `INTEREST` | `interest_cash` | Eligible physical interest cash already carried at opening |
| `RESERVE` | `reserve` | Separate restricted reserve; reconciles to the workbook reserve control |
| `PENDING_PRINCIPAL` | `pending_principal_cash` | Physically received principal awaiting determination eligibility |
| `PENDING_INTEREST` | `pending_interest_cash` | Physically received interest awaiting determination eligibility |
| `ORIGINAL_PRINCIPAL_REINVESTMENT` | `original_principal_reinvestment_cash` | Reinvestment designation **inside** PRINCIPAL |
| `PENDING_ORIGINAL_PRINCIPAL_REINVESTMENT` | `pending_original_principal_reinvestment_cash` | Designation **inside** PENDING_PRINCIPAL |
| `HELD_DIVERSION` | `held_diversion_principal` | Held IDT designation **inside** PRINCIPAL |

Principal reinvestment and held-diversion designations must be disjoint: their sum cannot exceed principal cash. Pending original principal permission cannot exceed pending principal cash. Do not add these three designation rows to cash, collateral or OC assets a second time. A held IDT designation requires an active configured IDT window.

Opening CLO Claims uses `claim_type`, `class_id`, cent `amount` and `source`. Supply `NOTE_COUPON` for **every** retained debt class, including zero claims. Also supply these four fee rows with blank `class_id`, including zeros:

| Claim type | Core field |
| --- | --- |
| `SENIOR_EXPENSES` | `expense_arrears` |
| `SENIOR_MANAGEMENT` | `senior_management_fee_arrears` |
| `SUBORDINATED_MANAGEMENT` | `subordinated_management_fee_arrears` |
| `DEFERRED_SENIOR_EXPENSES` | `deferred_senior_expense_arrears` |

Claims are unpaid **pre-opening** amounts, not the next period's new dues. Missing rows do not mean zero. Duplicate/unknown account or claim types, unknown debt identities and amounts without sources reject. Note classes with zero face and zero claim can remain as inactive template rows with not-applicable own tests. A zero-face class with a positive unpaid claim remains active and retains its applicable payment/coverage treatment; it is not deleted merely because face is zero.

## Face, claims and cash conservation

Capital Stack note amounts represent **current face**, excluding the separately supplied unpaid coupon claim. The model preserves those two ledgers. If the trustee's reported Principal Amount Outstanding already includes capitalized deferred coupon, reconcile it into model face plus coupon claim first; entering that aggregate as face and adding the claim again double-counts the liability. The model does not silently perform that report-specific decomposition.

The retained compatibility controls still validate `CLO Size` against the supplied Capital Stack nominal total, including the residual reference nominal. In this opening interface set that control to the current supplied stack total; it is not a reconstructed original issuance size or equity valuation and creates no new debt proceeds. `Opening Collateral Par` is current performing par, while any original collateral amount required by an initial-par fee basis belongs in `initial_collateral_par`. These control interpretations are implementation assumptions, not legal definitions of transaction size.

The next period accrues current note coupon on opening face, then applies the explicit arrears-accrual policy to opening coupon claims. Fees add new period dues to their opening unpaid claims. Payments reduce the appropriate claims/face ledgers and cash exactly once. OC/IDT and IC include or exclude deferred claims according to the configured definitions; the physical face ledger is not a substitute for a legal covenant denominator. The existing generic waterfall, cure/diversion, expense-cap and deferral policies still require mapping to the actual indenture.

Opening pending cash was physically received no later than as-of. At the first future determination cutoff reaching as-of, it transfers once from pending to eligible cash. It is not a new receipt and is not available for distribution before eligibility. Account remuneration, when configured, tracks physical cash held; a separate bank-interest receipt follows its own configured policy. The final modeled distribution releases the remaining cutoff population under the existing final-period policy.

The invariant is opening physical cash, including separately held reserve/pending accounts, plus actual future receipts equals future payments and remaining physical balances. Designations do not create another source. Note face and unpaid claims have separate bridges; repayment of an unpaid coupon is not an additional face redemption.

## Current holdings and forward equity return

All positive native Assets must use the opening as-of date, retain their original contracts and explicit seasoned state where required, and match analytical exposure ID/par/currency. Capital Stack uses current debt face and current coupon terms. Existing CLO Opening requires `CLO_BASELINE` and `INTERNAL_ENGINE`; the closing ScenarioRunner and full closing candidate search are not applicable to this profile. The independent compact interface may run static portfolio research and StaticOpeningScenarioService. That opening service keeps original accounts/claims and requires both forward_equity_value and equity_value_source for any existing asset/note par edit; it does not execute a trade.

Historic asset purchases and debt issuance are not funded again. Set upfront arrangement/closing cost components, Closing Costs, Other Initial Uses, Other Initial Sources and Purchased Accrued Interest to zero. The reserve control is retained as a reconciliation input and must equal RESERVE. Ongoing recurring fees remain active; their unpaid history belongs in the claim rows. Acquisition/issue descriptor prices can remain for schema compatibility, but do not create a new sources-and-uses calculation in this profile. Sources & Uses is unavailable rather than a fabricated historical funding statement.

A remaining principal-funded accrued classification balance can be supplied through the separate [Coupon Proceeds profile](coupon_proceeds.md), without recharging that historical purchase cost. It requires a sufficient positive sourced opening coupon entitlement and an exact instruction for the first positive future native coupon. The balance is a classification memo, not additional opening cash or performing par. Restoration relabels that actual receipt between interest and principal accounts; ordinary cutoff and the explicit reinvestment-permission flag govern when the principal can be used. Do not enter already received pre-opening accrued as another future restoration or add the memo to OC credit automatically.

The equity calculation starts with `-forward_equity_value` at as-of, adds only future modeled distributions and subtracts future contributions. It is a **forward return from the supplied current value**, not since-inception equity IRR or a recharge of issuance costs. The XIRR calculation uses actual dated cash with a 365-day annualization, consistent with [Microsoft's XIRR convention](https://support.microsoft.com/en-us/excel/functions/xirr-function). The value and source are explicit inputs; the model does not infer them from equity nominal or outstanding debt. Incomplete terminal debt/default/cash/claim state leaves investor returns unavailable.

## Optional settled operational bridge

Set `use_ledger_snapshot=TRUE` only after reconciling a complete operational ledger. Ledger Controls `horizon_date` must equal the CLO opening date. The operator's CLO Opening source and `POST_DISTRIBUTION` selection attest that its end-of-day ledger state represents the same post-distribution boundary; equal calendar dates alone cannot establish intraday ownership.

The final snapshot must be EUR with no pending trades, reserved cash or uncollected receivables, and no positive defaulted inventory. Every positive performing holding must match a current LoanPosition's ID, par, currency and as-of exactly. Available cash must equal actual cash. Opening CLO PRINCIPAL and INTEREST must already equal snapshot cash; Excel **rejects** a mismatch rather than overwriting controls. Pending opening CLO accounts must be zero when this strict bridge is used; the separate native opening profile can accept explicitly sourced pending cutoff cash.

Retired Ledger Assets optionally lists verified zero-par IDs with their sources. They add no projected asset and cannot admit unknown positive inventory. A fully sold asset retained at zero by the ledger needs this declaration; an outstanding recovery/interest claim still prevents bridging. The bridge can validate an all-cash snapshot, but the unified CLO application currently requires at least one positive identified performing asset and does not run a cash-only empty-pool opening.

The standalone `LedgerCloOpeningBridgeService.import_cash` is an explicitly selected API replacing only principal/interest cash. It preserves reserve, claims, arrears and designations and rejects unsupported remaining state. Excel uses the stricter `bind` API. Neither method injects historical journal receipts into the future waterfall or replays future real trades. Future real reinvestment execution needs a separate dated trade/collection/ownership integration.

## Rejected profiles and review evidence

This release rejects mid-period liability openings, payment/accrual gaps, incentive fees lacking a historical investor-hurdle account, already occurred call/refinancing events, imported opening inventory and positive defaulted opening inventory. To model a historical refinancing, provide already effective current terms and disable replay of the past event. Scheduled future credit/reinvestment/call/refinancing assumptions remain subject to their existing supported policies; they do not execute real orders.

Asset payment lag, ended unpaid borrower coupons, unsupported seasoned recasts, missing historical fixing dates, incomplete claim/account rows, nonzero closing costs, active full closing redesign switches and unsupported empty-pool openings also reject. Compact-interface opening what-if and static portfolio research use their explicit separate service boundaries. Do not replace unknown values with zero merely to pass the gate.

When explicit Coupon Proceeds instructions are active, their additional guards reject claimed-loan default, proportional original-pool overlay, optional-call sale allocation, partial restoration and receipts after legal final. Unrelated supported credit events remain possible. Exact sourced allocations cannot be automatically rebound by closing what-if or optimization edits; refresh and independently verify their records for another baseline.

CLO Opening Audit publishes the exact account, claim, original fee-base and forward equity value used, with component sources. Calculated References/Reconciliation exposes their semantic opening records alongside future tranche, coverage, account, collection and portfolio observations. Inspect the original period IDs, first carried note rate, current versus opening coupon claim, IC/OC `GATE`/post-diversion/end stages, reserve and pending transfers, and every actual account bridge. A matching supplied benchmark scope is numerical evidence, not legal sign-off.

An [original SEC-filed CLO indenture, section 10.7](https://www.sec.gov/Archives/edgar/data/1373561/000119312512507388/d455464dex41.htm) separately reports account beginning balances, debits/credits and endings, note rates and transaction activity. This supports independent source reconciliation; its US transaction terms do not prescribe a universal EUR opening profile. The post-distribution restriction and supported-state choices here are explicit implementation assumptions, chosen to avoid inventing unavailable accrual or ownership history.

Independent controls include [core opening cases](../../tests/test_clo_opening_state.py), [settled ledger bridge cases](../../tests/test_ledger_clo_bridge.py), [existing Excel opening cases](../../tests/test_existing_clo_workbook.py) and [opening acceptance cases](../../tests/test_opening_clo_acceptance.py). Real use additionally needs the actual indenture, agent data, reconciled post-distribution trustee balances and transaction-specific methodology review.
