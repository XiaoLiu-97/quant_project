"""Metadata changes preserve workbook content and atomic-save guarantees.

The theme's display labels do not define its colours, fonts or formats. These
tests compare package payloads and independent theme definitions, including
failure paths, rather than treating successful workbook loading as sufficient.
"""

from copy import deepcopy
import importlib.util
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
import warnings
from xml.etree import ElementTree
from zipfile import ZipFile

from openpyxl import Workbook, load_workbook
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.workbook.defined_name import DefinedName

from trident.adapters.excel import NamedWorkbook, _save_atomic
from trident.domain.models import InputValidationError


ROOT = Path(__file__).resolve().parents[1]
THEME_PATH = "xl/theme/theme1.xml"
THEME_NAMESPACE = "http://schemas.openxmlformats.org/drawingml/2006/main"
PROJECT_NAME = "Project Trident"
THEME_BYTES = f"""<?xml version="1.0" encoding="UTF-8"?>
<a:theme xmlns:a="{THEME_NAMESPACE}" name="OriginalTheme">
  <a:themeElements>
    <a:clrScheme name="OriginalColours">
      <a:dk1><a:srgbClr val="102030" /></a:dk1>
      <a:lt1><a:srgbClr val="FFFFFF" /></a:lt1>
      <a:accent1><a:srgbClr val="CCEEFF" /></a:accent1>
    </a:clrScheme>
    <a:fontScheme name="OriginalFonts">
      <a:majorFont><a:latin typeface="Example Serif" /></a:majorFont>
      <a:minorFont><a:latin typeface="Example Sans" /></a:minorFont>
    </a:fontScheme>
    <a:fmtScheme name="OriginalFormats">
      <a:fillStyleLst><a:solidFill><a:schemeClr val="phClr" /></a:solidFill></a:fillStyleLst>
      <a:lnStyleLst><a:ln w="9525" cap="flat"><a:prstDash val="solid" /></a:ln></a:lnStyleLst>
      <a:effectStyleLst><a:effectStyle><a:effectLst /></a:effectStyle></a:effectStyleLst>
      <a:bgFillStyleLst><a:solidFill><a:srgbClr val="FFFFFF" /></a:solidFill></a:bgFillStyleLst>
    </a:fmtScheme>
  </a:themeElements>
</a:theme>""".encode("utf-8")

# Load the project tool by location: it is a developer script, not an installed
# runtime package, and test discovery need not add scripts/ to PYTHONPATH.
_spec = importlib.util.spec_from_file_location("workbook_metadata_tool", ROOT / "scripts/prepare_template.py")
assert _spec is not None and _spec.loader is not None
_metadata_tool = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(_metadata_tool)


def theme_definition(contents: bytes) -> tuple[tuple[str, ...], bytes]:
    """Separate the four descriptive labels from all DrawingML definitions."""
    theme = ElementTree.fromstring(contents)
    labels = [theme]
    for local_name in ("clrScheme", "fontScheme", "fmtScheme"):
        labels.append(theme.find(f"{{{THEME_NAMESPACE}}}themeElements/{{{THEME_NAMESPACE}}}{local_name}"))
    if any(label is None for label in labels):
        raise AssertionError("Fixture must include the four theme labels")
    names = tuple(label.attrib.pop("name") for label in labels)
    # Prefix spelling is not a DrawingML definition and may differ when the
    # normalizer registers the conventional namespace prefix globally.
    definition = ElementTree.canonicalize(
        ElementTree.tostring(theme, encoding="unicode"), rewrite_prefixes=True,
    )
    return names, definition.encode("utf-8")


def package_parts(path: Path) -> tuple[dict[str, bytes], bytes]:
    with ZipFile(path) as archive:
        return {entry.filename: archive.read(entry) for entry in archive.infolist()}, archive.comment


def write_input_workbook(path: Path) -> None:
    """Provide a named input, an independent formula and explicit formatting."""
    workbook = Workbook()
    try:
        sheet = workbook.active
        sheet.title = "Flexible Inputs"
        sheet["D7"] = 12345.67
        sheet["D8"] = 0.025
        sheet["E7"] = "=trident_principal*trident_rate"
        sheet["D7"].font = Font(name="Example Sans", size=11, bold=True, color="102030")
        sheet["D7"].fill = PatternFill("solid", fgColor="CCEEFF")
        sheet["D7"].border = Border(bottom=Side(style="thin", color="102030"))
        sheet["D7"].alignment = Alignment(horizontal="right")
        sheet["D7"].number_format = "#,##0.00"
        workbook.defined_names.add(DefinedName("trident_principal", attr_text="'Flexible Inputs'!$D$7"))
        workbook.defined_names.add(DefinedName("trident_rate", attr_text="'Flexible Inputs'!$D$8"))
        workbook.properties.creator = "LibraryOwner"
        workbook.properties.lastModifiedBy = "PreviousEditor"
        workbook.properties.title = "OriginalTitle"
        workbook.properties.subject = "Retain the input assumptions"
        workbook.loaded_theme = THEME_BYTES
        workbook.save(path)
    finally:
        workbook.close()
    with ZipFile(path, "a") as archive:
        archive.comment = b"Independent workbook fixture"


class WorkbookMetadataTests(unittest.TestCase):
    def setUp(self) -> None:
        # The tool deliberately refuses writes outside the workspace. Keep
        # ordinary test files inside it and clean each case independently.
        folder = tempfile.TemporaryDirectory(prefix=".metadata-test-", dir=ROOT)
        self.addCleanup(folder.cleanup)
        self.folder = Path(folder.name)
        self.path = self.folder / "inputs.xlsx"
        write_input_workbook(self.path)

    def test_normalizer_preserves_other_parts_and_theme_definitions_and_is_idempotent(self) -> None:
        before_parts, before_comment = package_parts(self.path)
        before_names, before_definition = theme_definition(before_parts[THEME_PATH])

        changed = _metadata_tool.normalize_workbook_metadata(self.path)
        after_parts, after_comment = package_parts(self.path)
        after_names, after_definition = theme_definition(after_parts[THEME_PATH])

        self.assertEqual(changed, (THEME_PATH,))
        self.assertEqual(before_names, ("OriginalTheme", "OriginalColours", "OriginalFonts", "OriginalFormats"))
        self.assertEqual(after_names, (PROJECT_NAME,) * 4)
        self.assertEqual(before_definition, after_definition)
        self.assertEqual(set(before_parts), set(after_parts))
        self.assertEqual(after_comment, before_comment)
        for name in before_parts:
            if name != THEME_PATH:
                with self.subTest(part=name):
                    self.assertEqual(after_parts[name], before_parts[name])
        first_bytes = self.path.read_bytes()
        self.assertEqual(_metadata_tool.normalize_workbook_metadata(self.path), ())
        self.assertEqual(self.path.read_bytes(), first_bytes)
        self.assertEqual(tuple(self.folder.iterdir()), (self.path,))

    def test_replacement_failure_retains_original_and_removes_staging_file(self) -> None:
        original = self.path.read_bytes()
        with patch.object(_metadata_tool.os, "replace", side_effect=PermissionError("File is in use")):
            with self.assertRaises(PermissionError):
                _metadata_tool.normalize_workbook_metadata(self.path)
        self.assertEqual(self.path.read_bytes(), original)
        self.assertEqual(tuple(self.folder.iterdir()), (self.path,))

    def test_duplicate_package_member_is_rejected_without_rewriting(self) -> None:
        with warnings.catch_warnings():
            warnings.simplefilter("ignore", UserWarning)
            with ZipFile(self.path, "a") as archive:
                archive.writestr(THEME_PATH, THEME_BYTES)
        original = self.path.read_bytes()
        with self.assertRaisesRegex(InputValidationError, "duplicate part names"):
            _metadata_tool.normalize_workbook_metadata(self.path)
        self.assertEqual(self.path.read_bytes(), original)
        self.assertEqual(tuple(self.folder.iterdir()), (self.path,))

    def test_outside_project_file_is_rejected_without_rewriting(self) -> None:
        with tempfile.TemporaryDirectory(prefix="workbook-metadata-outside-") as folder:
            outside = Path(folder).resolve() / "inputs.xlsx"
            self.assertFalse(outside.is_relative_to(ROOT))
            write_input_workbook(outside)
            original = outside.read_bytes()
            with self.assertRaisesRegex(InputValidationError, "inside the project workspace"):
                _metadata_tool.normalize_workbook_metadata(outside)
            self.assertEqual(outside.read_bytes(), original)
            self.assertEqual(tuple(outside.parent.iterdir()), (outside,))

    def test_malformed_theme_is_rejected_without_rewriting_or_staging(self) -> None:
        malformed = self.folder / "malformed.xlsx"
        with ZipFile(malformed, "w") as archive:
            archive.writestr(THEME_PATH, b"<theme>")
            archive.writestr("xl/worksheets/sheet1.xml", b"preserve this part")
        original = malformed.read_bytes()
        before_files = set(self.folder.iterdir())
        with self.assertRaises(ElementTree.ParseError):
            _metadata_tool.normalize_workbook_metadata(malformed)
        self.assertEqual(malformed.read_bytes(), original)
        self.assertEqual(set(self.folder.iterdir()), before_files)

    def test_atomic_save_preserves_named_inputs_formula_style_and_theme_definition(self) -> None:
        destination = self.folder / "output.xlsx"
        workbook = load_workbook(self.path)
        try:
            sheet = workbook["Flexible Inputs"]
            names = {name.name: name.attr_text for name in workbook.defined_names.values()}
            style = deepcopy(sheet["D7"]._style)
            _, original_theme_definition = theme_definition(workbook.loaded_theme)
            _save_atomic(workbook, destination)
        finally:
            workbook.close()
        output = load_workbook(destination)
        try:
            adapter = NamedWorkbook(output)
            self.assertEqual(adapter.scalar("trident_principal"), 12345.67)
            self.assertEqual(adapter.scalar("trident_rate"), 0.025)
            self.assertEqual({name.name: name.attr_text for name in output.defined_names.values()}, names)
            sheet = output["Flexible Inputs"]
            self.assertEqual((sheet["E7"].value, sheet["E7"].data_type), ("=trident_principal*trident_rate", "f"))
            self.assertEqual(sheet["D7"]._style, style)
            self.assertEqual((sheet["D7"].font.name, sheet["D7"].font.color.rgb), ("Example Sans", "00102030"))
            self.assertEqual(sheet["D7"].fill.fgColor.rgb, "00CCEEFF")
            # Some readers fill an absent creator with their own default.
            # Inspect the written package to prove no author was attributed.
            with ZipFile(destination) as archive:
                core = ElementTree.fromstring(archive.read("docProps/core.xml"))
            author_elements = [element for element in core.iter()
                if element.tag.rsplit("}", 1)[-1] in {"creator", "lastModifiedBy"}]
            self.assertTrue(all(element.text in {None, ""} for element in author_elements))
            self.assertIsNone(output.properties.lastModifiedBy)
            self.assertEqual(output.properties.title, PROJECT_NAME)
            self.assertEqual(output.properties.subject, "Retain the input assumptions")
            labels, saved_definition = theme_definition(output.loaded_theme)
            self.assertEqual(labels, (PROJECT_NAME,) * 4)
            self.assertEqual(saved_definition, original_theme_definition)
        finally:
            output.close()
        self.assertEqual(set(self.folder.iterdir()), {self.path, destination})


if __name__ == "__main__":
    unittest.main()
