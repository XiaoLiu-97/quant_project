"""Independent collar answers across native coupons, credit and closing edits.

All hand coupon examples hold 100 face on exact 30E/360 quarters; one percent
annual coupon therefore posts 0.25. Reference observations stay unmodified.
"""

from dataclasses import replace
from datetime import date
from decimal import Decimal, Inexact, localcontext
import unittest

from trident.cashflows.engine import ContractualCashflowEngine
from trident.credit import CreditEventCashflowEngine, DefaultEvent, PrepaymentEvent
from trident.domain.models import AmortizationType, CouponType, LoanPosition
from trident.domain.numeric import compose_floating_rate
from trident.market import FlatRateProvider
from trident.application.scenarios import ScenarioDefinition, ScenarioRunner
from test_cashflows_principal import terms_for
from test_scenarios import request, edit

D = Decimal


def floating(**changes):
    """100 face, 400 bps spread; only explicitly supplied bounds bind."""
    terms = terms_for(coupon_type=CouponType.FLOATING, fixed_rate=None,
                      rate_index="EURIBOR_3M", spread_bps=D(400), **changes)
    return LoanPosition(terms, terms.start_date, D(100))


class CouponBoundsTests(unittest.TestCase):
    def setUp(self):
        self.provider = FlatRateProvider({"EURIBOR_3M": D(".10")})
        self.engine = ContractualCashflowEngine(self.provider)

    def test_reference_then_all_in_cap_and_raw_index_diagnostic(self):
        rows = self.engine.generate(floating(index_cap=D(".05"), all_in_cap=D(".08")))
        self.assertEqual([r.cash_interest for r in rows], [D(2)] * 3)
        self.assertTrue(all(r.index_rate == D(".10") and r.all_in_rate == D(".08") for r in rows))
        self.assertEqual(sum(r.principal_repayment for r in rows), D(100))

    def test_all_in_floor_after_reference_cap(self):
        rows = self.engine.generate(floating(index_cap=D(".05"), all_in_floor=D(".10")))
        self.assertEqual(rows[0].cash_interest, D("2.50"))

    def test_zero_bound_differs_from_disabled(self):
        self.assertEqual(self.engine.generate(floating())[0].cash_interest, D("3.50"))
        self.assertEqual(self.engine.generate(floating(index_cap=D(0)))[0].cash_interest, D(1))
        self.assertEqual(self.engine.generate(floating(all_in_cap=D(0)))[0].cash_interest, D(0))

    def test_negative_rate_is_not_silently_floored(self):
        provider = FlatRateProvider({"EURIBOR_3M": D("-.06")})
        rows = ContractualCashflowEngine(provider).generate(floating())
        self.assertEqual(rows[0].cash_interest, D("-.50"))
        self.assertEqual(self.engine.generate(floating(all_in_cap=D("-.01")))[0].cash_interest, D("-.25"))

    def test_reference_and_all_in_collars_have_separate_scopes(self):
        rate = compose_floating_rate(D("-.02"), D(100), D(0), all_in_floor=D(".02"))
        self.assertEqual(rate, D(".02"))
        # A final cap can sit below the reference floor plus margin.
        self.assertEqual(compose_floating_rate(D(0), D(400), D(".05"), all_in_cap=D(".02")), D(".02"))
        self.assertEqual(compose_floating_rate(D(1), D(400), D(".05"), index_cap=D(".05")), D(".09"))

    def test_invalid_pairs_and_fixed_contract_fields_rejected(self):
        for changes in ({"index_floor": D(".06"), "index_cap": D(".05")},
                        {"all_in_floor": D(".10"), "all_in_cap": D(".09")}):
            with self.subTest(changes=changes), self.assertRaises(ValueError):
                floating(**changes)
        for field in ("index_cap", "all_in_floor", "all_in_cap"):
            with self.subTest(field=field), self.assertRaises(ValueError):
                terms_for(**{field: D(0)})
            for invalid in (0, D("NaN"), D("Infinity")):
                with self.subTest(field=field, invalid=invalid), self.assertRaises((TypeError, ValueError)):
                    floating(**{field: invalid})

    def test_clamping_preserves_exact_rate_under_hostile_context(self):
        raw = D(".000000000000000000000000000000000000001")
        expected = D(".010000000000000000000000000000000000001")
        with localcontext() as ctx:
            ctx.prec = 2
            ctx.traps[Inexact] = True
            self.assertEqual(compose_floating_rate(raw, D(100), index_cap=D(".02")), expected)

    def test_projected_annuity_uses_bounded_coupon_factors(self):
        rows = self.engine.generate(floating(maturity_date=date(2026, 7, 1),
            all_in_cap=D(".04"), amortization_type=AmortizationType.ANNUITY,
            balloon_amount=D(0)))
        # 100*(1.01)^2/(1+1.01) = 50.75124378; cents principal
        # 49.75 then 50.25, with interest 1.00 then 0.50.
        self.assertEqual([r.cash_interest for r in rows], [D(1), D(".50")])
        self.assertEqual([r.principal_repayment for r in rows], [D("49.75"), D("50.25")])

    def test_credit_no_event_and_midperiod_prepayment_use_bounded_rate(self):
        position = floating(index_cap=D(".05"), all_in_cap=D(".08"))
        engine = CreditEventCashflowEngine(self.provider)
        result = engine.generate(position)
        self.assertEqual(result.total_cash_interest, D(6))
        prepaid = engine.generate(position, PrepaymentEvent(position.terms.loan_id, date(2026, 2, 1)))
        # Exact 30/360 month: 100 * 8% / 12 = 0.666..., posted 0.67.
        self.assertEqual(prepaid.total_cash_interest, D(".67"))
        self.assertEqual(prepaid.total_scheduled_principal, D(0))
        self.assertEqual(prepaid.final_performing_par, D(0))

    def test_default_does_not_create_bounded_unpaid_coupon_cash(self):
        position = floating(all_in_cap=D(".08"))
        result = CreditEventCashflowEngine(self.provider).generate(position,
            DefaultEvent(position.terms.loan_id, date(2026, 2, 1)))
        self.assertEqual(result.total_cash_interest, 0)
        self.assertEqual(result.defaulted_exposure, D(100))

    def test_public_reference_rejects_uncapped_contractual_rows(self):
        position = floating(all_in_cap=D(".08"))
        unbounded = replace(position, terms=replace(position.terms, all_in_cap=None))
        rows = self.engine.generate(unbounded)
        with self.assertRaises(ValueError):
            CreditEventCashflowEngine(self.provider).apply(position, rows)

    def test_scenario_collars_are_atomic_and_order_independent(self):
        baseline = request()
        original = baseline.cashflow_request.positions[0]
        original = replace(original, terms=replace(original.terms, all_in_floor=D(".02"), all_in_cap=D(".03")))
        baseline = replace(baseline, cashflow_request=replace(baseline.cashflow_request, positions=(original,)))
        edits = (edit("ASSET", "all_in_floor", D(".04")), edit("ASSET", "all_in_cap", D(".05")))
        batch = ScenarioRunner().run(baseline, (ScenarioDefinition("FORWARD", edits), ScenarioDefinition("REVERSE", edits[::-1])))
        self.assertEqual(batch.scenarios[0].result.cashflows.cashflows, batch.scenarios[1].result.cashflows.cashflows)
        self.assertEqual(batch.scenarios[0].result.equity_irr, batch.scenarios[1].result.equity_irr)
        self.assertEqual(original.terms.all_in_cap, D(".03"))
        self.assertTrue(all(r.all_in_rate == D(".05") for r in batch.scenarios[0].result.cashflows.cashflows))


if __name__ == "__main__":
    unittest.main()
