"""Small local launcher; all calculation paths call the same application."""

import argparse
import json
import sys
from decimal import DecimalException
from fractions import Fraction
from pathlib import Path

from trident.adapters.csv_input import run_synthetic_example
from trident.application.clo_services import TridentModelResult
from trident.application.services import ProjectionResult
from trident import __version__
from trident.domain.numeric import post_currency


def _summary(result: ProjectionResult | TridentModelResult) -> dict[str, object]:
    """Use exact decimal text in JSON instead of binary float output."""
    model = result if isinstance(result, TridentModelResult) else None
    result = result.cashflows if model is not None else result
    summary = {
        "version": __version__, "run_id": result.run_id, "mode": "CASHFLOW_ONLY",
        "rate_provenance": result.rate_provenance, "asset_count": result.asset_count,
        "projection_start_date": result.projection_start_date.isoformat(),
        "rate_provider_kind": result.rate_provider_kind,
        "market_data_as_of": result.market_data_as_of.isoformat() if result.market_data_as_of is not None else None,
        "cashflow_row_count": len(result.cashflows),
        "currency": result.currency,
        "opening_collateral_par": str(result.opening_collateral_par),
        "total_pik_interest": str(result.total_pik_interest),
        "collateral_par_eur": str(result.opening_collateral_par),
        "total_principal_eur": str(result.total_principal),
        "total_contractual_interest_eur": str(result.total_interest),
        "first_payment_date": result.first_payment_date.isoformat(),
        "first_payment_interest_eur": str(result.first_payment_interest),
        "debt_proceeds_eur": None if result.funding is None else str(result.funding.debt_proceeds),
        "equity_cash_funding_eur": None if result.funding is None else str(result.funding.equity_cash_funding),
        "clo_waterfall_and_equity_irr": "NOT_SELECTED",
    }
    if result.currency != "EUR":
        # A standalone USD/GBP run reports local units. Do not label its cash
        # as EUR or imply an FX conversion absent from the financial model.
        for key in tuple(summary):
            if key.endswith("_eur"):
                summary[key[:-4]] = summary.pop(key)
    if model is not None:
        summary.update(
            mode="CASHFLOW_ONLY" if model.clo is None else "CLO_BASELINE",
            clo_waterfall_and_equity_irr="NOT_SELECTED" if model.clo is None else model.clo.status.value,
            equity_irr_status=model.equity_irr.status.value,
            equity_irr=None if model.equity_irr.value is None else str(model.equity_irr.value),
            equity_moic=None if model.equity_moic.value is None else str(model.equity_moic.value),
            portfolio_metrics={metric.name: {"value": None if metric.value is None else str(metric.value), "status": metric.status.value}
                               for metric in model.opening_portfolio.metrics},
            opening_limit_statuses={row.limit_id: row.status.value for row in model.opening_portfolio.limits},
        )
        if model.clo is not None:
            summary.update(clo_period_count=len(model.clo.periods),
                           equity_distributions_eur=str(model.clo.total_equity_distributions),
                           final_debt_par_eur=str(model.clo.final_debt_par),
                           terminal_value_available=model.clo.terminal_value_available)
        if model.clo_opening_state is not None:
            summary.update(mode='EXISTING_CLO_POST_DISTRIBUTION', equity_return_basis='FORWARD_FROM_OPENING_VALUE',
                           forward_equity_value_eur=str(model.equity_cashflows[0].amount.copy_abs()),
                           equity_value_source=model.equity_value_source,
                           original_first_projected_period=model.clo.first_projected_period_number)
        if model.credit_projections:
            summary["mode"] = "CASHFLOW_CREDIT_SCENARIO" if model.clo is None else "CLO_CREDIT_SCENARIO"
            summary["credit_projection"] = {
                "mode": "EXPLICIT_DATED_EVENTS", "contractual_cashflows_are_reference": True,
                "principal_collections_eur": str(post_currency(sum((Fraction(row.total_principal_collections) for row in model.credit_projections), Fraction()))),
                "cash_interest_eur": str(post_currency(sum((Fraction(row.total_cash_interest) for row in model.credit_projections), Fraction()))),
                "defaulted_exposure_eur": str(post_currency(sum((Fraction(row.defaulted_exposure) for row in model.credit_projections), Fraction()))),
                "recognized_par_loss_eur": str(post_currency(sum((Fraction(row.total_par_loss) for row in model.credit_projections), Fraction()))),
            }
            if model.clo is not None:
                summary["credit_projection"].update(
                    final_defaulted_par_eur=str(model.clo.final_defaulted_par),
                    recovery_collections_through_clo_horizon_eur=str(model.clo.total_recovery_collections),
                )
    return summary


def _compact_interface(path):
    """Inspect the package marker without opening Excel or changing a file."""
    from zipfile import ZipFile, BadZipFile
    try:
        with ZipFile(path) as archive:
            return b'trident_ui_schema' in archive.read('xl/workbook.xml')
    except BadZipFile as error:
        # Routing precedes either workbook adapter. A corrupt Excel package
        # must still produce the same clean input error and preserve the file.
        raise ValueError('Input is not a readable Excel workbook package') from error


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Project Trident unified cashflows, CLO and portfolio model")
    commands = parser.add_subparsers(dest="command", required=True)
    example = commands.add_parser("example", help="Run the labelled EUR500m synthetic CSV example")
    example.add_argument("--directory", type=Path, default=Path("data/examples/hybrid_500m"))
    clo_example = commands.add_parser("example-clo", help="Run the synthetic EUR500m H00 cash-pay NO_TRADES CLO")
    clo_example.add_argument("--directory", type=Path, default=Path("data/examples/hybrid_500m"))
    commands.add_parser("example-credit", help="Run a labelled 100-par default/recovery hand-ledger fixture")
    workbook = commands.add_parser("workbook", help="Read and update one named-range CLO workbook")
    workbook.add_argument("path", type=Path)
    workbook.add_argument("--output", type=Path, help="Optional complete model copy; default updates the same workbook")
    check = commands.add_parser("check-optimization", help="Check frozen optimization inputs without solving or updating Excel")
    check.add_argument("path", type=Path)
    check.add_argument("--mode", choices=("candidate", "static"), default="candidate")
    model_check = commands.add_parser('check-model', help='Read-only input, stale-result and optional benchmark checks')
    model_check.add_argument('path', type=Path)
    model_check.add_argument('--project', action='store_true', help='Calculate selected services in memory; never save the workbook')
    model_check.add_argument('--require-reconciliation', action='store_true', help='Require fresh independent benchmark MATCH; needs --project')
    arguments = parser.parse_args(argv)
    try:
        integrated_run = None
        if arguments.command == 'check-model':
            if _compact_interface(arguments.path):
                if arguments.require_reconciliation:
                    raise ValueError('Compact interface independent reconciliation is not selected; review the cash/return and regression evidence instead')
                from trident.adapters.interface_run import check_interface_workbook
                report = check_interface_workbook(arguments.path, project=arguments.project)
                print(json.dumps(report, indent=2, ensure_ascii=False))
                return 0

            from trident.adapters.pilot_workbook import check_model_workbook
            report = check_model_workbook(arguments.path, project=arguments.project,
                require_reconciliation=arguments.require_reconciliation)
            print(json.dumps(report, indent=2, ensure_ascii=False))
            return 2 if report['status'] == 'REVIEW_FAILED' else 0
        if arguments.command == "check-optimization":
            if _compact_interface(arguments.path):
                from dataclasses import asdict
                from trident.adapters.interface_inputs import read_interface_inputs, static_optimization_request, closing_candidate_request
                from trident.application.optimization_readiness import OptimizationReadinessService
                inputs=read_interface_inputs(arguments.path)
                request=(closing_candidate_request(inputs) if arguments.mode=='candidate' else static_optimization_request(inputs))
                report=OptimizationReadinessService().check(request)
                print(json.dumps({'status':report.status,**asdict(report),'scope':'FROZEN_INPUT_DATA_ONLY','execution_status':'NOT_EXECUTED'},indent=2,ensure_ascii=False))
                return 0 if report.ready else 2
            from trident.adapters.optimization_preflight import check_optimization_workbook
            report = check_optimization_workbook(arguments.path, mode=arguments.mode)
            print(json.dumps(report, indent=2, ensure_ascii=False))
            return 0 if report["status"] == "DATA_READY" else 2
        if arguments.command == "example":
            result = run_synthetic_example(arguments.directory)
        elif arguments.command == "example-clo":
            from trident.adapters.clo_example import run_synthetic_clo_example
            result = run_synthetic_clo_example(arguments.directory)
        elif arguments.command == "example-credit":
            from trident.adapters.credit_example import run_credit_example
            result = run_credit_example()
        else:
            from trident.adapters.excel import run_workbook
            if _compact_interface(arguments.path):
                from trident.adapters.interface_run import run_interface_workbook
                integrated_run=run_interface_workbook(arguments.path,arguments.output)
                result=integrated_run.baseline
            else:
                result = run_workbook(arguments.path, arguments.output)
        summary=_summary(result)
        if integrated_run is not None:
            summary.update(interface_schema='1.0',input_fingerprint=integrated_run.inputs.input_fingerprint,
                complete_cases=[c.case_id for c in integrated_run.cases],
                library_reference_cashflows=len(integrated_run.library_projection.cashflows),
                warnings=list(integrated_run.inputs.warnings))
        print(json.dumps(summary, indent=2, ensure_ascii=False))
        return 0
    except (ValueError, TypeError, OSError, ArithmeticError, DecimalException, KeyError) as error:
        print(f"Trident input/run error: {error}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
