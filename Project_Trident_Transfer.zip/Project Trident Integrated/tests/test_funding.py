"""Funding known answers distinguish nominal, prices and cash contributions."""

import unittest
from decimal import Decimal, Inexact, localcontext

from trident.funding.engine import AssetPurchase, DebtIssue, FundingEngine

D = Decimal


class FundingKnownAnswerTests(unittest.TestCase):
    def test_hybrid_sources_uses(self) -> None:
        purchases = (AssetPurchase("INFRA", D("350000000"), D(100)),
                     AssetPurchase("BSL", D("150000000"), D("98.5")))
        issues = tuple(DebtIssue(name, D(par), D(price)) for name, par, price in (
            ("A", "315000000", "100"), ("B", "55000000", "100"),
            ("C", "35000000", "99.5"), ("D", "35000000", "99"), ("E", "10000000", "98"),
        ))
        result = FundingEngine().calculate(purchases, issues, upfront_fees=D("2500000"), cash_reserve=D("2500000"))
        self.assertEqual(result.asset_clean_cost, D("497750000"))
        self.assertEqual(result.debt_par, D("450000000"))
        self.assertEqual(result.debt_proceeds, D("449275000"))
        self.assertEqual(result.equity_cash_funding, D("53475000"))
        self.assertEqual(result.total_sources, result.total_uses)

    def test_acquired_accrued_is_separate_from_clean_price(self) -> None:
        result = FundingEngine().calculate((AssetPurchase("L", D(100), D(98), D(2)),), (), upfront_fees=D(1), cash_reserve=D(3))
        self.assertEqual(result.asset_clean_cost, D(98))
        self.assertEqual(result.acquired_accrued_interest, D(2))
        self.assertEqual(result.equity_cash_funding, D(104))

    def test_per_issue_half_cent_and_caller_context(self) -> None:
        with localcontext() as caller:
            caller.prec = 2
            caller.traps[Inexact] = True
            result = FundingEngine().calculate((AssetPurchase("L", D(10), D("99.95")),),
                (DebtIssue("A", D(1), D("99.5")),), upfront_fees=D(0), cash_reserve=D(0))
            self.assertEqual(result.asset_clean_cost, D("10.00"))
            self.assertEqual(result.debt_proceeds, D("1.00"))
            self.assertEqual(result.equity_cash_funding, D(9))

    def test_invalid_and_duplicate_inputs(self) -> None:
        purchase = AssetPurchase("L", D(100), D(100))
        for purchases, issues in (((), ()), ((purchase, purchase), ()),
                                 ((purchase,), (DebtIssue("A", D(200), D(100)),))):
            with self.subTest(purchases=purchases, issues=issues), self.assertRaises(ValueError):
                FundingEngine().calculate(purchases, issues, upfront_fees=D(0), cash_reserve=D(0))
        with self.assertRaises(ValueError):
            AssetPurchase("L", D(100), D("NaN"))


if __name__ == "__main__":
    unittest.main()
