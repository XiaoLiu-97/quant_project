"""Independent event-date checks reach candidate admission and Excel reports.

Quoted margins below are literal contractual levels. A dip and recovery before
the first quarterly distribution proves why payment-only monitoring misses a
configured quality failure; extra analytical dates must not alter cash gates.
"""

from dataclasses import replace
from datetime import date, datetime
from decimal import Decimal
import unittest

from trident.analysis import LimitDirection, LimitSpec, LimitStatus
from trident.application.clo_services import TridentModelService
from trident.application.construction import ClosingPoolRedesignService, ConstructionStatus
from trident.application.portfolio_phases import ACTIVE_PORTFOLIO_PHASES
from trident.domain.models import CouponStep, InputValidationError

from test_construction import SECOND, fixture, replace_candidate
from test_dated_coupon_analytics import model_request


D = Decimal
DIP, RECOVERY = date(2026, 2, 10), date(2026, 3, 10)


class ObservationIntegrationTests(unittest.TestCase):
    def test_temporary_dip_is_observed_even_when_every_payment_margin_passes(self):
        request = model_request(stepped=False)
        position = request.cashflow_request.positions[0]
        stepped = replace(position, terms=replace(position.terms, coupon_steps=(
            CouponStep(DIP, spread_bps=D(200)),
            CouponStep(RECOVERY, spread_bps=D(500)),
        )))
        # The CLO is quarterly here, so both dates lie before its first gate.
        terms = replace(request.clo_terms, frequency_months=3)
        limit = LimitSpec("MIN_WAS", "WAS_BPS", D(400), LimitDirection.MINIMUM,
                          phases=ACTIVE_PORTFOLIO_PHASES)
        request = replace(request, cashflow_request=replace(request.cashflow_request,
            positions=(stepped,)), clo_terms=terms, limits=(limit,))
        result = TridentModelService().run(request)
        by_date = {report.as_of_date: report for report in result.portfolio_observations}
        self.assertEqual(by_date[DIP].metric("WAS_BPS").value, D(200))
        self.assertIs(by_date[DIP].limits[0].status, LimitStatus.BREACH)
        self.assertEqual(by_date[RECOVERY].metric("WAS_BPS").value, D(500))
        self.assertTrue(all(report.limits[0].status in {LimitStatus.PASS, LimitStatus.NOT_APPLICABLE}
                            for report in result.portfolio_snapshots))
        self.assertEqual(len(result.clo.periods), 4)
        self.assertEqual(len(result.portfolio_snapshots), 4)

    def test_full_candidate_replay_rejects_temporary_dip(self):
        limit = LimitSpec("MIN_WAS", "WAS_BPS", D(400), LimitDirection.MINIMUM,
                          phases=ACTIVE_PORTFOLIO_PHASES)
        request = fixture(new_maturity=SECOND, old_maturity=SECOND, limits=(limit,))
        native = next(row for row in request.candidate_snapshot.candidates if row.asset_id == "NEW")
        position = replace(native.position, terms=replace(native.position.terms,
            coupon_steps=(CouponStep(DIP, spread_bps=D(200)),
                          CouponStep(RECOVERY, spread_bps=D(800)))))
        request = replace_candidate(request, "NEW", position=position)
        result = ClosingPoolRedesignService().run(request)
        self.assertTrue(result.optimization.validated)
        self.assertIs(result.status, ConstructionStatus.REPLAY_REJECTED)
        self.assertFalse(result.validated)
        self.assertTrue(any(finding.code == "PORTFOLIO_LIMIT_BREACH" and finding.payment_date == DIP
                            for finding in result.findings))

    def test_explicit_observation_dates_leave_cash_and_waterfall_gates_unchanged(self):
        request = model_request(stepped=False)
        baseline = TridentModelService().run(request)
        dated = TridentModelService().run(replace(request,
            portfolio_observation_dates=(date(2026, 2, 3),)))
        self.assertIn(date(2026, 2, 3), [row.as_of_date for row in dated.portfolio_observations])
        self.assertEqual(dated.cashflows.cashflows, baseline.cashflows.cashflows)
        self.assertEqual(dated.cashflows.funding, baseline.cashflows.funding)
        self.assertEqual(dated.clo, baseline.clo)
        self.assertEqual(dated.equity_irr, baseline.equity_irr)
        self.assertEqual(dated.portfolio_snapshots, baseline.portfolio_snapshots)

    def test_additional_dates_reject_invalid_types_and_actual_horizon(self):
        request = model_request(stepped=False)
        for invalid in ([DIP], (datetime(2026, 2, 10),), (None,)):
            with self.subTest(invalid=invalid), self.assertRaises(InputValidationError):
                replace(request, portfolio_observation_dates=invalid)
        for invalid_date in (date(2025, 1, 1), date(2030, 1, 1)):
            with self.subTest(invalid_date=invalid_date), self.assertRaises(InputValidationError):
                TridentModelService().run(replace(request,
                    portfolio_observation_dates=(invalid_date,)))


if __name__ == "__main__":
    unittest.main()
