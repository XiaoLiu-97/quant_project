"""Presentation preservation, safe horizontal growth and named-role controls.

These tests inspect underlying values/formulas and independent Table identities,
not screenshots. Number-format changes may hide decimal places on face/par;
they must never round the stored value or change cash/claim precision.
"""

from copy import copy
from datetime import date
from decimal import Decimal as D
from io import BytesIO
import unittest

from openpyxl import Workbook, load_workbook
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.workbook.defined_name import DefinedName
from openpyxl.worksheet.table import Table, TableColumn

from trident.adapters import excel_schema as schema
from trident.adapters.excel import NamedWorkbook
from trident.domain.models import InputValidationError
from trident.adapters.pilot_workbook import ensure_pilot_interface, input_fingerprint
from trident.adapters.workbook_presentation import (
    FACE_NUMBER_FORMAT, INPUT_TAB_COLOR, OUTPUT_TAB_COLOR,
    HORIZONTAL_INPUT_GROUPS, apply_workbook_presentation, presentation_payload,
)
from workbook_fixtures import INPUT_TEMPLATE, put_records


def registered_table(book, key, title, rows=()):
    """Small independently authored Table; only fixture layout uses addresses."""
    from openpyxl.utils import get_column_letter
    sheet = book.create_sheet(title)
    columns = schema.TABLE_COLUMNS[key]
    sheet.cell(2, 1, title)
    sheet.cell(3, 1, 'Independent table instruction')
    sheet.merge_cells(start_row=3, start_column=1, end_row=3, end_column=len(columns))
    for offset, field in enumerate(columns, 1):
        sheet.cell(5, offset, field)
        sheet.cell(6, offset).alignment = Alignment(vertical='center')
        sheet.column_dimensions[get_column_letter(offset)].width = 24
    table = Table(displayName=schema.TABLE_NAMES[key],
        ref=f'A5:{get_column_letter(len(columns))}{5 + max(1, len(rows))}',
        tableColumns=[TableColumn(id=index, name=field) for index, field in enumerate(columns, 1)])
    sheet.add_table(table)
    book.defined_names.add(DefinedName(schema.TABLE_RANGE_NAMES[key],
        attr_text=f"'{title}'!$A$5:${get_column_letter(len(columns))}${5 + max(1, len(rows))}"))
    if rows:
        put_records(NamedWorkbook(book), key, rows)
    return sheet


class WorkbookPresentationTests(unittest.TestCase):
    def setUp(self):
        self.book = Workbook()
        self.addCleanup(self.book.close)
        self.book.active.title = 'User Notes'
        self.adapter = NamedWorkbook(self.book)

    def expenses(self):
        left = registered_table(self.book, 'closing_costs', 'Closing Costs', ({'cost_id': 'C', 'amount': 2.47},))
        right = registered_table(self.book, 'recurring_expenses', 'Recurring Expenses', ({'expense_id': 'R', 'annual_amount': 3.81},))
        return left, right

    def test_payload_exports_one_reusable_semantic_rule_matrix(self):
        payload = presentation_payload()
        self.assertEqual(payload['input_tab_color'], INPUT_TAB_COLOR)
        self.assertEqual(payload['output_tab_color'], OUTPUT_TAB_COLOR)
        self.assertIn('nominal_amount', payload['face_columns'])
        self.assertNotIn('principal_amount', payload['face_columns'])
        self.assertNotIn('principal_repayment', payload['face_columns'])
        self.assertEqual(len(payload['horizontal_groups']), 5)

    def test_underlying_face_and_cash_values_are_preserved_with_different_formats(self):
        sheet = registered_table(self.book, 'tranche_cashflows', 'Custom Notes', ())
        fields = schema.TABLE_COLUMNS['tranche_cashflows']
        for field, value in (('opening_balance', 80.47), ('closing_balance', 40.12), ('current_coupon_due', 1.49)):
            sheet.cell(6, fields.index(field) + 1, value).number_format = '#,##0.00'
        apply_workbook_presentation(self.adapter)
        face = sheet.cell(6, fields.index('opening_balance') + 1)
        cash = sheet.cell(6, fields.index('current_coupon_due') + 1)
        self.assertEqual((face.value, face.number_format), (80.47, FACE_NUMBER_FORMAT))
        self.assertEqual((cash.value, cash.number_format), (1.49, '#,##0.00'))
        for row in sheet.iter_rows(min_row=5, max_row=6, max_col=len(fields)):
            self.assertTrue(all(cell.alignment.horizontal == cell.alignment.vertical == 'center' for cell in row))

    def test_detailed_notional_display_preserves_face_and_cash_cents(self):
        sheet = registered_table(self.book, 'cashflow_detailed_export', 'Contract Detail', ())
        fields = schema.TABLE_COLUMNS['cashflow_detailed_export']
        values = {'beginning_notional': 100.47, 'ending_notional': 105.62,
                  'cash_interest': 1.49, 'pik_interest': 5.15, 'principal_repayment': 2.31}
        for field, value in values.items():
            sheet.cell(6, fields.index(field) + 1, value).number_format = '#,##0.00'
        apply_workbook_presentation(self.adapter)
        for field, value in values.items():
            with self.subTest(field=field):
                cell = sheet.cell(6, fields.index(field) + 1)
                self.assertEqual(cell.value, value)
                self.assertEqual(cell.number_format, FACE_NUMBER_FORMAT if field.endswith('_notional')
                                 else '#,##0.00')

    def test_summary_value_precision_depends_on_row_semantics(self):
        sheet = registered_table(self.book, 'funding_summary', 'Sources Uses', (
            {'name': 'collateral_par', 'value': 100.47, 'unit': 'EUR'},
            {'name': 'acquired_accrued_interest', 'value': 1.47, 'unit': 'EUR'}))
        sheet['B6'].number_format = sheet['B7'].number_format = '#,##0.00'
        apply_workbook_presentation(self.adapter)
        self.assertEqual((sheet['B6'].value, sheet['B6'].number_format), (100.47, FACE_NUMBER_FORMAT))
        self.assertEqual((sheet['B7'].value, sheet['B7'].number_format), (1.47, '#,##0.00'))

    def test_guidance_input_output_groups_and_mixed_selector_priority_are_explicit(self):
        output = registered_table(self.book, 'concentrations', 'A Report')
        input_ = registered_table(self.book, 'factor_mapping', 'Z Inputs')
        mixed = self.book.create_sheet('Run Control')
        mixed['B2'], mixed['B3'] = 'CLO_BASELINE', .123456
        self.book.defined_names.add(DefinedName(schema.SCALAR_NAMES['mode'], attr_text="'Run Control'!$B$2"))
        self.book.defined_names.add(DefinedName(schema.SCALAR_NAMES['result_equity_irr'], attr_text="'Run Control'!$B$3"))
        self.book.create_sheet('Guidance')
        report = apply_workbook_presentation(self.adapter)
        self.assertEqual(self.book.sheetnames, ['Guidance', 'Z Inputs', 'Run Control', 'A Report', 'User Notes'])
        self.assertEqual(report['input_sheets'], ('Z Inputs', 'Run Control'))
        self.assertEqual(input_.sheet_properties.tabColor.rgb[-6:], INPUT_TAB_COLOR)
        self.assertEqual(mixed.sheet_properties.tabColor.rgb[-6:], INPUT_TAB_COLOR)
        self.assertEqual(output.sheet_properties.tabColor.rgb[-6:], OUTPUT_TAB_COLOR)
        self.assertEqual(mixed['B3'].value, .123456)

    def test_market_data_values_formulas_geometry_and_all_number_formats_are_preserved(self):
        sheet = self.book.create_sheet('Market Data')
        sheet['A1'], sheet['B2'], sheet['C2'], sheet['D2'] = 'Market', date(2026, 1, 1), .03125, '=C2'
        sheet['B2'].number_format, sheet['C2'].number_format = 'dd-mmm-yyyy', '0.0000%'
        sheet['C2'].font = Font(name='Arial', size=10, color='AABBCC')
        sheet['C2'].fill = PatternFill('solid', fgColor='112233')
        sheet['C2'].border = Border(bottom=Side(style='thin', color='ABCDEF'))
        sheet.column_dimensions['C'].width, sheet.row_dimensions[2].height = 29, 22
        sheet.merge_cells('A4:C4')
        before = [(sheet[key].value, sheet[key].number_format, copy(sheet[key].font),
                   copy(sheet[key].fill), copy(sheet[key].border)) for key in ('A1', 'B2', 'C2', 'D2')]
        # The user's uniform-font policy applies even to inherited default
        # styles. Every other font attribute and workbook value is preserved.
        for record in before:
            record[2].name, record[2].scheme = 'Arial', None
        apply_workbook_presentation(self.adapter)
        after = [(sheet[key].value, sheet[key].number_format, copy(sheet[key].font),
                  copy(sheet[key].fill), copy(sheet[key].border)) for key in ('A1', 'B2', 'C2', 'D2')]
        self.assertEqual(after, before)
        self.assertEqual((sheet.column_dimensions['C'].width, sheet.row_dimensions[2].height), (29, 22))
        self.assertEqual(str(sheet.merged_cells), 'A4:C4')
        self.assertEqual(sheet['C2'].alignment.horizontal, 'center')

    def test_safe_expense_pair_preserves_cash_comments_links_and_column_widths(self):
        from openpyxl.comments import Comment
        left, right = self.expenses()
        left['A6'].comment = Comment('Verified expense classification', 'Portfolio Operations')
        right['A6'].hyperlink = 'https://example.com/expense-policy'
        right.column_dimensions['A'].width = 42
        self.book.active = self.book.sheetnames.index(right.title)
        report = apply_workbook_presentation(self.adapter)
        result = next(row for row in report['consolidation'] if row['sheet'] == 'Expense Inputs')
        self.assertEqual(result['status'], 'GROUPED')
        self.assertNotIn('Closing Costs', self.book.sheetnames)
        self.assertNotIn('Recurring Expenses', self.book.sheetnames)
        sheet = self.book['Expense Inputs']
        self.assertEqual((sheet['B6'].value, sheet['F6'].value), (2.47, 3.81))
        self.assertEqual(sheet['A6'].comment.text, 'Verified expense classification')
        self.assertEqual(sheet['E6'].hyperlink.target, 'https://example.com/expense-policy')
        self.assertEqual(sheet['E6'].hyperlink.ref, 'E6')
        self.assertEqual(sheet.column_dimensions['E'].width, 42)
        self.assertEqual(str(sheet.merged_cells), 'A3:B3 E3:F3')
        self.assertEqual(self.book.active.title, 'Expense Inputs')
        self.assertEqual(self.book.defined_names[schema.TABLE_RANGE_NAMES['recurring_expenses']].attr_text,
                         schema.TABLE_NAMES['recurring_expenses'] + '[#All]')

    def test_horizontal_tables_expand_to_different_row_counts_without_collision(self):
        self.expenses()
        apply_workbook_presentation(self.adapter)
        left_rows = tuple({'cost_id': f'C{index}', 'amount': index + .01} for index in range(100))
        right_rows = ({'expense_id': 'R1', 'annual_amount': 3.81}, {'expense_id': 'R2', 'annual_amount': 4.91})
        put_records(self.adapter, 'closing_costs', left_rows)
        put_records(self.adapter, 'recurring_expenses', right_rows)
        self.assertEqual(len(self.adapter.table_records(schema.TABLE_RANGE_NAMES['closing_costs'], schema.TABLE_NAMES['closing_costs'])), 100)
        self.assertEqual(len(self.adapter.table_records(schema.TABLE_RANGE_NAMES['recurring_expenses'], schema.TABLE_NAMES['recurring_expenses'])), 2)
        left = self.adapter.region(schema.TABLE_RANGE_NAMES['closing_costs'])[1]
        right = self.adapter.region(schema.TABLE_RANGE_NAMES['recurring_expenses'])[1]
        self.assertEqual((left, right), ((1, 5, 2, 105), (5, 5, 6, 7)))
        self.assertIsNone(self.book['Expense Inputs']['C105'].value)
        self.assertIsNone(self.book['Expense Inputs']['E105'].value)
        self.adapter.validate_output_layout((), tuple(schema.TABLE_RANGE_NAMES[key] for key in ('closing_costs', 'recurring_expenses')))

    def test_grouping_is_idempotent_and_optional_reader_does_not_recreate_old_sheets(self):
        ensure_pilot_interface(self.adapter)
        apply_workbook_presentation(self.adapter)
        before = tuple(self.book.sheetnames), len(self.book.defined_names)
        ensure_pilot_interface(self.adapter)
        second = apply_workbook_presentation(self.adapter)
        self.assertEqual((tuple(self.book.sheetnames), len(self.book.defined_names)), before)
        self.assertEqual(sum(row['status'] == 'ALREADY_GROUPED' for row in second['consolidation']), 3)
        self.assertNotIn('Seasoned Positions', self.book.sheetnames)
        self.assertNotIn('Opening CLO Accounts', self.book.sheetnames)
        self.assertNotIn('Proceeds Allocations', self.book.sheetnames)

    def test_literal_dropdowns_move_to_the_correct_band_and_keep_full_input_length(self):
        ensure_pilot_interface(self.adapter)
        apply_workbook_presentation(self.adapter)
        sheet = self.book['Seasoned Inputs']
        rules = {(str(rule.sqref), rule.formula1) for rule in sheet.data_validations.dataValidation}
        self.assertIn(('A6:A1005', '"ASSET,CANDIDATE"'), rules)
        self.assertIn(('H6:H1005', '"ASSET,CANDIDATE"'), rules)
        self.assertIn(('D6:D1005', '"FULL_CURRENT_PERIOD,POST_ASOF_ONLY,EXPLICIT_CASH_CLAIM"'), rules)

    def test_custom_content_retains_both_sources_and_reports_why(self):
        left, right = self.expenses()
        right['A12'] = 'User comparison below the Table'
        report = apply_workbook_presentation(self.adapter)
        result = next(row for row in report['consolidation'] if row['sheet'] == 'Expense Inputs')
        self.assertEqual(result['status'], 'SKIPPED')
        self.assertIn('user content', result['reason'])
        self.assertEqual((left['B6'].value, right['A12'].value), (2.47, 'User comparison below the Table'))
        self.assertNotIn('Expense Inputs', self.book.sheetnames)

    def test_foreign_name_reference_prevents_source_deletion(self):
        self.expenses()
        self.book.defined_names.add(DefinedName('user_expense_total', attr_text="'Closing Costs'!$B$6"))
        report = apply_workbook_presentation(self.adapter)
        result = next(row for row in report['consolidation'] if row['sheet'] == 'Expense Inputs')
        self.assertEqual(result['status'], 'SKIPPED')
        self.assertIn('foreign named', result['reason'])
        self.assertEqual(self.book.defined_names['user_expense_total'].attr_text, "'Closing Costs'!$B$6")

    def test_user_note_comment_or_hyperlink_outside_band_above_header_is_preserved(self):
        from openpyxl.comments import Comment
        for kind in ('note', 'comment', 'hyperlink'):
            with self.subTest(kind=kind):
                book = Workbook()
                book.active.title = 'User Notes'
                left = registered_table(book, 'closing_costs', 'Closing Costs')
                registered_table(book, 'recurring_expenses', 'Recurring Expenses')
                cell = left['C2']
                if kind == 'note':
                    cell.value = 'User expense comparison'
                elif kind == 'comment':
                    cell.comment = Comment('User expense evidence', 'Portfolio Operations')
                else:
                    cell.hyperlink = 'https://example.com/expense-evidence'
                try:
                    report = apply_workbook_presentation(NamedWorkbook(book))
                    result = next(row for row in report['consolidation'] if row['sheet'] == 'Expense Inputs')
                    self.assertEqual(result['status'], 'SKIPPED')
                    self.assertIn('user content', result['reason'])
                    self.assertIs(book['Closing Costs']['C2'], cell)
                    self.assertIn('Recurring Expenses', book.sheetnames)
                finally:
                    book.close()

    def test_foreign_name_scoped_to_another_sheet_prevents_source_deletion(self):
        self.expenses()
        notes = self.book['User Notes']
        notes.defined_names.add(DefinedName('LocalForeign', attr_text="'Closing Costs'!$B$6"))
        report = apply_workbook_presentation(self.adapter)
        result = next(row for row in report['consolidation'] if row['sheet'] == 'Expense Inputs')
        self.assertEqual(result['status'], 'SKIPPED')
        self.assertIn('sheet-local named reference', result['reason'])
        self.assertEqual(notes.defined_names['LocalForeign'].attr_text, "'Closing Costs'!$B$6")
        self.assertIn('Closing Costs', self.book.sheetnames)

    def test_foreign_validation_formula1_and_formula2_keep_source_sheet(self):
        from openpyxl.worksheet.datavalidation import DataValidation
        self.expenses()
        notes = self.book['User Notes']
        for field, formula in ((field, formula) for field in ('formula1', 'formula2')
                               for formula in ("'Closing Costs'!$A$6:$A$7", 'INDIRECT("\'Closing Costs\'!$A$6:$A$7")')):
            with self.subTest(field=field, formula=formula):
                notes.data_validations.dataValidation.clear()
                rule = DataValidation(type='list')
                setattr(rule, field, formula)
                rule.add('A1')
                notes.add_data_validation(rule)
                report = apply_workbook_presentation(self.adapter)
                result = next(row for row in report['consolidation'] if row['sheet'] == 'Expense Inputs')
                self.assertEqual(result['status'], 'SKIPPED')
                self.assertIn('dynamic' if formula.startswith('INDIRECT') else 'data validation', result['reason'])
                self.assertIn('Closing Costs', self.book.sheetnames)

    def test_foreign_conditional_formatting_formula_keeps_source_sheet(self):
        from openpyxl.formatting.rule import FormulaRule
        self.expenses()
        self.book['User Notes'].conditional_formatting.add('A1:A3',
            FormulaRule(formula=["'Closing Costs'!$B$6>0"]))
        report = apply_workbook_presentation(self.adapter)
        result = next(row for row in report['consolidation'] if row['sheet'] == 'Expense Inputs')
        self.assertEqual(result['status'], 'SKIPPED')
        self.assertIn('conditional formatting', result['reason'])
        self.assertIn('Closing Costs', self.book.sheetnames)

    def test_foreign_chart_and_combined_chart_sources_keep_source_sheet(self):
        from openpyxl.chart import BarChart, LineChart, Reference
        self.expenses()
        notes = self.book['User Notes']
        notes['B1'] = 1
        bar = BarChart()
        bar.add_data(Reference(notes, min_col=2, min_row=1))
        line = LineChart()
        line.add_data(Reference(self.book['Closing Costs'], min_col=2, min_row=6))
        bar += line
        notes.add_chart(bar, 'D2')
        report = apply_workbook_presentation(self.adapter)
        result = next(row for row in report['consolidation'] if row['sheet'] == 'Expense Inputs')
        self.assertEqual(result['status'], 'SKIPPED')
        self.assertIn('chart', result['reason'])
        self.assertIn('Closing Costs', self.book.sheetnames)

    def test_foreign_chart_category_and_series_title_references_keep_source_sheet(self):
        from openpyxl.chart import BarChart, Reference
        from openpyxl.chart.data_source import StrRef
        from openpyxl.chart.series import SeriesLabel
        self.expenses()
        notes = self.book['User Notes']
        notes['B1'] = 1
        for kind in ('category', 'series_title'):
            with self.subTest(kind=kind):
                notes._charts.clear()
                chart = BarChart()
                chart.add_data(Reference(notes, min_col=2, min_row=1))
                if kind == 'category':
                    chart.set_categories(Reference(self.book['Closing Costs'], min_col=1, min_row=6))
                else:
                    chart.series[0].tx = SeriesLabel(strRef=StrRef(f="'Closing Costs'!$A$6"))
                notes.add_chart(chart, 'D2')
                report = apply_workbook_presentation(self.adapter)
                result = next(row for row in report['consolidation'] if row['sheet'] == 'Expense Inputs')
                self.assertEqual(result['status'], 'SKIPPED')
                self.assertIn('chart', result['reason'])
                self.assertIn('Closing Costs', self.book.sheetnames)

    def test_foreign_table_calculated_and_totals_formula_metadata_keep_source_sheet(self):
        from openpyxl.worksheet.table import TableFormula
        self.expenses()
        sheet = registered_table(self.book, 'factor_mapping', 'User Formula Table')
        table = sheet.tables[schema.TABLE_NAMES['factor_mapping']]
        column = table.tableColumns[-1]
        for field in ('calculatedColumnFormula', 'totalsRowFormula'):
            with self.subTest(field=field):
                column.calculatedColumnFormula = column.totalsRowFormula = None
                setattr(column, field, TableFormula(attr_text="'Closing Costs'!$B$6"))
                report = apply_workbook_presentation(self.adapter)
                result = next(row for row in report['consolidation'] if row['sheet'] == 'Expense Inputs')
                self.assertEqual(result['status'], 'SKIPPED')
                self.assertIn('table formula metadata', result['reason'])
                self.assertIn('Closing Costs', self.book.sheetnames)

    def test_foreign_xy_and_bubble_chart_sources_keep_source_sheet(self):
        from openpyxl.chart import BubbleChart, Reference, Series
        self.expenses()
        notes = self.book['User Notes']
        notes['B1'], notes['C1'], notes['D1'] = 1, 2, 3
        for field in ('xVal', 'yVal', 'bubbleSize'):
            with self.subTest(field=field):
                notes._charts.clear()
                chart = BubbleChart()
                series = Series(Reference(notes, min_col=2, min_row=1),
                                xvalues=Reference(notes, min_col=3, min_row=1),
                                zvalues=Reference(notes, min_col=4, min_row=1))
                getattr(series, field).numRef.f = "'Closing Costs'!$B$6"
                chart.series.append(series)
                notes.add_chart(chart, 'E2')
                report = apply_workbook_presentation(self.adapter)
                result = next(row for row in report['consolidation'] if row['sheet'] == 'Expense Inputs')
                self.assertEqual(result['status'], 'SKIPPED')
                self.assertIn('chart', result['reason'])
                self.assertIn('Closing Costs', self.book.sheetnames)

    def test_quoted_and_unquoted_three_dimensional_intervals_keep_original_sources(self):
        self.expenses()
        for formula in ("=SUM('Closing Costs:Recurring Expenses'!$B$6)", '=SUM(Sheet1:Sheet3!A1)',
                        '=SUM(开始:结束!$B$6)'):
            with self.subTest(formula=formula):
                before = tuple(self.book.sheetnames)
                self.book['User Notes']['A1'] = formula
                report = apply_workbook_presentation(self.adapter)
                result = next(row for row in report['consolidation'] if row['sheet'] == 'Expense Inputs')
                self.assertEqual(result['status'], 'SKIPPED')
                self.assertIn('3D sheet interval', result['reason'])
                self.assertIn('Closing Costs', self.book.sheetnames)
                self.assertEqual(tuple(self.book.sheetnames), before)
                self.assertTrue(report['sheet_order_retained'])

    def test_dynamic_assembled_indirect_preserves_original_sources_and_order(self):
        self.expenses()
        self.book['User Notes']['A1'] = '=INDIRECT("Closing "&"Costs!B6")'
        self.book.create_sheet('Guidance')
        before = tuple(self.book.sheetnames)
        report = apply_workbook_presentation(self.adapter)
        result = next(row for row in report['consolidation'] if row['sheet'] == 'Expense Inputs')
        self.assertEqual(result['status'], 'SKIPPED')
        self.assertIn('dynamic', result['reason'])
        self.assertEqual(tuple(self.book.sheetnames), before)

    def test_array_formula_text_and_opaque_data_table_formulas_are_preserved(self):
        from openpyxl.worksheet.formula import ArrayFormula, DataTableFormula
        self.expenses()
        notes = self.book['User Notes']
        for value, expected in ((ArrayFormula(ref='A1:A2', text="=SUM('Closing Costs'!B6)"), 'direct formula'),
                                (DataTableFormula(ref='A1:A2', r1='B1'), 'opaque formula')):
            with self.subTest(value=type(value).__name__):
                notes['A1'] = value
                before = tuple(self.book.sheetnames)
                report = apply_workbook_presentation(self.adapter)
                result = next(row for row in report['consolidation'] if row['sheet'] == 'Expense Inputs')
                self.assertEqual(result['status'], 'SKIPPED')
                self.assertIn(expected, result['reason'])
                self.assertIs(notes['A1'].value, value)
                if isinstance(value, DataTableFormula):
                    self.assertEqual(tuple(self.book.sheetnames), before)

    def test_already_grouped_book_with_three_dimensional_reference_preserves_custom_order(self):
        self.expenses()
        apply_workbook_presentation(self.adapter)
        self.book['User Notes']['A1'] = "=SUM('User Notes:Expense Inputs'!B6)"
        self.book.move_sheet('User Notes', offset=-1)
        before = tuple(self.book.sheetnames)
        report = apply_workbook_presentation(self.adapter)
        self.assertEqual(tuple(self.book.sheetnames), before)
        self.assertTrue(report['sheet_order_retained'])

    def test_unknown_foreign_object_serializer_retains_original_layout(self):
        from unittest.mock import patch
        from openpyxl.chart import BarChart
        self.expenses()
        self.book['User Notes'].add_chart(BarChart(), 'D2')
        with patch.object(BarChart, 'to_tree', side_effect=NotImplementedError('Unknown chart profile')):
            report = apply_workbook_presentation(self.adapter)
        result = next(row for row in report['consolidation'] if row['sheet'] == 'Expense Inputs')
        self.assertEqual(result['status'], 'SKIPPED')
        self.assertIn('cannot be inspected safely', result['reason'])
        self.assertIn('Closing Costs', self.book.sheetnames)

    def test_saved_literal_equal_prefix_remains_text_after_consolidation(self):
        left, _ = self.expenses()
        left['A6'].value = '=EXPENSE_ID'
        left['A6'].data_type = 's'
        apply_workbook_presentation(self.adapter)
        cell = self.book['Expense Inputs']['A6']
        self.assertEqual((cell.value, cell.data_type), ('=EXPENSE_ID', 's'))
        self.assertEqual(self.adapter.table_records(schema.TABLE_RANGE_NAMES['closing_costs'],
                         schema.TABLE_NAMES['closing_costs'])[0]['cost_id'], '=EXPENSE_ID')

    def test_direct_formula_and_internal_hyperlink_references_are_not_guessed(self):
        self.expenses()
        self.book['User Notes']['A1'] = "='Closing Costs'!B6"
        report = apply_workbook_presentation(self.adapter)
        result = next(row for row in report['consolidation'] if row['sheet'] == 'Expense Inputs')
        self.assertIn('direct formula', result['reason'])
        self.book['User Notes']['A1'] = 'Link'
        self.book['User Notes']['A1'].hyperlink = "#'Recurring Expenses'!A6"
        report = apply_workbook_presentation(self.adapter)
        result = next(row for row in report['consolidation'] if row['sheet'] == 'Expense Inputs')
        self.assertIn('internal hyperlink', result['reason'])
        self.assertIn('Recurring Expenses', self.book.sheetnames)

    def test_nonliteral_validation_custom_placement_or_target_content_prevent_merge(self):
        from openpyxl.worksheet.datavalidation import DataValidation
        left, right = self.expenses()
        rule = DataValidation(type='decimal', operator='greaterThan', formula1='B2')
        rule.add('B6:B20')
        right.add_data_validation(rule)
        report = apply_workbook_presentation(self.adapter)
        result = next(row for row in report['consolidation'] if row['sheet'] == 'Expense Inputs')
        self.assertIn('nonliteral data validation', result['reason'])
        right.data_validations.dataValidation.clear()
        self.book.create_sheet('Expense Inputs')['A1'] = 'User layout'
        report = apply_workbook_presentation(self.adapter)
        result = next(row for row in report['consolidation'] if row['sheet'] == 'Expense Inputs')
        self.assertIn('Target sheet already exists', result['reason'])
        self.assertEqual(self.book['Expense Inputs']['A1'].value, 'User layout')

    def test_saved_horizontal_names_values_dropdowns_and_styles_round_trip(self):
        ensure_pilot_interface(self.adapter)
        put_records(self.adapter, 'principal_accrued_balances', ({'loan_id': 'L', 'as_of_date': date(2026, 2, 16),
            'amount': 1.47, 'source': 'Verified source', 'legal_reference': 'Verified legal clause'},))
        apply_workbook_presentation(self.adapter)
        stream = BytesIO()
        self.book.save(stream)
        restored = load_workbook(BytesIO(stream.getvalue()))
        try:
            adapter = NamedWorkbook(restored)
            ensure_pilot_interface(adapter)
            rows = adapter.table_records(schema.TABLE_RANGE_NAMES['principal_accrued_balances'], schema.TABLE_NAMES['principal_accrued_balances'])
            self.assertEqual((rows[0]['loan_id'], D(str(rows[0]['amount']))), ('L', D('1.47')))
            sheet, (left, top, _, _) = adapter.region(schema.TABLE_RANGE_NAMES['principal_accrued_balances'])
            self.assertEqual(sheet.title, 'Proceeds Inputs')
            self.assertEqual(sheet.cell(top + 1, left + 2).number_format, '#,##0.00')
            self.assertEqual(sheet.cell(top + 1, left).alignment.horizontal, 'center')
            self.assertEqual(len(restored['Proceeds Inputs'].data_validations.dataValidation), 2)
        finally:
            restored.close()

    def test_complete_fixture_has_five_safe_merges_and_identical_input_fingerprint(self):
        book = load_workbook(BytesIO(INPUT_TEMPLATE.read_bytes()))
        try:
            adapter = NamedWorkbook(book)
            ensure_pilot_interface(adapter)
            before = input_fingerprint(adapter)
            table_count = sum(len(sheet.tables) for sheet in book)
            names = set(book.defined_names)
            report = apply_workbook_presentation(adapter)
            self.assertEqual(len(report['consolidation']), len(HORIZONTAL_INPUT_GROUPS))
            self.assertTrue(all(row['status'] in {'GROUPED', 'ALREADY_GROUPED'}
                                for row in report['consolidation']))
            self.assertEqual(input_fingerprint(adapter), before)
            self.assertEqual(sum(len(sheet.tables) for sheet in book), table_count)
            self.assertEqual(set(book.defined_names), names)
            self.assertEqual(book.sheetnames[0], 'Guidance')
            self.assertEqual(len(book.sheetnames), 74)
        finally:
            book.close()

    def test_reference_preflight_does_not_materialise_large_formatted_rectangles(self):
        self.expenses()
        notes = self.book['User Notes']
        notes['Z100000'].alignment = Alignment(horizontal='right')
        before = len(notes._cells)
        report = apply_workbook_presentation(self.adapter)
        self.assertEqual(len(notes._cells), before)
        self.assertEqual(next(row for row in report['consolidation']
                              if row['sheet'] == 'Expense Inputs')['status'], 'GROUPED')

    def test_escaped_quoted_source_title_is_retained_when_directly_referenced(self):
        left, _ = self.expenses()
        self.book.defined_names[schema.TABLE_RANGE_NAMES['closing_costs']].attr_text = schema.TABLE_NAMES['closing_costs'] + '[#All]'
        left.title = "Closing O'Brien"
        self.book['User Notes']['A1'] = "='Closing O''Brien'!B6"
        report = apply_workbook_presentation(self.adapter)
        result = next(row for row in report['consolidation'] if row['sheet'] == 'Expense Inputs')
        self.assertEqual(result['status'], 'SKIPPED')
        self.assertIn('direct formula', result['reason'])
        self.assertIn("Closing O'Brien", self.book.sheetnames)

    def test_nonfinite_or_out_of_range_numeric_output_is_rejected_before_assignment(self):
        cell = self.book['User Notes']['A1']
        cell.value = 'Previous valid output'
        for value in (D('1e1000'), D('-1e1000'), D('NaN'), D('Infinity'), D('sNaN'),
                      float('nan'), float('inf'), -float('inf'), 10 ** 1000):
            with self.subTest(value=repr(value)), self.assertRaisesRegex(InputValidationError, 'finite'):
                self.adapter._write_value(cell, value)
            self.assertEqual(cell.value, 'Previous valid output')

    def test_finite_rates_ratios_large_par_and_boolean_are_not_cent_quantized(self):
        cell = self.book['User Notes']['A1']
        for value in (D('500000000.47'), D('0.03123456789123'), D('1.2345678912345'), True):
            self.adapter._write_value(cell, value)
            self.assertEqual(cell.value, float(value) if isinstance(value, D) else value)

    def test_nonzero_decimal_underflow_rejects_zero_substitution_but_real_zero_is_allowed(self):
        cell = self.book['User Notes']['A1']
        cell.value = 'Previous valid output'
        for value in (D('1e-1000'), D('-1e-1000')):
            with self.subTest(value=value), self.assertRaisesRegex(InputValidationError, 'underflow'):
                self.adapter._write_value(cell, value)
            self.assertEqual(cell.value, 'Previous valid output')
        for value in (D('0'), D('-0'), D('0e-1000')):
            self.adapter._write_value(cell, value)
            self.assertEqual(cell.value, 0)


if __name__ == '__main__':
    unittest.main()
