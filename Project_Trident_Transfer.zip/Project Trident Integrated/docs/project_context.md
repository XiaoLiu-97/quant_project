# 项目上下文

更新：2026-10-08。当前独立项目`Project Trident Integrated`，软件**0.12.3**、compact schema1.0。稳定入口[outputs/Project_Trident.xlsx](../outputs/Project_Trident.xlsx)已完成waterfall修复及格式补充修正并原子发布，SHA`eba243c79afd6e0531990b410131c747aad36339a2b5f3ada40cc6ba1d4784ed`。证据：[waterfall修复](validation/waterfall_repair.json)、[整体界面](validation/interface_formatting.json)、[完整回归](validation/current.json)。支持已验证generic profile；真实deal法律映射/agency calibration/trustee benchmark仍独立核验。外部独立原项目完整保留；当前无旧项目运行依赖。

解压后部署：按[部署说明](deployment.md)在目标Windows电脑重建独立`.venv`，推荐Python3.12/64-bit及openpyxl3.1.5、numpy2.3.5、scipy1.18.1；固定SciPy要求Python>=3.12，源码>=3.11不代表固定组合兼容3.11。普通运行不要求PDF工具或Activate.ps1。邮件迁移包排除环境/缓存，包含完整src/data/tests/scripts/docs/outputs；离线另备匹配wheels及setuptools84.0.0，保留build isolation。公司电脑安装及整套测试尚未实际执行；本机环境probe/pip check已通过。

## 持续要求

金融正确性优先，目标为首个简单、可读、可操作且无明显/重大modelling错误的模型。主要场景：CLO structuring、portfolio analysis、完整每期每tranche waterfall/IC/OC/cure/diversion、发行后what-if、静态optimization及明确synthetic reinvestment。当前不要求动态lifetime交易optimization，不增加非必要inputs/outputs/tabs妨碍使用。

架构清晰、模块化、对象组合、可维护扩展、高效且robust；足够详细的comment/docstring解释数据流、单位、时点、假设、不变量及边界；corner cases用独立known answers、回归及现金/face/claims守恒验证。重大更新同步guidance、methodology、assumptions、architecture、flowcharts及本context。用户说“等等”等表示列举不是上限，应主动补齐同类依赖与风险，同时保持首版范围。

不加入模型/代码/文件生成者或作者自述；必要数据/金融来源、synthetic fixture和假设标记保留。默认只维护当前版本；仅用户明确授权的独立历史保存例外，不让当前代码链接旧项目。Excel统一Arial、输入/输出分组色、居中数据及money/rate/bps/date语义格式；有限选项均有native dropdown/Stop validation。业务字段通过named owner/Table/header管理，namespace为trident_ui_。Market Data粘贴布局、owning inputs和native资源不得破坏。 每次界面新增、修改或删除后必须核对整体formatting、interaction及业务语义，并在交付前检查整个界面，包含隐藏/预留区、单位日期、行高列宽、下拉框、导航/冻结、状态及图表；pure internal code changes without UI impact exempt。不得再将用户找出问题当作默认验收。

## 当前设计及边界

15用户tabs＋2隐藏支持页，198Tables、514names、8native charts。Asset Library拥有共同ID/合同/分类/评级；Asset Schedules拥有BESPOKE本金、coupon/credit/fixing/seasoned一对多事件；Pool拥有实际face/cost/accrued/OC classification及mark；Capital Stack拥有note terms/current face/opening claims；CLO Assumptions拥有fees、coverage/diversion、OC policy及opening accounts；Optimization拥有mandate/constraints，Trade Universe拥有sourced quotes。

Python负责金融计算；Excel负责展示lookup及少量汇总/单位转换。case/date/scope/tranche仅过滤saved完整结果，不生成新scenario。snapshot/execution profile纳入fingerprint；witness提示dirty/unchanged。UNAVAILABLE、NOT_CONFIGURED、BLOCKED、NOT_APPLICABLE、FAIL及有效零区分；freshness不替代独立benchmark/数据来源核验。

Closing以实际purchase/issue/funding计算equity投入。Existing仅支持post-distribution/payment boundary；保留原schedule、八种cash/designations、四类fee claims及retained debt coupon claims。Designation是principal子集，不增加现金。Forward return从sourced whole current equity mark起算，不重复历史acquisition/issue/setup。Opening what-if支持未来fee/coupon/coverage及有完整equity value/source的已有face resize；不推测真实settlement/ownership。

静态LP/MILP产生未成交proposal，没有full replay不展示trade IRR。Closing有限候选完成funding/assets/waterfall/return replay后，仅在候选集合中选优。缺quote/snapshot身份明确拒绝；NO_TRADE_CHECK不是求解成功。Synthetic reinvestment是明确经济模板，非dealer execution。CDR/CPR按比例/dated events确定性计算，无Monte Carlo/相关违约；原池与synthetic CPR独立拥有。用户最新保存原池overlayOn、CDR2%、CPR0%、RR60%、lag6个月，reinvestmentNo；未启用的synthetic CPR10%不作用于当前持仓。

## 本轮waterfall修复

已修复：STOP仅检查买前而遗漏拟买后OC，以及买入后PRINCIPAL_GATE读取旧collateral valuation。Ledger以纯 `plan_purchase` 计算posted cash/par/maturity及unused cash，waterfall先检查prospective generic OC/IC，再 `commit_purchase`；拒购不创建cohort、不扣现金/designation。成交后即时刷新valuation；已exercise的call/maturity处置也先更新inventory，再决定本金分配。

STOP要求适用买前/拟买后tests通过及coupon权限；当前IC不加入新cohort未来coupon。ALWAYS仍是明确coverage/unpaid-coupon敏感性override，保留日期/现金/final、禁止long-dated及asset-level classification guards。Rejected ordinary cash继续正常本金分配；窗口内held IDT仍earmarked，按原规则释放。Cent、低精度/深折价及纯计划/重复提交边界有独立回归。

Purchase/principal gates仅内部使用，不增加Excel report stage；Reinvestment cash为0可能是prospective veto，即使可见GATE/end均PASS，当前无单独purchase rejection reason。期末OC PASS或cash residual0不证明中间分配正确。Synthetic generic checks不等于完整真实deal maintained/improved或法律质量测试；Existing incentive仍因缺historical hurdle明确不支持。

当前[17页中文waterfall指南](../outputs/Project_Trident_Waterfall_Flowcharts_CN.pdf)及[可搜索文字版](waterfall_guide_cn.md)重新按主题拆分：总览/起点/合同/信用/回收/账户/费用/OC/IC/利息分配/IDT/再投资/本金分配/退出与refi/incentive/核对/术语来源。弃用A1/B2作为说明标题；正文11.6pt，每页约819-1013字符；中文动作、例子和边界分开，先讲资金变化再讲公式。Asset Cashflows明确为合同参考、Waterfall为信用调整后收款；IC储备示例遵守实际draw规则；退出与refi画成分支。全部17页视觉和内容复核、15项独立手算、源码/工作簿hash保护通过，证据见[文档验收](validation/waterfall_guide_cn.json)。仅重做说明，不改金融模型或Excel、不重跑完整金融suite；脚本`scripts/build_waterfall_guide.py`同步生成PDF及文字版，临时预览不进入项目。

## 长表配色补充修正

用户指出 assumptions 分区颜色不一致，确认为直接填充及 named-style 继承覆盖 Table 条纹，不是业务分区。已统一整张116行 assumptions 的 Table banding、蓝色 owning Value、深色 metadata；四个参考 Value 继续灰色。Optimization inherited limits、comparison reader及Checks的300行有效/预留区同样统一 Table 条纹；fixed settings/opening拥有者字体统一。原始数值、单位、日期、公式/cache、Market Data、names/Tables、validation及charts均保留。此前代表范围视觉检查遗漏长表分区，旧检查数量不证明颜色一致；后续逐行检查长表及各分区交界、直接和继承样式，并用Excel DisplayFormat验证。[颜色验收](validation/interface_palette.json)绑定当前文件；金融source/tests未变，沿用完整suite，本次仅做格式/保存重开/视觉及持久性验证。

## 当前验收证据

完整suite **1,797项全部通过，零failure/error/skip**；运行前后source/tests不变，99源文件＋116test/input文件＋日志hash独立复核。19项acquisition已知答案及9项展示格式/单位/输入保护测试已纳入完整suite。

保留用户最新输入fingerprint`496a300309413d4ce7e803fb4f6a67d2717118863f535e41f04779adfc5a1bfe`，同一模型格式前后两次独立运行的完整typedrequest及financialresult精确一致（只排除uuid执行ID，不normalize/round数值）。当前150资产、三个case各42期COMPLETED，BASELINE IRR3.2916419919%、MOIC1.21309717214；default€54,683,311.04、recovery€32,809,983.18、loss€21,873,327.86、prepay0/reinvestment0。

本轮格式覆盖17页、198Tables、隐藏/预留明细、mixed单位、日期、输入/参考角色、冻结、列宽/行高、exact status/freshness、8chart文字及九处旧帮助。Native Excel 39286项通过，保存重开及26个视图（15用户页＋8隐藏/预留区域＋3额外图表区域）复查完成；匹配native cache后原package保留，最终hash由界面记录绑定。原始Market Data粘贴区、owning inputs及named interfaces保留，A2只读说明去除过时preview前缀。重复样式应用不增加styles/CF，非状态自定义CF保留；Waterfall状态metadata覆盖300期，不生成额外金融periods。

150资产/40期启用synthetic reinvestment的冻结只读variant独立证明12笔购买及其后续信用收款/现金守恒；不是当前用户输入或真实成交。当前修复记录保留该variant的原始fingerprint与scope。

## 容量、写出与性能

资产register/terms/details/Pool/Trade Universe各300、ratings900、schedule/events各3000、stack12含equity、limits100、scenario edits/factor mapping各300；固定账户/fees/options保持schema数量。Output按300资产×最大合同期数、至少60季度/12层及case数预留；blank tail不产生金融记录或公式。Live ID跨空行紧凑，witness涵盖reserve，隐藏tbl_trident_ui_table_capacity登记actual/capacity。OC导航AC9:AH20、warningAC22:AH22，owning inputs不变。

Writer复用不变formula/style/metadata及容量，必要值/cache刷新、旧尾部清理；真实增长才检查notes/merges/相邻Tables/names碰撞。完整DOM关系/schema/name/formula/输入保护及临时ZIP检查后原子发布；same-source前后proof阻止并发覆盖。正常运行重算enabled cases并失效旧chart cache，不能删claims/full Waterfall或造零值来提速。

[writer_optimization.json](validation/writer_optimization.json)仍是其冻结源码的历史性能/保留证明；write60.94→25.67秒、total82.31→45.08秒属于此前单次匹配计时，本轮未重新测量这一pair。Static synthetic 300注册资产/200quotes的LP约0.030秒、MILP0.057秒及候选replay计时同样只是原测试条件，不能保证复杂真实deal速度。本轮验证目标及最终发布状态一律看waterfall_repair.json，完整suite看current.json；更多性能条件见[计时](optimization_runtime.md)。

## 后续工作与入口

本轮金融修复、完整界面验收及稳定工作簿发布完成。随后优先真实deal条款、rating/recovery来源及trustee benchmark和用户测试。完整法律eligibility、真实单次Existing交易包settlement/ownership/forward replay、动态lifetime optimization仍分别保留边界；不要为了极致复杂度增加不必要输入。后续提速先测reader/展示规模，保留claims、typed inputs、cash及full Waterfall保护。

文档入口：[user guide](user_guide.md)、[architecture](architecture.md)、[flowcharts](calculation_flowcharts.md)、[readiness](readiness.md)、[deployment](deployment.md)。
