"""Linear-time par-weighted portfolio analytics with complete denominators."""

from collections import defaultdict
from dataclasses import replace
from datetime import date
from decimal import Decimal
from fractions import Fraction
from typing import Iterable

from trident.domain.models import CouponType, InputValidationError, LoanCashflow, require_date, require_money
from trident.domain.numeric import decimal_fraction

from .models import (
    AssetExposure, ConcentrationResult, FactorMapping, LimitDirection, LimitResult,
    LimitSpec, LimitStatus, MetricResult, MetricStatus, PortfolioReport, ScheduledMaturityReceipt, _text,
)


def _validate_maturity_receipts(
    assets: dict[str, AssetExposure], asof: date, rows: tuple[LoanCashflow, ...],
    receipts: tuple[ScheduledMaturityReceipt, ...],
) -> frozenset[str]:
    """Permit only evidenced final principal between nominal and cash dates.

    A caller cannot waive stale holdings with a boolean. Every expired holding
    needs exactly one full, strictly future final receipt matching the original
    nominal maturity and the held identity/currency. This is a narrow calendar
    adjustment bridge, not support for overdue/defaulted or seasoned claims.
    """
    expired = frozenset(identity for identity, asset in assets.items() if asset.maturity_date < asof)
    if type(receipts) is not tuple or any(not isinstance(row, ScheduledMaturityReceipt) for row in receipts):
        raise InputValidationError("scheduled_maturity_receipts must be an immutable tuple of receipt evidence")
    by_id = {receipt.loan_id: receipt for receipt in receipts}
    if len(by_id) != len(receipts):
        raise InputValidationError("Duplicate scheduled maturity receipt evidence")
    if set(by_id) != expired:
        raise InputValidationError("Held par has a maturity before the snapshot date without matching scheduled receipt evidence")
    if not expired:
        return expired
    future = defaultdict(list)
    for row in rows:
        if not isinstance(row, LoanCashflow):
            raise InputValidationError("Maturity receipt reference must contain LoanCashflow objects")
        require_money(row.principal_repayment, "maturity receipt principal")
        if row.loan_id in expired and row.principal_repayment > 0:
            future[row.loan_id].append(row)
    for identity in expired:
        asset, receipt = assets[identity], by_id[identity]
        source = future[identity]
        if (receipt.currency != asset.currency or receipt.nominal_maturity_date != asset.maturity_date
                or receipt.outstanding_principal != asset.par or len(source) != 1):
            raise InputValidationError("Scheduled maturity receipt does not cover the held asset and original nominal maturity")
        row = source[0]
        if (row.payment_date != receipt.receipt_date or row.payment_date <= asof
                or row.currency != asset.currency or row.principal_repayment != asset.par
                or row.unadjusted_end != asset.maturity_date or row.closing_balance != 0):
            raise InputValidationError("Scheduled maturity receipt lacks a matching complete future final-principal reference")
    return expired


class PortfolioAnalyzer:
    """Analyse an explicitly dated, single-currency held-par snapshot.

    WAL uses payment dates and actual calendar days / 365. It is an analytical
    convention, not a replacement for contractual coupon day counts. Complete
    future principal projections must reconcile asset by asset to snapshot par.
    """

    DIMENSIONS = ("asset_class", "obligor", "country", "sector", "financing_type", "test_factor_bucket")

    def analyze(
        self,
        exposures: Iterable[AssetExposure],
        asof: date,
        cashflows: Iterable[LoanCashflow] = (),
        mapping: FactorMapping | None = None,
        limits: Iterable[LimitSpec] = (),
        phase: str = "ALL",
        legal_final_date: date | None = None,
        *, scheduled_maturity_receipts: tuple[ScheduledMaturityReceipt, ...] = (),
    ) -> PortfolioReport:
        """Aggregate exact par weights once and test inclusive declared limits.

        Missing observations retain the full applicable denominator and produce
        INCOMPLETE/UNAVAILABLE status. They are not removed to improve a mean.
        Metric calculation and phase-dependent limit assessment are distinct;
        a report with no measured breach need not have complete data coverage.
        """
        require_date(asof, "asof")
        _text(phase, "phase")
        assets = tuple(exposures)
        if any(not isinstance(asset, AssetExposure) for asset in assets):
            raise InputValidationError("exposures must contain AssetExposure objects")
        by_id = {asset.loan_id: asset for asset in assets}
        if len(by_id) != len(assets):
            raise InputValidationError("Duplicate portfolio loan_id")
        currencies = {asset.currency for asset in assets}
        if len(currencies) > 1:
            raise InputValidationError("Portfolio analysis requires a common currency; FX translation is explicit")
        rows = tuple(cashflows)
        unsettled_maturity = _validate_maturity_receipts(by_id, asof, rows, scheduled_maturity_receipts)
        if mapping is not None and not isinstance(mapping, FactorMapping):
            raise InputValidationError("mapping must be FactorMapping")
        specs = tuple(limits)
        if any(not isinstance(spec, LimitSpec) for spec in specs):
            raise InputValidationError("limits must contain LimitSpec objects")
        if len({spec.limit_id for spec in specs}) != len(specs):
            raise InputValidationError("Duplicate limit_id")
        if legal_final_date is not None:
            require_date(legal_final_date, "legal_final_date")
        # Compare limits against exact rational aggregates. Decimal values are
        # presentation outputs; rounding a mean must not create mandate slack.
        total = sum((Fraction(asset.par) for asset in assets), Fraction())
        metrics: list[MetricResult] = []
        concentrations: list[ConcentrationResult] = []
        exact_metrics: dict[str, Fraction] = {}

        def weighted(name: str, values: list[tuple[AssetExposure, Decimal | Fraction | None]], unit: str,
                     denominator: Fraction | None = None, scope: str = "portfolio") -> None:
            denominator = total if denominator is None else denominator
            covered = sum((Fraction(asset.par) for asset, value in values if value is not None), Fraction())
            coverage = decimal_fraction(covered / denominator) if denominator else Decimal(0)
            if not denominator or covered != denominator:
                status = MetricStatus.UNAVAILABLE if not covered else MetricStatus.INCOMPLETE
                metrics.append(MetricResult(name, None, status, unit, coverage,
                                            f"No {scope} par" if not denominator else f"Missing inputs; denominator is full {scope} par"))
            else:
                numerator = sum((Fraction(asset.par) * Fraction(value) for asset, value in values if value is not None), Fraction())
                exact_metrics[name] = numerator / denominator
                metrics.append(MetricResult(name, decimal_fraction(numerator / denominator), MetricStatus.AVAILABLE, unit, coverage))

        def class_weighted(base_name: str, values: list[tuple[AssetExposure, Decimal | None]], unit: str) -> None:
            """Use only explicitly classified subset par, including missing factors.

            An unclassified asset could belong to either subset. Consequently
            no BSL/INFRA subset denominator is established until every asset has
            an asset class; known members are never silently treated as complete.
            """
            for asset_class in ("BSL", "INFRA"):
                name = f"{asset_class}_{base_name}"
                if any(asset.asset_class is None for asset in assets):
                    metrics.append(MetricResult(name, None, MetricStatus.UNAVAILABLE, unit, Decimal(0),
                                                "Missing asset_class prevents establishing the selected subset denominator"))
                    continue
                selected = [(asset, value) for asset, value in values if asset.asset_class == asset_class]
                subset_par = sum((Fraction(asset.par) for asset, _ in selected), Fraction())
                weighted(name, selected, unit, subset_par, f"{asset_class} subset")

        # Floating WAS and fixed WAC have different contractual denominators.
        # A missing coupon classification could belong to either population;
        # never infer floating from a margin or treat fixed coupons as zero WAS.
        # These simple analytics omit deal-specific excess coupon/floor/discount
        # adjustments, and are not substitutes for a configured indenture test.
        for name, coupon_type, value_field, unit in (
            ("WAS_BPS", CouponType.FLOATING, "spread_bps", "bps"),
            ("WAC_RATE", CouponType.FIXED, "fixed_coupon_rate", "fraction"),
        ):
            if any(asset.coupon_type is None for asset in assets):
                metrics.append(MetricResult(name, None, MetricStatus.UNAVAILABLE, unit, Decimal(0),
                                            "Missing coupon_type prevents establishing the selected coupon denominator"))
                continue
            selected = [(asset, getattr(asset, value_field)) for asset in assets if asset.coupon_type is coupon_type]
            subset_par = sum((Fraction(asset.par) for asset, _ in selected), Fraction())
            weighted(name, selected, unit, subset_par, f"{coupon_type.value} coupon subset")
        weighted("ALL_ASSET_SPREAD_BPS", [(asset, asset.spread_bps) for asset in assets], "bps")
        # A caller-supplied recovery observation is not an agency calibration.
        # Full performing par stays in the denominator when data is missing.
        recoveries = [(asset, asset.recovery_rate) for asset in assets]
        weighted("WARR", recoveries, "fraction")
        class_weighted("WARR", recoveries, "fraction")
        recovery_sources = sorted({asset.recovery_rate_source for asset in assets if asset.recovery_rate_source is not None})
        if recovery_sources:
            for index, metric in enumerate(metrics):
                if metric.name in {"WARR", "BSL_WARR", "INFRA_WARR"}:
                    metrics[index] = replace(metric, message=(metric.message + "; " if metric.message else "")
                                             + "User-supplied recovery sources: " + ", ".join(recovery_sources))
        for field, name in (("is_senior", "SENIOR_FRACTION"), ("is_secured", "SECURED_FRACTION"),
                            ("is_pik", "PIK_FRACTION"), ("is_revolver", "REVOLVER_FRACTION"),
                            ("is_construction", "CONSTRUCTION_FRACTION")):
            weighted(name, [(asset, None if getattr(asset, field) is None else Decimal(int(getattr(asset, field)))) for asset in assets], "fraction")
        if unsettled_maturity:
            # Actual principal has not settled. Keep the full held denominator
            # and the original nominal dates; do not publish negative nominal
            # remaining maturity or silently replace it with a cash date. WAL
            # below remains measurable from the verified future receipt.
            covered = sum((Fraction(asset.par) for asset in assets
                           if asset.loan_id not in unsettled_maturity), Fraction())
            metrics.append(MetricResult("WEIGHTED_AVERAGE_MATURITY_YEARS", None,
                MetricStatus.UNAVAILABLE, "years_ACT365F", decimal_fraction(covered / total),
                "Nominal maturity reached; evidenced final principal awaits adjusted receipt. Remaining nominal maturity is undefined"))
        else:
            weighted("WEIGHTED_AVERAGE_MATURITY_YEARS",
                     [(asset, Fraction((asset.maturity_date - asof).days, 365)) for asset in assets], "years_ACT365F")
        # The legal-final reference is a deal term, never guessed from the
        # longest asset maturity. Missing reference gives unavailable, not 0.
        if legal_final_date is not None or any(spec.metric == "LONG_DATED_FRACTION" for spec in specs):
            if legal_final_date is None:
                metrics.append(MetricResult("LONG_DATED_FRACTION", None, MetricStatus.UNAVAILABLE,
                                            "fraction", Decimal(0), "Explicit CLO legal final date is required"))
            else:
                weighted("LONG_DATED_FRACTION",
                         [(asset, Decimal(int(asset.maturity_date > legal_final_date))) for asset in assets], "fraction")
        for dimension in self.DIMENSIONS:
            groups: dict[str | None, Fraction] = defaultdict(Fraction)
            for asset in assets:
                groups[getattr(asset, dimension)] += Fraction(asset.par)
            for bucket, par in sorted(groups.items(), key=lambda item: (item[0] is None, item[0] or "")):
                concentrations.append(ConcentrationResult(dimension, bucket, decimal_fraction(par), decimal_fraction(par / total)))
            complete = total and None not in groups
            coverage = decimal_fraction((total - groups.get(None, Fraction())) / total) if total else Decimal(0)
            value = decimal_fraction(max(groups.values()) / total) if complete else None
            if complete:
                exact_metrics[f"LARGEST_{dimension.upper()}_FRACTION"] = max(groups.values()) / total
            status = MetricStatus.AVAILABLE if complete else (MetricStatus.INCOMPLETE if coverage else MetricStatus.UNAVAILABLE)
            metrics.append(MetricResult(f"LARGEST_{dimension.upper()}_FRACTION", value, status, "fraction", coverage,
                                        "" if complete else "Missing group metadata prevents a complete largest concentration"))

        # Actual agency factors and synthetic fixture factors have separate paths.
        actual = [(asset, asset.rating_factor) for asset in assets]
        if mapping is not None and not mapping.is_synthetic:
            actual = []
            for asset in assets:
                if asset.rating_system is not None and (asset.rating_system, asset.rating_version) != (mapping.system, mapping.version):
                    raise InputValidationError("Rating factors from different systems/versions cannot be combined")
                factor = mapping.factors.get(asset.rating_bucket) if asset.rating_bucket is not None else None
                if asset.rating_factor is not None:
                    if factor is not None and asset.rating_factor != factor:
                        raise InputValidationError("Direct rating factor conflicts with selected mapping")
                    factor = asset.rating_factor
                actual.append((asset, factor))
        elif len({(asset.rating_system, asset.rating_version) for asset in assets if asset.rating_factor is not None}) > 1:
            raise InputValidationError("Rating factors from different systems/versions cannot be combined")
        weighted("WARF", actual, "rating_factor")
        rating_coverage = metrics[-1].coverage
        metrics.append(MetricResult("RATING_FACTOR_COVERAGE_FRACTION", rating_coverage if total else None,
                                    MetricStatus.AVAILABLE if total else MetricStatus.UNAVAILABLE,
                                    "fraction", Decimal(1) if total else Decimal(0)))
        if total:
            exact_metrics["RATING_FACTOR_COVERAGE_FRACTION"] = sum((Fraction(asset.par) for asset, factor in actual if factor is not None), Fraction()) / total
        class_weighted("WARF", actual, "rating_factor")
        if mapping is not None and mapping.is_synthetic:
            synthetic = [(asset, mapping.factors.get(asset.test_factor_bucket)) for asset in assets]
            weighted("TEST_FACTOR_AVERAGE", synthetic, "synthetic_factor")
            class_weighted("TEST_FACTOR_AVERAGE", synthetic, "synthetic_factor")
        else:
            for name in ("TEST_FACTOR_AVERAGE", "BSL_TEST_FACTOR_AVERAGE", "INFRA_TEST_FACTOR_AVERAGE"):
                metrics.append(MetricResult(name, None, MetricStatus.UNAVAILABLE, "synthetic_factor", Decimal(0), "No explicitly synthetic factor mapping selected"))

        principal_by_asset: dict[str, Fraction] = defaultdict(Fraction)
        future_pik_by_asset: dict[str, Fraction] = defaultdict(Fraction)
        timing = Fraction()
        seen_rows: set[tuple[str, int]] = set()
        for row in rows:
            if not isinstance(row, LoanCashflow) or row.loan_id not in by_id:
                raise InputValidationError("Cashflow must refer to a portfolio loan_id")
            if row.currency != by_id[row.loan_id].currency:
                raise InputValidationError("Cashflow currency differs from exposure")
            require_date(row.payment_date, "cashflow payment_date")
            require_money(row.principal_repayment, "principal_repayment")
            if type(row.period_number) is not int or row.period_number < 1:
                raise InputValidationError("Cashflow period number must be a positive integer")
            if row.payment_date < asof:
                raise InputValidationError("WAL cashflow payment precedes snapshot date")
            key = (row.loan_id, row.period_number)
            if key in seen_rows:
                raise InputValidationError("Duplicate cashflow period")
            seen_rows.add(key)
            principal = Fraction(row.principal_repayment)
            principal_by_asset[row.loan_id] += principal
            future_pik_by_asset[row.loan_id] += Fraction(row.pik_interest)
            timing += principal * Fraction((row.payment_date - asof).days, 365)
        for loan_id, principal in principal_by_asset.items():
            if principal > Fraction(by_id[loan_id].par) + future_pik_by_asset[loan_id]:
                raise InputValidationError("Projected principal exceeds snapshot par")
        # PIK redemption includes future coupon capitalization. Loan cash is
        # valid, but calling all that redemption today's funded principal
        # distorts WAL. Until a legal funded-principal allocation is selected,
        # retain its full denominator and report incomplete WAL explicitly.
        pik_ids = {asset.loan_id for asset in assets
                   if asset.is_pik or future_pik_by_asset[asset.loan_id]}
        covered = sum((Fraction(asset.par) for asset in assets if asset.loan_id not in pik_ids
                       and principal_by_asset[asset.loan_id] == Fraction(asset.par)), Fraction())
        coverage = decimal_fraction(covered / total) if total else Decimal(0)
        complete = bool(total) and covered == total
        if complete:
            exact_metrics["WAL_YEARS"] = timing / total
        metrics.append(MetricResult("WAL_YEARS", decimal_fraction(timing / total) if complete else None,
                                    MetricStatus.AVAILABLE if complete else (MetricStatus.INCOMPLETE if rows else MetricStatus.UNAVAILABLE),
                                    "years_ACT365F", coverage, "" if complete else
                                    "PIK funded-principal allocation is unspecified; future coupon is not opening funded face" if pik_ids else
                                    "Full future principal must reconcile to snapshot par for every asset"))

        # Resolve concentration limits through semantic dimension and bucket keys.
        available = {metric.name: metric for metric in metrics}
        for spec in specs:
            if spec.metric.startswith("concentration:"):
                parts = spec.metric.split(":", 2)
                if len(parts) != 3 or parts[1] not in self.DIMENSIONS or not parts[2]:
                    raise InputValidationError("Concentration limit must identify a known dimension and bucket")
                dimension, bucket = parts[1:]
                group = next((row for row in concentrations if row.dimension == dimension and row.bucket == bucket), None)
                known = total and all(getattr(asset, dimension) is not None for asset in assets)
                available[spec.metric] = MetricResult(spec.metric, group.fraction if group else (Decimal(0) if known else None),
                                                      MetricStatus.AVAILABLE if known else MetricStatus.INCOMPLETE, "fraction", Decimal(1) if known else Decimal(0))
                if known:
                    exact_metrics[spec.metric] = sum((Fraction(asset.par) for asset in assets if getattr(asset, dimension) == bucket), Fraction()) / total
            elif spec.metric not in available:
                raise InputValidationError(f"Unknown limit metric: {spec.metric}")
        limit_results = []
        for spec in specs:
            metric = available[spec.metric]
            if spec.phases and phase not in spec.phases:
                status, headroom, message = LimitStatus.NOT_APPLICABLE, None, "Limit is not applicable to this phase"
            elif metric.status is not MetricStatus.AVAILABLE:
                status, headroom, message = LimitStatus.UNAVAILABLE, None, metric.message
            else:
                # Compare exact fractions, not the 34-digit display value. An
                # infinitesimal rounding across a limit must not change status.
                raw = Fraction(spec.threshold) - exact_metrics[spec.metric]
                if spec.direction is LimitDirection.MINIMUM:
                    raw = -raw
                headroom = decimal_fraction(raw)
                status, message = (LimitStatus.PASS if raw >= 0 else LimitStatus.BREACH), ""
            limit_results.append(LimitResult(spec.limit_id, spec.metric, metric.value, spec.threshold, spec.direction, status, headroom, message))
        return PortfolioReport(asof, next(iter(currencies), None), len(assets), decimal_fraction(total), phase,
                               tuple(metrics), tuple(concentrations), tuple(limit_results))
