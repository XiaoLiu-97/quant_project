"""Independent hand-sized LP/MILP oracles, input failures and strict rechecks."""

from dataclasses import replace
from datetime import date
from decimal import Decimal, Inexact, localcontext
from types import SimpleNamespace
import unittest
from unittest.mock import patch

from trident.optimization import (
    AssetDescriptor, AssetKind, Holding, OptimizationObjective, OptimizationRequest,
    OptimizationStatus, PortfolioLimits, StaticTradeOptimizer, TradeQuote, TradeSide,
)

D = Decimal
M = D("1000000")


def asset(name, *, kind=AssetKind.BSL, factor="2000", spread="500", obligor=None, country=None, sector=None):
    return AssetDescriptor(name, kind, obligor or name, country or name, sector or name, D(spread), D(factor))


def fixture(*, limits=None, objective=OptimizationObjective.MIN_FACTOR, starting_cash=D("2000000"), lot=None, fixed_fee=D(0)):
    infra = asset("INFRA", kind=AssetKind.INFRA, factor="1000", spread="300")
    old = asset("OLD", factor="4000", spread="600")
    new = asset("NEW")
    return OptimizationRequest(
        holdings=(Holding(infra, D("60000000")), Holding(old, D("40000000"))),
        quotes=(TradeQuote(old, TradeSide.SELL, D(99), D("40000000"), lot_size=lot, fixed_fee=fixed_fee),
                TradeQuote(new, TradeSide.BUY, D(101), D("40000000"), lot_size=lot, fixed_fee=fixed_fee)),
        starting_cash=starting_cash, limits=limits or PortfolioLimits(D("100000000")),
        objective=objective, factor_provenance="TRIDENT_SYNTHETIC_TEST_FACTOR_V1", settlement_date=date(2026, 11, 20),
    )


class StaticOptimizationTests(unittest.TestCase):
    def test_simplex_full_replacement_hand_oracle(self):
        request = fixture(limits=PortfolioLimits(D("100000000"), maximum_obligor_share=D("0.6"),
            maximum_country_share=D("0.6"), maximum_sector_share=D("0.6"), maximum_bsl_share=D("0.4"),
            minimum_infra_share=D("0.6"), maximum_overall_factor=D("1500"), maximum_bsl_factor=D("2500")))
        result = StaticTradeOptimizer().solve(request)
        self.assertTrue(result.validated, result.violations)
        self.assertEqual(result.solver_method, "HIGHS_DUAL_SIMPLEX")
        self.assertEqual([t.par for t in result.trades], [D("40000000"), D("40000000")])
        # EUR 40m sold at 99, bought at 101: EUR 0.8m net use.
        self.assertEqual(result.ending_cash, D("1200000"))
        self.assertEqual(result.overall_factor, D("1400"))
        self.assertEqual(result.bsl_factor, D("2000"))
        self.assertEqual(result.spread_bps, D("380"))
        self.assertEqual(result.ending_par, D("100000000"))
        self.assertEqual(next(h.par for h in result.ending_holdings if h.asset.kind is AssetKind.INFRA), D("60000000"))

    def test_spread_and_factor_conflict_and_binding_quality_constraint(self):
        unconstrained = StaticTradeOptimizer().solve(fixture(objective=OptimizationObjective.MAX_SPREAD))
        self.assertTrue(unconstrained.validated)
        self.assertEqual(unconstrained.trades, ())
        self.assertEqual(unconstrained.spread_bps, D(420))
        # 2200 - 2000*x/100m <=1600 -> x >=30m. Max spread selects exactly30m.
        result = StaticTradeOptimizer().solve(fixture(objective=OptimizationObjective.MAX_SPREAD,
            limits=PortfolioLimits(D("100000000"), maximum_overall_factor=D(1600))))
        self.assertTrue(result.validated, result.violations)
        self.assertEqual([t.par for t in result.trades], [D("30000000"), D("30000000")])
        self.assertEqual(result.spread_bps, D(390))
        self.assertEqual(result.overall_factor, D(1600))

    def test_cash_includes_clean_accrued_and_proportional_fees(self):
        request = fixture(starting_cash=D("1200000"))
        # Net unit use=(1.01+.01+.005) -(.99+.02-.005) = .02.
        quotes = (replace(request.quotes[0], accrued_per_par=D(".02"), proportional_fee_per_par=D(".005")),
                  replace(request.quotes[1], accrued_per_par=D(".01"), proportional_fee_per_par=D(".005")))
        result = StaticTradeOptimizer().solve(replace(request, quotes=quotes,
            limits=PortfolioLimits(D("100000000"), minimum_cash=D("400000"))))
        self.assertTrue(result.validated, result.violations)
        self.assertEqual(result.ending_cash, D("400000"))
        sell, buy = result.trades
        self.assertEqual(sell.accrued_cash, D("800000"))
        self.assertEqual(buy.accrued_cash, D("400000"))
        self.assertEqual(sell.fee_cash, D("200000"))
        self.assertEqual(buy.fee_cash, D("200000"))

    def test_integer_lot_cash_known_answer(self):
        # Each EUR 10m swap costs EUR 0.2m; .55m can buy two, not 2.75 lots.
        result = StaticTradeOptimizer().solve(fixture(starting_cash=D("550000"), lot=D("10000000")))
        self.assertTrue(result.validated, result.violations)
        self.assertEqual(result.solver_method, "HIGHS_MILP")
        self.assertEqual([t.par for t in result.trades], [D("20000000"), D("20000000")])
        self.assertEqual(result.ending_cash, D("150000"))
        self.assertEqual(result.overall_factor, D(1800))
        self.assertEqual(result.solver_gap, 0)
        self.assertIsNotNone(result.solver_bound)

    def test_minimum_ticket_and_fixed_fees_activate_binary(self):
        request = fixture(starting_cash=D("210000"), fixed_fee=D("10000"))
        quotes = tuple(replace(q, minimum_ticket=D("10000000")) for q in request.quotes)
        # A 10m minimum swap costs .2m plus two .01m fees; zero trades only.
        result = StaticTradeOptimizer().solve(replace(request, quotes=quotes))
        self.assertTrue(result.validated, result.violations)
        self.assertEqual(result.solver_method, "HIGHS_MILP")
        self.assertEqual(result.trades, ())
        request = replace(request, starting_cash=D("420000"), quotes=quotes)
        result = StaticTradeOptimizer().solve(request)
        self.assertTrue(result.validated, result.violations)
        self.assertEqual([t.par for t in result.trades], [D("20000000"), D("20000000")])
        self.assertEqual(result.ending_cash, D(0))
        self.assertEqual([t.fee_cash for t in result.trades], [D("10000"), D("10000")])

    def test_turnover_and_availability_caps(self):
        request = fixture(limits=PortfolioLimits(D("100000000"), maximum_trade_par=D("20000000")))
        result = StaticTradeOptimizer().solve(request)
        self.assertTrue(result.validated, result.violations)
        self.assertEqual([t.par for t in result.trades], [D("10000000"), D("10000000")])
        request = fixture()
        request = replace(request, quotes=(request.quotes[0], replace(request.quotes[1], maximum_par=D("5000000"))))
        result = StaticTradeOptimizer().solve(request)
        self.assertTrue(result.validated, result.violations)
        self.assertEqual([t.par for t in result.trades], [D("5000000"), D("5000000")])

    def test_same_obligor_aggregates_distinct_assets(self):
        request = fixture()
        candidate = replace(request.quotes[1].asset, obligor="INFRA")
        quotes = (request.quotes[0], replace(request.quotes[1], asset=candidate))
        result = StaticTradeOptimizer().solve(replace(request, quotes=quotes,
            limits=PortfolioLimits(D("100000000"), maximum_obligor_share=D(".6"))))
        self.assertTrue(result.validated, result.violations)
        self.assertEqual(result.trades, ())

    def test_was_and_bsl_factor_caps_have_separate_denominators(self):
        result = StaticTradeOptimizer().solve(fixture(limits=PortfolioLimits(D("100000000"),
            maximum_bsl_factor=D(3000), minimum_spread_bps=D(400))))
        self.assertTrue(result.validated, result.violations)
        self.assertEqual([t.par for t in result.trades], [D("20000000"), D("20000000")])
        self.assertEqual(result.spread_bps, D(400))
        self.assertEqual(result.bsl_factor, D(3000))

    def test_infeasible_retains_solver_evidence(self):
        result = StaticTradeOptimizer().solve(fixture(limits=PortfolioLimits(D("100000000"),
            minimum_infra_share=D(".7"))))
        self.assertEqual(result.status, OptimizationStatus.INFEASIBLE)
        self.assertEqual(result.solver_status, 2)
        self.assertFalse(result.validated)
        self.assertIsNone(result.ending_cash)
        self.assertTrue(result.solver_message)

    def test_empty_universe_baseline_check_and_no_bsl_factor(self):
        request = fixture()
        request = replace(request, holdings=(request.holdings[0],), quotes=(),
                          limits=PortfolioLimits(D("60000000")))
        result = StaticTradeOptimizer().solve(request)
        self.assertTrue(result.validated)
        self.assertIsNone(result.bsl_factor)
        self.assertEqual(result.overall_factor, D(1000))
        result = StaticTradeOptimizer().solve(replace(request, limits=PortfolioLimits(D("50000000"))))
        self.assertEqual(result.status, OptimizationStatus.INFEASIBLE)
        self.assertFalse(result.validated)

    def test_caller_decimal_context_does_not_change_answers(self):
        request = fixture(lot=D("10000000"))
        with localcontext() as caller:
            caller.prec = 2
            caller.traps[Inexact] = True
            result = StaticTradeOptimizer().solve(request)
        self.assertTrue(result.validated, result.violations)
        self.assertEqual(result.ending_cash, D("1200000"))

    def test_exact_posting_rejects_plan_solver_called_feasible(self):
        # LP coefficients say buy EUR1 at100.5 costs1.005. Available cash1.00:
        # a fabricated solver incumbent ignoring the .005 infeasibility must be
        # rejected after the clean cash posts to1.01, even if solver.status=0.
        infra = asset("I", kind=AssetKind.INFRA, factor="1000", spread="300")
        new = asset("N")
        request = OptimizationRequest((Holding(infra, D(1)),),
            (TradeQuote(new, TradeSide.BUY, D("100.5"), D(1)),), D(1),
            PortfolioLimits(D(2)), OptimizationObjective.MIN_FACTOR, "SYNTHETIC_TEST", date(2026, 11, 20))
        fake = SimpleNamespace(status=0, message="fabricated incumbent", x=[.000001], fun=0)
        with patch("scipy.optimize.linprog", return_value=fake):
            result = StaticTradeOptimizer().solve(request)
        self.assertEqual(result.status, OptimizationStatus.REJECTED_POST_VALIDATION)
        self.assertFalse(result.validated)
        self.assertEqual(result.ending_cash, D("-.01"))
        self.assertIn("Posted ending cash is below minimum_cash", result.violations)

    def test_cent_quantity_reconstruction_cannot_hide_factor_breach(self):
        request = fixture(limits=PortfolioLimits(D("100000000"), maximum_overall_factor=D(1600)))
        # 29,999,999.99 swap is EUR.01 short of the exact quality threshold.
        fake = SimpleNamespace(status=0, message="near-boundary", x=[29.99999999, 29.99999999], fun=-600)
        with patch("scipy.optimize.linprog", return_value=fake):
            result = StaticTradeOptimizer().solve(request)
        self.assertEqual(result.status, OptimizationStatus.REJECTED_POST_VALIDATION)
        self.assertFalse(result.validated)
        self.assertIn("Overall factor cap violated", result.violations)

    def test_time_limit_with_and_without_incumbent(self):
        request = fixture()
        incumbent = SimpleNamespace(status=1, message="time limit", x=[0, 0], fun=0)
        with patch("scipy.optimize.linprog", return_value=incumbent):
            result = StaticTradeOptimizer().solve(request)
        self.assertEqual(result.status, OptimizationStatus.FEASIBLE_TIME_LIMIT)
        self.assertTrue(result.validated)
        with patch("scipy.optimize.linprog", return_value=SimpleNamespace(status=1, message="time limit", x=None, fun=None)):
            result = StaticTradeOptimizer().solve(request)
        self.assertEqual(result.status, OptimizationStatus.NO_INCUMBENT)
        self.assertFalse(result.validated)

    def test_unbounded_and_numerical_status_do_not_expose_proposals(self):
        for status, expected in ((3, OptimizationStatus.UNBOUNDED), (4, OptimizationStatus.NUMERICAL_ERROR)):
            with self.subTest(status=status), patch("scipy.optimize.linprog",
                return_value=SimpleNamespace(status=status, message="failure", x=None, fun=None)):
                result = StaticTradeOptimizer().solve(fixture())
            self.assertEqual(result.status, expected)
            self.assertFalse(result.validated)
            self.assertEqual(result.trades, ())

    def test_input_validation_preserves_bsl_only_and_immutable_universe(self):
        request = fixture()
        with self.assertRaisesRegex(ValueError, "Only BSL"):
            TradeQuote(request.holdings[0].asset, TradeSide.SELL, D(100), D(1))
        with self.assertRaisesRegex(ValueError, "new assets"):
            replace(request, quotes=(replace(request.quotes[0], side=TradeSide.BUY),))
        with self.assertRaisesRegex(ValueError, "availability"):
            replace(request, quotes=(replace(request.quotes[0], maximum_par=D("50000000")),))
        with self.assertRaisesRegex(ValueError, "exactly match"):
            replace(request, quotes=(replace(request.quotes[0], asset=replace(request.quotes[0].asset, factor=D(1))),))
        with self.assertRaisesRegex(ValueError, "one quote"):
            replace(request, quotes=(request.quotes[1], request.quotes[1]))
        with self.assertRaisesRegex(ValueError, "Duplicate"):
            replace(request, holdings=(request.holdings[0], request.holdings[0]))
        for invalid in (D(0), D(-1), D("NaN"), 100.0):
            with self.subTest(value=invalid), self.assertRaises(ValueError):
                PortfolioLimits(invalid)
        with self.assertRaises(ValueError):
            PortfolioLimits(D(1), maximum_country_share=D("1.01"))
        with self.assertRaises(ValueError):
            replace(request, factor_provenance="")
        with self.assertRaises(ValueError):
            replace(request, solver_time_limit=float("nan"))


if __name__ == "__main__":
    unittest.main()
