"""Prepare template inputs and normalize workbook descriptive metadata.

The source workbook is read as a reference only; VBA is never loaded/executed.
Physical cell addresses below describe the retained v4.2.2 Market Data layout,
not business fields consumed by the Python financial engines.
Metadata normalization changes theme labels only, without computing financial
results or rewriting worksheet values, formulas, styles, or named interfaces.
"""

import argparse
import json
import os
import sys
import tempfile
from pathlib import Path
from typing import Any
from xml.etree import ElementTree
from zipfile import BadZipFile, ZipFile

from trident.adapters import excel_schema as schema
from trident.adapters.csv_input import read_csv_records
from trident.adapters.records import decimal_value
from trident.domain.models import InputValidationError


PROJECT_ROOT = Path(__file__).resolve().parents[1]
DEFAULT_PAYLOAD = PROJECT_ROOT / "data/templates/Project_Trident_inputs.json"
DEFAULT_MARKET_REFERENCE = PROJECT_ROOT / "data/reference/market_data.json"
THEME_NAMESPACE = "http://schemas.openxmlformats.org/drawingml/2006/main"
PROJECT_THEME_NAME = "Project Trident"
LEGACY_MARKET_ROWS = 245
LEGACY_MARKET_COLUMNS = 11
ASSET_DEFAULTS = {
    "fixed_rate": "", "payment_lag_business_days": "0", "end_of_month": "false",
    "stub_convention": "SHORT_LAST", "acquired_accrued_interest": "0", "user_note": "",
    "interest_mode": "CASH", "pik_fraction": "0",
}
LIMIT_BINDINGS = (
    ("INFRA_MIN", "concentration:asset_class:INFRA", "MINIMUM", "infra_minimum_fraction"),
    ("BSL_MAX", "concentration:asset_class:BSL", "MAXIMUM", "bsl_maximum_fraction"),
    ("OBLIGOR_MAX", "LARGEST_OBLIGOR_FRACTION", "MAXIMUM", "single_obligor_maximum_fraction"),
    ("COUNTRY_MAX", "LARGEST_COUNTRY_FRACTION", "MAXIMUM", "single_country_maximum_fraction"),
    ("SECTOR_MAX", "LARGEST_SECTOR_FRACTION", "MAXIMUM", "single_sector_maximum_fraction"),
    ("TEST_FACTOR_MAX", "TEST_FACTOR_AVERAGE", "MAXIMUM", "combined_synthetic_test_factor_maximum"),
    ("BSL_TEST_FACTOR_MAX", "BSL_TEST_FACTOR_AVERAGE", "MAXIMUM", "bsl_synthetic_test_factor_maximum"),
    ("TEST_06_MAX", "concentration:test_factor_bucket:TEST_06", "MAXIMUM", "test_06_maximum_fraction"),
)


def _normalize_theme_labels(contents: bytes) -> bytes:
    """Rename only descriptive labels in a DrawingML theme definition.

    Office and custom themes share these four metadata nodes. Their names do
    not define colors or fonts, so project branding does not change rendering.
    Returning the original bytes when already normalized makes repeat runs
    idempotent and avoids needless workbook replacement.
    """
    theme = ElementTree.fromstring(contents)
    if theme.tag != f"{{{THEME_NAMESPACE}}}theme":
        return contents
    labels = [theme]
    for local_name in ("clrScheme", "fontScheme", "fmtScheme"):
        scheme = theme.find(f"{{{THEME_NAMESPACE}}}themeElements/{{{THEME_NAMESPACE}}}{local_name}")
        if scheme is not None:
            labels.append(scheme)
    if all(label.get("name") == PROJECT_THEME_NAME for label in labels):
        return contents
    for label in labels:
        label.set("name", PROJECT_THEME_NAME)
    ElementTree.register_namespace("a", THEME_NAMESPACE)
    return ElementTree.tostring(theme, encoding="utf-8", xml_declaration=True)


def normalize_workbook_metadata(workbook_path: Path) -> tuple[str, ...]:
    """Set descriptive theme labels, preserving every other package part.

    A theme's name and scheme names are descriptive metadata; the color,
    font and format definitions beneath them determine appearance. Only the
    four labels change. Worksheet data, formulas, Tables and named ranges are
    copied byte for byte. A complete temporary ZIP replaces the workbook
    atomically, so a failed normalization leaves the original file intact.
    """
    destination = workbook_path.resolve(strict=True)
    if destination.suffix.lower() != ".xlsx" or not destination.is_file():
        raise InputValidationError("Metadata normalization requires an existing .xlsx file")
    if not destination.is_relative_to(PROJECT_ROOT):
        raise InputValidationError("Workbook metadata updates must remain inside the project workspace")
    replacements: dict[str, bytes] = {}
    with ZipFile(destination, "r") as original:
        entries = original.infolist()
        if len({entry.filename for entry in entries}) != len(entries):
            raise InputValidationError("Workbook package contains duplicate part names")
        for entry in entries:
            if not entry.filename.startswith("xl/theme/") or not entry.filename.endswith(".xml"):
                continue
            original_contents = original.read(entry)
            normalized_contents = _normalize_theme_labels(original_contents)
            if normalized_contents != original_contents:
                replacements[entry.filename] = normalized_contents
        if not replacements:
            return ()
        descriptor, temporary_name = tempfile.mkstemp(prefix=f".{destination.stem}.", suffix=".xlsx", dir=destination.parent)
        os.close(descriptor)
        temporary_path = Path(temporary_name)
        try:
            with ZipFile(temporary_path, "w") as normalized:
                normalized.comment = original.comment
                for entry in entries:
                    contents = replacements.get(entry.filename)
                    normalized.writestr(entry, contents if contents is not None else original.read(entry))
            # Close the source package before replacing a file on Windows.
        except BaseException:
            temporary_path.unlink(missing_ok=True)
            raise
    try:
        os.replace(temporary_path, destination)
    finally:
        temporary_path.unlink(missing_ok=True)
    return tuple(replacements)


def _json_number(value: object, label: str) -> int | float:
    """Convert configured input numbers at the JSON authoring boundary only."""
    number = decimal_value(value, label)
    return int(number) if number == number.to_integral_value() else float(number)


def _fixture_file(directory: Path, relative: str) -> Path:
    resolved = (directory / relative).resolve(strict=True)
    if not resolved.is_relative_to(directory):
        raise InputValidationError(f"Fixture file must remain inside the example directory: {relative}")
    return resolved


def extract_market_data(source: Path) -> dict[str, Any]:
    """Read values/styles from the bounded legacy paste surface, without macros."""
    try:
        from openpyxl import load_workbook
    except ImportError as error:
        raise InputValidationError("Reading a source workbook requires the existing [excel] extra") from error
    if source.suffix.lower() not in {".xlsx", ".xlsm"}:
        raise InputValidationError("Market Data source must be .xlsx/.xlsm; VBA is never executed")
    workbook = load_workbook(source, read_only=False, data_only=False, keep_vba=False, keep_links=False)
    try:
        if "Market Data" not in workbook.sheetnames:
            raise InputValidationError("Source workbook is missing the Market Data worksheet")
        sheet = workbook["Market Data"]
        cells = []
        for row in sheet.iter_rows(min_row=1, max_row=LEGACY_MARKET_ROWS,
                                   min_col=1, max_col=LEGACY_MARKET_COLUMNS):
            for cell in row:
                if cell.value is None:
                    continue
                if cell.data_type in {"f", "e"}:
                    raise InputValidationError(f"Market Data {cell.coordinate}: paste values rather than formula/error inputs")
                value = cell.value.isoformat() if hasattr(cell.value, "isoformat") else cell.value
                color = cell.font.color
                cells.append({"address": cell.coordinate, "value": value, "type": cell.data_type,
                              "number_format": cell.number_format,
                              "font_color": color.rgb if color is not None and color.type == "rgb" else None,
                              "fill": cell.fill.fgColor.rgb if cell.fill.fgColor.type == "rgb" else None})
        return {
            "source": str(source), "sheet_name": sheet.title,
            "max_row": LEGACY_MARKET_ROWS, "max_column": LEGACY_MARKET_COLUMNS,
            "freeze_panes": sheet.freeze_panes, "show_grid_lines": sheet.sheet_view.showGridLines,
            "merged_ranges": [str(region) for region in sheet.merged_cells.ranges],
            "column_widths": {key: dimension.width for key,dimension in sheet.column_dimensions.items()},
            "row_heights": {key: dimension.height for key,dimension in sheet.row_dimensions.items() if dimension.height},
            "defined_names": [{"name": name.name, "reference": name.attr_text, "local_scope": name.localSheetId}
                              for name in workbook.defined_names.values()],
            "cells": cells,
        }
    finally:
        workbook.close()


def validate_market_data(data: dict[str, Any]) -> None:
    """Reject an incompatible or incomplete archived Market Data interface."""
    required = {"source", "sheet_name", "max_row", "max_column", "cells", "merged_ranges",
                "column_widths", "row_heights", "freeze_panes", "show_grid_lines"}
    if not required.issubset(data) or data["sheet_name"] != "Market Data":
        raise InputValidationError("Market Data archive does not contain the expected layout metadata")
    if (data["max_row"], data["max_column"]) != (LEGACY_MARKET_ROWS, LEGACY_MARKET_COLUMNS):
        raise InputValidationError("Market Data archive must describe the retained A1:K245 layout")
    cells = data["cells"]
    addresses = [cell["address"] for cell in cells]
    if len(addresses) != len(set(addresses)):
        raise InputValidationError("Duplicate Market Data cell addresses in archive")
    by_address = {cell["address"]: cell for cell in cells}
    expected = dict(zip(("A5", "B5", "C5", "D5", "E5"), schema.CURVE_BLOCKS[0].columns))
    expected.update(dict(zip(("G5", "H5", "I5", "J5"), schema.CURVE_BLOCKS[1].columns)))
    for address,label in expected.items():
        if by_address.get(address, {}).get("value") != label:
            raise InputValidationError(f"Incompatible legacy Market Data header: {address}")
    if by_address.get("B3", {}).get("type") != "d":
        raise InputValidationError("Market Data As Of Date must be a typed date")
    for cell in cells:
        if cell.get("type") in {"f", "e"}:
            raise InputValidationError(f"Market Data {cell['address']}: archived formulas/errors are unsupported")
        if "number_format" not in cell:
            raise InputValidationError(f"Missing Market Data number format: {cell['address']}")


def portfolio_limits(terms: dict[str, Any]) -> list[dict[str, Any]]:
    """Translate documented synthetic limits into semantic interface records."""
    gates = terms["quality_and_concentration_gates"]
    if gates["seniority_and_security"] != "SENIOR_SECURED_ONLY" or gates["construction_revolver_pik_allowed"] is not False:
        raise InputValidationError("This synthetic template requires explicit senior-secured, no PIK/revolver/construction gates")
    keyed = {key: {"limit_id": key, "metric": metric, "direction": direction,
                  "threshold": _json_number(gates[field], field), "phases": "CLOSING,REINVESTMENT", "enabled": True}
             for key,metric,direction,field in LIMIT_BINDINGS}
    for key,metric,direction,threshold in (
        ("SENIOR_MIN", "SENIOR_FRACTION", "MINIMUM", 1),
        ("SECURED_MIN", "SECURED_FRACTION", "MINIMUM", 1),
        ("PIK_MAX", "PIK_FRACTION", "MAXIMUM", 0),
        ("REVOLVER_MAX", "REVOLVER_FRACTION", "MAXIMUM", 0),
        ("CONSTRUCTION_MAX", "CONSTRUCTION_FRACTION", "MAXIMUM", 0),
    ):
        keyed[key] = {"limit_id": key, "metric": metric, "direction": direction,
                      "threshold": threshold, "phases": "CLOSING,REINVESTMENT", "enabled": True}
    order = ("INFRA_MIN", "BSL_MAX", "OBLIGOR_MAX", "COUNTRY_MAX", "SECTOR_MAX", "SENIOR_MIN",
             "SECURED_MIN", "PIK_MAX", "REVOLVER_MAX", "CONSTRUCTION_MAX", "TEST_FACTOR_MAX",
             "BSL_TEST_FACTOR_MAX", "TEST_06_MAX")
    return [keyed[key] for key in order]


def prepare_payload(directory: Path, market_data: dict[str, Any]) -> dict[str, Any]:
    """Assemble current named-schema inputs, preserving source data and units.

    The authoring payload is a reproducible input template, not a financial
    oracle. Candidate evidence stays empty and explicit synthetic examples are
    never represented as live Bloomberg data or actual transactions.
    """
    validate_market_data(market_data)
    terms = json.loads((directory / "deal_terms.json").read_text(encoding="utf-8-sig"))
    if terms.get("provenance", {}).get("classification") != "SYNTHETIC_ONLY":
        raise InputValidationError("Template example must have SYNTHETIC_ONLY provenance")
    assets = [dict(row) for row in read_csv_records(_fixture_file(directory, terms["loan_tape"]["path"]))]
    capital = [dict(row) for row in read_csv_records(_fixture_file(directory, terms["capital_stack"]["path"]))]
    if not assets or not capital:
        raise InputValidationError("Asset and capital example CSVs must not be empty")
    for row in assets:
        for field,value in ASSET_DEFAULTS.items():
            row.setdefault(field,value)
    payload = {
        "schema_version": schema.SCHEMA_VERSION,
        "scalars": dict(schema.SCALAR_NAMES), "tables": dict(schema.TABLE_NAMES),
        "table_ranges": dict(schema.TABLE_RANGE_NAMES), "cashflow_columns": schema.ASSET_CASHFLOW_COLUMNS,
        "fixing_columns": schema.FIXING_COLUMNS, "assets": assets, "capital": capital,
        "assets_columns": schema.ordered_columns(tuple(assets[0]), schema.ASSET_PRIORITY_COLUMNS),
        "capital_columns": schema.ordered_columns(tuple(capital[0]), schema.CAPITAL_PRIORITY_COLUMNS),
        "market_data": market_data,
    }
    for row in capital:
        row.setdefault("fixed_rate", "")
        row.setdefault("pik_rate_fraction", "0")
        # Explicit synthetic contract terms, not inferred real-deal rules.
        row["interest_deferrable"] = row["class_id"] in {"C", "D", "E"}
        row["oc_minimum"] = terms["coverage"]["oc_minimum_fraction_by_class"].get(row["class_id"], "")
        row["ic_minimum"] = terms["coverage"]["ic_minimum_fraction_by_class"].get(row["class_id"], "")
    factors = []
    for row in read_csv_records(_fixture_file(directory, terms["synthetic_factor_convention"]["path"])):
        if row["provenance"] != "SYNTHETIC_ONLY":
            raise InputValidationError("Example factor rows must be explicitly synthetic")
        factors.append({"system": row["test_factor_system"], "version": str(row["fixture_version"]),
                        "bucket": row["test_factor_bucket"],
                        "factor": _json_number(row["synthetic_test_factor"], "synthetic_test_factor"),
                        "is_synthetic": True})
    payload.update({"scalars": dict(schema.SCALAR_NAMES), "tables": dict(schema.TABLE_NAMES),
                    "table_ranges": dict(schema.TABLE_RANGE_NAMES), "table_columns": dict(schema.TABLE_COLUMNS),
                    "input_defaults": dict(schema.INPUT_DEFAULTS),
                    "table_rows": {"factor_mapping": factors, "portfolio_limits": portfolio_limits(terms), "trade_candidates": []},
                    "capital_columns": schema.ordered_columns(tuple(capital[0]), schema.CAPITAL_PRIORITY_COLUMNS)})
    from trident.adapters import pilot_schema
    from trident.adapters.workbook_presentation import presentation_payload
    payload['presentation_policy'] = presentation_payload()
    payload['pilot_tables'] = {key: {'sheet': title, 'columns': columns,
        'input': key in pilot_schema.INPUT_TABLES,
        'instruction': pilot_schema.INSTRUCTIONS.get(key, 'Calculated evidence. Review status, units and scope before using results.')}
        for key, (title, columns) in pilot_schema.DESCRIPTORS.items()}
    from trident.application.scenarios import SCENARIO_FIELD_TYPES
    from trident.adapters.legacy_inputs import LEGACY_ASSUMPTIONS
    from trident.adapters.legacy_execution import execution_for
    from trident.adapters.legacy_layout import LEGACY_ASSUMPTION_GROUPS

    # Blank optional terms remain absent; a blank is never silently made zero.
    for row in assets:
        for field in schema.ASSET_EXTENSION_COLUMNS:
            row.setdefault(field, "")
    # Visible priority and optional transport registration can overlap. Keep
    # the first occurrence so a field appears once in both native Excel Tables.
    priority = tuple(dict.fromkeys((*schema.ASSET_PRIORITY_COLUMNS, *schema.ASSET_EXTENSION_COLUMNS)))
    payload["assets_columns"] = schema.ordered_columns(tuple(assets[0]), priority)
    payload["scenario_field_types"] = {target.value: dict(types) for target, types in SCENARIO_FIELD_TYPES.items()}
    payload["table_rows"].update({
        "principal_schedule": [], "coupon_steps": [], "credit_events": [], "recovery_schedule": [],
        "scenario_edits": [
            {"scenario_id": "A_MARGIN_150", "target": "NOTE", "identifier": "A",
             "field": "spread_bps", "value": 150, "enabled": True},
            {"scenario_id": "SENIOR_FEE_20", "target": "CONTROL", "identifier": "DEAL",
             "field": "senior_management_fee_bps", "value": 20, "enabled": True},
        ],
    })
    payload["table_number_formats"] = {key: dict(formats) for key, formats in schema.TABLE_NUMBER_FORMATS.items()}
    # Quote-level price/accrued values belong to Trade Candidates; Candidate
    # Assets supplies contract terms and must not duplicate acquired claims.
    payload["candidate_assets_columns"] = [field for field in payload["assets_columns"]
        if field not in {"purchase_price_pct", "acquired_accrued_interest"}]
    payload["table_rows"].update({key: [] for key in ("closing_costs", "recurring_expenses", "candidate_assets",
        "candidate_ratings", "candidate_metadata", "quote_observations", "collateral_detailed", "collateral_simplified")})
    payload["table_rows"]["candidate_variants"] = [
        {"candidate_id": "FACTOR_PROPOSAL", "objective": "MIN_FACTOR", "enabled": True},
        {"candidate_id": "SPREAD_PROPOSAL", "objective": "MAX_SPREAD", "enabled": True},
    ]
    payload["legacy_groups"] = [{"title": group.title, "field_ids": group.field_ids} for group in LEGACY_ASSUMPTION_GROUPS]
    payload["legacy_fields"] = [{"field_id": field.field_id, "source_coordinate": field.source_coordinate,
        "label": field.label, "semantic_type": field.semantic_type, "unit": field.unit,
        "editable": field.editable, "choices": field.choices, "reference_default": field.reference_default,
        "source_note": field.source_note,
        "execution_path": execution_for(field.field_id)[0] if field.editable else "Named formula summary",
        "activation_condition": execution_for(field.field_id)[1] if field.editable else "Calculated from the named components above"}
        for field in LEGACY_ASSUMPTIONS]
    # This coordinate is reference-layout metadata, never a financial mapping.
    payload["input_defaults"]["legacy_pricing_date"] = next(cell["value"] for cell in market_data["cells"] if cell["address"] == "B3")
    return payload


def main(arguments: list[str] | None = None) -> int:
    """Prepare current inputs from an explicit source or the frozen reference.

    Raw Market Data is owned by the reference archive, so deleting temporary
    generation files or rebuilding the payload cannot destroy its provenance.
    """
    parser = argparse.ArgumentParser(description=__doc__)
    source = parser.add_mutually_exclusive_group()
    source.add_argument("--source-workbook", type=Path, help="Read-only .xlsm/.xlsx with the legacy Market Data layout")
    source.add_argument("--source-market-json", type=Path,
                        help="Read-only Market Data JSON; default data/reference/market_data.json")
    source.add_argument("--normalize-workbook-metadata", type=Path,
                        help="Normalize existing workbook descriptive theme labels only")
    source.add_argument("--apply-workbook-presentation", type=Path,
                        help="Apply the shared presentation policy to a current workspace workbook atomically")
    parser.add_argument("--example-directory", type=Path, default=PROJECT_ROOT / "data/examples/hybrid_500m")
    parser.add_argument("--output-payload", type=Path, default=DEFAULT_PAYLOAD,
                        help="Current durable authoring payload path")
    parser.add_argument("--archive-market-json", type=Path, help="Optional durable export of the read-only Market Data reference")
    options = parser.parse_args(arguments)
    try:
        if options.apply_workbook_presentation:
            if options.archive_market_json or options.example_directory != PROJECT_ROOT / "data/examples/hybrid_500m" or options.output_payload != DEFAULT_PAYLOAD:
                raise InputValidationError("Workbook presentation cannot be combined with template input/output options")
            from openpyxl import load_workbook
            from trident.adapters.excel import NamedWorkbook, _save_atomic
            from trident.adapters.workbook_presentation import apply_workbook_presentation
            target = options.apply_workbook_presentation.resolve(strict=True)
            if not target.is_relative_to(PROJECT_ROOT.resolve()) or target.suffix.lower() != '.xlsx':
                raise InputValidationError("Workbook presentation requires an .xlsx inside the project workspace")
            book = load_workbook(target)
            try:
                adapter = NamedWorkbook(book)
                schema.require_current_schema(str(adapter.scalar(schema.SCALAR_NAMES['schema_version'])))
                report = apply_workbook_presentation(adapter)
                _save_atomic(book, target)
                print(json.dumps(report, ensure_ascii=False))
            finally:
                book.close()
            return 0
        if options.normalize_workbook_metadata:
            if options.archive_market_json or options.example_directory != PROJECT_ROOT / "data/examples/hybrid_500m" or options.output_payload != DEFAULT_PAYLOAD:
                raise InputValidationError("Metadata normalization cannot be combined with template input/output options")
            changed = normalize_workbook_metadata(options.normalize_workbook_metadata)
            print(f"Normalized workbook descriptive metadata: {len(changed)} theme parts")
            return 0
        directory = options.example_directory.resolve(strict=True)
        if options.source_workbook:
            market = extract_market_data(options.source_workbook.resolve(strict=True))
        elif options.source_market_json:
            market = json.loads(options.source_market_json.read_text(encoding="utf-8-sig"))
        else:
            market = json.loads(DEFAULT_MARKET_REFERENCE.read_text(encoding="utf-8-sig"))
        payload = prepare_payload(directory, market)
        destination = options.output_payload
        destination.parent.mkdir(parents=True, exist_ok=True)
        destination.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
        if options.archive_market_json:
            options.archive_market_json.parent.mkdir(parents=True, exist_ok=True)
            options.archive_market_json.write_text(json.dumps(market, ensure_ascii=False, indent=2), encoding="utf-8")
        print(f"Prepared schema {schema.SCHEMA_VERSION}: {len(payload['assets'])} assets, {len(payload['capital'])} capital rows; {destination}")
        print(f"Frozen Market Data reference source: {market['source']}")
        return 0
    except (OSError, ValueError, TypeError, KeyError, BadZipFile, ElementTree.ParseError) as error:
        print(f"Template preparation error: {error}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
