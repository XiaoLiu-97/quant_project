"""Presentation controls independent of financial values and fixed page layout.

The small Table is deliberately relocated away from the production template.
Assertions use explicit expected fonts, formats, wrapping and heights, and
verify that resizing never overwrites a user's existing/custom presentation.
"""

from datetime import date
from decimal import Decimal
from pathlib import Path
from tempfile import TemporaryDirectory
import unittest

from openpyxl import Workbook, load_workbook
from openpyxl.comments import Comment
from openpyxl.styles import Alignment, Font, PatternFill
from openpyxl.workbook.defined_name import DefinedName
from openpyxl.worksheet.table import Table, TableColumn

from trident.adapters import excel_schema as schema
from trident.adapters.excel import NamedWorkbook
from trident.adapters.pilot_workbook import ensure_pilot_interface


class TablePresentationTests(unittest.TestCase):
    """A first body row is the template, never a blanket restyling instruction."""

    def setUp(self):
        self.book = Workbook()
        self.addCleanup(self.book.close)
        self.sheet = self.book.active
        self.sheet.title = 'Relocated Review'
        self.columns = ('observation_date', 'amount', 'source')
        for col, field in enumerate(self.columns, 2):
            self.sheet.cell(8, col, field)
            cell = self.sheet.cell(9, col)
            cell.font = Font(name='Arial', size=10, color='0000FF')
            cell.alignment = Alignment(wrap_text=True, vertical='center')
        self.sheet['B9'].number_format = 'dd-mmm-yyyy'
        self.sheet['C9'].number_format = '#,##0.00'
        self.sheet['D9'].fill = PatternFill('solid', fgColor='EAF0F6')
        self.sheet.row_dimensions[9].height = 54
        self.sheet.column_dimensions['D'].width = 38
        table = Table(displayName='tbl_review', ref='B8:D9',
                      tableColumns=[TableColumn(id=i, name=field)
                                    for i, field in enumerate(self.columns, 1)])
        self.sheet.add_table(table)
        self.book.defined_names.add(DefinedName('trident_review', attr_text='tbl_review[#All]'))
        self.adapter = NamedWorkbook(self.book)

    @staticmethod
    def records(count):
        # Actual dates and decimals stay typed; long evidence is one source
        # string and must wrap, rather than being split into invented records.
        return tuple({'observation_date': date(2026, 4, i + 1),
                      'amount': Decimal(i) + Decimal('.25'),
                      'source': 'Independent trustee distribution statement and bank confirmation'}
                     for i in range(count))

    def write(self, count, **options):
        self.adapter.write_table('trident_review', 'tbl_review', self.records(count), **options)

    def test_growth_retains_dates_cents_sources_and_relocated_named_interface(self):
        self.write(4)
        for row in range(9, 13):
            self.assertEqual(self.sheet.cell(row, 2).number_format, 'dd-mmm-yyyy')
            self.assertEqual(self.sheet.cell(row, 3).number_format, '#,##0.00')
            self.assertTrue(self.sheet.cell(row, 4).alignment.wrap_text)
            self.assertEqual(self.sheet.cell(row, 4).alignment.vertical, 'center')
            self.assertEqual(self.sheet.cell(row, 4).font.name, 'Arial')
            self.assertEqual(self.sheet.cell(row, 4).font.color.rgb, '000000FF')
            self.assertEqual(self.sheet.cell(row, 4).fill.fgColor.rgb, '00EAF0F6')
            self.assertEqual(self.sheet.row_dimensions[row].height, 54)
        self.assertEqual(self.adapter.table_records('trident_review', 'tbl_review'),
                         tuple({**record, 'amount': float(record['amount'])} for record in self.records(4)))
        self.assertEqual(self.book.defined_names['trident_review'].attr_text, 'tbl_review[#All]')
        self.assertEqual(self.sheet.tables['tbl_review'].ref, 'B8:D12')
        self.assertEqual(self.sheet.column_dimensions['D'].width, 38)
        self.assertEqual(tuple(self.sheet.cell(8, col).value for col in range(2, 5)), self.columns)

    def test_baseline_font_does_not_prevent_missing_wrap_and_amount_format_inheritance(self):
        # A broadly preformatted worksheet already has a nondefault font.
        # Preserve it, but do not mistake it for an explicit number format or
        # wrap setting. This was the actual post-expansion presentation failure.
        for col in range(2, 5):
            self.sheet.cell(10, col).font = Font(name='Arial', size=10, color='222222')
        self.write(2)
        self.assertEqual(self.sheet['D10'].font.color.rgb, '00222222')
        self.assertTrue(self.sheet['D10'].alignment.wrap_text)
        self.assertEqual(self.sheet['C10'].number_format, '#,##0.00')
        self.assertEqual(self.sheet.row_dimensions[10].height, 54)

    def test_custom_components_in_new_blank_cells_are_preserved(self):
        self.sheet['D10'].font = Font(name='Arial', size=12, bold=True, color='FF0000')
        self.sheet['D10'].fill = PatternFill('solid', fgColor='FFFF00')
        self.sheet['D10'].alignment = Alignment(horizontal='right', wrap_text=False)
        self.sheet['B10'].number_format = 'mm/dd/yyyy'
        self.sheet['C10'].number_format = '0.0000'
        self.sheet.row_dimensions[10].height = 24
        self.write(2)
        self.assertEqual(self.sheet['D10'].font.sz, 12)
        self.assertTrue(self.sheet['D10'].font.bold)
        self.assertEqual(self.sheet['D10'].font.color.rgb, '00FF0000')
        self.assertEqual(self.sheet['D10'].fill.fgColor.rgb, '00FFFF00')
        self.assertFalse(self.sheet['D10'].alignment.wrap_text)
        self.assertEqual(self.sheet['D10'].alignment.horizontal, 'right')
        self.assertEqual(self.sheet['B10'].number_format, 'mm/dd/yyyy')
        self.assertEqual(self.sheet['C10'].number_format, '0.0000')
        self.assertEqual(self.sheet.row_dimensions[10].height, 24)
        self.assertEqual(self.sheet['C10'].value, 1.25)

    def test_existing_row_custom_style_and_height_are_not_restyled(self):
        self.sheet['D9'].font = Font(name='Arial', size=13, italic=True, color='008000')
        self.sheet['D9'].alignment = Alignment(wrap_text=False, horizontal='center')
        self.sheet.row_dimensions[9].height = 37
        self.write(3)
        self.assertEqual(self.sheet['D9'].font.sz, 13)
        self.assertEqual(self.sheet['D9'].font.color.rgb, '00008000')
        self.assertFalse(self.sheet['D9'].alignment.wrap_text)
        self.assertEqual(self.sheet.row_dimensions[9].height, 37)
        self.assertEqual(self.sheet.row_dimensions[10].height, 37)

    def test_shrink_and_reexpand_preserve_retained_custom_style(self):
        self.write(4)
        self.sheet['D12'].font = Font(name='Arial', size=11, color='800080')
        self.sheet['C12'].number_format = '0.00000'
        self.sheet.row_dimensions[12].height = 61
        self.write(0)
        self.assertIsNone(self.sheet['D12'].value)
        self.assertEqual(self.sheet.tables['tbl_review'].ref, 'B8:D9')
        self.write(5)
        self.assertEqual(self.sheet['D12'].font.color.rgb, '00800080')
        self.assertEqual(self.sheet['C12'].number_format, '0.00000')
        self.assertEqual(self.sheet.row_dimensions[12].height, 61)
        self.assertEqual(self.sheet.row_dimensions[13].height, 54)
        self.assertEqual(len(self.adapter.table_records('trident_review', 'tbl_review')), 5)

    def test_zero_height_and_existing_row_options_are_not_treated_as_missing(self):
        self.sheet.row_dimensions[10].height = 0
        self.sheet.row_dimensions[10].hidden = True
        self.sheet.row_dimensions[10].outlineLevel = 2
        self.write(2)
        self.assertEqual(self.sheet.row_dimensions[10].height, 0)
        self.assertTrue(self.sheet.row_dimensions[10].hidden)
        self.assertEqual(self.sheet.row_dimensions[10].outlineLevel, 2)

    def test_template_without_style_or_explicit_height_does_not_invent_them(self):
        for col in range(2, 5):
            self.sheet.cell(9, col)._style = None
        self.sheet.row_dimensions[9].height = None
        self.write(2)
        self.assertFalse(self.sheet['D10'].has_style)
        self.assertIsNone(self.sheet.row_dimensions[10].height)
        self.assertEqual(self.sheet['B10'].number_format, 'yyyy-mm-dd')
        self.assertEqual(self.sheet['C10'].number_format, '#,##0.00')

    def test_inherited_styles_are_independent_and_do_not_duplicate_annotations(self):
        self.sheet['D9'].comment = Comment('Source locator for this record only', 'User')
        self.sheet['D9'].hyperlink = 'https://example.org/statement'
        self.write(3)
        self.sheet['D10'].font = Font(name='Arial', size=10, color='FF0000')
        self.assertEqual(self.sheet['D9'].font.color.rgb, '000000FF')
        self.assertEqual(self.sheet['D11'].font.color.rgb, '000000FF')
        self.assertIsNone(self.sheet['D10'].comment)
        self.assertIsNone(self.sheet['D10'].hyperlink)
        self.assertIsNotNone(self.sheet['D9'].comment)

    def test_explicit_number_format_contract_keeps_its_existing_priority(self):
        self.sheet['C10'].number_format = '0.0000'
        self.write(2, number_formats={'amount': '0.00'})
        self.assertEqual(self.sheet['C9'].number_format, '0.00')
        self.assertEqual(self.sheet['C10'].number_format, '0.00')
        self.assertEqual(self.sheet['C10'].value, 1.25)

    def test_validation_failure_changes_neither_values_nor_styles(self):
        self.sheet['D10'] = 'Keep this neighbouring record'
        self.sheet['D10'].fill = PatternFill('solid', fgColor='FF0000')
        before = str(self.sheet['D10']._style)
        with self.assertRaisesRegex(ValueError, 'overwrite'):
            self.write(2)
        self.assertEqual(str(self.sheet['D10']._style), before)
        self.assertEqual(self.sheet['D10'].value, 'Keep this neighbouring record')
        self.assertEqual(self.sheet.tables['tbl_review'].ref, 'B8:D9')

    def test_presentation_and_typed_values_survive_saved_roundtrip(self):
        self.write(3)
        with TemporaryDirectory() as directory:
            path = Path(directory) / 'review.xlsx'
            self.book.save(path)
            restored = load_workbook(path)
            try:
                sheet = restored['Relocated Review']
                self.assertTrue(sheet['D11'].alignment.wrap_text)
                self.assertEqual(sheet.row_dimensions[11].height, 54)
                self.assertEqual(sheet['C11'].number_format, '#,##0.00')
                self.assertEqual(sheet['C11'].value, 2.25)
                self.assertEqual(sheet['B11'].value.date(), date(2026, 4, 3))
            finally:
                restored.close()


class PilotBodyTemplateTests(unittest.TestCase):
    def setUp(self):
        self.book = Workbook()
        self.addCleanup(self.book.close)
        self.adapter = NamedWorkbook(self.book)
        ensure_pilot_interface(self.adapter)

    def test_created_opening_tables_have_readable_wrapped_body_templates(self):
        for key in ('clo_opening_accounts', 'clo_opening_claims', 'clo_opening_audit'):
            with self.subTest(table=key):
                sheet, (left, top, right, _) = self.adapter.region(schema.TABLE_RANGE_NAMES[key])
                self.assertEqual(sheet.row_dimensions[top + 1].height, 54 if key == 'clo_opening_audit' else 32)
                for col in range(left, right + 1):
                    self.assertTrue(sheet.cell(top + 1, col).alignment.wrap_text)
                    self.assertEqual(sheet.cell(top + 1, col).font.name, 'Arial')
                self.assertEqual(sheet.cell(top + 1, left).font.color.rgb,
                                 '00000000' if key == 'clo_opening_audit' else '000000FF')

    def test_creating_interfaces_again_preserves_existing_custom_body(self):
        sheet, (left, top, right, _) = self.adapter.region(schema.TABLE_RANGE_NAMES['clo_opening_audit'])
        cell = sheet.cell(top + 1, right)
        cell.alignment = Alignment(wrap_text=False, horizontal='right')
        cell.font = Font(name='Arial', size=12, color='FF0000')
        sheet.row_dimensions[top + 1].height = 19
        ensure_pilot_interface(self.adapter)
        self.assertFalse(cell.alignment.wrap_text)
        self.assertEqual(cell.font.sz, 12)
        self.assertEqual(cell.font.color.rgb, '00FF0000')
        self.assertEqual(sheet.row_dimensions[top + 1].height, 19)


if __name__ == '__main__':
    unittest.main()
