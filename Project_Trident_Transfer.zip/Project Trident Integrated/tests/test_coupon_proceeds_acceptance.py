"""Independent acceptance ledgers for sourced purchased-coupon routing.

Loan entitlement, consideration paid to a seller, and the amount classified as
principal are different inputs. The controls below keep the contractual coupon
unchanged and account for every cent paid to debt/equity after an explicit
receipt allocation. A small two-period example makes early debt redemption and
the resulting next-period coupon saving observable without relying on IRR.

These are limited native cash-pay controls, not assertions that every indenture
permits the same allocation, reinvestment, or default treatment.
"""

import unittest
from dataclasses import replace
from datetime import date
from decimal import Decimal, Inexact, localcontext
from fractions import Fraction

from trident.analysis import AssetExposure, ReturnStatus
from trident.application.clo_services import TridentModelRequest, TridentModelService
from trident.application.services import CashflowRunRequest, CashflowRunService
from trident.clo.engine import DeterministicCloEngine
from trident.clo.models import (
    CashAccountAccrualMode, CloNoteCouponClaim, CloOpeningState, CloRunRequest,
    CloTerms, CoverageStatus, DefaultedAssetOcTreatment, NoteTranche,
    ProjectionStatus,
)
from trident.clo.proceeds import PrincipalAccruedBalance, CouponProceedsAllocation
from trident.clo.reinvestment import SyntheticReinvestmentPolicy
from trident.conventions import AccrualDateBasis, BusinessDayConvention, DayCount, StubConvention
from trident.credit import DefaultEvent, PrepaymentEvent
from trident.credit.models import AssetCashSource, AssetCollection
from trident.credit.overlay import OriginalPoolOverlay
from trident.domain.models import (
    CouponType, InputValidationError, LoanPosition, LoanTerms,
    OpeningCouponEntitlement, SeasonedLoanState,
)
from trident.funding.engine import AssetPurchase, DebtIssue
from trident.market import FlatRateProvider


D = Decimal
START = date(2026, 4, 1)
OPEN = date(2026, 5, 15)
FIRST = date(2026, 7, 1)
FINAL = date(2026, 10, 1)
BALANCE_SOURCE = "Independent settlement account record: L/2026-05-15"
ALLOCATION_SOURCE = "Independent agent coupon allocation: L/2026-07-01"
LEGAL_REFERENCE = "Verified transaction principal-account purchased-coupon clause"


def position(loan_id="L", *, par=D(100), rate=D("0.12"), claim=D("1.47"),
             entitlement=OpeningCouponEntitlement.FULL_CURRENT_PERIOD):
    """Retain the original quarterly contract, not a newly originated loan."""
    terms = LoanTerms(
        loan_id, "EUR", START, FINAL, par, CouponType.FIXED,
        fixed_rate=rate, day_count=DayCount.ACT_360,
        business_day_convention=BusinessDayConvention.UNADJUSTED,
        accrual_date_basis=AccrualDateBasis.UNADJUSTED,
        fixing_lag_business_days=0,
    )
    return LoanPosition(terms, OPEN, par, SeasonedLoanState(
        claim, "Verified original coupon ownership", entitlement_policy=entitlement))


def request(*, classified=True, amount=D("1.47"), permission=False,
            purchase_accrued=D("1.47"), ic_minimum=D("1.3"),
            extra_position=None, existing=False):
    """Use at-par funding and explicit policies so the hand ledger is closed."""
    positions = (position(),) if extra_position is None else (position(), extra_position)
    purchases = tuple(AssetPurchase(
        item.terms.loan_id, item.opening_balance, D(100),
        D(0) if existing or item.terms.loan_id != "L" else purchase_accrued)
        for item in positions)
    cash = CashflowRunRequest(
        positions, purchases, (DebtIssue("A", D(80), D(100)),),
        FlatRateProvider({"EURIBOR_3M": D(0)}), D(0), D(0),
        "Independent two-period acceptance control",
    )
    exposures = tuple(AssetExposure(
        item.terms.loan_id, "Obligor-" + item.terms.loan_id, "BSL", "LOAN",
        "FR", "Industrial", "EUR", item.opening_balance, None, FINAL,
        coupon_type=CouponType.FIXED, fixed_coupon_rate=item.terms.fixed_rate)
        for item in positions)
    terms = CloTerms(
        date(2026, 2, 15) if existing else OPEN, FINAL,
        first_payment_date_unadjusted=OPEN if existing else FIRST,
        stub_convention=StubConvention.SHORT_LAST if existing else StubConvention.SHORT_FIRST,
        business_day_convention=BusinessDayConvention.UNADJUSTED,
        accrual_date_basis=AccrualDateBasis.UNADJUSTED,
        fixing_lag_business_days=0,
    )
    note = NoteTranche("A", 1, D(80), CouponType.FIXED,
                       fixed_rate=D("0.06"), day_count=DayCount.ACT_360,
                       oc_minimum=D("1.2"), ic_minimum=ic_minimum)
    balances = ((PrincipalAccruedBalance("L", OPEN, amount, BALANCE_SOURCE, LEGAL_REFERENCE),)
                if classified else ())
    allocations = ((CouponProceedsAllocation(
        "L-COUPON-1", "L", FIRST, AssetCashSource.SCHEDULED, amount,
        permission, ALLOCATION_SOURCE, LEGAL_REFERENCE),) if classified else ())
    opening = (CloOpeningState(OPEN, D(0), D(0), D(0),
               (CloNoteCouponClaim("A", D(0)),), "Verified post-distribution state")
               if existing else None)
    return TridentModelRequest(
        cash, exposures, clo_terms=terms, notes=(note,),
        clo_opening_state=opening,
        forward_equity_value=D(20) if existing else None,
        equity_value_source="Independent current equity mark" if existing else "",
        principal_accrued_balances=balances, coupon_proceeds_allocations=allocations,
    )


def low_level(model_request, **overrides):
    """Feed identical native promises to the public waterfall boundary."""
    projection = CashflowRunService().run(model_request.cashflow_request)
    values = dict(
        asset_cashflows=projection.cashflows,
        opening_collateral_par=sum(item.opening_balance for item in model_request.cashflow_request.positions),
        tranches=model_request.notes, terms=model_request.clo_terms,
        principal_accrued_balances=model_request.principal_accrued_balances,
        coupon_proceeds_allocations=model_request.coupon_proceeds_allocations,
    )
    values.update(overrides)
    return CloRunRequest(**values)


def gate(projection, period=1, stage="GATE"):
    return next(item for item in projection.coverage_tests
                if item.period_number == period and item.class_id == "A" and item.stage == stage)


class CouponProceedsFinancialAcceptanceTests(unittest.TestCase):
    def test_untagged_two_period_baseline_remains_an_interest_receipt(self):
        result = TridentModelService().run(request(classified=False))
        first, final = result.clo.periods
        # Borrower coupon posts91days once to3.03; the new note's first
        # period is47days, giving.63. A remains80 until the final100 receipt.
        self.assertEqual([row.cash_interest for row in result.cashflows.cashflows],
                         [D("3.03"), D("3.07")])
        self.assertEqual(result.cashflows.funding.equity_cash_funding, D("21.47"))
        self.assertEqual((first.equity_from_interest, first.closing_debt_par),
                         (D("2.40"), D(80)))
        self.assertEqual(final.note_coupon_due, D("1.23"))
        self.assertEqual(final.equity_from_interest + final.equity_from_principal, D("21.84"))
        self.assertEqual(result.clo.total_equity_distributions, D("24.24"))
        self.assertEqual(result.clo.coupon_proceeds_audit, ())

    def test_explicit_classification_conserves_cash_and_saves_next_coupon(self):
        result = TridentModelService().run(request())
        first, final = result.clo.periods
        # A borrower still pays3.03, split1.47 principal and1.56 interest.
        # .63 note coupon leaves.93 equity. Immediate principal redemption
        # leaves78.53, whose92day next coupon is1.20 rather than1.23.
        self.assertEqual(result.cashflows.cashflows[0].cash_interest, D("3.03"))
        self.assertEqual((first.received_asset_interest, first.received_asset_principal),
                         (D("1.56"), D("1.47")))
        self.assertEqual((first.note_coupon_due, first.equity_from_interest,
                          first.debt_principal_from_principal, first.closing_debt_par),
                         (D("0.63"), D("0.93"), D("1.47"), D("78.53")))
        self.assertEqual((final.received_asset_interest, final.received_asset_principal),
                         (D("3.07"), D(100)))
        self.assertEqual((final.note_coupon_due, final.equity_from_interest,
                          final.equity_from_principal), (D("1.20"), D("1.87"), D("21.47")))
        self.assertEqual(result.clo.total_equity_distributions, D("24.27"))
        self.assertEqual(result.equity_cashflows[0].amount, D("-21.47"))
        self.assertIs(result.equity_irr.status, ReturnStatus.AVAILABLE)
        self.assertIs(result.clo.status, ProjectionStatus.COMPLETED)
        self.assertTrue(result.clo.terminal_value_available)
        self.assertTrue(all(row.cash_conservation_residual == 0 for row in result.clo.periods))
        # Independent lifetime cash ledger: borrower106.10 = note80 face
        # +1.83 coupon +24.27 equity. Reclassification creates no new cash.
        self.assertEqual(Fraction(100) + Fraction("6.10"),
                         Fraction(80) + Fraction("1.83") + Fraction(result.clo.total_equity_distributions))
        audit, = result.clo.coupon_proceeds_audit
        self.assertEqual((audit.raw_coupon_cash, audit.raw_principal_cash,
                          audit.principal_accrued_restored, audit.interest_proceeds,
                          audit.principal_proceeds, audit.remaining_principal_accrued),
                         (D("3.03"), D(0), D("1.47"), D("1.56"), D("1.47"), D(0)))
        self.assertEqual((audit.balance_source, audit.allocation_source, audit.legal_reference),
                         (BALANCE_SOURCE, ALLOCATION_SOURCE, LEGAL_REFERENCE))
        self.assertEqual(audit.receipt_rows, 1)

    def test_explicit_smaller_allocation_is_not_inferred_from_cost_or_entitlement(self):
        result = TridentModelService().run(request(amount=D("0.50")))
        first, final = result.clo.periods
        self.assertEqual(result.cashflows.funding.acquired_accrued_interest, D("1.47"))
        self.assertEqual(result.cashflows.cashflows[0].opening_accrued_interest, D("1.47"))
        self.assertEqual((first.received_asset_interest, first.received_asset_principal),
                         (D("2.53"), D("0.50")))
        self.assertEqual((first.equity_from_interest, first.closing_debt_par),
                         (D("1.90"), D("79.50")))
        self.assertEqual(final.note_coupon_due, D("1.22"))
        self.assertEqual(result.clo.total_equity_distributions, D("24.25"))

    def test_coverage_uses_classified_interest_and_actual_principal_cash(self):
        projection = TridentModelService().run(request()).clo
        opening_gate = gate(projection)
        period_end = gate(projection, stage="PERIOD_END")
        self.assertEqual((opening_gate.ic_numerator, opening_gate.ic_denominator),
                         (D("1.56"), D("0.63")))
        self.assertEqual((opening_gate.oc_numerator, opening_gate.oc_denominator),
                         (D("101.47"), D(80)))
        self.assertEqual((period_end.oc_numerator, period_end.oc_denominator),
                         (D(100), D("78.53")))
        self.assertIs(opening_gate.ic_status, CoverageStatus.PASS)
        self.assertIs(opening_gate.oc_status, CoverageStatus.PASS)

    def test_principal_cash_exclusion_does_not_add_the_old_financing_claim_to_oc(self):
        model = request()
        model = replace(model, clo_terms=replace(model.clo_terms, include_principal_cash_in_oc=False))
        first_gate = gate(TridentModelService().run(model).clo)
        self.assertEqual(first_gate.oc_numerator, D(100))

    def test_restoration_can_change_ic_and_its_actual_cure_diversion(self):
        untagged = TridentModelService().run(request(classified=False, ic_minimum=D(3))).clo
        classified = TridentModelService().run(request(ic_minimum=D(3))).clo
        # 3.03/.63 passes3x;1.56/.63 fails. The remaining.93 then cures
        # debt rather than going to equity, independently of the1.47 split.
        self.assertIs(gate(untagged).ic_status, CoverageStatus.PASS)
        self.assertIs(gate(classified).ic_status, CoverageStatus.FAIL)
        self.assertEqual(classified.periods[0].equity_from_interest, D(0))
        self.assertEqual(classified.periods[0].debt_principal_from_interest, D("0.93"))
        self.assertEqual(classified.periods[0].closing_debt_par, D("77.60"))
        self.assertTrue(all(row.cash_conservation_residual == 0 for row in classified.periods))

    def test_cutoff_transfers_classified_cash_once_and_preserves_bank_balance(self):
        model = request(ic_minimum=None)
        cash = replace(model.cashflow_request, cash_reserve=D(1))
        terms = replace(model.clo_terms, initial_reserve=D(1), collection_cutoff_business_days=2,
                        continue_after_coupon_shortfall=True,
                        cash_account_accrual_mode=CashAccountAccrualMode.FIXED_SIMPLE,
                        cash_account_fixed_rate=D("0.036"))
        result = TridentModelService().run(replace(model, cashflow_request=cash, clo_terms=terms))
        first, final = result.clo.periods
        # Jul1 cash misses the first cutoff: no spendable asset proceeds.
        # Restricted reserve does not finance note coupons; carry.63 to the
        # explicitly continued distribution. Physical3.03 earns92days ->.03.
        self.assertEqual((first.pending_interest_cash, first.pending_principal_cash),
                         (D("1.56"), D("1.47")))
        self.assertEqual((first.eligible_asset_interest, first.eligible_asset_principal), (D(0), D(0)))
        self.assertEqual((first.reserve_draw, first.reserve_closing), (D(0), D(1)))
        self.assertEqual(first.note_coupon_unpaid, D("0.63"))
        self.assertEqual(first.closing_debt_par, D(80))
        self.assertEqual((final.eligible_asset_interest, final.eligible_asset_principal),
                         (D("4.63"), D("101.47")))
        self.assertEqual(final.received_asset_interest, D("3.07"))
        self.assertEqual(final.cash_account_interest, D("0.03"))
        self.assertEqual(final.note_coupon_due, D("1.86"))
        self.assertEqual(result.clo.total_equity_distributions, D("25.27"))
        self.assertEqual(result.cashflows.funding.equity_cash_funding, D("22.47"))
        self.assertTrue(all(row.cash_conservation_residual == 0 for row in result.clo.periods))
        self.assertEqual(len(result.clo.coupon_proceeds_audit), 1)

    def test_original_principal_permission_is_separate_from_principal_classification(self):
        policy = SyntheticReinvestmentPolicy(
            enabled=True, end_date=FIRST, spread_bps=D(0), purchase_price=D(1),
            bullet_wal_years=D("0.25"), annual_prepayment_rate=D(0),
            annual_default_rate=D(0), recycle_reinvestment_principal=False)
        results = []
        for permission in (False, True):
            model = request(permission=permission)
            results.append(TridentModelService().run(replace(
                model, clo_terms=replace(model.clo_terms, synthetic_reinvestment_policy=policy))).clo)
        excluded, permitted = results
        self.assertEqual(excluded.reinvestment_purchases, ())
        self.assertEqual(excluded.periods[0].closing_debt_par, D("78.53"))
        purchase, = permitted.reinvestment_purchases
        self.assertEqual((purchase.purchase_date, purchase.cash_used, purchase.acquired_par),
                         (FIRST, D("1.47"), D("1.47")))
        self.assertEqual(permitted.periods[0].closing_debt_par, D(80))
        self.assertEqual(permitted.periods[0].closing_collateral_par, D("101.47"))
        self.assertEqual(excluded.coupon_proceeds_audit[0].original_principal_permission, D(0))
        self.assertEqual(permitted.coupon_proceeds_audit[0].original_principal_permission, D("1.47"))
        self.assertTrue(all(row.cash_conservation_residual == 0 for row in permitted.periods))

    def test_existing_opening_can_classify_a_sourced_claim_without_reissuing_funding(self):
        result = TridentModelService().run(request(existing=True, ic_minimum=None))
        self.assertIsNone(result.cashflows.funding)
        self.assertEqual(result.equity_cashflows[0].amount, D(-20))
        self.assertEqual(result.clo.coupon_proceeds_audit[0].principal_accrued_restored, D("1.47"))
        self.assertTrue(all(row.cash_conservation_residual == 0 for row in result.clo.periods))

    def test_exact_early_prepayment_source_is_not_the_cancelled_contractual_coupon(self):
        model = request(ic_minimum=None)
        prepay = date(2026, 6, 1)
        allocation = replace(model.coupon_proceeds_allocations[0], payment_date=prepay,
                             collection_source=AssetCashSource.PREPAYMENT)
        result = TridentModelService().run(replace(
            model, credit_events=(PrepaymentEvent("L", prepay),),
            coupon_proceeds_allocations=(allocation,)))
        # ActualApr1-Jun1 coupon is61days ->2.03; the July promised3.03
        # remains a reference. Routing1.47 cannot collect both promises.
        audit, = result.clo.coupon_proceeds_audit
        self.assertEqual((audit.payment_date, audit.collection_source, audit.raw_coupon_cash),
                         (prepay, AssetCashSource.PREPAYMENT, D("2.03")))
        self.assertEqual(audit.interest_proceeds, D("0.56"))
        self.assertEqual(audit.principal_proceeds, D("101.47"))
        self.assertEqual(result.clo.total_equity_distributions, D("21.40"))
        self.assertTrue(all(row.cash_conservation_residual == 0 for row in result.clo.periods))

    def test_unrelated_default_does_not_change_the_claimed_native_coupon(self):
        other = position("OTHER", par=D(10), rate=D(0), claim=D(0))
        model = request(extra_position=other, ic_minimum=None)
        default_date = date(2026, 6, 1)
        model = replace(model,
            credit_events=(DefaultEvent("OTHER", default_date, writeoff_date=default_date),),
            clo_terms=replace(model.clo_terms,
                              defaulted_asset_oc_treatment=DefaultedAssetOcTreatment.EXCLUDE))
        result = TridentModelService().run(model)
        self.assertEqual(result.clo.coupon_proceeds_audit[0].loan_id, "L")
        self.assertEqual(result.clo.coupon_proceeds_audit[0].raw_coupon_cash, D("3.03"))
        self.assertEqual(result.clo.total_recognized_par_loss, D(10))
        self.assertTrue(all(row.cash_conservation_residual == 0 for row in result.clo.periods))

    def test_caller_precision_and_traps_do_not_change_the_financial_ledger(self):
        model = request()
        expected = TridentModelService().run(model)
        with localcontext() as context:
            context.prec = 6
            context.traps[Inexact] = True
            actual = TridentModelService().run(model)
        # Run IDs identify publications, not economics; compare every other
        # returned field under the hostile caller context.
        actual = replace(actual, cashflows=replace(actual.cashflows, run_id=expected.cashflows.run_id))
        self.assertEqual(actual, expected)

    def test_early_cash_pay_failure_excludes_a_later_valid_allocation_from_actual_audit(self):
        model = request()
        # Monthly debt first paysJun15, before the asset's firstJul1 coupon.
        # The valid Jul1 instruction remains an input, not an actual receipt
        # in a projection stopping at the unpaid first debt distribution.
        terms = replace(model.clo_terms, frequency_months=1,
                        first_payment_date_unadjusted=None,
                        stub_convention=StubConvention.SHORT_LAST)
        result = TridentModelService().run(replace(model, clo_terms=terms))
        first, = result.clo.periods
        self.assertEqual(first.payment_date, date(2026, 6, 15))
        self.assertEqual(first.note_coupon_unpaid, D("0.41"))
        self.assertIs(result.clo.status, ProjectionStatus.CASH_PAY_FAILURE)
        self.assertFalse(result.clo.terminal_value_available)
        self.assertEqual(result.clo.coupon_proceeds_audit, ())
        self.assertEqual((first.received_asset_interest, first.received_asset_principal), (D(0), D(0)))
        self.assertEqual(first.cash_conservation_residual, D(0))


class CouponProceedsScopeAcceptanceTests(unittest.TestCase):
    def assert_model_rejected(self, model_or_factory):
        """Accept failure at either typed-input or calculation boundary."""
        with self.assertRaises(InputValidationError):
            model = model_or_factory() if callable(model_or_factory) else model_or_factory
            TridentModelService().run(model)

    def test_declared_cap_cannot_exceed_actual_purchase_accrued_cost(self):
        self.assert_model_rejected(lambda: request(purchase_accrued=D("0.50")))

    def test_existing_cap_cannot_exceed_held_historical_entitlement(self):
        self.assert_model_rejected(lambda: request(existing=True, amount=D("1.48")))

    def test_existing_post_asof_only_ownership_cannot_supply_a_purchased_coupon_claim(self):
        model = request(existing=True)
        held = position(claim=D(0), entitlement=OpeningCouponEntitlement.POST_ASOF_ONLY)
        self.assert_model_rejected(lambda: replace(model, cashflow_request=replace(
            model.cashflow_request, positions=(held,))))

    def test_second_coupon_and_wrong_event_source_are_not_automatic_fifo(self):
        model = request()
        for payment_date, source in ((FINAL, AssetCashSource.SCHEDULED),
                                     (FIRST, AssetCashSource.PREPAYMENT),
                                     (date(2026, 6, 30), AssetCashSource.SCHEDULED)):
            with self.subTest(payment_date=payment_date, source=source):
                self.assert_model_rejected(replace(model, coupon_proceeds_allocations=(replace(
                    model.coupon_proceeds_allocations[0], payment_date=payment_date,
                    collection_source=source),)))

    def test_balance_asof_and_asset_identity_must_match_the_held_position(self):
        model = request()
        for balance in (replace(model.principal_accrued_balances[0], as_of_date=START),
                        replace(model.principal_accrued_balances[0], loan_id="UNKNOWN")):
            with self.subTest(balance=balance):
                self.assert_model_rejected(lambda: replace(model, principal_accrued_balances=(balance,)))

    def test_claimed_default_is_rejected_instead_of_restoring_hypothetical_coupon(self):
        model = request()
        default_date = date(2026, 6, 1)
        self.assert_model_rejected(lambda: replace(model,
            credit_events=(DefaultEvent("L", default_date, writeoff_date=default_date),),
            clo_terms=replace(model.clo_terms,
                              defaulted_asset_oc_treatment=DefaultedAssetOcTreatment.EXCLUDE)))

    def test_zero_default_without_a_classification_preserves_the_existing_cash_model(self):
        model = request(classified=False)
        expected = TridentModelService().run(model)
        actual = TridentModelService().run(replace(
            model, principal_accrued_balances=(), coupon_proceeds_allocations=()))
        self.assertEqual(replace(actual, cashflows=replace(actual.cashflows,
                         run_id=expected.cashflows.run_id)), expected)

    def test_one_balance_and_one_equal_allocation_per_loan_are_required(self):
        model = request()
        balance, = model.principal_accrued_balances
        allocation, = model.coupon_proceeds_allocations
        for balances, allocations in (
            ((balance,), ()), ((), (allocation,)),
            ((balance, balance), (allocation,)),
            ((balance,), (allocation, replace(allocation, allocation_id="SECOND"))),
            ((balance,), (replace(allocation, principal_amount=D("0.50")),)),
            ((balance,), (replace(allocation, loan_id="OTHER"),)),
        ):
            with self.subTest(balances=balances, allocations=allocations):
                with self.assertRaises(InputValidationError):
                    changed = replace(model, principal_accrued_balances=balances,
                                      coupon_proceeds_allocations=allocations)
                    TridentModelService().run(changed)

    def test_negative_fractional_or_nonfinite_claim_cannot_enter_the_cash_accounts(self):
        for amount in (D(0), D("-0.01"), D("1.001"), D("NaN"), D("Infinity"), "1.47", 1.47):
            with self.subTest(amount=amount), self.assertRaises(InputValidationError):
                request(amount=amount)

    def test_sources_legal_reference_and_boolean_permission_are_mandatory(self):
        model = request()
        balance, = model.principal_accrued_balances
        allocation, = model.coupon_proceeds_allocations
        for field in ("source", "legal_reference"):
            for missing in ("", " ", None):
                with self.subTest(record="balance", field=field, missing=missing), self.assertRaises(InputValidationError):
                    replace(balance, **{field: missing})
                with self.subTest(record="allocation", field=field, missing=missing), self.assertRaises(InputValidationError):
                    replace(allocation, **{field: missing})
        for permission in (0, 1, "False", None):
            with self.subTest(permission=permission), self.assertRaises(InputValidationError):
                replace(allocation, original_principal_permission=permission)
        with self.assertRaises(InputValidationError):
            replace(allocation, collection_source="SCHEDULED")

    def test_noneligible_principal_cannot_bypass_permission_through_recycle_all(self):
        model = request(permission=False)
        policy = SyntheticReinvestmentPolicy(enabled=True, end_date=FIRST,
                                             recycle_reinvestment_principal=True)
        self.assert_model_rejected(replace(model, clo_terms=replace(
            model.clo_terms, synthetic_reinvestment_policy=policy)))

    def test_optional_call_and_original_overlay_require_another_legal_profile(self):
        model = request()
        variants = (
            replace(model.clo_terms, optional_call_enabled=True, optional_call_date=FIRST),
            replace(model.clo_terms, original_pool_overlay=OriginalPoolOverlay(
                enabled=True, annual_default_rate=D(0))),
        )
        for terms in variants:
            with self.subTest(terms=terms):
                self.assert_model_rejected(replace(model, clo_terms=terms))

    def test_low_level_additional_receipt_cannot_manufacture_or_reassign_the_claim(self):
        model = request()
        extra = AssetCollection("L", "EUR", date(2026, 6, 1), AssetCashSource.SCHEDULED,
                                D("0.01"), D(0), D("0.01"), 1)
        with self.assertRaises(InputValidationError):
            value = low_level(model, additional_asset_collections=(extra,))
            DeterministicCloEngine(model.cashflow_request.rate_provider).run(value)

    def test_duplicate_first_native_receipts_do_not_restore_the_claim_twice(self):
        model = request()
        value = low_level(model)
        with self.assertRaises(InputValidationError):
            duplicate = replace(value, asset_cashflows=(value.asset_cashflows[0], *value.asset_cashflows))
            DeterministicCloEngine(model.cashflow_request.rate_provider).run(duplicate)


if __name__ == "__main__":
    unittest.main()
