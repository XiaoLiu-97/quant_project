"""Read-only local Markdown link check for README and project documentation."""
from pathlib import Path
from urllib.parse import unquote
import json, re

root=Path(__file__).resolve().parents[1]
files=[root/'README.md',*sorted((root/'docs').rglob('*.md'))]
checked=0;broken=[]
for path in files:
    text=path.read_text(encoding='utf8')
    text=re.sub(r'```.*?```','',text,flags=re.S)
    for match in re.finditer(r'!?\[[^\]]*\]\(([^\s)]+)(?:\s+"[^"]*")?\)',text):
        link=match.group(1).strip('<>')
        if re.match(r'^[a-zA-Z][a-zA-Z0-9+.-]*:',link) or link.startswith('#'):continue
        local=unquote(link.split('#',1)[0])
        target=(path.parent/local).resolve()
        checked+=1
        if not target.exists():broken.append({'file':str(path.relative_to(root)),'link':link})
report={'status':'FAIL' if broken else 'PASS','files':len(files),'local_links_checked':checked,'broken':broken,
        'scope':'Local file existence only; anchors and internet URLs are not checked'}
print(json.dumps(report,ensure_ascii=False,indent=2))
raise SystemExit(1 if broken else 0)
