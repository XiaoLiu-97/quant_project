"""Sources & Uses with clean prices, acquired accrued interest and equity cash."""

from dataclasses import dataclass
from decimal import Decimal
from enum import Enum
from fractions import Fraction
from typing import Iterable

from trident.domain.models import InputValidationError, require_decimal, require_money
from trident.domain.numeric import post_currency


class ClosingSourceType(str, Enum):
    """Classify closing cash without inventing an unmodelled repayment claim.

    EXTERNAL_CONTRIBUTION is an irrevocable cash contribution with no coupon,
    repayment, redemption or residual-distribution entitlement. A warehouse
    loan, liquidity facility, equity subscription or restricted balance is not
    such a contribution and must be modelled in its own funding/state account.
    """

    EXTERNAL_CONTRIBUTION = "EXTERNAL_CONTRIBUTION"


@dataclass(frozen=True)
class ClosingCostItem:
    """One identified cash closing-cost component, in currency units."""

    cost_id: str
    amount: Decimal

    def __post_init__(self) -> None:
        if not isinstance(self.cost_id, str) or not self.cost_id or self.cost_id != self.cost_id.strip():
            raise InputValidationError("closing cost_id must be a nonblank, unpadded string")
        require_money(self.amount, "closing cost amount")


@dataclass(frozen=True)
class ClosingCostBudget:
    """Arrangement fee on an explicit base plus itemized fixed closing costs.

    The rate is a decimal fraction (0.0075 = 75 bps), not a percent display
    value. The base is explicitly supplied: collateral par, issued debt par
    and capital-structure reference size are different possible contract bases.
    Fees are posted once to cents; the total never depends on caller precision.
    """

    arrangement_fee_base: Decimal
    arrangement_fee_rate: Decimal
    fixed_costs: tuple[ClosingCostItem, ...] = ()

    def __post_init__(self) -> None:
        require_money(self.arrangement_fee_base, "arrangement_fee_base")
        require_decimal(self.arrangement_fee_rate, "arrangement_fee_rate", minimum=Decimal(0))
        if type(self.fixed_costs) is not tuple or any(not isinstance(row, ClosingCostItem) for row in self.fixed_costs):
            raise InputValidationError("fixed_costs must be an immutable tuple of ClosingCostItem")
        if len({row.cost_id for row in self.fixed_costs}) != len(self.fixed_costs):
            raise InputValidationError("Duplicate closing cost_id")
        if self.arrangement_fee_rate != 0 and self.arrangement_fee_base == 0:
            raise InputValidationError("A nonzero arrangement fee rate requires a positive explicit base")

    @property
    def arrangement_fee(self) -> Decimal:
        """Cash fee posted on the explicitly selected transaction base."""
        return post_currency(Fraction(self.arrangement_fee_base) * Fraction(self.arrangement_fee_rate))

    @property
    def other_upfront_costs(self) -> Decimal:
        return post_currency(sum((Fraction(row.amount) for row in self.fixed_costs), Fraction()))

    @property
    def total(self) -> Decimal:
        return post_currency(Fraction(self.arrangement_fee) + Fraction(self.other_upfront_costs))


@dataclass(frozen=True)
class AssetPurchase:
    """A held loan's acquisition costs, independent of its contractual par."""

    loan_id: str
    par: Decimal
    clean_price_pct: Decimal
    accrued_interest: Decimal = Decimal(0)

    def __post_init__(self) -> None:
        if not isinstance(self.loan_id, str) or not self.loan_id.strip():
            raise InputValidationError("Purchase loan_id is required")
        require_money(self.par, "purchase par", positive=True)
        require_decimal(self.clean_price_pct, "clean_price_pct", minimum=Decimal(0))
        require_money(self.accrued_interest, "acquired accrued interest")


@dataclass(frozen=True)
class DebtIssue:
    """Par and cash issue price, excluding subordinated reference nominal."""

    class_id: str
    par: Decimal
    issue_price_pct: Decimal

    def __post_init__(self) -> None:
        if not isinstance(self.class_id, str) or not self.class_id.strip():
            raise InputValidationError("Debt class_id is required")
        require_money(self.par, "debt par", positive=True)
        require_decimal(self.issue_price_pct, "issue_price_pct", minimum=Decimal(0))


@dataclass(frozen=True)
class SourcesUses:
    """Cent-posted closing funding; not a valuation or an equity IRR."""

    collateral_par: Decimal
    asset_clean_cost: Decimal
    acquired_accrued_interest: Decimal
    upfront_fees: Decimal
    cash_reserve: Decimal
    debt_par: Decimal
    debt_proceeds: Decimal
    equity_cash_funding: Decimal
    total_uses: Decimal
    total_sources: Decimal
    arrangement_fee: Decimal = Decimal(0)
    other_upfront_costs: Decimal = Decimal(0)
    other_initial_uses: Decimal = Decimal(0)
    other_initial_sources: Decimal = Decimal(0)


class FundingEngine:
    """Compute actual equity funding rather than par minus issued debt."""

    def calculate(
        self, purchases: Iterable[AssetPurchase], issues: Iterable[DebtIssue],
        *, upfront_fees: Decimal, cash_reserve: Decimal,
        other_initial_uses: Decimal = Decimal(0),
        other_initial_sources: Decimal = Decimal(0),
        other_initial_source_type: ClosingSourceType | None = None,
        closing_cost_budget: ClosingCostBudget | None = None,
    ) -> SourcesUses:
        """Freeze each input iterable once; post individual cash amounts to cents.

        Validation and aggregation both inspect the same immutable snapshot.
        Consuming a generator during validation must never silently turn later
        acquisition costs or debt proceeds into zero.
        """
        try:
            purchases, issues = tuple(purchases), tuple(issues)
        except TypeError as error:
            raise InputValidationError("purchases and issues must be iterable funding records") from error
        require_money(upfront_fees, "upfront_fees")
        require_money(cash_reserve, "cash_reserve")
        require_money(other_initial_uses, "other_initial_uses")
        require_money(other_initial_sources, "other_initial_sources")
        if other_initial_source_type is not None and not isinstance(other_initial_source_type, ClosingSourceType):
            raise InputValidationError("other_initial_source_type must be an explicit ClosingSourceType")
        if other_initial_sources != 0 and other_initial_source_type is None:
            raise InputValidationError("Nonzero other_initial_sources require explicit EXTERNAL_CONTRIBUTION classification")
        if closing_cost_budget is not None:
            if not isinstance(closing_cost_budget, ClosingCostBudget):
                raise InputValidationError("closing_cost_budget must be ClosingCostBudget")
            if upfront_fees != 0:
                raise InputValidationError("Use an itemized closing_cost_budget or aggregate upfront_fees; both would double count costs")
        if not purchases:
            raise InputValidationError("At least one asset purchase is required")
        if any(not isinstance(item, AssetPurchase) for item in purchases):
            raise InputValidationError("purchases must contain AssetPurchase")
        if any(not isinstance(item, DebtIssue) for item in issues):
            raise InputValidationError("issues must contain DebtIssue")
        if len({item.loan_id for item in purchases}) != len(purchases):
            raise InputValidationError("Duplicate purchase loan_id")
        if len({item.class_id for item in issues}) != len(issues):
            raise InputValidationError("Duplicate debt class_id")
        # Prices are posted per asset/issue. Aggregate posted cash as exact
        # fractions: precision inferred only from asset par cannot protect a
        # much larger accrued cost, fee, reserve or issue-proceeds amount.
        cost = sum((Fraction(post_currency(Fraction(item.par) * Fraction(item.clean_price_pct) / 100))
                    for item in purchases), Fraction())
        proceeds = sum((Fraction(post_currency(Fraction(item.par) * Fraction(item.issue_price_pct) / 100))
                        for item in issues), Fraction())
        accrued = sum((Fraction(item.accrued_interest) for item in purchases), Fraction())
        fees = Fraction(upfront_fees if closing_cost_budget is None else closing_cost_budget.total)
        uses = cost + accrued + fees + Fraction(cash_reserve) + Fraction(other_initial_uses)
        sources_before_equity = proceeds + Fraction(other_initial_sources)
        equity = uses - sources_before_equity
        if equity < 0:
            raise InputValidationError("Debt/contribution overfunding needs an explicit excess-cash use; negative equity funding is unsupported")
        return SourcesUses(
            collateral_par=post_currency(sum((Fraction(item.par) for item in purchases), Fraction())),
            asset_clean_cost=post_currency(cost), acquired_accrued_interest=post_currency(accrued),
            upfront_fees=post_currency(fees), cash_reserve=cash_reserve,
            debt_par=post_currency(sum((Fraction(item.par) for item in issues), Fraction())),
            debt_proceeds=post_currency(proceeds), equity_cash_funding=post_currency(equity),
            total_uses=post_currency(uses), total_sources=post_currency(sources_before_equity + equity),
            arrangement_fee=Decimal(0) if closing_cost_budget is None else closing_cost_budget.arrangement_fee,
            other_upfront_costs=Decimal(0) if closing_cost_budget is None else closing_cost_budget.other_upfront_costs,
            other_initial_uses=other_initial_uses, other_initial_sources=other_initial_sources,
        )
