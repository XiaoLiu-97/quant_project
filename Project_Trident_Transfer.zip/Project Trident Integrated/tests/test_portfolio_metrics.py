"""Independent recovery-weight and remaining-principal WAL controls."""

from dataclasses import replace
from datetime import date
from decimal import Decimal, Inexact, localcontext
from fractions import Fraction
import unittest

from trident.analysis import LimitDirection, LimitSpec, LimitStatus, MetricStatus, PortfolioAnalyzer
from trident.application.clo_services import TridentModelService
from trident.application.construction import ClosingPoolRedesignService
from trident.credit import PrepaymentEvent
from trident.domain.models import InputValidationError
from test_analysis import ASOF, exposure
from test_construction import FIRST, SECOND, fixture


D = Decimal


class RecoveryAnalyticsTests(unittest.TestCase):
    def test_recovery_hand_weights_and_subsets(self):
        a = exposure(par="70", recovery_rate=D(".8"), recovery_rate_source="USER_STRESS_INFRA")
        b = exposure("L2", "30", asset_class="BSL", recovery_rate=D(".4"), recovery_rate_source="USER_STRESS_BSL")
        report = PortfolioAnalyzer().analyze((a, b), ASOF,
            limits=(LimitSpec("MIN_RECOVERY", "WARR", D(".68"), LimitDirection.MINIMUM),))
        self.assertEqual(report.metric("WARR").value, D(".68"))
        self.assertEqual(report.metric("BSL_WARR").value, D(".4"))
        self.assertEqual(report.metric("INFRA_WARR").value, D(".8"))
        self.assertEqual(report.limits[0].status, LimitStatus.PASS)
        self.assertIn("USER_STRESS_INFRA", report.metric("WARR").message)

    def test_missing_recovery_never_reweights_known_assets(self):
        report = PortfolioAnalyzer().analyze((
            exposure(par="70", recovery_rate=D(".8"), recovery_rate_source="USER_SUPPLIED"),
            exposure("L2", "30", asset_class="BSL")), ASOF)
        metric = report.metric("WARR")
        self.assertEqual(metric.status, MetricStatus.INCOMPLETE)
        self.assertEqual(metric.coverage, D(".7"))
        self.assertIsNone(metric.value)

    def test_zero_recovery_is_observed_not_missing(self):
        report = PortfolioAnalyzer().analyze((exposure(recovery_rate=D(0), recovery_rate_source="STRESS_ZERO"),), ASOF)
        self.assertEqual(report.metric("WARR").value, D(0))
        self.assertEqual(report.metric("WARR").status, MetricStatus.AVAILABLE)

    def test_recovery_input_requires_bounded_fraction_and_provenance(self):
        for values in ({"recovery_rate": D("1.01"), "recovery_rate_source": "TEST"},
                       {"recovery_rate": D("-.01"), "recovery_rate_source": "TEST"},
                       {"recovery_rate": D(".4")}, {"recovery_rate_source": "TEST"},
                       {"recovery_rate": .4, "recovery_rate_source": "TEST"}):
            with self.subTest(values=values), self.assertRaises(InputValidationError):
                exposure(**values)

    def test_recovery_precision_and_limit_compare_are_context_independent(self):
        a = exposure(par="70", recovery_rate=D(".8"), recovery_rate_source="TEST")
        b = exposure("L2", "30", recovery_rate=D(".4"), recovery_rate_source="TEST")
        with localcontext() as caller:
            caller.prec = 3
            caller.traps[Inexact] = True
            report = PortfolioAnalyzer().analyze((a, b), ASOF)
        self.assertEqual(report.metric("WARR").value, D(".68"))


class RemainingWalTests(unittest.TestCase):
    def test_future_bullet_wal_and_phase_limit_now_compute(self):
        request = fixture(old_maturity=SECOND, new_maturity=SECOND,
            limits=(LimitSpec("FUTURE_WAL", "WAL_YEARS", D(1), phases=("REINVESTMENT",)),),
            reinvestment_end=date(2026, 5, 20))
        result = ClosingPoolRedesignService().run(request)
        self.assertTrue(result.validated, result.findings)
        report = result.target_result.portfolio_snapshots[0]
        self.assertEqual(report.metric("WAL_YEARS").status, MetricStatus.AVAILABLE)
        self.assertEqual(float(report.metric("WAL_YEARS").value), float(Fraction(91, 365)))
        self.assertEqual(report.limits[0].status, LimitStatus.PASS)

    def test_remaining_amortizing_wal_uses_held_par_and_excludes_settled_principal(self):
        from trident.domain.models import AmortizationType
        request = fixture(old_maturity=SECOND).baseline
        old = request.cashflow_request.positions[0]
        old = replace(old, terms=replace(old.terms, amortization_type=AmortizationType.LINEAR_INITIAL_PAR,
                                        amortization_fraction=D(".5")))
        request = replace(request, cashflow_request=replace(request.cashflow_request, positions=(old,)))
        result = TridentModelService().run(request)
        report = result.portfolio_snapshots[0]
        self.assertEqual(report.total_par, D(5000))
        self.assertEqual(float(report.metric("WAL_YEARS").value), float(Fraction(91, 365)))
        self.assertEqual(result.portfolio_snapshots[-1].total_par, D(0))
        self.assertIsNone(result.portfolio_snapshots[-1].metric("WAL_YEARS").value)

    def test_credit_future_exit_does_not_change_contractual_wal_before_exit(self):
        request = fixture(old_maturity=SECOND).baseline
        request = replace(request, credit_events=(PrepaymentEvent("OLD", date(2026, 5, 20)),))
        result = TridentModelService().run(request)
        first = result.portfolio_snapshots[0]
        self.assertEqual(float(first.metric("WAL_YEARS").value), float(Fraction(91, 365)))
        # The explanatory text distinguishes contractual remaining WAL from
        # scenario exits; the independent 91/365 answer above verifies the math.
        self.assertIn("future scenario defaults/prepayments excluded", first.metric("WAL_YEARS").message)
        self.assertEqual(result.portfolio_snapshots[-1].total_par, D(0))


if __name__ == "__main__":
    unittest.main()
