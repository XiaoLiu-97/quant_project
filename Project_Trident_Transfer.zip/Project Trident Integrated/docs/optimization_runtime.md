# Optimization 实测运行时间

静态LP/MILP及完整候选比较的合成实测日期为2026-10-07，原始证据见[optimization_runtime.json](validation/optimization_runtime.json)。2026-10-08已完成稳定模板与增量Excel writer优化，最新实测与文件验收见[writer_optimization.json](validation/writer_optimization.json)。金融引擎、输入和优化算法未改变。

## 先看结果

| 计算范围 | 规模 | 实测秒数 |
| --- | --- | ---: |
| LP 静态优化，含建模与独立复核 | 150 持仓 + 50 新 BUY 候选；100 条可执行报价 | 0.022 |
| LP 静态优化，含建模与独立复核 | 150 持仓 + 150 新 BUY 候选；200 条可执行报价 | 0.030 |
| MILP 静态优化，含建模与独立复核 | 150 持仓 + 50 新 BUY 候选；100 条可执行报价 | 0.034 |
| MILP 静态优化，含建模与独立复核 | 150 持仓 + 150 新 BUY 候选；200 条可执行报价 | 0.057 |
| 完整 CLO / equity IRR 比较，LP 生成候选 | 基准 + 2 个不同目标池；3 次实际完整投影 | 6.66 |
| 完整 CLO / equity IRR 比较，MILP 生成候选 | 基准 + 2 个不同目标池；3 次实际完整投影 | 6.42 |
| 完整 CLO / equity IRR 比较，LP 生成候选 | 基准 + 8 个不同目标池；9 次实际完整投影 | 19.56 |

静态优化每组测3次，表中为中位数；2-candidate完整比较各测2次；8-candidate仅测1次。全部静态重复均为 `OPTIMAL`、`validated=True` 且产生实际正交易量；完整比较的所有评估均 eligible，搜索均为 `COMPLETED`。MILP 与 LP 完整比较的少量差异属于本次运行波动，不能据此认为 MILP 通常更快。

300 个资产是 **150 个现有持仓 + 150 个新 BUY 候选**，对应 Asset Library 的300身份；不是300持仓再加300候选。报价计数包含50条 held SELL以及50/150条新 BUY。没有把300个预留空行作为资产计算。

## 测的是什么

复用当前 [性能测试 fixture](../scripts/benchmark_optimization.py) 和生产 `StaticTradeOptimizer`、`ClosingPoolSearchService`、`TridentModelService`。测试池为 EUR500m，150项持仓、100 Infra（EUR350m）和50 BSL（EUR150m），40个季度、6层债务；候选合同、分类、报价、评级观察和factor全部明确标为 synthetic。

LP 使用 HiGHS dual simplex。MILP 增加 EUR250k lots、EUR500k minimum ticket 和每笔 EUR100 fixed fee；预留 EUR10m 明确现金。约束覆盖固定 EUR500m target par、现金、obligor/country/sector集中度、BSL/Infra占比、整体/BSL测试factor、spread与gross BUY+SELL turnover。MILP保留默认 relative gap `1e-9`；每次HiGHS最多30秒，本次所有解均正常达到最优，没有靠 time-limit incumbent完成。

完整比较先生成候选，再重建各目标池的合同现金流、购买成本、funding、每期waterfall、coverage及equity XIRR，然后排名。2个候选的gross turnover cap为EUR150m/300m，使目标池不同；8个候选采用8个不同cap，实际执行9个不同完整投影。每次完整搜索使用新缓存，仅在同一次搜索内复用严格相同的完整请求。

这是一组简单合成性能基线：bullet合同、flat index 2.5%、零accrued、无信用事件、无synthetic reinvestment、零持续management fees，upfront fees为EUR1m；真实法律portfolio limits不由此fixture提供。扩展的额外BUY共享第一项BUY的sector/country，仍接受相同集中度约束。它不代表真实组合优化结果，也不代表复杂整数条件、bespoke schedules、credit stress或更多lifetime假设的最坏速度。静态LP/MILP优化的是factor/spread；equity IRR是通过完整候选replay比较，仅在该有限集合内选择最优。

NumPy/SciPy及optimize模块导入另测为 0.73 秒，随后第一次LP solve为 0.025 秒。此数不包含Python进程启动、Excel读取或写出。

## 当前工作簿与 Excel 时间

当前保存示例仍有150个持仓、3个完整cases，两个优化开关均Off，**可执行报价为0**。直接构建静态request只会返回 `NO_TRADE_CHECK`（约 0.005 秒），不能当作优化求解耗时；closing candidate request缺少snapshot identity，明确拒绝。本轮没有填造报价、评级、现金或修改真实mandate来绕过这个状态。

同一冻结输入、同一台电脑、串行运行，实际 `source=destination` 路径在独立TEMP副本计时：

| 阶段 | 优化前秒数 | 当前秒数 |
| --- | ---: | ---: |
| Excel输入读取 | 11.25 | 10.24 |
| 完整金融计算，3cases；优化Off | 10.13 | 9.17 |
| Python写出Excel package | 60.94 | 25.67 |
| 总计 | 82.31 | 45.08 |

每组1次，写出减少57.9%，总计减少45.2%。读取与计算变化属于运行波动，没有声称金融算法加速。另一个独立新目的地对比为write53.81→27.95秒、total74.27→47.74秒，使用优化过程中的writer；最终版验收与上表按实际原路径覆盖为准。全部源为同一150held/3case/40quarter输入，input fingerprint `a97eb377ae5cf8d4ce443c5acf3546072542385482bdee996931d8e68de99b47`，三cases的IRR/MOIC完全相同，每期cash残差为零。

独立reader回读、约105万physical cell比较、nativeExcel打开/计算/保存重开及最终cache adoption均不计入这些时间。18inputTables/83,703owning cells、198Tables、109,611formula cells、8charts与MarketData完整核对，只有运行UTC和softwareversionmetadata变化。表中没有开启优化，不能与合成solver时间直接相加，声称已测真实optimizationOn的完整运行。实际报价和mandate配置后应重新计时。

## 如何重复计时

在本项目自己的venv中使用现有benchmark fixture。以下示例仅运行当前完整search，不做缓存策略历史对比：

```python
from scripts.benchmark_optimization import benchmark_request, _search_measurement

request = benchmark_request(integer=False, variants=2, distinct_targets=True)
measurement = _search_measurement(request)
print(measurement)
```

`integer=True` 测MILP；`variants=8` 测8个不同目标池。静态规模使用同一文件中的 `_expanded_static(request.base_mandate, 100/200)` 并调用 `StaticTradeOptimizer.solve`；每次必须确认 `validated`、solver method、实际交易及失败原因。需要真正测Excel完整运行时，使用TEMP目的地和相同source hash，并分开记录read / calculate / write，避免改动真实持仓或输入。

计时依赖本机、后台负载、文件缓存与输入复杂度，不是固定速度承诺。此次 Python 3.12.14、NumPy 2.3.5、SciPy 1.18.1、openpyxl 3.1.5，全部顺序运行，没有并行性能测试。

## Excel 写出为什么慢，以及展示公式的用途

进一步读取当前文件并进行只诊断的cProfile，确认工作簿含109,611个公式单元格，其中Asset Cashflows为69,056、隐藏_Results为22,930、CLO Analysis为12,331、Waterfall为2,640。它们主要用INDEX/MATCH/IFERROR按照已保存的case、tranche、period等选择展示结果。贷款应计、违约/提前还款/回收、waterfall分配、IC/OC判定、diversion、IRR和优化由Python完成；Excel还进行少量展示汇总、单位转换和状态/图表计算，因此不能说Excel完全没有算术。

约6.29MB的xlsx解压后有88.62MB、251个package parts，包含约105万个物理cell节点（不是105万个不同金融指标）。_Results约47.36MB、Asset Cashflows约27.70MB。文件大小与内部处理量不同。

优化前的cProfile显示：主要开销是XML/单元格处理和重复parse，不是金融公式在Excel中运算。该诊断的非重叠阶段约为init/index21%、83次Table更新39%、最终serialize/validate/ZIP30%、其余10%；profile本身write93.67秒带instrumentation，不能替代普通运行计时。原始[writer_profile.json](validation/writer_profile.json)属于其绑定的源码快照，其调用次数不代表当前writer。

当前writer采用以下处理：

- 保留已解析的DOM和owner/cell索引，raw XML变动时按bytes/revision同步失效；对已有单元格先比较语义，避免构造大量相同节点。
- 相同展示公式保留定义与扩展；cache改变时刷新结果，公式或payload改变时清除过期value metadata。
- 一次决定实际记录和最终Table容量；容量内保留ref/name/style，仅真正增长时索引周围notes并检查保护边界。缩短结果清空旧尾部。
- Source首次完整验证，最终仍检查全体当前DOM的关系/names/schema/公式和输入保护；合法序列化后对临时ZIP逐项核对内容、metadata及CRC，减少重复XML解析。
- 原路径覆盖前及原子发布前均核对载入的source未被修改；不同既有目的地独立验证。冲突/失败保留原完整输出。

金融值、case records、freshness witness和运行metadata仍更新；xlsx仍需XML序列化与压缩，图表旧cache失效后Excel重算展示。Excel保留少量展示汇总/单位转换。详细安全边界与流程见[架构](architecture.md#稳定模板与增量写出)及[流程图](calculation_flowcharts.md)。本轮没有新增包、改变金融假设或启用动态lifetime optimization。
