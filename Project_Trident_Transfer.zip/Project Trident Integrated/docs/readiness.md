# 验证、可用范围与验收

软件 **0.12.3**、用户界面 schema **1.0** 已完成 **SUPPORTED_GENERIC_PROFILE** 验收及发布。结论适用于已测试的 Closing、受支持 payment-boundary opening、完整 what-if、静态优化、standalone asset workflow及明确的synthetic reinvestment。具体交易的法律映射、agency calibration与trustee reconciliation仍按实际资料核验。

稳定入口 [Project_Trident.xlsx](../outputs/Project_Trident.xlsx) 已替换为本轮验证文件；保留15个用户页、2个隐藏支持页、198个Tables、514个names及8个native charts。SHA-256：

```text
eba243c79afd6e0531990b410131c747aad36339a2b5f3ada40cc6ba1d4784ed
```

本轮证据：[完整回归](validation/current.json)、[waterfall修复及发布](validation/waterfall_repair.json)、[整体界面验收](validation/interface_formatting.json)。金融修复包含买前/拟买后 STOP coverage veto、买后即时本金gate估值及实际出售后的collateral credit更新；格式修复没有新增金融假设或改写用户业务输入；修正结算日期的显示后，正常writer同步刷新其日期身份、fingerprint及freshness记录。[17页中文流程图](../outputs/Project_Trident_Waterfall_Flowcharts_CN.pdf)与[方法说明](waterfall_review.md)覆盖default/prepayment/recovery、fees/incentive、IC/OC、cure/diversion、reinvestment和deleverage。

本次颜色补充检查修复 assumptions 的继承白色、Coverage/diversion 的另一套配色，以及三个长表有效记录/预留区的底色差异。此前26个代表视图没有覆盖全部长表分区，不能证明这些配色一致。本次按整表核验原生 Excel 实际颜色，详情见[颜色验收](validation/interface_palette.json)。金融计算、输入、公式及缓存未变，未重复执行完整金融suite。

理解计算先读[中文waterfall指南](waterfall_guide_cn.md)。本次文档重做已完成17页视觉与源码对照、独立示例核算、链接及文件保护检查，见[文档验收](validation/waterfall_guide_cn.json)。未修改金融代码或工作簿，未重新执行完整金融suite。

## 本轮实际验证

| 范围 | 证据 | 含义与限制 |
| --- | --- | --- |
| 完整Python回归 | **1,797项全部通过，零failure/error/skip** | 99个package源文件、116个test/input文件及完整日志独立hash复核；运行前后source/tests一致；44个input owners的83,712个原始输入cell payload核对未变 |
| 独立已知答案 | 19项acquisition/valuation修复测试＋9项展示单位/日期/保护测试 | 全部纳入完整suite；不是只看headline IRR或cash residual |
| 完整金融等价性 | 同一模型两次独立运行，格式前后typed request及financial results逐字段精确相等 | 三个完整case、claims/cashflows/coverage/limits/economics及library reference全部核对；只排除独立uuid运行标识，不舍入金融数值 |
| 整体模板样式 | 样式阶段17页raw payload一致；原始输入、names/Table definitions及Market Data粘贴区保留 | 初次30项样式/布局操作及视觉复核修正均按named owners定位；Market Data仅更新A2只读说明，优化流程说明按实际功能更新 |
| 重复应用及定向保护 | style数量及CF容器不增长，自定义非状态CF保留 | 日期、单位及既有各行字体/颜色/边框在writer重新运行后保留 |
| Native Excel及交互 | 39286项检查通过，正常打开、保存重开，零非预期error/repair | 17页、198Tables、6161个代表cell、三个42期case、日期、tranche/scope、预留dropdown、真实状态颜色及freshness；详情见界面记录 |
| 渲染视觉复核 | 26个视图：15个用户页、8个隐藏/预留区域及3个额外图表区域 | 检查列宽/行高/换行、数值与日期格式、单位、表头、图表及导航；修正实测问题后复查 |
| 最终缓存与发布保护 | 匹配公式/chart identity后采用native caches；來源hash guard及最终复核 | 原始package拥有公式、styles、names、Tables和Market Data；成功后原子发布，不以Excel整本resave替代输入保护 |

用户最近保存将 Original pool credit overlay设为On；本轮保留这一输入，原池CDR2%、CPR0%、Recovery60%、lag6个月，Reinvestment仍No。当前150资产、三个完整case均COMPLETED、**42期**。BASELINE IRR **3.2916419919%**、MOIC **1.21309717214**；A_MARGIN_150 IRR **2.6729853277%**，SENIOR_FEE_20 IRR **2.8842180857%**。这些是当前假设下的模型结果，不能用此前另一输入snapshot的收益替代。

三个case的default exposure均€54,683,311.04、recoveries€32,809,983.18、recognized loss€21,873,327.86；原池CPR0%，prepayment为0；Reinvestment No，synthetic purchases为0。完整金融等价性证明覆盖真实当前输入；启用再投资的独立已知答案及下述冻结variant补充覆盖购买路径。

冻结的150资产/40期只读enabled-reinvestment variant仍保留其特定输入与hash：12笔购买、cash€96,899,394.41、face€97,878,176.17，synthetic prepay€31,543,972.04、default€6,303,457.56、recovery€3,782,074.47、loss€2,521,383.09，全部cash residual0。该验证scenario不是当前42期用户输入，也未写回用户假设，不代表真实成交或agency认证。

仅明确注册chart series中不适用点的NA()可以作为chart gap；真实lookup/error不获豁免。格式与颜色不代替金融或法律节点验证。

## 其他支持范围及冻结证据

以下记录保留其各自输入、源码、日志及文件hash，用于追溯已经核验的独立profiles；它们不是本轮源码或当前文件的发布绑定。当前完整回归使用current.json，本轮验证文件、修复及最终发布状态使用waterfall_repair.json。

| 冻结记录 | 相关支持范围与限制 |
| --- | --- |
| [writer_optimization.json](validation/writer_optimization.json) | 稳定模板、增量输出、并发保护及Current-template Existing/Asset-only流水线；记录的150项定向测试和native检查属于该冻结源码，不替代本轮1,797项回归 |
| [capacity.json](validation/capacity.json) | 204项容量/reader/writer/credit相关测试；空行、live dropdown、witness、扩容碰撞、旧结果清理；保留其native QA和source hashes |
| [runtime.json](validation/runtime.json) | Closing三个完整cases、150个资产、4,316条held和4,316条library reference cashflows、40期；cash/face/claims及匹配package的独立核验 |
| [native_excel.json](validation/native_excel.json) | 对应冻结Closing文件的case/date/tranche/scope/metric、隐藏数据、names/Tables及图表原生核对，保留明确注册chart gaps |
| [existing_clo.json](validation/existing_clo.json) | 合成双贷款opening流水线，3m sourced current equity mark、八种账户/designation、四类fee claims、retained debt claims及8个未来period；不是任意真实existing deal的认证 |
| [asset_only.json](validation/asset_only.json) | 独立合同现金流、无CLO/股权回报、清空历史Waterfall/account；完整reader/writer与原生Excel检查 |
| [cache_adoption.json](validation/cache_adoption.json) | 对应冻结源文件的108,711个formula caches及8charts/28caches；当前修复文件的匹配cache及保留证明在waterfall_repair.json |
| [preservation.json](validation/preservation.json) | 用户授权保留的独立原项目文件hash不变、当前项目无外部旧路径运行依赖；当前部署重建自身环境 |
| [environment.json](validation/environment.json) | 本项目Python 3.12.14、Excel adapter、HiGHS LP/MILP小型已知答案及安装probe；环境可用不等于所有交易定义正确 |

已有opening专项20项已知答案/边界、8项显示金融语义及5个asset-only smoke profiles继续受当前完整回归覆盖。Opening未来fees/coupons/coverage和带whole equity mark/source的现有face resizing保留claims/accounts/permissions、BESPOKE/seasoned cents；不适用NOTE/CLO修改明确拒绝，不静默忽略。

## 性能记录的适用范围

[writer_optimization.json](validation/writer_optimization.json)的冻结匹配计时为同150资产/三个完整cases/40期、static optimizer和candidate search均Off：write **60.94→25.67秒**，total **82.31→45.08秒**，每组仅一次；独立QA、native Excel及cache adoption不计入。这些是此前writer优化时的测量，**不是本轮waterfall修复重新测得的速度**。当前probe计时另存修复记录，仍不作为复杂real-deal性能承诺。更多说明见[运行时间](optimization_runtime.md)与[Table容量](table_capacity.md)。

## 已验证的金融及传输条件

1. Closing Sources & Uses等额；asset identity、current par、currency和sourced fixing一致。完整cases从同一BASELINE独立建立。
2. Opening保留8组账户/designation、4类fee claims、每个retained debt claim及original payment/fixing anchors。不重购持仓、不重发债务、不重复历史setup cash。
3. Actual cash、performing/defaulted par、debt face、coupon/fee claims分别守恒。Contractual reference与credit collections分开，不推测terminal cash。
4. 完整Waterfall按actual future date和原period ID显示due/paid/arrears/principal/PIK，保留真正执行的GATE、POST_DIVERSION和PERIOD_END。BLOCKED、NOT_CONFIGURED、NOT_APPLICABLE及missing data具有明确含义。
5. Synthetic STOP核验买前与拟买后generic coverage，提交后principal gate即时使用新valuation。ALWAYS是显式coverage/unpaid-coupon override，不能绕过资金/日期/final、禁止long-dated或asset-level classification guards。
6. PURCHASE_GATE、POST_PURCHASE_GATE及PRINCIPAL_GATE是内部决策，不是新增Excel可选report stage。Reinvestment cash为0可能是prospective veto，即使可见GATE和PERIOD_END均PASS；当前界面没有单独保存purchase rejection reason。
7. Existing resize必须有完整positive equity value/source；unsupported ADD/REMOVE、零face清仓或receipt-claim重绑明确失败。Static proposal不执行交易；closing return candidate完成full replay后才进入validated ranking。
8. 单一input owners、Market Data布局及native资源保留；variable outputs不覆盖相邻input/Table。Software version、execution profile、input identity、UTC、case/scope和return basis与结果保存，selectors仅过滤saved results。

本轮保留用户最新保存输入并完成重算；其fingerprint：

```text
496a300309413d4ce7e803fb4f6a67d2717118863f535e41f04779adfc5a1bfe
```

## 首个可用范围与明确边界

支持Closing和受支持payment-boundary Existing state的lifetime cashflow、analysis、structuring/what-if，静态优化及明确synthetic reinvestment assumptions。动态lifetime trading optimization不属于当前必要范围。Existing静态BUY/SELL proposal没有完整settlement cash、ownership、claims/fixings及whole equity mark时，不执行projected trade IRR replay。

Asset Cashflows模式仅计算资产合同与组合观察。关闭不适用NOTE/CLO/control scenarios、static optimizer和candidate search；已支持ASSET edits可独立重算。核心return为UNAVAILABLE并说明CLO projection未选择；界面显示n.a.，不补造零回报。

Synthetic TEST factors与agency WARF分别标识；missing rating/recovery保留coverage和unavailable status。中途liability opening、缺历史incentive hurdle、positive defaulted opening inventory、未结算real trade ownership、完整deal-specific eligibility及trustee benchmark仍有明确profile边界。金融数学、交易条款和经济假设分开记录；测试证明所覆盖路径的实现，真实交易应按executed terms和对应日期agent/trustee records核对。
