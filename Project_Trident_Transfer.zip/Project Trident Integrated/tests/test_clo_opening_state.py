"""Small independent controls for seeded, original-grid CLO projections.

The opening accounts here are supplied observations, not generated historical
outputs. In particular a pending eligibility transfer is not a second receipt,
and original-period numbering is part of the financial reporting contract.
"""

import unittest
from dataclasses import FrozenInstanceError, replace
from datetime import date, datetime
from decimal import Decimal

from trident.cashflows.engine import ContractualCashflowEngine
from trident.clo.engine import DeterministicCloEngine, _NoteState
from trident.clo.models import (
    CashAccountAccrualMode, CloNoteCouponClaim, CloOpeningState, CloRunRequest,
    CloTerms, CoverageStatus, NoteTranche, ProjectionStatus,
)
from trident.conventions import (
    AccrualDateBasis, AccrualPeriod, BusinessDayConvention, DayCount,
)
from trident.credit.engine import CreditEventCashflowEngine
from trident.credit.models import PrepaymentEvent
from trident.domain.models import (
    CouponType, InputValidationError, LoanCashflow, LoanPosition, LoanTerms,
)
from trident.market import FlatRateProvider


D = Decimal
ORIGINAL = date(2026, 1, 1)
OPEN = date(2026, 4, 1)
JULY = date(2026, 7, 1)
OCTOBER = date(2026, 10, 1)
SOURCE = "Independently supplied post-distribution trustee balances"


def opening(as_of=OPEN, **changes):
    return replace(CloOpeningState(
        as_of, D(0), D(0), D(0), (CloNoteCouponClaim("A", D(0)),), SOURCE,
    ), **changes)


def terms(final=JULY, **changes):
    return CloTerms(
        ORIGINAL, final,
        business_day_convention=BusinessDayConvention.UNADJUSTED,
        accrual_date_basis=AccrualDateBasis.UNADJUSTED,
        fixing_lag_business_days=0, **changes,
    )


def note(par="80", rate="0.06", **changes):
    return NoteTranche("A", 1, D(par), CouponType.FIXED,
                       fixed_rate=D(rate), day_count=DayCount.ACT_360, **changes)


def receipt(number, start, end, principal="0", interest="0"):
    """Hand cash and face movements isolate the CLO from asset math helpers."""
    repayment, coupon = D(principal), D(interest)
    return LoanCashflow(
        "L", "EUR", number, start, end, start, end, end, None,
        D(100), None, D(0), D(0), D("0.25"), coupon, coupon,
        repayment, D(100) - repayment, repayment + coupon,
    )


def project(rows, *, state=None, deal=None, debt=None):
    request = CloRunRequest(rows, D(100), (debt or note(),), deal or terms(),
                           opening_state=state)
    return DeterministicCloEngine(FlatRateProvider({"EURIBOR_3M": D("0.025")})).run(request)


class CloOpeningStateCoreTests(unittest.TestCase):
    def test_explicit_zero_issue_date_state_preserves_the_entire_baseline(self):
        rows = (receipt(1, ORIGINAL, OPEN, interest="3.00"),
                receipt(2, OPEN, JULY, principal="100", interest="3.03"))
        ordinary = project(rows)
        seeded = project(rows, state=opening(ORIGINAL))
        # 90 and91 ACT/360 days imply note coupons1.20 and1.21. An
        # explicitly verified all-zero opening changes no closing cash flows.
        self.assertEqual(seeded, ordinary)
        self.assertEqual(ordinary.total_equity_distributions, D("23.62"))
        self.assertEqual(ordinary.first_projected_period_number, 1)
        self.assertEqual(tuple(row.period_number for row in ordinary.periods), (1, 2))

    def test_pending_opening_cash_waits_for_a_later_determination_then_releases_once(self):
        state = opening(pending_interest_cash=D("0.05"),
                        pending_principal_cash=D(2),
                        pending_original_principal_reinvestment_cash=D(2))
        result = project(
            (receipt(1, OPEN, JULY, principal="100", interest="3.03"),),
            state=state, deal=terms(OCTOBER, collection_cutoff_business_days=100,
                                    continue_after_coupon_shortfall=True),
        )
        first, final = result.periods
        # The July determination date precedes Apr1. Both the known opening
        # pending balances and actual July receipts remain physically pending.
        self.assertEqual(first.eligible_asset_interest, D(0))
        self.assertEqual(first.eligible_asset_principal, D(0))
        self.assertEqual((first.pending_interest_cash, first.pending_principal_cash),
                         (D("3.08"), D(102)))
        self.assertEqual(first.note_coupon_unpaid, D("1.21"))
        # Legal final releases105.08 of physical sources in total, never
        # creates another receipt. Note coupons1.21+1.23 and face80 leave22.64.
        self.assertEqual((final.received_asset_interest, final.received_asset_principal),
                         (D(0), D(0)))
        self.assertEqual((final.eligible_asset_interest, final.eligible_asset_principal),
                         (D("3.08"), D(102)))
        self.assertEqual(result.total_equity_distributions, D("22.64"))
        self.assertEqual(result.status, ProjectionStatus.COMPLETED)
        self.assertEqual(result.first_projected_period_number, 2)
        self.assertEqual(tuple(row.period_number for row in result.periods), (2, 3))
        self.assertTrue(all(row.cash_conservation_residual == 0 for row in result.periods))

    def test_opening_physical_cash_earns_forward_interest_without_remunerating_reserve(self):
        state = opening(principal_cash=D(10), interest_cash=D(5), reserve=D(7),
                        pending_principal_cash=D(2), pending_interest_cash=D(3))
        result = project(
            (receipt(1, OPEN, JULY, principal="100"),), state=state,
            debt=note(rate="0"),
            deal=terms(cash_account_accrual_mode=CashAccountAccrualMode.FIXED_SIMPLE,
                       cash_account_fixed_rate=D("0.12")),
        )
        period, = result.periods
        # Eligible15 plus pending5 are physical cash for91 days. Reserve7
        # earns nothing under this explicit profile; maturity cash arrives on
        # Jul1 and earns no earlier interest. 20*.12*91/360 posts0.61 once.
        self.assertEqual(period.cash_account_interest, D("0.61"))
        self.assertEqual(result.total_cash_account_interest, D("0.61"))
        self.assertEqual(result.total_equity_distributions, D("47.61"))
        self.assertEqual(period.cash_conservation_residual, D(0))

    def test_forward_prepayment_uses_opening_asset_time_axis_and_original_note_period(self):
        loan = LoanTerms(
            "L", "EUR", OPEN, JULY, D(100), CouponType.FIXED,
            fixed_rate=D("0.12"), day_count=DayCount.ACT_360,
            business_day_convention=BusinessDayConvention.UNADJUSTED,
            accrual_date_basis=AccrualDateBasis.UNADJUSTED,
            fixing_lag_business_days=0,
        )
        position = LoanPosition(loan, OPEN, D(100))
        provider = FlatRateProvider({"EURIBOR_3M": D("0.025")})
        rows = ContractualCashflowEngine(provider).generate(position)
        credit = CreditEventCashflowEngine(provider).apply(
            position, rows, PrepaymentEvent("L", date(2026, 6, 1)),
        )
        result = DeterministicCloEngine(provider).run(CloRunRequest(
            rows, D(100), (note(),), terms(),
            asset_credit_projections=(credit,), opening_state=opening(),
        ))
        period, = result.periods
        # The collateral accrues61 days before its June prepayment. The note
        # still accrues its original91-day Apr-Jul period, which remains#2.
        self.assertEqual(period.period_number, 2)
        self.assertEqual(period.received_asset_interest, D("2.03"))
        self.assertEqual(period.prepayment_principal_received, D(100))
        self.assertEqual(period.note_coupon_due, D("1.21"))
        self.assertEqual(result.total_equity_distributions, D("20.82"))
        self.assertEqual(period.closing_collateral_par, D(0))
        self.assertEqual(period.cash_conservation_residual, D(0))

    def test_zero_face_live_coupon_does_not_hide_ic_when_oc_excludes_the_claim(self):
        # This directly tests the financial node shared by issuance and
        # opening-state projections. Excluding a coupon claim from OC does
        # not discharge the5 of still-payable IC debt service.
        debt = note(par="0", rate="0", interest_deferrable=True,
                    oc_minimum=D("1.2"), ic_minimum=D("1.5"))
        period = AccrualPeriod(2, OPEN, JULY, OPEN, JULY, JULY, OPEN)
        test = DeterministicCloEngine._coverage(
            [_NoteState(debt, D(0), D(5))], 0, period, "HAND_CONTROL",
            D(100), D(0), D(1), (D(5),),
            unpaid_coupon_claims=[D(5)], include_deferred_interest=False,
        )
        self.assertEqual(test.oc_status, CoverageStatus.NOT_APPLICABLE)
        self.assertEqual(test.ic_denominator, D(5))
        self.assertEqual(test.ic_ratio, D("0.2"))
        self.assertEqual(test.ic_status, CoverageStatus.FAIL)

    def test_zero_issued_face_requires_explicit_existing_state(self):
        rows = (receipt(1, ORIGINAL, OPEN, principal="100"),)
        with self.assertRaisesRegex(InputValidationError, "positive issued face"):
            CloRunRequest(rows, D(100), (note(par="0", rate="0"),), terms())
        # The same retained class is a valid inactive existing-state record.
        result = project(rows, state=opening(ORIGINAL), debt=note(par="0", rate="0"))
        self.assertEqual(result.final_debt_par, D(0))
        self.assertEqual(result.total_equity_distributions, D(100))

    def test_state_money_identity_dates_and_immutability_fail_closed(self):
        bad_changes = (
            {"as_of_date": datetime(2026, 4, 1)}, {"source": " "},
            {"principal_cash": D("NaN")}, {"reserve": D("Infinity")},
            {"interest_cash": D("0.001")}, {"expense_arrears": D(-1)},
            {"note_coupon_claims": [CloNoteCouponClaim("A", D(0))]},
            {"note_coupon_claims": (CloNoteCouponClaim("A", D(0)),) * 2},
        )
        for change in bad_changes:
            with self.subTest(change=change), self.assertRaises(InputValidationError):
                opening(**change)
        with self.assertRaises(FrozenInstanceError):
            opening().reserve = D(1)

    def test_reinvestment_designations_are_subsets_of_physical_cash_not_extra_cash(self):
        state = opening(principal_cash=D(7), original_principal_reinvestment_cash=D(5),
                        held_diversion_principal=D(2), pending_principal_cash=D(3),
                        pending_original_principal_reinvestment_cash=D(3))
        self.assertEqual(state.principal_cash, D(7))
        for changes in ({"principal_cash": D("6.99")},
                        {"pending_principal_cash": D("2.99")}):
            with self.subTest(changes=changes), self.assertRaises(InputValidationError):
                replace(state, **changes)


if __name__ == "__main__":
    unittest.main()
