"""Prepayment ownership and activation through the compact named interface.

These cases keep the annual hazard assumptions separate from contractual
repayment. Independent Decimal arithmetic supplies the expected CPR posting;
the ordinary reader and model service must transport the actual receipt into
the same account records used by the visible Waterfall.
"""
from datetime import date
from decimal import Decimal, localcontext
from types import SimpleNamespace
import unittest

from trident.adapters.interface_inputs import NamedWorkbook, read_interface_inputs
from trident.adapters.interface_reporting import PREFIX, case_tables
from trident.application.clo_services import TridentModelService
from trident.adapters.legacy_model_records import RECURRING_COMPONENTS
from trident.credit.overlay import project_fractional_period
from test_interface_inputs import _cell, workbook_fixture

D = Decimal


def set_assumption(workbook, field, value):
    """Locate the financial owner by its semantic name, never a fixed address."""
    sheet, (left, top, right, bottom) = NamedWorkbook(workbook).region(
        "trident_ui_" + field
    )
    if (left, top) != (right, bottom):
        raise AssertionError("An assumption owner must be a scalar")
    sheet.cell(top, left).value = value


def annual_cpr_amount(par, rate, start, end):
    """Independent high-precision known answer for this ACT/365F model policy."""
    with localcontext() as context:
        context.prec = 70
        probability = 1 - (1 - rate) ** (D((end - start).days) / D(365))
        return (par * probability).quantize(D(".01"))


def inputs_for(*, overlay="Off", original_cpr="0", reinvestment="No",
               reinvestment_cpr=".10", amortizing=False):
    workbook = workbook_fixture()
    for field, value in (
        ("credit_prepayment_overlay", overlay),
        ("original_collateral_cpr", D(original_cpr)),
        ("original_annual_default_rate", D(0)),
        ("reinvestment_enabled", reinvestment),
        ("reinvestment_annual_prepayment_rate", D(reinvestment_cpr)),
        ("reinvestment_annual_default_rate", D(0)),
    ):
        set_assumption(workbook, field, value)
    if reinvestment == "Yes":
        # Scale the hand-sized fee-free study independently of the default
        # large-deal fee assumptions. A zero determination lag makes same-day
        # receipts eligible; its first purchase gate must also be solvent.
        set_assumption(workbook, "determination_lag", 0)
        for field in (*RECURRING_COMPONENTS,
                      "senior_management_fee", "subordinated_management_fee",
                      "expected_senior_expenses_variable"):
            set_assumption(workbook, field, D(0))
    if amortizing:
        _cell(workbook, "asset_terms", "Principal strategy").value = "LINEAR_AMOUNT"
        _cell(workbook, "asset_details", "Scheduled principal").value = 1250000
    return read_interface_inputs(workbook)


class InterfacePrepaymentTests(unittest.TestCase):
    def test_original_and_reinvestment_cpr_have_distinct_named_owners(self):
        inputs = inputs_for(overlay="On", original_cpr=".10", reinvestment_cpr=".70")
        terms = inputs.request.clo_terms
        self.assertTrue(terms.original_pool_overlay.enabled)
        self.assertEqual(terms.original_pool_overlay.annual_prepayment_rate, D(".10"))
        self.assertEqual(terms.synthetic_reinvestment_policy.annual_prepayment_rate, D(".70"))
        self.assertFalse(terms.synthetic_reinvestment_policy.enabled)

    def test_disabled_original_overlay_does_not_apply_entered_cpr(self):
        result = TridentModelService().run(
            inputs_for(original_cpr=".10").request
        )
        self.assertTrue(all(p.prepayment_principal_received == 0 for p in result.clo.periods))
        self.assertTrue(all(p.newly_defaulted_par == 0 for p in result.clo.periods))
        self.assertTrue(all(p.cash_conservation_residual == 0 for p in result.clo.periods))

    def test_enabled_original_cpr_reaches_waterfall_backing_records(self):
        inputs = inputs_for(overlay="On", original_cpr=".10")
        result = TridentModelService().run(inputs.request)
        first = result.clo.periods[0]
        start = inputs.request.cashflow_request.positions[0].par_as_of_date
        # Two independently posted EUR10m bullet loans have no scheduled
        # principal at the first date. Round each asset before aggregation.
        expected = 2 * annual_cpr_amount(D(10000000), D(".10"), start, first.payment_date)
        self.assertEqual(first.scheduled_principal_received, D(0))
        self.assertEqual(first.prepayment_principal_received, expected)
        self.assertGreater(expected, 0)
        tables, audit = case_tables(
            SimpleNamespace(request=inputs.request, result=result), inputs
        )
        accounts = tables[PREFIX + "view_accounts"]
        self.assertEqual(accounts[0]["prepayment_principal_received"], expected)
        self.assertEqual(
            tables[PREFIX + "account_records"][0]["prepayment_principal_received"],
            expected,
        )
        self.assertTrue(all(p.cash_conservation_residual == 0 for p in result.clo.periods))

    def test_disabled_nonzero_cpr_inputs_are_disclosed_without_activation(self):
        inputs = inputs_for(original_cpr=".10", reinvestment_cpr=".70")
        warnings = "\n".join(inputs.warnings)
        self.assertIn("Original Collateral CPR is nonzero", warnings)
        self.assertIn("original-pool CPR assumption is inactive", warnings)
        self.assertIn("belongs only to synthetic reinvestment assets", warnings)
        self.assertFalse(inputs.request.clo_terms.original_pool_overlay.enabled)
        self.assertFalse(inputs.request.clo_terms.synthetic_reinvestment_policy.enabled)

    def test_asset_only_mode_does_not_emit_unused_clo_cpr_warnings(self):
        workbook = workbook_fixture()
        workbook["Home"]["D7"] = "Asset Cashflows"
        set_assumption(workbook, "original_collateral_cpr", D(".10"))
        set_assumption(workbook, "reinvestment_annual_prepayment_rate", D(".70"))
        inputs = read_interface_inputs(workbook)
        self.assertIsNone(inputs.request.clo_terms)
        warnings = "\n".join(inputs.warnings)
        self.assertNotIn("Original Collateral CPR is nonzero", warnings)
        self.assertNotIn("belongs only to synthetic reinvestment assets", warnings)

    def test_active_reinvestment_does_not_display_disabled_cohort_warning(self):
        inputs = inputs_for(reinvestment="Yes", amortizing=True)
        self.assertNotIn("belongs only to synthetic reinvestment assets", "\n".join(inputs.warnings))

    def test_cpr_acts_after_default_and_scheduled_principal(self):
        # Face100 - default10 =90; contractual20% amortization =18;
        # CPR applies to remaining72, rather than initial100 or survivor90.
        start, end = date(2026, 1, 20), date(2026, 4, 20)
        projected = project_fractional_period(
            opening_par=D(100), contractual_opening_par=D(100),
            contractual_interest=D(5), contractual_principal=D(20),
            default_amount=D(10), prepayment_rate=D(".10"),
            start_date=start, end_date=end,
        )
        expected = annual_cpr_amount(D(72), D(".10"), start, end)
        self.assertEqual(projected.default_par, D(10))
        self.assertEqual(projected.scheduled_principal, D(18))
        self.assertEqual(projected.prepayment_principal, expected)
        self.assertEqual(projected.cash_interest, D("4.50"))
        self.assertEqual(projected.closing_par, D(72) - expected)

    def test_reinvestment_cpr_cannot_change_original_loans_when_disabled(self):
        inputs = inputs_for(
            original_cpr="0", reinvestment="No", reinvestment_cpr=".70",
            amortizing=True,
        )
        result = TridentModelService().run(inputs.request)
        self.assertEqual(result.clo.periods[0].scheduled_principal_received, D(1250000))
        self.assertTrue(all(p.prepayment_principal_received == 0 for p in result.clo.periods))
        self.assertEqual(result.clo.reinvestment_purchases, ())

    def test_reinvestment_cpr_starts_only_after_a_funded_cohort_purchase(self):
        inputs = inputs_for(
            original_cpr="0", reinvestment="Yes", reinvestment_cpr=".50",
            amortizing=True,
        )
        result = TridentModelService().run(inputs.request)
        first, second = result.clo.periods[:2]
        self.assertGreater(first.reinvestment_cash_used, 0)
        self.assertEqual(first.prepayment_principal_received, 0)
        self.assertTrue(result.clo.reinvestment_purchases)
        purchase = result.clo.reinvestment_purchases[0]
        expected = annual_cpr_amount(
            purchase.acquired_par, D(".50"), first.payment_date, second.payment_date
        )
        self.assertEqual(second.prepayment_principal_received, expected)
        self.assertTrue(all(p.cash_conservation_residual == 0 for p in result.clo.periods))

    def test_full_original_cpr_exits_remaining_face_without_double_redemption(self):
        result = TridentModelService().run(
            inputs_for(overlay="On", original_cpr="1").request
        )
        first = result.clo.periods[0]
        self.assertEqual(first.prepayment_principal_received, D(20000000))
        self.assertEqual(first.closing_collateral_par, D(0))
        self.assertEqual(first.cash_conservation_residual, D(0))
        self.assertTrue(all(p.prepayment_principal_received == 0 for p in result.clo.periods[1:]))

    def test_zero_original_cpr_remains_zero_when_overlay_is_enabled(self):
        result = TridentModelService().run(
            inputs_for(overlay="On", original_cpr="0", reinvestment_cpr=".10").request
        )
        self.assertTrue(all(p.prepayment_principal_received == 0 for p in result.clo.periods))
        self.assertTrue(all(p.cash_conservation_residual == 0 for p in result.clo.periods))


if __name__ == "__main__":
    unittest.main()

