# Portfolio analysis与investor return方法

Dated native coupons使用与cashflow engine相同的CouponStepPolicy时间轴：WAS统计snapshot date有效raw floating margin，WAC统计有效fixed annual coupon，分别按各自coupon population的performing par加权。Actual-date step当日生效，deferred step须等原payment/reset boundary；不能用包含未来step的full-period平均利率。特别检查TARGET initial adjustment holiday gap中尚未开始的boundary，禁止提前应用deferred step。原持仓在ordinary/credit/overlay及synthetic组合中更新，synthetic与imported sources保持自身语义。独立测试见`tests/test_dated_coupon_analytics.py`，政策和day-count边界见 [dated steps](conventions.md#dated-fixed-coupon--floating-spread-steps)。

更新：2026-10-05。Generic analytics不是目标deal的全部legal/agency tests；完整分母、来源、状态和units必须与结果一起读。真实WARF/WARR需要适用rating/recovery method及lineage；synthetic test factor单独报告。

**独立事件观察日历。** `LimitSpec`仍是snapshot limit。完整模型及candidate replay现在检查post-event closing、原CLO payment dates、真正生效的coupon changes、实际performing-par changes（scheduled principal、default/prepayment、imported桥接、synthetic purchase及其par）和reinvestment phase boundary。每个日期取全部同日源事件后的状态；deferred steps使用原payment/reset starts。Recovery应收、现金与reserve不增加performing par；纯付息、零par变化及no-op coupon replacement不额外增加日期。

`TridentModelRequest.portfolio_observation_dates`允许immutable tuple的额外date，例如经确认的determination/月报日期；去重排序，范围为新设CLO的closing或存续CLO的opening as-of，至实际最后投影付款日（含两端），非法类型及越界日期拒绝。Excel的`Observation Dates` Table提供有source的额外日期；这些日期和自动事件日期会显示在Portfolio Analysis、Concentrations和Limit Tests，并进入候选拒绝检查。Opening API保留pre-event准入报告；Excel显示post-event opening状态。付款日API为同一报告流的子集，每期仍核对实际CLO par。

这是finite/end-of-day检查，不自动确定法律measurement dates，不检查同日每笔交易的前后状态，也不证明continuous compliance。额外报告不创造waterfall period或OC/IC distribution gate。时间本身影响WAL等指标，契约指定日期仍须明确输入。参考[ADS CLO 2公开indenture](https://www.sec.gov/Archives/edgar/data/1837532/000119312525179805/d949401dex102.htm)的Measurement Date和Collateral Quality Tests定义，监测可能涉及purchase、determination及monthly report日期，部分投资规则允许maintain/improve；这仅支持分离观察与付款日期的设计理由，是美国交易示例，不能替代目标EUR交易条款。

## 已核对的金融口径

### 名义到期与已知实际本金收款之间

非工作日名义到期可能早于合法adjusted receipt。Native holding scanner仅在已验证future principal reference证明一个完整final receipt时传入`ScheduledMaturityReceipt`：loan ID、currency、nominal boundary、全部当前held par、strict future receipt和zero ending par均须匹配。没有证据、partial/重复/错误日期或错误币种仍拒绝。公共API只能验证receipt证据与提交的cashflow reference一致；它没有Calendar/BDC metadata，调用者须独立确认实际收款日的合同依据。Native路径从已验证合同schedule取得日期。此桥接不处理真实逾期欠款、seasoned开账、payment lag应收或未知settlement，不建立额外现金，也不自动default。

该间隔保留实际held par和raw WAS/WAC。WAL可按实际future principal日期计算；`WEIGHTED_AVERAGE_MATURITY_YEARS`标为UNAVAILABLE并说明nominal remaining maturity未定义，相应required limit也UNAVAILABLE。不能把负名义remaining years算成通过，也不静默把原maturity改成receipt date。例：两笔各100，下一日及29日收本金，WAL为15/365年；300bps和200bps的WAS为250bps。原contractual accrual和native long-dated分类不变。[Disney公开信贷协议§2.13(c)](https://www.sec.gov/Archives/edgar/data/1744489/000119312524057958/d759203dex102.htm)提供非工作日付款调整的原始例证；调整与延长期计息须分别按目标合同确认，不能从该例自动套用。

### 生命周期与质量测试

Opening 为 CLOSING；正常期间为 REINVESTMENT / POST_REINVESTMENT。`application/portfolio_phases.py` 只将最后完全结清的快照标为 TERMINATED：引擎 COMPLETED/terminal available、资产/默认 claims/债务/现金/reserve/pending receipts/费用与 coupon 欠款全零，且引擎已检查未来活动。Native、imported 和 overlay snapshots 共用该判断。零 performing par 本身不满足条件。

七项 CLO Controls 自动质量限制仅适用于 active phases，TERMINATED 为 NOT_APPLICABLE；空池指标仍 UNAVAILABLE。用户 Portfolio Limits 的 phases 保持原样，blank 表示所有阶段，也会在 TERMINATED 执行；需要限 active lifecycle 时填 `CLOSING,REINVESTMENT,POST_REINVESTMENT`。这不是 covenant pass 或所有契约的统一终止约定，实际 deal profile 必须确认 applicability。参见 [优化方法](optimization.md#终止阶段的质量测试适用范围)。

| 范围 | 核对结论 |
|---|---|
| 金额及精度 | Domain 拒绝 binary float、NaN、infinity；现金与本金输入要求 cent precision；金额计算保持 `Fraction` 至最终 HALF_UP posting；含正负半分边界、指数移动 bps conversion、floor-before-margin 和调用者低精度 context 的独立回归。34-digit 显示值不作为精确 limit 比较依据。 |
| 日期和 day count | ACT/360、ACT/365F、ACT/ACT ISDA 分开；30E/360 Eurobond、Bond Basis、US February-EOM 分开。Feb 28→Mar 31 的 Eurobond 32/360 与 US-EOM 30/360 不混用。ISDA 30E/360 的 maturity exception 不被声称已支持。 |
| Schedule / fixing | Anchored schedule 不因 February clipping 或 business-day adjustment 漂移；payment、accrual、fixing 有明确不同语义。TARGET 与 Weekends Only 是显式配置。Euribor 历史 fixing 必须精确提供，未来 term scenario 不冒充历史；现有通用 loan 支持的 tenor / reset、dual stub、payment-lag amortisation 限制均明确报错。 |
| Principal policies | Coupon 在同日还本之前按 opening par 计算。Bespoke schedule 总额必须等于实际 held par；其他 scheduled / accelerated / annuity 政策保持本金守恒，显式 balloon 与 negative amortisation 边界不被静默 sweep / capitalise。Annuity 为 projected level-payment policy，不声称是每笔 floating loan 的实际 recast 条款。 |
| 曲线 / collection account | Term fixing、monthly projected buckets 与 OIS zero curve 分开。Cash projection 按 DF(start)/DF(end) 的实际持有区间 forward earnings，spread 与 floor 使用独立 account DCF；不能把 zero node 当 receipt-date deposit rate。历史实际 overnight compounding 仍要求观测数据，不能用 forward curve 替代。 |
| WAS / WAC | 两种 coupon 群体使用独立本金分母。Missing coupon type 不默认合规；floating 缺 spread / fixed 缺 coupon 时不重新加权已知资产。当前数值为简单 par-weighted analytics，不等于某份 indenture 的 excess-coupon、floor benefit、discount-adjusted spread / target-par 法律测试。 |
| WAL / WAM | 通用 `WAL_YEARS` 使用未来 scheduled principal payment timing、ACT/365F，逐资产还本总额须对到 snapshot par；缺部分本金投影不发布被低估的 WAL。`WEIGHTED_AVERAGE_MATURITY_YEARS` 是另一项指标。交易或 agency monitor 的 eligible assets、逐日期 rounding / maturity-based 定义必须另选实际条款，不能静默把两者互换。 |
| WARF / WARR | Direct factors 要 system/version；synthetic factors 单独标识。Missing factors / recoveries 保留完整分母，零 recovery 是有效观测。WARR 为明确来源的 recovery 假设平均值，不能仅凭一个 source 字符串声称为 rating-stress recovery calibration；不同 agency 的 eligible pool、评级映射、stress level 和 rounding 仍需真正的交易方法配置。 |
| Concentration / limits | 同一 obligor 多笔合并，unknown metadata 留在 full par；largest concentration / selected bucket 的未知数据不变成合规零。Inclusive equality 与 max/min direction 按精确分数判断，phase 不适用与 unavailable 分开。多货币组合没有隐式 FX。 |
| Investor returns | XNPV/XIRR 为 actual days /365、年化 effective rate；同日 netting 精确；MOIC 对 gross contributions/distributions 分别累计，含后续追加出资。Multiple-sign-change IRR 返回 ambiguity，不隐式挑选有利 root；fractional exponent / root solver 的有限数值精度与支持域明确披露。 |
| Closing funding | Acquisition clean cost 与 acquired accrued 分开；逐资产 / debt issue 先 posting 再聚合；equity 用真实 funding cash，不以 reference nominal 替代；itemised / aggregate fees 互斥，未建模 future claim 不可藏在 other sources。 |

## 原始参考与适用范围

以下原始来源于2026-10-05核查；取得正文与访问限制分别登记。引用证明对应定义或说明差异，不代表 Project Trident 已复制某笔交易的所有条款或获得 agency certification。

- [SEC 2024 CLO indenture](https://www.sec.gov/Archives/edgar/data/1702510/000170251024000079/indenture-clo2024x1.htm)：定义分别给出 fixed coupon 与 floating spread，且存在 transaction-specific excess / denominator adjustments；同一文件还区分 contractual scheduled-principal WAL 与 S&P maturity-based monitor life，并规定相应 eligibility / rounding。此次修复分开 coupon populations；法律条款差异保留为显式限制。
- [EMMI Euribor methodology 目录](https://www.emmi-benchmarks.eu/benchmarks/euribor/methodology/)：当前目录列 D0016G-2019、2026-06-29；benchmark 的计算方法变动不应被误称为自定义 projected monthly curve。[已可读取的 D0016E PDF](https://www.emmi-benchmarks.eu/globalassets/documents/pdf/euribor/d0016e-2019-final_benchmark-determination-methodology-for-euribor.pdf) 提供欧元 money-market convention；它是历史版本，不声称已取得 G 全文。
- [ECB 2026–2028 holidays](https://www.ecb.europa.eu/ecb/contacts/working-hours/html/index.en.html)：只将标注 TARGET closing 的日期与 weekends 用于 TARGET calendar，不把其他 ECB office holidays 或 substitute Mondays 填入。
- [ECB compounded €STR rules](https://www.ecb.europa.eu/stats/euro-short-term-rates/interest_rate_benchmarks/WG_euro_risk-free_rates/shared/pdf/ecb.Compounded_euro_short-term_rate_calculation_rules.sv.pdf)：实际 compounded averages 使用历史 daily observations，ACT/360 与 nonbusiness calendar-day carry；这与目前 projected DF-forward assumption 不同。
- [Microsoft XIRR](https://support.microsoft.com/en-us/excel/functions/xirr-function)：actual dates /365 与 positive/negative cashflows 定义及已知答案；Trident 的 ambiguity policy 比 Excel 的 guess-based root selection 更保守。
- [FpML 对 2006 ISDA day-count 编码的说明](https://www.fpml.org/ticket/317/)：30E/360 与 30E/360 ISDA 明确区分。现有 [ISDA 原始 day-count reference](https://www.isda.org/a/HAxgE/ISDA-Response-to-ROC-CDEv3-Consultation-103122.pdf) 此前direct open返回403；搜索结果仍可核到 ACT/ACT ISDA 年份分配定义，不能把它记成已取得完整 PDF。

### 公开已知答案：XIRR

Microsoft 的 XIRR 使用实际日期、365 天指数，并求解 XNPV 为零。其公开案例可作为独立 reference fixture：[Microsoft XIRR](https://support.microsoft.com/en-us/excel/functions/xirr-function)。

| 日期 | 投资者现金流 |
| --- | ---: |
| 2008-01-01 | -10,000 |
| 2008-03-01 | 2,750 |
| 2008-10-30 | 4,250 |
| 2009-02-15 | 3,250 |
| 2009-04-01 | 2,750 |

官方 reference rate 为 **0.373362535**。该案例已加入独立测试：相对官方展示值采用 `1e-8` 的 rate 容差，并另行要求 Decimal XNPV 绝对残差小于 `1e-6`。直接求解得到约 `0.3733625335188`，与官方展示值相差约 `1.5e-9`；展示参考值不能替代残差核验。Microsoft 的另一独立案例在9%折现率下给出 XNPV **2,086.65**，也已用于验证。[Microsoft XNPV](https://support.microsoft.com/en-us/excel/functions/xnpv-function)

实现先按日期精确聚合，使用实际天数/365，通过 `log(1+r)` 变量的区间二分求根，并以独立 Decimal XNPV 检查结果。多个净现金流符号变化可能存在多根；当前明确返回 `AMBIGUOUS`，不会用默认 guess 选择一个好看的 IRR。空输入、单一符号、同日净额为零返回 `UNAVAILABLE`；数值范围或残差检查失败返回 `NUMERIC_FAILURE`。专项测试覆盖负 IRR、闰日、同日聚合、非法日期及 caller Decimal context。XNPV 的排序约定及 MOIC 的 gross contribution/distribution 口径见当前returns实现；不能把不同 IRR convention 的结果仅因名字相同就直接比较。

## 分析指标与legal tests的区别

WAS/WAC使用各自coupon population，whole-pool spread仅是`ALL_ASSET_SPREAD_BPS` diagnostic，不是legal WAS。

当前 `WAL_YEARS` 使用完整未来本金支付日，计算 `Σ[principal × actual_days/365] / held_par`，不先把年数舍入。每笔贷款的未来本金必须与 snapshot par 对齐；缺少完整偿本、缺失字段或空分母明确报告，不能发布低估的 WAL 或把已知子集重新归一化。`WEIGHTED_AVERAGE_MATURITY_YEARS` 是另一个指标，不能替代摊还本金 WAL。

真实 CLO 条款可以指定不同资产范围、年数舍入和测试时点。例如 **OWL ROCK CLO X，2023-03-09 indenture，第68–69页**，定义 WAL 时排除 Defaulted Obligations，并把各笔本金回收的年数舍入至0.01年。这证明本金支付权重有原始条款依据，同时说明当前未舍入 ACT/365F **分析 WAL 不能自动等同于每宗 CLO 的法律 WAL test**；取得目标交易条款后须单独配置并验证。[SEC 原始 indenture](https://www.sec.gov/Archives/edgar/data/1655888/000119312523069106/d363501dex101.htm)

全部held par的spread加权值仅为 `ALL_ASSET_SPREAD_BPS`，WAS/WAC 见 V07-AN01。BSL/INFRA 分组因子使用各自完整 subset par。任何 asset_class 缺失时，无法确认分组分母，该分组指标不可用。缺失评级因子显示 coverage，不把已知因子重新归一化。真实 WARF 只接受同一 versioned methodology 的输入；合成 fixture 的 `TEST_FACTOR_AVERAGE` 及 `BSL_TEST_FACTOR_AVERAGE` 是独立测试指标，实际 agency WARF 仍 unavailable。

Limit equality 通过；比较使用精确 Fraction，展示值的34位 Decimal 舍入不能改变 breach 状态。Limits 明确区分 `PASS`、`BREACH`、`UNAVAILABLE` 和 `NOT_APPLICABLE`；phase 不适用不能冒充通过。当前一般组合指标是分析口径，尚未复制目标交易的 rating notching、WAS adjustment、default exclusions 等法律定义。

### 组合指标假设与方法

| ID | 值 / 单位 / 范围 | 来源、影响及验证 |
| --- | --- | --- |
| V05-AN01 | Snapshot WAL：remaining contractual principal，actual payment dates，snapshot中的actual held performing assets；years ACT/365F | 已有完整未来principal ledger，不猜maturity bullet；snapshot日及之前付款排除。独立bullet91/365年、amortization剩余50%、future prepayment仍为contractreference；实际信用退出后loan不再held。空池UNAVAILABLE |
| V05-AN02 | Generic WARR：全performing par denominator，explicit recovery_rate fraction0–1及source；BSL/Infra各自子池 | 全数据才AVAILABLE，缺失为INCOMPLETE/UNAVAILABLE，不能重加权knownsubset；70par×80%＋30par×40%=68%，观察值0有效。非agencyprofile、无production参数默认 |
| V05-AN03 | Generic WAL / WARR不施加indenture-specific eligibility、default category或rounding | OCP交易给出不同legal/agency-specific metric口径，必须另建metric policy；当前结果不可直接冒充所有法律tests或rating methodologies |

[OCP Euro CLO 2017-1 2026 Offering Circular](https://ise-prodnr-eu-west-1-data-integration.s3-eu-west-1.amazonaws.com/202601/07d64e17-e59d-4980-b089-0096b0ee4bc1.pdf) printed p347（PDF index361）用scheduledprincipal加权并规定两层舍入和default/deferring排除；printed p338（index352）S&P-specific life以maturity计算。Printed p339（index353）与p345（index359）分别规定S&P/Fitch recovery metric的不同舍入。这支持显式metric policy设计，不支持用某一笔交易的规则作为通用默认。

## Closing what-if的经济身份


`ScenarioRunner`以immutable baseline为唯一起点；每个scenario是closing inputs的**绝对替换**，不会继承前一个scenario的改动。Asset可改existing par/clean price/coupon/reference及all-in bounds/maturity；note可改existing par/issue price/coupon/floor/IC/OC；control可改fees/reserve/legal final。所有scenario重新计算funding、现金流、组合、瀑布和dated investor returns。同资产的reference/all-in collar按最终pair原子校验；WAS仍使用raw spread，不把cap后的coupon反推为spread。Scenario Edits不提供effective-date交易、新增/删除资产、call/credit/rate编辑；baseline既有explicit credit events可以沿用。所以完整重跑是独立closing模型对比，不证明一笔reinvestment trade已经验算。

经济身份必须同步：note par同时修改opening balance和发行par；reserve同时修改funding use与CLO reserve；asset par同时修改holding/exposure/purchase par及proportionate contract/reference amounts、balloon和acquired accrued。这是固定合同占比的holding resize假设，不是新贷款条款。Bespoke金额按largest remainders分配cent（同余数按早日期），保留原日期并精确加总至new held par，复杂度O(n log n)。不满足原始领域约束或maturity/explicit schedule关联的编辑仍报错，不能自动重写合同。

Comparison保存baseline/scenario value、status、unit及message。数字只有两侧`AVAILABLE`才计算delta；IRR unavailable/ambiguous不当0，法律gate状态另存。Period outputs按**actual payment date + class + metric**做outer join，不按period number强行对齐；缺失一侧为`NOT_PRESENT`而非0。Delta是结果差值，不是严格因果归因；改变closing funding本身会影响IRR，不能只比较distribution而遗漏初始实缴。Case-insensitive scenario ID须唯一，`BASELINE`保留、重复字段编辑拒绝；任一invalid scenario整批失败，由Excel调用方完整计算后atomic save，避免混合新旧结果。

当前接口和实际已验证范围见 [用户指南](../user_guide.md) / [审查记录](../readiness.md)。
