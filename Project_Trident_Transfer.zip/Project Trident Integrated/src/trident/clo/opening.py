"""Restrict an existing CLO opening to a verified original payment boundary.

The original legal schedule remains authoritative. Selecting its future tail
must not manufacture a new stub, reset a liability period, or replace original
fee bases with today's smaller pool. Unsupported historical state rejects
before cash is allocated, rather than being silently initialized to zero.
"""

from trident.conventions.calendar import BusinessCalendar
from trident.conventions.schedule import AccrualPeriod, ScheduleBuilder
from trident.domain.models import InputValidationError

from .models import CloRunRequest, ManagementFeeBasis


def select_opening_periods(request: CloRunRequest, calendar: BusinessCalendar) -> tuple[tuple[AccrualPeriod, ...], tuple[AccrualPeriod, ...]]:
    """Return the full original grid and its unchanged future period objects.

    A payment-date snapshot is taken AFTER that entire distribution. It may
    therefore exclude every original period paying on that date. The next
    original accrual boundary must be the snapshot date: an unadjusted accrual
    schedule paying later/earlier needs additional intra-period liability
    ownership and principal history, which this boundary-only profile lacks.
    """
    terms = request.terms
    full = ScheduleBuilder(calendar).build(
        terms.closing_date, terms.legal_final_date, terms.frequency_months,
        terms.business_day_convention, terms.accrual_date_basis,
        terms.fixing_lag_business_days, 0, terms.end_of_month, terms.stub_convention,
        first_payment_date=terms.first_payment_date_unadjusted,
        last_regular_payment_date=terms.last_regular_date_unadjusted,
    )
    opening = request.opening_state
    if opening is None:
        return full, full
    asof = opening.as_of_date
    if asof != terms.closing_date and asof not in {period.payment_date for period in full}:
        raise InputValidationError("Existing CLO opening must be a post-distribution original actual payment boundary; mid-period openings are unsupported")
    future = tuple(period for period in full if period.payment_date > asof)
    if not future or future[0].accrual_start != asof:
        raise InputValidationError("Existing CLO opening payment boundary must also equal the next original liability accrual start; business-day accrual gaps require another opening profile")
    if request.imported_collateral is not None:
        raise InputValidationError("Existing CLO opening currently requires identified native performing collateral; imported opening inventory is unsupported")
    if terms.incentive_fee_enabled:
        raise InputValidationError("Existing CLO opening cannot initialize an investor incentive hurdle without its historical hurdle balance")
    for prefix in ("refinancing", "optional_call"):
        if getattr(terms, f"{prefix}_enabled") and getattr(terms, f"{prefix}_date") <= asof:
            raise InputValidationError(f"Existing CLO opening cannot replay historical {prefix}; provide already effective current terms and disable the past event")
    if (opening.held_diversion_principal and (not terms.interest_diversion_test_enabled
            or asof > terms.interest_diversion_test_end_date)):
        raise InputValidationError("Opening held IDT principal requires an active explicit IDT designation window")
    if (terms.management_fee_basis is ManagementFeeBasis.INITIAL_COLLATERAL_PAR
            and asof > terms.closing_date and opening.initial_collateral_par is None):
        raise InputValidationError("INITIAL_COLLATERAL_PAR fees require verified original initial collateral par, not the current opening pool")
    return full, future
