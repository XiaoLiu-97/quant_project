"""Independent cent-account controls for explicit coupon proceeds routing.

The raw receipts are hand supplied. No test rebuilds borrower accrued history
from a settlement cost: ownership and principal classification are independent
verified inputs, and the compiler only relabels cash that already exists.
"""

import unittest
from dataclasses import FrozenInstanceError, dataclass, replace
from datetime import date, datetime
from decimal import Decimal, Inexact, ROUND_DOWN, localcontext
from fractions import Fraction

from trident.clo import (
    CloRunRequest, CloTerms, CouponProceedsAllocation, PrincipalAccruedBalance,
    classify_coupon_proceeds,
)
from trident.clo.models import DefaultedAssetOcTreatment, NoteTranche
from trident.clo.reinvestment import SyntheticReinvestmentPolicy
from trident.conventions import AccrualDateBasis, BusinessDayConvention
from trident.credit.engine import CreditEventCashflowEngine
from trident.credit.models import AssetCashSource, AssetCollection, DefaultEvent, PrepaymentEvent
from trident.credit.overlay import OriginalPoolOverlay
from trident.domain.models import CouponType, InputValidationError, LoanCashflow, LoanPosition, LoanTerms
from trident.market import FlatRateProvider


D = Decimal
OPEN = date(2026, 4, 1)
PAY = date(2026, 7, 1)
FINAL = date(2026, 10, 1)
SCHEDULED = AssetCashSource.SCHEDULED
PREPAYMENT = AssetCashSource.PREPAYMENT
BALANCE_SOURCE = "Trustee verified remaining principal-funded accrued balance"
ALLOCATION_SOURCE = "Verified receipt account instruction"
LEGAL_REFERENCE = "Approved transaction Principal Financed Accrued Interest definition"


@dataclass(frozen=True)
class RawReceipt:
    loan_id: str
    payment_date: date
    cash_interest: Decimal
    principal_repayment: Decimal
    source: AssetCashSource


def raw(coupon="3.03", principal="0", *, loan="L", day=PAY, source=SCHEDULED):
    return RawReceipt(loan, day, D(coupon), D(principal), source)


def balance(amount="1.47", *, loan="L", **changes):
    return replace(PrincipalAccruedBalance(loan, OPEN, D(amount), BALANCE_SOURCE,
                                          LEGAL_REFERENCE), **changes)


def allocation(amount="1.47", *, loan="L", permitted=False, **changes):
    return replace(CouponProceedsAllocation(
        "RESTORE:" + loan, loan, PAY, SCHEDULED, D(amount), permitted,
        ALLOCATION_SOURCE, LEGAL_REFERENCE,
    ), **changes)


def classify(receipts, *, balances=None, allocations=None):
    return classify_coupon_proceeds(
        receipts, (balance(),) if balances is None else balances,
        (allocation(),) if allocations is None else allocations, as_of_date=OPEN,
    )


def contract(loan="L"):
    # A hand future coupon1 and complete100 face receipt isolate input guards.
    return LoanCashflow(
        loan, "EUR", 1, OPEN, PAY, OPEN, PAY, PAY, None,
        D(100), None, D(0), D(0), D("0.25"), D(3), D(3),
        D(100), D(0), D(103),
    )


def request(*, deal=None, rows=None, **changes):
    terms = deal or CloTerms(OPEN, FINAL,
        business_day_convention=BusinessDayConvention.UNADJUSTED,
        accrual_date_basis=AccrualDateBasis.UNADJUSTED, fixing_lag_business_days=0)
    note = NoteTranche("A", 1, D(80), CouponType.FIXED, fixed_rate=D("0.06"))
    return CloRunRequest(
        (contract(),) if rows is None else rows, D(100), (note,), terms,
        principal_accrued_balances=(balance(),),
        coupon_proceeds_allocations=(allocation(),), **changes,
    )


class CouponProceedsCompilerTests(unittest.TestCase):
    def test_principal_target_and_interest_residual_conserve_the_original_receipt(self):
        receipts = (raw(principal="100"),)
        result = classify(receipts)
        audit, = result.audit_rows
        # Gross borrower coupon3.03 already includes its verified ownership.
        # Restore1.47 to principal; leave1.56 as interest. The original100
        # face repayment remains100, while principal ACCOUNT proceeds101.47.
        self.assertEqual(result.restored_by_index, (D("1.47"),))
        self.assertEqual(result.permission_by_index, (D(0),))
        self.assertEqual(audit.raw_coupon_cash, D("3.03"))
        self.assertEqual(audit.raw_principal_cash, D(100))
        self.assertEqual(audit.interest_proceeds, D("1.56"))
        self.assertEqual(audit.principal_proceeds, D("101.47"))
        self.assertEqual(audit.remaining_principal_accrued, D(0))
        self.assertEqual(audit.interest_proceeds + audit.principal_proceeds, D("103.03"))
        self.assertEqual(receipts[0].principal_repayment, D(100))
        self.assertEqual((audit.balance_source, audit.allocation_source, audit.legal_reference),
                         (BALANCE_SOURCE, ALLOCATION_SOURCE, LEGAL_REFERENCE))

    def test_grouped_physical_coupon_splits_markers_only_inside_its_raw_component_rows(self):
        receipts = (raw("0.50", "100"), raw("99", loan="UNRELATED"), raw("1.03"))
        result = classify(receipts, allocations=(allocation(permitted=True),))
        # One physical loan coupon1.53 consists of two raw components. The
        # unrelated99 may not fund restoration; stable index markers0.50/.97
        # add exactly1.47 without changing either source row or its face.
        self.assertEqual(result.restored_by_index, (D("0.50"), D(0), D("0.97")))
        self.assertEqual(result.permission_by_index, result.restored_by_index)
        audit, = result.audit_rows
        self.assertEqual(audit.receipt_rows, 2)
        self.assertEqual(audit.raw_coupon_cash, D("1.53"))
        self.assertEqual(audit.interest_proceeds, D("0.06"))
        self.assertEqual(audit.principal_proceeds, D("101.47"))
        self.assertEqual(audit.original_principal_permission, D("1.47"))
        with self.assertRaises(FrozenInstanceError):
            audit.receipt_rows = 3

    def test_whole_coupon_restoration_preserves_a_subcent_rounding_residual(self):
        # The borrower has already posted one gross34-cent coupon. Routing a
        # supplied34-cent principal target must not separately manufacture a
        # further1-cent interest receipt by reposting an accrued factor.
        result = classify((raw("0.34"),), balances=(balance("0.34"),),
                          allocations=(allocation("0.34"),))
        self.assertEqual(result.audit_rows[0].interest_proceeds, D(0))
        self.assertEqual(result.audit_rows[0].principal_proceeds, D("0.34"))

    def test_prepayment_receipt_is_explicit_and_uses_its_actual_source_and_date(self):
        day = date(2026, 6, 1)
        result = classify((raw("2.03", "100", day=day, source=PREPAYMENT),),
                          allocations=(allocation(payment_date=day, collection_source=PREPAYMENT),))
        self.assertEqual(result.audit_rows[0].interest_proceeds, D("0.56"))
        self.assertEqual(result.audit_rows[0].principal_proceeds, D("101.47"))
        self.assertEqual(result.audit_rows[0].collection_source, PREPAYMENT)

    def test_disabled_profile_returns_aligned_zero_markers_without_audit_or_mutation(self):
        receipts = (raw(), raw(day=FINAL), raw(loan="SECOND"))
        result = classify(receipts, balances=(), allocations=())
        self.assertEqual(result.restored_by_index, (D(0),) * 3)
        self.assertEqual(result.permission_by_index, (D(0),) * 3)
        self.assertEqual(result.audit_rows, ())
        self.assertEqual(classify((), balances=(), allocations=()).restored_by_index, ())

    def test_earlier_zero_coupon_cannot_be_selected_but_does_not_pay_the_claim(self):
        prior = date(2026, 5, 1)
        rows = (raw("0", day=prior), raw())
        result = classify(rows)
        self.assertEqual(result.restored_by_index, (D(0), D("1.47")))
        with self.assertRaisesRegex(InputValidationError, "first positive"):
            classify(rows, allocations=(allocation(payment_date=prior),))
        with self.assertRaisesRegex(InputValidationError, "no positive"):
            classify((raw("0"),))

    def test_insufficient_first_coupon_never_spends_another_loan_or_a_later_coupon(self):
        rows = (raw("1"), raw("100", loan="OTHER"), raw("100", day=FINAL))
        with self.assertRaisesRegex(InputValidationError, "insufficient"):
            classify(rows)
        with self.assertRaisesRegex(InputValidationError, "first positive"):
            classify(rows, allocations=(allocation(payment_date=FINAL),))

    def test_same_day_two_positive_sources_are_ambiguous_even_when_dates_match(self):
        rows = (raw(), raw("2", "100", source=PREPAYMENT))
        with self.assertRaisesRegex(InputValidationError, "ambiguous"):
            classify(rows)
        # Same-day prepayment with no coupon is not a second positive coupon;
        # its principal does not augment the scheduled coupon cash capacity.
        result = classify((raw(), raw("0", "100", source=PREPAYMENT)))
        self.assertEqual(result.restored_by_index, (D("1.47"), D(0)))

    def test_orphan_wrong_source_and_unknown_claim_loan_reject(self):
        for rows, instructions in (
            ((raw(loan="OTHER"),), (allocation(),)),
            ((raw(source=PREPAYMENT),), (allocation(),)),
            ((), (allocation(),)),
        ):
            with self.subTest(rows=rows), self.assertRaises(InputValidationError):
                classify(rows, allocations=instructions)

    def test_huge_cent_targets_and_low_precision_traps_preserve_complete_cents(self):
        huge = "1234567890123456789012345678901234567890.47"
        coupon = "1234567890123456789012345678901234567891.50"
        with localcontext() as context:
            context.prec = 3
            context.rounding = ROUND_DOWN
            context.traps[Inexact] = True
            result = classify((raw(coupon, "1000000000000000000000000.01"),),
                              balances=(balance(huge),), allocations=(allocation(huge),))
        audit, = result.audit_rows
        self.assertEqual(audit.interest_proceeds, D("1.03"))
        self.assertEqual(result.restored_by_index, (D(huge),))
        self.assertEqual(Fraction(audit.interest_proceeds) + Fraction(audit.principal_proceeds),
                         Fraction(D(coupon)) + Fraction(D("1000000000000000000000000.01")))

    def test_multiple_loan_audits_are_deterministic_without_reordering_raw_receipts(self):
        receipts = (raw("5", loan="Z"), raw("3.03", loan="A"))
        result = classify(receipts, balances=(balance(loan="Z"), balance(loan="A")),
                          allocations=(allocation(loan="Z"), allocation(loan="A")))
        self.assertEqual(tuple(row.loan_id for row in result.audit_rows), ("A", "Z"))
        self.assertEqual(result.restored_by_index, (D("1.47"), D("1.47")))
        self.assertEqual(tuple(row.loan_id for row in receipts), ("Z", "A"))


class CouponProceedsInputValidationTests(unittest.TestCase):
    def test_cash_identity_provenance_and_typed_flags_are_strict(self):
        for change in ({"amount": D(0)}, {"amount": D(-1)}, {"amount": D("0.001")},
                       {"amount": D("NaN")}, {"source": " "}, {"legal_reference": ""},
                       {"loan_id": " L"}, {"as_of_date": datetime(2026, 4, 1)}):
            with self.subTest(change=change), self.assertRaises(InputValidationError):
                balance(**change)
        for change in ({"principal_amount": D(0)}, {"principal_amount": D("Infinity")},
                       {"collection_source": "SCHEDULED"},
                       {"collection_source": AssetCashSource.RECOVERY},
                       {"original_principal_permission": 1}, {"source": ""},
                       {"legal_reference": " "}, {"allocation_id": "RESTORE: L "}):
            with self.subTest(change=change), self.assertRaises(InputValidationError):
                allocation(**change)

    def test_balance_and_instruction_require_one_matching_full_amount_per_loan(self):
        invalid = (
            ((balance(),), ()), ((), (allocation(),)),
            ((balance(),), (allocation("1.46"),)),
            ((balance(), balance()), (allocation(),)),
            ((balance(),), (allocation(), allocation())),
            ((balance(),), (allocation(loan="OTHER"),)),
            ((balance(as_of_date=date(2026, 3, 31)),), (allocation(),)),
            ((balance(),), (allocation(payment_date=OPEN),)),
        )
        for balances, instructions in invalid:
            with self.subTest(balances=balances, instructions=instructions), self.assertRaises(InputValidationError):
                classify((raw(),), balances=balances, allocations=instructions)
        with self.assertRaisesRegex(InputValidationError, "allocation_id"):
            classify((raw(), raw(loan="OTHER")),
                     balances=(balance(), balance(loan="OTHER")),
                     allocations=(allocation(), allocation(loan="OTHER", allocation_id="RESTORE:L")))

    def test_mutable_tuple_and_malformed_receipt_boundaries_reject(self):
        for receipts, balances, instructions in (
            ([raw()], (balance(),), (allocation(),)),
            ((raw(),), [balance()], (allocation(),)),
            ((raw(),), (balance(),), [allocation()]),
            ((replace(raw(), cash_interest=D("0.001")),), (balance(),), (allocation(),)),
            ((replace(raw(), payment_date=OPEN),), (balance(),), (allocation(),)),
            ((replace(raw(), principal_repayment=D(-1)),), (balance(),), (allocation(),)),
        ):
            with self.subTest(receipts=receipts), self.assertRaises(InputValidationError):
                classify(receipts, balances=balances, allocations=instructions)


class CouponProceedsCloScopeTests(unittest.TestCase):
    def test_plain_native_request_admits_the_exact_known_balance_and_instruction(self):
        result = request()
        self.assertEqual(result.principal_accrued_balances, (balance(),))
        self.assertEqual(result.coupon_proceeds_allocations, (allocation(),))

    def test_restoration_after_legal_final_is_not_a_receipt_from_terminal_sale(self):
        # A permitted long-dated loan may still have coupons after the CLO's
        # legal final. Those future contract rows cannot restore accrued in a
        # projection which sells the asset first; sale allocation is separate.
        with self.assertRaisesRegex(InputValidationError, "legal final"):
            replace(request(), coupon_proceeds_allocations=(
                allocation(payment_date=date(2026, 11, 1)),))
        self.assertEqual(replace(request(), coupon_proceeds_allocations=(
            allocation(payment_date=FINAL),)).coupon_proceeds_allocations[0].payment_date, FINAL)

    def test_external_extra_cash_optional_sale_and_proportional_overlay_reject(self):
        extra = AssetCollection("L", "EUR", PAY, SCHEDULED, D(1), D(0), D(1), 1)
        changes = (
            {"additional_asset_collections": (extra,)},
            {"deal": replace(request().terms, optional_call_enabled=True, optional_call_date=PAY)},
            {"deal": replace(request().terms, original_pool_overlay=OriginalPoolOverlay(enabled=True))},
        )
        for change in changes:
            with self.subTest(change=change), self.assertRaises(InputValidationError):
                request(**change)

    def test_noneligible_restoration_cannot_bypass_permission_via_recycle_all(self):
        policy = SyntheticReinvestmentPolicy(enabled=True, end_date=PAY,
                                             recycle_reinvestment_principal=True)
        deal = replace(request().terms, synthetic_reinvestment_policy=policy)
        with self.assertRaisesRegex(InputValidationError, "Noneligible"):
            request(deal=deal)
        # Permission is independently explicit; enabled recycle-all is allowed
        # only when every classified amount carries that permission.
        admitted = replace(request(), terms=deal,
                           coupon_proceeds_allocations=(allocation(permitted=True),))
        self.assertTrue(admitted.coupon_proceeds_allocations[0].original_principal_permission)
        no_recycle = replace(deal, synthetic_reinvestment_policy=replace(policy, recycle_reinvestment_principal=False))
        self.assertFalse(request(deal=no_recycle).coupon_proceeds_allocations[0].original_principal_permission)

    def test_claimed_default_rejects_without_forbidding_an_unrelated_loan_default(self):
        provider = FlatRateProvider({})
        def credit(identity, event_type):
            loan = LoanTerms(identity, "EUR", OPEN, PAY, D(100), CouponType.FIXED,
                             fixed_rate=D("0.12"),
                             business_day_convention=BusinessDayConvention.UNADJUSTED,
                             accrual_date_basis=AccrualDateBasis.UNADJUSTED,
                             fixing_lag_business_days=0)
            return CreditEventCashflowEngine(provider).generate(
                LoanPosition(loan, OPEN, D(100)), event_type(identity, date(2026, 6, 1)))
        defaulted = credit("L", DefaultEvent)
        deal = replace(request().terms, defaulted_asset_oc_treatment=DefaultedAssetOcTreatment.EXCLUDE)
        with self.assertRaisesRegex(InputValidationError, "claimed loan default"):
            request(deal=deal, asset_credit_projections=(defaulted,))
        unrelated = credit("OTHER", DefaultEvent)
        admitted = request(deal=deal, rows=(contract(), contract("OTHER")),
                           asset_credit_projections=(unrelated,))
        self.assertEqual(admitted.principal_accrued_balances[0].loan_id, "L")
        prepaid = credit("L", PrepaymentEvent)
        self.assertIs(request(asset_credit_projections=(prepaid,)).asset_credit_projections[0], prepaid)


if __name__ == "__main__":
    unittest.main()
