"""Current workbook boundary: scenario publication and principal terms.

Private copies protect the delivered workbook. Assertions use independent
baseline economics and contractual amounts; failed inputs must preserve bytes.
"""

import tempfile
import unittest
from datetime import date
from decimal import Decimal
from pathlib import Path

from openpyxl import load_workbook
from workbook_fixtures import copy_input_template

from trident.adapters import excel_schema as schema
from trident.adapters.clo_example import run_synthetic_clo_example
from trident.adapters.excel import NamedWorkbook, run_workbook
from workbook_fixtures import assert_h00_projection_matches


ROOT = Path(__file__).resolve().parents[1]
EXAMPLE = ROOT / "data/examples/hybrid_500m"
D = Decimal


class ExcelScenarioTests(unittest.TestCase):
    def setUp(self):
        folder = tempfile.TemporaryDirectory()
        self.addCleanup(folder.cleanup)
        self.path = Path(folder.name) / "model.xlsx"
        copy_input_template(self.path)

    @staticmethod
    def table(adapter, key):
        return adapter.table_records(schema.TABLE_RANGE_NAMES[key], schema.TABLE_NAMES[key])

    def access(self, function, *, save=False):
        book = load_workbook(self.path)
        try:
            value = function(NamedWorkbook(book))
            if save:
                book.save(self.path)
            return value
        finally:
            book.close()

    def edit_table(self, key, rows):
        self.access(lambda adapter: adapter.write_table(
            schema.TABLE_RANGE_NAMES[key], schema.TABLE_NAMES[key], rows), save=True)

    def test_complete_baseline_and_two_independent_scenarios_are_published(self):
        result = run_workbook(self.path)
        reference = run_synthetic_clo_example(EXAMPLE)
        assert_h00_projection_matches(self, result.clo, reference.clo)
        self.assertEqual(result.equity_irr, reference.equity_irr)
        def check(adapter):
            self.assertEqual(adapter.scalar(schema.SCALAR_NAMES["result_scenario_status"]), "COMPLETED")
            self.assertEqual(adapter.scalar(schema.SCALAR_NAMES["result_scenario_count"]), 2)
            metrics = self.table(adapter, "scenario_comparisons")
            cases = {row["scenario_id"]: row for row in metrics if row["metric"] == "EQUITY_IRR"}
            self.assertEqual(set(cases), {"A_MARGIN_150", "SENIOR_FEE_20"})
            for row in cases.values():
                self.assertEqual(row["baseline_status"], "AVAILABLE")
                self.assertEqual(row["scenario_status"], "AVAILABLE")
                self.assertEqual(row["delta_status"], "AVAILABLE")
                self.assertAlmostEqual(row["baseline_value"], float(result.equity_irr.value), places=14)
                self.assertLess(row["delta"], 0)
            # Baseline funding is unchanged by either coupon/fee edit.
            funding = [row for row in metrics if row["metric"] == "EQUITY_CASH_FUNDING"]
            self.assertEqual(len(funding), 2)
            self.assertTrue(all(row["delta"] == 0 for row in funding))
            periods = self.table(adapter, "scenario_periods")
            self.assertTrue(any(row["metric"] == "OC_GATE_RATIO" for row in periods))
            self.assertTrue(any(row["metric"] == "IC_GATE_HEADROOM" for row in periods))
            # Small IRR changes retain visible diagnostic precision.
            sheet, (left, top, right, _) = adapter.region(schema.TABLE_RANGE_NAMES["scenario_comparisons"])
            columns = {sheet.cell(top, col).value: col for col in range(left, right + 1)}
            row_number = next(index for index, row in enumerate(metrics, top + 1) if row["metric"] == "EQUITY_IRR")
            self.assertEqual(sheet.cell(row_number, columns["delta"]).number_format, "0.########")
        self.access(check)

    def test_disabled_scenarios_clear_stale_results_and_ignore_unused_bad_edits(self):
        def edit(adapter):
            adapter.write_scalar(schema.SCALAR_NAMES["scenario_enabled"], False)
            adapter.write_table(schema.TABLE_RANGE_NAMES["scenario_edits"], schema.TABLE_NAMES["scenario_edits"],
                ({"scenario_id": "UNUSED", "target": "UNKNOWN", "identifier": "?", "field": "?", "value": "?", "enabled": True},))
        self.access(edit, save=True)
        result = run_workbook(self.path)
        self.assertEqual(result.clo.total_equity_distributions, D("96115867.54"))
        def check(adapter):
            self.assertEqual(adapter.scalar(schema.SCALAR_NAMES["result_scenario_status"]), "DISABLED")
            self.assertEqual(adapter.scalar(schema.SCALAR_NAMES["result_scenario_count"]), 0)
            self.assertEqual(self.table(adapter, "scenario_comparisons"), ())
            self.assertEqual(self.table(adapter, "scenario_periods"), ())
        self.access(check)

    def test_empty_enabled_batch_has_explicit_status_and_clears_outputs(self):
        self.edit_table("scenario_edits", ())
        run_workbook(self.path)
        self.access(lambda a: self.assertEqual(a.scalar(schema.SCALAR_NAMES["result_scenario_status"]), "NO_SCENARIOS"))
        self.access(lambda a: self.assertEqual(self.table(a, "scenario_comparisons"), ()))

    def test_invalid_scenario_fails_atomically_with_its_name(self):
        self.edit_table("scenario_edits", ({"scenario_id": "BAD_ASSET", "target": "ASSET", "identifier": "UNKNOWN",
                                          "field": "par", "value": 100, "enabled": True},))
        before = self.path.read_bytes()
        with self.assertRaisesRegex(ValueError, "Scenario BAD_ASSET.*Unknown"):
            run_workbook(self.path)
        self.assertEqual(self.path.read_bytes(), before)

    def test_duplicate_edit_is_rejected_atomically(self):
        row = {"scenario_id": "DUPLICATE", "target": "NOTE", "identifier": "A", "field": "spread_bps", "value": 150, "enabled": True}
        self.edit_table("scenario_edits", (row, dict(row, value=160)))
        before = self.path.read_bytes()
        with self.assertRaisesRegex(ValueError, "Duplicate edit"):
            run_workbook(self.path)
        self.assertEqual(self.path.read_bytes(), before)

    def test_case_insensitive_duplicate_scenario_names_are_rejected_atomically(self):
        row = {"scenario_id": "CASE", "target": "NOTE", "identifier": "A", "field": "spread_bps", "value": 150, "enabled": True}
        self.edit_table("scenario_edits", (row, dict(row, scenario_id="case", value=160)))
        before = self.path.read_bytes()
        with self.assertRaisesRegex(ValueError, "Scenario names must be unique"):
            run_workbook(self.path)
        self.assertEqual(self.path.read_bytes(), before)

    def test_principal_table_header_error_is_rejected_atomically(self):
        def edit(adapter):
            sheet, (left, top, _, _) = adapter.region(schema.TABLE_RANGE_NAMES["principal_schedule"])
            sheet.cell(top, left).value = "UNKNOWN_HEADER"
        self.access(edit, save=True)
        before = self.path.read_bytes()
        with self.assertRaisesRegex(ValueError, "headers"):
            run_workbook(self.path)
        self.assertEqual(self.path.read_bytes(), before)

    def change_first_asset(self, kind, **fields):
        def edit(adapter):
            rows = tuple(dict(row) for row in self.table(adapter, "assets"))
            first = rows[0]
            first.update(amortization_type=kind, amortization_fraction_initial_par_per_period=0,
                         amortization_first_date_unadjusted=None, amortization_periods_remaining=None, **fields)
            adapter.write_table(schema.TABLE_RANGE_NAMES["assets"], schema.TABLE_NAMES["assets"], rows)
            adapter.write_scalar(schema.SCALAR_NAMES["scenario_enabled"], False)
            return first["loan_id"], D(str(first["current_par"]))
        return self.access(edit, save=True)

    def test_bespoke_schedule_reaches_asset_and_clo_cashflows(self):
        loan, par = self.change_first_asset("BESPOKE")
        self.assertEqual(par, D("7000000"))
        self.edit_table("principal_schedule", (
            {"loan_id": loan, "payment_date_unadjusted": date(2027, 2, 20), "amount": D("3500000")},
            {"loan_id": loan, "payment_date_unadjusted": date(2036, 11, 20), "amount": D("3500000")},
        ))
        result = run_workbook(self.path)
        rows = tuple(row for row in result.cashflows.cashflows if row.loan_id == loan)
        self.assertEqual(rows[0].principal_repayment, D("3500000"))
        self.assertEqual(rows[-1].principal_repayment, D("3500000"))
        self.assertTrue(all(row.principal_repayment == 0 for row in rows[1:-1]))
        self.assertEqual(sum(row.principal_repayment for row in rows), par)
        self.assertEqual(result.clo.periods[0].received_asset_principal, D("10325000"))
        self.assertEqual(result.clo.final_collateral_par, 0)
        self.assertTrue(all(row.cash_conservation_residual == 0 for row in result.clo.periods))

    def test_projected_annuity_terms_reach_the_unified_clo(self):
        loan, par = self.change_first_asset("ANNUITY", balloon_amount=0)
        result = run_workbook(self.path)
        rows = tuple(row for row in result.cashflows.cashflows if row.loan_id == loan)
        self.assertEqual(len(rows), 40)
        self.assertEqual(sum(row.principal_repayment for row in rows), par)
        self.assertEqual(len({row.cash_interest + row.principal_repayment for row in rows[:-1]}), 1)
        self.assertTrue(all(row.principal_repayment >= 0 for row in rows))
        self.assertEqual(result.clo.final_collateral_par, 0)
        self.assertEqual(result.clo.final_debt_par, 0)


if __name__ == "__main__":
    unittest.main()
