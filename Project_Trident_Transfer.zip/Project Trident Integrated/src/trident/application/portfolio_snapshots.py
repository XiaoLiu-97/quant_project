"""Actual performing holdings for credit slices and synthetic acquisitions.

Snapshots consume the waterfall's dated audit, preserving past receipts and
loan identities. A purchased synthetic cohort never inherits the original
pool's rating, issuer or concentration metadata. Analytical future principal
is a surviving contractual reference, separate from stressed cash collections.
"""

from __future__ import annotations

from bisect import bisect_left, bisect_right
from collections import defaultdict
from dataclasses import replace
from datetime import date
from decimal import Decimal
from fractions import Fraction

from trident.analysis import AssetExposure, FactorMapping, LimitSpec, PortfolioAnalyzer, PortfolioReport
from trident.analysis.models import LimitStatus, MetricStatus, ScheduledMaturityReceipt
from trident.clo.models import CloProjection
from trident.clo.reinvestment import SyntheticReinvestmentPolicy
from trident.credit.models import AssetCreditProjection
from trident.credit.overlay import PoolOverlayProjection
from trident.domain.models import CouponType, InputValidationError, LoanCashflow, require_date
from trident.domain.numeric import post_currency, decimal_fraction
from .imported_cashflows import ImportedCollateralProjection
from .portfolio_phases import portfolio_phase
from .coupon_timeline import CouponTimeline


ZERO = Decimal(0)


def _imported_exposures(
    exposures: tuple[AssetExposure, ...], source: ImportedCollateralProjection,
    structural_horizon: date, reference_ids: frozenset[str],
) -> tuple[tuple[AssetExposure, ...], frozenset[str], frozenset[str]]:
    """Keep matched metadata; aggregate records have explicitly unknown terms.

    AssetExposure requires a structural date. For unidentified imported pools,
    this is only an internal horizon boundary; the public report masks every
    metric that could mistake it for a contractual maturity or scheduled WAL.
    """
    known = {asset.loan_id: asset for asset in exposures}
    # Positive capitalized coupon in the active identified source establishes
    # PIK exposure independently of a dormant native contract. Conversely,
    # zero future PIK does not establish CASH: a contractual option or a later
    # election can leave no capitalization in this particular projection.
    proved_pik = frozenset(row.loan_id for row in source.detailed_rows if row.pik_interest > 0
                          and (source.projection_start_date is None
                               or row.payment_date >= source.projection_start_date))
    result, unknown, unconfirmed_maturity = [], set(), set()
    for identity, par in source.loan_opening_par.items():
        asset = known.get(identity)
        if identity in proved_pik and asset is not None and asset.is_pik is False:
            raise InputValidationError(f"Imported {identity}: positive PIK coupon contradicts explicit non-PIK exposure metadata")
        valid_reference = identity in reference_ids
        reference_end = source.final_principal_dates[identity] if valid_reference else structural_horizon
        if asset is not None and asset.par == par:
            # The external transport currently establishes cash/par timing,
            # but does not retain coupon-type/rate evidence. An inactive native
            # contract cannot certify floating WAS or fixed WAC for this source.
            result.append(replace(asset, maturity_date=reference_end,
                                  coupon_type=None, fixed_coupon_rate=None,
                                  is_pik=True if identity in proved_pik else asset.is_pik))
            if valid_reference and asset.maturity_date != reference_end:
                unconfirmed_maturity.add(identity)
        else:
            unconfirmed_maturity.add(identity)
            result.append(AssetExposure(
                identity, None, None, None, None, None, "EUR", par, None,
                reference_end, is_pik=True if identity in proved_pik else None,
            ))
        if not valid_reference:
            unknown.add(identity)
    return tuple(result), frozenset(unknown), frozenset(unconfirmed_maturity)


def _external_principal_reference(source: ImportedCollateralProjection) -> tuple[tuple[LoanCashflow, ...], frozenset[str]]:
    """Use active, unstressed detailed principal dates, never the internal tape.

    The transport is analytical principal-only LoanCashflow data, without a
    LoanTerms contract or invented coupon/fixing. PIK, stressed inputs and an
    incomplete principal bridge cannot establish unstressed contractual WAL.
    """
    if source.credit_effects_included:
        return (), frozenset()
    grouped = defaultdict(list)
    for row in source.detailed_rows:
        if source.projection_start_date is None or row.payment_date >= source.projection_start_date:
            grouped[row.loan_id].append(row)
    result, valid = [], set()
    for identity, rows in grouped.items():
        rows.sort(key=lambda row: (row.payment_date, row.period_number))
        opening = source.loan_opening_par[identity]
        if (any(row.pik_interest for row in rows) or rows[-1].ending_par != 0
                or sum((Fraction(row.principal_collection) for row in rows), Fraction()) != Fraction(opening)):
            continue
        valid.add(identity)
        previous = source.projection_start_date or rows[0].accrual_start or rows[0].payment_date
        for row in rows:
            start = row.accrual_start or previous
            end = row.accrual_end or row.payment_date
            result.append(LoanCashflow(
                loan_id=identity, currency=row.currency, period_number=row.period_number,
                unadjusted_start=start, unadjusted_end=end, accrual_start=start, accrual_end=end,
                payment_date=row.payment_date, fixing_date=None, opening_balance=row.beginning_par,
                index_rate=None, spread_bps=ZERO, all_in_rate=ZERO,
                day_count_fraction=decimal_fraction(Fraction((end - start).days, 365)),
                interest_unrounded=ZERO, cash_interest=ZERO, principal_repayment=row.principal_collection,
                closing_balance=row.ending_par, total_cash=row.principal_collection,
            ))
            previous = row.payment_date
    return tuple(result), frozenset(valid)


def _unknown_imported_terms(report: PortfolioReport, unknown: frozenset[str], unconfirmed_maturity: frozenset[str] = frozenset()) -> PortfolioReport:
    """Never pass maturity-dependent limits using an internal horizon date."""
    if not unknown and not unconfirmed_maturity:
        return report
    affected = {"WAL_YEARS", "WEIGHTED_AVERAGE_MATURITY_YEARS", "LONG_DATED_FRACTION"} if unknown else {"WEIGHTED_AVERAGE_MATURITY_YEARS"}
    reason = ("Active imported source is aggregate, stressed, PIK or lacks a complete identified principal bridge; unstressed WAL/maturity is unavailable"
              if unknown else "Internal maturity metadata differs from or is absent for the active external principal schedule; contractual maturity is unconfirmed")
    return replace(
        report,
        metrics=tuple(replace(metric, value=None, status=MetricStatus.UNAVAILABLE, coverage=ZERO, message=reason)
                      if metric.name in affected else metric for metric in report.metrics),
        limits=tuple(replace(limit, value=None, status=LimitStatus.UNAVAILABLE, headroom=None, message=reason)
                     if limit.metric in affected and limit.status is not LimitStatus.NOT_APPLICABLE else limit for limit in report.limits),
    )


def build_opening_portfolio(
    exposures: tuple[AssetExposure, ...], contractual_cashflows: tuple[LoanCashflow, ...], asof: date,
    *, factor_mapping: FactorMapping | None = None, limits: tuple[LimitSpec, ...] = (),
    imported_collateral: ImportedCollateralProjection | None = None,
    legal_final_date: date | None = None,
) -> PortfolioReport:
    """Opening analysis of the active source, with unknown aggregate metadata."""
    unknown = frozenset()
    unconfirmed_maturity = frozenset()
    actual = exposures
    reference_rows = contractual_cashflows
    if imported_collateral is not None:
        reference_rows, reference_ids = _external_principal_reference(imported_collateral)
        horizon = max(asof, legal_final_date or asof, max(imported_collateral.final_principal_dates.values()))
        actual, unknown, unconfirmed_maturity = _imported_exposures(exposures, imported_collateral, horizon, reference_ids)
    principal = _principal_reference(reference_rows, actual, asof, include_asof=imported_collateral is not None)
    report = PortfolioAnalyzer().analyze(actual, asof, principal, factor_mapping, limits, "CLOSING", legal_final_date)
    if imported_collateral is not None:
        report = _annotate_external_reference(report)
    return _unknown_imported_terms(report, unknown, unconfirmed_maturity)


def _annotate_external_reference(report: PortfolioReport) -> PortfolioReport:
    """Expose which active dates underlie timing and long-dated diagnostics."""
    return replace(report, metrics=tuple(
        replace(metric, message=("Active detailed external principal schedule; long-dated uses its final receipt date, not unused internal maturity. " + metric.message).rstrip())
        if metric.name in {"WAL_YEARS", "LONG_DATED_FRACTION"} else metric for metric in report.metrics
    ))


def _principal_reference(
    rows: tuple[LoanCashflow, ...], held: tuple[AssetExposure, ...], asof: date,
    *, include_asof: bool = False,
) -> tuple[LoanCashflow, ...]:
    """Allocate surviving contractual principal with cumulative cent targets.

    Only fields used by WAL are consumed. Coupon is zero because this is an
    analytical principal reference, never another cashflow-engine projection.
    If the full reference is absent, keep the shortfall visible to the analyzer.
    """
    return _PrincipalReferenceIndex(rows).at(held, asof, include_asof=include_asof)


class _PrincipalReferenceIndex:
    """Index positive contractual principal once for a dated analytical run.

    A growing observation calendar should not repeatedly group/sort the whole
    cashflow tape. Bisect selects each surviving holding's future receipts;
    cached suffix sums retain exact principal totals. The proportional cent
    allocation remains the same as the standalone opening reference helper.
    """

    def __init__(self, rows: tuple[LoanCashflow, ...]) -> None:
        grouped: dict[str, list[LoanCashflow]] = defaultdict(list)
        for row in rows:
            if row.principal_repayment > 0:
                grouped[row.loan_id].append(row)
        self._rows: dict[str, tuple[LoanCashflow, ...]] = {}
        self._dates: dict[str, tuple[date, ...]] = {}
        self._suffix: dict[str, tuple[Fraction, ...]] = {}
        for identity, source in grouped.items():
            ordered = tuple(sorted(source, key=lambda row: (row.payment_date, row.period_number)))
            self._rows[identity] = ordered
            self._dates[identity] = tuple(row.payment_date for row in ordered)
            suffix = [Fraction()] * (len(ordered) + 1)
            for index in range(len(ordered) - 1, -1, -1):
                suffix[index] = suffix[index + 1] + Fraction(ordered[index].principal_repayment)
            self._suffix[identity] = tuple(suffix)

    def at(self, held: tuple[AssetExposure, ...], asof: date,
           *, include_asof: bool = False) -> tuple[LoanCashflow, ...]:
        """Allocate only the future surviving reference, with one cent bridge.

        Post-event observations exclude principal paid on the observation date.
        The separate opening imported-source view can include closing-day cash
        before that day's movements are applied. Missing future principal is
        intentionally left incomplete rather than inventing a bullet maturity.
        """
        result = []
        for asset in held:
            identity = asset.loan_id
            if identity not in self._rows:
                continue
            boundary = (bisect_left if include_asof else bisect_right)(self._dates[identity], asof)
            reference = self._suffix[identity][boundary]
            if reference == 0:
                continue
            target = min(Fraction(asset.par), reference)
            cumulative, prior_target, balance = Fraction(), ZERO, post_currency(target)
            for row in self._rows[identity][boundary:]:
                cumulative += Fraction(row.principal_repayment)
                cumulative_target = post_currency(target * cumulative / reference)
                principal = post_currency(Fraction(cumulative_target) - Fraction(prior_target))
                prior_target = cumulative_target
                closing = post_currency(Fraction(balance) - Fraction(principal))
                result.append(replace(row, opening_balance=balance, principal_repayment=principal,
                                      closing_balance=closing, cash_interest=ZERO,
                                      interest_unrounded=ZERO, total_cash=principal, pik_interest=ZERO))
                balance = closing
        return tuple(result)


def _bullet_reference(asset: AssetExposure, asof: date) -> LoanCashflow:
    """An analytical synthetic bullet, explicitly without coupon-rate claims."""
    return LoanCashflow(
        loan_id=asset.loan_id, currency=asset.currency, period_number=1,
        unadjusted_start=asof, unadjusted_end=asset.maturity_date,
        accrual_start=asof, accrual_end=asset.maturity_date,
        payment_date=asset.maturity_date, fixing_date=None,
        opening_balance=asset.par, index_rate=None, spread_bps=ZERO,
        all_in_rate=ZERO, day_count_fraction=decimal_fraction(Fraction((asset.maturity_date - asof).days, 365)),
        interest_unrounded=ZERO, cash_interest=ZERO, principal_repayment=asset.par,
        closing_balance=ZERO, total_cash=asset.par,
    )


class PortfolioStateScanner:
    """Replay the actual holdings ledger once across ordered observations.

    The same scanner serves contractual CLO payment snapshots and the richer
    event calendar. It consumes absolute performing-face balances, not cash
    collections or defaulted receivables, and keeps source order for same-day
    credit operations. Purchases precede their own par movements; a full sale
    follows all those operations and permanently disposes the entire book.
    """

    def __init__(
        self, exposures: tuple[AssetExposure, ...], contractual_cashflows: tuple[LoanCashflow, ...],
        clo_projection: CloProjection, *, factor_mapping: FactorMapping | None = None,
        limits: tuple[LimitSpec, ...] = (), reinvestment_end_date: date | None = None,
        credit_projections: tuple[AssetCreditProjection, ...] = (),
        original_overlay_projection: PoolOverlayProjection | None = None,
        reinvestment_policy: SyntheticReinvestmentPolicy | None = None,
        legal_final_date: date | None = None,
        imported_collateral: ImportedCollateralProjection | None = None,
        coupon_timeline: CouponTimeline | None = None,
    ) -> None:
        if not isinstance(clo_projection, CloProjection):
            raise InputValidationError("Snapshot construction requires a CloProjection")
        overlay = original_overlay_projection or clo_projection.original_overlay_projection
        if overlay is not None and not isinstance(overlay, PoolOverlayProjection):
            raise InputValidationError("Snapshot overlay must be PoolOverlayProjection")
        if overlay is not None and credit_projections:
            raise InputValidationError("Full exit credit and fractional overlay cannot be applied twice")
        unknown, unconfirmed_maturity = frozenset(), frozenset()
        reference_rows = contractual_cashflows
        if imported_collateral is not None:
            reference_rows, reference_ids = _external_principal_reference(imported_collateral)
            horizon = max(legal_final_date or date.min,
                          max((period.payment_date for period in clo_projection.periods), default=date.min),
                          max(imported_collateral.final_principal_dates.values()))
            exposures, unknown, unconfirmed_maturity = _imported_exposures(exposures, imported_collateral, horizon, reference_ids)
        self._baseline = {asset.loan_id: asset for asset in exposures}
        if len(self._baseline) != len(exposures):
            raise InputValidationError("Duplicate opening snapshot identity")
        self._balances = {asset.loan_id: asset.par for asset in exposures}
        purchases = tuple(clo_projection.reinvestment_purchases)
        if purchases and reinvestment_policy is None:
            raise InputValidationError("Synthetic purchases require their explicit template policy")
        self._purchased = {row.cohort_id: row for row in purchases}
        if len(self._purchased) != len(purchases) or set(self._purchased) & set(self._baseline):
            raise InputValidationError("Synthetic and opening snapshot identities must be unique")
        # Stable sorting by date and operation priority preserves the credit
        # engine's ordered scheduled/default/prepayment bridge on the same day.
        events: list[tuple[date, int, str | None, Decimal]] = []
        if overlay is not None:
            movements = overlay.par_movements
        elif credit_projections:
            movements = tuple(row for asset in credit_projections for row in asset.par_movements)
        elif imported_collateral is not None:
            movements = imported_collateral.par_movements
        else:
            movements = ()
        changed_dates: set[date] = set()
        if movements:
            events.extend((row.event_date, 1, row.loan_id, row.performing_par_after) for row in movements)
            changed_dates.update(row.event_date for row in movements
                                 if row.performing_par_before != row.performing_par_after)
        elif overlay is None and not credit_projections and imported_collateral is None:
            # Share the contract's capitalization date with the CLO ledger:
            # accrual end, capped at an earlier advance-adjusted cash date.
            # Same-day PIK must exist before principal redemption; ordinary
            # settlement lag still keeps its earlier noncash face addition.
            deltas = [(row.pik_capitalization_date, 0, row.loan_id, Fraction(row.pik_interest))
                      for row in contractual_cashflows if row.pik_interest]
            deltas.extend((row.payment_date, 1, row.loan_id, -Fraction(row.principal_repayment))
                          for row in contractual_cashflows if row.principal_repayment)
            native_balances = {identity: Fraction(balance) for identity, balance in self._balances.items()}
            for day, _, identity, delta in sorted(deltas, key=lambda event: (event[0], event[1])):
                native_balances[identity] += delta
                if native_balances[identity] < 0:
                    raise ArithmeticError("Native holdings face became negative")
                events.append((day, 1, identity, post_currency(native_balances[identity])))
                changed_dates.add(day)
        events.extend((row.purchase_date, 0, row.cohort_id, row.acquired_par) for row in purchases)
        changed_dates.update(row.purchase_date for row in purchases)
        events.extend((row.event_date, 1, row.loan_id, row.performing_par_after)
                      for row in clo_projection.reinvestment_par_movements)
        changed_dates.update(row.event_date for row in clo_projection.reinvestment_par_movements
                             if row.performing_par_before != row.performing_par_after)
        for period in clo_projection.periods:
            if period.collateral_sale_par > 0:
                if period.closing_collateral_par != 0:
                    raise ArithmeticError("Full terminal collateral sale left performing face")
                events.append((period.payment_date, 2, None, ZERO))
                changed_dates.add(period.payment_date)
        self._events = tuple(sorted(events, key=lambda row: (row[0], row[1])))
        self.event_dates = tuple(sorted(changed_dates))
        self._event_index, self._disposed, self._last_date = 0, False, None
        self._projection, self._mapping, self._limits = clo_projection, factor_mapping, limits
        self._reinvestment_end, self._reinvestment_policy = reinvestment_end_date, reinvestment_policy
        self._legal_final, self._imported, self._timeline = legal_final_date, imported_collateral, coupon_timeline
        self._overlay, self._credit = overlay, credit_projections
        self._unknown, self._unconfirmed_maturity = unknown, unconfirmed_maturity
        self._principal = _PrincipalReferenceIndex(reference_rows)
        self._analyzer = PortfolioAnalyzer()
        self._period_par = {period.payment_date: period.closing_collateral_par
                            for period in clo_projection.periods}

    def _maturity_receipts(
        self, original: tuple[AssetExposure, ...], future: tuple[LoanCashflow, ...], day: date,
    ) -> tuple[ScheduledMaturityReceipt, ...]:
        """Prove a native contractual final receipt after nominal maturity.

        Business-day adjustment/payment lag can leave performing face awaiting
        its actual final payment while another holding creates an observation.
        A fully matching single final principal receipt permits that gap; it
        never changes nominal maturity or infers an overdue asset's status.
        Active imported streams cannot borrow inactive native-contract evidence.
        """
        if self._imported is not None:
            return ()
        expired = {asset.loan_id: asset for asset in original if asset.maturity_date < day}
        if not expired:
            return ()
        rows: dict[str, list[LoanCashflow]] = defaultdict(list)
        for row in future:
            if row.loan_id in expired and row.principal_repayment > 0:
                rows[row.loan_id].append(row)
        receipts = []
        for identity, asset in expired.items():
            source = rows[identity]
            if len(source) != 1:
                continue
            row = source[0]
            if (row.payment_date > day and row.currency == asset.currency
                    and row.unadjusted_end == asset.maturity_date
                    and row.closing_balance == 0 and row.principal_repayment == asset.par):
                receipts.append(ScheduledMaturityReceipt(identity, asset.currency, asset.maturity_date,
                                                         row.payment_date, asset.par))
        return tuple(receipts)

    def scan(self, dates: tuple[date, ...], *, closing_date: date | None = None) -> tuple[PortfolioReport, ...]:
        """Produce post-event reports, reconciling every included CLO date.

        Callers supply a monotone unique calendar. Each ledger event is consumed
        once, even when many extra dates occur between CLO payments. This is an
        end-of-day observation convention, not an invented intra-day settlement
        sequence or a continuous-compliance claim.
        """
        if type(dates) is not tuple:
            raise InputValidationError("Portfolio observation dates must be an immutable tuple")
        if closing_date is not None:
            require_date(closing_date, "portfolio closing date")
        reports = []
        for day in dates:
            require_date(day, "portfolio observation date")
            if self._last_date is not None and day <= self._last_date:
                raise InputValidationError("Portfolio observation dates must be strictly increasing")
            while self._event_index < len(self._events) and self._events[self._event_index][0] <= day:
                _, priority, identity, balance = self._events[self._event_index]
                self._event_index += 1
                if priority == 2:
                    self._balances = {identity: ZERO for identity in self._balances}
                    self._disposed = True
                else:
                    if identity not in self._baseline and identity not in self._purchased:
                        raise InputValidationError("Snapshot movement refers to an unknown holding")
                    if self._disposed:
                        # Native tapes can extend beyond an earlier sale. Those
                        # future rights cannot resurrect the disposed book.
                        if priority == 0:
                            raise InputValidationError("Synthetic acquisition follows terminal collateral disposal")
                    else:
                        self._balances[identity] = balance
            original = tuple(replace(asset, par=self._balances[identity])
                             for identity, asset in self._baseline.items() if self._balances[identity] > 0)
            if self._timeline is not None and self._imported is None:
                original = self._timeline.at(original, day)
            synthetic = tuple(
                AssetExposure(
                    loan_id=identity, obligor=None, asset_class=None, financing_type=None,
                    country=None, sector=None, currency="EUR", par=self._balances[identity],
                    spread_bps=self._reinvestment_policy.spread_bps, maturity_date=purchase.maturity_date,
                    recovery_rate=self._reinvestment_policy.recovery_rate,
                    recovery_rate_source="SYNTHETIC_REINVESTMENT_SCENARIO_NOT_AGENCY_RECOVERY",
                    coupon_type=CouponType.FLOATING,
                )
                for identity, purchase in self._purchased.items() if self._balances.get(identity, ZERO) > 0
            )
            current = original + synthetic
            future = self._principal.at(original, day)
            maturity_receipts = self._maturity_receipts(original, future, day)
            future += tuple(_bullet_reference(asset, day) for asset in synthetic)
            phase = portfolio_phase(self._projection, day, self._reinvestment_end)
            if day == closing_date and phase != "TERMINATED":
                phase = "CLOSING"
            report = self._analyzer.analyze(current, day, future, self._mapping, self._limits,
                                            phase, self._legal_final,
                                            scheduled_maturity_receipts=maturity_receipts)
            if self._overlay is not None or self._credit or synthetic:
                report = replace(report, metrics=tuple(
                    replace(metric, message=("Surviving contractual principal reference; future scenario defaults/prepayments excluded. " + metric.message).rstrip())
                    if metric.name == "WAL_YEARS" else metric for metric in report.metrics
                ))
            if self._imported is not None:
                report = _annotate_external_reference(report)
            held_ids = frozenset(asset.loan_id for asset in current)
            report = _unknown_imported_terms(report, self._unknown & held_ids,
                                              self._unconfirmed_maturity & held_ids)
            if day in self._period_par and report.total_par != self._period_par[day]:
                raise ArithmeticError("Actual portfolio snapshot does not reconcile to CLO performing-par ledger")
            reports.append(report)
            self._last_date = day
        return tuple(reports)


def build_portfolio_snapshots(
    exposures: tuple[AssetExposure, ...], contractual_cashflows: tuple[LoanCashflow, ...],
    clo_projection: CloProjection, *, factor_mapping: FactorMapping | None = None,
    limits: tuple[LimitSpec, ...] = (), reinvestment_end_date: date | None = None,
    credit_projections: tuple[AssetCreditProjection, ...] = (),
    original_overlay_projection: PoolOverlayProjection | None = None,
    reinvestment_policy: SyntheticReinvestmentPolicy | None = None,
    legal_final_date: date | None = None,
    imported_collateral: ImportedCollateralProjection | None = None,
    coupon_timeline: CouponTimeline | None = None,
) -> tuple[PortfolioReport, ...]:
    """Reconcile every snapshot to actual CLO performing face, including buys.

    End-date monitoring remains the previously documented exclusive phase
    boundary; purchase permission is separately inclusive in the policy. WAL
    follows remaining contractual principal of surviving slices, not assumed
    future CDR/CPR cash. Missing synthetic quality metadata remains unavailable.
    A supplied native coupon timeline updates original held margins/fixed rates
    at the snapshot date; synthetic cohorts use their own explicit template.
    Active imported sources deliberately ignore unused native step metadata.
    """
    scanner = PortfolioStateScanner(exposures, contractual_cashflows, clo_projection,
        factor_mapping=factor_mapping, limits=limits, reinvestment_end_date=reinvestment_end_date,
        credit_projections=credit_projections, original_overlay_projection=original_overlay_projection,
        reinvestment_policy=reinvestment_policy, legal_final_date=legal_final_date,
        imported_collateral=imported_collateral, coupon_timeline=coupon_timeline)
    return scanner.scan(tuple(period.payment_date for period in clo_projection.periods))
