"""Independent hand-sized cash ledgers for migrated CLO lifecycle inputs."""

import unittest
from dataclasses import replace
from datetime import date
from decimal import Decimal, Inexact, localcontext
from fractions import Fraction

from trident.clo import CloRunRequest, CloTerms, DeterministicCloEngine, NoteTranche, ProjectionStatus, report_tranche_periods, report_equity_periods, CashAccountAccrualMode, DefaultedAssetOcTreatment
from trident.clo.lifecycle import AdjustedCollateralValuePolicy, OcAssetBalance, OcAssetData, ShortfallAccrualMethod
from trident.clo.reinvestment import SyntheticReinvestmentPolicy, ReinvestmentTestGate
from trident.conventions import DayCount, StubConvention
from trident.conventions.calendar import CalendarName
from trident.conventions.liability_rates import FixingDateAnchor, FirstStubRateMethod
from trident.domain.models import CouponType, InputValidationError
from trident.market.rates import FlatRateProvider
from trident.market.cash_accounts import CashCurveRateProvider, DiscountFactorCashCurve, ZeroCompounding, ZeroRatePoint
from trident.credit.overlay import OriginalPoolOverlay
from trident.application.imported_cashflows import (compile_imported_cashflows, CollateralCashflowInputMode,
                                                DetailedImportedCashflow, SimplifiedImportedCashflow)
from test_clo import CLOSE, FIRST, SECOND, receipt, note, run

D = Decimal


class LifecycleLedgerTests(unittest.TestCase):
    def test_incentive_charges_total_residual_above_actual_cash_funding(self):
        result = run((receipt("L", 1, CLOSE, FIRST, "100", "100", "20"),), (note(par="60"),),
                     incentive_fee_enabled=True, incentive_fee_rate=D("0.2"), incentive_hurdle_rate=D(0),
                     incentive_initial_equity_funding=D(40))
        # 20 interest + 40 principal residual; hurdle40; fee20%*(60-40)=4.
        self.assertEqual(result.periods[0].incentive_fee_paid, D(4))
        self.assertEqual(result.periods[0].equity_from_interest, D(16))
        self.assertEqual(result.periods[0].equity_from_principal, D(40))
        self.assertEqual(result.total_equity_distributions, D(56))
        self.assertEqual(result.periods[0].cash_conservation_residual, D(0))

    def test_incentive_effective_annual_hurdle_and_rounding(self):
        end = date(2027, 1, 20)
        result = run((receipt("L", 1, CLOSE, end, "100", "100", "20"),), (note(par="60"),),
                     final=end, frequency_months=12, incentive_fee_enabled=True,
                     incentive_fee_rate=D("0.2"), incentive_hurdle_rate=D("0.1"), incentive_initial_equity_funding=D(40))
        self.assertEqual(result.periods[0].incentive_fee_paid, D("3.20"))
        self.assertEqual(result.total_equity_distributions, D("56.80"))

    def test_incentive_unfunded_input_rejected_and_nominal_not_inferred(self):
        with self.assertRaises(InputValidationError):
            CloTerms(CLOSE, SECOND, incentive_fee_enabled=True)

    def test_compounded_arrears_keep_separate_claim_and_eventual_catchup(self):
        result = run((receipt("L", 1, CLOSE, FIRST, "100", "0", "0"),
                      receipt("L", 2, FIRST, SECOND, "100", "100", "8")), (note(par="60", rate="0.08"),),
                     continue_after_coupon_shortfall=True, shortfall_accrual_method=ShortfallAccrualMethod.COUPON_RATE)
        self.assertEqual(result.tranche_periods[0].closing_coupon_arrears, D("1.20"))
        self.assertEqual(result.tranche_periods[1].coupon_shortfall_interest, D("0.02"))
        self.assertEqual(result.tranche_periods[1].current_coupon_due, D("1.21"))
        self.assertEqual(result.tranche_periods[1].coupon_paid_from_interest, D("2.43"))
        self.assertEqual(result.total_equity_distributions, D("45.57"))
        self.assertIs(result.status, ProjectionStatus.COMPLETED)
        report_tranche_periods(result)

    def test_gate_redemption_does_not_skip_junior_coupon_to_repay_junior_par(self):
        floating = NoteTranche("B", 2, D(20), CouponType.FLOATING, "EURIBOR_3M", D(1750))
        result = run((receipt("L", 1, CLOSE, FIRST, "100", "0", "200"),
                      receipt("L", 2, FIRST, SECOND, "100", "100", "0")),
                     (note("A", 1, "80", "0", oc_minimum=D(3)), floating),
                     continue_after_coupon_shortfall=True, shortfall_accrual_method=ShortfallAccrualMethod.COUPON_RATE)
        # Senior gate can retire A; B principal cannot be redeemed while its
        # coupon is blocked. The residual120 is held for the next allocation.
        self.assertEqual(result.tranche_periods[1].closing_balance, D(20))
        self.assertEqual(result.tranche_periods[1].closing_coupon_arrears, D(1))
        second_b = result.tranche_periods[3]
        self.assertEqual(second_b.current_coupon_due, D("1.01"))
        self.assertEqual(second_b.coupon_shortfall_interest, D("0.05"))
        self.assertEqual(second_b.coupon_paid_from_interest, D("2.06"))
        self.assertIsNotNone(second_b.fixing_date)
        report_tranche_periods(result)

    def test_disabled_shortfall_carry_records_waiver_not_a_cash_payment(self):
        result = run((receipt("L", 1, CLOSE, FIRST, "100", "0", "0"),
                      receipt("L", 2, FIRST, SECOND, "100", "100", "8")), (note(par="60", rate="0.08"),),
                     continue_after_coupon_shortfall=True, interest_shortfall_carry=False)
        first = result.tranche_periods[0]
        self.assertEqual(first.waived_coupon_shortfall, D("1.20"))
        self.assertEqual(first.closing_coupon_arrears, D(0))
        self.assertEqual(first.coupon_paid_from_interest, D(0))
        self.assertTrue(result.periods[0].cash_pay_failure)
        self.assertEqual(result.tranche_periods[1].opening_coupon_arrears, D(0))
        report_tranche_periods(result)

    def test_call_is_real_sale_and_redemption_with_cost_and_no_future_cash(self):
        result = run((receipt("L", 1, CLOSE, FIRST, "100", "0", "2"),
                      receipt("L", 2, FIRST, SECOND, "100", "100", "50")), (note(par="60"),),
                     optional_call_enabled=True, optional_call_date=date(2026, 2, 20),
                     optional_call_collateral_sale_price=D("0.9"), optional_call_cost_pct_of_debt=D("0.01"))
        self.assertEqual(len(result.periods), 1)
        self.assertEqual(result.periods[0].payment_date, FIRST)
        self.assertEqual(result.periods[0].collateral_sale_proceeds, D(90))
        self.assertEqual(result.periods[0].optional_call_costs, D("0.60"))
        self.assertEqual(result.total_equity_distributions, D("31.40"))
        self.assertEqual(result.periods[0].collateral_sale_gain_loss, D(-10))
        self.assertEqual(result.final_collateral_par, D(0))
        self.assertEqual(result.final_debt_par, D(0))
        self.assertEqual(result.periods[0].cash_conservation_residual, D(0))
        report_tranche_periods(result)

    def test_insufficient_call_retains_assets_and_eventual_hold_collections(self):
        result = run((receipt("L", 1, CLOSE, FIRST, "100", "0", "2"),
                      receipt("L", 2, FIRST, SECOND, "100", "100", "2")), (note(par="60"),),
                     optional_call_enabled=True, optional_call_date=FIRST,
                     optional_call_collateral_sale_price=D("0.5"))
        self.assertEqual(result.periods[0].optional_call_status, "INSUFFICIENT_PROCEEDS")
        self.assertEqual(result.periods[0].collateral_sale_proceeds, D(0))
        self.assertEqual(len(result.periods), 2)
        self.assertEqual(result.total_equity_distributions, D(44))

    def test_declined_call_is_not_silently_retried_on_later_payment_dates(self):
        third = date(2026, 10, 20)
        result = run((receipt("L", 1, CLOSE, FIRST, "100", "50", "0"),
                      receipt("L", 2, FIRST, SECOND, "50", "10", "0"),
                      receipt("L", 3, SECOND, third, "40", "40", "10")), (note(par="80"),), final=third,
                     optional_call_enabled=True, optional_call_date=FIRST, optional_call_collateral_sale_price=D("0.5"))
        # The first call is short5. Next date would become fundable at that price,
        # but the requested one-date election has failed; no new election exists.
        self.assertEqual(result.periods[0].optional_call_status, "INSUFFICIENT_PROCEEDS")
        self.assertEqual(result.periods[1].optional_call_status, "NOT_REQUESTED")
        self.assertEqual(len(result.periods), 3)
        self.assertEqual(result.total_equity_distributions, D(30))

    def test_explicit_final_liquidation_sales_long_dated_rights(self):
        third = date(2026, 10, 20)
        result = run((receipt("L", 1, CLOSE, FIRST, "100", "0", "2"),
                      receipt("L", 2, FIRST, SECOND, "100", "0", "2"),
                      receipt("L", 3, SECOND, third, "100", "100", "50")), (note(par="60"),),
                     maturity_liquidation_price=D("0.7"))
        self.assertEqual(result.periods[-1].collateral_sale_par, D(100))
        self.assertEqual(result.periods[-1].collateral_sale_proceeds, D(70))
        self.assertEqual(result.total_equity_distributions, D(14))
        self.assertTrue(result.terminal_value_available)

    def test_liquidation_below_debt_preserves_unsettled_claim(self):
        result = run((receipt("L", 1, CLOSE, FIRST, "100", "0", "0"),
                      receipt("L", 2, FIRST, SECOND, "100", "100", "0")), (note(par="60"),), final=FIRST,
                     maturity_liquidation_price=D("0.5"))
        self.assertEqual(result.final_collateral_par, D(0))
        self.assertEqual(result.final_debt_par, D(10))
        self.assertFalse(result.terminal_value_available)
        self.assertEqual(result.total_equity_distributions, D(0))

    def test_forbidden_long_dated_contract_rejected(self):
        with self.assertRaises(InputValidationError):
            run((receipt("L", 1, CLOSE, SECOND, "100", "100", "0"),), (note(),),
                final=FIRST, allow_long_dated_assets=False)

    def test_refinancing_amends_future_coupon_and_reports_real_equity_fee(self):
        floating = NoteTranche("A", 1, D(60), CouponType.FLOATING, "EURIBOR_3M", D(200), index_floor=D(0))
        result = run((receipt("L", 1, CLOSE, FIRST, "100", "0", "5"),
                      receipt("L", 2, FIRST, SECOND, "100", "100", "5")), (floating,),
                     refinancing_enabled=True, refinancing_date=date(2026, 2, 20),
                     refinancing_spread_reduction=D("0.01"), refinancing_fee_pct_of_debt=D("0.01"))
        self.assertEqual(result.tranche_periods[0].current_coupon_due, D("0.68"))
        self.assertEqual(result.tranche_periods[1].current_coupon_due, D("0.53"))
        self.assertEqual(result.equity_contributions[0].payment_date, FIRST)
        self.assertEqual(result.equity_contributions[0].amount, D("0.60"))
        self.assertEqual(result.total_refinancing_fees, D("0.60"))
        self.assertTrue(all(row.cash_conservation_residual == 0 for row in result.periods))
        equity_rows = report_equity_periods(result, class_id="EQ", payment_priority=2, equity_cash_funding=D(40))
        self.assertEqual(equity_rows[0].equity_capital_contribution, D("0.60"))
        self.assertEqual(equity_rows[0].net_investor_cashflow, D("3.72"))
        self.assertEqual(equity_rows[0].cumulative_equity_cash_funding, D("40.60"))
        self.assertEqual(equity_rows[-1].cumulative_equity_cash_funding, D("40.60"))

    def test_refinancing_reduction_never_turns_margin_negative(self):
        floating = NoteTranche("A", 1, D(60), CouponType.FLOATING, "EURIBOR_3M", D(200), index_floor=D(0))
        result = run((receipt("L", 1, CLOSE, FIRST, "100", "0", "5"),
                      receipt("L", 2, FIRST, SECOND, "100", "100", "5")), (floating,),
                     refinancing_enabled=True, refinancing_date=FIRST, refinancing_spread_reduction=D("0.5"))
        self.assertEqual(result.tranche_periods[1].all_in_rate, D("0.025"))

    def test_acquired_accrued_adds_identified_inherited_coupon_not_par(self):
        request = CloRunRequest((receipt("L", 1, CLOSE, FIRST, "100", "100", "5"),), D(100), (note(par="60"),),
                                CloTerms(CLOSE, FIRST), acquired_accrued_by_loan={"L": D("1.25")})
        result = DeterministicCloEngine(FlatRateProvider({})).run(request)
        self.assertEqual(result.periods[0].received_asset_interest, D("6.25"))
        self.assertEqual(result.total_equity_distributions, D("46.25"))
        self.assertEqual(result.final_collateral_par, D(0))

    def test_acquired_accrued_mapping_is_a_frozen_request_snapshot(self):
        supplied = {"L": D("1.25")}
        request = CloRunRequest((receipt("L", 1, CLOSE, FIRST, "100", "100", "5"),), D(100), (note(par="60"),),
                                CloTerms(CLOSE, FIRST), acquired_accrued_by_loan=supplied)
        supplied["L"] = D(999)
        self.assertEqual(request.acquired_accrued_by_loan["L"], D("1.25"))
        with self.assertRaises(TypeError):
            request.acquired_accrued_by_loan["L"] = D(999)

    def test_defaulted_oc_valuation_does_not_become_sale_cash(self):
        policy = AdjustedCollateralValuePolicy(defaulted_valuation=D("0.5"))
        result = run((receipt("L", 1, CLOSE, FIRST, "100", "100", "0"),), (note(par="60"),), final=FIRST,
                     original_pool_overlay=OriginalPoolOverlay(True, D(1), D(0), D(1), 12),
                     defaulted_asset_oc_treatment=DefaultedAssetOcTreatment.ADJUSTED_POLICY,
                     adjusted_oc_policy=policy, maturity_liquidation_price=D(1))
        self.assertEqual(result.coverage_tests[0].oc_numerator, D(50))
        self.assertEqual(result.periods[0].collateral_sale_proceeds, D(0))
        self.assertEqual(result.periods[0].collateral_sale_par, D(100))
        self.assertEqual(result.final_debt_par, D(60))
        self.assertEqual(result.final_defaulted_par, D(0))
        self.assertFalse(result.terminal_value_available)

    def test_original_overlay_full_default_and_zero_recovery_lag_conserve(self):
        result = run((receipt("L", 1, CLOSE, FIRST, "100", "100", "5"),), (note(par="60"),),
                     original_pool_overlay=OriginalPoolOverlay(True, D(1), D(0), D("0.8"), 0))
        self.assertEqual(result.periods[0].newly_defaulted_par, D(100))
        self.assertEqual(result.periods[0].recovery_principal_received, D(80))
        self.assertEqual(result.periods[0].recognized_par_loss, D(20))
        self.assertEqual(result.final_defaulted_par, D(0))
        self.assertEqual(result.final_collateral_par, D(0))
        self.assertIsNotNone(result.original_overlay_projection)
        self.assertEqual(result.periods[0].cash_conservation_residual, D(0))

    def test_synthetic_discount_purchase_increases_par_without_extra_cash(self):
        policy = SyntheticReinvestmentPolicy(True, FIRST, spread_bps=D(0), purchase_price=D("0.5"),
                                             bullet_wal_years=D("0.25"), annual_prepayment_rate=D(0), annual_default_rate=D(0))
        result = run((receipt("L", 1, CLOSE, FIRST, "100", "50", "0"),
                      receipt("L", 2, FIRST, SECOND, "50", "50", "0")), (note(par="60"),),
                     synthetic_reinvestment_policy=policy)
        self.assertEqual(result.periods[0].reinvestment_cash_used, D(50))
        self.assertEqual(result.periods[0].reinvestment_par_acquired, D(100))
        self.assertEqual(result.periods[0].closing_collateral_par, D(150))
        self.assertEqual(result.periods[0].debt_principal_from_principal, D(0))
        self.assertEqual(result.final_collateral_par, D(0))
        self.assertEqual(result.periods[1].scheduled_principal_received, D(150))
        self.assertEqual(len(result.reinvestment_purchases), 1)
        self.assertTrue(all(row.cash_conservation_residual == 0 for row in result.periods))
        first_end = next(row for row in result.coverage_tests if row.period_number == 1 and row.stage == "PERIOD_END")
        self.assertEqual(first_end.oc_numerator, D(150))
        self.assertEqual(first_end.oc_ratio, D("2.5"))

    def test_imported_independent_par_reduction_and_principal_cash_are_not_equalized(self):
        imported = compile_imported_cashflows(CollateralCashflowInputMode.SIMPLIFIED, CLOSE, D(100),
                    simplified_rows=(SimplifiedImportedCashflow(FIRST, D(0), D(20), performing_par_reduction=D(100)),), credit_effects_included=True)
        result = DeterministicCloEngine(FlatRateProvider({})).run(CloRunRequest((), D(100), (note(par="60"),), CloTerms(CLOSE, FIRST), imported_collateral=imported))
        self.assertEqual(result.final_collateral_par, D(0))
        self.assertEqual(result.final_debt_par, D(40))
        self.assertEqual(result.periods[0].collateral_non_cash_par_change, D(-80))
        self.assertEqual(result.periods[0].cash_conservation_residual, D(0))

    def test_imported_pik_is_a_non_cash_par_increase(self):
        imported = compile_imported_cashflows(CollateralCashflowInputMode.DETAILED, CLOSE, D(100), detailed_rows=(
                    DetailedImportedCashflow("L", 1, FIRST, D(100), D(0), D(0), D(105), D(0), pik_interest=D(5)),
                    DetailedImportedCashflow("L", 2, SECOND, D(105), D(0), D(105), D(0), D(105))))
        result = DeterministicCloEngine(FlatRateProvider({})).run(CloRunRequest((), D(100), (note(par="60"),), CloTerms(CLOSE, SECOND), imported_collateral=imported))
        self.assertEqual(result.periods[0].closing_collateral_par, D(105))
        self.assertEqual(result.periods[0].collateral_non_cash_par_change, D(5))
        self.assertEqual(result.total_equity_distributions, D(45))

    def test_df_cash_interest_uses_forward_holding_interval_after_receipt(self):
        paid = date(2026, 3, 20)
        curve = DiscountFactorCashCurve("ESTR", CLOSE, (ZeroRatePoint(D(1), D("0.1")),),
                                        ZeroCompounding.ANNUAL_EFFECTIVE, DayCount.ACT_365F)
        provider = CashCurveRateProvider(FlatRateProvider({}), {"ESTR": curve})
        terms = CloTerms(CLOSE, FIRST, cash_account_accrual_mode=CashAccountAccrualMode.DF_FORWARD_SIMPLE,
                         cash_account_rate_index="ESTR", cash_account_day_count=DayCount.ACT_365F)
        result = DeterministicCloEngine(provider).run(CloRunRequest((receipt("L", 1, CLOSE, paid, "100", "100", "0"),), D(100), (note(par="60"),), terms))
        # 31 actual cash days: annual effective10% compound, 100*(1.1**(31/365)-1)=.8128... ->.81.
        self.assertEqual(result.periods[0].cash_account_interest, D("0.81"))
        self.assertEqual(result.total_equity_distributions, D("40.81"))
        self.assertIsNone(result.periods[0].cash_account_all_in_rate)

    def test_df_cash_requires_explicit_curve_provider(self):
        terms = CloTerms(CLOSE, FIRST, cash_account_accrual_mode=CashAccountAccrualMode.DF_FORWARD_SIMPLE, cash_account_rate_index="ESTR")
        with self.assertRaises(InputValidationError):
            DeterministicCloEngine(FlatRateProvider({})).run(CloRunRequest((receipt("L", 1, CLOSE, date(2026, 3, 20), "100", "100", "0"),), D(100), (note(par="60"),), terms))

    def test_payment_date_fixing_anchor_is_independent_from_coupon_start(self):
        class RecordingProvider:
            def __init__(self):
                self.calls = []
            def rate(self, index, fixing_date):
                self.calls.append((index, fixing_date))
                return D("0.01")
        provider = RecordingProvider()
        floating = NoteTranche("A", 1, D(60), CouponType.FLOATING, "EURIBOR_1M", D(100))
        terms = CloTerms(CLOSE, FIRST, independent_note_reference_tenor=True,
                         fixing_calendar=CalendarName.WEEKENDS_ONLY, fixing_date_anchor=FixingDateAnchor.PAYMENT_DATE)
        result = DeterministicCloEngine(provider).run(CloRunRequest((receipt("L", 1, CLOSE, FIRST, "100", "100", "5"),), D(100), (floating,), terms))
        self.assertEqual(provider.calls, [("EURIBOR_1M", date(2026, 4, 16))])
        self.assertEqual(result.tranche_periods[0].fixing_date, date(2026, 4, 16))
        self.assertEqual(result.tranche_periods[0].current_coupon_due, D("0.30"))

    def test_fixed_only_first_stub_ignores_floating_override_and_interpolation(self):
        class NoReferenceProvider:
            def rate(self, index, fixing_date):
                raise AssertionError("Fixed-only note coupons must not request a floating reference")
        first = date(2026, 3, 20)
        final = date(2026, 6, 20)
        rows = (receipt("L", 1, CLOSE, first, "100", "0", "1"),
                receipt("L", 2, first, date(2026, 6, 22), "100", "100", "5"))
        terms = CloTerms(CLOSE, final, stub_convention=StubConvention.SHORT_FIRST,
                         first_payment_date_unadjusted=first)
        engine = DeterministicCloEngine(NoReferenceProvider())
        baseline = engine.run(CloRunRequest(rows, D(100), (note(par="80", rate="0.04"),), terms))
        self.assertEqual([row.current_coupon_due for row in baseline.tranche_periods], [D("0.52"), D("0.84")])
        self.assertEqual(baseline.total_equity_distributions, D("24.64"))
        for method, override in ((FirstStubRateMethod.USER_OVERRIDE, D("0.9")),
                                 (FirstStubRateMethod.INTERPOLATE_1M_3M_6M, None)):
            with self.subTest(method=method):
                actual = engine.run(CloRunRequest(rows, D(100), (note(par="80", rate="0.04"),),
                                                 replace(terms, first_stub_rate_method=method,
                                                         first_stub_rate_override=override)))
                self.assertEqual(actual, baseline)

    def test_call_cost_base_excludes_ordinary_same_day_redemption(self):
        result = run((receipt("L", 1, CLOSE, FIRST, "100", "50", "0"),
                      receipt("L", 2, FIRST, SECOND, "50", "50", "0")), (note(par="60"),),
                     optional_call_enabled=True, optional_call_date=FIRST,
                     optional_call_collateral_sale_price=D(1), optional_call_cost_pct_of_debt=D("0.01"))
        self.assertEqual(result.periods[0].optional_call_costs, D("0.10"))
        self.assertEqual(result.total_equity_distributions, D("39.90"))

    def test_refi_fee_base_excludes_ordinary_same_day_redemption(self):
        result = run((receipt("L", 1, CLOSE, FIRST, "100", "50", "0"),
                      receipt("L", 2, FIRST, SECOND, "50", "50", "0")), (note(par="60"),),
                     refinancing_enabled=True, refinancing_date=FIRST, refinancing_fee_pct_of_debt=D("0.01"))
        self.assertEqual(result.equity_contributions[0].amount, D("0.10"))

    def test_infeasible_legal_final_call_falls_back_to_explicit_maturity_sale(self):
        result = run((receipt("L", 1, CLOSE, FIRST, "100", "0", "0"),
                      receipt("L", 2, FIRST, SECOND, "100", "100", "0")), (note(par="60"),), final=FIRST,
                     optional_call_enabled=True, optional_call_date=FIRST,
                     optional_call_collateral_sale_price=D("0.3"), optional_call_cost_pct_of_debt=D("0.1"),
                     maturity_liquidation_price=D("0.5"))
        self.assertEqual(result.periods[0].optional_call_status, "MATURITY_LIQUIDATION")
        self.assertEqual(result.periods[0].optional_call_costs, D(0))
        self.assertEqual(result.periods[0].collateral_sale_proceeds, D(50))
        self.assertEqual(result.final_debt_par, D(10))

    def test_imported_original_overlay_preserves_separate_par_cash_bridge(self):
        imported = compile_imported_cashflows(CollateralCashflowInputMode.SIMPLIFIED, CLOSE, D(100),
                    simplified_rows=(SimplifiedImportedCashflow(FIRST, D(0), D(20), performing_par_reduction=D(100)),))
        terms = CloTerms(CLOSE, FIRST, original_pool_overlay=OriginalPoolOverlay(True, D(0), D(0), D(0), 0))
        result = DeterministicCloEngine(FlatRateProvider({})).run(CloRunRequest((), D(100), (note(par="60"),), terms, imported_collateral=imported))
        self.assertEqual(result.final_collateral_par, D(0))
        self.assertEqual(result.final_debt_par, D(40))
        self.assertEqual(result.periods[0].collateral_non_cash_par_change, D(-80))

    def test_imported_stressed_source_rejects_second_overlay(self):
        imported = compile_imported_cashflows(CollateralCashflowInputMode.SIMPLIFIED, CLOSE, D(100),
                    simplified_rows=(SimplifiedImportedCashflow(FIRST, D(0), D(100)),), credit_effects_included=True)
        terms = CloTerms(CLOSE, FIRST, original_pool_overlay=OriginalPoolOverlay(True, D("0.1")))
        with self.assertRaises(InputValidationError):
            DeterministicCloEngine(FlatRateProvider({})).run(CloRunRequest((), D(100), (note(par="60"),), terms, imported_collateral=imported))

    def test_synthetic_defaults_recovery_and_sale_claims_conserve(self):
        policy = SyntheticReinvestmentPolicy(True, FIRST, spread_bps=D(0), purchase_price=D(1), bullet_wal_years=D(1),
                                             annual_prepayment_rate=D(0), annual_default_rate=D(1), recovery_rate=D("0.8"), recovery_lag_months=0)
        result = run((receipt("L", 1, CLOSE, FIRST, "100", "50", "0"),
                      receipt("L", 2, FIRST, SECOND, "50", "50", "0")), (note(par="60"),),
                     synthetic_reinvestment_policy=policy)
        self.assertEqual(result.periods[1].newly_defaulted_par, D(50))
        self.assertEqual(result.periods[1].recovery_principal_received, D(40))
        self.assertEqual(result.periods[1].recognized_par_loss, D(10))
        self.assertEqual(result.final_defaulted_par, D(0))
        self.assertEqual(result.final_collateral_par, D(0))
        self.assertTrue(all(row.cash_conservation_residual == 0 for row in result.periods))

    def test_synthetic_reinvestment_stops_at_failed_gate(self):
        policy = SyntheticReinvestmentPolicy(True, FIRST, spread_bps=D(0), purchase_price=D(1), bullet_wal_years=D("0.25"),
                                             annual_prepayment_rate=D(0), annual_default_rate=D(0))
        result = run((receipt("L", 1, CLOSE, FIRST, "100", "50", "5"),
                      receipt("L", 2, FIRST, SECOND, "50", "50", "5")), (note(par="60", oc_minimum=D(2)),),
                     synthetic_reinvestment_policy=policy)
        self.assertEqual(result.periods[0].reinvestment_cash_used, D(0))
        self.assertEqual(len(result.reinvestment_purchases), 0)

    def test_synthetic_reinvestment_can_override_test_gate_explicitly(self):
        policy = SyntheticReinvestmentPolicy(True, FIRST, spread_bps=D(0), purchase_price=D(1), bullet_wal_years=D("0.25"),
                                             annual_prepayment_rate=D(0), annual_default_rate=D(0), test_gate=ReinvestmentTestGate.ALWAYS_REINVEST)
        result = run((receipt("L", 1, CLOSE, FIRST, "100", "50", "5"),
                      receipt("L", 2, FIRST, SECOND, "50", "50", "5")), (note(par="60", oc_minimum=D(2)),),
                     synthetic_reinvestment_policy=policy)
        self.assertEqual(result.periods[0].reinvestment_cash_used, D(50))
        self.assertEqual(len(result.reinvestment_purchases), 1)


class AdjustedCollateralTests(unittest.TestCase):
    def test_top_down_proxy_and_default_claim_value(self):
        policy = AdjustedCollateralValuePolicy(False, D("0.2"), D("0.075"), D("0.6"), D("0.1"), D("0.8"), D("0.4"), D("0.7"))
        assets = (OcAssetBalance("L", D(20), date(2027, 1, 20), OcAssetData("L")),
                  OcAssetBalance("S", D(80), FIRST, OcAssetData("S")))
        value = policy.value(assets, D(100), D(10), SECOND)
        self.assertEqual(value.ccc_haircut, D(5))
        self.assertEqual(value.discount_haircut, D(2))
        self.assertEqual(value.long_dated_haircut, D(6))
        self.assertEqual(value.collateral_value, D(91))

    def test_overlapping_asset_categories_take_lowest_value_once(self):
        policy = AdjustedCollateralValuePolicy(True, ccc_limit_fraction=D("0.1"), ccc_valuation=D("0.5"),
                                                long_dated_valuation=D("0.7"), discount_price_threshold=D("0.8"))
        assets = (OcAssetBalance("A", D(50), date(2027, 1, 20), OcAssetData("A", True, True, D("0.6"), D("0.5"))),
                  OcAssetBalance("B", D(50), FIRST, OcAssetData("B")))
        value = policy.value(assets, D(100), D(0), SECOND)
        # CCC excess40:40*.5 + remainder10*.6 + safe50 =76.
        self.assertEqual(value.adjusted_performing_par, D(76))
        self.assertEqual(value.overlap_credit, D(31))
        self.assertEqual(value.ccc_haircut, D(20))
        self.assertEqual(value.discount_haircut, D(20))
        self.assertEqual(value.long_dated_haircut, D(15))

    def test_asset_level_missing_data_rejected(self):
        policy = AdjustedCollateralValuePolicy(True)
        with self.assertRaises(InputValidationError):
            run((receipt("L", 1, CLOSE, FIRST, "100", "100", "0"),), (note(par="60"),), adjusted_oc_policy=policy)

    def test_asset_level_synthetic_par_rejects_unknown_cohort_quality(self):
        policy = AdjustedCollateralValuePolicy(True, discount_price_threshold=D("0.8"))
        assets = (OcAssetBalance("L", D(50), SECOND, OcAssetData("L")),)
        with self.assertRaisesRegex(InputValidationError, "explicit asset-level OC classification"):
            policy.value(assets, D(150), D(0), SECOND, synthetic_par=D(100))
        # An identified original pool remains usable; the guard is specific to
        # unsupported classification of acquired synthetic cohort par.
        self.assertEqual(policy.value(assets, D(50), D(0), SECOND).collateral_value, D(50))

    def test_asset_level_reinvestment_purchase_cannot_report_false_oc_pass(self):
        policy = SyntheticReinvestmentPolicy(True, FIRST, spread_bps=D(0), purchase_price=D("0.5"),
                                             bullet_wal_years=D("0.25"), annual_prepayment_rate=D(0), annual_default_rate=D(0))
        request = CloRunRequest(
            (receipt("L", 1, CLOSE, FIRST, "100", "50", "0"),
             receipt("L", 2, FIRST, SECOND, "50", "50", "0")), D(100), (note(par="60"),),
            CloTerms(CLOSE, SECOND, synthetic_reinvestment_policy=policy,
                     adjusted_oc_policy=AdjustedCollateralValuePolicy(True, discount_price_threshold=D("0.8"))),
            oc_asset_data=(OcAssetData("L"),),
        )
        # Buy50 cash at50% would create100 par, below the80% discount threshold.
        # The missing cohort metadata must fail before a misleading post-trade
        # coverage ratio is returned to Excel or the optimization evaluator.
        with self.assertRaisesRegex(InputValidationError, "explicit asset-level OC classification"):
            DeterministicCloEngine(FlatRateProvider({"EURIBOR_3M": D(0)})).run(request)

    def test_value_extreme_context_preserves_cents(self):
        policy = AdjustedCollateralValuePolicy(False, ccc_fraction=D("0.2"), ccc_limit_fraction=D("0.1"), ccc_valuation=D("0.8"))
        with localcontext() as context:
            context.prec = 4
            context.traps[Inexact] = True
            value = policy.value((), D("100000000.01"), D(0), SECOND)
        self.assertEqual(value.adjusted_performing_par, D("98000000.01"))


if __name__ == "__main__":
    unittest.main()
