"""Translate calculated financial evidence into compact Excel report records.

No financial posting, coverage test or return is implemented in Excel. This
module joins immutable outputs once; the package writer only filters these
saved complete cases. Missing measurements remain 'n.a.', never a zero/pass.
"""
from collections import defaultdict
from dataclasses import fields
from datetime import datetime, timezone
from decimal import Decimal
from enum import Enum
from fractions import Fraction

from trident.analysis import PortfolioAnalyzer
from trident.clo.reporting import report_equity_periods, report_tranche_periods
from trident.domain.numeric import decimal_fraction, post_currency
from . import excel_schema as schema
from .model_records import flat_record

NA = 'n.a.'
PREFIX = 'tbl_trident_ui_'

# Existing metric labels are presentation aliases, not alternate calculations.
# Central ownership prevents display wording from changing the denominator.
METRIC_LABELS = {
 'WAS_BPS':'WAS','WAC_RATE':'WAC','ALL_ASSET_SPREAD_BPS':'All-asset spread',
 'WARR':'Warr','BSL_WARR':'Bsl warr','INFRA_WARR':'Infra warr',
 'SENIOR_FRACTION':'Senior share','SECURED_FRACTION':'Secured share',
 'PIK_FRACTION':'Pik share','REVOLVER_FRACTION':'Revolver share',
 'CONSTRUCTION_FRACTION':'Construction share',
 'WEIGHTED_AVERAGE_MATURITY_YEARS':'Weighted average maturity',
 'LONG_DATED_FRACTION':'Long dated share','WARF':'WARF (agency)',
 'RATING_FACTOR_COVERAGE_FRACTION':'Rating factor coverage share',
 'BSL_WARF':'BSL WARF (agency)','INFRA_WARF':'Infra WARF (agency)',
 'TEST_FACTOR_AVERAGE':'Synthetic test factor','BSL_TEST_FACTOR_AVERAGE':'BSL synthetic test factor',
 'INFRA_TEST_FACTOR_AVERAGE':'Infra synthetic test factor','WAL_YEARS':'Collateral WAL',
}
for _dimension in PortfolioAnalyzer.DIMENSIONS:
    METRIC_LABELS['LARGEST_'+_dimension.upper()+'_FRACTION']='Largest '+_dimension.replace('_',' ')+' share'


def available(value):
    """Display blanks and financial unavailability deliberately differently."""
    return NA if value is None else value.value if isinstance(value,Enum) else value


def _rows(values, columns):
    return tuple({c: available(getattr(value,c,None)) for c in columns} for value in values)


def _sum(values):
    return post_currency(sum((Fraction(v) for v in values),Fraction()))


def case_tables(case, inputs):
    """Build current whole-case reports, with complete detail behind each view."""
    request,result=case.request,case.result
    projection,portfolio,clo=result.cashflows,result.opening_portfolio,result.clo
    periods=() if clo is None else clo.periods
    out={}
    def put(key, rows): out[PREFIX+key]=tuple(rows)
    metrics={m.name:m for m in portfolio.metrics}
    def metric(name): return available(metrics[name].value) if name in metrics else NA
    funding=projection.funding
    equity_cost=abs(result.equity_cashflows[0].amount) if result.equity_cashflows else None
    summary=[('Equity IRR',result.equity_irr.value,'annual return',result.equity_irr.status.value),
             ('Equity MOIC',result.equity_moic.value,'multiple',result.equity_moic.status.value),
             ('Current equity value' if request.clo_opening_state else 'Equity funding',equity_cost,'EUR','AVAILABLE' if equity_cost is not None else 'NOT_APPLICABLE'),
             ('Total equity distributions',None if clo is None else clo.total_equity_distributions,'EUR','AVAILABLE' if clo else 'NOT_SELECTED'),
             ('Collateral face',projection.opening_collateral_par,'EUR','AVAILABLE'),
             ('Asset count',projection.asset_count,'count','AVAILABLE'),
             ('WAS',metric('WAS_BPS'),'bps',metrics['WAS_BPS'].status.value),
             ('Collateral WAL',metric('WAL_YEARS'),'years',metrics['WAL_YEARS'].status.value),
             ('Agency WARF',metric('WARF'),'rating factor',metrics['WARF'].status.value),
             ('Synthetic test factor',metric('TEST_FACTOR_AVERAGE'),'synthetic factor',metrics['TEST_FACTOR_AVERAGE'].status.value),
             ('Opening legal tests unavailable',sum(l.status.value=='UNAVAILABLE' for l in portfolio.limits),'count','REVIEW REQUIRED' if any(l.status.value=='UNAVAILABLE' for l in portfolio.limits) else 'AVAILABLE')]
    put('dashboard',({'Metric':k,'Saved Base Case':available(v),'Unit':u,'Data status':s} for k,v,u,s in summary))
    put('metrics',({'Metric':METRIC_LABELS.get(m.name,m.name),'Value':available(m.value),'Unit':m.unit,'Coverage':m.coverage,'Data status':m.status.value} for m in portfolio.metrics))
    put('limit_results',({'Limit':l.limit_id,'Value':available(l.value),'Threshold':l.threshold,'Headroom':available(l.headroom),'Result':l.status.value} for l in portfolio.limits))
    put('concentrations',({'Dimension':c.dimension,'Bucket':c.bucket or 'Unknown','Face (EUR)':c.par,'Share':c.fraction} for c in portfolio.concentrations))
    put('economics',({'Economics metric':e.metric_id,'Value':available(e.value),'Unit':e.unit,'Numerator':available(e.numerator),'Denominator':available(e.denominator),'Basis':e.basis,'Data status':e.status.value} for e in result.economics))
    cfcolumns=('loan_id','period_number','payment_date','opening_balance','cash_interest','pik_interest','principal_repayment','closing_balance','total_cash','currency','accrual_start','accrual_end','index_rate','spread_bps','all_in_rate','day_count_fraction')
    cfheaders=('Asset ID','Period','Payment date','Opening face','Cash interest','PIK interest','Principal','Closing face','Total cash','Currency','Accrual start','Accrual end','Base rate','Spread (bps)','All-in rate','DCF')
    put('asset_cashflows',({h:available(getattr(row,c,None)) for h,c in zip(cfheaders,cfcolumns)} for row in projection.cashflows))
    # Contractual asset rows remain references under stress; the waterfall uses
    # actual stressed collections. Keeping both avoids double-counted defaults.
    class_rows=[]
    if clo is not None:
        class_rows.extend({**flat_record(r),'instrument_type':'DEBT'} for r in report_tranche_periods(clo))
        residual=next(c for c in inputs.capital if c['instrument_type']=='EQUITY')
        class_rows.extend(flat_record(r) for r in report_equity_periods(clo,class_id=residual['class_id'],payment_priority=int(residual['payment_priority']),equity_cash_funding=equity_cost))
    class_rows.sort(key=lambda r:(r['period_number'],r['payment_priority']))
    classcols=schema.TABLE_COLUMNS['tranche_waterfall']
    waterfall=tuple({'Record key':str(r['class_id'])+'|'+str(r['period_number']),**{k:available(r.get(k)) for k in classcols}} for r in class_rows)
    put('waterfall_records',waterfall)
    accounts=_rows(periods,schema.TABLE_COLUMNS['clo_periods'])
    put('account_records',accounts);put('view_accounts',accounts)
    put('debt_chart',({'Period':p.period_number,'Opening debt':p.opening_debt_par,'Closing debt':p.closing_debt_par} for p in periods))
    put('view_amortization',({'Period':p.period_number,'Date':p.payment_date,'Label':p.payment_date.strftime('%b %y'),'Opening collateral':p.opening_collateral_par,'Closing collateral':p.closing_collateral_par,'Opening debt':p.opening_debt_par,'Closing debt':p.closing_debt_par,'Scheduled principal':p.scheduled_principal_received,'Principal received':p.received_asset_principal,'Debt principal paid':_sum((p.debt_principal_from_interest,p.debt_principal_from_principal))} for p in periods))
    equity=[]
    if result.equity_cashflows:
        equity.append({'Equity cash date':projection.projection_start_date,'Cashflow (EUR)':result.equity_cashflows[0].amount,'Source':'CURRENT_EQUITY_VALUE' if request.clo_opening_state else 'INITIAL_EQUITY_FUNDING'})
        equity.extend({'Equity cash date':r.payment_date,'Cashflow (EUR)':r.amount,'Source':'PROJECTED_NET_INVESTOR_CASHFLOW'} for r in result.equity_cashflows[1:])
    put('equity_cashflows',equity)
    cumulative=Fraction();cumulative_net=-Fraction(equity_cost or 0)
    eqview=[]
    if equity_cost is not None:
        eqview.append({'Period':0,'Date':projection.projection_start_date,'Label':'Opening' if request.clo_opening_state else 'Closing','Initial funding':-equity_cost,'Interest distribution':Decimal(0),'Principal distribution':Decimal(0),'Reserve distribution':Decimal(0),'Distribution':Decimal(0),'Net cashflow':-equity_cost,'Cumulative distribution':Decimal(0),'Cumulative net cashflow':-equity_cost})
    for p in periods:
        dist=_sum((p.equity_from_interest,p.equity_from_principal,p.equity_from_reserve))
        contribution=_sum(r.amount for r in clo.equity_contributions if r.payment_date==p.payment_date)
        net=_sum((dist,-contribution));cumulative+=Fraction(dist);cumulative_net+=Fraction(net)
        eqview.append({'Period':p.period_number,'Date':p.payment_date,'Label':p.payment_date.strftime('%b %y'),'Initial funding':-contribution,'Interest distribution':p.equity_from_interest,'Principal distribution':p.equity_from_principal,'Reserve distribution':p.equity_from_reserve,'Distribution':dist,'Net cashflow':net,'Cumulative distribution':post_currency(cumulative),'Cumulative net cashflow':post_currency(cumulative_net)})
    put('view_equity',eqview)
    coverage=[]
    for r in class_rows:
        if r['instrument_type']!='DEBT': continue
        coverage.append(dict(zip(('Key','Period','Date','Tranche','Opening face','Closing face','Gate OC status','Gate OC ratio','OC minimum','Gate IC status','Gate IC ratio','IC minimum','End OC status','End OC ratio','End IC status','End IC ratio'),
            (r['class_id']+'|'+str(r['period_number']),r['period_number'],r['payment_date'],r['class_id'],r['opening_balance'],r['closing_balance'],'BLOCKED' if r['interest_gate_blocked'] and not r['gate_evaluated'] else available(r['gate_oc_status']),available(r['gate_oc_ratio']),available(r['oc_minimum']),'BLOCKED' if r['interest_gate_blocked'] and not r['gate_evaluated'] else available(r['gate_ic_status']),available(r['gate_ic_ratio']),available(r['ic_minimum']),available(r['period_end_oc_status']),available(r['period_end_oc_ratio']),available(r['period_end_ic_status']),available(r['period_end_ic_ratio'])))))
    put('view_coverage',coverage)
    minima=[]
    for note in request.notes:
        rows=[r for r in class_rows if r['class_id']==note.class_id]
        m={'Tranche':note.class_id}
        for kind in ('oc','ic'):
            active=[r for r in rows if r.get('gate_evaluated') is True and r.get('gate_'+kind+'_ratio') is not None and r.get(kind+'_minimum') is not None and r.get('gate_'+kind+'_status') in {'PASS','FAIL'}]
            lowest=min(active,key=lambda r:Fraction(r['gate_'+kind+'_ratio'])-Fraction(r[kind+'_minimum'])) if active else None
            m['Minimum gate '+kind.upper()+' headroom']=NA if lowest is None else decimal_fraction(Fraction(lowest['gate_'+kind+'_ratio'])-Fraction(lowest[kind+'_minimum']))
            m['Minimum gate '+kind.upper()+' date']=NA if lowest is None else lowest['payment_date']
        m['Redemption period']=next((r['period_number'] for r in rows if r['opening_balance']>0 and r['closing_balance']==0),NA)
        minima.append(m)
    put('view_coverage_minima',minima)
    scope_rows=[];scope_metrics=[];composition=[]
    by_id={r['loan_id']:r for r in inputs.library_assets}
    from trident.application.coupon_timeline import CouponTimeline
    effective_exposures=CouponTimeline(request.cashflow_request.positions).at(request.exposures,projection.projection_start_date)
    for scope in ('Whole','BSL','INFRA'):
        exposures=tuple(e for e in effective_exposures if scope=='Whole' or e.asset_class==scope)
        ids={e.loan_id for e in exposures};cashflows=tuple(r for r in projection.cashflows if r.loan_id in ids)
        report=portfolio if scope=='Whole' else PortfolioAnalyzer().analyze(exposures,projection.projection_start_date,cashflows,request.factor_mapping)
        sm={m.name:m for m in report.metrics};value=lambda k:available(sm[k].value)
        total=sum((Fraction(e.par) for e in exposures),Fraction())
        scope_rows.append({'scope':scope,'asset_count':len(exposures),'opening_face':post_currency(total),'whole_face_share':decimal_fraction(total/Fraction(projection.opening_collateral_par)),'was_bps':value('WAS_BPS'),'was_coverage':sm['WAS_BPS'].coverage,'collateral_wal_years_act365f':value('WAL_YEARS'),'wal_status':sm['WAL_YEARS'].status.value,'principal_cashflow_sum':_sum(r.principal_repayment for r in cashflows),'weighted_maturity_years_act365f':value('WEIGHTED_AVERAGE_MATURITY_YEARS'),'agency_warf':value('WARF'),'agency_warf_status':sm['WARF'].status.value,'selected_rating_coverage':decimal_fraction(sum((Fraction(e.par) for e in exposures if e.rating_bucket),Fraction())/total) if total else Decimal(0),'senior_share':value('SENIOR_FRACTION'),'secured_share':value('SECURED_FRACTION'),'pik_share':value('PIK_FRACTION'),'revolver_share':value('REVOLVER_FRACTION'),'construction_share':value('CONSTRUCTION_FRACTION')})
        # Publish each scope's existing measured value and availability
        # together. The UI must not infer AVAILABLE from a template label,
        # nor turn an agency measurement into the synthetic TEST factor.
        scope_metrics.extend({'Key':scope+'|'+m.name,'Scope':scope,'Metric':m.name,
                              'Value':available(m.value),'Data status':m.status.value,'Unit':m.unit}
                             for m in report.metrics)
        scope_metrics.append({'Key':scope+'|ASSET_COUNT','Scope':scope,'Metric':'ASSET_COUNT',
                              'Value':len(exposures),'Data status':'AVAILABLE','Unit':'count'})
        scope_metrics.append({'Key':scope+'|SELECTED_RATING_COVERAGE','Scope':scope,
                              'Metric':'SELECTED_RATING_COVERAGE',
                              'Value':scope_rows[-1]['selected_rating_coverage'] if total else NA,
                              'Data status':'AVAILABLE' if total else 'NOT_APPLICABLE','Unit':'fraction'})
        for dimension in ('sector','country','selected_rating','asset_class','financing_type','credit_status'):
            groups=defaultdict(Fraction)
            for e in exposures:
                bucket=e.rating_bucket if dimension=='selected_rating' else by_id.get(e.loan_id,{}).get('credit_status') if dimension=='credit_status' else getattr(e,dimension)
                groups[bucket or 'Unknown']+=Fraction(e.par)
            ranked=sorted(groups.items(),key=lambda kv:(-kv[1],kv[0]))
            top=ranked[:10]
            if len(ranked)>10: top.append(('Other',sum((v for _,v in ranked[10:]),Fraction())))
            for rank in range(1,12):
                bucket,face=top[rank-1] if rank<=len(top) else ('',Fraction())
                composition.append({'Key':scope+'|'+dimension+'|'+str(rank),'Scope':scope,'Dimension':dimension,'Rank':rank,'Bucket':bucket,'Face':post_currency(face) if bucket else '', 'Share':decimal_fraction(face/total) if bucket and total else ''})
    put('view_scope',scope_rows);put('view_scope_metrics',scope_metrics);put('view_composition',composition)
    notes={n.class_id:n for n in request.notes};issues={i.class_id:i for i in request.cashflow_request.issues}
    stack=[]
    for c in inputs.capital:
        n=notes.get(c['class_id']);issue=issues.get(c['class_id'])
        stack.append({'Tranche':c['class_id'],'Priority':c['payment_priority'],'Type':c['instrument_type'],'Face (EUR)':n.opening_balance if n else c['nominal_amount'],'Issue price / 100':available(issue.issue_price_pct if issue else c.get('issue_price_pct')),'Coupon index':available(n.rate_index if n and n.rate_index else None),'Spread (bps)':available(n.spread_bps if n else None),'OC minimum':available(n.oc_minimum if n else None),'IC minimum':available(n.ic_minimum if n else None),'Deferrable':available(n.interest_deferrable if n else None),'PIK rate':available(n.pik_rate_fraction if n else None),'Day count':available(n.day_count.value if n else None),'Calendar':c.get('holiday_calendar',NA)})
    put('view_stack',stack)
    details=[]
    for r in out[PREFIX+'dashboard']:
        details.append({'Group':'Returns / summary','Metric':r['Metric'],'Value':r['Saved Base Case'],'Unit':r['Unit'],'Status':r['Data status'],'Basis / requirement':'Forward from sourced opening value' if request.clo_opening_state else 'Full lifecycle from closing funding','Calculation source':'Python financial service','Snapshot date':projection.projection_start_date})
    for m in portfolio.metrics:
        details.append({'Group':'Portfolio','Metric':METRIC_LABELS.get(m.name,m.name),'Value':available(m.value),'Unit':m.unit,'Status':m.status.value,'Basis / requirement':m.message or 'Opening held par; coverage '+str(m.coverage),'Calculation source':'PortfolioAnalyzer','Snapshot date':portfolio.as_of_date})
    for e in result.economics:
        details.append({'Group':'Economics','Metric':e.metric_id,'Value':available(e.value),'Unit':e.unit,'Status':e.status.value,'Basis / requirement':e.basis,'Calculation source':'Numerator '+str(e.numerator)+'; denominator '+str(e.denominator),'Snapshot date':projection.projection_start_date})
    put('analysis_details',details)
    # Complete dated analytical/credit audit records live in one hidden Results
    # sheet. They support drill-down without multiplying visible user tabs.
    reports=result.portfolio_observations or (portfolio,*result.portfolio_snapshots)
    audit={
      'portfolio_metrics':tuple({'as_of_date':r.as_of_date,'phase':r.phase,**flat_record(m)} for r in reports for m in r.metrics),
      'limit_tests':tuple({'as_of_date':r.as_of_date,'phase':r.phase,**flat_record(m)} for r in reports for m in r.limits),
      'concentrations':tuple({'as_of_date':r.as_of_date,'phase':r.phase,**flat_record(m)} for r in reports for m in r.concentrations),
      'credit_collections':tuple(flat_record(r) for p in result.credit_projections for r in p.collections),
      'asset_par_movements':tuple(flat_record(r) for p in result.credit_projections for r in p.par_movements),
      'coverage_tests':() if clo is None else tuple(flat_record(r) for r in clo.coverage_tests),
      'reinvestment_purchases':() if clo is None else tuple(flat_record(r) for r in clo.reinvestment_purchases),
      'reinvestment_par_movements':() if clo is None else tuple(flat_record(r) for r in clo.reinvestment_par_movements),
    }
    return out,audit


def comparison_records(run):
    """Preserve full metric/period comparison scope, not only headline IRR."""
    return tuple({'Scenario':r.scenario_id,'Metric':r.metric if r.identifier is None else r.metric+'|'+r.identifier,
                  'Base':available(r.baseline_value),'Scenario result':available(r.scenario_value),
                  'Difference':available(r.delta),'Unit':r.unit,'Status':r.delta_status} for r in run.comparisons)


# Display precision is independent of stored Decimal precision. Keep the same
# conventions for visible readers, hidden complete cases and chart source rows.
DATE_FORMAT = 'dd-mmm-yyyy'
FACE_FORMAT = '#,##0;(#,##0);–'
CASH_FORMAT = '#,##0.00;(#,##0.00);–'


def number_formats(headers):
    """Infer formats only for columns whose names establish their units.

    Principal *receipts/payments* are cash, whereas face/par is inventory.
    Specific cash names therefore take precedence over broad collateral names;
    a collateral sale's proceeds and gain/loss must retain cents. Mixed Value
    columns are deliberately absent here and are formatted by each record's
    declared metric/unit after publication, including unavailable observations.
    """
    cash_fields = {
        'eligible_asset_principal', 'debt_principal_from_principal',
        'equity_from_principal', 'equity_from_reserve', 'reserve_opening',
        'reserve_draw', 'reserve_release', 'reserve_closing',
        'interest_diversion_test_transferred', 'interest_diversion_test_held_principal',
        'collateral_sale_proceeds', 'collateral_sale_gain_loss',
        'total_collateral_sale_proceeds', 'refinancing_fee', 'optional_call_costs',
        'incentive_hurdle_balance', 'note_pik_capitalized', 'principal_from_principal',
        'cashflow (eur)', 'cash (eur)', 'initial funding', 'interest distribution',
        'principal distribution', 'reserve distribution', 'distribution',
        'net cashflow', 'cumulative distribution', 'cumulative net cashflow',
        'cash interest', 'pik interest', 'principal', 'total cash',
    }
    face_fields = {
        'par', 'opening debt', 'closing debt', 'opening collateral',
        'closing collateral', 'adjusted_collateral_value', 'oc_numerator',
        'oc_denominator', 'oc_ccc_haircut', 'oc_discount_haircut',
        'oc_long_dated_haircut', 'oc_overlap_credit', 'oc_defaulted_value',
        'reinvestment_par_acquired', 'collateral_non_cash_par_change',
        'interest_diversion_test_oc_numerator', 'interest_diversion_test_oc_denominator',
    }
    result = {}
    for header in headers:
        low = header.lower()
        if low in {'date', 'settlement', 'accrual_start', 'accrual_end',
                   'accrual start', 'accrual end'} or low.endswith((' date', '_date')):
            result[header] = DATE_FORMAT
        elif 'status' in low or low in {'key', 'record key', 'source', 'basis',
                'result', 'metric', 'scope', 'dimension', 'bucket', 'tranche',
                'calendar', 'type', 'label'}:
            result[header] = 'General'
        elif 'par_years' in low:
            result[header] = '#,##0.000'
        elif 'years' in low or low in {'weighted maturity', 'wal'}:
            result[header] = '0.000'
        elif low in {'equity_irr', 'equity_irr_delta', 'fraction'} or low.endswith(
                ('_coverage', '_share', '_fraction', '_rate')) or low in {
                    'share', 'coverage', 'base rate', 'all-in rate', 'pik rate'}:
            result[header] = '0.00%'
        elif low.endswith('_bps') or low in {'spread (bps)', 'price / 100',
                'issue price / 100', 'bid / 100', 'ask / 100'}:
            result[header] = '0.00'
        elif 'ratio' in low or low in {'oc minimum', 'ic minimum', 'oc_minimum',
                'ic_minimum', 'interest_diversion_test_oc_minimum',
                'minimum gate oc headroom', 'minimum gate ic headroom'} or low.endswith(
                    ('_oc_minimum', '_ic_minimum')):
            result[header] = '0.0000"x"'
        elif low == 'equity_moic' or low.endswith('_multiple'):
            result[header] = '0.000"x"'
        elif low in {'factor', 'factor_delta', 'agency_warf'} or low.endswith(
                ('_factor', '_warf')):
            result[header] = '#,##0'
        elif low in cash_fields or low.endswith(('_ic_numerator', '_ic_denominator',
                                                  '_from_principal', '_from_reserve')):
            result[header] = CASH_FORMAT
        elif low in face_fields or 'balance' in low or 'face' in low or low.endswith(
                ('_par', '_oc_numerator', '_oc_denominator')):
            result[header] = FACE_FORMAT
        elif 'period' in low or low in {'rank', 'priority', 'asset_count'}:
            result[header] = '0'
        elif any(word in low for word in ('paid', 'cash', 'arrears', 'due',
                'received', 'proceeds', 'expense', 'interest', 'coupon', 'fee',
                'funding', 'loss', 'contribution')):
            result[header] = CASH_FORMAT
    return result


def unit_format(unit):
    """Use declared units for heterogeneous Value/Threshold/Delta columns.

    Unrecognized units remain General: a new/custom metric must not become a
    percentage merely because nearby rows contain concentration fractions.
    Currency cash keeps cents; explicit inventory units display whole face.
    """
    unit = str(unit or '').strip().lower()
    if unit in {'eur', 'usd', 'gbp', 'currency', 'cash'}:
        return CASH_FORMAT
    if unit in {'par', 'face', 'notional'}:
        return FACE_FORMAT
    if unit in {'annual return', 'annual_return', 'annual_fraction', 'annual_rate',
                'annual rate', 'fraction', 'rate', '%'}:
        return '0.00%'
    if unit in {'multiple', 'ratio'}:
        return '0.000"x"'
    if unit in {'bps', 'basis_points'}:
        return '0.00'
    if unit == 'years' or unit.startswith(('years_', 'year_')):
        return '0.000'
    if unit in {'count', 'integer', 'factor', 'synthetic_factor', 'rating_factor',
                'synthetic factor', 'rating factor'}:
        return '#,##0'
    return 'General'


def metric_format(metric, unit=None):
    """Resolve a metric's display unit without changing its financial value.

    Known monetary face metrics refine a currency unit; funding and payments
    keep cents. Limits often omit a Unit column, so established metric IDs
    provide a bounded fallback. A supplied but unknown unit remains General,
    rather than guessing a legal limit's scale from its label or current value.
    """
    low = str(metric or '').strip().lower().split('|', 1)[0]
    upper = low.upper()
    declared = str(unit or '').strip().lower()
    result = unit_format(declared)
    if result != 'General':
        if declared in {'eur', 'usd', 'gbp', 'currency'} and (
                upper.endswith(('_PAR', '_FACE')) or low.endswith((' par', ' face'))):
            return FACE_FORMAT
        return result
    if declared:
        return 'General'
    if low.startswith('concentration:') or upper.endswith('_FRACTION') or upper in {
            'WARR', 'BSL_WARR', 'INFRA_WARR', 'WAC_RATE'}:
        return '0.00%'
    if upper in {'WARF', 'BSL_WARF', 'INFRA_WARF'} or upper.endswith('TEST_FACTOR_AVERAGE'):
        return '#,##0'
    if 'YEARS' in upper:
        return '0.000'
    if upper.endswith('_BPS'):
        return '0.00'
    return 'General'
