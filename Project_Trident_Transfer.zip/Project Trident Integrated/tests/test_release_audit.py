"""Independent receipt-boundary controls from the financial release audit.

A cash/par bridge proves conservation, not the existence of a cash receipt.
These controls verify that a typed native credit projection cannot introduce a
second coupon merely by balancing its own aggregate totals. Actual external
receipts require their separately sourced import/operational-ledger interfaces.
"""

import unittest
from dataclasses import replace
from datetime import date
from decimal import Decimal

from trident.cashflows.engine import ContractualCashflowEngine
from trident.clo.engine import DeterministicCloEngine
from trident.clo.models import CloRunRequest, CloTerms, NoteTranche
from trident.conventions import AccrualDateBasis, BusinessDayConvention, DayCount
from trident.credit.engine import CreditEventCashflowEngine
from trident.credit.models import AssetCashSource, AssetCollection, PrepaymentEvent
from trident.domain.models import CouponType, InputValidationError, LoanPosition, LoanTerms
from trident.market import FlatRateProvider


D = Decimal
START = date(2026, 4, 1)
FIRST = date(2026, 7, 1)
FINAL = date(2026, 10, 1)
PREPAY = date(2026, 6, 1)


def credit_fixture(event=None, *, horizon=None):
    """Hand contract: 100 EUR at 12% ACT/360; no opening claim or fees."""
    rates = FlatRateProvider({"EURIBOR_3M": D(0)})
    terms = LoanTerms(
        "AUDIT", "EUR", START, FINAL, D(100), CouponType.FIXED,
        fixed_rate=D("0.12"), day_count=DayCount.ACT_360,
        business_day_convention=BusinessDayConvention.UNADJUSTED,
        accrual_date_basis=AccrualDateBasis.UNADJUSTED,
        fixing_lag_business_days=0,
    )
    position = LoanPosition(terms, START, D(100))
    promises = ContractualCashflowEngine(rates).generate(position)
    return CreditEventCashflowEngine(rates).apply(
        position, promises, event, horizon_date=horizon)


def append_interest_only(projection, receipt_date):
    """Create internally balanced evidence without inventing face repayment."""
    receipt = AssetCollection(
        "AUDIT", "EUR", receipt_date, AssetCashSource.PREPAYMENT,
        D(1000), D(0), D(1000))
    return replace(
        projection,
        collections=tuple(sorted((*projection.collections, receipt),
                                 key=lambda item: item.payment_date)),
        total_cash_interest=projection.total_cash_interest + D(1000),
    )


class CreditReceiptBoundaryAuditTests(unittest.TestCase):
    def test_valid_contractual_coupon_and_actual_prepayment_remain_available(self):
        ordinary = credit_fixture()
        # Apr 1-Jul 1 is 91 days; Jul 1-Oct 1 is 92 days. Each payment
        # posts its own coupon exactly once; the full face is paid in October.
        self.assertEqual([item.cash_interest for item in ordinary.collections],
                         [D("3.03"), D("3.07")])
        prepaid = credit_fixture(PrepaymentEvent("AUDIT", PREPAY))
        # Apr 1-Jun 1 is 61 days: 100 * .12 * 61 / 360 = 2.033333...
        self.assertEqual(len(prepaid.collections), 1)
        self.assertEqual((prepaid.collections[0].payment_date,
                          prepaid.collections[0].cash_interest,
                          prepaid.collections[0].principal_collection),
                         (PREPAY, D("2.03"), D(100)))

    def test_absent_credit_event_cannot_create_interest_only_prepayment(self):
        original = credit_fixture()
        with self.assertRaises(InputValidationError):
            append_interest_only(original, date(2026, 8, 1))

    def test_future_credit_event_cannot_create_current_exit_receipt(self):
        original = credit_fixture(PrepaymentEvent("AUDIT", date(2026, 8, 1)),
                                  horizon=date(2026, 6, 15))
        self.assertFalse(original.credit_event_applied)
        with self.assertRaises(InputValidationError):
            append_interest_only(original, date(2026, 6, 1))

    def test_applied_prepayment_cannot_add_another_dated_interest_receipt(self):
        original = credit_fixture(PrepaymentEvent("AUDIT", PREPAY))
        with self.assertRaises(InputValidationError):
            append_interest_only(original, date(2026, 8, 1))

    def test_applied_prepayment_cannot_duplicate_event_date_interest_receipt(self):
        original = credit_fixture(PrepaymentEvent("AUDIT", PREPAY))
        with self.assertRaises(InputValidationError):
            append_interest_only(original, PREPAY)

    def test_event_receipt_date_cannot_be_relabelled_without_dated_par(self):
        original = credit_fixture(PrepaymentEvent("AUDIT", PREPAY))
        shifted = replace(original.collections[0], payment_date=date(2026, 6, 2))
        with self.assertRaises(InputValidationError):
            replace(original, collections=(shifted,))

    def test_correct_event_date_does_not_validate_an_inflated_coupon(self):
        original = credit_fixture(PrepaymentEvent("AUDIT", PREPAY))
        # Correct source/date/par and all total fields still cannot turn
        # 61 days of ACT/360 accrual into the entire 91-day July coupon.
        inflated = replace(original.collections[0], cash_interest=D("3.03"),
                           total_cash=D("103.03"))
        with self.assertRaises(InputValidationError):
            replace(original, collections=(inflated,),
                    total_cash_interest=D("3.03"))

    def test_prepayment_cannot_change_or_omit_the_explicit_day_count(self):
        original = credit_fixture(PrepaymentEvent("AUDIT", PREPAY))
        for convention in (None, "ACT/360", DayCount.ACT_365F):
            with self.subTest(convention=convention):
                with self.assertRaises(InputValidationError):
                    replace(original, contractual_day_count=convention)

    def test_agreeing_full_coupons_do_not_replace_known_partial_day_count(self):
        rates = FlatRateProvider({"EURIBOR_3M": D(0)})
        start, end, exit_date = (date(2026, 1, 1), date(2026, 4, 1),
                                date(2026, 2, 1))
        terms = LoanTerms(
            "COUNT", "EUR", start, end, D(100), CouponType.FIXED,
            fixed_rate=D(".12"), day_count=DayCount.ACT_360,
            business_day_convention=BusinessDayConvention.UNADJUSTED,
            accrual_date_basis=AccrualDateBasis.UNADJUSTED,
            fixing_lag_business_days=0)
        position = LoanPosition(terms, start, D(100))
        promises = ContractualCashflowEngine(rates).generate(position)
        original = CreditEventCashflowEngine(rates).apply(
            position, promises, PrepaymentEvent("COUNT", exit_date))
        self.assertEqual(promises[0].cash_interest, D("3.00"))
        self.assertEqual(original.collections[0].cash_interest, D("1.03"))
        # Both conventions give90/360 over this entire first quarter. Their
        # February exit differs: ACT/360 counts31 days, 30E/360 counts30.
        # Internally consistent alternate evidence is not this known contract.
        alternate_receipt = replace(original.collections[0],
                                    cash_interest=D("1.00"),
                                    total_cash=D("101.00"))
        alternate = replace(original, collections=(alternate_receipt,),
                            total_cash_interest=D("1.00"),
                            contractual_day_count=DayCount.THIRTY_E_360)
        note = NoteTranche("A", 1, D(80), CouponType.FIXED, fixed_rate=D(0))
        clo_terms = CloTerms(start, end,
                             business_day_convention=BusinessDayConvention.UNADJUSTED,
                             accrual_date_basis=AccrualDateBasis.UNADJUSTED,
                             fixing_lag_business_days=0)
        known_request = CloRunRequest(
            promises, D(100), (note,), clo_terms,
            asset_credit_projections=(original,),
            asset_day_counts={"COUNT": DayCount.ACT_360})
        self.assertEqual(DeterministicCloEngine(rates).run(known_request)
                         .total_equity_distributions, D("21.03"))
        with self.assertRaises(InputValidationError):
            DeterministicCloEngine(rates).run(replace(
                known_request, asset_credit_projections=(alternate,)))


if __name__ == "__main__":
    unittest.main()
