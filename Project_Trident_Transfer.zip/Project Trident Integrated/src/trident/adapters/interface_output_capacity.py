"""Reserve native result Table space without inventing financial records.

Capacity is presentation state. Python writes only calculated records; unused
Table rows have no amounts, statuses or display formulas. Dropdown catalogues
keep exact lengths. A source-cell index excludes existing Tables and protects
notes outside them without scanning the entire result sheet for every resize.
"""
from __future__ import annotations

from bisect import bisect_left
from collections import Counter
from dataclasses import dataclass
from pathlib import Path
from typing import TYPE_CHECKING, Iterable, Mapping

from trident.domain.models import InputValidationError
from .interface_package import WorkbookPackage, TableInfo, TABLE_PREFIX, UI_PREFIX, _coordinate, _column, _overlap, _reference, _tag, _bounds


if TYPE_CHECKING:
    from .interface_run import InterfaceRun


@dataclass(frozen=True)
class OutputCapacityPolicy:
    """Initial reserves, not model limits; larger actual records always win."""
    asset_rows: int = 300
    period_rows: int = 60
    tranche_rows: int = 12
    detail_rows: int = 300

    def __post_init__(self) -> None:
        for value in (self.asset_rows, self.period_rows, self.tranche_rows, self.detail_rows):
            if type(value) is not int or value < 1:
                raise InputValidationError('Presentation capacities must be positive integers')


class CapacityWorkbookPackage(WorkbookPackage):
    """Preserve output capacity while recording real populated row counts.

    The base writer retains input/growth/atomic-save protections. This layer
    determines the guarded final capacity before writing records. It never pads records
    with zeros or create formulas for unused capacity. Layout-bound Tables
    reserve only their free lane; genuine records still must fit or publication
    fails in the base writer. Complete backing Tables use independent lanes.
    """
    REGISTRY = TABLE_PREFIX + 'table_capacity'

    def __init__(self, source: str | Path, *, run: InterfaceRun,
                 policy: OutputCapacityPolicy | None = None, **kwargs) -> None:
        super().__init__(source, **kwargs)
        self.capacity_policy = policy or OutputCapacityPolicy()
        self._run = run
        self._row_counts = {}
        self._capacity_modes = {}
        self._requested_rows = {}
        self._reserve_floors = {}
        self._case_count = max(1, len(run.cases))
        counts = Counter(row.loan_id for row in run.baseline.cashflows.cashflows)
        library = getattr(run, 'library_projection', None)
        library_counts = Counter(row.loan_id for row in getattr(library, 'cashflows', ()))
        self._asset_periods = max([1, *counts.values(), *library_counts.values()])
        self._periods = max(self.capacity_policy.period_rows, *(len(c.result.clo.periods) if c.result.clo else 0 for c in run.cases))
        self._tranches = max(self.capacity_policy.tranche_rows, len(run.inputs.capital))
        # Existing native capacity is already owned by its Table. Index notes
        # only when a real extension needs additional worksheet space; an
        # ordinary repeat must not scan every cell of every saved result.
        self._non_table_rows: dict[str, dict[int, tuple[int, ...]]] = {}

    def _unowned_content_index(self, sheet: str) -> dict[int, tuple[int, ...]]:
        """Index non-Table content only on a sheet that actually needs growth.

        All value, formula and inline-text cells protect their occupied rows.
        Formatting-only blanks do not block a reserve. The base writer still
        checks the proposed added rectangle before committing real records.
        """
        part = self._sheet_parts()[sheet]
        by_column: dict[int, list[int]] = {}
        for address, cell in self._sheet_cells(self._xml(part)).items():
            if not any(cell.find(_tag(kind)) is not None for kind in ('f', 'v', 'is')):
                continue
            column, row = _coordinate(address)
            if self._table_intersections(sheet, (column, row, column, row)):
                continue
            by_column.setdefault(column, []).append(row)
        return {column: tuple(sorted(rows)) for column, rows in by_column.items()}

    def _requested_capacity(self, name: str, headers: Iterable[str], count: int) -> int | None:
        """Dimension reserves by record grain, preserving finite choices."""
        suffix = name.removeprefix(TABLE_PREFIX)
        if 'options' in suffix or suffix.startswith('frozen_'):
            return None
        fields = {str(h).lower().replace(' ', '_') for h in headers}
        multiple = self._case_count if fields.intersection({'case', 'result_case'}) else 1
        if 'asset_cashflows' in suffix:
            if suffix.startswith('results_'):
                multiple = self._case_count + 1  # independent library reference
            return max(count, self.capacity_policy.asset_rows * self._asset_periods * multiple)
        has_asset = bool(fields.intersection({'asset_id', 'loan_id'}))
        has_period = bool(fields.intersection({'period', 'period_number', 'payment_date'}))
        has_tranche = bool(fields.intersection({'tranche', 'class_id'}))
        if has_asset and has_period:
            return max(count, self.capacity_policy.asset_rows * self._asset_periods * multiple)
        if has_tranche and has_period:
            return max(count, self._tranches * self._periods * multiple)
        if has_period:
            return max(count, self._periods * multiple)
        if has_tranche:
            return max(count, self._tranches * multiple)
        if has_asset:
            return max(count, self.capacity_policy.asset_rows * multiple)
        return max(count, self.capacity_policy.detail_rows)

    def _free_bottom(self, info: TableInfo, requested_bottom: int) -> int:
        """Bound reserve space by neighbouring Tables, named inputs and notes."""
        left, top, right, bottom = info.bounds
        limit = min(1048576, requested_bottom)
        if limit <= bottom:
            return bottom
        for other in self._tables_by_sheet().get(info.sheet, ()):
            a, b, c, d = other.bounds
            if other.name != info.name and left <= c and right >= a and b > top:
                limit = min(limit, b - 1)
        tree = self._xml(self._sheet_parts()[info.sheet])
        merges = tree.find(_tag('mergeCells'))
        for merge in merges if merges is not None else ():
            a, b, c, d = _bounds(merge.attrib['ref'])
            if left <= c and right >= a and b > top:
                limit = min(limit, b - 1)
        for name in self.protected_names:
            sheet, bounds = self.named_region(name)
            a, b, c, d = bounds
            if sheet == info.sheet and left <= c and right >= a and b > top:
                limit = min(limit, b - 1)
        if limit <= bottom:
            return bottom
        if info.sheet not in self._non_table_rows:
            self._non_table_rows[info.sheet] = self._unowned_content_index(info.sheet)
        for column in range(left, right + 1):
            rows = self._non_table_rows[info.sheet].get(column, ())
            index = bisect_left(rows, bottom + 1)
            if index < len(rows):
                limit = min(limit, rows[index] - 1)
        return max(bottom, limit)

    def write_table(self, name: str, records: Iterable[Mapping[str, object]], **kwargs) -> TableInfo:
        """Write actual results once into their final, guarded native capacity.

        The record count is independent of the Table's reserved range. Keeping
        the final ref throughout a repeat avoids a shrink/grow metadata cycle,
        while the base writer clears stale values beyond the actual record end.
        Options and frozen inputs retain their exact semantic shapes instead.
        """
        records = tuple(records)
        previous = self.table_inventory().get(name)
        if previous is None:
            # Preserve the base API's explicit unknown-Table error.
            return super().write_table(name, records, **kwargs)
        left, top, right, previous_bottom = previous.bounds
        actual_bottom = top + max(1, len(records))
        actual = (left, top, right, actual_bottom)
        merges = self._xml(self._sheet_parts()[previous.sheet]).find(_tag('mergeCells'))
        if any(_overlap(actual, _bounds(m.attrib['ref'])) for m in (merges if merges is not None else ())):
            raise InputValidationError('Result records overlap a merged worksheet rectangle')
        requested = self._requested_capacity(name, previous.headers, len(records))
        if requested is None:
            info = super().write_table(name, records, **kwargs)
            self._capacity_modes[name] = 'EXACT_CATALOGUE_OR_WITNESS'
        else:
            self._requested_rows[name] = requested
            target = max(requested, previous_bottom - top, self._reserve_floors.get(name, 0))
            reserved_bottom = self._free_bottom(previous, top + target)
            # Required records cannot be clipped to a soft reserve boundary.
            # The base rectangle/ownership checks reject any real collision.
            final_bottom = max(actual_bottom, reserved_bottom)
            info = super().write_table(name, records, _reserved_bottom=final_bottom, **kwargs)
            self._reserve_floors[name] = info.bounds[3] - top
            self._capacity_modes[name] = ('RESERVED_OUTPUT' if info.bounds[3] >= top + target
                                         else 'LAYOUT_BOUND_OUTPUT')
        self._row_counts[name] = len(records)
        return info

    def refresh_capacity_registry(self) -> None:
        """Register every Table, including exact semantic structures and itself."""
        headers = ('Table', 'Sheet', 'Role', 'Capacity rows', 'Populated rows', 'Requested rows', 'Capacity mode')
        if self.REGISTRY not in self.table_inventory():
            self.add_table(self.REGISTRY, headers, ())
        # Establish its final native capacity before reporting the registry
        # itself; first publication must not report the initial one-row shell.
        self.write_table(self.REGISTRY, ())
        rows = []
        for name, info in self.table_inventory().items():
            capacity = info.bounds[3] - info.bounds[1]
            if name == self.REGISTRY:
                populated = len(self.table_inventory())
            elif 'frozen_' in name or 'options' in name:
                populated = sum(any(value not in (None, '') for value in row.values()) for row in self._table_records(name))
            elif name in self._row_counts:
                populated = self._row_counts[name]
            else:
                populated = sum(any(value not in (None, '') for value in row.values()) for row in self._table_records(name))
            if name in self.protected_tables:
                role = 'INPUT'
                mode = 'RESERVED_INPUT' if name in {TABLE_PREFIX+x for x in ('assets','asset_terms','asset_details','asset_ratings','pool','trade_universe','principal_schedule','asset_events','stack','limits','scenario_edits','factor_mapping')} else 'FIXED_INPUT_STRUCTURE'
            elif 'frozen_' in name:
                role, mode = 'INPUT_WITNESS', 'MATCH_INPUT_CAPACITY'
            elif 'options' in name:
                role, mode = 'CHOICE_CATALOGUE', 'EXACT_CHOICES'
            else:
                role, mode = 'OUTPUT', self._capacity_modes.get(name, 'FIXED_OUTPUT_STRUCTURE')
            rows.append(dict(zip(headers, (name, info.sheet, role, capacity, populated, self._requested_rows.get(name, capacity), mode))))
        self.write_table(self.REGISTRY, rows, number_formats={'Capacity rows':'#,##0','Populated rows':'#,##0','Requested rows':'#,##0'})
