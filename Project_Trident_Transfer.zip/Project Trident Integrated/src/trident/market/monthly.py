"""Legacy CLO month-bucket semantics for projected term-rate inputs.

Legacy CLO v4.2.2 ``modSchedule.bas`` maps a fixing's year/month to that
month's MarketData row. Node dates are month labels: there is no daily linear
interpolation, no requirement that a label be month-end, and no use of a
projected monthly value as an actual historical fixing.
"""

from __future__ import annotations

from bisect import bisect_left
from dataclasses import dataclass, field
from datetime import date
from decimal import Decimal

from .rates import (
    CurveRangeError,
    ExtrapolationPolicy,
    MissingCurveError,
    ProjectedRateCurve,
    _validate_date,
    _validate_index,
)


def _month_index(value: date) -> int:
    """Convert a calendar month to a consecutive integer, including year rolls."""
    return (value.year - 1) * 12 + value.month - 1


@dataclass(frozen=True, slots=True)
class MonthlyProjectedRateCurve(ProjectedRateCurve):
    """One projected term rate per consecutive calendar-month bucket.

    This is the legacy month lookup, rather than daily interpolation. Every
    date in a node's calendar month uses that node's supplied rate unchanged.
    ``ERROR`` rejects months outside the supplied coverage; explicit ``FLAT``
    extends endpoint-month rates. Neither policy fills a missing middle month.

    The immutable parent node tuple is validated first. Cached month indices
    give logarithmic lookups without rescanning a full monthly input table.
    """

    _month_indices: tuple[int, ...] = field(init=False, repr=False, compare=False)

    def __post_init__(self) -> None:
        # Explicit parent dispatch is safe with slotted dataclass inheritance.
        ProjectedRateCurve.__post_init__(self)
        months = tuple(_month_index(point.fixing_date) for point in self.points)
        for previous, current in zip(months, months[1:]):
            if current == previous:
                raise ValueError("monthly curve requires exactly one point per calendar month")
            if current != previous + 1:
                raise ValueError("monthly curve calendar months must be consecutive without missing months")
        object.__setattr__(self, "_month_indices", months)

    def rate(self, index: str, fixing_date: date) -> Decimal:
        """Return the fixing month's projected rate without interpolating days."""
        _validate_index(index)
        _validate_date(fixing_date, "fixing_date")
        if index != self.index:
            raise MissingCurveError(f"Monthly curve for {self.index!r} cannot supply index {index!r}")
        month = _month_index(fixing_date)
        position = bisect_left(self._month_indices, month)
        if position < len(self.points) and self._month_indices[position] == month:
            return self.points[position].rate
        # Consecutive-month validation means an absent bucket can only be outside
        # the curve. Endpoint extrapolation cannot silently bridge a middle gap.
        if self.extrapolation is ExtrapolationPolicy.ERROR:
            first_month = self.points[0].fixing_date.strftime("%Y-%m")
            last_month = self.points[-1].fixing_date.strftime("%Y-%m")
            raise CurveRangeError(
                f"OUTSIDE_MONTH_RANGE: fixing month {fixing_date.strftime('%Y-%m')} "
                f"is outside {self.index!r} monthly curve {first_month} to {last_month}"
            )
        return self.points[0 if position == 0 else -1].rate
