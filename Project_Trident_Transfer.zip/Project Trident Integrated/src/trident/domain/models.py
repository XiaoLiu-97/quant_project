"""Explicit contract, holding and posting semantics for cash/PIK loans.

Projection starts from an explicit held-par snapshot. Seasoned cash-pay loans
retain their original schedule and require an opening coupon claim and carried
fixing evidence; historical amortisation, arrears, defaults and PIK are never
reconstructed from a par balance.
Historical PIK is supplied in held opening face, never reconstructed from a
current balance. Rates are decimal fractions; spreads are basis points; money
is currency units.
"""

from dataclasses import dataclass
from datetime import date
from decimal import Context, Decimal, ROUND_HALF_EVEN, localcontext
from enum import Enum
from fractions import Fraction

from trident.conventions.calendar import BusinessDayConvention, CalendarName
from trident.conventions.day_count import DayCount
from trident.conventions.schedule import AccrualDateBasis, StubConvention
from trident.domain.numeric import post_currency


class InputValidationError(ValueError):
    """An input is missing, ambiguous or outside the implemented contract."""


def require_decimal(value: object, label: str, *, minimum: Decimal | None = None) -> Decimal:
    """Reject binary floats and non-finite values at the domain boundary."""
    if not isinstance(value, Decimal) or not value.is_finite():
        raise InputValidationError(f"{label} must be a finite Decimal")
    if minimum is not None and value < minimum:
        raise InputValidationError(f"{label} must be >= {minimum}")
    return value


def require_date(value: object, label: str) -> date:
    """Accept a calendar date, never an accidental date-time/timezone value."""
    if type(value) is not date:
        raise InputValidationError(f"{label} must be datetime.date")
    return value


def require_money(value: object, label: str, *, positive: bool = False) -> Decimal:
    """First-release EUR/USD/GBP cash inputs have at most cent precision."""
    money = require_decimal(value, label, minimum=Decimal(0))
    with localcontext(Context(prec=max(34, money.adjusted() + 4), rounding=ROUND_HALF_EVEN)):
        if money != money.quantize(Decimal("0.01")):
            raise InputValidationError(f"{label} must have at most two decimal places")
    if positive and money == 0:
        raise InputValidationError(f"{label} must be positive")
    return money


class CouponType(str, Enum):
    FIXED = "FIXED"
    FLOATING = "FLOATING"


class InterestMode(str, Enum):
    """Contractual settlement of earned coupon, separate from coupon type.

    PIK means payment by adding debt at the contractual accrual boundary;
    MIXED divides one gross coupon between cash and capitalized principal.
    Neither mode describes default-related unpaid interest or a CLO claim.
    """

    CASH = "CASH"
    PIK = "PIK"
    MIXED = "MIXED"


class CouponStepPolicy(str, Enum):
    """When an absolute dated rate level becomes contractual entitlement.

    ACTUAL_DATE changes the fixed coupon or floating margin on that calendar
    date. PAYMENT_START defers fixed changes to the next cash accrual start;
    RESET_START defers margin changes to the next original reference reset.
    None of these policies moves a step date for business-day adjustment.
    """

    ACTUAL_DATE = "ACTUAL_DATE"
    PAYMENT_START = "PAYMENT_START"
    RESET_START = "RESET_START"


@dataclass(frozen=True)
class CouponStep:
    """One replacement level, never a change added to the preceding level.

    Supply exactly one finite Decimal: fixed_rate is an annual fraction;
    spread_bps is a raw contractual margin in basis points. Zero and negative
    levels are valid contract values. LoanTerms checks type, dates and policy.
    """

    effective_date: date
    fixed_rate: Decimal | None = None
    spread_bps: Decimal | None = None

    def __post_init__(self) -> None:
        require_date(self.effective_date, "coupon step effective_date")
        if (self.fixed_rate is None) == (self.spread_bps is None):
            raise InputValidationError("Coupon step requires exactly one fixed_rate or spread_bps level")
        for name in ("fixed_rate", "spread_bps"):
            if getattr(self, name) is not None:
                require_decimal(getattr(self, name), f"coupon step {name}")


class AmortizationType(str, Enum):
    BULLET = "BULLET"
    LINEAR_INITIAL_PAR = "LINEAR_INITIAL_PAR"
    LINEAR_AMOUNT = "LINEAR_AMOUNT"
    LINEAR_AUTO = "LINEAR_AUTO"
    ANNUITY = "ANNUITY"
    ACCELERATED = "ACCELERATED"
    ACCELERATED_AUTO = "ACCELERATED_AUTO"
    BESPOKE = "BESPOKE"


@dataclass(frozen=True)
class PrincipalScheduleEntry:
    """An explicit cent principal amount on an UNADJUSTED accrual boundary.

    ``payment_date`` is the contractual nominal boundary, before business-day
    adjustment. It is deliberately distinct from LoanCashflow.payment_date.
    Zero entries are allowed; missing intermediate boundaries mean zero.
    """

    payment_date: date
    amount: Decimal

    def __post_init__(self) -> None:
        require_date(self.payment_date, "principal schedule payment_date")
        require_money(self.amount, "principal schedule amount")


@dataclass(frozen=True)
class LoanTerms:
    """Contract projection terms, separate from the held opening balance.

    reference_principal is the documented reference for scheduled amortisation,
    not an inferred original facility amount. Blank reset frequency follows
    the payment schedule; a distinct reset frequency rolls from the contract
    start and uses SHORT_LAST. Equal explicit frequency keeps the payment grid.
    Amortisation
    dates and schedule entries use nominal unadjusted accrual boundaries, with
    the first instalment payable on or after amortization_start_date. A projected
    annuity requires an explicit post-level-payment balloon (zero is valid).
    LINEAR_AUTO and ACCELERATED_AUTO calibrate to held opening face and an
    explicit balloon, rather than inferring contractual historical payments.
    Geometric growth is a fraction per eligible principal installment; growth
    1 means each installment doubles. Automatic schedules require contractual
    authorization; otherwise supply explicit amounts or BESPOKE dates.
    Floating reference bounds apply before spread; all-in bounds apply after
    spread. Bounds are annual decimal fractions (0.05 means 5%), None disables
    an endpoint and zero is binding. Fixed-rate contracts reject these fields.
    Coupon steps replace absolute levels and have an explicit date policy;
    they neither re-fix the reference index nor change principal/settlement.
    ACTUAL_DATE steps require an additive day count in this implementation.
    """

    loan_id: str
    currency: str
    start_date: date
    maturity_date: date
    reference_principal: Decimal
    coupon_type: CouponType
    frequency_months: int = 3
    day_count: DayCount = DayCount.ACT_360
    rate_index: str | None = None
    spread_bps: Decimal = Decimal(0)
    fixed_rate: Decimal | None = None
    index_floor: Decimal | None = None
    amortization_type: AmortizationType = AmortizationType.BULLET
    amortization_fraction: Decimal = Decimal(0)
    business_day_convention: BusinessDayConvention = BusinessDayConvention.MODIFIED_FOLLOWING
    accrual_date_basis: AccrualDateBasis = AccrualDateBasis.ADJUSTED
    fixing_lag_business_days: int = 2
    payment_lag_business_days: int = 0
    end_of_month: bool = False
    stub_convention: StubConvention = StubConvention.SHORT_LAST
    amortization_start_date: date | None = None
    scheduled_principal_amount: Decimal | None = None
    amortization_growth: Decimal | None = None
    balloon_amount: Decimal | None = None
    principal_schedule: tuple[PrincipalScheduleEntry, ...] = ()
    first_payment_date: date | None = None
    last_regular_payment_date: date | None = None
    index_cap: Decimal | None = None
    all_in_floor: Decimal | None = None
    all_in_cap: Decimal | None = None
    reset_frequency_months: int | None = None
    coupon_steps: tuple[CouponStep, ...] = ()
    coupon_step_policy: CouponStepPolicy = CouponStepPolicy.ACTUAL_DATE
    interest_mode: InterestMode = InterestMode.CASH
    pik_fraction: Decimal = Decimal(0)
    holiday_calendar: CalendarName = CalendarName.TARGET

    def __post_init__(self) -> None:
        if not isinstance(self.loan_id, str) or not self.loan_id.strip() or self.loan_id != self.loan_id.strip():
            raise InputValidationError("loan_id is required")
        if self.currency not in {"EUR", "USD", "GBP"}:
            raise InputValidationError(f"Unsupported currency: {self.currency}")
        require_date(self.start_date, "start_date")
        require_date(self.maturity_date, "maturity_date")
        if self.maturity_date <= self.start_date:
            raise InputValidationError("maturity_date must follow start_date")
        require_money(self.reference_principal, "reference_principal", positive=True)
        if type(self.frequency_months) is not int or self.frequency_months not in {1, 3, 6, 12}:
            raise InputValidationError("frequency_months must be 1, 3, 6 or 12")
        for value, enum_type, name in (
            (self.coupon_type, CouponType, "coupon_type"),
            (self.day_count, DayCount, "day_count"),
            (self.amortization_type, AmortizationType, "amortization_type"),
            (self.business_day_convention, BusinessDayConvention, "business_day_convention"),
            (self.accrual_date_basis, AccrualDateBasis, "accrual_date_basis"),
            (self.stub_convention, StubConvention, "stub_convention"),
            (self.holiday_calendar, CalendarName, "holiday_calendar"),
        ):
            if not isinstance(value, enum_type):
                raise InputValidationError(f"{name} must be {enum_type.__name__}")
        for lag in (self.fixing_lag_business_days, self.payment_lag_business_days):
            if type(lag) is not int or lag < 0:
                raise InputValidationError("Business-day lags must be non-negative integers")
        if type(self.end_of_month) is not bool:
            raise InputValidationError("end_of_month must be boolean")
        require_decimal(self.spread_bps, "spread_bps")
        if not isinstance(self.interest_mode, InterestMode):
            raise InputValidationError("interest_mode must be InterestMode")
        share = require_decimal(self.pik_fraction, "pik_fraction", minimum=Decimal(0))
        if share > 1:
            raise InputValidationError("pik_fraction must be <= 1")
        if ((self.interest_mode is InterestMode.CASH and share != 0)
                or (self.interest_mode is InterestMode.PIK and share != 1)
                or (self.interest_mode is InterestMode.MIXED and not 0 < share < 1)):
            raise InputValidationError("CASH requires pik_fraction=0, PIK requires 1 and MIXED requires 0<pik_fraction<1")
        if self.interest_mode is not InterestMode.CASH and self.amortization_type is AmortizationType.ANNUITY:
            raise InputValidationError("Projected annuity supports CASH interest only, as in the source contract capability")
        if self.index_floor is not None:
            require_decimal(self.index_floor, "index_floor")
        for name in ("index_cap", "all_in_floor", "all_in_cap"):
            if getattr(self, name) is not None:
                require_decimal(getattr(self, name), name)
        for lower, upper in ((self.index_floor, self.index_cap), (self.all_in_floor, self.all_in_cap)):
            if lower is not None and upper is not None and lower > upper:
                raise InputValidationError("Rate floor cannot exceed cap within the same scope")
        if self.coupon_type is CouponType.FIXED:
            if self.reset_frequency_months is not None:
                raise InputValidationError("Fixed loans cannot specify floating reset frequency")
            require_decimal(self.fixed_rate, "fixed_rate")
            if self.rate_index is not None or self.index_floor is not None or self.spread_bps != 0:
                raise InputValidationError("Fixed loans use fixed_rate only, without index/floor/spread")
            if any(value is not None for value in (self.index_cap, self.all_in_floor, self.all_in_cap)):
                raise InputValidationError("Coupon bounds apply only to floating loans; fixed loans use fixed_rate")
        else:
            reset = self.frequency_months if self.reset_frequency_months is None else self.reset_frequency_months
            overnight_currency = {"ESTR": "EUR", "SOFR": "USD", "SONIA": "GBP"}
            overnight = self.rate_index in overnight_currency
            if overnight:
                if self.currency != overnight_currency[self.rate_index]:
                    raise InputValidationError("Overnight reference index must match the loan currency")
                if self.reset_frequency_months is not None:
                    raise InputValidationError("Projected overnight coupons compound over the payment accrual period; separate term resets are not applicable")
                required_basis = DayCount.ACT_365F if self.rate_index == "SONIA" else DayCount.ACT_360
                if self.day_count is not required_basis:
                    raise InputValidationError("Projected overnight asset coupons require ACT/360 for ESTR/SOFR or ACT/365F for SONIA")
            else:
                if type(reset) is not int or reset not in (1, 3, 6):
                    raise InputValidationError("Term floating reset frequency must be 1, 3 or 6 months")
                if self.currency != "EUR" or self.rate_index != f"EURIBOR_{reset}M":
                    raise InputValidationError("Floating loans require EURIBOR tenor matching reset frequency or currency-matched ESTR/SOFR/SONIA")
            if self.fixed_rate is not None:
                raise InputValidationError("Floating loans cannot specify fixed_rate")
        fraction = require_decimal(self.amortization_fraction, "amortization_fraction", minimum=Decimal(0))
        if fraction > 1:
            raise InputValidationError("amortization_fraction must be <= 1")
        if self.amortization_type is AmortizationType.LINEAR_INITIAL_PAR and fraction == 0:
            raise InputValidationError("Linear amortisation requires an explicit positive fraction")
        if self.amortization_type is not AmortizationType.LINEAR_INITIAL_PAR and fraction != 0:
            raise InputValidationError("Only LINEAR_INITIAL_PAR uses amortization_fraction")
        self._validate_optional_dates()
        self._validate_principal_parameters()
        self._validate_coupon_steps()

    def _validate_coupon_steps(self) -> None:
        """Reject ambiguous levels and unsupported intra-period conventions.

        Start already has an explicit base coupon; maturity has no new accrual
        entitlement. Non-additive thirty-day conventions need a separate
        contract-defined allocation rule for intra-period changes, so only
        boundary-deferred policies are admitted for those conventions. See
        docs/methodology/conventions.md for the hand-computed counterexamples.
        """
        if not isinstance(self.coupon_step_policy, CouponStepPolicy):
            raise InputValidationError("coupon_step_policy must be CouponStepPolicy")
        if type(self.coupon_steps) is not tuple or any(not isinstance(s, CouponStep) for s in self.coupon_steps):
            raise InputValidationError("coupon_steps must be an immutable tuple of CouponStep")
        if not self.coupon_steps:
            if self.coupon_step_policy is not CouponStepPolicy.ACTUAL_DATE:
                raise InputValidationError("A deferred coupon step policy requires explicit coupon_steps")
            return
        dates = tuple(s.effective_date for s in self.coupon_steps)
        if any(not self.start_date < value < self.maturity_date for value in dates):
            raise InputValidationError("Coupon step dates must strictly follow start and precede maturity")
        if any(current <= previous for previous, current in zip(dates, dates[1:])):
            raise InputValidationError("Coupon step dates must be strictly increasing and unique")
        fixed = self.coupon_type is CouponType.FIXED
        if any((s.fixed_rate is not None) != fixed for s in self.coupon_steps):
            raise InputValidationError("Coupon step level type must match the loan coupon type")
        if (fixed and self.coupon_step_policy is CouponStepPolicy.RESET_START
                or not fixed and self.coupon_step_policy is CouponStepPolicy.PAYMENT_START):
            raise InputValidationError("Deferred fixed steps use PAYMENT_START; floating steps use RESET_START")
        if (self.coupon_step_policy is CouponStepPolicy.ACTUAL_DATE and self.day_count in
                (DayCount.THIRTY_360_ISDA, DayCount.THIRTY_U_360_EOM)):
            raise InputValidationError("ACTUAL_DATE coupon steps require an additive day count; use an explicit boundary policy")

    def _validate_optional_dates(self) -> None:
        """Validate date types/ranges; the schedule builder checks actual rolls."""
        for name in ("amortization_start_date", "first_payment_date", "last_regular_payment_date"):
            value = getattr(self, name)
            if value is None:
                continue
            require_date(value, name)
            if not self.start_date <= value <= self.maturity_date:
                raise InputValidationError(f"{name} must lie within the contract dates")
            if name == "first_payment_date" and value == self.start_date:
                raise InputValidationError("first_payment_date must follow start_date")

    def _validate_principal_parameters(self) -> None:
        """Reject unused fields rather than silently applying another policy."""
        kind = self.amortization_type
        if self.scheduled_principal_amount is not None:
            require_money(self.scheduled_principal_amount, "scheduled_principal_amount", positive=True)
        if self.amortization_growth is not None:
            require_decimal(self.amortization_growth, "amortization_growth", minimum=Decimal(0))
        if self.balloon_amount is not None:
            require_money(self.balloon_amount, "balloon_amount")
            if self.balloon_amount > self.reference_principal:
                raise InputValidationError("balloon_amount cannot exceed reference_principal")
        if type(self.principal_schedule) is not tuple or any(
            not isinstance(entry, PrincipalScheduleEntry) for entry in self.principal_schedule
        ):
            raise InputValidationError("principal_schedule must be a tuple of PrincipalScheduleEntry")
        allowed = {
            AmortizationType.BULLET: set(),
            AmortizationType.LINEAR_INITIAL_PAR: {"amortization_start_date", "balloon_amount"},
            AmortizationType.LINEAR_AMOUNT: {"amortization_start_date", "scheduled_principal_amount", "balloon_amount"},
            AmortizationType.LINEAR_AUTO: {"amortization_start_date", "balloon_amount"},
            AmortizationType.ACCELERATED: {"amortization_start_date", "scheduled_principal_amount", "amortization_growth", "balloon_amount"},
            AmortizationType.ACCELERATED_AUTO: {"amortization_start_date", "amortization_growth", "balloon_amount"},
            AmortizationType.ANNUITY: {"amortization_start_date", "balloon_amount"},
            AmortizationType.BESPOKE: {"principal_schedule", "amortization_start_date", "balloon_amount"},
        }[kind]
        for name in ("amortization_start_date", "scheduled_principal_amount", "amortization_growth", "balloon_amount", "principal_schedule"):
            value = getattr(self, name)
            present = bool(value) if name == "principal_schedule" else value is not None
            if present and name not in allowed:
                raise InputValidationError(f"{name} is not applicable to {kind.value}")
        if kind in (AmortizationType.LINEAR_AMOUNT, AmortizationType.ACCELERATED) and self.scheduled_principal_amount is None:
            raise InputValidationError(f"{kind.value} requires scheduled_principal_amount")
        if kind in (AmortizationType.ACCELERATED, AmortizationType.ACCELERATED_AUTO) and self.amortization_growth is None:
            raise InputValidationError(f"{kind.value} requires amortization_growth, including explicit zero")
        if kind in (AmortizationType.ANNUITY, AmortizationType.LINEAR_AUTO, AmortizationType.ACCELERATED_AUTO) and self.balloon_amount is None:
            raise InputValidationError(f"{kind.value} requires an explicit balloon_amount, including zero")
        if kind is AmortizationType.BESPOKE:
            if not self.principal_schedule or self.principal_schedule[-1].payment_date != self.maturity_date:
                raise InputValidationError("BESPOKE requires an explicit maturity schedule entry")
            dates = tuple(entry.payment_date for entry in self.principal_schedule)
            if any(not self.start_date < value <= self.maturity_date for value in dates):
                raise InputValidationError("Principal schedule dates must follow start and not exceed maturity")
            if any(current <= previous for previous, current in zip(dates, dates[1:])):
                raise InputValidationError("Principal schedule dates must be strictly increasing and unique")
            if self.amortization_start_date is not None and any(entry.amount != 0
                    and entry.payment_date < self.amortization_start_date for entry in self.principal_schedule):
                raise InputValidationError("BESPOKE cannot specify principal before its explicit amortization start")


@dataclass(frozen=True)
class OpeningFixing:
    """One actual carried term-index observation, annual decimal fraction.

    The date is the original contractual fixing date, not trade, settlement or
    portfolio valuation date. Floors and margins remain LoanTerms economics;
    this observation therefore contains the raw reference index rate.
    """

    fixing_date: date
    index_rate: Decimal

    def __post_init__(self) -> None:
        require_date(self.fixing_date, "opening fixing_date")
        require_decimal(self.index_rate, "opening index_rate")


class OpeningCouponEntitlement(str, Enum):
    """Contractual first-coupon ownership and opening-claim posting policy."""

    FULL_CURRENT_PERIOD = "FULL_CURRENT_PERIOD"
    POST_ASOF_ONLY = "POST_ASOF_ONLY"
    EXPLICIT_CASH_CLAIM = "EXPLICIT_CASH_CLAIM"


@dataclass(frozen=True)
class SeasonedLoanState:
    """Explicit opening cash-pay coupon entitlement, separate from its price.

    opening_accrued_interest is the signed posted claim at as-of. FULL_CURRENT_PERIOD
    validates it against exact accrual on the surviving held slice and preserves
    that unposted amount for one combined coupon posting. A posted zero can
    therefore retain a nonzero sub-cent exact prefix under this policy.
    POST_ASOF_ONLY requires
    an explicit zero and excludes history. EXPLICIT_CASH_CLAIM uses a verified
    agreed cent amount instead. Settlement accrued cost is a separate funding
    input and need not equal entitlement. provenance identifies the loan-agent
    statement or allocation agreement; no ownership rule is inferred from price.
    """

    opening_accrued_interest: Decimal
    provenance: str
    fixing_observations: tuple[OpeningFixing, ...] = ()
    entitlement_policy: OpeningCouponEntitlement = OpeningCouponEntitlement.FULL_CURRENT_PERIOD

    def __post_init__(self) -> None:
        amount = require_decimal(self.opening_accrued_interest, "opening_accrued_interest")
        with localcontext(Context(prec=max(34, amount.adjusted() + 4), rounding=ROUND_HALF_EVEN)):
            if amount != amount.quantize(Decimal(".01")):
                raise InputValidationError("opening_accrued_interest must have cent precision")
        if not isinstance(self.provenance, str) or not self.provenance.strip():
            raise InputValidationError("Seasoned opening state requires provenance")
        if not isinstance(self.entitlement_policy, OpeningCouponEntitlement):
            raise InputValidationError("Opening coupon entitlement must be OpeningCouponEntitlement")
        if self.entitlement_policy is OpeningCouponEntitlement.POST_ASOF_ONLY and amount != 0:
            raise InputValidationError("POST_ASOF_ONLY cannot retain an opening accrued claim")
        if type(self.fixing_observations) is not tuple or any(not isinstance(row, OpeningFixing) for row in self.fixing_observations):
            raise InputValidationError("Opening fixings must be an immutable tuple of OpeningFixing")
        dates = tuple(row.fixing_date for row in self.fixing_observations)
        if any(current <= previous for previous, current in zip(dates, dates[1:])):
            raise InputValidationError("Opening fixing dates must be strictly increasing and unique")

    def scaled(self, ratio: Fraction, *, unrounded_claim: Fraction | None = None) -> "SeasonedLoanState":
        """Resize an independent modeled holding's claim once to currency cents.

        FULL_CURRENT_PERIOD requires its exact source claim to avoid scaling a
        previously rounded amount. Market observations/provenance remain
        unchanged. Scenario/redesign resizing is an independent target
        portfolio, not allocation of two sides
        of an executed split trade; a settlement ledger must separately conserve
        the original claim when both retained and sold lots are represented.
        """
        if not isinstance(ratio, Fraction) or ratio <= 0:
            raise InputValidationError("Seasoned holding scale must be a positive exact Fraction")
        if self.entitlement_policy is OpeningCouponEntitlement.FULL_CURRENT_PERIOD:
            if not isinstance(unrounded_claim, Fraction) or post_currency(unrounded_claim) != self.opening_accrued_interest:
                raise InputValidationError("FULL_CURRENT_PERIOD resizing requires the exact original accrued claim")
            claim = unrounded_claim
        else:
            claim = Fraction(self.opening_accrued_interest)
        return SeasonedLoanState(post_currency(claim * ratio), self.provenance,
                                 self.fixing_observations, self.entitlement_policy)


@dataclass(frozen=True)
class LoanPosition:
    """Held principal at as-of; original contract anchors remain LoanTerms.

    A seasoned state is mandatory when as-of follows the contractual start.
    It authorizes a forward cash-pay projection, not a reconstruction of the
    existing CLO's historical liability, account or unsettled trade ledgers.
    """

    terms: LoanTerms
    par_as_of_date: date
    opening_balance: Decimal
    seasoned_state: SeasonedLoanState | None = None

    def __post_init__(self) -> None:
        if not isinstance(self.terms, LoanTerms):
            raise InputValidationError("terms must be LoanTerms")
        require_date(self.par_as_of_date, "par_as_of_date")
        require_money(self.opening_balance, "opening_balance", positive=True)
        if self.seasoned_state is not None and not isinstance(self.seasoned_state, SeasonedLoanState):
            raise InputValidationError("seasoned_state must be SeasonedLoanState or None")
        if self.par_as_of_date < self.terms.start_date or self.par_as_of_date >= self.terms.maturity_date:
            raise InputValidationError("Position as-of must be on/after contract start and before nominal maturity")
        if self.par_as_of_date == self.terms.start_date and self.seasoned_state is not None:
            raise InputValidationError("Seasoned opening state requires as-of after the original contract start")
        if self.par_as_of_date != self.terms.start_date and self.seasoned_state is None:
            raise InputValidationError("LoanPosition requires explicit seasoned_state for an as-of after contract start; mid-period history is not inferred")
        if self.seasoned_state is not None:
            if (self.terms.interest_mode is not InterestMode.CASH
                    and self.seasoned_state.entitlement_policy is OpeningCouponEntitlement.FULL_CURRENT_PERIOD
                    and self.seasoned_state.opening_accrued_interest != 0):
                raise InputValidationError("Seasoned PIK requires a separately verified cash claim or POST_ASOF_ONLY; historical uncapitalized PIK is not inferred")
            if any(step.effective_date <= self.par_as_of_date for step in self.terms.coupon_steps):
                raise InputValidationError("Seasoned historical coupon steps require a separate current-quote binding profile; only future steps are supported")
            if self.terms.amortization_type in (AmortizationType.ANNUITY, AmortizationType.LINEAR_AUTO, AmortizationType.ACCELERATED_AUTO):
                raise InputValidationError("Seasoned positions require contractual scheduled principal; automatic/annuity recasts are unsupported")
            if self.terms.coupon_type is CouponType.FIXED and self.seasoned_state.fixing_observations:
                raise InputValidationError("A fixed seasoned loan has no reference-index opening fixings")
            if any(row.fixing_date > self.par_as_of_date for row in self.seasoned_state.fixing_observations):
                raise InputValidationError("Opening fixing observations cannot follow the position as-of")
        if self.opening_balance > self.terms.reference_principal and self.terms.interest_mode is InterestMode.CASH:
            raise InputValidationError("Opening par cannot exceed its explicit amortisation reference")
        if self.terms.balloon_amount is not None and self.terms.balloon_amount > self.opening_balance:
            raise InputValidationError("balloon_amount cannot exceed held opening_balance")
        if self.terms.amortization_type is AmortizationType.BESPOKE:
            scheduled = sum((Fraction(entry.amount) for entry in self.terms.principal_schedule), Fraction())
            if scheduled != Fraction(self.opening_balance):
                raise InputValidationError("BESPOKE principal amounts must sum exactly to held opening_balance")


@dataclass(frozen=True)
class CouponSegment:
    """Frozen contractual annual rate on [accrual_start, accrual_end).

    A reset interval may span several payments. reset_date/fixing_date refer
    to that original interval, never to a later payment's truncated start.
    Rates are decimal fractions; spread is bps. No cash is posted here.
    """

    accrual_start: date
    accrual_end: date
    reset_date: date | None
    fixing_date: date | None
    index_rate: Decimal | None
    spread_bps: Decimal
    all_in_rate: Decimal
    exact_factor: Fraction | None = None
    exact_index_factor: Fraction | None = None

    def __post_init__(self) -> None:
        require_date(self.accrual_start, "segment accrual_start")
        require_date(self.accrual_end, "segment accrual_end")
        if self.accrual_start >= self.accrual_end:
            raise InputValidationError("Coupon segment must have positive length")
        require_decimal(self.spread_bps, "segment spread_bps")
        require_decimal(self.all_in_rate, "segment all_in_rate")
        for value in (self.exact_factor, self.exact_index_factor):
            if value is not None and not isinstance(value, Fraction):
                raise InputValidationError("Projected overnight segment factors must be exact Fractions")
        if (self.exact_factor is None) != (self.exact_index_factor is None):
            raise InputValidationError("Projected overnight segment requires both coupon and reference factors")
        if self.index_rate is None:
            if self.reset_date is not None or self.fixing_date is not None or self.spread_bps != 0:
                raise InputValidationError("Fixed segment has no reset/fixing/index/spread")
        else:
            require_decimal(self.index_rate, "segment index_rate")
            require_date(self.reset_date, "segment reset_date")
            require_date(self.fixing_date, "segment fixing_date")
            if not self.fixing_date <= self.reset_date <= self.accrual_start:
                raise InputValidationError("Segment fixing must precede reset and accrual")


@dataclass(frozen=True)
class LoanCashflow:
    """Cent-posted receivable, not a realised collection.

    Native rows retain immutable reset segments. Multi-reset annual rates are
    DCF-normalized display diagnostics; exact segment factors determine cash.
    fixing_date identifies the first active reset, including carried fixings.
    A seasoned first row adds opening_accrued_exact to forward earned coupon
    before posting. opening_accrued_interest is its posted audit amount, not a
    second receipt or a substitute for the exact unposted claim.
    """

    loan_id: str
    currency: str
    period_number: int
    unadjusted_start: date
    unadjusted_end: date
    accrual_start: date
    accrual_end: date
    payment_date: date
    fixing_date: date | None
    opening_balance: Decimal
    index_rate: Decimal | None
    spread_bps: Decimal
    all_in_rate: Decimal
    day_count_fraction: Decimal
    interest_unrounded: Decimal
    cash_interest: Decimal
    principal_repayment: Decimal
    closing_balance: Decimal
    total_cash: Decimal
    coupon_segments: tuple[CouponSegment, ...] = ()
    opening_accrued_interest: Decimal = Decimal(0)
    opening_accrued_exact: Fraction = Fraction()
    pik_interest: Decimal = Decimal(0)
    interest_mode: InterestMode = InterestMode.CASH
    pik_fraction: Decimal = Decimal(0)

    @property
    def gross_interest(self) -> Decimal:
        """Posted cash coupon plus posted noncash coupon, without double count."""
        return post_currency(Fraction(self.cash_interest) + Fraction(self.pik_interest))

    @property
    def pik_capitalization_date(self) -> date:
        """Capitalise no later than the cash date that can redeem that coupon.

        Ordinary lagged cash leaves PIK on its accrual boundary. PRECEDING
        can move final redemption before an unadjusted boundary; in that case
        the payable capitalised face must exist by the earlier cash date.
        This explicit projected policy changes neither the nominal accrual
        interval nor its coupon factor and is shared by all dated face ledgers.
        """
        return min(self.accrual_end, self.payment_date)

    def __post_init__(self) -> None:
        if type(self.coupon_segments) is not tuple or any(not isinstance(s, CouponSegment) for s in self.coupon_segments):
            raise InputValidationError("coupon_segments must be an immutable tuple of CouponSegment")
        require_money(self.pik_interest, "cashflow pik_interest")
        require_decimal(self.pik_fraction, "cashflow pik_fraction", minimum=Decimal(0))
        if not isinstance(self.interest_mode, InterestMode) or self.pik_fraction > 1:
            raise InputValidationError("Cashflow coupon settlement mode/share are invalid")
        amount = require_decimal(self.opening_accrued_interest, "cashflow opening_accrued_interest")
        with localcontext(Context(prec=max(34, amount.adjusted() + 4), rounding=ROUND_HALF_EVEN)):
            if amount != amount.quantize(Decimal(".01")):
                raise InputValidationError("Cashflow opening_accrued_interest must have cent precision")
        if not isinstance(self.opening_accrued_exact, Fraction) or post_currency(self.opening_accrued_exact) != amount:
            raise InputValidationError("Cashflow exact opening claim must post to its stated accrued amount")
