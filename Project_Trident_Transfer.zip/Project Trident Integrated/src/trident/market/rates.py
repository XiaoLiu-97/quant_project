"""Term-rate inputs with an explicit historical/projected-data boundary.

Rates are annualized decimals: ``Decimal("0.025")`` means 2.5%, while
``Decimal("-0.005")`` means -0.5%. Instrument floors belong to the cashflow
engine and are deliberately not applied by a rate provider.

A projected curve contains user-supplied term fixing rates. It is not a
discount curve, an OIS zero curve, a bootstrap, or a compounded RFR engine.
Interpolation uses actual calendar days and 34 significant decimal digits
with half-even rounding, independent of the caller's decimal context.
"""

from __future__ import annotations

from bisect import bisect_left
from collections.abc import Mapping
from dataclasses import dataclass, field
from datetime import date
from decimal import Context, Decimal, DecimalException, ROUND_HALF_EVEN, localcontext
from enum import Enum
from types import MappingProxyType
from typing import Protocol


class RequiredFixingError(ValueError):
    """An exact historical fixing is required but was not supplied."""


class MissingCurveError(ValueError):
    """No rate scenario or matching projected curve exists for an index."""


class CurveRangeError(ValueError):
    """A requested date lies outside a curve's permitted projection range."""


class ExtrapolationPolicy(Enum):
    """Out-of-range term-rate behavior; flat extrapolation is opt-in."""

    ERROR = "ERROR"
    FLAT = "FLAT"


class RateProvider(Protocol):
    """Supply an annualized decimal term rate for an index and fixing date."""

    def rate(self, index: str, fixing_date: date) -> Decimal:
        """Return the supplied/projected rate, or reject missing inputs."""
        ...


def _validate_index(index: str) -> None:
    """Reject missing identifiers without silently normalizing their meaning."""
    if not isinstance(index, str) or not index or index != index.strip():
        raise ValueError("index must be a nonempty string without surrounding whitespace")


def _validate_date(value: date, field_name: str) -> None:
    # datetime subclasses date, but a timestamp has different fixing semantics.
    if type(value) is not date:
        raise ValueError(f"{field_name} must be a date, not a datetime or another type")


def _validate_rate(value: Decimal, field_name: str) -> None:
    if not isinstance(value, Decimal) or not value.is_finite():
        raise ValueError(f"{field_name} must be a finite Decimal; floats and bools are not accepted")


def _validate_provenance(value: str) -> None:
    if not isinstance(value, str) or not value.strip():
        raise ValueError("provenance must be a nonempty string")


@dataclass(frozen=True, slots=True)
class RatePoint:
    """An immutable supplied term-rate observation/scenario node."""

    fixing_date: date
    rate: Decimal

    def __post_init__(self) -> None:
        _validate_date(self.fixing_date, "fixing_date")
        _validate_rate(self.rate, "rate")


@dataclass(frozen=True, slots=True)
class FlatRateProvider:
    """Immutable flat scenario rates, explicitly synthetic rather than observed.

    ``provenance`` records the source/rationale of the scenario. Regardless of
    that label, this provider remains synthetic; use ``CurveRateProvider`` for
    a dated set of actual historical fixings. The input mapping is copied.
    """

    rates: Mapping[str, Decimal]
    provenance: str = "SYNTHETIC_ASSUMPTION"

    def __post_init__(self) -> None:
        _validate_provenance(self.provenance)
        if not isinstance(self.rates, Mapping):
            raise ValueError("rates must be a mapping of index names to Decimal rates")
        snapshot = dict(self.rates)
        for index, value in snapshot.items():
            _validate_index(index)
            _validate_rate(value, f"rate for {index}")
        object.__setattr__(self, "rates", MappingProxyType(snapshot))

    @property
    def is_synthetic(self) -> bool:
        """Flat inputs are assumptions even when their source label changes."""
        return True

    def rate(self, index: str, fixing_date: date) -> Decimal:
        """Return the explicitly assumed flat rate, including for past dates."""
        _validate_index(index)
        _validate_date(fixing_date, "fixing_date")
        try:
            return self.rates[index]
        except KeyError as error:
            raise MissingCurveError(f"No flat rate supplied for index {index!r}") from error


@dataclass(frozen=True, slots=True)
class ProjectedRateCurve:
    """Immutable calendar-day interpolation of user-projected term rates.

    Nodes must be unique and already sorted; silently sorting could hide an
    input error. ``FLAT`` extends endpoint assumptions only when explicitly
    requested. Exact nodes are returned unchanged and never re-rounded.
    """

    index: str
    points: tuple[RatePoint, ...]
    extrapolation: ExtrapolationPolicy = ExtrapolationPolicy.ERROR
    provenance: str = "USER_PROJECTED_TERM_RATES"
    _fixing_dates: tuple[date, ...] = field(init=False, repr=False, compare=False)

    def __post_init__(self) -> None:
        _validate_index(self.index)
        _validate_provenance(self.provenance)
        if not isinstance(self.extrapolation, ExtrapolationPolicy):
            raise ValueError("extrapolation must be an ExtrapolationPolicy")
        if not isinstance(self.points, tuple) or not self.points:
            raise ValueError("points must be a nonempty tuple of RatePoint nodes")
        dates: list[date] = []
        for point in self.points:
            if not isinstance(point, RatePoint):
                raise ValueError("each curve point must be a RatePoint")
            if dates and point.fixing_date <= dates[-1]:
                raise ValueError("curve fixing dates must be unique and strictly increasing")
            dates.append(point.fixing_date)
        object.__setattr__(self, "_fixing_dates", tuple(dates))

    def rate(self, index: str, fixing_date: date) -> Decimal:
        """Evaluate the scenario without interpreting it as observed fixing data."""
        _validate_index(index)
        _validate_date(fixing_date, "fixing_date")
        if index != self.index:
            raise MissingCurveError(f"Curve for {self.index!r} cannot supply index {index!r}")
        position = bisect_left(self._fixing_dates, fixing_date)
        if position < len(self.points) and self._fixing_dates[position] == fixing_date:
            return self.points[position].rate
        if position == 0 or position == len(self.points):
            if self.extrapolation is ExtrapolationPolicy.ERROR:
                raise CurveRangeError(
                    f"Fixing date {fixing_date.isoformat()} is outside {self.index!r} "
                    f"curve range {self._fixing_dates[0].isoformat()} to "
                    f"{self._fixing_dates[-1].isoformat()}"
                )
            return self.points[0 if position == 0 else -1].rate
        left, right = self.points[position - 1], self.points[position]
        elapsed_days = Decimal((fixing_date - left.fixing_date).days)
        interval_days = Decimal((right.fixing_date - left.fixing_date).days)
        try:
            with localcontext(Context(prec=34, rounding=ROUND_HALF_EVEN)):
                return left.rate + (right.rate - left.rate) * elapsed_days / interval_days
        except DecimalException as error:
            raise ValueError("rate nodes cannot be interpolated within the decimal context") from error


@dataclass(frozen=True, slots=True)
class CurveRateProvider:
    """Actual historical fixings through valuation date, projections thereafter.

    An exact supplied fixing is mandatory for any date on or before the
    valuation date. There is no previous-fixing carry-forward, interpolation,
    or flat historical proxy. Future dates always use their projected curve.
    Mappings are copied and made read-only so an input snapshot stays stable.
    """

    curves: Mapping[str, ProjectedRateCurve]
    valuation_date: date
    historical_fixings: Mapping[tuple[str, date], Decimal] = field(default_factory=dict)

    def __post_init__(self) -> None:
        _validate_date(self.valuation_date, "valuation_date")
        if not isinstance(self.curves, Mapping):
            raise ValueError("curves must be a mapping of index names to projected curves")
        curves_snapshot = dict(self.curves)
        for index, curve in curves_snapshot.items():
            _validate_index(index)
            if not isinstance(curve, ProjectedRateCurve):
                raise ValueError("each curve must be a ProjectedRateCurve")
            if index != curve.index:
                raise ValueError(f"Curve mapping key {index!r} does not match curve index {curve.index!r}")
        if not isinstance(self.historical_fixings, Mapping):
            raise ValueError("historical_fixings must be a mapping of (index, date) keys")
        fixings_snapshot = dict(self.historical_fixings)
        for key, value in fixings_snapshot.items():
            if not isinstance(key, tuple) or len(key) != 2:
                raise ValueError("historical fixing keys must be (index, date) tuples")
            index, fixing_date = key
            _validate_index(index)
            _validate_date(fixing_date, "historical fixing_date")
            if fixing_date > self.valuation_date:
                raise ValueError("historical fixing dates cannot be after valuation_date")
            _validate_rate(value, f"historical fixing for {index} on {fixing_date.isoformat()}")
        object.__setattr__(self, "curves", MappingProxyType(curves_snapshot))
        object.__setattr__(self, "historical_fixings", MappingProxyType(fixings_snapshot))

    def rate(self, index: str, fixing_date: date) -> Decimal:
        """Use exact actual history or the matching future term-rate scenario."""
        _validate_index(index)
        _validate_date(fixing_date, "fixing_date")
        if fixing_date <= self.valuation_date:
            try:
                return self.historical_fixings[(index, fixing_date)]
            except KeyError as error:
                raise RequiredFixingError(
                    f"Exact historical fixing required for {index!r} on {fixing_date.isoformat()}"
                ) from error
        try:
            curve = self.curves[index]
        except KeyError as error:
            raise MissingCurveError(f"No projected curve supplied for index {index!r}") from error
        return curve.rate(index, fixing_date)
