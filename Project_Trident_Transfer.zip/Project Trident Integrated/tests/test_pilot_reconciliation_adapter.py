"""Test semantic reconciliation keys without workbook layout dependencies.

The catalog is the contract presented to a user supplying independent controls.
It must retain unavailable evidence, distinguish waterfall test stages, reject
duplicate observations, and avoid turning dates or flags into monetary values.
Expected records below are hand inputs rather than copies of model output.
"""

import unittest
from datetime import date, datetime
from decimal import Decimal, Inexact, localcontext
from types import SimpleNamespace

from trident.adapters.pilot_workbook import benchmark_records, input_fingerprint, observed_catalog
from trident.domain.models import InputValidationError
from trident.validation import ReconciliationKey, ReconciliationService, ReconciliationStatus


D = Decimal
OPEN = date(2026, 2, 1)
PAY = date(2026, 4, 1)


def tables(**replacements):
    empty = {name: () for name in (
        "asset_cashflows", "tranche_cashflows", "coverage_tests", "clo_periods",
        "portfolio_metrics", "credit_collections", "overlay_collections",
    )}
    empty.update(replacements)
    return empty


def result(currency="EUR"):
    """Expose the same explicit currency required by a typed projection."""
    return SimpleNamespace(cashflows=SimpleNamespace(projection_start_date=OPEN, currency=currency))


def key(kind, identity, metric, stage, day=PAY):
    return ReconciliationKey(day, kind, identity, metric, stage)


class FingerprintAdapter:
    """Minimal named-input reader; positions and blank curves are irrelevant."""

    def __init__(self, value):
        self.value = value

    def scalar(self, name):
        from trident.adapters import excel_schema as schema
        return self.value if name == schema.SCALAR_NAMES["legacy_closing_date"] else None

    def table_records(self, *_):
        return ()

    def region(self, _):
        sheet = SimpleNamespace(cell=lambda *args: SimpleNamespace(value=None))
        return sheet, (1, 1, 1, 1)


class LedgerRecordAdapter:
    """Expose frozen named table inputs without real worksheet addresses."""

    def __init__(self, records):
        from trident.adapters import excel_schema as schema
        self.records = {schema.TABLE_NAMES[name]: rows for name, rows in records.items()}

    def table_records(self, _range_name, table_name):
        return self.records.get(table_name, ())


class PilotReconciliationAdapterTests(unittest.TestCase):
    def test_available_portfolio_comment_is_not_an_unavailable_reason(self):
        rows = ({"as_of_date": OPEN, "phase": "CLOSING", "name": "WAS_BPS",
                 "value": D(400), "status": "AVAILABLE", "unit": "bps",
                 "message": "Floating coupon population only"},)
        observed, catalog = observed_catalog(result(), tables(portfolio_metrics=rows), {})
        metric = observed[key("PORTFOLIO", "POOL", "WAS_BPS", "CLOSING", OPEN)]
        self.assertEqual(metric.value, D(400))
        self.assertEqual(metric.unavailable_reason, "")
        self.assertEqual(catalog[0]["status"], "AVAILABLE")

    def test_incomplete_diagnostic_value_remains_unavailable_for_reconciliation(self):
        rows = ({"as_of_date": OPEN, "phase": "CLOSING", "name": "WARF",
                 "value": D(2200), "status": "INCOMPLETE", "unit": "factor",
                 "message": "Missing factors for part of held par"},)
        observed, catalog = observed_catalog(result(), tables(portfolio_metrics=rows), {})
        metric = observed[key("PORTFOLIO", "POOL", "WARF", "CLOSING", OPEN)]
        self.assertIsNone(metric.value)
        self.assertEqual(metric.unavailable_reason, rows[0]["message"])
        self.assertEqual(catalog[0]["status"], "UNAVAILABLE")

    def test_coverage_stage_keeps_gate_post_cure_and_period_end_distinct(self):
        rows = tuple({"payment_date": PAY, "class_id": "A", "stage": stage,
                      "oc_ratio": ratio, "ic_ratio": None, "oc_numerator": D(100),
                      "oc_denominator": D(80), "period_number": 1,
                      "payment_priority": 1, "coverage_failed": False}
                     for stage, ratio in (("GATE", D("1.20")),
                                          ("POST_DIVERSION", D("1.25")),
                                          ("PERIOD_END", D("1.30"))))
        observed, _ = observed_catalog(result(), tables(coverage_tests=rows), {})
        for row in rows:
            item = observed[key("COVERAGE", "A", "oc_ratio", row["stage"])]
            self.assertEqual(item.value, row["oc_ratio"])
            self.assertEqual(item.unit, "MULTIPLE")
            self.assertIsNone(observed[key("COVERAGE", "A", "ic_ratio", row["stage"])].value)
        self.assertFalse(any(item.metric in {"period_number", "payment_priority", "coverage_failed"}
                             for item in observed))

    def test_contract_and_tranche_cash_have_independent_identity_and_stage(self):
        observed, _ = observed_catalog(result(), tables(
            asset_cashflows=({"payment_date": PAY, "loan_id": "L", "cash_interest": D(3),
                              "fixing_date": None, "all_in_rate": D(".12")},),
            tranche_cashflows=({"payment_date": PAY, "class_id": "A", "current_coupon_due": D(".79"),
                                "fixing_date": None, "all_in_rate": D(".06")},),
        ), {})
        self.assertEqual(observed[key("ASSET_CONTRACT", "L", "cash_interest", "CONTRACTUAL")].value, D(3))
        self.assertEqual(observed[key("TRANCHE", "A", "current_coupon_due", "WATERFALL")].value, D(".79"))
        self.assertEqual(observed[key("ASSET_CONTRACT", "L", "all_in_rate", "CONTRACTUAL")].unit, "FRACTION")
        self.assertFalse(any(item.metric == "fixing_date" for item in observed))

    def test_duplicate_semantic_rows_fail_before_dictionary_overwrite(self):
        row = {"payment_date": PAY, "loan_id": "L", "cash_interest": D(3)}
        with self.assertRaisesRegex(InputValidationError, "duplicate|Duplicate"):
            observed_catalog(result(), tables(asset_cashflows=(row, dict(row, cash_interest=D(4)))), {})

    def test_unknown_scalar_absence_is_omitted_while_unavailable_irr_is_visible(self):
        observed, _ = observed_catalog(result(), tables(), {
            "result_equity_irr": None, "result_first_payment_date": None,
            "result_asset_count": 1, "result_was_bps": D(400),
            "result_opening_limit_breaches": 2,
            "result_last_calculated_at": "2026-01-01T12:00:00+00:00",
        })
        irr = observed[key("SCALAR", "DEAL", "result_equity_irr", "BASELINE", OPEN)]
        self.assertIsNone(irr.value)
        self.assertEqual(irr.unit, "FRACTION")
        self.assertEqual(observed[key("SCALAR", "DEAL", "result_asset_count", "BASELINE", OPEN)].unit, "COUNT")
        self.assertEqual(observed[key("SCALAR", "DEAL", "result_was_bps", "BASELINE", OPEN)].unit, "BPS")
        self.assertEqual(observed[key("SCALAR", "DEAL", "result_opening_limit_breaches", "BASELINE", OPEN)].unit, "COUNT")
        self.assertFalse(any(item.metric in {"result_first_payment_date", "result_last_calculated_at"}
                             for item in observed))

    def test_gbp_contract_cash_and_pik_fraction_match_independent_units(self):
        observed, _ = observed_catalog(result("GBP"), tables(asset_cashflows=({
            "payment_date": PAY, "loan_id": "L", "currency": "GBP",
            "cash_interest": D(3), "pik_fraction": D(".5"),
        },)), {"result_total_interest": D(3)})
        # A cash amount and a contractual settlement share have different
        # dimensions even when their numeric values are both ordinary Decimals.
        references = benchmark_records((
            dict(observation_date=PAY, entity_type="ASSET_CONTRACT", entity_id="L",
                 metric="cash_interest", stage="CONTRACTUAL", expected="3", tolerance="0",
                 unit="GBP", source="Independent GBP coupon ledger", reference_id="H-GBP-CASH"),
            dict(observation_date=PAY, entity_type="ASSET_CONTRACT", entity_id="L",
                 metric="pik_fraction", stage="CONTRACTUAL", expected=".5", tolerance="0",
                 unit="FRACTION", source="Signed 50 percent PIK contract", reference_id="H-PIK-SHARE"),
            dict(observation_date=OPEN, entity_type="SCALAR", entity_id="DEAL",
                 metric="result_total_interest", stage="BASELINE", expected="3", tolerance="0",
                 unit="GBP", source="Independent GBP aggregate ledger", reference_id="H-GBP-TOTAL"),
        ))
        comparison = ReconciliationService().compare(references, observed)
        self.assertEqual(comparison.status, ReconciliationStatus.MATCH)
        self.assertEqual(comparison.matched_count, 3)

    def test_face_time_exposure_is_not_labelled_as_plain_currency(self):
        observed, _ = observed_catalog(result(), tables(clo_periods=({
            "payment_date": PAY, "original_performing_par_years": D(25),
            "reinvestment_performing_par_years": D(5), "debt_face_par_years": D(15),
        },)), {})
        for metric in ("original_performing_par_years", "reinvestment_performing_par_years", "debt_face_par_years"):
            self.assertEqual(observed[key("ACCOUNT", "DEAL", metric, "PERIOD_END")].unit, "EUR_YEARS_ACT365F")

    def test_saved_midnight_excel_datetime_has_the_same_calendar_fingerprint(self):
        self.assertEqual(input_fingerprint(FingerprintAdapter(OPEN)),
                         input_fingerprint(FingerprintAdapter(datetime(2026, 2, 1))))
        self.assertNotEqual(input_fingerprint(FingerprintAdapter(OPEN)),
                            input_fingerprint(FingerprintAdapter(datetime(2026, 2, 1, 12))))

    def test_saved_numeric_types_keep_identical_economics_and_distinct_booleans(self):
        original = input_fingerprint(FingerprintAdapter(D("100.00")))
        self.assertEqual(original, input_fingerprint(FingerprintAdapter(100)))
        self.assertEqual(original, input_fingerprint(FingerprintAdapter(100.0)))
        self.assertNotEqual(original, input_fingerprint(FingerprintAdapter(D("100.01"))))
        self.assertNotEqual(input_fingerprint(FingerprintAdapter(False)),
                            input_fingerprint(FingerprintAdapter(0)))

    def test_numeric_fingerprint_does_not_round_with_callers_decimal_context(self):
        quantity = D("12345678901234567890.123456789")
        original = input_fingerprint(FingerprintAdapter(quantity))
        with localcontext() as caller:
            caller.prec = 3
            caller.traps[Inexact] = True
            actual = input_fingerprint(FingerprintAdapter(quantity))
        self.assertEqual(actual, original)

    def test_external_record_keeps_reference_and_matches_a_hand_coupon(self):
        observed, _ = observed_catalog(result(), tables(
            asset_cashflows=({"payment_date": PAY, "loan_id": "L", "cash_interest": D(3)},)), {})
        references = benchmark_records(({
            "observation_date": PAY, "entity_type": "ASSET_CONTRACT", "entity_id": "L",
            "metric": "cash_interest", "stage": "CONTRACTUAL", "expected": "3.00",
            "tolerance": "0.00", "unit": "EUR", "source": "Signed independent hand ledger",
            "reference_id": "H-COUPON-001",
        },))
        report = ReconciliationService().compare(references, observed)
        self.assertEqual(report.status, ReconciliationStatus.MATCH)
        self.assertEqual(report.results[0].benchmark.reference_id, "H-COUPON-001")
        self.assertEqual(report.results[0].benchmark.source, "Signed independent hand ledger")

    def test_missing_reference_source_is_rejected_at_excel_record_boundary(self):
        with self.assertRaises(InputValidationError):
            benchmark_records(({
                "observation_date": PAY, "entity_type": "TRANCHE", "entity_id": "A",
                "metric": "current_coupon_due", "stage": "WATERFALL", "expected": ".79",
                "tolerance": ".01", "unit": "EUR", "source": None, "reference_id": "H-001",
            },))

    def test_generated_seasoned_projection_exposes_registered_hand_controls(self):
        # Use the same flattening boundary as execution, so domain/schema
        # changes cannot silently invalidate the user's benchmark catalog.
        from test_seasoned_clo_integration import clo_request, fixed_position
        from trident.adapters import excel_schema as schema
        from trident.adapters.excel_model import _registered_record
        from trident.adapters.model_records import flat_record
        from trident.application.clo_services import TridentModelService

        actual = TridentModelService().run(clo_request(fixed_position()))
        reports = actual.portfolio_observations or (actual.opening_portfolio, *actual.portfolio_snapshots)
        actual_tables = tables(
            asset_cashflows=tuple(_registered_record(row, schema.ASSET_CASHFLOW_COLUMNS)
                                  for row in actual.cashflows.cashflows),
            tranche_cashflows=tuple(_registered_record(row, schema.TABLE_COLUMNS["tranche_cashflows"])
                                    for row in actual.clo.tranche_periods),
            clo_periods=tuple(_registered_record(row, schema.TABLE_COLUMNS["clo_periods"])
                             for row in actual.clo.periods),
            coverage_tests=tuple(flat_record(row) for row in actual.clo.coverage_tests),
            portfolio_metrics=tuple({"as_of_date": report.as_of_date, "phase": report.phase,
                                     **flat_record(metric)}
                                    for report in reports for metric in report.metrics),
        )
        observed, _ = observed_catalog(actual, actual_tables, {
            "result_equity_irr": actual.equity_irr.value,
            "result_asset_count": actual.cashflows.asset_count,
        })
        controls = tuple({
            "observation_date": PAY, "entity_type": kind, "entity_id": identity,
            "metric": metric, "stage": stage, "expected": expected,
            "tolerance": "0", "unit": "EUR", "source": "Independent coupon/funding hand ledger",
            "reference_id": reference,
        } for kind, identity, metric, stage, expected, reference in (
            ("ASSET_CONTRACT", "L", "cash_interest", "CONTRACTUAL", "3.00", "H-ASSET-001"),
            ("TRANCHE", "A", "current_coupon_due", "WATERFALL", "0.79", "H-NOTE-001"),
            ("ACCOUNT", "DEAL", "received_asset_interest", "PERIOD_END", "3.00", "H-RECEIPT-001"),
        ))
        comparison = ReconciliationService().compare(benchmark_records(controls), observed)
        self.assertEqual(comparison.status, ReconciliationStatus.MATCH)
        self.assertEqual(comparison.matched_count, 3)
        # Matching these three controls covers only their declared numbers;
        # it conveys no benchmark agreement for the investor IRR or legal terms.
        self.assertEqual(len(comparison.results), len(controls))

    def test_legitimate_coalesced_payment_dates_retain_both_contract_periods(self):
        from dataclasses import replace
        from test_seasoned_clo_integration import clo_request, fixed_position
        from trident.adapters.model_records import flat_record
        from trident.application.clo_services import TridentModelService
        from trident.conventions import BusinessDayConvention
        from trident.domain.models import LoanPosition, SeasonedLoanState

        terms = replace(fixed_position().terms, start_date=date(2026, 3, 28),
                        maturity_date=date(2026, 6, 29),
                        business_day_convention=BusinessDayConvention.FOLLOWING)
        position = LoanPosition(terms, date(2026, 3, 30), D(100),
                                SeasonedLoanState(D(".07"), "Independent current-period ledger"))
        actual = TridentModelService().run(clo_request(position, purchase_accrued=D(".07")))
        # Sunday nominalJun28 and Monday nominalJun29 both pay MondayJun29.
        # Their original positive accrual intervals and coupons remain distinct.
        self.assertEqual([row.payment_date for row in actual.cashflows.cashflows],
                         [date(2026, 6, 29)] * 2)
        observed, _ = observed_catalog(actual, tables(
            asset_cashflows=tuple(flat_record(row) for row in actual.cashflows.cashflows)), {})
        coupons = [item.value for item_key, item in observed.items()
                   if item_key.entity_type == "ASSET_CONTRACT" and item_key.entity_id == "L"
                   and item_key.metric == "cash_interest"]
        self.assertEqual(sorted(coupons), [D(".03"), D("3.07")])
        self.assertEqual(sum(coupons), D("3.10"))

    def test_named_ledger_inputs_preserve_actual_sources_and_catalog_cash_face(self):
        from trident.adapters.ledger_records import ledger_reports, ledger_request_from_workbook

        commit, settle = date(2026, 2, 2), date(2026, 2, 3)
        adapter = LedgerRecordAdapter({
            "ledger_controls": ({"as_of_date": OPEN, "horizon_date": PAY, "currency": "EUR",
                "principal_cash": "100", "interest_cash": "10", "allow_principal_for_accrued": False,
                "allow_principal_for_fees": False, "source": "Verified opening bank balances"},),
            "opening_holdings": ({"asset_id": "L", "currency": "EUR", "settled_par": "100",
                                   "status": "PERFORMING"},),
            "trade_ledger": ({"trade_id": "T", "asset_id": "Y", "side": "BUY", "trade_date": commit,
                "settlement_date": settle, "par": "50", "clean_price_pct": "100", "accrued_cash": "1",
                "fees_cash": ".50", "accrued_account": "INTEREST", "fee_account": "INTEREST",
                "lot_size": "25", "minimum_ticket": "25", "maximum_par": "50"},),
            "ledger_events": (
                {"event_id": "INCOME", "event_date": commit, "kind": "CASH_COLLECTION", "asset_id": "L",
                 "principal_cash": "0", "interest_cash": "3", "source": "Loan-agent actual payment"},
                # A supplied ID can equal a generated COMMIT reference. Their
                # different event kinds must keep their evidence sources apart.
                {"event_id": "COMMIT:T", "event_date": commit, "kind": "CASH_PAYMENT",
                 "principal_cash": "2", "interest_cash": "1", "source": "Trustee actual payment"},
            ),
        })
        ledger_request = ledger_request_from_workbook(adapter)
        reports = ledger_reports(ledger_request)
        journal = reports["ledger_journal"]
        self.assertEqual(next(row["source"] for row in journal if row["event_type"] == "CASH_COLLECTION"),
                         "Loan-agent actual payment")
        self.assertEqual(next(row["source"] for row in journal if row["event_type"] == "CASH_PAYMENT"),
                         "Trustee actual payment")
        self.assertTrue(all(row["source"] == "Verified opening bank balances" for row in journal
                            if row["event_type"] in {"COMMIT", "SETTLE"}))
        observed, _ = observed_catalog(result(), tables(**reports), {})
        # Opening100/10 + interest3 - payment2/1 - purchase50/1.50 =>48/10.50.
        # SettledL100 plusY50 establishes150face; cash never becomes extra par.
        controls = tuple({
            "observation_date": PAY, "entity_type": kind, "entity_id": identity, "metric": metric,
            "stage": "END_OF_DAY", "expected": expected, "tolerance": "0", "unit": "EUR",
            "source": "Independent settlement ledger", "reference_id": reference,
        } for kind, identity, metric, expected, reference in (
            ("LEDGER_CASH", "LEDGER", "principal_cash", "48", "LEDGER-P"),
            ("LEDGER_CASH", "LEDGER", "interest_cash", "10.50", "LEDGER-I"),
            ("LEDGER_CASH", "LEDGER", "settled_par", "150", "LEDGER-FACE"),
            ("LEDGER_POSITION", "Y", "available_to_sell", "50", "LEDGER-Y"),
        ))
        comparison = ReconciliationService().compare(benchmark_records(controls), observed)
        self.assertEqual(comparison.status, ReconciliationStatus.MATCH)
        self.assertEqual(comparison.matched_count, 4)

    def test_modeled_prepayment_collection_does_not_replace_contractual_coupon(self):
        from dataclasses import replace
        from test_seasoned_clo_integration import clo_request, fixed_position
        from trident.adapters.model_records import flat_record
        from trident.application.clo_services import TridentModelService
        from trident.credit import PrepaymentEvent

        prepaid = date(2026, 3, 1)
        request = replace(clo_request(fixed_position()), credit_events=(PrepaymentEvent("L", prepaid),))
        actual = TridentModelService().run(request)
        observed, _ = observed_catalog(actual, tables(
            asset_cashflows=tuple(flat_record(row) for row in actual.cashflows.cashflows),
            credit_collections=tuple(flat_record(row) for credit in actual.credit_projections
                                     for row in credit.collections)), {})
        self.assertEqual(observed[key("ASSET_CONTRACT", "L", "cash_interest", "CONTRACTUAL")].value, D(3))
        collected = observed[key("ASSET_COLLECTION", "L", "cash_interest", "CREDIT:PREPAYMENT", prepaid)]
        self.assertEqual(collected.value, D("1.97"))
        self.assertEqual(collected.unit, "EUR")
        self.assertEqual(observed[key("ASSET_COLLECTION", "L", "principal_collection",
                                     "CREDIT:PREPAYMENT", prepaid)].value, D(100))
        self.assertFalse(any(item.entity_type == "ASSET_COLLECTION" and item.observation_date == PAY
                             for item in observed))

    def test_duplicate_benchmark_key_rejects_distinct_reference_labels(self):
        original = {"observation_date": PAY, "entity_type": "COVERAGE", "entity_id": "A",
                    "metric": "oc_ratio", "stage": "GATE", "expected": "1.25", "tolerance": ".01",
                    "unit": "MULTIPLE", "source": "Independent trustee gate calculation",
                    "reference_id": "GATE-001"}
        duplicate = dict(original, expected="1.30", reference_id="GATE-002")
        with self.assertRaisesRegex(InputValidationError, "unique|duplicate|Duplicate"):
            benchmark_records((original, duplicate))


if __name__ == "__main__":
    unittest.main()
