"""Discount-factor forwards for explicitly specified collection-account curves.

An OIS zero-rate node is an as-of-valuation maturity rate. It is not the deposit
rate at a later receipt date. Projected account accumulation over [s,e] is
DF(s)/DF(e), with simple contractual spread added over the selected account DCF.
This is a projected OIS-forward remuneration assumption, not a replay of actual
daily €STR/SOFR/SONIA observations or a guarantee of bank account returns.

Zero compounding/day count must be supplied; the legacy paste labels do not
contain these conventions. Interpolation is linear in log-discount factors,
with DF(valuation)=1. Extrapolation is opt-in flat continuously compounded
endpoint zero, never an unmarked last-node rate. Transcendentals use an isolated
50-digit Decimal context; monetary posting is exact Fraction on those values.
"""

from bisect import bisect_left
from collections.abc import Mapping
from dataclasses import dataclass, field
from datetime import date
from decimal import Context, Decimal, DecimalException, ROUND_HALF_EVEN, localcontext
from enum import Enum
from fractions import Fraction
from types import MappingProxyType

from trident.conventions.day_count import DayCount, accrual_fraction
from trident.domain.models import InputValidationError, require_date, require_decimal
from trident.domain.numeric import basis_points_rate

from .rates import CurveRangeError, ExtrapolationPolicy, MissingCurveError, RateProvider


class ZeroCompounding(str, Enum):
    CONTINUOUS = "CONTINUOUS"
    ANNUAL_EFFECTIVE = "ANNUAL_EFFECTIVE"
    SIMPLE = "SIMPLE"


def _fraction_decimal(value: Fraction) -> Decimal:
    """Convert interpolation factors in the same 50-digit curve context."""
    with localcontext(Context(prec=50, rounding=ROUND_HALF_EVEN)):
        return Decimal(value.numerator) / Decimal(value.denominator)


@dataclass(frozen=True, slots=True)
class ZeroRatePoint:
    """Maturity in explicit curve year units, and annual decimal zero rate."""
    tenor_years: Decimal
    zero_rate: Decimal

    def __post_init__(self) -> None:
        require_decimal(self.tenor_years, "tenor_years", minimum=Decimal(0))
        require_decimal(self.zero_rate, "zero_rate")


@dataclass(frozen=True, slots=True)
class DiscountFactorCashCurve:
    """Immutable OIS-forward projection, not an observed overnight fixing feed."""
    index: str
    valuation_date: date
    points: tuple[ZeroRatePoint, ...]
    compounding: ZeroCompounding
    day_count: DayCount
    extrapolation: ExtrapolationPolicy = ExtrapolationPolicy.ERROR
    provenance: str = "USER_SUPPLIED_OIS_ZERO_CURVE"
    _tenors: tuple[Fraction, ...] = field(init=False, repr=False, compare=False)
    _logs: tuple[Decimal, ...] = field(init=False, repr=False, compare=False)

    def __post_init__(self) -> None:
        if self.index not in {"ESTR", "SOFR", "SONIA"}:
            raise InputValidationError("Discount-factor cash index must be ESTR, SOFR or SONIA")
        require_date(self.valuation_date, "valuation_date")
        if not isinstance(self.compounding, ZeroCompounding) or self.day_count not in {DayCount.ACT_360, DayCount.ACT_365F}:
            raise InputValidationError("Explicit zero compounding and ACT/360 or ACT/365F curve basis required")
        if not isinstance(self.extrapolation, ExtrapolationPolicy):
            raise InputValidationError("extrapolation must be an explicit ExtrapolationPolicy")
        if not isinstance(self.provenance, str) or not self.provenance.strip():
            raise InputValidationError("Cash curve provenance is required")
        if type(self.points) is not tuple or not self.points or any(not isinstance(p, ZeroRatePoint) for p in self.points):
            raise InputValidationError("Cash curve requires an immutable nonempty ZeroRatePoint tuple")
        tenors = tuple(Fraction(p.tenor_years) for p in self.points)
        if any(right <= left for left, right in zip(tenors, tenors[1:])):
            raise InputValidationError("Zero curve tenors must be unique and strictly increasing")
        logs = tuple(self._node_log(p) for p in self.points)
        if tenors[0] == 0:
            tenors, logs = tenors[1:], logs[1:]
        if not tenors:
            raise InputValidationError("Cash curve needs at least one positive tenor node")
        object.__setattr__(self, "_tenors", (Fraction(), *tenors))
        object.__setattr__(self, "_logs", (Decimal(0), *logs))

    def _node_log(self, point: ZeroRatePoint) -> Decimal:
        try:
            with localcontext(Context(prec=50, rounding=ROUND_HALF_EVEN)):
                if self.compounding is ZeroCompounding.CONTINUOUS:
                    return -point.zero_rate * point.tenor_years
                if self.compounding is ZeroCompounding.ANNUAL_EFFECTIVE:
                    if point.zero_rate <= -1:
                        raise InputValidationError("Annual effective zero rate must exceed -100%")
                    return -(Decimal(1) + point.zero_rate).ln() * point.tenor_years
                accumulation = Decimal(1) + point.zero_rate * point.tenor_years
                if accumulation <= 0:
                    raise InputValidationError("Simple zero rate must create a positive discount factor")
                return -accumulation.ln()
        except DecimalException as error:
            raise InputValidationError("Cash zero node exceeds supported numeric domain") from error

    def discount_factor(self, value: date) -> Decimal:
        """Evaluate log-linear DF, rejecting a date before the valuation snapshot."""
        require_date(value, "discount date")
        if value < self.valuation_date:
            raise CurveRangeError("Cash-forward date cannot precede the curve valuation date")
        tenor = accrual_fraction(self.valuation_date, value, self.day_count)
        position = bisect_left(self._tenors, tenor)
        if position == 0:
            return Decimal(1)
        try:
            with localcontext(Context(prec=50, rounding=ROUND_HALF_EVEN)):
                if position == len(self._tenors):
                    if self.extrapolation is ExtrapolationPolicy.ERROR:
                        raise CurveRangeError("Cash-forward maturity exceeds supplied zero curve")
                    # A constant endpoint log-zero is a stated extrapolation.
                    ratio = _fraction_decimal(tenor / self._tenors[-1])
                    log_df = self._logs[-1] * ratio
                elif tenor == self._tenors[position]:
                    log_df = self._logs[position]
                else:
                    weight = _fraction_decimal((tenor - self._tenors[position - 1]) /
                                              (self._tenors[position] - self._tenors[position - 1]))
                    log_df = self._logs[position - 1] + (self._logs[position] - self._logs[position - 1]) * weight
                factor = log_df.exp()
                if factor <= 0 or not factor.is_finite():
                    raise InputValidationError("Discount factor must be finite and strictly positive")
                return factor
        except DecimalException as error:
            raise InputValidationError("Cash discount factor exceeds supported numeric domain") from error

    def accumulation_factor(
        self, start: date, end: date, account_day_count: DayCount,
        spread_bps: Decimal = Decimal(0), floor: Decimal | None = None,
    ) -> Fraction:
        """Return exact projected earnings per currency unit, after all-in floor.

        Principal plus earnings is 1+returned factor. The spread/floor uses the
        account day count, while DF maturities retain their separate curve basis.
        An empty interval earns zero without looking up an unneeded rate.
        """
        require_date(start, "cash start")
        require_date(end, "cash end")
        if end < start:
            raise InputValidationError("Cash end must not precede cash start")
        if not isinstance(account_day_count, DayCount):
            raise InputValidationError("account_day_count must be DayCount")
        require_decimal(spread_bps, "cash spread_bps")
        if floor is not None:
            require_decimal(floor, "cash all-in floor")
        if start < self.valuation_date:
            raise CurveRangeError("Actual historical overnight earnings require observed data, not a forward zero curve")
        if end == start:
            return Fraction()
        dcf = accrual_fraction(start, end, account_day_count)
        factor = Fraction(self.discount_factor(start)) / Fraction(self.discount_factor(end)) - 1
        factor += Fraction(basis_points_rate(spread_bps)) * dcf
        if floor is not None:
            factor = max(factor, Fraction(floor) * dcf)
        return factor


@dataclass(frozen=True, slots=True)
class CashCurveRateProvider:
    """Composite provider: term fixings and separate explicit DF cash curves."""
    term_provider: RateProvider
    cash_curves: Mapping[str, DiscountFactorCashCurve]

    def __post_init__(self) -> None:
        if not callable(getattr(self.term_provider, "rate", None)) or not isinstance(self.cash_curves, Mapping):
            raise InputValidationError("Term provider and cash-curves mapping required")
        snapshot = dict(self.cash_curves)
        if any(not isinstance(value, DiscountFactorCashCurve) or key != value.index for key, value in snapshot.items()):
            raise InputValidationError("Cash curve mapping keys must equal their typed indices")
        object.__setattr__(self, "cash_curves", MappingProxyType(snapshot))

    @property
    def valuation_date(self) -> date | None:
        return getattr(self.term_provider, "valuation_date", None)

    def rate(self, index: str, fixing_date: date) -> Decimal:
        return self.term_provider.rate(index, fixing_date)

    def accumulation_factor(
        self, index: str, start: date, end: date, account_day_count: DayCount,
        spread_bps: Decimal = Decimal(0), floor: Decimal | None = None,
    ) -> Fraction:
        """Supply dated projected earnings; never expose OIS zeros as fixings."""
        try:
            curve = self.cash_curves[index]
        except KeyError as error:
            raise MissingCurveError(f"Missing cash discount-factor curve for {index!r}") from error
        return curve.accumulation_factor(start, end, account_day_count, spread_bps, floor)
