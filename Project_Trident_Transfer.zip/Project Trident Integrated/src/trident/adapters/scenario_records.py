"""Translate named what-if edits using the scenario service's field registry."""

from typing import Mapping

from trident.application.scenarios import (
    SCENARIO_FIELD_TYPES, ScenarioDefinition, ScenarioEdit, ScenarioTarget,
)
from trident.domain.models import InputValidationError
from .records import boolean_value, date_value, decimal_value, text_value


def scenarios_from_records(rows: tuple[Mapping[str, object], ...]) -> tuple[ScenarioDefinition, ...]:
    """Grouping order follows the input table; each case edits the same baseline.

    Blank values clear only explicitly optional fields such as OC thresholds.
    All other blank values fail validation instead of becoming implicit zero.
    """
    grouped: dict[str, list[ScenarioEdit]] = {}
    for row in rows:
        if not boolean_value(row.get("enabled"), "scenario edit enabled"):
            continue
        scenario_id = text_value(row.get("scenario_id"), "scenario_id")
        target = ScenarioTarget(text_value(row.get("target"), "scenario target"))
        identifier = text_value(row.get("identifier"), "scenario identifier")
        field = text_value(row.get("field"), "scenario field")
        kind = SCENARIO_FIELD_TYPES[target].get(field)
        if kind is None:
            raise InputValidationError(f"Unsupported {target.value} scenario field: {field}")
        raw = row.get("value")
        if kind == "date":
            value = date_value(raw, f"scenario {field}")
        elif kind == "boolean":
            value = boolean_value(raw, f"scenario {field}")
        elif kind == "text":
            value = text_value(raw, f"scenario {field}")
        elif kind == "optional_decimal" and (raw is None or raw == ""):
            value = None
        else:
            value = decimal_value(raw, f"scenario {field}")
        grouped.setdefault(scenario_id, []).append(ScenarioEdit(target, identifier, field, value))
    return tuple(ScenarioDefinition(identifier, tuple(edits)) for identifier, edits in grouped.items())
