"""Independent acquisition-state controls for synthetic reinvestment.

Tiny cash/face ledgers separate the purchase gate from loan analytics. Expected
answers are specified from hand arithmetic, including post-purchase OC and the
cent allocation of ordinary pro-rata principal. Planning a rejected acquisition
must leave dated cohort, coupon and recovery rights unchanged.
"""

from dataclasses import replace
from datetime import date
from decimal import Context, Decimal, Inexact, localcontext
from fractions import Fraction
from unittest.mock import patch
import unittest

from trident.clo import (
    CloRunRequest, CloTerms, CoverageStatus, DeterministicCloEngine,
    PrincipalRepaymentMode, report_tranche_periods,
)
from trident.clo.lifecycle import AdjustedCollateralValuePolicy, OcAssetData
from trident.clo.models import CloNoteCouponClaim, CloOpeningState
from trident.clo.reinvestment import (
    ReinvestmentTestGate, SyntheticReinvestmentLedger, SyntheticReinvestmentPolicy,
)
from trident.domain.models import InputValidationError
from trident.market.rates import FlatRateProvider
from test_clo import CLOSE, FIRST, SECOND, note, receipt, run


D = Decimal
THIRD = date(2026, 10, 20)


def acquisition_policy(*, end=FIRST, **changes):
    """No stress or income obscures the clean-price cash/face exchange."""
    return replace(SyntheticReinvestmentPolicy(
        enabled=True, end_date=end, spread_bps=D(0), purchase_price=D(1),
        bullet_wal_years=D("0.25"), annual_default_rate=D(0),
        annual_prepayment_rate=D(0), recovery_lag_months=0,
    ), **changes)


def closing_projection(*, principal="10", policy=None, threshold="1.25", **changes):
    """100 original par becomes90 par plus10 physical cash at first payment."""
    # The second contractual row is explicit; leaving90 principal unprojected
    # would fail schedule integrity independently of the acquisition logic.
    survivor = str(D(100) - D(principal))
    return run((
        receipt("L", 1, CLOSE, FIRST, "100", principal, "0"),
        receipt("L", 2, FIRST, SECOND, survivor, survivor, "0"),
    ), (note(par="80", oc_minimum=D(threshold)),),
       synthetic_reinvestment_policy=policy or acquisition_policy(), **changes)


def opening_projection(*, price="1", threshold="1.30", permission="10", **changes):
    """Observed cash20 contains permission10; the other10 must amortize debt."""
    policy = acquisition_policy(end=SECOND, purchase_price=D(price),
                                recycle_reinvestment_principal=False)
    state = CloOpeningState(
        FIRST, D(20), D(0), D(0),
        (CloNoteCouponClaim("A", D(0)), CloNoteCouponClaim("B", D(0))),
        "Independent post-distribution cash and claims", 
        original_principal_reinvestment_cash=D(permission),
    )
    request = CloRunRequest((
        receipt("L", 1, FIRST, SECOND, "100", "0", "0"),
        receipt("L", 2, SECOND, THIRD, "100", "100", "0"),
    ), D(100), (
        note("A", 1, "50", oc_minimum=D(threshold)),
        note("B", 2, "40", oc_minimum=D(threshold)),
    ), CloTerms(CLOSE, THIRD, principal_repayment_mode=PrincipalRepaymentMode.PRO_RATA,
                synthetic_reinvestment_policy=policy, **changes), opening_state=state)
    return DeterministicCloEngine(FlatRateProvider({"EURIBOR_3M": D(0)})).run(request)


class ReinvestmentAcquisitionGateTests(unittest.TestCase):
    def assert_cash_and_report(self, result):
        """Cash conservation alone is insufficient; principal recipients matter."""
        self.assertTrue(all(row.cash_conservation_residual == 0 for row in result.periods))
        report_tranche_periods(result)

    def test_premium_purchase_that_creates_oc_failure_is_vetoed(self):
        result = closing_projection(policy=acquisition_policy(purchase_price=D("1.01")))
        first = result.periods[0]
        # Before buying: (90 collateral +10 cash)/80 debt =1.25 PASS.
        # Proposed: (90 +9.90)/80 =1.24875 FAIL. All10 instead repaysA.
        self.assertEqual((first.reinvestment_cash_used, first.reinvestment_par_acquired), (0, 0))
        self.assertFalse(result.reinvestment_purchases)
        self.assertEqual(first.closing_collateral_par, D(90))
        self.assertEqual(result.tranche_periods[0].principal_from_principal, D(10))
        self.assertEqual(first.closing_debt_par, D(70))
        self.assert_cash_and_report(result)

    def test_post_purchase_par_preserves_pro_rata_allocation(self):
        result = opening_projection()
        first, a, b = result.periods[0], *result.tranche_periods[:2]
        # Numerator120 before and after par purchase:110 assets +10 cash.
        # 10 *50/90 posts5.56 toA; balancing4.44 is paid toB.
        self.assertEqual((first.reinvestment_cash_used, first.reinvestment_par_acquired), (10, 10))
        self.assertEqual((a.principal_from_principal, b.principal_from_principal), (D("5.56"), D("4.44")))
        self.assertEqual((a.closing_balance, b.closing_balance), (D("44.44"), D("35.56")))
        self.assertEqual(first.closing_collateral_par, D(110))
        self.assert_cash_and_report(result)

    def test_future_purchased_coupon_cannot_cure_todays_ic_failure(self):
        policy = acquisition_policy(spread_bps=D(10000))
        rows = (receipt("L", 1, CLOSE, FIRST, "100", "10", "0"),
                receipt("L", 2, FIRST, SECOND, "90", "90", "0"))
        result = run(rows, (note(par="80", rate="0.04", ic_minimum=D("1.1")),),
                     synthetic_reinvestment_policy=policy)
        # Today80*.04*90/360=0.80 coupon is covered from principal10. Future
        # cohort carry, however high, cannot turn today's IC0/.80 into a PASS.
        first = result.periods[0]
        self.assertEqual(result.tranche_periods[0].coupon_paid_from_principal, D("0.80"))
        self.assertEqual(result.tranche_periods[0].principal_from_principal, D("9.20"))
        self.assertEqual(first.reinvestment_cash_used, D(0))
        self.assertEqual(first.reinvestment_asset_cash_interest, D(0))
        self.assertFalse(result.reinvestment_purchases)
        first_end = next(row for row in result.coverage_tests if row.period_number == 1 and row.stage == "PERIOD_END")
        self.assertEqual(first_end.ic_denominator, D("0.80"))
        self.assertIs(first_end.ic_status, CoverageStatus.FAIL)
        self.assert_cash_and_report(result)

    def test_discount_purchase_passes_and_creates_real_par_gain(self):
        result = closing_projection(policy=acquisition_policy(purchase_price=D("0.99")))
        first = result.periods[0]
        self.assertEqual((first.reinvestment_cash_used, first.reinvestment_par_acquired), (D(10), D("10.10")))
        self.assertEqual(first.closing_collateral_par, D("100.10"))
        self.assertEqual(first.closing_debt_par, D(80))
        self.assert_cash_and_report(result)

    def test_discount_and_permitted_premium_refresh_principal_gate(self):
        for price, acquired in (("0.99", "10.10"), ("1.01", "9.90")):
            with self.subTest(price=price):
                result = opening_projection(price=price)
                # Both proposed total numerators120.10 and119.90 exceed117.
                self.assertEqual(result.periods[0].reinvestment_par_acquired, D(acquired))
                self.assertEqual(tuple(row.principal_from_principal for row in result.tranche_periods[:2]),
                                 (D("5.56"), D("4.44")))
                self.assert_cash_and_report(result)

    def test_explicit_always_reinvest_bypasses_oc_veto(self):
        result = closing_projection(policy=acquisition_policy(
            purchase_price=D("1.01"), test_gate=ReinvestmentTestGate.ALWAYS_REINVEST))
        first = result.periods[0]
        self.assertEqual((first.reinvestment_cash_used, first.reinvestment_par_acquired), (D(10), D("9.90")))
        first_end = next(row for row in result.coverage_tests if row.period_number == 1 and row.stage == "PERIOD_END")
        self.assertEqual(first_end.oc_numerator, D("99.90"))
        self.assertIs(first_end.oc_status, CoverageStatus.FAIL)
        self.assert_cash_and_report(result)

    def test_longdated_haircut_is_included_before_purchase_commit(self):
        result = closing_projection(
            policy=acquisition_policy(bullet_wal_years=D(1)),
            adjusted_oc_policy=AdjustedCollateralValuePolicy(long_dated_valuation=D("0.8")))
        # New10 par matures after legal final: value8, not10. Proposed98/80 fails.
        self.assertEqual(result.periods[0].reinvestment_cash_used, D(0))
        self.assertEqual(result.tranche_periods[0].principal_from_principal, D(10))
        self.assertFalse(result.reinvestment_purchases)
        self.assert_cash_and_report(result)

    def test_disabled_coverage_has_no_implicit_oc_veto(self):
        result = closing_projection(policy=acquisition_policy(purchase_price=D("1.01")),
                                    coverage_tests_enabled=False)
        self.assertEqual(result.periods[0].reinvestment_cash_used, D(10))
        self.assertEqual(result.periods[0].reinvestment_par_acquired, D("9.90"))
        self.assert_cash_and_report(result)

    def test_no_original_permission_does_not_spend_opening_cash(self):
        result = opening_projection(permission="0")
        self.assertFalse(result.reinvestment_purchases)
        # Without purchase the full cash20 amortizes in50:40 proportion.
        self.assertEqual(tuple(row.principal_from_principal for row in result.tranche_periods[:2]),
                         (D("11.11"), D("8.89")))
        self.assert_cash_and_report(result)

    def test_cutoff_cash_is_oc_credit_but_is_not_purchase_funding(self):
        result = closing_projection(collection_cutoff_business_days=2)
        first = result.periods[0]
        self.assertEqual(first.pending_principal_cash, D(10))
        self.assertEqual(first.reinvestment_cash_used, D(0))
        self.assertFalse(result.reinvestment_purchases)
        self.assert_cash_and_report(result)

    def test_reinvestment_window_and_terminal_never_purchase(self):
        expired = closing_projection(policy=acquisition_policy(end=CLOSE))
        self.assertFalse(expired.reinvestment_purchases)
        final = run((receipt("L", 1, CLOSE, FIRST, "100", "100", "0"),),
                    (note(par="80"),), final=FIRST,
                    synthetic_reinvestment_policy=acquisition_policy())
        self.assertFalse(final.reinvestment_purchases)
        self.assertEqual(final.periods[0].debt_principal_from_principal, D(80))
        self.assert_cash_and_report(expired)
        self.assert_cash_and_report(final)

    def test_successful_call_does_not_leave_new_synthetic_rights(self):
        result = closing_projection(optional_call_enabled=True, optional_call_date=FIRST)
        self.assertEqual(result.periods[0].optional_call_status, "EXERCISED")
        self.assertFalse(result.reinvestment_purchases)
        self.assertEqual(result.final_collateral_par, D(0))
        self.assertEqual(result.final_debt_par, D(0))
        self.assert_cash_and_report(result)

    def test_oc_cash_exclusion_is_respected_in_prospective_gate(self):
        result = closing_projection(threshold="1.1", include_principal_cash_in_oc=False,
                                    policy=acquisition_policy(purchase_price=D("1.1")))
        # Current90/80 passes1.10 even without cash credit. Proposed99.09/80
        # also passes; the actual9.999 cost posts10.00. Excluding cash cannot
        # incorrectly subtract it from the asset-only OC numerator.
        self.assertEqual(result.periods[0].reinvestment_cash_used, D(10))
        self.assertEqual(result.periods[0].reinvestment_par_acquired, D("9.09"))
        self.assert_cash_and_report(result)

    def test_terminal_sale_does_not_keep_disposed_assets_in_principal_gate(self):
        result = run((receipt("L", 1, CLOSE, FIRST, "100", "0", "0"),
                      receipt("L", 2, FIRST, SECOND, "100", "100", "0")),
                     (note("A", 1, "50", oc_minimum=D("1.1")),
                      note("B", 2, "40", oc_minimum=D("1.1"))),
                     final=FIRST, principal_repayment_mode=PrincipalRepaymentMode.PRO_RATA,
                     maturity_liquidation_price=D("0.5"),
                     synthetic_reinvestment_policy=acquisition_policy())
        # After terminalsale no100 collateral remains: only50 physicalcash.
        # 50/90 fails1.10, so sequential paymentA50/B0 is mandatory. Retaining
        # disposed100 in numerator would falsely pass and allocate27.78/22.22.
        self.assertEqual(result.periods[0].collateral_sale_proceeds, D(50))
        self.assertEqual(tuple(row.principal_from_principal for row in result.tranche_periods),
                         (D(50), D(0)))
        self.assertEqual(result.final_collateral_par, D(0))
        self.assertEqual(result.final_debt_par, D(40))
        self.assertFalse(result.reinvestment_purchases)
        self.assert_cash_and_report(result)

    def test_forbidden_longdated_and_unknown_asset_oc_cannot_mutate_ledger(self):
        books = []

        class ObservedLedger(SyntheticReinvestmentLedger):
            def __init__(self, *args, **kwargs):
                super().__init__(*args, **kwargs)
                books.append(self)

        # ALWAYS bypasses coverage only. Missing classification or a forbidden
        # contract maturity still fails, before cash/cohort state can be changed.
        for controls, message in (
            ({"allow_long_dated_assets": False}, "forbidden long-dated"),
            ({"adjusted_oc_policy": AdjustedCollateralValuePolicy(True)}, "explicit asset-level OC classification"),
        ):
            with self.subTest(controls=controls), patch("trident.clo.engine.SyntheticReinvestmentLedger", ObservedLedger):
                policy = acquisition_policy(bullet_wal_years=D(1), test_gate=ReinvestmentTestGate.ALWAYS_REINVEST)
                terms = CloTerms(CLOSE, SECOND, synthetic_reinvestment_policy=policy, **controls)
                request = CloRunRequest((receipt("L", 1, CLOSE, FIRST, "100", "10", "0"),
                                        receipt("L", 2, FIRST, SECOND, "90", "90", "0")),
                                       D(100), (note(par="80"),), terms,
                                       oc_asset_data=(OcAssetData("L"),))
                with self.assertRaisesRegex(InputValidationError, message):
                    DeterministicCloEngine(FlatRateProvider({"EURIBOR_3M": D(0)})).run(request)
                self.assertEqual(books[-1].performing_par, D(0))
                self.assertFalse(books[-1].purchases)


class ReinvestmentAcquisitionPlanningTests(unittest.TestCase):
    def book(self, **changes):
        return SyntheticReinvestmentLedger(acquisition_policy(**changes),
                                           FlatRateProvider({"EURIBOR_3M": D(0)}))

    def test_discarded_plan_has_no_par_coupon_claim_or_identity_side_effect(self):
        book = self.book(end=SECOND)
        book.project(CLOSE, FIRST, CLOSE)
        proposal = book.plan_purchase(FIRST, D(10))
        self.assertEqual(proposal.cohort_id, "TRIDENT_REINV_000001")
        self.assertEqual(proposal.acquired_par, D(10))
        self.assertEqual(book.performing_par, D(0))
        self.assertEqual(book.balance_at(FIRST), D(0))
        self.assertEqual(book.par_days(CLOSE, SECOND), Fraction(0))
        self.assertEqual(book.pending_recovery_amount, D(0))
        self.assertFalse(book.purchases)
        # Discarding a plan creates no future entitlement or ghost maturity.
        result = book.project(FIRST, SECOND, FIRST)
        self.assertEqual((result.interest_cash, result.principal_cash), (0, 0))
        self.assertEqual(book.plan_purchase(SECOND, D(10)).cohort_id, "TRIDENT_REINV_000001")

    def test_cent_face_floor_and_half_up_cost_leave_only_physical_residual(self):
        book = self.book(purchase_price=D("1.03"))
        planned = book.plan_purchase(FIRST, D(10))
        # Floor10/1.03 to9.70 face;9.70*1.03=9.991 posts9.99 cash.
        self.assertEqual((planned.acquired_par, planned.cash_used, planned.unused_cash),
                         (D("9.70"), D("9.99"), D("0.01")))
        self.assertEqual(book.commit_purchase(planned), planned)
        self.assertEqual(book.performing_par, D("9.70"))
        self.assertEqual(book.purchases, (planned,))

    def test_stale_or_forged_plan_is_rejected_without_secondary_mutation(self):
        book = self.book()
        first = book.plan_purchase(FIRST, D(10))
        competing = book.plan_purchase(FIRST, D(20))
        for forged in (replace(first, acquired_par=D(11)), replace(first, cash_used=D(9)),
                       replace(first, cohort_id="TRIDENT_REINV_000099"),
                       replace(first, acquired_par=10.0), replace(first, unused_cash=False)):
            with self.subTest(forged=forged):
                with self.assertRaises(InputValidationError):
                    book.commit_purchase(forged)
                self.assertEqual(book.performing_par, D(0))
                self.assertFalse(book.purchases)
        book.commit_purchase(first)
        with self.assertRaises(InputValidationError):
            book.commit_purchase(competing)
        self.assertEqual(book.performing_par, D(10))
        self.assertEqual(book.purchases, (first,))

    def test_purchase_wrapper_and_planning_use_owned_numeric_precision(self):
        with localcontext(Context(prec=2)) as context:
            context.traps[Inexact] = True
            planned_book = self.book(purchase_price=D("0.99"))
            planned = planned_book.plan_purchase(FIRST, D("100000000.01"))
            committed = planned_book.commit_purchase(planned)
            ordinary = self.book(purchase_price=D("0.99")).purchase(FIRST, D("100000000.01"))
        # Values are independently fixed, not rounded by the caller context.
        self.assertEqual(committed.acquired_par, D("101010101.02"))
        self.assertEqual(committed.cash_used, D("100000000.01"))
        self.assertEqual(committed.unused_cash, D(0))
        self.assertEqual(committed, ordinary)


if __name__ == "__main__":
    unittest.main()
