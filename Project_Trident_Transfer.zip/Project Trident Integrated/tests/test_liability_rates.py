"""Actual-day stub interpolation and independent calendar-role behavior."""
from datetime import date
from decimal import Decimal
from fractions import Fraction
import unittest

from trident.conventions.calendar import CalendarName, calendar_from_name, TargetCalendar, WeekendCalendar
from trident.conventions.liability_rates import FirstStubRateMethod, FixingDateAnchor, first_stub_reference_rate, fixing_date_for_period
from trident.conventions.schedule import ScheduleBuilder
from trident.domain.numeric import decimal_fraction
from trident.market.rates import FlatRateProvider

class LiabilityRateTests(unittest.TestCase):
    def setUp(self):
        self.provider = FlatRateProvider({"EURIBOR_1M": Decimal(".01"), "EURIBOR_3M": Decimal(".03"), "EURIBOR_6M": Decimal(".06")})

    def test_calendar_profiles_are_selected_explicitly(self):
        self.assertIsInstance(calendar_from_name(CalendarName.TARGET), TargetCalendar)
        self.assertIsInstance(calendar_from_name("Weekends Only"), WeekendCalendar)
        self.assertFalse(calendar_from_name("TARGET").is_business_day(date(2026, 12, 25)))
        self.assertTrue(calendar_from_name("WEEKENDS_ONLY").is_business_day(date(2026, 12, 25)))
        with self.assertRaises(ValueError):
            calendar_from_name("Paris")

    def test_calendar_role_and_anchor_are_independent(self):
        p = ScheduleBuilder(WeekendCalendar()).build(date(2026, 12, 28), date(2027, 3, 28), 3)[0]
        self.assertEqual(fixing_date_for_period(p, 1, TargetCalendar(), FixingDateAnchor.PERIOD_START), date(2026, 12, 24))
        self.assertEqual(fixing_date_for_period(p, 1, WeekendCalendar(), FixingDateAnchor.PERIOD_START), date(2026, 12, 25))
        self.assertGreater(fixing_date_for_period(p, 2, TargetCalendar(), FixingDateAnchor.PAYMENT_DATE), p.accrual_start)

    def test_selected_and_override_keep_reference_before_floor(self):
        args = self.provider, date(2026, 1, 29), date(2026, 1, 31), date(2026, 3, 31), "EURIBOR_3M"
        self.assertEqual(first_stub_reference_rate(*args, FirstStubRateMethod.SELECTED_REFERENCE), Decimal(".03"))
        self.assertEqual(first_stub_reference_rate(*args, FirstStubRateMethod.USER_OVERRIDE, Decimal("-.01")), Decimal("-.01"))
        with self.assertRaises(ValueError):
            first_stub_reference_rate(*args, FirstStubRateMethod.SELECTED_REFERENCE, Decimal(0))

    def test_actual_calendar_day_weight_differs_from_approximate_month(self):
        # Jan31 1M=Feb28, 3M=Apr30, Mar31 is 31/61 along the bracket.
        result = first_stub_reference_rate(self.provider, date(2026, 1, 29), date(2026, 1, 31), date(2026, 3, 31), "EURIBOR_3M", FirstStubRateMethod.INTERPOLATE_1M_3M_6M)
        expected = decimal_fraction(Fraction(1, 100) + Fraction(2, 100) * Fraction(31, 61))
        self.assertEqual(result, expected)

    def test_outside_available_tenors_uses_declared_endpoint_policy(self):
        for end, expected in ((date(2026, 2, 1), ".01"), (date(2027, 1, 31), ".06")):
            self.assertEqual(first_stub_reference_rate(self.provider, date(2026, 1, 29), date(2026, 1, 31), end, "EURIBOR_3M", FirstStubRateMethod.INTERPOLATE_1M_3M_6M), Decimal(expected))
