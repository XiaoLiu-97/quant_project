"""Named Excel inputs → typed model request → calculations → complete outputs.

The reader is shared with the inexpensive optimization preflight. It validates
transport and constructs requests without projecting loans or solving trades.
Execution separately validates output destinations, calculates all selected
services, then publishes a complete refresh. The outer Excel adapter alone owns
the atomic file replacement, so a failed calculation cannot save partial output.
"""

from dataclasses import dataclass, fields, replace
from datetime import datetime, timezone
from enum import Enum
from types import MappingProxyType
from typing import Mapping

from trident.analysis import LimitStatus
from trident.application.clo_services import TridentModelRequest, TridentModelResult, TridentModelService
from trident.domain.models import InputValidationError
from trident.optimization import StaticTradeOptimizer
from . import excel_schema as schema
from .excel import NamedWorkbook, _rate_provider
from .model_records import flat_record
from .optimization_records import optimization_request_from_records
from .records import boolean_value, coupon_steps_from_records, integer_value, position_from_record


INPUT_NAMES = schema.INPUT_NAMES
OUTPUT_KEYS = schema.OUTPUT_KEYS
OUTPUT_NAMES = schema.OUTPUT_SCALARS


def _read_table(adapter: NamedWorkbook, key: str) -> tuple[dict[str, object], ...]:
    records = adapter.table_records(schema.TABLE_RANGE_NAMES[key], schema.TABLE_NAMES[key])
    if key in schema.TABLE_COLUMNS:
        sheet, (left, top, right, _) = adapter.region(schema.TABLE_RANGE_NAMES[key])
        headers = tuple(sheet.cell(top, col).value for col in range(left, right + 1))
        if set(headers) != set(schema.TABLE_COLUMNS[key]):
            raise InputValidationError(f"Table headers do not match registered schema {schema.SCHEMA_VERSION}: {key}")
    return records


def _ensure_optional_inputs(adapter: NamedWorkbook) -> None:
    """Extend the optional current interface in memory before name validation."""
    from .pilot_workbook import ensure_pilot_interface
    ensure_pilot_interface(adapter)
    # Optional migration columns preserve the current named transport. Existing
    # workbooks gain only missing fields; changes remain in memory until the
    # full run succeeds and the outer adapter atomically replaces the file.
    protected = tuple(name for name in (*schema.SCALAR_NAMES.values(), *schema.TABLE_RANGE_NAMES.values())
                      if name in adapter.workbook.defined_names)
    for key in ("assets", "candidate_assets"):
        region = schema.TABLE_RANGE_NAMES[key]
        adapter.ensure_optional_columns(region, schema.TABLE_NAMES[key], schema.ASSET_OPTIONAL_TERM_COLUMNS,
            protected_names=tuple(name for name in protected if name != region))
    region = schema.TABLE_RANGE_NAMES["capital_stack"]
    adapter.ensure_optional_columns(region, schema.TABLE_NAMES["capital_stack"], {"pik_rate_fraction": "0.0000%"},
        protected_names=tuple(name for name in protected if name != region))
    for key in ("asset_cashflows", "clo_periods", "tranche_cashflows", "tranche_waterfall", "asset_par_movements"):
        region = schema.TABLE_RANGE_NAMES[key]
        formats = {field: schema.TABLE_NUMBER_FORMATS.get(key, {}).get(field, "General")
                   for field in schema.TABLE_COLUMNS[key]}
        adapter.ensure_optional_columns(region, schema.TABLE_NAMES[key], formats,
            protected_names=tuple(name for name in protected if name != region))
    for key, title, instruction in (
        ("cashflow_detailed_export", "Detailed Cashflows", "Native contractual A:X-compatible cashflow export; separate cash coupon, capitalized PIK and principal redemption. Display rates do not reconstruct posted coupon."),
        ("clo_economics", "CLO Economics", "Opening leverage, actual stressed cash yields, contractual coupon diagnostics, debt cost, fees and investor returns. Check status, basis, numerator and denominator."),
    ):
        adapter.ensure_optional_table(schema.TABLE_RANGE_NAMES[key], schema.TABLE_NAMES[key],
            schema.TABLE_COLUMNS[key], sheet_title=title, title=title, instruction=instruction,
            number_formats=schema.TABLE_NUMBER_FORMATS[key])
    adapter.ensure_optional_table(schema.TABLE_RANGE_NAMES["coupon_steps"], schema.TABLE_NAMES["coupon_steps"],
        schema.TABLE_COLUMNS["coupon_steps"], sheet_title="Coupon Steps", title="Dated coupon / margin steps",
        instruction=("Optional absolute levels: ASSET targets held Assets; CANDIDATE targets new Candidate Assets. "
            "Use exactly one fixed_rate (annual fraction) or spread_bps (bps). Policy must be consistent per loan: "
            "ACTUAL_DATE, PAYMENT_START (fixed only), RESET_START (floating only). Dates are unadjusted calendar dates."),
        number_formats=schema.TABLE_NUMBER_FORMATS["coupon_steps"], before_sheet="Guidance",
        auto_expand=True,
        list_options={"scope": ("ASSET", "CANDIDATE"),
                      "policy": ("ACTUAL_DATE", "PAYMENT_START", "RESET_START")})


def _registered_record(value: object, columns: tuple[str, ...]) -> dict[str, object]:
    """Flatten registered scalar fields once, avoiding nested projection copies."""
    row = {key: getattr(value, key) for key in columns}
    return {key: item.value if isinstance(item, Enum) else item for key, item in row.items()}


@dataclass(frozen=True)
class WorkbookModelInputs:
    """One input snapshot, with transport records separate from financial terms.

    Read-only mappings prevent later services from changing another service's
    baseline. The typed request carries financial meaning; row labels and
    workbook schema belong only to this adapter layer.
    """

    request: TridentModelRequest
    controls: Mapping[str, object]
    assets: tuple[Mapping[str, object], ...]
    capital: tuple[Mapping[str, object], ...]
    quotes: tuple[Mapping[str, object], ...]
    scenario_rows: tuple[Mapping[str, object], ...]
    coupon_step_records: tuple[Mapping[str, object], ...]
    seasoned_state_records: tuple[Mapping[str, object], ...] = ()
    opening_fixing_records: tuple[Mapping[str, object], ...] = ()


def _freeze_records(rows: tuple[Mapping[str, object], ...]) -> tuple[Mapping[str, object], ...]:
    """Copy transport rows once so services cannot mutate their common inputs."""
    return tuple(MappingProxyType(dict(row)) for row in rows)


def read_model_workbook_inputs(adapter: NamedWorkbook) -> WorkbookModelInputs:
    """Build the same inputs for preflight and execution without running engines.

    Formula/error inputs are rejected by ``NamedWorkbook`` rather than read from
    Excel's potentially stale cache. Calendar, units and contractual validation
    stay in existing typed parsers; this reader does not invent missing facts.
    """
    schema.require_current_schema(str(adapter.scalar(schema.SCALAR_NAMES["schema_version"])))
    _ensure_optional_inputs(adapter)
    assets, capital = _read_table(adapter, "assets"), _read_table(adapter, "capital_stack")
    factor_rows, limit_rows, quotes = (
        _read_table(adapter, key) for key in ("factor_mapping", "portfolio_limits", "trade_candidates"))
    controls = {key: adapter.scalar(schema.SCALAR_NAMES[key]) for key in schema.READ_INPUT_KEYS}
    from .coupon_proceeds_records import coupon_proceeds_from_workbook
    principal_accrued_balances, coupon_proceeds_allocations = coupon_proceeds_from_workbook(adapter, controls)
    from .clo_opening_records import opening_from_workbook, bind_ledger_opening
    opening_state, equity_value, equity_source, linked_ledger = opening_from_workbook(adapter, capital)
    if opening_state is not None and any(boolean_value(controls[key], key) for key in (
            'scenario_enabled', 'optimizer_enabled', 'candidate_search_enabled')):
        raise InputValidationError('Existing CLO opening currently requires closing redesign/scenario/optimization switches disabled')
    principal_rows = _read_table(adapter, "principal_schedule")
    step_rows = _read_table(adapter, "coupon_steps")
    from .pilot_workbook import seasoned_states_from_records
    state_rows, fixing_rows = _read_table(adapter, 'seasoned_positions'), _read_table(adapter, 'opening_fixings')
    seasoned_states = seasoned_states_from_records(state_rows, fixing_rows, assets)
    candidate_states = {}
    if any(row.get('scope') == 'CANDIDATE' for row in (*state_rows, *fixing_rows)):
        candidate_rows = _read_table(adapter, 'candidate_assets')
        candidate_states = seasoned_states_from_records(state_rows, fixing_rows, candidate_rows, scope='CANDIDATE')
        for row in candidate_rows:
            if row.get('loan_id') in candidate_states:
                position_from_record(row, seasoned_state=candidate_states[row['loan_id']])
    # Validate candidate step targets even while search is off. Empty optional
    # terms do not activate the otherwise disabled Candidate Assets surface.
    if any(row.get("scope") == "CANDIDATE" for row in step_rows):
        candidate_rows = _read_table(adapter, "candidate_assets")
        candidate_groups = coupon_steps_from_records(step_rows, candidate_rows, scope="CANDIDATE")
        indexed = {row.get("loan_id"): row for row in candidate_rows}
        if len(indexed) != len(candidate_rows):
            raise InputValidationError("Stepped Candidate Assets require unique loan_id values")
        for identifier, (steps, policy) in candidate_groups.items():
            position_from_record(indexed[identifier], coupon_steps=steps, coupon_step_policy=policy,
                                 seasoned_state=candidate_states.get(identifier))
    scenario_rows = _read_table(adapter, "scenario_edits")
    provider, provenance = _rate_provider(adapter)
    from .legacy_model_records import legacy_model_request_from_records, legacy_values
    from .cash_curve_records import cash_curve_provider_from_workbook
    values = legacy_values(controls)
    provider = cash_curve_provider_from_workbook(adapter, provider, values, controls,
        asset_indices=tuple(row.get("rate_index") for row in (*assets,
            *(_read_table(adapter, "candidate_assets") if boolean_value(controls["candidate_search_enabled"], "candidate_search_enabled") else ()))))
    request = legacy_model_request_from_records(assets, capital, provider, controls=controls, provenance=provenance,
        factors=factor_rows, limits=limit_rows, principal_schedule_records=principal_rows,
        coupon_step_records=step_rows,
        seasoned_states=seasoned_states,
        clo_opening_state=opening_state, forward_equity_value=equity_value, equity_value_source=equity_source,
        closing_cost_records=_read_table(adapter, "closing_costs"),
        recurring_expense_records=_read_table(adapter, "recurring_expenses"),
        detailed_records=_read_table(adapter, "collateral_detailed"),
        simplified_records=_read_table(adapter, "collateral_simplified"))
    from trident.clo.models import DefaultedAssetOcTreatment
    from .credit_records import credit_events_from_records
    events = credit_events_from_records(
        _read_table(adapter, "credit_events"), _read_table(adapter, "recovery_schedule"),
        loan_ids=frozenset(position.terms.loan_id for position in request.cashflow_request.positions))
    terms = None if request.clo_terms is None else replace(
        request.clo_terms, defaulted_asset_oc_treatment=DefaultedAssetOcTreatment.ADJUSTED_POLICY)
    request = replace(request, credit_events=events, clo_terms=terms,
        principal_accrued_balances=principal_accrued_balances,
        coupon_proceeds_allocations=coupon_proceeds_allocations)
    from .records import date_value, text_value
    dates = _read_table(adapter, 'observation_dates')
    for row in dates:
        text_value(row.get('source'), 'observation date source')
    request = replace(request, portfolio_observation_dates=tuple(
        date_value(row.get('observation_date'), 'portfolio observation date') for row in dates))
    if linked_ledger:
        request = bind_ledger_opening(adapter, request)
    return WorkbookModelInputs(request, MappingProxyType(controls), _freeze_records(assets),
                               _freeze_records(capital), _freeze_records(quotes), _freeze_records(scenario_rows),
                               _freeze_records(step_rows), _freeze_records(state_rows), _freeze_records(fixing_rows))


def execute_model_workbook(adapter: NamedWorkbook) -> TridentModelResult:
    """Validate destinations, calculate a common baseline, publish named outputs.

    Static LP/MILP proposals and full candidate CLO replays remain different
    services. Sharing their baseline never turns static feasibility into legal
    purchase eligibility or a claim of globally optimal equity IRR.
    """
    output_names, input_names = OUTPUT_NAMES, INPUT_NAMES
    schema.require_current_schema(str(adapter.scalar(schema.SCALAR_NAMES["schema_version"])))
    _ensure_optional_inputs(adapter)
    output_table_names = tuple(schema.TABLE_RANGE_NAMES[key] for key in schema.OUTPUT_TABLE_KEYS)
    for name in output_names:
        adapter.scalar(name)
    adapter.validate_output_layout((*output_names, *output_table_names), input_names)
    for key in schema.OUTPUT_TABLE_KEYS:
        _read_table(adapter, key)
    # Phase 1: a single immutable input snapshot feeds every selected service.
    inputs = read_model_workbook_inputs(adapter)
    request, controls = inputs.request, inputs.controls
    assets, capital, quotes, scenario_rows = inputs.assets, inputs.capital, inputs.quotes, inputs.scenario_rows
    # Phase 2: the optional search cache owns all projections it reuses. It
    # cannot accept arbitrary caller results, and equality checks include the
    # full contract, market provider, fees, gates and scenario configuration.
    search_enabled = boolean_value(controls["candidate_search_enabled"], "candidate_search_enabled")
    if search_enabled:
        from trident.application.candidate_search import ModelProjectionCache
        model_service = ModelProjectionCache()
    else:
        model_service = TridentModelService()
    batch = None
    if boolean_value(controls["scenario_enabled"], "scenario_enabled"):
        from trident.application.scenarios import ScenarioRunner
        from .scenario_records import scenarios_from_records
        batch = ScenarioRunner(service=model_service).run(request, scenarios_from_records(scenario_rows))
        result = batch.baseline
    else:
        result = model_service.run(request)
    optimize = boolean_value(controls["optimizer_enabled"], "optimizer_enabled")
    optimization = None
    if optimize:
        optimization = StaticTradeOptimizer().solve(optimization_request_from_records(
            assets, quotes, controls, request.factor_mapping, result,
        ))
    search = None
    if search_enabled:
        from trident.application.candidate_search import ClosingPoolSearchService
        from .candidate_records import candidate_search_from_records
        search = ClosingPoolSearchService(service=model_service).run(candidate_search_from_records(request, result, assets, quotes, controls,
            coupon_step_records=inputs.coupon_step_records,
            seasoned_state_records=inputs.seasoned_state_records, opening_fixing_records=inputs.opening_fixing_records,
            **{key: _read_table(adapter, key) for key in ("candidate_assets", "candidate_metadata", "candidate_ratings", "quote_observations", "candidate_variants")}))
    # Phase 3: flatten only the registered scalar output fields. Deep dataclass
    # conversion would copy complete nested loan/waterfall projections per row.
    projection, portfolio, clo = result.cashflows, result.opening_portfolio, result.clo
    # Publish the event-aware post-event report stream, including closing.
    # The separate opening result remains the pre-event admission benchmark;
    # it is not duplicated as an indistinguishable same-date Excel row.
    reports = result.portfolio_observations or (portfolio, *result.portfolio_snapshots)
    tables = {
        "asset_cashflows": tuple(_registered_record(row, schema.ASSET_CASHFLOW_COLUMNS) for row in projection.cashflows),
        "portfolio_metrics": tuple({"as_of_date": report.as_of_date, "phase": report.phase, **flat_record(row)} for report in reports for row in report.metrics),
        "concentrations": tuple({"as_of_date": report.as_of_date, "phase": report.phase, **flat_record(row)} for report in reports for row in report.concentrations),
        "limit_tests": tuple({"as_of_date": report.as_of_date, "phase": report.phase, **flat_record(row)} for report in reports for row in report.limits),
        "clo_periods": () if clo is None else tuple(_registered_record(row, schema.TABLE_COLUMNS["clo_periods"]) for row in clo.periods),
        "tranche_cashflows": () if clo is None else tuple(_registered_record(row, schema.TABLE_COLUMNS["tranche_cashflows"]) for row in clo.tranche_periods),
        "coverage_tests": () if clo is None else tuple(flat_record(row) for row in clo.coverage_tests),
        "equity_cashflows": (() if clo is None else (
            {"payment_date": projection.projection_start_date, "amount": result.equity_cashflows[0].amount,
             "source": "CURRENT_EQUITY_VALUE" if request.clo_opening_state is not None else "INITIAL_EQUITY_FUNDING"},
            *({"payment_date": row.payment_date, "amount": row.amount, "source": row.source} for row in clo.equity_cashflows),
            *({"payment_date": row.payment_date, "amount": row.amount.copy_negate(), "source": row.source}
                for row in clo.equity_contributions),
        )),
        "optimizer_trades": () if optimization is None else tuple(flat_record(row) for row in optimization.trades),
        "optimizer_summary": (),
        "clo_economics": tuple(_registered_record(row, schema.TABLE_COLUMNS["clo_economics"]) for row in result.economics),
    }
    from .detailed_export import detailed_cashflow_records
    tables["cashflow_detailed_export"] = detailed_cashflow_records(projection.cashflows, request.cashflow_request.positions)
    if optimization is not None:
        tables["optimizer_summary"] = tuple({"name": key, "value": getattr(optimization, key), "message": "Static opening snapshot; proposed trades have not been executed or replayed in the CLO"}
                                             for key in ("status", "solver_status", "solver_message", "solver_method", "solver_objective",
                                                         "solver_bound", "solver_gap", "factor_provenance", "ending_cash", "ending_par", "overall_factor",
                                                         "bsl_factor", "spread_bps", "validation_scope", "clo_replay_status", "solver_optimality_scope"))
        tables["optimizer_summary"] = tuple({**row, "value": row["value"].value if hasattr(row["value"], "value") else row["value"]} for row in tables["optimizer_summary"])
        tables["optimizer_summary"] += tuple({"name": "POST_VALIDATION_VIOLATION", "value": item, "message": "Proposal rejected; do not execute"} for item in optimization.violations)
        tables["optimizer_summary"] += (
            {"name": "portfolio_limit_table_validation", "value": "NOT_RUN", "message": "Optimizer validates its explicit linear limits; arbitrary Portfolio Limits and candidate eligibility are not certified"},
            {"name": "equity_irr_optimization", "value": "NOT_RUN", "message": "MIN_FACTOR/MAX_SPREAD are static objectives; no claim of improved equity IRR"},
        )
    tables["scenario_comparisons"] = () if batch is None else tuple(flat_record(row) for case in batch.scenarios for row in case.comparisons)
    tables["scenario_periods"] = () if batch is None else tuple(flat_record(row) for case in batch.scenarios for row in case.period_comparisons)
    credits = result.credit_projections
    tables["credit_collections"] = tuple(flat_record(row) for item in credits for row in item.collections)
    tables["asset_par_movements"] = tuple(flat_record(row) for item in credits for row in item.par_movements)
    tables["credit_summary"] = tuple(_registered_record(row, schema.TABLE_COLUMNS["credit_summary"]) for row in credits)
    from trident.clo.reporting import report_equity_periods, report_tranche_periods
    class_rows = []
    if clo is not None:
        class_rows.extend({**flat_record(row), "instrument_type": "DEBT"}
                          for row in report_tranche_periods(clo))
        residual = next(row for row in capital if row["instrument_type"] == "EQUITY")
        class_rows.extend(flat_record(row) for row in report_equity_periods(clo,
            class_id=residual["class_id"], payment_priority=integer_value(residual["payment_priority"], "equity payment_priority"),
            equity_cash_funding=result.equity_cashflows[0].amount.copy_abs()))
    # A common presentation schema leaves inapplicable note metrics blank
    # for equity, whose actual residual cash is independently reconciled.
    columns = schema.TABLE_COLUMNS["tranche_waterfall"]
    tables["tranche_waterfall"] = tuple({key: row.get(key) for key in columns} for row in
        sorted(class_rows, key=lambda row: (row["period_number"], row["payment_priority"])))
    tables["funding_summary"] = () if projection.funding is None else tuple(
        {"name": field.name, "value": getattr(projection.funding, field.name), "unit": projection.currency}
        for field in fields(projection.funding))
    from .clo_opening_records import opening_audit
    tables['clo_opening_audit'] = opening_audit(adapter, request)
    tables['coupon_proceeds_audit'] = () if clo is None else tuple(_registered_record(row,
        schema.TABLE_COLUMNS['coupon_proceeds_audit']) for row in clo.coupon_proceeds_audit)
    from .legacy_execution import assumption_execution_records
    tables["assumption_execution"] = assumption_execution_records(controls)
    overlay = None if clo is None else clo.original_overlay_projection
    tables["overlay_summary"] = () if overlay is None else tuple(_registered_record(row,
        schema.TABLE_COLUMNS["overlay_summary"]) for row in overlay.assets)
    tables["overlay_collections"] = () if overlay is None else tuple(flat_record(row) for row in overlay.collections)
    tables["overlay_par_movements"] = () if overlay is None else tuple(flat_record(row) for row in overlay.par_movements)
    tables["reinvestment_purchases"] = () if clo is None else tuple(flat_record(row) for row in clo.reinvestment_purchases)
    tables["reinvestment_par_movements"] = () if clo is None else tuple(flat_record(row) for row in clo.reinvestment_par_movements)
    from .candidate_records import candidate_result_record
    evaluations = () if search is None else search.evaluations
    tables["candidate_results"] = tuple(candidate_result_record(row, search.selected_candidate_id) for row in evaluations)
    tables["candidate_trades"] = tuple({"candidate_id": row.candidate_id, **flat_record(trade)} for row in evaluations
        if row.replay is not None and row.replay.plan is not None for trade in row.replay.plan.trades)
    tables["candidate_findings"] = tuple({"candidate_id": row.candidate_id, **flat_record(finding)} for row in evaluations
        if row.replay is not None for finding in row.replay.findings)
    if evaluations and evaluations[0].replay is not None:
        tables["candidate_findings"] += tuple({"candidate_id": "UNIVERSE", "code": "CANDIDATE_QUARANTINED", "message": "; ".join(row.reasons),
            "source": "FROZEN_SNAPSHOT", "severity": "WARNING", "payment_date": None, "identifier": row.asset_id}
            for row in evaluations[0].replay.admission.quarantined)
    values = dict(zip(schema.BASE_RESULT_KEYS, (
        "COMPLETED_CASHFLOW_ONLY" if clo is None else f"CLO_{clo.status.value}", projection.run_id, projection.asset_count,
        projection.opening_collateral_par, projection.total_principal, projection.total_interest,
        None if projection.funding is None else projection.funding.equity_cash_funding,
        None if projection.funding is None else projection.funding.debt_proceeds, projection.first_payment_date,
        projection.first_payment_interest, projection.rate_provenance, projection.projection_start_date,
    )))
    values.update(
        result_clo_status="NOT_SELECTED" if clo is None else clo.status.value,
        result_equity_irr=result.equity_irr.value, result_equity_irr_status=result.equity_irr.status.value,
        result_equity_moic=result.equity_moic.value,
        result_equity_distributions=None if clo is None else clo.total_equity_distributions,
        result_final_debt_par=None if clo is None else clo.final_debt_par,
        result_was_bps=portfolio.metric("WAS_BPS").value, result_wal_years=portfolio.metric("WAL_YEARS").value,
        result_warf=portfolio.metric("WARF").value, result_warf_status=portfolio.metric("WARF").status.value,
        result_test_factor=portfolio.metric("TEST_FACTOR_AVERAGE").value,
        result_opening_limit_breaches=sum(row.status is LimitStatus.BREACH for row in portfolio.limits),
        result_optimizer_status="DISABLED" if optimization is None else optimization.status.value,
    )
    values.update(result_scenario_status="DISABLED" if batch is None else ("COMPLETED" if batch.scenarios else "NO_SCENARIOS"),
                  result_scenario_count=0 if batch is None else len(batch.scenarios))
    values.update(
        result_was_status=portfolio.metric("WAS_BPS").status.value,
        result_wac_rate=portfolio.metric("WAC_RATE").value,
        result_wac_status=portfolio.metric("WAC_RATE").status.value,
        result_opening_limit_unavailable_count=sum(row.status is LimitStatus.UNAVAILABLE for row in portfolio.limits),
        result_last_calculated_at=datetime.now(timezone.utc).isoformat(timespec="seconds"),
    )
    values.update(result_candidate_search_status="DISABLED" if search is None else search.status.value,
                  result_selected_candidate=None if search is None else search.selected_candidate_id)
    from .pilot_workbook import pilot_reports
    tables.update(pilot_reports(adapter, result, tables, values, positions=request.cashflow_request.positions))
    # Surface newly supported optional terms only after calculations succeed.
    # Existing fields/order/values remain intact; the adapter resolves and
    # extends both the named range and native Table, rejecting any overlap.
    for key in ("assets", "candidate_assets"):
        region = schema.TABLE_RANGE_NAMES[key]
        adapter.ensure_optional_columns(region, schema.TABLE_NAMES[key], schema.ASSET_OPTIONAL_TERM_COLUMNS,
            protected_names=tuple(name for name in (*schema.SCALAR_NAMES.values(), *schema.TABLE_RANGE_NAMES.values())
                                  if name != region))
    for key, rows in tables.items():
        protected = (*input_names, *output_names, *(name for name in output_table_names if name != schema.TABLE_RANGE_NAMES[key]))
        adapter.write_table(schema.TABLE_RANGE_NAMES[key], schema.TABLE_NAMES[key], rows, protected_names=protected,
                            number_formats=getattr(schema, "TABLE_NUMBER_FORMATS", {}).get(key))
    for key, value in values.items():
        adapter.write_scalar(schema.SCALAR_NAMES[key], value)
    # The UI policy is independent of financial posting. Names still resolve
    # after safe horizontal consolidation, and the outer atomic saver alone
    # publishes the complete calculation together with its presentation.
    from .workbook_presentation import apply_workbook_presentation
    adapter.presentation_report = apply_workbook_presentation(adapter)
    retained = tuple(item for item in adapter.presentation_report['consolidation'] if item['status'] == 'SKIPPED')
    if adapter.presentation_report['sheet_order_retained']:
        retained += (dict(sheet='WORKBOOK_TAB_ORDER', reason=adapter.presentation_report['sheet_order_reason']),)
    if retained:
        # A user's custom objects/references must survive, and Excel users must
        # see why a requested presentation consolidation was safely retained.
        # This is an informational UI finding; it changes no financial status.
        findings = tables['readiness_findings'] + tuple(dict(code='UI_LAYOUT_RETAINED', severity='INFO',
            entity_id=item['sheet'], observation_date=projection.projection_start_date,
            message='Original input layout retained: ' + item['reason']) for item in retained)
        key = 'readiness_findings'
        adapter.write_table(schema.TABLE_RANGE_NAMES[key], schema.TABLE_NAMES[key], findings,
            protected_names=(*input_names, *output_names, *(schema.TABLE_RANGE_NAMES[other]
                for other in schema.OUTPUT_TABLE_KEYS if other != key)),
            number_formats=schema.TABLE_NUMBER_FORMATS[key])
    return result
