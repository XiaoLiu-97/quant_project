# 紧凑界面的样式与维护约定

本项目保留15个用户页；`_Lists` 保存选项和输入 witness，`_Results` 保存完整 case 与审阅记录。样式帮助区分输入与结果；实际所有权仍由 Table、header 和 named owner 决定。显示格式不改变底层数值、单位或金融计算。

| 显示 | 含义 |
| --- | --- |
| 蓝色文字、浅蓝输入区 | 在 owning input 中修改；保存关闭后重新运行 |
| 深色文字、浅灰结果区 | 已保存结果、lookup 或显示选择；不能替代输入 |
| 灰色文字与灰色 Value 背景 | 保留参考字段；按 `When used` 和单元格备注找到真正所有者 |
| 提示条与状态文字 | 阅读 basis、缺失数据或下一步动作；颜色本身不证明 test 通过 |

字体使用 Arial。数据与选择器通常居中；说明使用左对齐、必要时换行。新增说明采用 Arial 10。主结果区保持紧凑，完整记录通过命名入口和支持表检查。

## 保留参考与真正所有者

| CLO Assumptions 字段 | 实际使用与编辑位置 |
| --- | --- |
| Collateral Purchase Price | 保留参考；实际 acquisition price 由 Collateral Pool 的每项持仓拥有 |
| Purchased Accrued Interest | 保留参考；实际 purchased accrued 由 Collateral Pool 的每项持仓拥有 |
| Reference Curve | 保留参考；各 debt tranche 的 Coupon index 由 Capital Stack 拥有 |
| Day Count | 设置 synthetic reinvestment coupon convention；note day count 在 Capital Stack，loan day count 在资产合同，账户和费用使用明确 execution policy |
| Collateral Cashflow Input Mode | 保留的 imported-mode 参考；当前界面运行 `INTERNAL_ENGINE` |

四个参考 Value 使用灰色样式；Day Count 仍是可执行的 synthetic convention。原字段名称、field ID、Value、公式和 number format 保留。`When used` 与原生 Excel 备注说明实际 owner，不引入 aggregate override。

## 单位与缺失数据

| 内容 | 显示约定 |
| --- | --- |
| Face / notional | 主视图整数显示；底层金额保持原精度 |
| EUR cash、fee、claim、funding | 两位小数；规定 posting 节点到 cent |
| 日期 | 选择器、可见明细、隐藏结果及日期目录统一使用 numeric Excel date，显示 `dd-mmm-yyyy`；图表周期标签可使用 `mmm yy`，不替代日期身份 |
| 年数 / WAL | 三位小数；保留原计算 basis |
| 年化 rate、share、fraction、relative headroom | 百分比；bps 保持 bps 单位 |
| IC/OC ratio、MOIC | 明确 multiple / ratio；不与百分比混用 |
| Factor、count、period ID | 整数显示；保留原 metric 与 period identity |
| Portfolio limit Value / Threshold / Headroom | 按同一 case、date、phase 的原 metric unit；WARF 为 factor、WAS 为 bps、WAL 为 years、concentration 为 fraction，禁止全部套百分比 |

混合 Value 列按每条记录的 Unit 格式化。原生结果 Table 保留完整 status enum；紧凑视图可显示 `Missing data`、`Not set`、`Not selected` 或 `n.a.`。真实零、缺失、未配置和未选择保持区别；金额的零可能按格式显示为短横线，其底层值仍是零。可见 value 与 status 必须读取同一 saved case / scope。

## 增长、下拉框与模板持久性

原生下拉框使用有限 named list、Stop error 与输入提示。CLO 日期目录来自当前完整 case 的实际未来记录，排除其他 case 的空白尾行；case / scope / tranche 选择只过滤已保存输出。不存在当前 case 的记录显示缺失或不适用，不补零，也不改写 Python period number。

日期筛选与明细保持相同显示格式；运行刷新选项目录时同样写入 `dd-mmm-yyyy`，不能因新 case、新日期或隐藏列重新出现 General / 日期序号。日期显示修改不改变用于匹配的真实日期值。

所有 native Tables 均按输入、固定 schema、结果或支持数据登记容量；隐藏 `_Results` 的 `tbl_trident_ui_table_capacity` 区分物理行数、实际记录数、请求容量及容量类别。资产 register、terms、details、Pool 和 Trade Universe 预留300行；评级预留900行；bespoke principal schedule 和 asset events 各预留3,000行；Capital Stack预留12行、limits100行，Scenario Edits与factor mapping各300行。新增 owning 行保留真实空白、原生输入格式和约束；已有有效值与 formula 不替换。固定账户、费用及枚举保留其语义数量，Market Data 的原有粘贴布局保留。完整规则见 [Table 容量](table_capacity.md)。

结果 Tables 在独立列区预留与资产、期数、tranche 和 case 相匹配的物理容量；真实记录数量独立登记，未使用尾部保持空白，不预填结果公式或零值。容量足够时重复运行后的 Table ref 保持稳定，Writer 复用已有 cell styles 和不变的展示公式；超过容量时才安全扩展。结果缩短时清除过期值、formula 及 cache，保留可复用的空白样式尾部。Waterfall 原始数据放入隐藏结果页，主矩阵按实际记录顺序扩展。相邻 Table、owning input 或 Excel 容量发生碰撞时停止发布，不截断结果。原生图表保留；范围与缓存跟随新完整结果刷新。Market Data package part 与无关内容保留，已有 style resources 不改号，新增样式追加。

CLO Assumptions的OC ownership说明和导航使用右侧独立区域 `AC9:AH20`，Table为 `AC10:AE14`；factor warning使用 `AC22:AH22`。这为limits及factor mapping向下增长留出空间，保留named navigation和原业务输入位置。移动前核验新区域没有Table、owning input、合并区或已有内容碰撞。

模板保留两条说明区域：CLO Analysis `B8:P8` 显示 freshness，保留 `B8` 的公式和 cache；Asset Cashflows `B6:P6` 说明合同 reference 与 default/prepayment-adjusted receipts 的区别。两处均先核验无 owning input、dropdown 或有效内容碰撞。模板中的合并、样式、说明与备注在运行写入时保留；后续模板修改应再次验证 typed request 和 input fingerprint 不变。

输入操作见 [使用指南](user_guide.md)，格式与计算的边界见 [架构](architecture.md)。

## 每次界面变更的验收

新增、修改或删除界面内容后，在交付前检查整个界面的格式、交互及业务语义，覆盖15个用户页、两个隐藏支持页、所有 Tables 与预留区域。颜色、字体只是检查的一部分；还包括字体层级、单位与日期、对齐、边框、行高列宽、换行、导航、冻结、分组/隐藏、下拉框、状态提示、图表及邻接区域。纯内部代码变更且不影响界面、显示、输出 schema 或交互时，无需额外进行界面检查；修改显示 writer 仍属于界面变更。

长表颜色必须遍历每个业务分区及其交界，核对每行同角色字段、直接填充、named-style继承及Table条纹。不能用首行/中间/末行几个截图替代完整分区检查；用原生Excel DisplayFormat检查实际底色/字体，并明确记录哪些范围已逐段渲染。检查还覆盖空白容量，实际每个 saved case，以及 relevant date/tranche/scope selectors。验证 names/Tables、validation 和 chart bindings 没有遗漏或失效；正常 Excel 打开、交互、保存重开后仍正确。不得以用户自行发现问题作为验收步骤。自动结构/单位检查与渲染视觉检查互相补充，任何一个都不能独立证明全部布局正确。

正文说明左对齐并换行，输入/结果数据和选择器居中；readonly labels 与灰色 lookup 不能使用可编辑输入的蓝色提示。表头完整冻结，长枚举、负现金、首次资金投入、隐藏明细及末期日期需要足够列宽。预留 owning input 保持实际 schema 的格式和 Stop validation；混合 New value/Threshold/event Value 的未填空行使用 General，不能从第一个 bps 或百分比例子推测后续字段单位。已填日期格式保留，因为 input reader 需要真实日期类型。

状态条件格式使用精确状态身份：FAIL/BREACH 为红色，UNAVAILABLE/Missing data/BLOCKED/过期输入为橙黄色，未配置/未选择/不适用为灰色。NO BREACH 和 UNCHANGED INPUTS 不应因包含单词而触发失败或过期提示。有效零仍是有效数值；friendly status 与 raw enum 的映射不得补造 AVAILABLE。Waterfall 状态覆盖完整实际及预留期间，规则的显示范围不生成额外金融期间。

`python scripts/apply_interface_style.py --source <source.xlsx> --output <review.xlsx> --evidence <evidence.json>` 用于对独立候选文件应用模板样式政策。它按 named Table/header 定位，复用或追加样式，不改写已有 style ID；逐页核验 raw types、values、formulas 和 caches 没有变化，并检查 Market Data、names 及 Table definitions 保留。随后验证 writer 格式持久性，进行 native Excel 与视觉检查，最后通过来源 hash guard 发布。仅颜色修正可使用 `--palette-only`，通过所有 raw payload/公式/cache 精确未变及 focused writer 复用检查保持金融结果，无需重复执行金融计算。涉及日期类型、展示计算或金融含义时仍须重算相关路径。日常计算复用现有模板格式，不运行整套模板重建。

长表普通隔行底色由其原生Table样式统一管理，不按Section另建配色。普通body style清除直接及named-style继承填充；四个保留参考Value和状态CF保留自己的含义。Owning input字体统一 `#195CA8`，metadata使用 `#18334D`；预留capacity采用相同角色字体。定期维护和扩容应继续复用Table banding，不能复制某一行的固定底色到整段。
