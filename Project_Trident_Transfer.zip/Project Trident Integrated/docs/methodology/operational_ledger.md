# Operational holdings, cash and settlement ledger

The operational ledger reviews an explicitly supplied opening portfolio and subsequent cash, credit and trade events. It records settled face, separate principal and interest cash, reservations, unsettled commitments and opening receivables. Its replay remains independent of the CLO projection. The optional [existing CLO opening profile](existing_clo_opening.md) can now bind a fully settled, explicitly attested post-distribution snapshot to the same waterfall; entering a ledger balance or payment alone does not activate that connection.

Implementation: [typed inputs and outputs](../../src/trident/portfolio/models.py), [chronological replay](../../src/trident/portfolio/ledger.py), [Excel transport](../../src/trident/adapters/ledger_records.py), and [independent ledger tests](../../tests/test_holdings_ledger.py). The service uses immutable public records and one finite event-date sweep; it does not step through every calendar day.

## Opening state and recognition

`as_of_date` means **the beginning of the ledger day**. Opening cash and holdings must already include all earlier settled activity. Historical unsettled commitments reconstruct reservations without inventing past cash postings. Standalone Python accepts explicitly designated opening commitments with `trade_date <= as_of_date < settlement_date`; Excel classifies Trade Ledger rows with `trade_date < as_of_date` as opening commitments, and equality as new same-day trades. An already settled historical trade belongs in the supplied opening balances, rather than being replayed.

One request uses one currency: EUR, USD or GBP. Mixed currencies require an FX policy and are rejected. Settled face excludes unsettled purchases. A sale reserves deliverable face at commitment but retains the holding until settlement. A pending purchase provides no capacity to sell. Buying or selling changes actual cash and face together only on the explicitly supplied settlement date.

Two measures are deliberately reported:

| Measure | Definition | Interpretation |
| --- | --- | --- |
| Settled par | Sum of actual held face | Operational settled position, including defaulted face until explicit reduction |
| Trade-date par | Settled par + pending BUY par - pending SELL par | Commitment exposure diagnostic; not an automatically configured legal covenant numerator |
| Available to sell | Settled asset face - pending SELL face | Delivery capacity; pending BUY face is excluded |
| Available account cash | Actual account cash - reserved account cash | Commitment and payment capacity; outstanding claims are excluded |

An expected sale receipt and the retained holding must not both be counted as collateral value or OC assets. Legal tests may use a transaction-specific trade-date rule, anticipated proceeds, eligibility exclusions and maintain-or-improve conditions; this ledger does not infer those definitions.

## Price, accrued cash and account permissions

Trade par, accrued cash and fees are total currency amounts. `clean_price_pct=99` means 99 per 100 par. Clean consideration is `par * clean_price_pct / 100`, calculated exactly and posted once to cents using HALF_UP. Accrued cash is an explicitly verified signed settlement adjustment; fees are nonnegative. The ledger does not derive accrued entitlement or delayed settlement compensation from price or elapsed days.

Clean consideration uses principal cash. Accrued cash and fees each carry an explicit `PRINCIPAL` or `INTEREST` account. A nonzero component routed through principal requires its own permission: `allow_principal_for_accrued` or `allow_principal_for_fees`. These permissions authorize that supplied settlement component only; they do not classify later coupon receipts or establish legal authority. Receipts and payments must be classified independently from the actual transaction documents.

For each trade and account, the engine nets its own clean/accrued/fee settlement legs. A net debit reserves actual available cash; a net credit is an unavailable settlement receivable. It never finances one new purchase with another unsettled sale or claim. This is a conservative liquidity policy; a deal permitting binding commitments against expected proceeds needs a separately reviewed policy.

Example: buying 100 par at 99 with 2 accrued and 0.50 fees routed to interest reserves principal 99 and interest 2.50. Opening cash of principal 100 and interest 10 remains unchanged at commitment; settlement produces principal 1, interest 7.50 and settled face 100. A corresponding sale from zero cash retains the 100 face until settlement and reports expected principal 99 and net interest 1.50; those expected receipts are not spendable beforehand.

## Same-day policy

The dates alone provide no intraday chronology. Replay therefore applies this fixed, conservative order:

1. Actual cash collections and explicitly linked receivable collections.
2. Actual `CASH_PAYMENT` account debits.
3. Default classification, then noncash write-offs.
4. Cancellation of existing unsettled commitments.
5. Settlement of prior-day commitments, including opening commitments.
6. Reservation of **all** new commitments as one batch.
7. Settlement of new trades whose settlement date is that day.
8. An immutable closing snapshot.

Within each event phase, IDs provide deterministic ordering. A same-day receipt can fund a payment. A cancellation or settlement in a later phase cannot retroactively finance that payment: payments check unencumbered cash immediately. A prior sale settling today can fund a new commitment made today after settlement. A new same-day sale cannot fund a simultaneous new buy. New trade and cancellation on the same trade date are rejected because the required intraday order is ambiguous. These are model policies, not universal market conventions.

## Collections, defaults and pending claims

| Event | Cash and face treatment |
| --- | --- |
| `CASH_COLLECTION` | Credits the supplied principal/interest cash; reduces face only by explicit `par_reduction` |
| `CASH_PAYMENT` | Debits the supplied positive principal/interest amounts, without reducing face; cannot spend reserved cash or another account |
| `RECEIVABLE_COLLECTION` | Credits cash and consumes the referenced opening claim component by component; partial collection is supported, excess or duplicate collection fails |
| `DEFAULT` | Changes classification only; creates no recovery, repayment, cash or face reduction |
| `WRITE_OFF` | Reduces explicitly defaulted face without cash; performing forgiveness requires a separate contract policy |
| `TRADE_CANCEL` | Releases an active commitment before its settlement; creates no cash or face posting |

A claim due date creates an observation, not payment, automatic default or write-off. Overdue opening claims remain pending until an explicit collection. A zero-face opening holding can preserve a retired asset's claim identity; a later recovery can be collected without a second face reduction. Do not enter one receipt both as a linked claim collection and an unlinked cash collection. New future claim recognition and claim amendments are not yet supported.

An actual debt or fee `CASH_PAYMENT` is manually supplied account activity. It does not calculate tranche entitlement, arrears, IC/OC cures, diversion or the liability waterfall. A linked existing opening carries only the reconciled final state into the future waterfall, never those historical payments as new future receipts. A default affecting a pending trade requires cancellation or explicit reconfirmation; it cannot silently settle a stale performing quote. The standalone API exposes `allow_defaulted_asset` for that reconfirmation; the current Excel trade interface conservatively rejects defaulted-asset execution.

## Trade constraints and evidence

`lot_size` means an exact par multiple. `minimum_ticket` is the minimum full trade; `maximum_par` is frozen availability. The modeled trade settles in full or rejects: partial fills, assignment consent, exchange calendars, automatic settlement lags, order routing and real delivery-versus-payment execution are outside scope. A canceled trade has no later settlement posting. Scheduled repayments can reduce deliverable face before a sale settles; the user must explicitly cancel or amend the commitment rather than allowing an oversell.

The service returns a distinct pre-event opening snapshot, post-day snapshots, a signed journal and final pending items. It independently verifies:

```text
opening principal cash + sum(principal journal changes) = final principal cash
opening interest cash  + sum(interest journal changes)  = final interest cash
opening settled par   + sum(face journal changes)      = final settled par
```

Reservations and receivables are excluded from actual cash bridges. No sale P&L is inferred without a cost-basis policy. Excel reports are Ledger Cash, Holdings Timeline, Ledger Journal and Pending Items; the same-day row represents closing state. Supplied events retain their individual sources in the journal; generated commitment and settlement entries use Ledger Controls source. Claim sources remain attached to pending claims. Sources are not automatically authenticated against agent or trustee reports. Calculated References includes LEDGER_CASH and LEDGER_POSITION closing observations, so supplied independent cash, face and reservation benchmarks can be compared as well as the financial projection controls. Journal classification and source completeness also need review.

## Binding a settled snapshot to an existing CLO

The [typed bridge](../../src/trident/portfolio/clo_bridge.py) requires a mandatory post-distribution attestation and source. Ledger Controls horizon must equal CLO Opening as-of, and the operator must verify that the final end-of-day snapshot is after the same distribution. Equal dates do not infer the actual cash cutoff or coupon ownership. The core additionally checks the original distribution/accrual boundary.

Only EUR, fully settled physical cash and positive performing holdings can bridge: no pending trades, reserved balances, uncollected claims or positive defaulted inventory. Positive IDs/par/currencies/as-of dates must match the supplied current LoanPositions exactly. Known zero-par identities require explicit Retired Ledger Assets rows with sources and no remaining claim. The unified CLO still requires at least one positive performing native asset, even though the standalone bridge can validate an all-cash snapshot.

Excel calls strict `bind`: opening CLO PRINCIPAL and INTEREST must already equal actual snapshot cash. A mismatch rejects; user controls are not overwritten. Reserve, fees, unpaid note claims and principal designations remain separately supplied state. Pending opening CLO accounts must be zero for this bridge; they remain supported as explicit known cutoff balances in the unlinked native opening profile. The deliberately named standalone `import_cash` API can replace only physical principal/interest cash while preserving and validating the rest.

This is settled history to opening-state integration. It does not inject the journal into future collections or simulate future real trading through the waterfall. The next projected period starts with those balances once, according to [existing opening methodology](existing_clo_opening.md).

## Principal-funded accrued receipts

Settlement accrued account routing is independent of borrower coupon entitlement and the governing CLO proceeds classification. A sourced remaining balance and explicit first-receipt instruction can now classify native coupon cash in the unified waterfall. The ledger does not infer those inputs or inject a second receipt. See [coupon proceeds methodology](coupon_proceeds.md) for scope, caps and permissions.

## Primary references and scope of inference

The [LMA primary delayed settlement guidance announcement, 17 April 2024](https://www.lma.eu.com/news-publications/press-releases?id=214) describes a recommended ten-business-day primary syndication target and restricted compensation conditions. It does not establish a universal secondary BSL settlement lag. The model therefore requires actual settlement dates.

The [LMA secondary documentation archive, 18 February 2022 entry](https://www.lma.eu.com/policy-regulation/alerts-archive?show=older) states that secondary confirmation choices concerning compensation adjustments remain commercial elections agreed at trade. This supports explicit settlement adjustments rather than an assumed automatic compensation formula.

An [original SEC-filed CLO indenture](https://www.sec.gov/Archives/edgar/data/1373561/000119312512507388/d455464dex41.htm), section 1.3(n), uses trade dates for compliance calculations. Its definitions of Principal Financed Accrued Interest, Interest Proceeds and Sale Proceeds separately classify principal-funded purchased accrued interest. This US transaction is evidence of the need for explicit transaction rules, not a legal template for every EUR CLO. The ledger's separation of settled cash, commitment exposure and accrued permissions is a modeling inference from these distinctions; the actual deal documents remain the authority.

Use [pilot acceptance](../user_guide.md) for the initial supervised workflow and the required independent checks.
