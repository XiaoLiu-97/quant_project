# Default、repayment、recovery与reinvestment方法

更新：2026-10-08。区分explicit full-exit dated events、proportional经济overlay及agency stress。所有路径分开performing par、defaulted claim、recognized loss、contractual PIK capitalization 和actual collected cash；default后未收到的coupon不制造现金。Synthetic reinvestment是经济模板，不是实际BSL成交/settlement。

## 输入与领域映射

|旧 input|新对象与单位|实际行为|
|---|---|---|
|B62 Credit / Prepayment Overlay|`OriginalPoolOverlay.enabled` bool|Off 保留合同 cash/par；On 启用原池独立 CDR/CPR|
|B63 Annual Default Rate|`annual_default_rate` 年条件概率0–1|Flat 按 surviving performing par 应用 ACT/365F 条件退出；vector 模式定义五年经济累计目标|
|B64 Recovery Rate|`recovery_rate` fraction0–1|每次实际 default face 的回收现金，非 opening pool face|
|B65 Recovery Lag Months|`recovery_lag_months` 非负整数月|default date + 实际 calendar months；不再四舍五入成 note periods|
|B70 Original Collateral CPR|`annual_prepayment_rate` 年条件概率0–1|default、surviving scheduled 后对剩余本金应用，Off 不生效|
|B133 Default Timing Pattern|`DefaultTimingPattern`|保留 Flat 与 S&P Pattern1–4标签，修正累计量语义，见下文|
|B15 / B16|`SyntheticReinvestmentPolicy.end_date/enabled`|end date inclusive；final waterfall 不购买|
|B72 Reference Curve|`reference_curve` EURIBOR1M/3M/6M|独立于 note index，交由正常 market provider 提供 selected term fixing|
|B73 Spread|`spread_bps` bps，Excel fraction转换|先 reference floor，再加 spread|
|B74 Purchase Price|`purchase_price` fraction，0.99=99%|实际 cash 与 acquired par 独立；cent par 向下取整，cash residual 留账户|
|B75 WAL|`bullet_wal_years` years|明确 synthetic bullet maturity=purchase+HALF_UP(WAL×12)calendar months；不 capped 到 CLO maturity|
|B76 / B77|独立 `annual_prepayment_rate/default_rate`|新 cohort 自 settlement 起承担自身 CDR/CPR，不恢复旧 defaulted claim|
|B78 / B79|独立 recovery fraction / lag months|独立 claims、actual-date recovery、zero-recovery workout loss|
|B80 Recycle Principal|`recycle_reinvestment_principal`|Yes可使用全部eligible principal；No使用已授权original principal及held IDT，不能仅凭receipt为recovery/synthetic principal而授权|
|B81 Test Gate|`ReinvestmentTestGate`|STOP核验买前与拟买后generic OC/IC；ALWAYS是显式coverage/coupon敏感性override，资金/日期/long-dated等guards仍生效|
|B131 Reference Floor|`reference_floor` decimal rate|floor selected reference 之后才加 asset margin|

B66–69 CCC 与 terminal liquidation、B99–100 long-dated controls 属于共同 adjusted-OC / lifecycle policy；不在本模块重复实现估值。B75旧 tab 注释说 capped，但源 `modReinvestment.bas` 明确未 capped，保留实际业务行为并修正文档。

## 可复核的信用算法

本模块是 proportional fractional-loan **经济情景**。同一 loan 的 surviving slice 持续减少；它不是 borrower 的离散违约事件，也没有声称是机构完整 rating engine。旧 full-exit `AssetCreditProjection` 继续表达另一种确定性 dated event，两种路径不能叠加。

Flat CDR/CPR：`q=1−(1−annual_probability)^(actual_days/365)`。沿用已验证 `PeriodProbability.apply_to_par` 的 certified cent rounding，hazard clock 独立于 coupon day count。0/1率与零时间按显式端点处理。

每期顺序是 **midpoint default → surviving scheduled principal at its actual payment → end-date CPR**。midpoint 为 interval start + floor(days/2)，至少一个 elapsed day，用于 par 转移和 recovery 起点。**违约 slice 尚未收到的 coupon 全部不作为现金**；default 前已经实际收到的前期 coupon 保留。CPR 在期末发生，因此赚取完整 surviving coupon。这是明确的简化经济情景，并不自动代表某一机构全部压力或 loan 文件。当前实现已修正此前将未收到的半期应计利息当作现金的错误；不再混用经济违约日期与历史 midpoint coupon 压力规则。

例：100 performing，default20，contractual scheduled10，CPR50%，surviving scheduled8，end prepayment36，closing36，故 `100=20+8+36+36`。若一年365天，contract coupon10，则 interest cash 为 **8.00**，来自 survivor80 全期；default20 的未收到应计利息不支付。不能把 CPR50% 当成无条件退出50本金。100% default、zero recovery 的一期投资现金为0，而不是以前的约5.00半期 coupon。

Original pool 的未来 contractual principal 按每期 surviving-to-reference ratio 缩放，之前退出的本金不会在下一期复活。内部 CLO 通过显式 `loan_day_counts` 按合同 rate、opening par 和 exact Fraction DCF 计算 surviving coupon，最终一次 HALF_UP cent posting；不先舍入 full coupon 再缩放。独立 `project()` 缺 day-count map 时使用 frozen `interest_unrounded` diagnostic，不能因此声称所有截断 diagnostic 在 half-cent 边界得到 exact 认证。Synthetic coupon 对实际 surviving exposure 使用自身明确的 day count。

## 显式信用事件的回款与经济校验

`AssetCreditProjection` 在公开对象构造时同时校验 principal bridge、actual collections 和 event metadata。现金与本金加总正确，仍不足以证明一笔回款有经济依据：例如在没有 prepayment event 时增加一笔本金为0、利息为1000的 `PREPAYMENT` receipt，不会改变 principal bridge，却会凭空增加 equity cash。这类输入现在明确拒绝。

- Event 尚未到达 horizon 或未提供 event 时，collections 只能是原始 contractual reference 的 `SCHEDULED` prefix，不能出现任何 `PREPAYMENT` 或 `RECOVERY` receipt，金额为0也不例外。每个 contractual period 保留一条对应的 scheduled par operation；真实的同日多个付款期可以保留，但不能添加重复/no-op operation。
- 已发生 full `PrepaymentEvent` 必须恰好有一条 `PREPAYMENT` receipt，并与 event date、唯一 full-exit par operation 的本金一致。不能增加同日或其他日期的 interest-only receipt，也不能通过重复现金行绕过校验。同日 scheduled cash 先执行，prepayment 仅针对其后的 remaining face 和尚未收取的 current coupon。
- 已发生 `DefaultEvent` 只允许按显式 recovery schedule 生成 `RECOVERY` principal receipts；default 本身没有现金。每个已到达 horizon 的 recovery installment 必须恰好对应一条实际日期/累计 target 差额的回款。显式0和 rounded-zero recovery 仍保留一条记录；重复、拆分或移动日期的回款均拒绝。未来 recovery 留在 pending queue，未收 principal claim 不因现金为0而消失。

Native credit engine 从 `LoanPosition.terms.day_count` 自动携带 typed `contractual_day_count`。公开 aggregate 对已发生 prepayment 必须取得这个 convention，不能从 displayed full-period DCF 推断：不同 day count 可能在一个完整付款期得到相同 DCF，却在提前退出时得到不同金额。直接构造 aggregate 的调用者必须提供明确的 `DayCount`；没有 applied prepayment 的 legacy absent/default aggregate 可省略。正常 Excel/native workflow 不新增输入字段。

提供 convention 后，aggregate 先检查完整 contractual reference 的 accrual DCF、冻结 coupon segments 的连续覆盖、exact unrounded coupon 和 posted cash。随后以第一条尚未实际支付的原始 coupon row，使用共同 `cashflow_coupon_factor` 计算退出日前的 exact factor，避免把整个付款期的 weighted display rate 当作提前还款利率：

`prepayment_interest = post_currency(remaining_face × exact_partial_coupon_factor + unpaid_opening_accrued_exact)`。

上式是 Cash-only profile。Native PIK / Mixed 的 earned partial coupon 按 `pik_fraction` 拆分：gross coupon 和 PIK 各 posting 一次，cash 为二者残额；prepayment 在实际退出日将该当期 PIK 资本化并偿还 enlarged principal。详见下文，不把 PIK 再计为 interest cash。

原始 contract/reset/fixing 一致性仍由 `CreditEventCashflowEngine.apply(position, reference, event)` 按明确的 loan terms 校验；aggregate 使用这些冻结 reference 检查结果自身的一致性，不额外查询 market fixing。零 coupon、负 coupon 和同日 scheduled-first policy 均保留。已收 coupon 不重复计入；seasoned exact opening entitlement 与 forward earned coupon 合并后只做一次 cent posting，而不是先分别舍入再相加。

独立例子：100 par、12% ACT/360，原始 accrual anchor 为 Apr 1，May 15 开始 projection，FULL opening claim 的 exact amount 为 `22/15`，显示为1.47；Jun 1 prepayment 的 forward 17天为 `17/30`。两者 exact sum 为 `61/30`，最终 interest receipt 为 **2.03**，不能把显示的1.47与单独舍入的0.57相加成2.04。另一例没有 event 却添加1000的 interest-only `PREPAYMENT`，即使 total fields 同步增加1000且本金仍守恒，也必须报错。

独立 controls 见 [receipt trust-boundary tests](../../tests/test_credit_projection_receipts.py) 和 [release audit tests](../../tests/test_release_audit.py)。覆盖 absent/future phantom receipts、正确 event date 的伪造 coupon、错误/缺失 day count、重复/拆分/改日 recoveries、同日 execution ordering，以及 signed/zero coupon、seasoned exact history 和低精度 Decimal context。既有 [credit known-answer tests](../../tests/test_credit_events.py) 继续验证 zero recovery、future claims 和完整 cash/par/loss bridge。

## Timing vector 修正

Flat 是年条件率；四条历史五年 timing vector 是累计违约额的年度分配。旧权重/20%乘 CDR 算法改变 compounded defaults，被修正为：

`fixed_target = initial_reference_par × [1−(1−CDR)^5]`。

这是本模型为了保留一个 CDR输入而显式选择的 **economic five-year stress target**，不是机构给出的 scenario default rate。若实际机构另给 SDR，应使用 standalone `FixedCumulativeDefaultVector`，不得宣称该派生目标代替 agency SDR。历史向量39/22/16/13/10、16/23/26/22/13、12/18/22/23/25、20/20/20/20/20保留；按原始 closing 周年与每周年实际天数分配，累计cent target 的差保证总额不改变，五年之后不新增该 vector default。早到期、摊还或 CPR 可能让目标不可达；`unallocated_default_target` 明确报告，没有静默称为完成压力。

独立反例：100000、CDR10%，固定五年目标40951，Pattern1首年15970.89。首年全部资产到期后，其余24980.11是明确的 capacity shortfall。

## Claim、cash 与 reinvestment 守恒

每次 default 先增加 defaulted face；workout date 回收 `default_face×RR` 并将其余 face 记 loss，claim整体结清。RR=0、lag=0仍正常结清，不使用 cash/RR。超出 horizon 的 recovery 留在 pending queue，不自动形成 terminal cash。Synthetic queue 没有旧500cohorts或固定24period截断。

`performing_open + purchased_face + posted_PIK − scheduled − prepayment − default − sold_face = performing_close`。

`default_claim_open + new_defaults − recovery_principal − workout_loss − sold_claim_face = default_claim_close`。

`eligible_principal_cash − clean_purchase_cash − other_waterfall_uses = eligible_cash_close`。Discount price 增加的 par 不等于现金收益，也不自动等于 adjusted OC。Terminal disposal取消所卖 claim 的未来 recovery，防止 sale 和 recovery重复收款。

Synthetic purchases 在 waterfall 中完成，买入时不产生前一期 coupon。Ledger先用不改变状态的 `plan_purchase` 计算actual cash/par、cent residual及maturity；waterfall以拟购买后collateral value和剩余principal cash检查适用coverage，然后才 `commit_purchase`。被STOP否决的计划不创建cohort或支出现金。提交后立即更新valuation，用于当日后续principal gate。独立ledger提供dated receipts/movements、purchase actual cash/par、historical balances、par-day integrals和long-dated face；现金actual receipt与determination cut-off由共同CLO engine分配。

## 当前口径及边界

- `DefaultEvent` 为显式 full exit：同日 scheduled cash 先发生，再 default；之后仅显式 principal recovery，不推断未收 interest/fees recovery。
- Proportional default 是经济 midpoint 情景，default 先于 end-date scheduled/prepay；surviving slice earns完整 coupon，defaulted unpaid slice 不收。它不模拟离散 borrower contagion/migration。
- Flat hazard 使用 `1−(1−annual_probability)^(actual_days/365)`，cent posting 由现有 ln/exp interval certificate 决定；0/1率、RR0、lag0 与跨 horizon claim 分开。
- 原池 CLO exact day-count map 是正式计算路径；缺 map 的 standalone fallback 只可利用 unrounded diagnostic，不能承诺截断 recurring diagnostic 在任意 half-cent 处 exact。
- Imported source已含信用效果时拒绝重复overlay；default/recovery memo不额外增加cash/claims。来源明确的owned opening coupon entitlement与purchase accrued funding cost分开，二者不必相等。Default forfeits对应未收entitlement，first coupon/prepay仅收一次；含full entitlement的imported source不追加重复receipt。Cost、ownership与proceeds分类分别见[seasoned方法](seasoned_loans.md)及[收款分类](coupon_proceeds.md)。
- RR0 且 workout 在 horizon 后仍有 defaulted face，pending recovery cash可以为0；不能因现金0自动删 claim。Legal-final sale 的现金估值与 OC claim 认可分开；所卖 claim 的未来 rights 被取消。
- Synthetic template reinvestment使用actual eligible cash、clean price与独立acquired par，未来cohort不继承原池评级和集中度metadata。STOP检查买前和prospective买后generic OC/IC，后者包含purchase价差、long-dated haircut和现金政策；当期IC不使用新cohort未来coupon。`Always Reinvest` 是coverage/unpaid-coupon敏感性override，仍保留资金、期限和asset-level classification guards。Generic买后coverage不证明完整§12.2质量测试。独立真实commitment/settlement/receivables账本及settled opening bridge已实现；未来交易逐期接入waterfall、完整post-purchase法律测试及更广源款权限仍需开发。
- 本模型仍不支持泛化 workout coupon/fees 重分类、opening defaults、migration、合同级 interest-recovery basis，不能把这些缺失数据当作0风险。

## Native PIK / Mixed、O/N 和 payment lag

Native contract projection 已支持 Cash / PIK / Mixed；PIK 是明确的 capitalized face 增量，不是违约后的未付 cash coupon。`AssetParMovement.non_cash_par_change` 与 `OverlayParMovement.non_cash_par_change` 以独立字段记录实际资本化；`AssetCreditProjection.total_pik_interest` 从已发生的 par operations 汇总，不从 future reference 或 cash coupons 推测。

**Explicit dated event 路径：**无 event 的贷款可以与同一 portfolio 中其他 defaulted / prepaid loans 一起生成完整 PIK ledger。已完成 coupon boundary 的 PIK 增加 performing face；default 只把当时实际 face 转为 defaulted claim，不添加尚未到资本化日的 current PIK。Scheduled coupon / PIK / principal 在同日 event 之前执行。例：100 par、12% quarterly、30E/360，在两个 coupon boundary 后 default，实际 exposure 为106.09，已资本化PIK为6.09；50% recovery 的累计 target 为53.05，loss为53.04。

Explicit prepayment 按 original frozen coupon factor 计 accrual 至实际退出日。Cash / Mixed 的 cash share 进入 interest receipt；PIK share 同日资本化，并包含在 principal redemption。100 par、12% 30E/360、Jan 1至Feb 15，44/360年的 earned coupon 为1.4666…，100% PIK 则 capitalized1.47、principal101.47、cash interest0。50% Mixed 则 capitalized0.73、cash interest0.74、principal100.73。既有 opening cash claim 是 cash，仅收一次，不因新 PIK profile 改成资本化。

Explicit `CreditEventCashflowEngine` 仍要求 **zero contractual payment lag**，PIK还要求 **accrual end与cash date一致**。即使lag为0，Unadjusted accrual加Following付款调整也可能有间隙；当本金effective reduction/PIK boundary与现金receipt间存在时间差，default/prepayment会同时涉及尚未结算receivable和新期间本金，当前full-exit profile不能凭一个face推断其法律归属，明确拒绝。Standalone contract和完整native CLO baseline的paymentlag已支持；它们与这个event-policyguard不是同一个边界。

**Legacy annual CDR/CPR 路径：**`OriginalPoolOverlay.project` 对 zero-lag native PIK 保留 exact frozen coupon factors。Defaulted slice 失去其尚未收取/资本化的 current coupon，surviving slice 才产生 actual PIK。Scheduled principal 依据 surviving-to-reference participation；final repayment 使用 survivor face + actual current PIK，保证 cash/par 守恒。CPR 在完整 surviving coupon / capitalization / scheduled principal 后作用，因此退出base包含已资本化PIK。CDR100%、RR50%、lag0对opening100的结果是cash50、loss50、PIK0；CPR100%、CDR0则firstquarter capitalize3并prepay103。

Native PIK 配合 **nonzero payment lag** 时，CLO使用 `project_external` 的独立 accrual-end noncash movement 和 actual-payment-date coupon/principal ledger。这是为旧 annual overlay 完整迁移提供的明确 source-date profile。`prepayment_dates_by_loan` 限制 CPR 只发生在 source actual cash dates；capitalization-only date 不允许额外提前还款。CPR hazard time仍从前一个允许的cash boundary累计，而不是仅用capitalization后到receipt的数日。Defaults按实际source interval发生；capitalized face和未收cash都遵守当前overlay的surviving entitlement政策。这不证明任意真实loan-agent receivable/default交叉条款。

Projected ESTR / SOFR / SONIA coupon 的 unposted factor 储存在 frozen segment 的 `exact_factor` / `exact_index_factor`。完整 period 使用 `DF(start)/DF(end)-1`，margin在compounding外加入；partial explicit prepayment按冻结的equivalent period factor乘partial DCF比例。它是明确的 projected-period-rate assumption，不是 observed-RFR lookback/lockout 或实际partial index ratio。曲线不能替代historical realized observations。完整输入、公式和假设见[native coupon方法](native_coupon_migration.md)。

Native PIK principal redemption可以大于original opening face，因为包含capitalized coupon。Analytics不能因此报普通principal overpayment，也不能把capitalized interest当funded-principal WAL。当前WAL对受PIK影响的denominator保留INCOMPLETE或UNAVAILABLE，并说明缺少明确的funded-principal allocation profile；rating、issuer、country和其他缺失字段同样保持其真实availability状态。

新controls见[native coupon tests](../../tests/test_native_coupon_migration.py)和[PIK credit / overlay / unified API tests](../../tests/test_native_pik_credit.py)，覆盖default/currentcapitalization顺序、prepay、history、CPR、delayedcashcalendar、gross/cash/par守恒、forgedpublicreference与CLO/monitoring对账。

```mermaid
flowchart TD
    A[Complete frozen contractual or imported reference] --> B[Current performing exposure]
    B --> D[Midpoint default moves face to claim]
    D --> L[Unreceived default coupon excluded]
    B --> S[Surviving scheduled coupon and principal at receipt date]
    S --> K[Survivor-only explicit PIK capitalization]
    K --> P[End-date CPR on remaining survivor par including PIK]
    D --> R[Actual calendar-month recovery and separate loss]
    R --> Q[Cash received or pending claim beyond horizon]
    S --> C[Eligible cash accounts]
    P --> C
    Q --> C
    C --> W[Waterfall and explicitly gated synthetic purchase]
    W --> N[New par and future cohort receipts]
    N --> B
```

## 真实 snapshot 与未知 metadata

`application/portfolio_snapshots.py` 按原池 overlay movement、实际 imported par movement、synthetic purchase/movement 建立每个 loan/cohort 的 performing par。期末余额逐期对账 CLO summary；terminal sale 清除剩余持仓，保留过去 snapshot。

新 synthetic cohort 不继承旧池评级、issuer、industry、country或assetclass；相应集中度、WARF及子集指标因缺数据返回 INCOMPLETE/UNAVAILABLE。只有显式模板 spread/recovery scenario 有值，recovery provenance明确标为非机构回收率。

identified detailed source 只有与原 asset ID和opening par一致才沿用原 quality metadata。如果 active detailed source 未包含信用压力、没有 PIK、逐期 principal bridge 完整且 principal cash 合计等于 opening par，则直接使用 **外部 source 的 principal dates** 作为未受压的 analytical WAL reference；不使用模型内未激活的 loan schedule，也不构造虚假的 LoanTerms。缺少原 asset metadata 仍可计算这条已知 principal schedule 的 WAL，但评级、借款人等质量指标保持未知。后续 snapshot 把该 source 的剩余 principal 按实际 surviving par 比例分配，partial overlay 不改变 reference timing。

外部 long-dated diagnostic 使用最后一条仍有 beginning/ending performing par 的 source date；零 face 后的纯 interest receivable 不延长 principal boundary。此 boundary 是 active source 的本金时点依据，不自动证明法律合同 maturity。原 maturity metadata 缺失或与该 boundary 不一致时，weighted average contractual maturity 返回 UNAVAILABLE，并在 metric message 标明差异。

Simplified aggregate、含信用压力的 detailed source、PIK 或未完整偿还的 principal bridge 无法据此推断未受压 principal schedule，WAL、weighted maturity、LONG_DATED及其 limit 均 UNAVAILABLE；内部 structural horizon 只满足数据结构要求，不出现在报告的金融指标。普通 partialoverlay WAL 按 surviving contractual reference 比例分配 future principal，不把未来 CDR/CPR scenario 当成合同 WAL。

`LONG_DATED_FRACTION = performing face(maturity > explicit CLO legal final)/total performing face`。等于legalfinal不算long-dated；legalfinal缺失时不返回0。该generic concentration不含deal-specific rounding、grace periods或agency WAL定义。

### 独立已知答案与不变量

| 案例 | 预先确定的答案 / 守恒 | 实际验证与边界 |
| --- | --- | --- |
| Default basis / recovery | opening100，先scheduled偿还30，再default：defaulted exposure70；60% recovery=42，write-off28；先前已偿30不可再default | 单资产dated-event tests；每日期par/claim/cash/loss chain，不用旧VBA结果作期望 |
| Zero recovery | default20，RR=0，explicit write-off20；cash0、loss20、claim0 | write-off不使用cash/RR；无write-off时claim保持unresolved，不默认完成 |
| 分段回收 | 每次fraction×original actual default exposure，按累计target posting后作差；cash累计≤defaulted exposure | 例如0.01 par的50%/50%：累计targets0.01/0.01，单笔0.01/0.00，不能独立round成0.02 |
| Same-day ordering | scheduled actual cash先执行，退出只作用其后余额；default没有未付accrued coupon | same-day scheduled/default/prepay、adjusted cash gap及coupon边界独立验证；不外推其他agency策略 |
| 100-par完整CLO | assets100、debt60、equity实缴40；首个coupon前default100，actual recovery80、write-off20；偿debt60，equity20，MOIC0.5 | `python -m trident example-credit`已实际运行：COMPLETED、default claim0、actual interest0、equity IRR约−60.4156062%；原contract interest4.05只作reference |
| Legal final / cut-off | late recovery不能提前计入cash；future claim-resolution即使cash0也阻止提前completed/reserve release | root credit-CLO integration覆盖late cash、pending、future zero recovery/writeoff、EXCLUDE OC、note本金只随actual redemption变化 |
| Annual probability | annual20%、365天⇒20%；730天survival=0.8²=0.64、累计exit36%；coupon ACT/360不替代hazard ACT/365F | compiler手算rational root、independent float log-survival、monthly/quarterly crossing year/leap、0/1/t0、current par及near-cent tests |
| Fixed target vector | target40.95，39/22/16/13/10% cents=15.97/9.01/6.55/5.32/4.10；合计40.95 | exact Fraction+largest remainders；非法sum/date/capacity报错；capacity9/11遇target10/10实现19、shortfall1，不重分配 |
| Snapshot准入/对账 | identity、complete contract、ratings层级/nature、bid/ask、actual quote age/quality/settlement和provenance一致；trade ledger independently reconstructs holdings/cash | 验证quarantine原因与tampered proposal拒绝；不是Bloomberg live、法律eligibility或评级factor自动映射 |
| Closing target replay | preserved holdings采用原initial acquisition，新assets按admitted BUY；重新做Sources & Uses和equity实缴；SELL cash/static ending cash不得混入 | fullmodel检查post-event opening、付款日及独立有限事件observations的configured limits，并检查付款日GATE IC/OC、terminal/return availability及显式minimum IRR；negative/deteriorated IRR本身warning，不默认新增法律gate |

## 评级原始来源、版本与访问限制

所有在线来源于 2026-10-05 核查。发布日期取来源本身，不使用搜索引擎的相对日期或 crawl 日期。下面区分“目录核实”“搜索索引片段可读”和“全文取得”；没有据无法访问的文件声称已经核实全部表格。

| ID | 官方原始来源 | 版本/日期与访问状态 | 本次用途 |
| --- | --- | --- | --- |
| SP-CLO-REGISTER | [S&P In-Use Criteria：CDOs](https://www.spglobal.com/ratings/en/regulatory/ratings-criteria/-/articles/criteria/structured-finance/filter/cdos) | 目录可读；列明 corporate CLO criteria 原始日期 2019-06-21，PF criteria 2025-06-27 | 核实在用目录与文章身份；日期不是全文修订历史 |
| SP-CLO-CURRENT | [Global Methodology And Assumptions For CLOs And Corporate CDOs](https://www.spglobal.com/ratings/en/regulatory/article/-/view/type/HTML/id/3547721) | 从在用目录直接打开；正文当前仅返回页面占位内容 | 生产应用仍需取得适用全文、修订记录与相关变量版本 |
| SP-CLO-GUIDANCE | [Archived corporate CLO guidance](https://www.spglobal.com/ratings/en/research/articles/190621-guidance-criteria-structured-finance-cdos-global-methodology-and-assumptions-for-clos-and-corporate-cdos-11005168) | 原始 2019-06-21；2024-07-26 曾修订；编者注明 2024-10-25 内容移入 criteria、没有实质改动。官方搜索索引片段可读，直接页面正文不可完整读取 | 历史算法核对；不能称为最新在用 guidance |
| SP-PF-CURRENT | [CDOs Of Project Finance Debt: Global Methodology And Assumptions](https://www.spglobal.com/ratings/en/regulatory/article/-/view/type/HTML/id/3397512) | 在用目录标示 2025-06-27；直接正文不可完整读取 | 核实独立 PF 方法存在，不沿用 corporate BSL 参数 |
| SP-PF-FAQ | [How We Would Rate A Project Finance CLO](https://www.spglobal.com/ratings/en/regulatory/article/-/view/sourceId/101626294) | 官方索引可读；说明 2025-06-27 PF 方法变化。直接页面正文不可完整读取 | PF 分类、回收时间与 corporate 方法适用范围 |
| MD-CURRENT-REGISTER | [Moody’s methodologies and models](https://www.moodys.com/web/en/us/insights/methodologies-and-models.html) | 页面可读；列明 CLO methodology **2026-08-14**。该文章链接本次无法取得正文 | 不能将 2021/2024 corporate CLO 方法称作最新版 |
| MD-CLO-2024 | [Moody’s Global Approach to Rating CLOs, 2024-05-15](https://ratings.moodys.com/api/rmc-documents/420962) | 官方搜索索引 §2.3.3.1–5、Appendix 3 可读；PDF 直接访问 403；可见 OUTDATED METHODOLOGY 标记 | 历史 default timing、reinvestment 与 cashflow 假设 |
| MD-CLO-2021 | [Moody’s Global Approach to Rating CLOs, 2021-12-21](https://ratings.moodys.com/api/rmc-documents/74832) | 官方索引 §2.3.3.5 可读；属于过期方法 | 核对默认期 midpoint coupon 假设的历史出处 |
| MD-PF-2024 | [Project Finance and Infrastructure Asset CLOs, 2024-07-25](https://ratings.moodys.com/api/rmc-documents/425583) | 官方索引 Scope、§Asset-level analysis 与 phase modelling 可读；直接 PDF 403；本次未证实之后没有新修订 | PF outstanding par、amortization 与 mixed-pool 的方法边界 |
| VBA-CONVERSION | [Microsoft VBA type conversion functions](https://learn.microsoft.com/en-us/office/vba/language/concepts/getting-started/type-conversion-functions) | 官方语言文档 | `CLng` 的半数取偶数行为；用于旧 recovery lag 算法审查 |

Moody’s 的 [2026 RFC 说明活动](https://events.moodys.com/2026-miu26074-clo-rfc) 将 2026-06-05 的材料标为 proposed methodology update，讨论 default stresses 与 actual-portfolio 分析。RFC、最终方法和生产使用日期必须分别登记；不能据 RFC 宣称最终参数已生效。

本项目当前不能声称复刻了任何机构完整的 rating engine，也没有获得评级机构认可。公开方法给出分析框架与部分压力；实际 deal 的定义、适用评级输入、完整附件、工具版本和委员会判断仍需核实。

## 评级方法核对的有限结论

S&P 历史 guidance §31/Table 7 将五年向量定义为累计违约量的年度分配，违约期不收违约资产利息。§29 与 §72–79 表明再投资权限依 proceeds 来源、期限与文件而变，不能以单一 IC/OC 开关替代。四条五年向量为 39/22/16/13/10、16/23/26/22/13、12/18/22/23/25、20/20/20/20/20；它们不是 annual CDR。本文仅用于识别旧实现语义差异。 [S&P archived guidance](https://www.spglobal.com/ratings/en/research/articles/190621-guidance-criteria-structured-finance-cdos-global-methodology-and-assumptions-for-clos-and-corporate-cdos-11005168)

Moody’s 2024 §2.3.3.4–5/Appendix 3 的历史方法将 scenario defaults 分配到六年，含移动的一年 spike；recovery 与 interest-diversion 再投资另有违约处理，scheduled-amortization 再投资的违约影响已反映在该方法的 WAL 假设中。2021 §2.3.3.5 明确采用 default-period midpoint coupon。这不能证明 2026 最终版保留全部细节。 [Moody’s 2024 method](https://ratings.moodys.com/api/rmc-documents/420962), [Moody’s 2021 method](https://ratings.moodys.com/api/rmc-documents/74832)

因此，经济情景不能把历史 Moody’s 的 WAL 简化与逐笔新资产完整 lifetime hazard 同时施加；也不能混合 S&P 的 zero-default-period coupon 与 Moody’s midpoint coupon 后称为某一家机构方法。应分别保存 `scenario_kind`、source/version、default amount/timing、coupon loss、reinvestment default scope 与 recovery 参数。

## Hybrid Infra/PF 与 corporate BSL 必须分开

S&P PF FAQ明确：PF债务适用2025 PF方法，corporate loans适用corporate方法；PF recovery timing按country groups区分，披露一般24/42个月、部分情况18个月。它们是该方法的压力，不是所有Infra贷款真实workout预计时间。 [S&P PF FAQ](https://www.spglobal.com/ratings/en/regulatory/article/-/view/sourceId/101626294)

Moody’s 2024 PF方法使用asset outstanding principal与remaining WAL，考虑construction/operation以及资产类型；mixed PF/corporate pool的recovery与correlation需逐案分析。不能把所有“Infra”标签视作同一PF信用类别，也不能只混合两种pool的平均WARF证明hybrid评级。 [Moody’s PF method](https://ratings.moodys.com/api/rmc-documents/425583)

对 Project Trident €500m synthetic hybrid测试，建议区分contractual engine与credit assumptions：PF保留实际amortization，BSL保留facility条款；分别设base/default timing/recovery basis/lag；共用账户、交易、waterfall和headroom测试。cross-sector/country/obligor关联与rating stress规则未取得前，以 `SYNTHETIC_TEST_ONLY` 标识输出，不能将当前TEST_FACTOR改称机构WARF。

## 实现和验证边界

Native、imported及synthetic路径统一actual-cash原则；exactdaycount在正式CLO应用中明确传入，standalone无mapping的diagnostic fallback不能认证任意halfcent。非零imported stress需要完整future principal reference；stress改变zero-face receivable entitlement而缺具体应收数据时拒绝。Dispose只发生在当前projected boundary，不删除过去状态或提前执行future sale。

Opening defaults、borrower migration/issuer contagion、workout coupon/fees分类、未来真实trade-to-waterfall及全部purchase permissions仍需后续实现；独立真实commitment/settlement/receivables与settled snapshot开账衔接已有实现。评级source目录核验不代表取得最新全文或完成SDR/BDR/BET/CDOROM/hybrid correlation/calibration。真实dated流程规格见 [工作流](../calculation_flowcharts.md)，已完成金融regression见 [审查记录](../readiness.md)。
