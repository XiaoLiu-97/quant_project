"""Imported source bridges, no duplicate credit, and acquired coupon entitlement."""
from dataclasses import replace
from datetime import date
from decimal import Decimal
import unittest

from trident.adapters.imported_records import detailed_from_records, simplified_from_records, imported_projection_from_records
from trident.application.imported_cashflows import (
    CollateralCashflowInputMode as Mode, DetailedImportedCashflow as Detailed,
    SimplifiedImportedCashflow as Simple, compile_imported_cashflows,
    allocate_purchased_accrued, inherited_accrued_collections, inherited_accrued_for_overlay, SIMPLIFIED_POOL_ID,
)
from trident.credit.models import AssetCollection, AssetCashSource
from trident.domain.models import InputValidationError

D = Decimal
START = date(2027, 1, 1)
PAY = date(2027, 4, 1)


class ImportedCashflowTests(unittest.TestCase):
    def test_simple_three_column_fallback_reconciles_cash_and_par(self):
        p = compile_imported_cashflows(Mode.SIMPLIFIED, START, D(100), simplified_rows=(Simple(PAY, D(5), D(100)),))
        self.assertEqual(p.collections[0].total_cash, D(105))
        self.assertEqual(p.par_movements[0].performing_par_after, 0)
        self.assertEqual(p.par_movements[0].external_par_cash_difference, 0)

    def test_external_reduction_is_independent_from_principal_cash(self):
        p = compile_imported_cashflows(Mode.SIMPLIFIED, START, D(100), simplified_rows=(Simple(PAY, D(5), D(20), D(50), D(50), D(30), D(8)),))
        self.assertEqual(p.par_movements[0].performing_par_after, D(50))
        self.assertEqual(p.par_movements[0].external_par_cash_difference, D(30))
        self.assertEqual(p.collections[0].principal_collection, D(20))
        self.assertEqual(p.collections[0].total_cash, D(25))  # Memo recovery/default never added as cash.
        self.assertEqual(p.par_movements[0].defaulted_par_after, 0)  # No invented claim balance.

    def test_explicit_reduction_and_ending_balance_must_agree(self):
        with self.assertRaises(InputValidationError):
            compile_imported_cashflows(Mode.SIMPLIFIED, START, D(100), simplified_rows=(Simple(PAY, D(5), D(20), D(20), D(50)),))

    def test_negative_par_and_recovery_double_count_rejected(self):
        with self.assertRaises(InputValidationError):
            compile_imported_cashflows(Mode.SIMPLIFIED, START, D(100), simplified_rows=(Simple(PAY, D(5), D(101)),))
        with self.assertRaises(InputValidationError):
            Simple(PAY, D(5), D(20), recovery_proceeds_memo=D(21))

    def test_detailed_identified_period_bridge(self):
        rows = (Detailed("A", 1, PAY, D(100), D(5), D(50), D(50), D(55)),
                Detailed("A", 2, date(2027, 7, 1), D(50), D(2), D(50), D(0), D(52)))
        p = compile_imported_cashflows(Mode.DETAILED, START, D(100), rows)
        self.assertEqual(p.loan_opening_par, {"A": D(100)})
        self.assertEqual(p.final_principal_dates, {"A": date(2027, 7, 1)})
        self.assertEqual(sum(row.total_cash for row in p.collections), D(107))

    def test_detailed_external_pik_is_non_cash_par_increase(self):
        row = Detailed("A", 1, PAY, D(100), D(0), D(0), D(105), D(0), D(5))
        p = compile_imported_cashflows(Mode.DETAILED, START, D(100), (row,))
        self.assertEqual(p.collections[0].cash_interest, 0)
        self.assertEqual(p.par_movements[0].performing_par_after, D(105))
        self.assertEqual(p.par_movements[0].external_par_cash_difference, 0)

    def test_duplicate_period_and_discontinuous_asset_par_rejected(self):
        row = Detailed("A", 1, PAY, D(100), D(5), D(50), D(50), D(55))
        for other in (row, replace(row, period_number=2, payment_date=date(2027, 7, 1))):
            with self.assertRaises(InputValidationError):
                compile_imported_cashflows(Mode.DETAILED, START, D(100), (row, other))

    def test_mixed_consolidates_disjoint_sources_once(self):
        p = compile_imported_cashflows(Mode.MIXED, START, D(100),
             (Detailed("A", 1, PAY, D(40), D(2), D(40), D(0), D(42)),),
             (Simple(PAY, D(3), D(60), ending_performing_par=D(0)),), D(60))
        self.assertEqual(p.loan_opening_par, {"A": D(40), SIMPLIFIED_POOL_ID: D(60)})
        self.assertEqual(sum(row.total_cash for row in p.collections), D(105))
        self.assertEqual(len(p.collections), 2)

    def test_mixed_ending_par_requires_subpool_opening(self):
        with self.assertRaises(InputValidationError):
            compile_imported_cashflows(Mode.MIXED, START, D(100),
                (Detailed("A", 1, PAY, D(40), D(2), D(40), D(0), D(42)),),
                (Simple(PAY, D(3), D(60), ending_performing_par=D(0)),))

    def test_preclosing_excluded_and_future_beyond_legal_retained(self):
        future = date(2040, 1, 1)
        p = compile_imported_cashflows(Mode.SIMPLIFIED, START, D(100), simplified_rows=(Simple(date(2026, 1, 1), D(50), D(50)), Simple(future, D(5), D(100))))
        self.assertEqual(p.pre_closing_row_count, 1)
        self.assertEqual(p.collections[0].payment_date, future)
        self.assertEqual(p.opening_performing_par, D(100))

    def test_credit_flags_cannot_overlay_stressed_source(self):
        with self.assertRaises(InputValidationError):
            compile_imported_cashflows(Mode.SIMPLIFIED, START, D(100), simplified_rows=(Simple(PAY, D(5), D(100)),), credit_effects_included=True, overlay_enabled=True)

    def test_simplified_credit_flag_is_inactive_for_detailed_mode(self):
        controls = {"collateral_cashflow_input_mode": "Detailed", "closing_date": START,
                    "opening_collateral_par": D(100), "simplified_pool_opening_performing_par": D(0),
                    "simplified_cashflows_include_credit_prepayment_effects": "Yes", "credit_prepayment_overlay": "On"}
        row = dict(asset_id="A", period=1, payment_date=PAY, beginning_notional=100,
                   cash_interest=5, principal_repayment=100, ending_notional=0, total_cash_payment=105)
        result = imported_projection_from_records(controls, (row,))
        self.assertFalse(result.credit_effects_included)

    def test_unstressed_source_can_be_transported_to_independent_overlay(self):
        result = compile_imported_cashflows(Mode.SIMPLIFIED, START, D(100),
                    simplified_rows=(Simple(PAY, D(5), D(100)),), overlay_enabled=True)
        self.assertFalse(result.credit_effects_included)

    def test_source_modes_validate_presence_and_duplicate_dates(self):
        for kwargs in ({}, {"simplified_rows": (Simple(PAY, D(1), D(50)), Simple(PAY, D(1), D(50)))}):
            with self.assertRaises(InputValidationError):
                compile_imported_cashflows(Mode.SIMPLIFIED, START, D(100), **kwargs)

    def test_original_source_headers_and_currency(self):
        rows = simplified_from_records(({"Payment Date": PAY, "Interest Proceeds": "5", "Principal Proceeds": "100", "Currency (Optional)": "", "Source / Notes": "External model"},))
        self.assertEqual(rows[0].currency, "EUR")
        self.assertEqual(rows[0].provenance, "External model")
        with self.assertRaises(InputValidationError):
            simplified_from_records(({"payment_date": PAY, "interest_proceeds": 5, "principal_proceeds": 100, "currency": "USD"},))

    def test_detailed_gross_cash_pik_and_named_headers(self):
        record = dict(asset_id="A", period=1, payment_date=PAY, beginning_notional=100, cash_interest=2, pik_interest=3,
                      principal_repayment=10, ending_notional=93, total_cash_payment=12, gross_interest=5, currency="EUR")
        self.assertEqual(detailed_from_records((record,))[0].ending_par, D(93))
        with self.assertRaises(InputValidationError):
            detailed_from_records(({**record, "gross_interest": 6},))

    def test_acquired_accrued_allocation_exact_cents_deterministic(self):
        allocated = allocate_purchased_accrued({"B": D(1), "A": D(1), "C": D(1)}, D(".02"))
        self.assertEqual(allocated, {"A": D(".01"), "B": D(".01"), "C": D(0)})
        self.assertEqual(sum(allocated.values()), D(".02"))

    def test_acquired_claim_received_once_at_first_coupon(self):
        collections = (AssetCollection("A", "EUR", PAY, AssetCashSource.SCHEDULED, D(5), D(50), D(55), 1),
                       AssetCollection("A", "EUR", date(2027, 7, 1), AssetCashSource.SCHEDULED, D(3), D(50), D(53), 2))
        additional = inherited_accrued_collections({"A": D(2)}, collections)
        self.assertEqual(len(additional), 1)
        self.assertEqual((additional[0].payment_date, additional[0].total_cash, additional[0].principal_collection), (PAY, D(2), D(0)))

    def test_prepayment_earlier_and_default_forfeiture(self):
        prepay = AssetCollection("A", "EUR", PAY, AssetCashSource.PREPAYMENT, D(2), D(100), D(102))
        self.assertEqual(inherited_accrued_collections({"A": D(3)}, (prepay,))[0].payment_date, PAY)
        self.assertEqual(inherited_accrued_collections({"A": D(3)}, (), {"A": date(2027, 2, 1)}), ())
        with self.assertRaises(InputValidationError):
            inherited_accrued_collections({"A": D(3)}, ())

    def test_partial_default_and_earlier_partial_prepay_settle_accrued_slices(self):
        from trident.credit.overlay import OverlayCollection, OverlayParMovement
        default = OverlayParMovement("A", date(2027, 2, 1), AssetCashSource.DEFAULT, D(100), D(80), D(0), D(20), D(0), D(0))
        prepay = OverlayParMovement("A", date(2027, 3, 1), AssetCashSource.PREPAYMENT, D(80), D(64), D(20), D(20), D(16), D(0))
        cash = (OverlayCollection("A", "EUR", date(2027, 3, 1), AssetCashSource.PREPAYMENT, D(1), D(16), D(17)),
                OverlayCollection("A", "EUR", PAY, AssetCashSource.SCHEDULED, D(4), D(0), D(4), 1))
        added = inherited_accrued_for_overlay({"A": D(10)}, cash, (default, prepay))
        # 20% default forfeits2; early 20% partial prepay receives1.6, coupon receives6.4.
        self.assertEqual(tuple(row.cash_interest for row in added), (D("1.60"), D("6.40")))
        self.assertEqual(sum(row.cash_interest for row in added), D(8))

    def test_same_date_coupon_precedes_default_for_inherited_claim(self):
        from trident.credit.overlay import OverlayCollection, OverlayParMovement
        movement = OverlayParMovement("A", PAY, AssetCashSource.DEFAULT, D(100), D(0), D(0), D(100), D(0), D(0))
        cash = (OverlayCollection("A", "EUR", PAY, AssetCashSource.SCHEDULED, D(4), D(0), D(4), 1),)
        added = inherited_accrued_for_overlay({"A": D(2)}, cash, (movement,))
        self.assertEqual(added[0].cash_interest, D(2))

    def test_partial_acquired_claim_cumulative_cent_posting_cannot_overpay(self):
        from trident.credit.overlay import OverlayCollection, OverlayParMovement
        prepaid, moved = [], []
        for day, before in ((2, 3), (3, 2), (4, 1)):
            when = date(2027, 1, day)
            prepaid.append(OverlayCollection("A", "EUR", when, AssetCashSource.PREPAYMENT, D(0), D(1), D(1)))
            moved.append(OverlayParMovement("A", when, AssetCashSource.PREPAYMENT, D(before), D(before-1), D(0), D(0), D(1), D(0)))
        added = inherited_accrued_for_overlay({"A": D(".02")}, tuple(prepaid), tuple(moved))
        self.assertEqual(sum(row.cash_interest for row in added), D(".02"))

    def test_domain_types_and_mutation_guard(self):
        with self.assertRaises(InputValidationError):
            Simple(PAY, 5.0, D(100))
        p = compile_imported_cashflows(Mode.SIMPLIFIED, START, D(100), simplified_rows=(Simple(PAY, D(5), D(100)),))
        with self.assertRaises(TypeError):
            p.loan_opening_par["B"] = D(10)

    def test_public_imported_projection_rejects_cash_bridge_tampering(self):
        p = compile_imported_cashflows(Mode.SIMPLIFIED, START, D(100), simplified_rows=(Simple(PAY, D(5), D(100)),))
        forged = replace(p.collections[0], principal_collection=D(90), total_cash=D(95))
        with self.assertRaisesRegex(InputValidationError, "principal cash"):
            replace(p, collections=(forged,))
