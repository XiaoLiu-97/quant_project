"""Operational face, restricted cash, unsettled trades and explicit claims.

Recognition uses settlement dates for actual cash/face and separately reports
trade-date exposure. It is not a legal covenant numerator. LMA publications do
not justify universal settlement lags or automatic delayed compensation:
https://www.lma.eu.com/news-publications/press-releases?id=214
https://www.lma.eu.com/policy-regulation/alerts-archive?show=older
An original CLO uses trade dates for tests and separately classifies principal-
financed accrued interest; actual deal permissions must therefore be explicit:
https://www.sec.gov/Archives/edgar/data/1373561/000119312512507388/d455464dex41.htm
No historic fixing, accrued entitlement, assignment consent or valuation is
reconstructed from opening par. All cash inputs are currency units, not rates.
"""

from dataclasses import dataclass
from datetime import date
from decimal import Decimal
from enum import Enum
from fractions import Fraction

from trident.domain.models import InputValidationError, require_date, require_decimal, require_money
from trident.domain.numeric import post_currency

ZERO = Decimal("0.00")


def _text(value: object, label: str) -> None:
    if not isinstance(value, str) or not value or value != value.strip():
        raise InputValidationError(f"{label} must be nonempty unpadded text")


def _currency(value: object) -> None:
    if not isinstance(value, str) or value not in {"EUR", "USD", "GBP"}:
        raise InputValidationError("Ledger currency must be EUR, USD or GBP")


def _signed_money(value: object, label: str) -> Decimal:
    amount = require_decimal(value, label)
    if post_currency(Fraction(amount)) != amount:
        raise InputValidationError(f"{label} must have at most two decimal places")
    return amount


class CashAccount(str, Enum):
    PRINCIPAL = "PRINCIPAL"
    INTEREST = "INTEREST"


class TradeSide(str, Enum):
    BUY = "BUY"
    SELL = "SELL"


class HoldingStatus(str, Enum):
    """Default changes performing classification, not legal face or cash."""
    PERFORMING = "PERFORMING"
    DEFAULTED = "DEFAULTED"


class LedgerEventKind(str, Enum):
    CASH_COLLECTION = "CASH_COLLECTION"
    CASH_PAYMENT = "CASH_PAYMENT"
    RECEIVABLE_COLLECTION = "RECEIVABLE_COLLECTION"
    DEFAULT = "DEFAULT"
    WRITE_OFF = "WRITE_OFF"
    TRADE_CANCEL = "TRADE_CANCEL"


@dataclass(frozen=True)
class CashBalances:
    """Actual/reserved restricted cash, separate from face and receivables."""
    principal: Decimal = ZERO
    interest: Decimal = ZERO

    def __post_init__(self) -> None:
        require_money(self.principal, "principal cash")
        require_money(self.interest, "interest cash")


@dataclass(frozen=True)
class LedgerPermissions:
    """Explicit exceptions; clean loan consideration always uses principal.

    Nonzero accrued/fees routed through principal require their own authority.
    This does not infer subsequent coupon/reimbursement classification.
    """
    allow_principal_for_accrued: bool = False
    allow_principal_for_fees: bool = False

    def __post_init__(self) -> None:
        for name in ("allow_principal_for_accrued", "allow_principal_for_fees"):
            if type(getattr(self, name)) is not bool:
                raise InputValidationError(f"{name} must be bool")


@dataclass(frozen=True)
class OpeningHolding:
    """Settled legal face; zero face can preserve a retired receivable's identity."""
    asset_id: str
    currency: str
    settled_par: Decimal
    status: HoldingStatus = HoldingStatus.PERFORMING

    def __post_init__(self) -> None:
        _text(self.asset_id, "asset_id")
        _currency(self.currency)
        require_money(self.settled_par, "settled_par")
        if not isinstance(self.status, HoldingStatus):
            raise InputValidationError("holding status must be HoldingStatus")


@dataclass(frozen=True)
class TradeCommitment:
    """Frozen full-fill trade; dates and economic entitlement supplied explicitly.

    Clean price is per 100 par. Accrued/fees are total currency amounts; signed
    accrued can represent an independently verified settlement adjustment.
    Each component posts once. Lots are multiples, not minimum-plus-increment.
    Price, source consent and timing are not inferred from market conventions.
    """
    trade_id: str
    asset_id: str
    side: TradeSide
    trade_date: date
    settlement_date: date
    par: Decimal
    clean_price_pct: Decimal
    accrued_cash: Decimal = ZERO
    fees_cash: Decimal = ZERO
    accrued_account: CashAccount = CashAccount.INTEREST
    fee_account: CashAccount = CashAccount.INTEREST
    lot_size: Decimal | None = None
    minimum_ticket: Decimal = ZERO
    maximum_par: Decimal | None = None
    currency: str = "EUR"
    allow_defaulted_asset: bool = False

    def __post_init__(self) -> None:
        for name in ("trade_id", "asset_id"):
            _text(getattr(self, name), name)
        _currency(self.currency)
        if not isinstance(self.side, TradeSide):
            raise InputValidationError("trade side must be TradeSide")
        for name in ("trade_date", "settlement_date"):
            require_date(getattr(self, name), name)
        if self.settlement_date < self.trade_date:
            raise InputValidationError("settlement_date cannot precede trade_date")
        require_money(self.par, "trade par", positive=True)
        require_decimal(self.clean_price_pct, "clean_price_pct", minimum=Decimal(0))
        _signed_money(self.accrued_cash, "accrued_cash")
        require_money(self.fees_cash, "fees_cash")
        for name in ("accrued_account", "fee_account"):
            if not isinstance(getattr(self, name), CashAccount):
                raise InputValidationError(f"{name} must be CashAccount")
        require_money(self.minimum_ticket, "minimum_ticket")
        if self.par < self.minimum_ticket:
            raise InputValidationError("Trade par is below minimum_ticket")
        if self.maximum_par is not None:
            require_money(self.maximum_par, "maximum_par")
            if self.par > self.maximum_par:
                raise InputValidationError("Trade par exceeds frozen availability maximum_par")
        if self.lot_size is not None:
            require_money(self.lot_size, "lot_size", positive=True)
            if Fraction(self.par) % Fraction(self.lot_size):
                raise InputValidationError("Trade par must be a multiple of lot_size")
        if type(self.allow_defaulted_asset) is not bool:
            raise InputValidationError("allow_defaulted_asset must be bool")

    @property
    def clean_cash(self) -> Decimal:
        """Exact par * price/100 followed by one HALF_UP cent posting."""
        return post_currency(Fraction(self.par) * Fraction(self.clean_price_pct) / 100)


@dataclass(frozen=True)
class CashReceivable:
    """Opening claim; due_date alone never pays/defaults/writes off the claim.

    Amounts are remaining explicitly classified claims. Principal-financed
    accrued reimbursement can be principal; asset coupon is not assumed to be
    interest universally. New future recognition/amendment is not implemented.
    """
    receivable_id: str
    asset_id: str
    recognition_date: date
    due_date: date
    principal_cash: Decimal
    interest_cash: Decimal
    source: str

    def __post_init__(self) -> None:
        for name in ("receivable_id", "asset_id", "source"):
            _text(getattr(self, name), name)
        require_date(self.recognition_date, "receivable recognition_date")
        require_date(self.due_date, "receivable due_date")
        if self.due_date < self.recognition_date:
            raise InputValidationError("Receivable due_date cannot precede recognition_date")
        require_money(self.principal_cash, "receivable principal_cash")
        require_money(self.interest_cash, "receivable interest_cash")
        if self.principal_cash == self.interest_cash == 0:
            raise InputValidationError("CashReceivable requires a positive claim")


@dataclass(frozen=True)
class LedgerEvent:
    """Actual collection/payment, default, noncash write-off or cancellation.

    Collections can reduce loan face explicitly; recovery on already written-
    off face uses zero reduction. CASH_PAYMENT is a supplied account debit,
    e.g. an actual debt/fee payment, with no automatic waterfall calculation.
    Receivable collection consumes each claim
    component, preventing double payment. DEFAULT posts no cash or par change.
    """
    event_id: str
    event_date: date
    kind: LedgerEventKind
    source: str
    asset_id: str | None = None
    principal_cash: Decimal = ZERO
    interest_cash: Decimal = ZERO
    par_reduction: Decimal = ZERO
    trade_id: str | None = None
    receivable_id: str | None = None

    def __post_init__(self) -> None:
        _text(self.event_id, "event_id")
        _text(self.source, "event source")
        require_date(self.event_date, "event_date")
        if not isinstance(self.kind, LedgerEventKind):
            raise InputValidationError("event kind must be LedgerEventKind")
        for name in ("asset_id", "trade_id", "receivable_id"):
            if getattr(self, name) is not None:
                _text(getattr(self, name), name)
        for name in ("principal_cash", "interest_cash", "par_reduction"):
            require_money(getattr(self, name), name)
        if self.kind is LedgerEventKind.CASH_PAYMENT:
            if self.trade_id is not None or self.receivable_id is not None or self.par_reduction or not (self.principal_cash or self.interest_cash):
                raise InputValidationError("CASH_PAYMENT requires positive cash debit, zero par reduction and no trade/receivable payload")
        elif self.kind is LedgerEventKind.TRADE_CANCEL:
            if self.trade_id is None or self.asset_id is not None or self.receivable_id is not None or any((self.principal_cash, self.interest_cash, self.par_reduction)):
                raise InputValidationError("TRADE_CANCEL requires only trade_id and no cash/par/receivable payload")
        elif self.kind in {LedgerEventKind.DEFAULT, LedgerEventKind.WRITE_OFF}:
            if self.asset_id is None or self.trade_id is not None or self.receivable_id is not None or self.principal_cash or self.interest_cash:
                raise InputValidationError("DEFAULT/WRITE_OFF requires asset_id and no cash/trade/receivable payload")
            if self.kind is LedgerEventKind.DEFAULT and self.par_reduction:
                raise InputValidationError("DEFAULT changes classification, not loan face")
            if self.kind is LedgerEventKind.WRITE_OFF and not self.par_reduction:
                raise InputValidationError("WRITE_OFF requires positive par_reduction")
        else:
            if self.asset_id is None or self.trade_id is not None or not (self.principal_cash or self.interest_cash):
                raise InputValidationError("Collection requires asset_id and positive actual cash, without trade_id")
            if self.par_reduction and not self.principal_cash:
                raise InputValidationError("A cash collection's par reduction requires principal cash; noncash reduction is WRITE_OFF")
            if (self.kind is LedgerEventKind.RECEIVABLE_COLLECTION) != (self.receivable_id is not None):
                raise InputValidationError("receivable_id is required only for RECEIVABLE_COLLECTION")


@dataclass(frozen=True)
class HoldingsLedgerRequest:
    """Beginning-of-day state, historical unsettled commitments and new events.

    Historical commitments reconstruct reservations only, never historical cash.
    New trade dates may equal opening; events before opening are unsupported.
    """
    as_of_date: date
    horizon_date: date
    currency: str
    opening_cash: CashBalances
    opening_holdings: tuple[OpeningHolding, ...]
    trades: tuple[TradeCommitment, ...] = ()
    events: tuple[LedgerEvent, ...] = ()
    opening_commitments: tuple[TradeCommitment, ...] = ()
    opening_receivables: tuple[CashReceivable, ...] = ()
    permissions: LedgerPermissions = LedgerPermissions()
    source: str = "USER_SUPPLIED_FROZEN_LEDGER"

    def __post_init__(self) -> None:
        require_date(self.as_of_date, "as_of_date")
        require_date(self.horizon_date, "horizon_date")
        if self.horizon_date < self.as_of_date:
            raise InputValidationError("Ledger horizon cannot precede opening as_of_date")
        _currency(self.currency)
        _text(self.source, "ledger source")
        if not isinstance(self.opening_cash, CashBalances) or not isinstance(self.permissions, LedgerPermissions):
            raise InputValidationError("Opening cash/permissions must be typed ledger objects")
        for name, cls in (("opening_holdings", OpeningHolding), ("trades", TradeCommitment), ("events", LedgerEvent),
                          ("opening_commitments", TradeCommitment), ("opening_receivables", CashReceivable)):
            items = getattr(self, name)
            if type(items) is not tuple or any(not isinstance(item, cls) for item in items):
                raise InputValidationError(f"{name} must be an immutable tuple of {cls.__name__}")
        holdings = {item.asset_id: item for item in self.opening_holdings}
        if len(holdings) != len(self.opening_holdings):
            raise InputValidationError("Opening holding asset_id must be unique")
        all_trades = self.opening_commitments + self.trades
        for values, key, label in ((all_trades, "trade_id", "Trade IDs"), (self.events, "event_id", "Event IDs"),
                                   (self.opening_receivables, "receivable_id", "Receivable IDs")):
            if len({getattr(item, key) for item in values}) != len(values):
                raise InputValidationError(f"{label} must be unique")
        if any(item.currency != self.currency for item in (*self.opening_holdings, *all_trades)):
            raise InputValidationError("Mixed currencies require explicit FX and are unsupported")
        if any(not item.trade_date <= self.as_of_date < item.settlement_date for item in self.opening_commitments):
            raise InputValidationError("Opening commitment requires trade_date <= as_of_date < settlement_date")
        if any(item.trade_date < self.as_of_date for item in self.trades):
            raise InputValidationError("Pre-opening trades belong in opening_commitments")
        if any(not self.as_of_date <= item.event_date <= self.horizon_date for item in self.events):
            raise InputValidationError("Ledger events must fall within projection horizon")
        if any(item.recognition_date > self.as_of_date or item.asset_id not in holdings for item in self.opening_receivables):
            raise InputValidationError("Opening receivable needs an opening asset identity and recognised claim")


@dataclass(frozen=True)
class PendingTrade:
    """Cash obligation/claim and sale-face encumbrance; claims are unavailable cash."""
    trade: TradeCommitment
    reserved_cash: CashBalances
    settlement_receivable: CashBalances


@dataclass(frozen=True)
class LedgerJournalEntry:
    """Signed actual postings; commit/default/cancel entries post zero cash/par."""
    event_date: date
    entry_id: str
    kind: str
    asset_id: str | None
    trade_id: str | None
    principal_cash_change: Decimal = ZERO
    interest_cash_change: Decimal = ZERO
    par_change: Decimal = ZERO
    clean_cash: Decimal = ZERO
    accrued_cash: Decimal = ZERO
    fee_cash: Decimal = ZERO


@dataclass(frozen=True)
class HoldingsLedgerSnapshot:
    """Post-event settled state and separate trade-date diagnostics/encumbrance."""
    as_of_date: date
    currency: str
    holdings: tuple[OpeningHolding, ...]
    cash: CashBalances
    reserved_cash: CashBalances
    available_cash: CashBalances
    pending_trades: tuple[PendingTrade, ...]
    receivables: tuple[CashReceivable, ...]

    @property
    def settled_par(self) -> Decimal:
        return post_currency(sum((Fraction(item.settled_par) for item in self.holdings), Fraction()))

    @property
    def performing_par(self) -> Decimal:
        return post_currency(sum((Fraction(item.settled_par) for item in self.holdings if item.status is HoldingStatus.PERFORMING), Fraction()))

    @property
    def defaulted_par(self) -> Decimal:
        return post_currency(sum((Fraction(item.settled_par) for item in self.holdings if item.status is HoldingStatus.DEFAULTED), Fraction()))

    def _committed_par(self, side: TradeSide) -> Decimal:
        return post_currency(sum((Fraction(item.trade.par) for item in self.pending_trades if item.trade.side is side), Fraction()))

    @property
    def committed_buy_par(self) -> Decimal:
        return self._committed_par(TradeSide.BUY)

    @property
    def committed_sell_par(self) -> Decimal:
        return self._committed_par(TradeSide.SELL)

    @property
    def trade_date_par(self) -> Decimal:
        """Held+pending buy-pending sell; no automatic legal numerator/valuation."""
        return post_currency(Fraction(self.settled_par) + Fraction(self.committed_buy_par) - Fraction(self.committed_sell_par))

    def available_to_sell(self, asset_id: str) -> Decimal:
        """Settled face minus committed sells; pending buys add no capacity."""
        held = next((Fraction(item.settled_par) for item in self.holdings if item.asset_id == asset_id), Fraction())
        reserved = sum((Fraction(item.trade.par) for item in self.pending_trades if item.trade.asset_id == asset_id and item.trade.side is TradeSide.SELL), Fraction())
        return post_currency(held - reserved)


@dataclass(frozen=True)
class HoldingsLedgerResult:
    """Opening snapshot precedes opening-day events; all outputs are immutable."""
    opening_snapshot: HoldingsLedgerSnapshot
    snapshots: tuple[HoldingsLedgerSnapshot, ...]
    journal: tuple[LedgerJournalEntry, ...]
    source: str

    @property
    def final_snapshot(self) -> HoldingsLedgerSnapshot:
        return self.snapshots[-1]
