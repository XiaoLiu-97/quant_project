"""Closing-pool replay integration with independent funding/return oracles."""

from dataclasses import replace
from datetime import date, datetime, timedelta, timezone
from decimal import Decimal, Inexact, localcontext
import unittest

from trident.analysis import AssetExposure, FactorMapping, LimitDirection, LimitSpec, ReturnStatus
from trident.application.clo_services import TridentModelRequest
from trident.application.construction import (
    ClosingPoolRedesignRequest, ClosingPoolRedesignService, ConstructionStatus,
    FindingSeverity, selected_factor_provenance,
)
from trident.application.services import CashflowRunRequest
from trident.clo.models import CloTerms, NoteTranche
from trident.credit.models import PrepaymentEvent
from trident.domain.models import AmortizationType, CouponType, InputValidationError, LoanPosition, LoanTerms, PrincipalScheduleEntry
from trident.funding.engine import AssetPurchase, DebtIssue, FundingEngine
from trident.funding import ClosingCostBudget, ClosingCostItem
from trident.market import FlatRateProvider
from trident.optimization import (
    AssetDescriptor, AssetKind, Holding, OptimizationObjective, OptimizationRequest,
    PortfolioLimits, TradeQuote, TradeSide,
)
from trident.optimization.universe import (
    CandidateAdmissionPolicy, CandidateAssetSnapshot, CandidateCreditStatus,
    CandidateUniverseSnapshot, PriceObservation, PriceSide, QuoteQuality,
    RatingLevel, RatingNature, RatingObservation,
)

D = Decimal
CLOSE = date(2026, 1, 20)
FIRST = date(2026, 4, 20)
SECOND = date(2026, 7, 20)
CAPTURE = datetime(2026, 1, 19, 16, 0, tzinfo=timezone.utc)
MAPPING = FactorMapping("TRIDENT_TEST_FACTOR", "1", {"OLD_BUCKET": D(4000), "NEW_BUCKET": D(2000)}, is_synthetic=True)
PROVENANCE = selected_factor_provenance(MAPPING)


def position(name, *, spread=D(500), maturity=FIRST):
    return LoanPosition(LoanTerms(name, "EUR", CLOSE, maturity, D(10000), CouponType.FLOATING,
                                  rate_index="EURIBOR_3M", spread_bps=spread), CLOSE, D(10000))


def exposure(loan, bucket):
    return AssetExposure(loan.terms.loan_id, f"ISSUER_{loan.terms.loan_id}", "BSL", "TERM_LOAN", "GB",
                         f"SECTOR_{loan.terms.loan_id}", "EUR", loan.opening_balance, loan.terms.spread_bps,
                         loan.terms.maturity_date, is_senior=True, is_secured=True, is_pik=False,
                         is_revolver=False, is_construction=False, test_factor_bucket=bucket)


def descriptor(asset, factor):
    return AssetDescriptor(asset.loan_id, AssetKind.BSL, asset.obligor, asset.country, asset.sector,
                           asset.spread_bps, factor)


def candidate(loan, quality, asset, quote):
    facility = f"FACILITY_{asset.asset_id}"
    rating = RatingObservation("SYNTHETIC_TEST_AGENCY", "TEST_RATING", RatingLevel.FACILITY,
                               RatingNature.INTERNAL, facility, CAPTURE.date(), "EXPLICIT_TEST_RATING")
    price = PriceObservation(quote, PriceSide.ASK if quote.side is TradeSide.BUY else PriceSide.BID,
                             QuoteQuality.FIRM, CAPTURE, CLOSE, "HAND_INPUT_TEST_QUOTE")
    return CandidateAssetSnapshot(asset, facility, f"SYNTHETIC_BBG_{asset.asset_id}", loan, quality,
                                  (rating,), (price,), "VERIFIED_TEST_CONTRACT", "VERIFIED_TEST_CLASSIFICATION",
                                  CandidateCreditStatus.PERFORMING)


def fixture(*, new_spread=D(800), new_maturity=FIRST, old_maturity=FIRST, fees=False,
            accrued=None, buy_price=D(101),
            maximum_par=D(10000), limits=(), reinvestment_end=None, minimum_irr=None):
    old, new = position("OLD", maturity=old_maturity), position("NEW", spread=new_spread, maturity=new_maturity)
    old_exposure, new_exposure = exposure(old, "OLD_BUCKET"), exposure(new, "NEW_BUCKET")
    old_descriptor, new_descriptor = descriptor(old_exposure, D(4000)), descriptor(new_exposure, D(2000))
    sell = TradeQuote(old_descriptor, TradeSide.SELL, D(99), maximum_par,
                      fixed_fee=D(3) if fees else D(0))
    buy = TradeQuote(new_descriptor, TradeSide.BUY, buy_price, maximum_par,
                     accrued_per_par=D(".01") if (fees if accrued is None else accrued) else D(0),
                     proportional_fee_per_par=D(".001") if fees else D(0),
                     fixed_fee=D(5) if fees else D(0))
    note = NoteTranche("A", 1, D(8000), CouponType.FIXED, fixed_rate=D(".02"))
    baseline = TridentModelRequest(CashflowRunRequest((old,), (AssetPurchase("OLD", D(10000), D(100)),),
        (DebtIssue("A", D(8000), D(100)),), FlatRateProvider({"EURIBOR_3M": D(0)}), D(7), D(0), "FLAT_SYNTHETIC"),
        (old_exposure,), MAPPING, limits, CloTerms(CLOSE, max(old_maturity, new_maturity)), (note,), reinvestment_end)
    mandate = OptimizationRequest((Holding(old_descriptor, D(10000)),), (sell, buy), D(1000),
                                   PortfolioLimits(D(10000)), OptimizationObjective.MIN_FACTOR, PROVENANCE, CLOSE)
    universe = CandidateUniverseSnapshot("SNAPSHOT", CAPTURE, "SYNTHETIC_FROZEN_VALUES", PROVENANCE,
        (candidate(old, old_exposure, old_descriptor, sell), candidate(new, new_exposure, new_descriptor, buy)))
    policy = CandidateAdmissionPolicy(CLOSE, timedelta(0), (QuoteQuality.FIRM,))
    return ClosingPoolRedesignRequest(baseline, mandate, universe, policy, minimum_equity_irr=minimum_irr)


def replace_candidate(request, asset_id, **changes):
    universe = request.candidate_snapshot
    return replace(request, candidate_snapshot=replace(universe, candidates=tuple(
        replace(row, **changes) if row.asset_id == asset_id else row for row in universe.candidates)))


class ClosingPoolRedesignTests(unittest.TestCase):
    def test_itemized_closing_costs_include_only_actual_buy_acquisition_fees(self):
        request = fixture(fees=True, accrued=False)
        cash = replace(request.baseline.cashflow_request, upfront_fees=D(0),
            closing_cost_budget=ClosingCostBudget(D(10000), D("0.0003"), (ClosingCostItem("LEGAL", D(4)),)))
        request = replace(request, baseline=replace(request.baseline, cashflow_request=cash))
        result = ClosingPoolRedesignService().run(request)
        self.assertTrue(result.validated, result.findings)
        self.assertEqual(result.baseline_result.cashflows.funding.upfront_fees, D(7))
        target = result.target_result.cashflows.funding
        # Arrangement3+legal4+BUYfee15=22; SELLfee3 belongs only to trade cash.
        self.assertEqual(target.arrangement_fee, D(3))
        self.assertEqual(target.other_upfront_costs, D(19))
        self.assertEqual(target.upfront_fees, D(22))
        self.assertEqual(target.equity_cash_funding, D(2122))
        self.assertEqual(result.target_request.cashflow_request.upfront_fees, D(0))
        self.assertEqual(result.plan.ending_cash, D(782))
        self.assertEqual(tuple(item.cost_id for item in cash.closing_cost_budget.fixed_costs), ("LEGAL",))

    def test_reserved_buy_fee_component_cannot_conflict_with_user_budget(self):
        request = fixture(fees=True, accrued=False)
        cash = replace(request.baseline.cashflow_request, upfront_fees=D(0),
            closing_cost_budget=ClosingCostBudget(D(10000), D(0),
                (ClosingCostItem("TRIDENT_POOL_ACQUISITION_FEES", D(7)),)))
        result = ClosingPoolRedesignService().run(replace(request, baseline=replace(request.baseline, cashflow_request=cash)))
        self.assertEqual(result.status, ConstructionStatus.REPLAY_FAILED)
        self.assertIsNone(result.target_result)
        self.assertTrue(any("reserved" in finding.message for finding in result.findings))

    def test_full_replacement_replays_new_contract_and_exact_funding(self):
        request = fixture()
        result = ClosingPoolRedesignService().run(request)
        self.assertTrue(result.validated, result.findings)
        self.assertEqual(result.status, ConstructionStatus.REPLAY_VALIDATED)
        self.assertEqual(result.mode, "CLOSING_POOL_REDESIGN")
        self.assertEqual(result.execution_status, "NOT_EXECUTED")
        self.assertEqual(tuple(p.terms.loan_id for p in result.target_request.cashflow_request.positions), ("NEW",))
        self.assertEqual(result.target_request.cashflow_request.positions[0].terms.spread_bps, D(800))
        # Baseline uses 10000+7-8000=2007. Independent redesign uses
        # 10000*101/100+7-8000=2107; static 800 ending cash is not credited.
        self.assertEqual(result.baseline_result.cashflows.funding.equity_cash_funding, D(2007))
        self.assertEqual(result.target_result.cashflows.funding.asset_clean_cost, D(10100))
        self.assertEqual(result.target_result.cashflows.funding.equity_cash_funding, D(2107))
        self.assertEqual(result.plan.ending_cash, D(800))
        self.assertEqual(result.target_result.cashflows.total_interest, D(200))
        self.assertEqual(result.target_result.clo.total_equity_distributions, D(2160))
        # One cash inflow 90 days later: IRR=(2160/2107)^(365/90)-1.
        expected = (2160 / 2107) ** (365 / 90) - 1
        self.assertLess(abs(float(result.target_result.equity_irr.value) - expected), 1e-12)
        self.assertIs(result.equity_irr_improved, False)
        self.assertTrue(any(row.code == "EQUITY_IRR_DETERIORATED" for row in result.findings))

    def test_nonzero_accrued_preserves_static_cash_and_cost_request_but_blocks_full_replay(self):
        result = ClosingPoolRedesignService().run(fixture(fees=True))
        self.assertTrue(result.optimization.validated)
        self.assertFalse(result.validated)
        self.assertEqual(result.status, ConstructionStatus.REPLAY_FAILED)
        self.assertIsNone(result.target_result)
        self.assertTrue(any(row.code == "TARGET_PROJECTION_FAILED" and "accrued" in row.message.lower()
                            for row in result.findings))
        cash = result.target_request.cashflow_request
        target = FundingEngine().calculate(cash.purchases, cash.issues,
                                            upfront_fees=cash.upfront_fees, cash_reserve=cash.cash_reserve)
        # Buy clean10100 +accrued100 +buyfee(10+5) +baselinefee7 -debt8000=2222.
        # These sources/uses are correct; missing pre-closing coupon entitlement
        # makes a complete CLO investor return unavailable, rather than zero.
        self.assertEqual(target.asset_clean_cost, D(10100))
        self.assertEqual(target.acquired_accrued_interest, D(100))
        self.assertEqual(target.upfront_fees, D(22))
        self.assertEqual(target.equity_cash_funding, D(2222))
        # Static sellfee3 also affects the proposal cash ledger: 1000+9900-3-10100-100-15=682.
        self.assertEqual(result.plan.ending_cash, D(682))

    def test_negative_return_is_performance_warning_using_valid_zero_accrued_closing(self):
        result = ClosingPoolRedesignService().run(fixture(fees=True, accrued=False, buy_price=D(103)))
        # Clean10300+upfront(7+10+5)-8000=2322; no SELL fee3 in redesigned uses.
        self.assertEqual(result.target_result.cashflows.funding.equity_cash_funding, D(2322))
        self.assertTrue(result.validated)
        self.assertLess(result.target_result.equity_irr.value, 0)
        self.assertTrue(any(row.code == "NEGATIVE_EQUITY_IRR" and row.severity is FindingSeverity.WARNING for row in result.findings))

    def test_explicit_minimum_return_policy_rejects_otherwise_feasible_replay(self):
        result = ClosingPoolRedesignService().run(fixture(fees=True, accrued=False, buy_price=D(103), minimum_irr=D(0)))
        self.assertTrue(result.optimization.validated)
        self.assertEqual(result.status, ConstructionStatus.REPLAY_REJECTED)
        self.assertFalse(result.validated)
        self.assertTrue(any(row.code == "MINIMUM_EQUITY_IRR_BREACH" for row in result.findings))

    def test_no_trade_benchmark_preserves_original_purchase_price_and_financial_outputs(self):
        request = fixture()
        request = replace(request, optimization_request=replace(request.optimization_request, quotes=()))
        result = ClosingPoolRedesignService().run(request)
        self.assertTrue(result.validated, result.findings)
        self.assertEqual(result.plan.trades, ())
        self.assertEqual(result.baseline_result.cashflows.funding, result.target_result.cashflows.funding)
        self.assertEqual(result.baseline_result.clo, result.target_result.clo)
        self.assertEqual(result.baseline_result.equity_irr, result.target_result.equity_irr)
        self.assertIs(result.equity_irr_improved, False)

    def test_partial_swap_keeps_original_retained_cost_and_scales_new_bespoke_cents(self):
        request = fixture(new_maturity=SECOND, maximum_par=D(5000))
        new = next(row for row in request.candidate_snapshot.candidates if row.asset_id == "NEW")
        terms = replace(new.position.terms, amortization_type=AmortizationType.BESPOKE,
            principal_schedule=(PrincipalScheduleEntry(FIRST, D("3333.33")), PrincipalScheduleEntry(SECOND, D("6666.67"))))
        request = replace_candidate(request, "NEW", position=replace(new.position, terms=terms))
        result = ClosingPoolRedesignService().run(request)
        self.assertTrue(result.validated, result.findings)
        held = {row.terms.loan_id: row for row in result.target_request.cashflow_request.positions}
        self.assertEqual(held["OLD"].opening_balance, D(5000))
        self.assertEqual(held["NEW"].opening_balance, D(5000))
        self.assertEqual(tuple(row.amount for row in held["NEW"].terms.principal_schedule), (D("1666.67"), D("3333.33")))
        costs = {row.loan_id: row for row in result.target_request.cashflow_request.purchases}
        self.assertEqual(costs["OLD"].clean_price_pct, D(100))
        self.assertEqual(costs["NEW"].clean_price_pct, D(101))
        self.assertEqual(result.target_result.cashflows.total_principal, D(10000))
        self.assertTrue(any(row.baseline_status == "NOT_PRESENT" for row in result.period_comparisons))

    def test_retained_absolute_amortization_amount_is_resized(self):
        request = fixture(old_maturity=SECOND, new_maturity=SECOND, maximum_par=D(5000))
        old = request.baseline.cashflow_request.positions[0]
        terms = replace(old.terms, amortization_type=AmortizationType.LINEAR_AMOUNT,
                        scheduled_principal_amount=D(5000), balloon_amount=D(0))
        resized_old = replace(old, terms=terms)
        request = replace(request, baseline=replace(request.baseline,
            cashflow_request=replace(request.baseline.cashflow_request, positions=(resized_old,))))
        request = replace_candidate(request, "OLD", position=resized_old)
        result = ClosingPoolRedesignService().run(request)
        self.assertTrue(result.validated, result.findings)
        retained = next(row for row in result.target_request.cashflow_request.positions if row.terms.loan_id == "OLD")
        self.assertEqual(retained.terms.reference_principal, D(5000))
        self.assertEqual(retained.terms.scheduled_principal_amount, D(2500))
        self.assertEqual(retained.terms.balloon_amount, D(0))

    def test_configured_future_ic_gate_failure_prevents_validation_even_when_debt_repaid(self):
        request = fixture(new_spread=D(200), new_maturity=SECOND)
        request = replace(request, baseline=replace(request.baseline,
            notes=(replace(request.baseline.notes[0], ic_minimum=D(2)),)))
        result = ClosingPoolRedesignService().run(request)
        self.assertTrue(result.optimization.validated)
        self.assertEqual(result.target_result.clo.final_debt_par, D(0))
        self.assertFalse(result.validated)
        self.assertTrue(any(row.code == "IC_GATE_FAIL" and row.payment_date == FIRST for row in result.findings))

    def test_future_phase_limit_breach_and_unavailable_are_not_passes(self):
        for metric, threshold, direction, expected in (
            ("WAS_BPS", D(900), LimitDirection.MINIMUM, "PORTFOLIO_LIMIT_BREACH"),
            ("WAL_YEARS", D(".1"), LimitDirection.MAXIMUM, "PORTFOLIO_LIMIT_BREACH"),
            ("WARR", D(".4"), LimitDirection.MINIMUM, "PORTFOLIO_LIMIT_UNAVAILABLE"),
        ):
            with self.subTest(metric=metric):
                limit = LimitSpec("FUTURE", metric, threshold, direction, ("REINVESTMENT",))
                request = fixture(old_maturity=SECOND, new_maturity=SECOND, limits=(limit,),
                                  reinvestment_end=date(2026, 5, 20))
                result = ClosingPoolRedesignService().run(request)
                self.assertTrue(result.optimization.validated)
                self.assertFalse(result.validated)
                self.assertTrue(any(row.code == expected and row.source == "TARGET" and row.payment_date == FIRST for row in result.findings))

    def test_unresolved_legal_final_does_not_publish_terminal_return_as_validated(self):
        request = fixture(new_maturity=SECOND)
        request = replace(request, baseline=replace(request.baseline,
            clo_terms=replace(request.baseline.clo_terms, legal_final_date=FIRST)))
        result = ClosingPoolRedesignService().run(request)
        self.assertTrue(result.optimization.validated)
        self.assertFalse(result.validated)
        self.assertEqual(result.target_result.equity_irr.status, ReturnStatus.UNAVAILABLE)
        self.assertTrue(any(row.code == "CLO_NOT_COMPLETE" and row.source == "TARGET" for row in result.findings))

    def test_unsupported_overfunding_projection_error_and_zero_equity_unavailable_return_preserve_static_evidence(self):
        for price, expected_status, finding in (
            (D(70), ConstructionStatus.REPLAY_FAILED, "TARGET_PROJECTION_FAILED"),
            (D("79.93"), ConstructionStatus.REPLAY_REJECTED, "EQUITY_IRR_UNAVAILABLE"),
        ):
            with self.subTest(price=price):
                request = fixture()
                quotes = tuple(replace(q, clean_price_pct=price) if q.side is TradeSide.BUY else q
                               for q in request.optimization_request.quotes)
                request = replace(request, optimization_request=replace(request.optimization_request, quotes=quotes))
                new = next(row for row in request.candidate_snapshot.candidates if row.asset_id == "NEW")
                request = replace_candidate(request, "NEW", prices=(replace(new.prices[0], quote=quotes[1]),))
                result = ClosingPoolRedesignService().run(request)
                self.assertTrue(result.optimization.validated)
                self.assertFalse(result.validated)
                self.assertEqual(result.status, expected_status)
                self.assertIsNotNone(result.plan)
                self.assertTrue(any(row.code == finding for row in result.findings))

    def test_infeasible_static_budget_has_no_target_or_fake_replay(self):
        request = fixture()
        request = replace(request, optimization_request=replace(request.optimization_request,
            starting_cash=D(0), limits=PortfolioLimits(D(12000))))
        result = ClosingPoolRedesignService().run(request)
        self.assertEqual(result.status, ConstructionStatus.STATIC_REJECTED)
        self.assertFalse(result.validated)
        self.assertIsNone(result.plan)
        self.assertIsNone(result.target_result)
        self.assertEqual(result.comparisons, ())

    def test_low_decimal_context_and_immutable_baseline(self):
        request = fixture(fees=True, accrued=False)
        expected = ClosingPoolRedesignService().run(request)
        with localcontext() as context:
            context.prec = 2
            context.traps[Inexact] = True
            actual = ClosingPoolRedesignService().run(request)
        self.assertEqual(actual.target_request, expected.target_request)
        self.assertEqual(actual.target_result.clo, expected.target_result.clo)
        self.assertEqual(actual.comparisons, expected.comparisons)
        self.assertEqual(request.baseline.cashflow_request.positions[0].opening_balance, D(10000))
        self.assertEqual(request.baseline.cashflow_request.upfront_fees, D(7))

    def test_invalid_closing_date_holdings_identity_or_full_contract_rejected(self):
        request = fixture()
        invalid = (
            replace(request, admission_policy=replace(request.admission_policy, settlement_date=date(2026, 1, 21))),
            replace(request, optimization_request=replace(request.optimization_request, settlement_date=date(2026, 1, 21))),
            replace(request, optimization_request=replace(request.optimization_request,
                holdings=(replace(request.optimization_request.holdings[0], par=D(10001)),))),
            replace(request, baseline=replace(request.baseline, clo_terms=None)),
            replace(request, baseline=replace(request.baseline, cashflow_request=replace(
                request.baseline.cashflow_request, purchases=(replace(
                    request.baseline.cashflow_request.purchases[0], accrued_interest=D(1)),)))),
        )
        for changed in invalid:
            with self.subTest(changed=changed), self.assertRaises(InputValidationError):
                ClosingPoolRedesignService().run(changed)

    def test_selected_factor_values_and_versions_not_provenance_strings_are_verified(self):
        request = fixture()
        old_hold = request.optimization_request.holdings[0]
        bad_asset = replace(old_hold.asset, factor=D(3999))
        changed = replace(request, optimization_request=replace(request.optimization_request,
            holdings=(Holding(bad_asset, old_hold.par),), quotes=()))
        with self.assertRaisesRegex(InputValidationError, "selected factor"):
            ClosingPoolRedesignService().run(changed)
        for changed in (
            replace(request, optimization_request=replace(request.optimization_request, factor_provenance="SAME_WORDS_NOT_METHOD")),
            replace(request, candidate_snapshot=replace(request.candidate_snapshot, factor_provenance="OTHER")),
            replace(request, baseline=replace(request.baseline, factor_mapping=None)),
        ):
            with self.subTest(changed=changed), self.assertRaises(InputValidationError):
                ClosingPoolRedesignService().run(changed)
        new = next(row for row in request.candidate_snapshot.candidates if row.asset_id == "NEW")
        changed = replace_candidate(request, "NEW", exposure=replace(new.exposure, test_factor_bucket="UNKNOWN"))
        with self.assertRaisesRegex(InputValidationError, "no factor"):
            ClosingPoolRedesignService().run(changed)

    def test_user_selected_agency_mapping_checks_direct_factors_and_method_versions(self):
        request = fixture()
        mapping = FactorMapping("USER_SELECTED_AGENCY_METHOD", "VERIFIED_INPUT_VERSION",
                                dict(MAPPING.factors), is_synthetic=False)
        provenance = selected_factor_provenance(mapping)
        def agency_exposure(asset):
            return replace(asset, test_factor_bucket=None, rating_bucket=asset.test_factor_bucket,
                           rating_factor=mapping.factors[asset.test_factor_bucket],
                           rating_system=mapping.system, rating_version=mapping.version)
        request = replace(request, baseline=replace(request.baseline, factor_mapping=mapping,
            exposures=tuple(agency_exposure(row) for row in request.baseline.exposures)),
            optimization_request=replace(request.optimization_request, factor_provenance=provenance),
            candidate_snapshot=replace(request.candidate_snapshot, factor_provenance=provenance,
                candidates=tuple(replace(row, exposure=agency_exposure(row.exposure)) for row in request.candidate_snapshot.candidates)))
        result = ClosingPoolRedesignService().run(request)
        self.assertTrue(result.validated, result.findings)
        self.assertEqual(result.target_result.opening_portfolio.metric("WARF").value, D(2000))
        new = next(row for row in request.candidate_snapshot.candidates if row.asset_id == "NEW")
        for changes, message in (({"rating_factor": D(1999)}, "conflicts"),
                                 ({"rating_version": "DIFFERENT_METHOD_VERSION"}, "system/version")):
            changed = replace_candidate(request, "NEW", exposure=replace(new.exposure, **changes))
            with self.subTest(changes=changes), self.assertRaisesRegex(InputValidationError, message):
                ClosingPoolRedesignService().run(changed)

    def test_quarantined_missing_or_price_changed_candidate_cannot_enter_optimizer(self):
        request = fixture()
        new = next(row for row in request.candidate_snapshot.candidates if row.asset_id == "NEW")
        edits = (
            replace_candidate(request, "NEW", credit_status=CandidateCreditStatus.UNKNOWN),
            replace_candidate(request, "NEW", position=None),
            replace(request, candidate_snapshot=replace(request.candidate_snapshot,
                candidates=tuple(row for row in request.candidate_snapshot.candidates if row.asset_id != "NEW"))),
            replace_candidate(request, "NEW", prices=(replace(new.prices[0], quote=replace(new.prices[0].quote, clean_price_pct=D(102))),)),
        )
        for changed in edits:
            with self.subTest(changed=changed), self.assertRaises(InputValidationError):
                ClosingPoolRedesignService().run(changed)

    def test_sell_snapshot_cannot_replace_held_contract_or_quality_with_different_valid_data(self):
        request = fixture()
        old = next(row for row in request.candidate_snapshot.candidates if row.asset_id == "OLD")
        changed = replace_candidate(request, "OLD", exposure=replace(old.exposure, is_secured=False))
        with self.assertRaisesRegex(InputValidationError, "SELL snapshot"):
            ClosingPoolRedesignService().run(changed)

    def test_credit_events_unsupported_and_explicit_minimum_validation(self):
        request = fixture()
        changed = replace(request, baseline=replace(request.baseline, credit_events=(PrepaymentEvent("OLD", FIRST),)))
        with self.assertRaisesRegex(InputValidationError, "credit events"):
            ClosingPoolRedesignService().run(changed)
        for value in (-0.1, D("NaN"), D(-1)):
            with self.subTest(value=value), self.assertRaises(InputValidationError):
                replace(request, minimum_equity_irr=value)

    def test_held_quality_flags_cannot_bypass_candidate_support_boundary(self):
        request = fixture()
        request = replace(request, optimization_request=replace(request.optimization_request, quotes=()))
        for changes in ({"is_secured": None}, {"is_pik": True}, {"is_revolver": True}, {"is_construction": True}):
            changed = replace(request, baseline=replace(request.baseline,
                exposures=(replace(request.baseline.exposures[0], **changes),)))
            with self.subTest(changes=changes), self.assertRaises(InputValidationError):
                ClosingPoolRedesignService().run(changed)


if __name__ == "__main__":
    unittest.main()
