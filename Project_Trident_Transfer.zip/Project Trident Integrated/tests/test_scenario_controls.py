"""New assumption controls, itemized funding and immutable what-if behavior."""

from dataclasses import replace
from datetime import date
from decimal import Decimal, Inexact, localcontext
import unittest

from trident.adapters.model_records import model_request_from_records
from trident.adapters.scenario_records import scenarios_from_records
from trident.application.clo_services import TridentModelService
from trident.application.scenarios import ScenarioDefinition, ScenarioEdit, ScenarioExecutionError, ScenarioRunner, ScenarioTarget
from trident.clo import InterestDiversionMode, ManagementFeeBasis, PrincipalRepaymentMode
from trident.conventions import DayCount, StubConvention
from trident.domain.models import InputValidationError
from trident.funding import ClosingCostBudget, ClosingCostItem, ClosingSourceType
from trident.market import FlatRateProvider
from test_contract_records import _asset, _capital, _controls
from test_scenarios import comparison, edit, request

D = Decimal


def itemized_baseline():
    baseline = request()
    budget = ClosingCostBudget(D(10000000), D(".0075"), (ClosingCostItem("LEGAL", D(25000)),))
    cash = replace(baseline.cashflow_request, upfront_fees=D(0), closing_cost_budget=budget,
        other_initial_uses=D(500), other_initial_sources=D(300),
        other_initial_source_type=ClosingSourceType.EXTERNAL_CONTRIBUTION)
    return replace(baseline, cashflow_request=cash)


class ScenarioControlTests(unittest.TestCase):
    def test_itemized_arrangement_edits_reprice_actual_funding_and_keep_original_budget(self):
        baseline = itemized_baseline()
        scenarios = (
            ScenarioDefinition("RATE", (edit("CONTROL", "arrangement_fee_rate", D(".01")),)),
            ScenarioDefinition("BASE", (edit("CONTROL", "arrangement_fee_base", D(12000000)),)),
            ScenarioDefinition("BOTH", (edit("CONTROL", "arrangement_fee_rate", D(".01")),
                                        edit("CONTROL", "arrangement_fee_base", D(12000000)))),
        )
        result = ScenarioRunner().run(baseline, scenarios)
        # Baseline10m*.0075 +25kfixed =100k; initialotheruses500-source300
        # adds200 cash equity. Original10m+100k+50kreserve-8m+200=2150200.
        self.assertEqual(result.baseline.cashflows.funding.equity_cash_funding, D(2150200))
        for scenario, fee_delta in zip(result.scenarios, (D(25000), D(15000), D(45000)), strict=True):
            with self.subTest(scenario=scenario.scenario_id):
                self.assertEqual(comparison(scenario, "ARRANGEMENT_FEE").delta, fee_delta)
                self.assertEqual(comparison(scenario, "UPFRONT_FEES").delta, fee_delta)
                self.assertEqual(comparison(scenario, "EQUITY_CASH_FUNDING").delta, fee_delta)
                self.assertEqual(scenario.result.clo, result.baseline.clo)
                self.assertEqual(scenario.request.cashflow_request.closing_cost_budget.fixed_costs,
                                 baseline.cashflow_request.closing_cost_budget.fixed_costs)
                self.assertLess(scenario.result.equity_irr.value, result.baseline.equity_irr.value)
        self.assertEqual(baseline.cashflow_request.closing_cost_budget.arrangement_fee_rate, D(".0075"))
        self.assertEqual(baseline.cashflow_request.closing_cost_budget.arrangement_fee_base, D(10000000))

    def test_other_cash_uses_and_classified_contributions_change_funding_not_distributions(self):
        baseline = itemized_baseline()
        batch = ScenarioRunner().run(baseline, (
            ScenarioDefinition("USES", (edit("CONTROL", "other_initial_uses", D(1500)),)),
            ScenarioDefinition("SOURCES", (edit("CONTROL", "other_initial_sources", D(1300)),)),
        ))
        for scenario, delta in zip(batch.scenarios, (D(1000), D(-1000)), strict=True):
            self.assertEqual(comparison(scenario, "EQUITY_CASH_FUNDING").delta, delta)
            self.assertEqual(scenario.result.clo, batch.baseline.clo)
            self.assertEqual(scenario.result.cashflows.total_interest, batch.baseline.cashflows.total_interest)
        self.assertLess(batch.scenarios[0].result.equity_irr.value, batch.baseline.equity_irr.value)
        self.assertGreater(batch.scenarios[1].result.equity_irr.value, batch.baseline.equity_irr.value)

    def test_cost_modes_and_unclassified_cash_sources_cannot_silently_double_count(self):
        for baseline, field, value, message in (
            (itemized_baseline(), "upfront_fees", D(1), "AGGREGATE"),
            (request(), "arrangement_fee_rate", D(".01"), "ITEMIZED"),
            (request(), "other_initial_sources", D(1), "classification"),
        ):
            with self.subTest(field=field), self.assertRaisesRegex(ScenarioExecutionError, message):
                ScenarioRunner().run(baseline, (ScenarioDefinition("INVALID", (edit("CONTROL", field, value),)),))

    def test_boolean_and_enum_transport_reaches_typed_terms_without_mutating_baseline(self):
        baseline = request()
        cases = {
            "coverage_tests_enabled": "false", "interest_diversion_enabled": False,
            "include_principal_cash_in_oc": "False", "principal_repayment_mode": "PRO_RATA",
            "interest_diversion_mode": "CURE_OC_AND_CONTINUE", "management_fee_basis": "INITIAL_COLLATERAL_PAR",
            "management_fee_day_count": "ACT/365F", "senior_expenses_day_count": "ACT/360",
            "annual_senior_expense_cap": "10000", "variable_senior_expenses_bps": "1",
        }
        rows = tuple(dict(scenario_id="CONTROLS", target="CONTROL", identifier="DEAL", field=field,
                          value=value, enabled=True) for field, value in cases.items())
        scenarios = scenarios_from_records(rows)
        result = ScenarioRunner().run(baseline, scenarios).scenarios[0]
        terms = result.request.clo_terms
        self.assertIs(terms.coverage_tests_enabled, False)
        self.assertIs(terms.interest_diversion_enabled, False)
        self.assertIs(terms.include_principal_cash_in_oc, False)
        self.assertIs(terms.principal_repayment_mode, PrincipalRepaymentMode.PRO_RATA)
        self.assertIs(terms.interest_diversion_mode, InterestDiversionMode.CURE_OC_AND_CONTINUE)
        self.assertIs(terms.management_fee_basis, ManagementFeeBasis.INITIAL_COLLATERAL_PAR)
        self.assertIs(terms.management_fee_day_count, DayCount.ACT_365F)
        self.assertIs(terms.senior_expenses_day_count, DayCount.ACT_360)
        self.assertTrue(baseline.clo_terms.coverage_tests_enabled)
        self.assertIs(baseline.clo_terms.principal_repayment_mode, PrincipalRepaymentMode.SEQUENTIAL)

    def test_bad_boolean_enum_blank_required_or_nonfinite_input_is_rejected(self):
        for field, value in (("coverage_tests_enabled", 1), ("include_principal_cash_in_oc", "yes"),
                             ("other_initial_uses", True), ("management_fee_basis", "INVALID"),
                             ("principal_repayment_mode", ""), ("arrangement_fee_rate", "NaN")):
            row = dict(scenario_id="INVALID", target="CONTROL", identifier="DEAL", field=field, value=value, enabled=True)
            with self.subTest(field=field), self.assertRaises(ValueError):
                scenarios = scenarios_from_records((row,))
                ScenarioRunner().run(itemized_baseline(), scenarios)
        with self.assertRaises(InputValidationError):
            ScenarioEdit(ScenarioTarget.CONTROL, "DEAL", "coverage_tests_enabled", 1)

    def test_optional_expense_cap_can_be_cleared_and_low_context_preserves_results(self):
        baseline = itemized_baseline()
        baseline = replace(baseline, clo_terms=replace(baseline.clo_terms, annual_senior_expense_cap=D(5000)))
        scenarios = scenarios_from_records((dict(scenario_id="CLEAR", target="CONTROL", identifier="DEAL",
                                                 field="annual_senior_expense_cap", value="", enabled="true"),))
        expected = ScenarioRunner().run(baseline, scenarios)
        with localcontext() as context:
            context.prec = 2
            context.traps[Inexact] = True
            actual = ScenarioRunner().run(baseline, scenarios)
        self.assertIsNone(actual.scenarios[0].request.clo_terms.annual_senior_expense_cap)
        self.assertEqual(actual.scenarios[0].result.clo, expected.scenarios[0].result.clo)
        self.assertEqual(actual.scenarios[0].comparisons, expected.scenarios[0].comparisons)

    def test_model_records_itemized_costs_sources_and_new_flags_follow_cash_oracle(self):
        controls = _controls()
        controls.update(closing_costs_mode="ITEMIZED", arrangement_fee_base="1000", arrangement_fee_rate=".0075",
            upfront_fees="0", other_initial_uses="10", other_initial_sources="5",
            other_initial_source_type="EXTERNAL_CONTRIBUTION", recurring_expenses_mode="ITEMIZED",
            coverage_tests_enabled="false", interest_diversion_enabled=False, include_principal_cash_in_oc=False,
            principal_repayment_mode="PRO_RATA", management_fee_basis="INITIAL_COLLATERAL_PAR")
        model = model_request_from_records((_asset(),), _capital(), FlatRateProvider({}), controls=controls,
            provenance="HAND_RECORDS", factors=(), limits=(),
            closing_cost_records=(dict(cost_id="LEGAL", amount="2.50"),),
            recurring_expense_records=(dict(expense_id="TRUSTEE", annual_amount="1.00"),))
        result = TridentModelService().run(model)
        #1000asset+7.50arrangement+2.50legal+10otheruses-800debt-5source=215.
        self.assertEqual(result.cashflows.funding.equity_cash_funding, D(215))
        self.assertEqual(result.cashflows.funding.arrangement_fee, D("7.50"))
        self.assertEqual(result.cashflows.funding.other_upfront_costs, D("2.50"))
        self.assertIs(model.clo_terms.coverage_tests_enabled, False)
        self.assertIs(model.clo_terms.principal_repayment_mode, PrincipalRepaymentMode.PRO_RATA)
        self.assertEqual(model.clo_terms.recurring_senior_expenses[0].annual_amount, D(1))

    def test_model_records_automatic_initial_stub_uses_legal_final_anchor(self):
        controls = _controls()
        controls.update(legal_final_date="2025-08-31", clo_stub_convention="SHORT_FIRST",
                        reinvestment_end_date="2025-05-31")
        asset = _asset(cashflow_projection_start_date="2025-02-28", par_as_of_date="2025-02-28",
            maturity_date_unadjusted="2025-08-31", schedule_anchor_day=28, stub_convention="SHORT_LAST",
            amortization_type="BULLET", amortization_first_date_unadjusted="", amortization_periods_remaining="",
            scheduled_principal_amount="")
        capital = tuple(dict(row, schedule_anchor_day=31) for row in _capital())
        model = model_request_from_records((asset,), capital, FlatRateProvider({}), controls=controls,
                                          provenance="STUB_RECORDS", factors=(), limits=())
        self.assertIs(model.clo_terms.stub_convention, StubConvention.SHORT_FIRST)
        result = TridentModelService().run(model)
        # May31 Saturday: modified following crosses into June, so cash rolls
        # to FridayMay30; the regular NOMINAL anchor remains day31.
        self.assertEqual(result.clo.periods[0].payment_date, date(2025, 5, 30))
        wrong_capital = tuple(dict(row, schedule_anchor_day=28) for row in capital)
        with self.assertRaisesRegex(InputValidationError, "schedule_anchor_day"):
            model_request_from_records((asset,), wrong_capital, FlatRateProvider({}), controls=controls,
                                       provenance="STUB_RECORDS", factors=(), limits=())


if __name__ == "__main__":
    unittest.main()
