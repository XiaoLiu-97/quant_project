"""Typed terms and immutable audit records for the deterministic CLO waterfall.

These are the executable H00 synthetic waterfall definitions, not a claim that
all CLO indentures use the same priorities or coverage definitions. Rates are
decimal fractions, management fees are basis points, and cash is EUR cents.
"""

from dataclasses import dataclass
from datetime import date
from decimal import Decimal
from enum import Enum
from fractions import Fraction
from typing import TYPE_CHECKING
from collections.abc import Mapping
from types import MappingProxyType

from trident.conventions import AccrualDateBasis, BusinessDayConvention, DayCount, StubConvention
from trident.domain.models import CouponType, InputValidationError, LoanCashflow, require_date, require_decimal, require_money
from trident.credit.models import AssetCreditProjection, DefaultEvent, AssetCollection
from trident.credit.overlay import OriginalPoolOverlay, PoolOverlayProjection, OverlayParMovement
from .reinvestment import SyntheticReinvestmentPolicy, ReinvestmentPurchase
from .lifecycle import AdjustedCollateralValuePolicy, OcAssetData, ShortfallAccrualMethod
from .proceeds import (
    CouponProceedsAllocation, CouponProceedsAudit, PrincipalAccruedBalance,
    validate_coupon_proceeds_inputs,
)
from trident.conventions.calendar import CalendarName
from trident.conventions.liability_rates import FixingDateAnchor, FirstStubRateMethod

if TYPE_CHECKING:
    from trident.application.imported_cashflows import ImportedCollateralProjection


class DefaultedAssetOcTreatment(str, Enum):
    """Explicit stress valuation; no agency or indenture haircut is inferred."""

    EXCLUDE = "EXCLUDE"
    ADJUSTED_POLICY = "ADJUSTED_POLICY"


class PrincipalRepaymentMode(str, Enum):
    """Normal cash principal allocation; coverage cures remain sequential."""

    SEQUENTIAL = "SEQUENTIAL"
    PRO_RATA = "PRO_RATA"


class PrincipalCouponPolicy(str, Enum):
    """Permission to use principal for coupons, separate from debt redemption.

    Cash-pay senior coupons remain payable. A deferrable class can use principal
    only once it controls the remaining debt; ALL_CLASSES is an explicit legacy
    sensitivity and does not establish a transaction's controlling-class terms.
    """

    NON_DEFERRABLE_AND_CONTROLLING = "NON_DEFERRABLE_AND_CONTROLLING"
    ALL_CLASSES = "ALL_CLASSES"


class InterestDiversionMode(str, Enum):
    """An explicitly chosen coverage cure policy, not a universal indenture."""

    ALL_RESIDUAL = "ALL_RESIDUAL"
    CURE_OC_AND_CONTINUE = "CURE_OC_AND_CONTINUE"


class ManagementFeeBasis(str, Enum):
    """Par basis for recurring management fees and variable senior expenses."""

    TIME_WEIGHTED_PERFORMING_PAR = "TIME_WEIGHTED_PERFORMING_PAR"
    OPENING_PERFORMING_PAR = "OPENING_PERFORMING_PAR"
    CLOSING_PERFORMING_PAR = "CLOSING_PERFORMING_PAR"
    INITIAL_COLLATERAL_PAR = "INITIAL_COLLATERAL_PAR"


class CashAccountAccrualMode(str, Enum):
    """Explicit collection-account remuneration, excluding restricted reserve.

    PROJECTED_TERM_SIMPLE is a constant term reset per account accrual period.
    It is neither compounded overnight RFR nor an OIS zero-curve proxy.
    """

    NONE = "NONE"
    FIXED_SIMPLE = "FIXED_SIMPLE"
    PROJECTED_TERM_SIMPLE = "PROJECTED_TERM_SIMPLE"
    DF_FORWARD_SIMPLE = "DF_FORWARD_SIMPLE"


@dataclass(frozen=True)
class RecurringSeniorExpense:
    """One named annual fixed expense estimate, in EUR per calendar year."""

    expense_id: str
    annual_amount: Decimal

    def __post_init__(self) -> None:
        if (not isinstance(self.expense_id, str) or not self.expense_id
                or self.expense_id != self.expense_id.strip()):
            raise InputValidationError("expense_id must be a nonblank unpadded string")
        require_money(self.annual_amount, "recurring annual_amount")


class CoverageStatus(str, Enum):
    """Zero denominators are explicitly distinct from a passing active test."""

    PASS = "PASS"
    FAIL = "FAIL"
    NOT_APPLICABLE = "NOT_APPLICABLE"
    NOT_CONFIGURED = "NOT_CONFIGURED"


class ProjectionStatus(str, Enum):
    """Economic completion state, not a legal event-of-default determination."""
    COMPLETED = "COMPLETED"
    CASH_PAY_FAILURE = "CASH_PAY_FAILURE"
    LEGAL_FINAL_UNRESOLVED = "LEGAL_FINAL_UNRESOLVED"
    FINAL_FEES_UNSETTLED = "FINAL_FEES_UNSETTLED"


@dataclass(frozen=True)
class NoteTranche:
    """One note class; lower payment_priority means more senior.

    The common deal schedule supplies reset/payment dates. Coupon uses the
    opening period par; end-of-period redemptions do not reduce that coupon.
    None for a coverage threshold means that test was explicitly not configured.
    ``pik_rate_fraction`` elects a mandatory portion of the current contractual
    coupon to settle by adding face on the distribution date. It is distinct
    from optional deferral of an otherwise cash-pay coupon. Capitalized face
    earns the next period's coupon and must ultimately be redeemed in cash.
    Arrears compounding/waiver remain explicit, separate deal policies.
    """

    class_id: str
    payment_priority: int
    opening_balance: Decimal
    coupon_type: CouponType
    rate_index: str | None = None
    spread_bps: Decimal = Decimal(0)
    fixed_rate: Decimal | None = None
    index_floor: Decimal | None = None
    day_count: DayCount = DayCount.ACT_360
    oc_minimum: Decimal | None = None
    ic_minimum: Decimal | None = None
    interest_deferrable: bool = False
    pik_rate_fraction: Decimal = Decimal(0)

    def __post_init__(self) -> None:
        if not isinstance(self.class_id, str) or not self.class_id or self.class_id != self.class_id.strip():
            raise InputValidationError("class_id must be a nonblank, unpadded string")
        if type(self.payment_priority) is not int or self.payment_priority < 1:
            raise InputValidationError("payment_priority must be a positive integer")
        # The note type also represents an existing, fully redeemed class with
        # a surviving coupon claim. A new closing must still issue positive
        # face; CloRunRequest enforces that contextual restriction.
        require_money(self.opening_balance, "note opening_balance")
        if not isinstance(self.coupon_type, CouponType) or not isinstance(self.day_count, DayCount):
            raise InputValidationError("Note coupon_type/day_count must be their typed enums")
        require_decimal(self.spread_bps, "note spread_bps")
        if self.index_floor is not None:
            require_decimal(self.index_floor, "note index_floor")
        if self.coupon_type is CouponType.FIXED:
            require_decimal(self.fixed_rate, "note fixed_rate", minimum=Decimal(0))
            if self.rate_index is not None or self.index_floor is not None or self.spread_bps != 0:
                raise InputValidationError("Fixed notes use fixed_rate only")
        elif self.rate_index not in {"EURIBOR_1M", "EURIBOR_3M", "EURIBOR_6M"} or self.fixed_rate is not None:
            raise InputValidationError("Floating notes support EURIBOR_1M/3M/6M and no fixed_rate")
        for name in ("oc_minimum", "ic_minimum"):
            value = getattr(self, name)
            if value is not None:
                require_decimal(value, name, minimum=Decimal(0))
                if value == 0:
                    raise InputValidationError(f"{name} must be positive or explicitly None")
        if type(self.interest_deferrable) is not bool:
            raise InputValidationError("interest_deferrable must be boolean")
        require_decimal(self.pik_rate_fraction, "note pik_rate_fraction", minimum=Decimal(0))
        if self.pik_rate_fraction > 1:
            raise InputValidationError("note pik_rate_fraction must be <= 1")


@dataclass(frozen=True)
class CloTerms:
    """Explicit H00 execution policy, dates, fee terms and restricted reserve.

    NO_TRADES does not assume replacement assets are available. Configured
    synthetic cohorts use explicit cash permissions; independent IDT cash can
    remain earmarked without a purchase. Neither path executes real trades.
    A nonzero collection cutoff holds actual post-cutoff collections in separate
    pending cash accounts until the following distribution; it does not retain
    principal in performing collateral after the principal has been repaid.

    Grouped fields below separate contractual dates/fees, account permissions,
    lifecycle assumptions and coverage definitions. Defaults define a synthetic
    generic profile; selecting them does not verify a real transaction's terms.
    """

    closing_date: date
    legal_final_date: date
    # Distribution and senior-priority fee policy.
    frequency_months: int = 3
    senior_management_fee_bps: Decimal = Decimal(0)
    subordinated_management_fee_bps: Decimal = Decimal(0)
    annual_senior_expenses: Decimal = Decimal(0)
    initial_reserve: Decimal = Decimal(0)
    business_day_convention: BusinessDayConvention = BusinessDayConvention.MODIFIED_FOLLOWING
    accrual_date_basis: AccrualDateBasis = AccrualDateBasis.ADJUSTED
    fixing_lag_business_days: int = 2
    end_of_month: bool = False
    stub_convention: StubConvention = StubConvention.SHORT_LAST
    collection_cutoff_business_days: int = 0
    reinvestment_strategy: str = "NO_TRADES"
    defaulted_asset_oc_treatment: DefaultedAssetOcTreatment | None = None
    coverage_tests_enabled: bool = True
    interest_diversion_enabled: bool = True
    principal_repayment_mode: PrincipalRepaymentMode = PrincipalRepaymentMode.SEQUENTIAL
    interest_diversion_mode: InterestDiversionMode = InterestDiversionMode.ALL_RESIDUAL
    management_fee_basis: ManagementFeeBasis = ManagementFeeBasis.TIME_WEIGHTED_PERFORMING_PAR
    management_fee_day_count: DayCount = DayCount.ACT_360
    recurring_senior_expenses: tuple[RecurringSeniorExpense, ...] = ()
    variable_senior_expenses_bps: Decimal = Decimal(0)
    senior_expenses_day_count: DayCount = DayCount.ACT_365F
    annual_senior_expense_cap: Decimal | None = None
    senior_expense_cap_bps: Decimal = Decimal(0)
    include_principal_cash_in_oc: bool = True
    first_payment_date_unadjusted: date | None = None
    last_regular_date_unadjusted: date | None = None
    first_stub_rate_override: Decimal | None = None
    # Bank account remuneration applies to held physical collections, never
    # loan coupon accrual or restricted reserve without an explicit permission.
    cash_account_accrual_mode: CashAccountAccrualMode = CashAccountAccrualMode.NONE
    cash_account_fixed_rate: Decimal | None = None
    cash_account_rate_index: str | None = None
    cash_account_spread_bps: Decimal = Decimal(0)
    cash_account_rate_floor: Decimal | None = Decimal(0)
    cash_account_day_count: DayCount = DayCount.ACT_360
    cash_account_fixing_lag_business_days: int = 0
    # Investor hurdle fees apply only to actual residual distributions.
    incentive_fee_enabled: bool = False
    incentive_fee_rate: Decimal = Decimal(0)
    incentive_hurdle_rate: Decimal = Decimal(0)
    incentive_initial_equity_funding: Decimal | None = None
    # Claim carry/accrual is separate from the investor hurdle and OC measurement.
    interest_shortfall_carry: bool = True
    shortfall_accrual_method: ShortfallAccrualMethod = ShortfallAccrualMethod.NONE
    continue_after_coupon_shortfall: bool = False
    # Lifecycle changes execute at an actual distribution, with explicit costs.
    optional_call_enabled: bool = False
    optional_call_date: date | None = None
    optional_call_collateral_sale_price: Decimal = Decimal(1)
    optional_call_cost_pct_of_debt: Decimal = Decimal(0)
    refinancing_enabled: bool = False
    refinancing_date: date | None = None
    refinancing_spread_reduction: Decimal = Decimal(0)
    refinancing_fee_pct_of_debt: Decimal = Decimal(0)
    maturity_liquidation_price: Decimal | None = None
    defaulted_collateral_sale_price: Decimal = Decimal(0)
    # Collateral valuation assumptions change OC credit, not sale/recovery cash.
    allow_long_dated_assets: bool = True
    long_dated_limit_fraction: Decimal | None = None
    adjusted_oc_policy: AdjustedCollateralValuePolicy | None = None
    original_pool_overlay: "OriginalPoolOverlay | None" = None
    synthetic_reinvestment_policy: "SyntheticReinvestmentPolicy | None" = None
    # Payment, fixing and determination calendars can have distinct purposes.
    payment_calendar: CalendarName | None = None
    fixing_calendar: CalendarName | None = None
    determination_calendar: CalendarName | None = None
    fixing_date_anchor: FixingDateAnchor = FixingDateAnchor.PERIOD_START
    first_stub_rate_method: FirstStubRateMethod = FirstStubRateMethod.SELECTED_REFERENCE
    independent_note_reference_tenor: bool = False
    # IC period debt service and OC outstanding claims have separate policies.
    include_deferred_interest_in_ic: bool = False
    # Capitalized deferrable coupon claims enter coverage outstanding amounts,
    # while face par and coupon claims remain separate conserved cash ledgers.
    include_deferred_interest_in_oc: bool = True
    principal_coupon_policy: PrincipalCouponPolicy = PrincipalCouponPolicy.NON_DEFERRABLE_AND_CONTROLLING
    interest_diversion_test_enabled: bool = False
    interest_diversion_test_class_id: str | None = None
    interest_diversion_test_oc_minimum: Decimal | None = None
    interest_diversion_test_max_fraction: Decimal = Decimal("0.5")
    interest_diversion_test_end_date: date | None = None

    def __post_init__(self) -> None:
        require_date(self.closing_date, "closing_date")
        require_date(self.legal_final_date, "legal_final_date")
        if self.legal_final_date <= self.closing_date:
            raise InputValidationError("legal_final_date must follow closing_date")
        if type(self.frequency_months) is not int or self.frequency_months not in {1, 3, 6, 12}:
            raise InputValidationError("CLO frequency_months must be 1, 3, 6 or 12")
        for name in ("senior_management_fee_bps", "subordinated_management_fee_bps"):
            require_decimal(getattr(self, name), name, minimum=Decimal(0))
        require_money(self.annual_senior_expenses, "annual_senior_expenses")
        require_money(self.initial_reserve, "initial_reserve")
        for value, enum_type, name in (
            (self.business_day_convention, BusinessDayConvention, "business_day_convention"),
            (self.accrual_date_basis, AccrualDateBasis, "accrual_date_basis"),
            (self.stub_convention, StubConvention, "stub_convention"),
        ):
            if not isinstance(value, enum_type):
                raise InputValidationError(f"{name} must be {enum_type.__name__}")
        for name in ("fixing_lag_business_days", "collection_cutoff_business_days"):
            value = getattr(self, name)
            if type(value) is not int or value < 0:
                raise InputValidationError(f"{name} must be a nonnegative integer")
        if type(self.end_of_month) is not bool:
            raise InputValidationError("end_of_month must be boolean")
        if self.original_pool_overlay is not None and not isinstance(self.original_pool_overlay, OriginalPoolOverlay):
            raise InputValidationError("original_pool_overlay must be a typed OriginalPoolOverlay")
        if self.synthetic_reinvestment_policy is not None and not isinstance(self.synthetic_reinvestment_policy, SyntheticReinvestmentPolicy):
            raise InputValidationError("synthetic_reinvestment_policy must be a typed SyntheticReinvestmentPolicy")
        if self.reinvestment_strategy not in {"NO_TRADES", "SYNTHETIC_TEMPLATE"}:
            raise InputValidationError("CLO reinvestment_strategy must be NO_TRADES or SYNTHETIC_TEMPLATE")
        if self.reinvestment_strategy == "SYNTHETIC_TEMPLATE" and (self.synthetic_reinvestment_policy is None or not self.synthetic_reinvestment_policy.enabled):
            raise InputValidationError("SYNTHETIC_TEMPLATE requires an enabled explicit reinvestment policy")
        if self.defaulted_asset_oc_treatment is not None and not isinstance(self.defaulted_asset_oc_treatment, DefaultedAssetOcTreatment):
            raise InputValidationError("defaulted_asset_oc_treatment must be a typed explicit policy")
        if self.defaulted_asset_oc_treatment is DefaultedAssetOcTreatment.ADJUSTED_POLICY and self.adjusted_oc_policy is None:
            raise InputValidationError("ADJUSTED_POLICY defaulted credit requires an explicit adjusted OC valuation")
        if (self.defaulted_asset_oc_treatment is DefaultedAssetOcTreatment.EXCLUDE
                and self.adjusted_oc_policy is not None and self.adjusted_oc_policy.defaulted_valuation != 0):
            raise InputValidationError("EXCLUDE defaulted OC treatment conflicts with nonzero adjusted defaulted valuation")
        for name in ("coverage_tests_enabled", "interest_diversion_enabled", "include_principal_cash_in_oc"):
            if type(getattr(self, name)) is not bool:
                raise InputValidationError(f"{name} must be boolean")
        for name, enum_type in (
            ("principal_repayment_mode", PrincipalRepaymentMode),
            ("interest_diversion_mode", InterestDiversionMode),
            ("management_fee_basis", ManagementFeeBasis),
            ("cash_account_accrual_mode", CashAccountAccrualMode),
        ):
            if not isinstance(getattr(self, name), enum_type):
                raise InputValidationError(f"{name} must be its typed enum")
        for name in ("management_fee_day_count", "senior_expenses_day_count"):
            if not isinstance(getattr(self, name), DayCount) or getattr(self, name) not in {DayCount.ACT_360, DayCount.ACT_365F}:
                raise InputValidationError(f"{name} supports explicit ACT/360 or ACT/365F only")
        if (type(self.recurring_senior_expenses) is not tuple
                or any(not isinstance(row, RecurringSeniorExpense) for row in self.recurring_senior_expenses)
                or len({row.expense_id for row in self.recurring_senior_expenses}) != len(self.recurring_senior_expenses)):
            raise InputValidationError("recurring_senior_expenses must have unique named immutable components")
        if self.recurring_senior_expenses and self.annual_senior_expenses != 0:
            raise InputValidationError("Use annual_senior_expenses OR named recurring components, not both")
        for name in ("variable_senior_expenses_bps", "senior_expense_cap_bps"):
            require_decimal(getattr(self, name), name, minimum=Decimal(0))
        if self.annual_senior_expense_cap is not None:
            require_money(self.annual_senior_expense_cap, "annual_senior_expense_cap")
        elif self.senior_expense_cap_bps:
            raise InputValidationError("Variable expense cap requires explicit annual_senior_expense_cap, including zero")
        for name in ("first_payment_date_unadjusted", "last_regular_date_unadjusted"):
            boundary = getattr(self, name)
            if boundary is not None:
                require_date(boundary, name)
                if not self.closing_date < boundary <= self.legal_final_date:
                    raise InputValidationError(f"{name} must follow closing and not exceed legal final")
        if self.first_stub_rate_override is not None:
            require_decimal(self.first_stub_rate_override, "first_stub_rate_override")
        require_decimal(self.cash_account_spread_bps, "cash_account_spread_bps")
        if self.cash_account_rate_floor is not None:
            require_decimal(self.cash_account_rate_floor, "cash_account_rate_floor")
        if not isinstance(self.cash_account_day_count, DayCount) or self.cash_account_day_count not in {DayCount.ACT_360, DayCount.ACT_365F}:
            raise InputValidationError("Cash account day count supports explicit ACT/360 or ACT/365F only")
        if type(self.cash_account_fixing_lag_business_days) is not int or self.cash_account_fixing_lag_business_days < 0:
            raise InputValidationError("cash_account_fixing_lag_business_days must be a nonnegative integer")
        if self.cash_account_accrual_mode is CashAccountAccrualMode.NONE:
            if (self.cash_account_fixed_rate is not None or self.cash_account_rate_index is not None
                    or self.cash_account_spread_bps != 0 or self.cash_account_fixing_lag_business_days != 0
                    or self.cash_account_rate_floor not in {None, Decimal(0)}):
                raise InputValidationError("Cash accrual NONE requires inactive fixed/index/spread/floor/fixing-lag inputs")
        elif self.cash_account_accrual_mode is CashAccountAccrualMode.FIXED_SIMPLE:
            require_decimal(self.cash_account_fixed_rate, "cash_account_fixed_rate")
            if self.cash_account_rate_index is not None or self.cash_account_fixing_lag_business_days != 0:
                raise InputValidationError("Fixed cash accrual uses a fixed rate, no index or fixing lag")
        elif self.cash_account_accrual_mode is CashAccountAccrualMode.DF_FORWARD_SIMPLE:
            if self.cash_account_fixed_rate is not None or self.cash_account_rate_index not in {"ESTR", "SOFR", "SONIA"}:
                raise InputValidationError("DF-forward cash accrual requires an explicit OIS cash index and no fixed rate")
        elif (self.cash_account_fixed_rate is not None
              or self.cash_account_rate_index not in {"EURIBOR_1M", "EURIBOR_3M", "EURIBOR_6M"}):
            raise InputValidationError("Projected cash accrual requires EURIBOR term rate, no fixed rate; RFR zero curves are not cash fixings")
        for name in ("incentive_fee_enabled", "interest_shortfall_carry", "continue_after_coupon_shortfall",
                     "optional_call_enabled", "refinancing_enabled", "allow_long_dated_assets"):
            if type(getattr(self, name)) is not bool:
                raise InputValidationError(f"{name} must be boolean")
        if not isinstance(self.shortfall_accrual_method, ShortfallAccrualMethod):
            raise InputValidationError("shortfall_accrual_method must be its typed enum")
        for name in ("incentive_fee_rate", "incentive_hurdle_rate", "optional_call_cost_pct_of_debt", "refinancing_fee_pct_of_debt"):
            if require_decimal(getattr(self, name), name, minimum=Decimal(0)) > 1:
                raise InputValidationError(f"{name} must not exceed 1")
        require_decimal(self.refinancing_spread_reduction, "refinancing_spread_reduction", minimum=Decimal(0))
        if self.incentive_initial_equity_funding is not None:
            require_money(self.incentive_initial_equity_funding, "incentive_initial_equity_funding")
        if self.incentive_fee_enabled and self.incentive_initial_equity_funding is None:
            raise InputValidationError("Enabled incentive fee requires actual equity cash funding, not nominal par")
        for prefix in ("optional_call", "refinancing"):
            boundary = getattr(self, f"{prefix}_date")
            if boundary is not None:
                require_date(boundary, f"{prefix}_date")
                if not self.closing_date < boundary <= self.legal_final_date:
                    raise InputValidationError(f"{prefix}_date must follow closing and not exceed legal final")
            if getattr(self, f"{prefix}_enabled") and boundary is None:
                raise InputValidationError(f"Enabled {prefix} requires a requested date")
        price = require_decimal(self.optional_call_collateral_sale_price, "optional_call_collateral_sale_price", minimum=Decimal(0))
        if price > Decimal("1.5"):
            raise InputValidationError("optional_call_collateral_sale_price must not exceed 1.5")
        for name in ("maturity_liquidation_price", "long_dated_limit_fraction", "defaulted_collateral_sale_price"):
            value = getattr(self, name)
            if value is not None and require_decimal(value, name, minimum=Decimal(0)) > 1:
                raise InputValidationError(f"{name} must not exceed 1")
        if self.adjusted_oc_policy is not None and not isinstance(self.adjusted_oc_policy, AdjustedCollateralValuePolicy):
            raise InputValidationError("adjusted_oc_policy must be an explicit typed policy")
        for name in ("payment_calendar", "fixing_calendar", "determination_calendar"):
            value = getattr(self, name)
            if value is not None and not isinstance(value, CalendarName):
                raise InputValidationError(f"{name} must be CalendarName or None for the engine calendar")
        if not isinstance(self.fixing_date_anchor, FixingDateAnchor) or not isinstance(self.first_stub_rate_method, FirstStubRateMethod):
            raise InputValidationError("Note fixing anchor / stub method must be typed enums")
        if type(self.independent_note_reference_tenor) is not bool:
            raise InputValidationError("independent_note_reference_tenor must be boolean")
        for name in ("include_deferred_interest_in_ic", "include_deferred_interest_in_oc", "interest_diversion_test_enabled"):
            if type(getattr(self, name)) is not bool:
                raise InputValidationError(f"{name} must be boolean")
        if not isinstance(self.principal_coupon_policy, PrincipalCouponPolicy):
            raise InputValidationError("principal_coupon_policy must be its typed enum")
        if self.interest_diversion_test_class_id is not None and (
                not isinstance(self.interest_diversion_test_class_id, str)
                or not self.interest_diversion_test_class_id
                or self.interest_diversion_test_class_id != self.interest_diversion_test_class_id.strip()):
            raise InputValidationError("IDT class ID must be nonblank and unpadded")
        if self.interest_diversion_test_oc_minimum is not None:
            if require_decimal(self.interest_diversion_test_oc_minimum, "IDT OC minimum", minimum=Decimal(0)) == 0:
                raise InputValidationError("IDT OC minimum must be positive")
        if require_decimal(self.interest_diversion_test_max_fraction, "IDT residual fraction", minimum=Decimal(0)) > 1:
            raise InputValidationError("IDT residual fraction must not exceed 1")
        if self.interest_diversion_test_end_date is not None:
            require_date(self.interest_diversion_test_end_date, "IDT end date")
            if not self.closing_date < self.interest_diversion_test_end_date <= self.legal_final_date:
                raise InputValidationError("IDT end date must follow closing and not exceed legal final")
        if self.interest_diversion_test_enabled and (
                self.interest_diversion_test_class_id is None
                or self.interest_diversion_test_oc_minimum is None
                or self.interest_diversion_test_end_date is None):
            raise InputValidationError("Enabled IDT requires class, OC threshold and reinvestment end date")


@dataclass(frozen=True)
class CloNoteCouponClaim:
    """Verified unpaid coupon cents, separate from current note face principal."""

    class_id: str
    unpaid_coupon: Decimal

    def __post_init__(self) -> None:
        if not isinstance(self.class_id, str) or not self.class_id or self.class_id != self.class_id.strip():
            raise InputValidationError("Opening coupon class_id must be nonblank and unpadded")
        require_money(self.unpaid_coupon, "opening unpaid_coupon")


@dataclass(frozen=True)
class CloOpeningState:
    """Actual post-distribution cash and claims at an original payment boundary.

    Physical collection cash, determination-pending cash and restricted reserve
    are separate conserved balances. Reinvestment permission and held IDT cash
    are DESIGNATIONS inside principal cash, never additional assets or receipts.
    Every retained class has an explicit unpaid claim, including verified zeros.
    This state carries no historical investor hurdle, defaulted inventory or
    outstanding trade commitments. Those require fuller opening-state profiles.
    """

    as_of_date: date
    principal_cash: Decimal
    interest_cash: Decimal
    reserve: Decimal
    note_coupon_claims: tuple[CloNoteCouponClaim, ...]
    source: str
    pending_interest_cash: Decimal = Decimal(0)
    pending_principal_cash: Decimal = Decimal(0)
    expense_arrears: Decimal = Decimal(0)
    senior_management_fee_arrears: Decimal = Decimal(0)
    subordinated_management_fee_arrears: Decimal = Decimal(0)
    deferred_senior_expense_arrears: Decimal = Decimal(0)
    original_principal_reinvestment_cash: Decimal = Decimal(0)
    pending_original_principal_reinvestment_cash: Decimal = Decimal(0)
    held_diversion_principal: Decimal = Decimal(0)
    initial_collateral_par: Decimal | None = None

    def __post_init__(self) -> None:
        require_date(self.as_of_date, "CLO opening as_of_date")
        if not isinstance(self.source, str) or not self.source or self.source != self.source.strip():
            raise InputValidationError("CLO opening state requires nonblank unpadded source")
        for name in ("principal_cash", "interest_cash", "reserve", "pending_interest_cash",
                     "pending_principal_cash", "expense_arrears", "senior_management_fee_arrears",
                     "subordinated_management_fee_arrears", "deferred_senior_expense_arrears",
                     "original_principal_reinvestment_cash", "pending_original_principal_reinvestment_cash",
                     "held_diversion_principal"):
            require_money(getattr(self, name), f"CLO opening {name}")
        if (type(self.note_coupon_claims) is not tuple or not self.note_coupon_claims
                or any(not isinstance(row, CloNoteCouponClaim) for row in self.note_coupon_claims)
                or len({row.class_id for row in self.note_coupon_claims}) != len(self.note_coupon_claims)):
            raise InputValidationError("Opening note coupon claims require a nonempty immutable tuple of unique classes")
        if (Fraction(self.original_principal_reinvestment_cash) + Fraction(self.held_diversion_principal)
                > Fraction(self.principal_cash)):
            raise InputValidationError("Opening reinvestment and held IDT designations must be disjoint subsets of principal cash")
        if self.pending_original_principal_reinvestment_cash > self.pending_principal_cash:
            raise InputValidationError("Pending original principal permission cannot exceed pending principal cash")
        if self.initial_collateral_par is not None:
            require_money(self.initial_collateral_par, "original initial_collateral_par", positive=True)

    def monetary_values(self) -> tuple[Decimal, ...]:
        """Include every opening cash/claim when sizing exact ledger precision."""
        amounts = tuple(getattr(self, name) for name in (
            "principal_cash", "interest_cash", "reserve", "pending_interest_cash", "pending_principal_cash",
            "expense_arrears", "senior_management_fee_arrears", "subordinated_management_fee_arrears",
            "deferred_senior_expense_arrears", "original_principal_reinvestment_cash",
            "pending_original_principal_reinvestment_cash", "held_diversion_principal"))
        return (*amounts, *(row.unpaid_coupon for row in self.note_coupon_claims),
                *((self.initial_collateral_par,) if self.initial_collateral_par is not None else ()))


@dataclass(frozen=True)
class CloRunRequest:
    """Fully projected asset receivables plus closing performing par and debt.

    Asset rows are treated as deterministic realised-on-payment-date collections
    in this baseline. Credit losses and recoveries require explicit event models;
    an incomplete or inconsistent contractual schedule cannot stand in for them.
    """

    asset_cashflows: tuple[LoanCashflow, ...]
    opening_collateral_par: Decimal
    tranches: tuple[NoteTranche, ...]
    terms: CloTerms
    asset_credit_projections: tuple[AssetCreditProjection, ...] = ()
    oc_asset_data: tuple[OcAssetData, ...] = ()
    imported_collateral: "ImportedCollateralProjection | None" = None
    additional_asset_collections: tuple[AssetCollection, ...] = ()
    acquired_accrued_by_loan: Mapping[str, Decimal] | None = None
    asset_day_counts: Mapping[str, DayCount] | None = None
    opening_state: CloOpeningState | None = None
    principal_accrued_balances: tuple[PrincipalAccruedBalance, ...] = ()
    coupon_proceeds_allocations: tuple[CouponProceedsAllocation, ...] = ()

    def __post_init__(self) -> None:
        if self.imported_collateral is not None:
            from trident.application.imported_cashflows import ImportedCollateralProjection
            if not isinstance(self.imported_collateral, ImportedCollateralProjection):
                raise InputValidationError("imported_collateral must be a typed ImportedCollateralProjection")
        if type(self.asset_cashflows) is not tuple or (not self.asset_cashflows and self.imported_collateral is None) or not all(isinstance(row, LoanCashflow) for row in self.asset_cashflows):
            raise InputValidationError("asset_cashflows must be a nonempty immutable tuple of LoanCashflow")
        require_money(self.opening_collateral_par, "opening_collateral_par", positive=True)
        if type(self.tranches) is not tuple or not self.tranches or not all(isinstance(row, NoteTranche) for row in self.tranches):
            raise InputValidationError("tranches must be a nonempty immutable tuple of NoteTranche")
        if not isinstance(self.terms, CloTerms):
            raise InputValidationError("terms must be CloTerms")
        if self.opening_state is not None and not isinstance(self.opening_state, CloOpeningState):
            raise InputValidationError("opening_state must be CloOpeningState or None")
        if self.opening_state is None and any(row.opening_balance == 0 for row in self.tranches):
            raise InputValidationError("New CLO closing requires positive issued face in every debt class")
        if self.opening_state is not None:
            if not self.terms.closing_date <= self.opening_state.as_of_date < self.terms.legal_final_date:
                raise InputValidationError("Existing CLO opening must be on/after original closing and before legal final")
            if {row.class_id for row in self.opening_state.note_coupon_claims} != {row.class_id for row in self.tranches}:
                raise InputValidationError("Opening coupon claims must explicitly cover every retained note class")
        if type(self.asset_credit_projections) is not tuple or any(not isinstance(row, AssetCreditProjection) for row in self.asset_credit_projections):
            raise InputValidationError("asset_credit_projections must be an immutable tuple")
        if any(isinstance(row.event, DefaultEvent) for row in self.asset_credit_projections) and self.terms.defaulted_asset_oc_treatment is None:
            raise InputValidationError("Default scenarios require explicit defaulted_asset_oc_treatment; no legal OC valuation is guessed")
        if len({row.class_id for row in self.tranches}) != len(self.tranches):
            raise InputValidationError("Duplicate note class_id")
        if len({row.payment_priority for row in self.tranches}) != len(self.tranches):
            raise InputValidationError("Duplicate note payment_priority")
        if self.terms.interest_diversion_test_enabled and self.terms.interest_diversion_test_class_id not in {row.class_id for row in self.tranches}:
            raise InputValidationError("IDT tested class must exist in the capital stack")
        for tranche in self.tranches:
            if not self.terms.independent_note_reference_tenor and tranche.coupon_type is CouponType.FLOATING and tranche.rate_index != f"EURIBOR_{self.terms.frequency_months}M":
                raise InputValidationError("Floating note reset tenor must match the common distribution frequency")
        if type(self.oc_asset_data) is not tuple or any(not isinstance(row, OcAssetData) for row in self.oc_asset_data):
            raise InputValidationError("oc_asset_data must be an immutable tuple of OcAssetData")
        if len({row.loan_id for row in self.oc_asset_data}) != len(self.oc_asset_data):
            raise InputValidationError("Duplicate OC asset classification")
        if self.acquired_accrued_by_loan is not None:
            if not isinstance(self.acquired_accrued_by_loan, Mapping):
                raise InputValidationError("acquired_accrued_by_loan must be an identified mapping")
            for identifier, amount in self.acquired_accrued_by_loan.items():
                if not isinstance(identifier, str) or not identifier or identifier != identifier.strip():
                    raise InputValidationError("Inherited coupon loan IDs must be nonblank and unpadded")
                require_money(amount, "acquired coupon entitlement")
            object.__setattr__(self, "acquired_accrued_by_loan", MappingProxyType(dict(self.acquired_accrued_by_loan)))
        if type(self.additional_asset_collections) is not tuple or any(not isinstance(row, AssetCollection) for row in self.additional_asset_collections):
            raise InputValidationError("additional_asset_collections must be an immutable tuple of AssetCollection")
        identifiers = (set(self.imported_collateral.loan_opening_par) if self.imported_collateral is not None
                       else {row.loan_id for row in self.asset_cashflows})
        validate_coupon_proceeds_inputs(
            self.principal_accrued_balances, self.coupon_proceeds_allocations,
            as_of_date=self.projection_start_date,
        )
        if self.principal_accrued_balances:
            claimed = {row.loan_id for row in self.principal_accrued_balances}
            if any(row.payment_date > self.terms.legal_final_date for row in self.coupon_proceeds_allocations):
                raise InputValidationError("Coupon proceeds restoration receipt must be on/before CLO legal final; future sale proceeds need another classification policy")
            if not claimed.issubset(identifiers):
                raise InputValidationError("Principal accrued balances require identified native opening loans")
            if self.imported_collateral is not None or self.additional_asset_collections:
                raise InputValidationError("Coupon proceeds classification currently requires native cash only; imported/additional external receipts are unsupported")
            if self.terms.original_pool_overlay is not None and self.terms.original_pool_overlay.enabled:
                raise InputValidationError("Coupon proceeds classification does not implement proportional original-pool default/prepayment allocation")
            if self.terms.optional_call_enabled:
                raise InputValidationError("Coupon proceeds classification cannot allocate an optional-call asset sale without a sale-accrued policy")
            if any(row.loan_id in claimed and isinstance(row.event, DefaultEvent)
                   for row in self.asset_credit_projections):
                raise InputValidationError("A claimed loan default requires an explicit principal-accrued loss/recovery policy")
            policy = self.terms.synthetic_reinvestment_policy
            if (policy is not None and policy.enabled and policy.recycle_reinvestment_principal
                    and any(not row.original_principal_permission for row in self.coupon_proceeds_allocations)):
                raise InputValidationError("Noneligible restored principal cannot use an enabled recycle-all synthetic reinvestment policy")
        if self.asset_day_counts is not None:
            if not isinstance(self.asset_day_counts, Mapping) or not set(self.asset_day_counts).issubset(identifiers):
                raise InputValidationError("Asset day counts require an identified loan mapping")
            if any(not isinstance(value, DayCount) for value in self.asset_day_counts.values()):
                raise InputValidationError("Asset day counts must be typed DayCount values")
            object.__setattr__(self, "asset_day_counts", MappingProxyType(dict(self.asset_day_counts)))
        if any(row.loan_id not in identifiers or row.currency != "EUR" or row.payment_date <= self.projection_start_date
               or row.principal_collection != 0 for row in self.additional_asset_collections):
            raise InputValidationError("Additional interest collections require an identified EUR loan, post-closing date and zero principal")

    @property
    def projection_start_date(self) -> date:
        """Actual opening snapshot; original closing remains a contract anchor."""
        return self.terms.closing_date if self.opening_state is None else self.opening_state.as_of_date


@dataclass(frozen=True)
class CoverageTestResult:
    """Node-specific tested-stack snapshot; ratios are decimal multiples.

    Numerator/denominator are authoritative amounts at this node. A displayed
    ratio is diagnostic and is not rounded before testing the threshold. The
    cure field means interest-funded face redemption, not an IDT acquisition
    transfer or a guarantee that sufficient executable cash exists.
    """

    period_number: int
    payment_date: date
    class_id: str
    payment_priority: int
    stage: str
    oc_numerator: Decimal
    oc_denominator: Decimal
    oc_ratio: Decimal | None
    oc_minimum: Decimal | None
    oc_status: CoverageStatus
    ic_numerator: Decimal
    ic_denominator: Decimal
    ic_ratio: Decimal | None
    ic_minimum: Decimal | None
    ic_status: CoverageStatus
    minimum_interest_repayment_for_oc: Decimal | None


@dataclass(frozen=True)
class TranchePeriodSnapshot:
    """Separate face movement, coupon-origin claims and their cash sources.

    Opening/closing balances are actual face including previously capitalized
    mandatory PIK. Current ``pik_interest_capitalized`` increases that face;
    it is excluded from ``current_coupon_due``, which is a cash-pay claim.
    Remaining deferrable coupon claims
    may enter capitalized OC outstanding under the selected policy, but are
    retained here as coupon-origin economics. This is not a legal/tax payment
    classification or a second face-par redemption.
    """

    period_number: int
    payment_date: date
    class_id: str
    payment_priority: int
    opening_balance: Decimal
    closing_balance: Decimal
    opening_coupon_arrears: Decimal
    current_coupon_due: Decimal
    coupon_paid_from_interest: Decimal
    coupon_paid_from_principal: Decimal
    closing_coupon_arrears: Decimal
    principal_from_interest: Decimal
    principal_from_principal: Decimal
    fixing_date: date | None
    index_rate: Decimal | None
    all_in_rate: Decimal
    day_count_fraction: Decimal
    interest_gate_blocked: bool
    coupon_shortfall_interest: Decimal = Decimal(0)
    waived_coupon_shortfall: Decimal = Decimal(0)
    # Mandatory contractual PIK settles the coupon by increasing actual face;
    # it is not a surviving optional deferred claim or physical cash payment.
    pik_interest_capitalized: Decimal = Decimal(0)


@dataclass(frozen=True)
class DatedDistribution:
    """Positive economic cash amount; source distinguishes receipt/contribution.

    Investor return construction determines its sign from the owning ledger,
    not from a nominal equity-class balance or an inferred funding assumption.
    """
    payment_date: date
    amount: Decimal
    source: str


@dataclass(frozen=True)
class CloPeriodSummary:
    """Complete payment-day accounts and separate cash/par/claim diagnostics.

    Received cash includes pending collections; eligible cash is available to
    this waterfall. Debt par includes mandatory PIK face and excludes optional
    coupon-origin claims even when those claims enter OC capitalization.
    ``note_coupon_due`` describes outstanding cash-pay claims, not mandatory
    current PIK. Source cash/exposure fields supply matching economics inputs.
    The IDT held amount is a designation inside
    closing principal cash, not an extra asset or extra conservation source.
    """

    period_number: int
    payment_date: date
    accrual_start: date
    accrual_end: date
    opening_collateral_par: Decimal
    closing_collateral_par: Decimal
    received_asset_interest: Decimal
    received_asset_principal: Decimal
    eligible_asset_interest: Decimal
    eligible_asset_principal: Decimal
    opening_interest_cash: Decimal
    closing_interest_cash: Decimal
    opening_principal_cash: Decimal
    closing_principal_cash: Decimal
    pending_interest_cash: Decimal
    pending_principal_cash: Decimal
    senior_expenses_due: Decimal
    senior_expenses_paid: Decimal
    senior_expenses_unpaid: Decimal
    senior_management_fee_due: Decimal
    senior_management_fee_paid: Decimal
    senior_management_fee_unpaid: Decimal
    subordinated_management_fee_due: Decimal
    subordinated_management_fee_paid: Decimal
    subordinated_management_fee_unpaid: Decimal
    note_coupon_due: Decimal
    note_coupon_paid: Decimal
    note_coupon_unpaid: Decimal
    opening_debt_par: Decimal
    closing_debt_par: Decimal
    debt_principal_from_interest: Decimal
    debt_principal_from_principal: Decimal
    reserve_opening: Decimal
    reserve_draw: Decimal
    reserve_release: Decimal
    reserve_closing: Decimal
    equity_from_interest: Decimal
    equity_from_principal: Decimal
    equity_from_reserve: Decimal
    coverage_failed: bool
    failed_gate_class: str | None
    cash_pay_failure: bool
    reinvestment_strategy: str
    cash_conservation_residual: Decimal
    defaulted_par: Decimal = Decimal(0)
    scheduled_principal_received: Decimal = Decimal(0)
    prepayment_principal_received: Decimal = Decimal(0)
    recovery_principal_received: Decimal = Decimal(0)
    newly_defaulted_par: Decimal = Decimal(0)
    recognized_par_loss: Decimal = Decimal(0)
    newly_incurred_senior_expenses: Decimal = Decimal(0)
    senior_expense_priority_cap: Decimal | None = None
    deferred_senior_expenses_due: Decimal = Decimal(0)
    deferred_senior_expenses_paid: Decimal = Decimal(0)
    deferred_senior_expenses_unpaid: Decimal = Decimal(0)
    cash_account_interest: Decimal = Decimal(0)
    cash_account_all_in_rate: Decimal | None = None
    cash_account_fixing_date: date | None = None
    adjusted_collateral_value: Decimal = Decimal(0)
    oc_ccc_haircut: Decimal = Decimal(0)
    oc_discount_haircut: Decimal = Decimal(0)
    oc_long_dated_haircut: Decimal = Decimal(0)
    oc_overlap_credit: Decimal = Decimal(0)
    oc_defaulted_value: Decimal = Decimal(0)
    long_dated_par: Decimal = Decimal(0)
    note_shortfall_interest: Decimal = Decimal(0)
    waived_note_coupon_shortfall: Decimal = Decimal(0)
    incentive_fee_paid: Decimal = Decimal(0)
    incentive_hurdle_balance: Decimal = Decimal(0)
    collateral_sale_par: Decimal = Decimal(0)
    collateral_sale_proceeds: Decimal = Decimal(0)
    collateral_sale_gain_loss: Decimal = Decimal(0)
    optional_call_costs: Decimal = Decimal(0)
    optional_call_status: str = "NOT_REQUESTED"
    refinancing_fee: Decimal = Decimal(0)
    refinancing_effective: bool = False
    reinvestment_cash_used: Decimal = Decimal(0)
    reinvestment_par_acquired: Decimal = Decimal(0)
    collateral_non_cash_par_change: Decimal = Decimal(0)
    interest_diversion_test_oc_numerator: Decimal | None = None
    interest_diversion_test_oc_denominator: Decimal | None = None
    interest_diversion_test_oc_ratio: Decimal | None = None
    interest_diversion_test_oc_minimum: Decimal | None = None
    interest_diversion_test_status: CoverageStatus = CoverageStatus.NOT_CONFIGURED
    interest_diversion_test_transferred: Decimal = Decimal(0)
    interest_diversion_test_held_principal: Decimal = Decimal(0)
    note_pik_capitalized: Decimal = Decimal(0)
    # Economics denominator and source amounts share the actual stressed
    # collection stream. Exposure is face-days / 365, not coupon DCF or cash.
    original_asset_cash_interest: Decimal = Decimal(0)
    reinvestment_asset_cash_interest: Decimal = Decimal(0)
    original_performing_par_years: Decimal = Decimal(0)
    reinvestment_performing_par_years: Decimal = Decimal(0)
    debt_face_par_years: Decimal = Decimal(0)
    reinvestment_reference_interest: Decimal = Decimal(0)
    reinvestment_spread_interest: Decimal = Decimal(0)


@dataclass(frozen=True)
class CloProjection:
    """Unresolved failure does not invent liquidation proceeds or terminal IRR."""

    periods: tuple[CloPeriodSummary, ...]
    tranche_periods: tuple[TranchePeriodSnapshot, ...]
    coverage_tests: tuple[CoverageTestResult, ...]
    equity_cashflows: tuple[DatedDistribution, ...]
    status: ProjectionStatus
    terminal_value_available: bool
    final_collateral_par: Decimal
    final_debt_par: Decimal
    final_interest_cash: Decimal
    final_principal_cash: Decimal
    final_pending_interest_cash: Decimal
    final_pending_principal_cash: Decimal
    final_reserve: Decimal
    final_senior_claims: Decimal
    final_note_coupon_arrears: Decimal
    final_subordinated_fee_arrears: Decimal
    total_equity_distributions: Decimal
    final_defaulted_par: Decimal = Decimal(0)
    total_defaulted_exposure: Decimal = Decimal(0)
    total_recovery_collections: Decimal = Decimal(0)
    total_recognized_par_loss: Decimal = Decimal(0)
    final_deferred_senior_expenses: Decimal = Decimal(0)
    total_cash_account_interest: Decimal = Decimal(0)
    equity_contributions: tuple[DatedDistribution, ...] = ()
    total_incentive_fee_paid: Decimal = Decimal(0)
    total_collateral_sale_proceeds: Decimal = Decimal(0)
    total_refinancing_fees: Decimal = Decimal(0)
    original_overlay_projection: PoolOverlayProjection | None = None
    reinvestment_purchases: tuple[ReinvestmentPurchase, ...] = ()
    reinvestment_par_movements: tuple[OverlayParMovement, ...] = ()
    # Existing transactions retain their original contractual identifiers.
    # Reporting must validate contiguous surviving periods from this explicit
    # origin rather than silently renumbering the operating snapshot to one.
    first_projected_period_number: int = 1
    coupon_proceeds_audit: tuple[CouponProceedsAudit, ...] = ()
