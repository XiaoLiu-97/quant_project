"""Project Trident: financial engines independent of their Excel interface."""

__version__ = "0.12.3"
