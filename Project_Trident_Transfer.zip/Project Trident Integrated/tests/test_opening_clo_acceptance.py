"""Independent cash ledgers for a post-distribution existing CLO snapshot.

An operating snapshot is not another issuance: original contract dates remain
anchors, outstanding face and unpaid coupon claims are separate, and physical
opening cash belongs to explicitly identified accounts. The small controls in
this module expose restarted coupons, duplicated claims, and fictitious new
funding without relying on the model's fee or coverage formula helpers.
"""

import unittest
from dataclasses import replace
from datetime import date
from decimal import Decimal, localcontext

from trident.analysis import AssetExposure, ReturnStatus
from trident.application.clo_services import TridentModelRequest, TridentModelService
from trident.application.services import CashflowRunRequest
from trident.clo.engine import DeterministicCloEngine
from trident.clo.models import (
    CloNoteCouponClaim, CloOpeningState, CloRunRequest, CloTerms, CoverageStatus,
    ManagementFeeBasis, NoteTranche, ProjectionStatus,
)
from trident.conventions import AccrualDateBasis, BusinessDayConvention, DayCount, StubConvention
from trident.domain.models import (
    CouponType, InputValidationError, LoanCashflow, LoanPosition, LoanTerms,
    SeasonedLoanState,
)
from trident.funding.engine import AssetPurchase, DebtIssue
from trident.market import FlatRateProvider


D = Decimal
ORIGINAL = date(2026, 1, 1)
OPEN = date(2026, 4, 1)
NEXT = date(2026, 7, 1)
FINAL = date(2026, 10, 1)
SOURCE = "Independent post-distribution trustee hand control"


def state(*, claims=(("A", "0"),), **changes):
    """Every retained class supplies evidence even when its claim is zero."""
    return CloOpeningState(
        OPEN, D(0), D(0), D(0),
        tuple(CloNoteCouponClaim(identifier, D(amount)) for identifier, amount in claims),
        SOURCE, **changes,
    )


def note(identifier="A", priority=1, par="80", *, rate="0", **changes):
    return NoteTranche(identifier, priority, D(par), CouponType.FIXED,
                       fixed_rate=D(rate), day_count=DayCount.ACT_360, **changes)


def receipt(number, start, end, *, principal="0", interest="0", par="100"):
    """Cash is hand supplied so coverage controls do not depend on a loan engine."""
    face, redeemed, coupon = D(par), D(principal), D(interest)
    return LoanCashflow(
        "L", "EUR", number, start, end, start, end, end, None,
        face, None, D(0), D(0), D("0.25"), coupon, coupon,
        redeemed, face - redeemed, redeemed + coupon,
    )


def core(rows, notes, opening=None, *, legal_final=FINAL, **term_changes):
    terms = CloTerms(
        ORIGINAL, legal_final,
        business_day_convention=BusinessDayConvention.UNADJUSTED,
        accrual_date_basis=AccrualDateBasis.UNADJUSTED,
        fixing_lag_business_days=0, **term_changes,
    )
    request = CloRunRequest(rows, D(100), notes, terms,
                           opening_state=opening or state())
    return DeterministicCloEngine(FlatRateProvider({"EURIBOR_3M": D("0.025")})).run(request)


def operating_request(*, opening=None, equity_mark="18", terms=None):
    """One held original loan and one outstanding note; no historic purchases."""
    loan = LoanTerms(
        "L", "EUR", ORIGINAL, NEXT, D(100), CouponType.FIXED,
        fixed_rate=D("0.12"), day_count=DayCount.ACT_360,
        business_day_convention=BusinessDayConvention.UNADJUSTED,
        accrual_date_basis=AccrualDateBasis.UNADJUSTED,
        fixing_lag_business_days=0,
    )
    position = LoanPosition(loan, OPEN, D(100), SeasonedLoanState(D(0), SOURCE))
    opening = opening or state()
    cash = CashflowRunRequest(
        (position,), (AssetPurchase("L", D(100), D(100)),),
        (DebtIssue("A", D(80), D(100)),),
        FlatRateProvider({"EURIBOR_3M": D("0.025")}),
        D(0), opening.reserve, SOURCE,
    )
    exposure = AssetExposure(
        "L", "O", "BSL", "LOAN", "FR", "Industrial", "EUR", D(100),
        None, NEXT, coupon_type=CouponType.FIXED, fixed_coupon_rate=D("0.12"),
    )
    terms = terms or CloTerms(
        ORIGINAL, NEXT,
        business_day_convention=BusinessDayConvention.UNADJUSTED,
        accrual_date_basis=AccrualDateBasis.UNADJUSTED,
        fixing_lag_business_days=0,
    )
    return TridentModelRequest(
        cash, (exposure,), clo_terms=terms, notes=(note(rate="0.06"),),
        clo_opening_state=opening, forward_equity_value=D(equity_mark),
        equity_value_source="Independent equity opening market mark",
    )


class ExistingCloAcceptanceTests(unittest.TestCase):
    def test_original_grid_and_forward_equity_mark_do_not_reissue_the_deal(self):
        result = TridentModelService().run(operating_request())
        period, = result.clo.periods
        # Apr1-Jul1 contains91 days. Existing80 face owes80*.06*91/360,
        # and the original100 loan owes100*.12*91/360. Historical Jan-Apr
        # distributions and issuance funding must not be repeated.
        self.assertEqual(period.period_number, 2)
        self.assertEqual((period.accrual_start, period.accrual_end), (OPEN, NEXT))
        self.assertEqual(period.received_asset_interest, D("3.03"))
        self.assertEqual(period.note_coupon_due, D("1.21"))
        self.assertEqual(result.clo.total_equity_distributions, D("21.82"))
        self.assertIsNone(result.cashflows.funding)
        self.assertEqual(result.equity_cashflows[0].payment_date, OPEN)
        self.assertEqual(result.equity_cashflows[0].amount, D(-18))
        self.assertIs(result.equity_irr.status, ReturnStatus.AVAILABLE)
        self.assertIs(result.clo.status, ProjectionStatus.COMPLETED)
        self.assertEqual(result.opening_portfolio.as_of_date, OPEN)
        # Monitoring retains the opening observation itself, then future
        # events; it must never fabricate a pre-snapshot operating holding.
        self.assertTrue(all(row.as_of_date >= OPEN for row in result.portfolio_observations))

    def test_existing_clo_cli_summary_does_not_require_issuance_funding(self):
        from trident.cli import _summary

        result = TridentModelService().run(operating_request())
        output = _summary(result)
        self.assertEqual(D(output["collateral_par_eur"]), D(100))
        self.assertIsNone(output["debt_proceeds_eur"])
        self.assertIsNone(output["equity_cash_funding_eur"])
        self.assertEqual(output["projection_start_date"], "2026-04-01")

    def test_note_and_fee_claim_names_have_distinct_reconciliation_identities(self):
        from trident.adapters import excel_schema as schema
        from trident.adapters.clo_opening_records import ACCOUNT_FIELDS, FEE_FIELDS, opening_audit

        # A class label is user data. It can coincide with an expense type
        # without making the debt coupon and management fee the same claim.
        identity = "SENIOR_MANAGEMENT"
        opening = state(claims=((identity, "0.40"),), senior_management_fee_arrears=D("0.10"))
        request = operating_request()
        request = replace(request, clo_opening_state=opening,
                          notes=(note(identity, rate="0.06"),),
                          cashflow_request=replace(request.cashflow_request,
                              issues=(DebtIssue(identity, D(80), D(100)),)))
        records = {
            schema.TABLE_RANGE_NAMES["clo_opening_accounts"]:
                tuple(dict(account=key, balance=D(0), source=SOURCE) for key in ACCOUNT_FIELDS),
            schema.TABLE_RANGE_NAMES["clo_opening_claims"]: (
                dict(claim_type="NOTE_COUPON", class_id=identity, amount=D("0.40"), source=SOURCE),
                *(dict(claim_type=key, class_id=None,
                       amount=D("0.10") if key == identity else D(0), source=SOURCE)
                  for key in FEE_FIELDS)),
        }

        class ClaimRecordAdapter:
            def table_records(self, range_name, table_name):
                return records[range_name]

        rows = opening_audit(ClaimRecordAdapter(), request)
        keys = [(row["category"], row["identifier"]) for row in rows]
        self.assertEqual(len(set(keys)), len(keys))
        self.assertEqual(sum(row["amount"] for row in rows if row["amount"] in {D("0.40"), D("0.10")}),
                         D("0.50"))

    def test_existing_accounts_and_unpaid_claims_conserve_actual_cash(self):
        opening = replace(state(claims=(("A", "1.20"),)),
                          principal_cash=D(5), interest_cash=D(2), reserve=D(3),
                          expense_arrears=D("0.50"),
                          senior_management_fee_arrears=D("0.40"),
                          subordinated_management_fee_arrears=D("0.30"))
        # A historic issue-date reserve7 is metadata. Current reserve3 is
        # already owned cash, not another closing use or automatic7 refund.
        terms = replace(operating_request().clo_terms, initial_reserve=D(7))
        result = TridentModelService().run(operating_request(opening=opening, terms=terms))
        period, = result.clo.periods
        tranche, = result.clo.tranche_periods
        self.assertEqual((period.opening_principal_cash, period.opening_interest_cash,
                          period.reserve_opening), (D(5), D(2), D(3)))
        self.assertEqual(period.senior_expenses_paid, D("0.50"))
        self.assertEqual(period.senior_management_fee_paid, D("0.40"))
        self.assertEqual(period.subordinated_management_fee_paid, D("0.30"))
        self.assertEqual(tranche.opening_coupon_arrears, D("1.20"))
        self.assertEqual(tranche.current_coupon_due, D("1.21"))
        self.assertEqual(period.note_coupon_paid, D("2.41"))
        self.assertEqual(period.debt_principal_from_principal, D(80))
        # Physical sources10 + loan103.03 =113.03; feeclaims1.20,
        # noteclaims2.41, face80 and equity29.42 consume exactly113.03.
        self.assertEqual(result.clo.total_equity_distributions, D("29.42"))
        self.assertEqual(period.cash_conservation_residual, D(0))
        self.assertEqual(period.reserve_release, D(3))
        self.assertEqual(result.clo.final_note_coupon_arrears, D(0))

    def test_initial_fee_basis_uses_original_par_instead_of_current_held_pool(self):
        opening = state(initial_collateral_par=D(200))
        terms = replace(operating_request().clo_terms,
                        management_fee_basis=ManagementFeeBasis.INITIAL_COLLATERAL_PAR,
                        senior_management_fee_bps=D(360))
        result = TridentModelService().run(operating_request(opening=opening, terms=terms))
        # Original200*.036*91/360=1.82; the current100 pool would give0.91.
        self.assertEqual(result.clo.periods[0].senior_management_fee_due, D("1.82"))
        self.assertEqual(result.clo.total_equity_distributions, D(20))

    def test_initial_fee_basis_requires_evidence_for_original_collateral_par(self):
        terms = replace(operating_request().clo_terms,
                        management_fee_basis=ManagementFeeBasis.INITIAL_COLLATERAL_PAR,
                        senior_management_fee_bps=D(360))
        with self.assertRaises(InputValidationError):
            TridentModelService().run(operating_request(terms=terms))

    def test_an_original_first_stub_override_is_not_reapplied_when_resuming(self):
        original, asof = date(2026, 1, 5), date(2026, 2, 5)
        second, final = date(2026, 5, 5), date(2026, 8, 5)
        opening = replace(state(), as_of_date=asof, interest_cash=D(2))
        terms = CloTerms(
            original, final, business_day_convention=BusinessDayConvention.UNADJUSTED,
            accrual_date_basis=AccrualDateBasis.UNADJUSTED,
            fixing_lag_business_days=0, stub_convention=StubConvention.SHORT_FIRST,
            first_payment_date_unadjusted=asof, first_stub_rate_override=D("0.08"),
        )
        floating = NoteTranche("A", 1, D(80), CouponType.FLOATING,
                               "EURIBOR_3M", D(100), day_count=DayCount.ACT_360)
        rows = (receipt(1, asof, second), receipt(2, second, final, principal="100"))
        request = CloRunRequest(rows, D(100), (floating,), terms, opening_state=opening)
        result = DeterministicCloEngine(FlatRateProvider({"EURIBOR_3M": D("0.025")})).run(request)
        self.assertEqual([row.period_number for row in result.periods], [2, 3])
        first, last = result.tranche_periods
        self.assertEqual(first.index_rate, D("0.025"))
        self.assertEqual(first.current_coupon_due, D("0.69"))  #80*.035*89/360
        self.assertEqual(last.current_coupon_due, D("0.72"))  #80*.035*92/360
        self.assertEqual(result.total_equity_distributions, D("20.59"))

    def test_first_forward_note_fixing_can_precede_the_opening_snapshot(self):
        class HistoricalRateControl:
            def __init__(self):
                self.calls = []

            def rate(self, index, fixing_date):
                self.calls.append((index, fixing_date))
                if fixing_date != date(2026, 3, 30):
                    raise AssertionError("The original retained period owns its actual lagged fixing")
                return D("0.02")

        provider = HistoricalRateControl()
        terms = CloTerms(ORIGINAL, NEXT,
                         business_day_convention=BusinessDayConvention.UNADJUSTED,
                         accrual_date_basis=AccrualDateBasis.UNADJUSTED,
                         fixing_lag_business_days=2)
        floating = NoteTranche("A", 1, D(80), CouponType.FLOATING,
                               "EURIBOR_3M", D(100), day_count=DayCount.ACT_360)
        request = CloRunRequest((receipt(1, OPEN, NEXT, principal="100", interest="2"),),
                                D(100), (floating,), terms, opening_state=state())
        result = DeterministicCloEngine(provider).run(request)
        self.assertEqual(provider.calls, [("EURIBOR_3M", date(2026, 3, 30))])
        self.assertEqual(result.tranche_periods[0].current_coupon_due, D("0.61"))
        self.assertEqual(result.total_equity_distributions, D("21.39"))

    def test_opening_pending_release_is_an_account_transfer_not_a_new_receipt(self):
        rows = (receipt(1, OPEN, NEXT), receipt(2, NEXT, FINAL, principal="100"))
        opening = state(pending_interest_cash=D(1), pending_principal_cash=D(4))
        result = core(rows, (note(),), opening, collection_cutoff_business_days=2)
        first, last = result.periods
        self.assertEqual((first.received_asset_interest, first.received_asset_principal),
                         (D(0), D(0)))
        self.assertEqual((first.eligible_asset_interest, first.eligible_asset_principal),
                         (D(1), D(4)))
        self.assertEqual(first.debt_principal_from_principal, D(4))
        self.assertEqual((first.pending_interest_cash, first.pending_principal_cash), (D(0), D(0)))
        self.assertEqual(last.debt_principal_from_principal, D(76))
        self.assertEqual(result.total_equity_distributions, D(25))
        self.assertTrue(all(row.cash_conservation_residual == 0 for row in result.periods))

    def test_historical_lifecycle_events_are_not_executed_again_after_opening(self):
        rows = (receipt(1, OPEN, NEXT, principal="100"),)
        for changes in (
                {"refinancing_enabled": True, "refinancing_date": OPEN},
                {"optional_call_enabled": True, "optional_call_date": OPEN}):
            with self.subTest(changes=changes), self.assertRaises(InputValidationError):
                core(rows, (note(),), legal_final=NEXT, **changes)

    def test_inactive_retained_class_has_no_own_test_or_reset_obligation(self):
        class NoRateForSettledClass:
            def rate(self, index, fixing_date):
                raise AssertionError("A zero-face zero-claim class has no rate-reset obligation")

        rows = (receipt(1, OPEN, NEXT), receipt(2, NEXT, FINAL, principal="100"))
        inactive = NoteTranche("B", 2, D(0), CouponType.FLOATING,
                              "EURIBOR_3M", D(100), oc_minimum=D(100), ic_minimum=D(100))
        terms = CloTerms(ORIGINAL, FINAL,
                         business_day_convention=BusinessDayConvention.UNADJUSTED,
                         accrual_date_basis=AccrualDateBasis.UNADJUSTED,
                         fixing_lag_business_days=0)
        request = CloRunRequest(rows, D(100), (note(), inactive), terms,
                                opening_state=state(claims=(("A", "0"), ("B", "0"))))
        result = DeterministicCloEngine(NoRateForSettledClass()).run(request)
        self.assertTrue(all(row.oc_status is CoverageStatus.NOT_APPLICABLE
                            and row.ic_status is CoverageStatus.NOT_APPLICABLE
                            for row in result.coverage_tests if row.class_id == "B"))
        self.assertTrue(all(row.index_rate is None and row.current_coupon_due == 0
                            for row in result.tranche_periods if row.class_id == "B"))

    def test_live_deferred_claim_enters_oc_but_reserve_does_not(self):
        rows = (receipt(1, OPEN, NEXT), receipt(2, NEXT, FINAL, principal="100"))
        notes = (note(oc_minimum=D(1)),
                 note("B", 2, "20", interest_deferrable=True, oc_minimum=D(1)))
        opening = replace(state(claims=(("A", "0"), ("B", "5"))),
                          principal_cash=D(10), reserve=D(999))
        result = core(rows, notes, opening)
        gate = next(row for row in result.coverage_tests
                    if row.period_number == 2 and row.class_id == "B" and row.stage == "GATE")
        #100 heldpar +10 permittedprincipal / (80+20face+5deferredclaim).
        self.assertEqual((gate.oc_numerator, gate.oc_denominator), (D(110), D(105)))
        self.assertIs(gate.oc_status, CoverageStatus.PASS)
        first_b = next(row for row in result.tranche_periods
                       if row.period_number == 2 and row.class_id == "B")
        self.assertEqual(first_b.closing_coupon_arrears, D(5))
        self.assertEqual(first_b.closing_balance, D(20))
        self.assertEqual(result.periods[0].reserve_closing, D(999))
        self.assertTrue(all(row.cash_conservation_residual == 0 for row in result.periods))

    def test_zero_face_live_deferred_claim_is_not_fabricated_as_discharged(self):
        rows = (receipt(1, OPEN, NEXT), receipt(2, NEXT, FINAL, principal="100"))
        notes = (note(par="0", interest_deferrable=True, oc_minimum=D(1)),)
        result = core(rows, notes, state(claims=(("A", "5"),)))
        gate = next(row for row in result.coverage_tests
                    if row.period_number == 2 and row.stage == "GATE")
        self.assertEqual(gate.oc_denominator, D(5))
        self.assertIs(gate.oc_status, CoverageStatus.PASS)
        self.assertEqual(result.tranche_periods[0].current_coupon_due, D(0))
        self.assertEqual(result.tranche_periods[0].closing_coupon_arrears, D(5))
        self.assertEqual(result.total_equity_distributions, D(95))
        self.assertEqual(result.final_note_coupon_arrears, D(0))

    def test_ic_live_claim_cannot_be_hidden_by_exclusion_from_oc(self):
        rows = (receipt(1, OPEN, NEXT), receipt(2, NEXT, FINAL, principal="100"))
        notes = (note(par="0", interest_deferrable=True, ic_minimum=D(1)),)
        result = core(rows, notes, state(claims=(("A", "5"),)),
                      include_deferred_interest_in_oc=False,
                      include_deferred_interest_in_ic=True)
        gate = next(row for row in result.coverage_tests
                    if row.period_number == 2 and row.stage == "GATE")
        self.assertEqual((gate.ic_numerator, gate.ic_denominator), (D(0), D(5)))
        self.assertIs(gate.ic_status, CoverageStatus.FAIL)

    def test_midperiod_opening_is_rejected_instead_of_restarting_schedule(self):
        rows = (receipt(1, date(2026, 4, 2), NEXT, principal="100"),)
        opening = replace(state(), as_of_date=date(2026, 4, 2))
        with self.assertRaises(InputValidationError):
            core(rows, (note(),), opening, legal_final=NEXT)

    def test_adjusted_payment_gap_is_rejected_without_backdated_accrual(self):
        original, asof, final = date(2026, 2, 2), date(2026, 5, 4), date(2026, 8, 2)
        # OriginalMay2 fallsSaturday and paysMondayMay4. Under unadjusted
        # accrual the following period beganMay2, so May4 is not the
        # unaccrued post-distribution profile promised by this increment.
        opening = replace(state(), as_of_date=asof)
        terms = CloTerms(original, final,
                         business_day_convention=BusinessDayConvention.FOLLOWING,
                         accrual_date_basis=AccrualDateBasis.UNADJUSTED,
                         fixing_lag_business_days=0)
        request = CloRunRequest((receipt(1, asof, final, principal="100"),),
                                D(100), (note(),), terms, opening_state=opening)
        with self.assertRaises(InputValidationError):
            DeterministicCloEngine(FlatRateProvider({"EURIBOR_3M": D("0.025")})).run(request)

    def test_every_retained_class_requires_its_own_explicit_unpaid_claim(self):
        terms = operating_request().clo_terms
        for claims in ((("A", "0"),), (("A", "0"), ("UNKNOWN", "0"))):
            with self.subTest(claims=claims), self.assertRaises(InputValidationError):
                CloRunRequest((receipt(1, OPEN, NEXT, principal="100"),), D(100),
                              (note(), note("B", 2, "20")), terms,
                              opening_state=state(claims=claims))

    def test_disjoint_principal_designations_never_create_extra_cash(self):
        with self.assertRaises(InputValidationError):
            replace(state(), principal_cash=D(5),
                    original_principal_reinvestment_cash=D(4), held_diversion_principal=D(2))

    def test_large_opening_reserve_preserves_independent_cents_in_small_context(self):
        opening = replace(state(), reserve=D("1000000000000000000000000.01"))
        with localcontext() as context:
            context.prec = 6
            result = core((receipt(1, OPEN, NEXT, principal="100", interest="0.01"),),
                          (note(par="80"),), opening, legal_final=NEXT)
        self.assertEqual(result.total_equity_distributions,
                         D("1000000000000000000000020.02"))
        self.assertEqual(result.periods[0].cash_conservation_residual, D(0))


if __name__ == "__main__":
    unittest.main()
