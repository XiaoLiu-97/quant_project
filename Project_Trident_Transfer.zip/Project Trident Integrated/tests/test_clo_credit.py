"""Independent credit-to-waterfall bridges, including default claims after final.

Tiny 100-par loans isolate recovery from performing collateral and from coupon
cash. These hand ledgers do not use the legacy workbook as the expected answer.
"""

import unittest
from dataclasses import replace
from datetime import date
from decimal import Decimal, localcontext

from trident.cashflows.engine import ContractualCashflowEngine
from trident.clo import (
    CloRunRequest, CloTerms, CoverageStatus, DefaultedAssetOcTreatment,
    DeterministicCloEngine, NoteTranche, ProjectionStatus,
)
from trident.conventions import AccrualDateBasis, BusinessDayConvention, DayCount
from trident.credit import CreditEventCashflowEngine, DefaultEvent, PrepaymentEvent, RecoveryEvent
from trident.domain.models import AmortizationType, CouponType, InputValidationError, LoanPosition, LoanTerms
from trident.market.rates import FlatRateProvider

D = Decimal
CLOSE = date(2026, 1, 20)
FIRST = date(2026, 4, 20)
DEFAULT = date(2026, 3, 5)  # 44 actual days from closing.
RECOVER = date(2026, 8, 20)
FINAL = date(2028, 1, 20)
PROVIDER = FlatRateProvider({"EURIBOR_3M": D("0.025")})


def position(**changes: object) -> LoanPosition:
    values = dict(
        loan_id="L", currency="EUR", start_date=CLOSE, maturity_date=date(2027, 1, 20),
        reference_principal=D(100), coupon_type=CouponType.FIXED, fixed_rate=D("0.04"),
        business_day_convention=BusinessDayConvention.UNADJUSTED,
        accrual_date_basis=AccrualDateBasis.UNADJUSTED, day_count=DayCount.ACT_360,
    )
    values.update(changes)
    return LoanPosition(LoanTerms(**values), CLOSE, D(100))


def request(event, *, held=None, policy=DefaultedAssetOcTreatment.EXCLUDE, final=FINAL, **terms):
    held = held or position()
    original = ContractualCashflowEngine(PROVIDER).generate(held)
    credit = CreditEventCashflowEngine(PROVIDER).apply(held, original, event)
    return CloRunRequest(original, D(100), (NoteTranche("A", 1, D(60), CouponType.FIXED,
                         fixed_rate=D(0), oc_minimum=D(1)),),
                         CloTerms(CLOSE, final, business_day_convention=BusinessDayConvention.UNADJUSTED,
                                  accrual_date_basis=AccrualDateBasis.UNADJUSTED,
                                  defaulted_asset_oc_treatment=policy, **terms), (credit,))


class CreditCloBridgeTests(unittest.TestCase):
    def run_model(self, event, **kwargs):
        return DeterministicCloEngine(PROVIDER).run(request(event, **kwargs))

    def test_default_then_eighty_recovery_redeems_sixty_without_restoring_par(self):
        event = DefaultEvent("L", DEFAULT, (RecoveryEvent(RECOVER, D("0.8")),), RECOVER)
        result = self.run_model(event)
        self.assertIs(result.status, ProjectionStatus.COMPLETED)
        self.assertEqual(len(result.periods), 3)
        first, last = result.periods[0], result.periods[-1]
        self.assertEqual((first.closing_collateral_par, first.defaulted_par, first.newly_defaulted_par), (0, 100, 100))
        self.assertEqual(first.received_asset_interest, 0)
        gate = next(row for row in result.coverage_tests if row.stage == "GATE")
        self.assertEqual(gate.oc_numerator, 0)
        self.assertIs(gate.oc_status, CoverageStatus.FAIL)
        self.assertEqual((last.recovery_principal_received, last.recognized_par_loss), (80, 20))
        self.assertEqual((last.closing_collateral_par, last.defaulted_par, last.closing_debt_par), (0, 0, 0))
        self.assertEqual(last.equity_from_principal, 20)
        self.assertEqual(result.total_recovery_collections, 80)
        self.assertEqual(result.total_recognized_par_loss, 20)
        self.assertTrue(all(row.cash_conservation_residual == 0 for row in result.periods))

    def test_zero_recovery_writeoff_clears_claim_but_never_assumes_debt_liquidation(self):
        result = self.run_model(DefaultEvent("L", DEFAULT, writeoff_date=DEFAULT))
        self.assertIs(result.status, ProjectionStatus.LEGAL_FINAL_UNRESOLVED)
        self.assertEqual((result.final_collateral_par, result.final_defaulted_par, result.final_debt_par), (0, 0, 60))
        self.assertEqual(result.total_recognized_par_loss, 100)
        self.assertEqual(result.total_equity_distributions, 0)
        self.assertFalse(result.terminal_value_available)

    def test_partial_recovery_without_explicit_writeoff_retains_twenty_claim(self):
        event = DefaultEvent("L", DEFAULT, (RecoveryEvent(RECOVER, D("0.8")),))
        result = self.run_model(event, initial_reserve=D(1))
        self.assertIs(result.status, ProjectionStatus.LEGAL_FINAL_UNRESOLVED)
        self.assertEqual((result.final_collateral_par, result.final_defaulted_par), (0, 20))
        self.assertEqual(result.final_reserve, 1)
        self.assertEqual(result.total_recognized_par_loss, 0)
        self.assertFalse(result.terminal_value_available)

    def test_recovery_after_legal_final_stays_in_claim_and_does_not_create_cash(self):
        late = date(2029, 1, 20)
        result = self.run_model(DefaultEvent("L", DEFAULT, (RecoveryEvent(late, D("0.8")),), late))
        self.assertIs(result.status, ProjectionStatus.LEGAL_FINAL_UNRESOLVED)
        self.assertEqual((result.final_defaulted_par, result.total_recovery_collections, result.total_recognized_par_loss), (100, 0, 0))
        self.assertEqual(result.periods[-1].payment_date, FINAL)

    def test_actual_same_day_scheduled_principal_precedes_remaining_par_default(self):
        held = position(amortization_type=AmortizationType.LINEAR_AMOUNT, scheduled_principal_amount=D(25))
        event = DefaultEvent("L", FIRST, (RecoveryEvent(RECOVER, D("0.8")),), RECOVER)
        result = self.run_model(event, held=held)
        self.assertEqual((result.periods[0].scheduled_principal_received, result.periods[0].newly_defaulted_par), (25, 75))
        self.assertEqual(result.periods[0].received_asset_interest, 1)
        self.assertEqual((result.total_defaulted_exposure, result.total_recovery_collections, result.total_recognized_par_loss), (75, 60, 15))
        self.assertEqual(sum(p.scheduled_principal_received + p.prepayment_principal_received + p.recovery_principal_received + p.recognized_par_loss for p in result.periods), 100)

    def test_midperiod_prepayment_posts_fortyfour_days_coupon_once(self):
        result = self.run_model(PrepaymentEvent("L", DEFAULT), policy=None)
        first = result.periods[0]
        self.assertIs(result.status, ProjectionStatus.COMPLETED)
        self.assertEqual(len(result.periods), 1)
        self.assertEqual((first.prepayment_principal_received, first.received_asset_interest), (100, D("0.49")))
        self.assertEqual((first.scheduled_principal_received, first.recovery_principal_received, first.defaulted_par), (0, 0, 0))
        self.assertEqual(result.total_equity_distributions, D("40.49"))

    def test_post_cutoff_recovery_is_pending_cash_and_not_performing_par(self):
        event = DefaultEvent("L", DEFAULT, (RecoveryEvent(FIRST, D(1)),))
        result = self.run_model(event, collection_cutoff_business_days=1)
        first, second = result.periods
        self.assertEqual((first.closing_collateral_par, first.defaulted_par), (0, 0))
        self.assertEqual((first.recovery_principal_received, first.pending_principal_cash, first.debt_principal_from_principal), (100, 100, 0))
        self.assertEqual(second.recovery_principal_received, 0)
        self.assertEqual((second.eligible_asset_principal, second.debt_principal_from_principal), (100, 60))

    def test_fee_par_days_stop_at_default_even_before_recovery(self):
        event = DefaultEvent("L", DEFAULT, (RecoveryEvent(RECOVER, D(1)),))
        result = self.run_model(event, senior_management_fee_bps=D(100), initial_reserve=D(1))
        self.assertEqual(result.periods[0].senior_management_fee_due, D("0.12"))
        self.assertTrue(all(row.senior_management_fee_due == 0 for row in result.periods[1:]))
        self.assertEqual(result.final_reserve, 0)
        self.assertEqual(result.total_equity_distributions, D("40.88"))

    def test_default_requires_explicit_oc_treatment(self):
        with self.assertRaisesRegex(InputValidationError, "explicit defaulted_asset_oc_treatment"):
            request(DefaultEvent("L", DEFAULT), policy=None)

    def test_truncated_credit_queue_cannot_be_given_to_clo(self):
        event = DefaultEvent("L", DEFAULT, (RecoveryEvent(RECOVER, D("0.8")),), RECOVER)
        complete = request(event)
        short = CreditEventCashflowEngine(PROVIDER).apply(position(), complete.asset_cashflows, event, horizon_date=FIRST)
        with self.assertRaisesRegex(InputValidationError, "complete credit horizon"):
            DeterministicCloEngine(PROVIDER).run(replace(complete, asset_credit_projections=(short,)))

    def test_credit_projection_coverage_cannot_omit_an_original_loan(self):
        complete = request(PrepaymentEvent("L", DEFAULT))
        second = tuple(replace(row, loan_id="OTHER") for row in complete.asset_cashflows)
        with self.assertRaisesRegex(InputValidationError, "every original loan"):
            DeterministicCloEngine(PROVIDER).run(replace(complete, asset_cashflows=complete.asset_cashflows + second,
                                                       opening_collateral_par=D(200)))

    def test_credit_waterfall_is_independent_of_host_decimal_precision(self):
        event = DefaultEvent("L", DEFAULT, (RecoveryEvent(RECOVER, D("0.8")),), RECOVER)
        expected = self.run_model(event)
        with localcontext() as context:
            context.prec = 2
            actual = self.run_model(event)
        self.assertEqual(actual, expected)

    def test_full_contract_reference_without_credit_has_unchanged_collections(self):
        complete = request(None, policy=None)
        overlaid = DeterministicCloEngine(PROVIDER).run(complete)
        plain = DeterministicCloEngine(PROVIDER).run(replace(complete, asset_credit_projections=()))
        self.assertEqual(overlaid, plain)

    def test_explicit_future_resolution_date_is_binding_after_full_recovery(self):
        # Conservative scenario policy: every supplied dated operation is
        # processed, even if its final write-off happens to have zero effect.
        event = DefaultEvent("L", DEFAULT, (RecoveryEvent(FIRST, D(1)),), RECOVER)
        result = self.run_model(event, initial_reserve=D(1))
        self.assertEqual(result.periods[0].defaulted_par, 0)
        self.assertEqual(result.periods[0].reserve_release, 0)
        self.assertEqual(result.periods[-1].reserve_release, 1)
        self.assertEqual(len(result.periods), 3)


if __name__ == "__main__":
    unittest.main()
