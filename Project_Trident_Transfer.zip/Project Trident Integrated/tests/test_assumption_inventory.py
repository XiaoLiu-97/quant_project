"""Full legacy inventory and semantic validation, including source-DV defects."""

from datetime import date
from decimal import Decimal
import unittest

from trident.adapters.legacy_inputs import (
    LEGACY_ASSUMPTIONS, LEGACY_INPUTS, LEGACY_DERIVED, LEGACY_INPUT_BY_ID,
    LEGACY_BY_SOURCE, validate_legacy_controls, validate_pricing_date,
)
from trident.domain.models import InputValidationError


class LegacyInputsTests(unittest.TestCase):
    def test_complete_unique_editable_inventory(self):
        self.assertEqual((len(LEGACY_ASSUMPTIONS), len(LEGACY_INPUTS), len(LEGACY_DERIVED)), (110, 107, 3))
        self.assertEqual(len(LEGACY_INPUT_BY_ID), 107)
        self.assertEqual({item.source_coordinate for item in LEGACY_DERIVED}, {"B33", "B53", "B54"})

    def test_all_reference_defaults_parse(self):
        result = validate_legacy_controls({item.field_id: item.default_value for item in LEGACY_INPUTS})
        self.assertEqual(result["pricing_date"], date(2026, 8, 4))
        self.assertEqual(result["original_annual_default_rate"], Decimal("0.02"))
        self.assertEqual(result["reinvestment_annual_default_rate"], Decimal("0.02"))
        with self.assertRaises(TypeError):
            result["pricing_date"] = date(2027, 1, 1)

    def test_misplaced_data_validation_is_evidence_not_semantic_choices(self):
        expense = LEGACY_BY_SOURCE["B26"]
        self.assertEqual(expense.semantic_type, "MONEY")
        self.assertIn('"Enabled,Disabled"', expense.source_validation_formulas)
        lag = LEGACY_BY_SOURCE["B93"]
        self.assertEqual(lag.semantic_type, "INTEGER")
        self.assertIn('"TARGET,Weekends Only"', lag.source_validation_formulas)

    def test_reinvestment_gate_source_and_vba_alias(self):
        for gate in ("Continue", "Always Reinvest"):
            result = validate_legacy_controls({"reinvestment_test_gate": gate}, require_complete=False)
            self.assertEqual(result["reinvestment_test_gate"], "Continue")

    def test_missing_and_unknown_are_rejected(self):
        for values in ({}, {"B6": date(2026, 1, 1)}):
            with self.assertRaises(InputValidationError):
                validate_legacy_controls(values)

    def test_semantic_fraction_money_and_integer_ranges(self):
        for values in ({"ccc_fraction": "1.01"}, {"trustee_paying_agent_administrator": "0.001"},
                       {"rate_fixing_lag": "2.5"}, {"original_recovery_lag_months": -1},
                       {"base_currency": "AUD"}, {"cash_account_spread": True},
                       {"collateral_purchase_price": 0}):
            with self.subTest(values=values), self.assertRaises(InputValidationError):
                validate_legacy_controls(values, require_complete=False)
        self.assertEqual(validate_legacy_controls({"liability_reference_floor": "-0.005"}, require_complete=False)["liability_reference_floor"], Decimal("-0.005"))

    def test_supported_currency_choices_remain_available_to_mode_validation(self):
        # Standalone contractual runs support USD/GBP as well as EUR. The
        # schema must preserve those choices; the CLO application separately
        # enforces its EUR-only waterfall rather than banning valid input here.
        for currency in ("EUR", "USD", "GBP"):
            with self.subTest(currency=currency):
                result = validate_legacy_controls({"base_currency": currency}, require_complete=False)
                self.assertEqual(result["base_currency"], currency)

    def test_pricing_and_closing_snapshot(self):
        self.assertEqual(validate_pricing_date(date(2026, 1, 1), date(2026, 1, 1), date(2027, 1, 1)), date(2026, 1, 1))
        for args in ((date(2026, 1, 1), date(2026, 1, 2), date(2027, 1, 1)),
                     (date(2027, 1, 1), date(2027, 1, 1), date(2026, 1, 1))):
            with self.assertRaises(InputValidationError):
                validate_pricing_date(*args)

    def test_disabled_event_date_does_not_override_active_deal(self):
        values = {"optional_call_enabled": "No", "call_date": date(2025, 1, 1), "closing_date": date(2027, 1, 1)}
        self.assertEqual(validate_legacy_controls(values, require_complete=False)["call_date"], date(2025, 1, 1))
        values["optional_call_enabled"] = "Yes"
        with self.assertRaises(InputValidationError):
            validate_legacy_controls(values, require_complete=False)

    def test_enabled_partial_event_missing_date_is_domain_error(self):
        with self.assertRaisesRegex(InputValidationError, "requires call_date"):
            validate_legacy_controls({"optional_call_enabled": "Yes", "maturity_date": date(2030, 1, 1)}, require_complete=False)

    def test_equity_irr_hurdle_range_checked_even_when_incentive_disabled(self):
        for hurdle in ("-0.01", "1.0000000000000000000000000001"):
            with self.subTest(hurdle=hurdle), self.assertRaisesRegex(InputValidationError, "equity_irr_hurdle"):
                validate_legacy_controls({"incentive_management_fee_enabled": "No", "equity_irr_hurdle": hurdle}, require_complete=False)
        for hurdle in ("0", "1"):
            self.assertEqual(validate_legacy_controls({"equity_irr_hurdle": hurdle}, require_complete=False)["equity_irr_hurdle"], Decimal(hurdle))
