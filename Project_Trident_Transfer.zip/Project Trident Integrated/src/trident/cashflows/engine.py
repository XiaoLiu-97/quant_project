"""Compose contractual dates, coupon economics and a principal strategy.

This layer projects promised cash, without default, trading or CLO priorities.
Credit engines consume the immutable reference and produce separate receipts;
they do not overwrite contractual rows. Date conventions belong to schedule
construction, rates to the injected provider, and amortization to a principal
policy, so each concern can be reviewed and extended independently.
"""

from decimal import Context, Decimal, ROUND_HALF_EVEN, localcontext
from fractions import Fraction

from trident.conventions.calendar import BusinessCalendar, TargetCalendar, calendar_from_name
from trident.conventions.schedule import ScheduleBuilder
from trident.domain.models import AmortizationType, InterestMode, InputValidationError, LoanCashflow, LoanPosition
from trident.domain.numeric import decimal_fraction, post_currency
from trident.market.rates import RateProvider
from .principal import build_principal_policy
from .seasoned import build_position_coupon_projector, build_position_schedule, opening_coupon_claim_exact


class ContractualCashflowEngine:
    """Combine shared schedule/rate conventions and an explicit principal rule.

    Cash amounts post per loan/per payment using cent precision and HALF_UP.
    Interest accrues on opening balance before same-day principal repayment.
    PIK is explicit contractual capitalization, distinct from unpaid cash claims.
    Scheduled principal is effective on accrual end; payment lag moves settlement
    without extending coupon accrual or delaying the next principal balance.
    """

    def __init__(self, rate_provider: RateProvider, calendar: BusinessCalendar | None = None) -> None:
        self._rate_provider = rate_provider
        self._calendar_override = calendar
        self._schedule = ScheduleBuilder(calendar or TargetCalendar())

    def generate(self, position: LoanPosition) -> tuple[LoanCashflow, ...]:
        """Return one held loan's promised payments, with exact par conservation.

        The calendar builds cash dates first; intersected reset segments retain
        original fixings and exact DCFs, post coupon once, then apply principal. Bullet
        and scheduled loans need only rates until their actual payoff. Projected
        annuities need every future factor up front to solve a level payment;
        they remain a disclosed projection rule rather than a floating recast.
        Currency is posted once per economic coupon or principal amount. The
        unrounded interest/DCF and weighted rates are diagnostics, never monetary
        inputs. Frozen segments retain exact rate digits for credit replay.
        """
        if not isinstance(position, LoanPosition):
            raise TypeError("position must be LoanPosition")
        terms = position.terms
        # A caller-injected custom calendar retains API precedence. Otherwise
        # each contract resolves its own named market calendar, so a bulk book
        # can contain EUR, USD and GBP instruments without a shared default.
        calendar = self._calendar_override or calendar_from_name(terms.holiday_calendar)
        schedule = build_position_schedule(position, calendar)
        periods = schedule.projection_periods
        coupons = build_position_coupon_projector(position, schedule, calendar, self._rate_provider)
        opening_exact = opening_coupon_claim_exact(position, schedule, coupons)
        rows: list[LoanCashflow] = []
        balance = position.opening_balance
        with localcontext(Context(prec=max(34, terms.reference_principal.adjusted() + 34), rounding=ROUND_HALF_EVEN)):
            projected = (
                tuple(coupons.project(period) for period in periods)
                if terms.amortization_type is AmortizationType.ANNUITY else None
            )
            policy = build_principal_policy(
                position, schedule.contractual_periods,
                tuple(coupon.exact_factor for coupon in projected)
                if projected is not None else None,
            )
            for period_index, period in enumerate(periods):
                if balance == 0:
                    break
                coupon = projected[period_index] if projected is not None else coupons.project(period)
                # The dated slice earns only post-as-of coupon. Its explicit
                # retained historical claim is added exactly once, at the first
                # remaining payment, before the single monetary posting.
                opening_claim = (position.seasoned_state.opening_accrued_interest
                    if position.seasoned_state is not None and period_index == 0 else Decimal(0))
                first_claim_exact = opening_exact if period_index == 0 else Fraction()
                earned_interest = Fraction(balance) * coupon.exact_factor
                # Explicit seasoned cash claims remain cash: capitalizing a
                # historical agent-verified cash claim would change ownership.
                # New PIK entitlement is calculated only on forward accrual.
                exact_interest = earned_interest + first_claim_exact
                # Keep multiplication rational until the single cent posting.
                # Reusing a rounded/display DCF can change a half-cent coupon.
                dcf = decimal_fraction(coupon.exact_dcf)
                gross = decimal_fraction(exact_interest)
                gross_posted = post_currency(exact_interest)
                exact_pik = earned_interest * Fraction(terms.pik_fraction)
                if exact_pik < 0:
                    raise InputValidationError("A negative coupon cannot create negative PIK principal; use CASH or an explicit contract profile")
                pik = post_currency(exact_pik)
                # Post the total coupon and its capitalized component once;
                # the cash residual reconciles gross exactly even at cent ties.
                interest = post_currency(Fraction(gross_posted) - Fraction(pik))
                original_index = schedule.original_indices[period_index]
                final = original_index == len(schedule.contractual_periods) - 1
                # The source contract computes interim scheduled principal on
                # opening face, then capitalizes PIK. At final redemption we
                # capitalize and repay the enlarged face on the same date so
                # both cash and par identities hold (including current PIK).
                principal = (post_currency(Fraction(balance) + Fraction(pik))
                    if final and terms.interest_mode is not InterestMode.CASH
                    else policy.repayment(original_index, balance, interest))
                if not Decimal(0) <= principal <= post_currency(Fraction(balance) + Fraction(pik)):
                    raise ArithmeticError(f"Principal policy violated outstanding par: {terms.loan_id}")
                ending = post_currency(Fraction(balance) + Fraction(pik) - Fraction(principal))
                rows.append(LoanCashflow(
                    loan_id=terms.loan_id, currency=terms.currency, period_number=period.period_number,
                    unadjusted_start=period.unadjusted_start, unadjusted_end=period.unadjusted_end,
                    accrual_start=period.accrual_start, accrual_end=period.accrual_end,
                    payment_date=period.payment_date, fixing_date=coupon.fixing_date, opening_balance=balance,
                    index_rate=coupon.index_rate, spread_bps=coupon.spread_bps, all_in_rate=coupon.all_in_rate,
                    day_count_fraction=dcf, interest_unrounded=gross, cash_interest=interest,
                    principal_repayment=principal, closing_balance=ending,
                    total_cash=post_currency(Fraction(interest) + Fraction(principal)),
                    coupon_segments=coupon.segments,
                    opening_accrued_interest=opening_claim,
                    opening_accrued_exact=first_claim_exact,
                    pik_interest=pik, interest_mode=terms.interest_mode,
                    pik_fraction=terms.pik_fraction,
                ))
                balance = ending
            if sum((Fraction(row.principal_repayment) - Fraction(row.pik_interest)
                    for row in rows), Fraction()) != Fraction(position.opening_balance):
                raise ArithmeticError(f"Principal conservation failed: {terms.loan_id}")
        return tuple(rows)
