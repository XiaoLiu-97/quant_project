"""Operational checks and explicit benchmark reconciliation for Excel users.

This boundary assembles typed inputs and calculated evidence. It never treats
an installation check, a matching subset of benchmarks, or a solver status as
legal approval. Read-only inspection uses an in-memory workbook and discards
all additions; normal execution publishes through the existing atomic saver.
"""

from datetime import date, datetime, time
from decimal import Decimal
from enum import Enum
from fractions import Fraction
from hashlib import sha256
import json
from pathlib import Path

from trident import __version__
from trident.domain.models import InputValidationError, OpeningFixing, OpeningCouponEntitlement, SeasonedLoanState
from trident.domain.numeric import post_currency
from trident.validation import (BenchmarkRecord, ObservedMetric, ReconciliationKey,
                                ReconciliationService, index_observations)
from . import excel_schema as schema, pilot_schema
from .records import date_value, decimal_value, text_value


def ensure_pilot_interface(adapter) -> None:
    """Install dedicated optional named tables without touching prior inputs."""
    from openpyxl.styles import Alignment, Font
    for key, (title, columns) in pilot_schema.DESCRIPTORS.items():
        is_input = key in pilot_schema.INPUT_TABLES
        choices = {'scope': ('ASSET', 'CANDIDATE'),
                   'timing': ('POST_DISTRIBUTION',), 'use_ledger_snapshot': ('TRUE', 'FALSE'),
                   'account': ('PRINCIPAL', 'INTEREST', 'RESERVE', 'PENDING_PRINCIPAL', 'PENDING_INTEREST',
                       'ORIGINAL_PRINCIPAL_REINVESTMENT', 'PENDING_ORIGINAL_PRINCIPAL_REINVESTMENT', 'HELD_DIVERSION'),
                   'claim_type': ('NOTE_COUPON', 'SENIOR_EXPENSES', 'SENIOR_MANAGEMENT',
                       'SUBORDINATED_MANAGEMENT', 'DEFERRED_SENIOR_EXPENSES'),
                    'entitlement_policy': tuple(item.value for item in OpeningCouponEntitlement),
                    'collection_source': ('SCHEDULED', 'PREPAYMENT'),
                    'original_principal_permission': ('TRUE', 'FALSE'),
                   'side': ('BUY', 'SELL'), 'accrued_account': ('PRINCIPAL', 'INTEREST'),
                   'fee_account': ('PRINCIPAL', 'INTEREST')}
        created = adapter.ensure_optional_table(schema.TABLE_RANGE_NAMES[key], schema.TABLE_NAMES[key], columns,
            sheet_title=title, title=title,
            instruction=pilot_schema.INSTRUCTIONS.get(key, 'Calculated review evidence; do not edit. Read statuses and declared scope before using results.'),
            before_sheet='Guidance', auto_expand=True,
            number_formats=pilot_schema.formats(columns),
            list_options={field: options for field, options in choices.items() if field in columns and is_input})
        if created:
            sheet, (left, top, right, bottom) = adapter.region(schema.TABLE_RANGE_NAMES[key])
            # These are new dedicated interfaces, so establish a usable body
            # template once. write_table extends its default components later
            # without restyling any existing/user-formatted table or row.
            body_height = {'run_audit': 90, 'readiness_findings': 60,
                           'clo_opening_audit': 54, 'coupon_proceeds_audit': 54}.get(key, 32)
            for cells in sheet.iter_rows(min_row=top + 1, max_row=bottom, min_col=left, max_col=right):
                for cell in cells:
                    cell.font = Font(name='Arial', size=10, color='0000FF' if is_input else '000000')
                    cell.alignment = Alignment(wrap_text=True, vertical='center')
                sheet.row_dimensions[cells[0].row].height = body_height
        if created and (key.startswith('clo_opening') or key in {
                'principal_accrued_balances', 'coupon_proceeds_allocations', 'coupon_proceeds_audit'}):
            from openpyxl.utils import get_column_letter
            sheet, (left, top, right, _) = adapter.region(schema.TABLE_RANGE_NAMES[key])
            widths = {'account': 44, 'claim_type': 36, 'identifier': 42, 'source': 38,
                       'equity_value_source': 38, 'message': 78, 'timing': 28, 'category': 28,
                       'loan_id': 30, 'allocation_id': 32, 'collection_source': 26,
                       'original_principal_permission': 30, 'legal_reference': 52,
                       'balance_source': 38, 'allocation_source': 38}
            for offset, field in enumerate(columns):
                sheet.column_dimensions[get_column_letter(left + offset)].width = widths.get(field, 24)
                sheet.cell(top, left + offset).alignment = Alignment(wrap_text=True, vertical='center')
            sheet.row_dimensions[top].height = 32


def seasoned_states_from_records(states, fixings, assets, *, scope='ASSET'):
    """Bind explicit entitlement/history to identified contracts, never prices.

    ASSET and CANDIDATE are independent namespaces. An orphan fixing, duplicate
    state or an unrecognized scope cannot be hidden by a disabled search.
    """
    known = {text_value(row.get('loan_id'), 'loan_id') for row in assets}
    selected, grouped = {}, {}
    for row in states:
        namespace = text_value(row.get('scope'), 'seasoned scope')
        if namespace not in {'ASSET', 'CANDIDATE'}:
            raise InputValidationError('Seasoned scope must be ASSET or CANDIDATE')
        if namespace != scope:
            continue
        identity = text_value(row.get('loan_id'), 'seasoned loan_id')
        if identity not in known or identity in selected:
            raise InputValidationError('Seasoned state must identify one unique known loan: ' + identity)
        selected[identity] = (decimal_value(row.get('opening_accrued_interest'), 'opening accrued entitlement'),
                              text_value(row.get('source'), 'opening entitlement source'),
                              OpeningCouponEntitlement(text_value(row.get('entitlement_policy'), 'entitlement policy')))
    for row in fixings:
        namespace = text_value(row.get('scope'), 'fixing scope')
        if namespace not in {'ASSET', 'CANDIDATE'}:
            raise InputValidationError('Opening fixing scope must be ASSET or CANDIDATE')
        if namespace != scope:
            continue
        identity = text_value(row.get('loan_id'), 'opening fixing loan_id')
        if identity not in selected:
            raise InputValidationError('Opening fixing has no explicit seasoned state: ' + identity)
        grouped.setdefault(identity, []).append(OpeningFixing(
            date_value(row.get('fixing_date'), 'opening fixing date'),
            decimal_value(row.get('index_rate'), 'opening index rate')))
    return {identity: SeasonedLoanState(amount, source, tuple(sorted(grouped.get(identity, ()),
                key=lambda item: item.fixing_date)), policy) for identity, (amount, source, policy) in selected.items()}


def input_fingerprint(adapter) -> str:
    """Hash semantic saved inputs; ignore blank padding and sheet positions.

    Optional blank columns can be added without changing economics. All filled
    fields, including disabled-case inputs, are retained conservatively. Rates
    and amounts use decimal text, avoiding binary-float repr inconsistencies.
    This detects saved input changes when checked; Excel does not run Python
    on an unsaved edit and cannot promise immediate stale marking.
    """
    def normalize(value):
        if value is None or value == '':
            return None
        if isinstance(value, bool):
            return {'boolean': value}
        if isinstance(value, datetime) and value.time() == time():
            # Excel reloads calendar dates as midnight datetimes. The saved
            # economic date is unchanged by that transport representation.
            return {'date': value.date().isoformat()}
        if isinstance(value, (date, datetime)):
            return {'date': value.isoformat()}
        if isinstance(value, (int, float, Decimal)):
            number = Decimal(str(value))
            if not number.is_finite():
                raise InputValidationError('Fingerprint inputs must be finite numbers')
            if number.is_zero():
                return {'number': '0'}
            # Canonicalize without Decimal.normalize(), which can round under
            # a caller's ambient context. 100, 100.0 and 1E2 are one value.
            sign, digits, exponent = number.as_tuple()
            digits = list(digits)
            while digits[-1] == 0:
                digits.pop()
                exponent += 1
            return {'number': ('-' if sign else '') + ''.join(map(str, digits)) + 'e' + str(exponent)}
        return {'text': str(value)}
    payload = {'scalars': {key: normalize(adapter.scalar(schema.SCALAR_NAMES[key]))
                          for key in schema.READ_INPUT_KEYS}, 'tables': {}, 'curves': {}}
    for key in schema.INPUT_TABLE_KEYS:
        rows = adapter.table_records(schema.TABLE_RANGE_NAMES[key], schema.TABLE_NAMES[key])
        payload['tables'][key] = [{field: normalize(value) for field, value in row.items()
                                 if value is not None and value != ''} for row in rows]
    for block in schema.CURVE_BLOCKS:
        sheet, (left, top, right, bottom) = adapter.region(block.range_name)
        payload['curves'][block.range_name] = [[normalize(sheet.cell(row, col).value)
            for col in range(left, right + 1)] for row in range(top, bottom + 1)]
    return sha256(json.dumps(payload, sort_keys=True, ensure_ascii=False,
                              separators=(',', ':')).encode('utf-8')).hexdigest()


def benchmark_records(rows):
    """Expected values are independent inputs; never populate from actuals."""
    benchmarks = tuple(BenchmarkRecord(ReconciliationKey(
        date_value(row.get('observation_date'), 'benchmark date'),
        text_value(row.get('entity_type'), 'entity_type'), text_value(row.get('entity_id'), 'entity_id'),
        text_value(row.get('metric'), 'metric'), text_value(row.get('stage'), 'stage')),
        decimal_value(row.get('expected'), 'expected'), decimal_value(row.get('tolerance'), 'tolerance'),
        text_value(row.get('unit'), 'unit'), text_value(row.get('source'), 'benchmark source'),
        text_value(row.get('reference_id'), 'benchmark reference_id')) for row in rows)
    if len({item.key for item in benchmarks}) != len(benchmarks):
        raise InputValidationError('Benchmark keys must be unique')
    return benchmarks


def observed_catalog(result, tables, values):
    """Index promised cash, waterfall cash and tests in distinct namespaces.

    Every numeric key has an explicit unit and stage. Actual stressed receipts
    remain separate from contractual schedules; a trustee cash benchmark must
    use ASSET_COLLECTION rather than an unreceived contractual coupon.
    """
    pairs = []
    def add(day, kind, identity, metric, stage, value, unit, message=''):
        if isinstance(value, bool) or value is not None and not isinstance(value, (Decimal, int)):
            return
        pairs.append((ReconciliationKey(day, kind, identity, metric, stage),
                      ObservedMetric(None if value is None else Decimal(value), unit,
                                     (message or 'Not available in this projection') if value is None else '')))
    day = result.cashflows.projection_start_date
    for row in tables.get('clo_opening_audit', ()):
        add(day, 'CLO_OPENING', row['identifier'], row['category'], 'POST_DISTRIBUTION',
            row['amount'], row['unit'])
    for key, value in values.items():
        if value is None and key not in {'result_equity_irr', 'result_equity_moic', 'result_equity_distributions',
                'result_final_debt_par', 'result_was_bps', 'result_wal_years', 'result_warf', 'result_test_factor', 'result_wac_rate'}:
            continue
        if key.endswith('_count') or key in {'result_asset_count', 'result_opening_limit_breaches'}:
            unit = 'COUNT'
        elif key.endswith('_bps'):
            unit = 'BPS'
        elif key.endswith('_years'):
            unit = 'YEARS'
        elif key in {'result_equity_irr', 'result_wac_rate'}:
            unit = 'FRACTION'
        elif key in {'result_equity_moic', 'result_warf', 'result_test_factor'}:
            unit = 'MULTIPLE' if key.endswith('moic') else 'FACTOR'
        else:
            unit = result.cashflows.currency
        add(day, 'SCALAR', 'DEAL', key, 'BASELINE', value, unit)
    specifications = (
        ('asset_cashflows', 'ASSET_CONTRACT', 'loan_id', 'CONTRACTUAL'),
        ('tranche_cashflows', 'TRANCHE', 'class_id', 'WATERFALL'),
        ('coverage_tests', 'COVERAGE', 'class_id', None),
        ('clo_periods', 'ACCOUNT', None, 'PERIOD_END'),
    )
    for table_key, kind, identity_key, default_stage in specifications:
        # Business-day adjustment can put distinct nominal periods on one
        # receipt date. Keep each balance/rate/cash row's identity; summing
        # arbitrary metrics would corrupt balances and coverage ratios.
        periods_by_key = {}
        for row in tables[table_key]:
            base_key = (row['payment_date'], 'DEAL' if identity_key is None else row[identity_key],
                        default_stage or str(row['stage']))
            periods_by_key.setdefault(base_key, set()).add(row.get('period_number'))
        for row in tables[table_key]:
            identity = 'DEAL' if identity_key is None else row[identity_key]
            stage = default_stage or str(row['stage'])
            if len(periods_by_key[(row['payment_date'], identity, stage)]) > 1:
                stage += ':PERIOD_' + str(row['period_number'])
            for metric, value in row.items():
                if metric in {'period_number', 'payment_priority'} or metric.endswith('_date'):
                    continue
                # Financial dimensions belong to the registered observation,
                # not to the Python numeric type. A GBP standalone coupon must
                # reconcile in GBP; a PIK settlement share is dimensionless;
                # face-time exposures carry currency multiplied by ACT/365F
                # years and must not masquerade as a monetary balance.
                unit = ('BPS' if metric == 'spread_bps' else 'MULTIPLE' if metric.endswith(('_ratio', '_minimum'))
                        else 'FRACTION' if metric in {'index_rate', 'all_in_rate', 'day_count_fraction',
                                                     'cash_account_all_in_rate', 'pik_fraction', 'pik_rate_fraction'}
                        else result.cashflows.currency + '_YEARS_ACT365F' if metric in {
                            'original_performing_par_years', 'reinvestment_performing_par_years', 'debt_face_par_years'}
                        else result.cashflows.currency)
                add(row['payment_date'], kind, identity, metric, stage, value, unit)
    # Portfolio metrics already carry canonical calculation units and missing
    # data explanations. Preserve those definitions rather than guessing.
    for row in tables['portfolio_metrics']:
        add(row['as_of_date'], 'PORTFOLIO', 'POOL', row['name'], row['phase'],
            row['value'] if row['status'] == 'AVAILABLE' else None, row['unit'], row['message'])
    # The active modeled credit stream is independent of contractual promises.
    # Multiple receipts for the same date/source aggregate exact posted cents.
    collection_key = 'overlay_collections' if tables.get('overlay_collections') else 'credit_collections'
    groups = {}
    for row in tables.get(collection_key, ()):
        stage = ('CLO_OVERLAY:' if collection_key == 'overlay_collections' else 'CREDIT:') + str(row['source'])
        for metric in ('cash_interest', 'principal_collection', 'total_cash'):
            key = (row['payment_date'], row['loan_id'], stage, metric)
            groups[key] = groups.get(key, Fraction()) + Fraction(row[metric])
    for (day, identity, stage, metric), exact in groups.items():
        add(day, 'ASSET_COLLECTION', identity, metric, stage, post_currency(exact), 'EUR')
    # Allocation IDs form their own namespace. Raw received borrower cash and
    # its legal proceeds split remain independently reconcilable; contractual
    # coupon promises cannot stand in for either observation.
    for row in tables.get('coupon_proceeds_audit', ()):
        for metric in ('raw_coupon_cash', 'raw_principal_cash', 'principal_accrued_restored',
                       'interest_proceeds', 'principal_proceeds', 'remaining_principal_accrued',
                       'original_principal_permission'):
            add(row['payment_date'], 'PROCEEDS_ALLOCATION', row['allocation_id'], metric,
                'RECEIPT', row[metric], 'EUR')
        add(row['payment_date'], 'PROCEEDS_ALLOCATION', row['allocation_id'], 'receipt_rows',
            'RECEIPT', row['receipt_rows'], 'COUNT')
    for row in tables.get('ledger_snapshots', ()):
        for metric, value in row.items():
            if metric not in {'as_of_date', 'currency'}:
                add(row['as_of_date'], 'LEDGER_CASH', 'LEDGER', metric, 'END_OF_DAY', value, row['currency'])
    for row in tables.get('ledger_positions', ()):
        for metric in ('settled_par', 'available_to_sell'):
            add(row['as_of_date'], 'LEDGER_POSITION', row['asset_id'], metric, 'END_OF_DAY', row[metric], row['currency'])
    observed = index_observations(pairs)
    catalog = tuple({'observation_date': key.observation_date, 'entity_type': key.entity_type,
        'entity_id': key.entity_id, 'metric': key.metric, 'stage': key.stage,
        'value': item.value, 'unit': item.unit, 'status': 'AVAILABLE' if item.value is not None else 'UNAVAILABLE',
        'message': item.unavailable_reason} for key, item in observed.items())
    return observed, catalog


def pilot_reports(adapter, result, tables, values, *, positions=()):
    """Build review reports alongside the same calculation, before atomic save."""
    from .ledger_records import ledger_request_from_workbook, ledger_reports
    ledger_request = ledger_request_from_workbook(adapter)
    ledger_tables = ledger_reports(ledger_request)
    tables.update(ledger_tables)
    observed, catalog = observed_catalog(result, tables, values)
    benchmarks = benchmark_records(adapter.table_records(schema.TABLE_RANGE_NAMES['benchmarks'], schema.TABLE_NAMES['benchmarks']))
    comparison = ReconciliationService().compare(benchmarks, observed) if benchmarks else None
    rows = () if comparison is None else tuple({
        'observation_date': item.key.observation_date, 'entity_type': item.key.entity_type,
        'entity_id': item.key.entity_id, 'metric': item.key.metric, 'stage': item.key.stage,
        'expected': item.benchmark.expected, 'actual': None if item.observation is None else item.observation.value,
        'difference': item.difference, 'tolerance': item.benchmark.tolerance, 'unit': item.benchmark.unit,
        'status': item.status.value, 'source': item.benchmark.source,
        'reference_id': item.benchmark.reference_id, 'message': item.message} for item in comparison.results)
    findings = []
    def finding(code, severity, message, identity='DEAL', observation= None):
        findings.append(dict(code=code, severity=severity, entity_id=identity,
                             observation_date=observation, message=message))
    if comparison is None:
        finding('NO_INDEPENDENT_BENCHMARKS', 'WARNING', 'Calculation completed; no independent benchmark comparisons were supplied.')
    elif not comparison.matched:
        finding('BENCHMARK_NOT_MATCHED', 'ERROR', 'Independent comparisons contain mismatches or unavailable observations.')
    else:
        finding('BENCHMARK_SCOPE', 'INFO', f'{len(benchmarks)} supplied comparisons matched. Other outputs and legal terms are outside this assertion.')
    for row in tables['limit_tests']:
        if row['status'] in {'BREACH', 'UNAVAILABLE'}:
            finding('PORTFOLIO_LIMIT_' + row['status'], 'WARNING', row.get('message') or row['limit_id'],
                    row['limit_id'], row['as_of_date'])
    existing = result.clo_opening_state is not None
    finding('OPERATING_SCOPE', 'INFO',
        'Existing CLO post-distribution opening at an original payment boundary. Face, claims and account balances are explicit; equity IRR is forward from the supplied opening mark. Future real trades and mid-period liability accrual are outside this profile.'
        if existing else 'Supported cash-pay asset research and closing redesign. Use the optional CLO Opening tables for an explicit existing post-distribution profile.')
    if ledger_request is not None:
        finding('LEDGER_SEPARATE_SCOPE', 'WARNING', 'Operational cash and settlement review is complete for explicit ledger inputs. Missing real events, legal eligibility, future loan payments or debt waterfalls are not inferred. Inspect both settled and trade-date par.')
    status = 'BENCHMARK_SCOPE_MATCHED' if comparison is not None and comparison.matched else 'CALCULATED_REQUIRES_REVIEW'
    if any(row['severity'] == 'ERROR' for row in findings):
        status = 'REVIEW_FAILED'
    audit = ({'software_version': __version__, 'schema_version': schema.SCHEMA_VERSION,
        'run_id': result.cashflows.run_id, 'calculated_at': values['result_last_calculated_at'],
        'input_sha256': input_fingerprint(adapter), 'mode': adapter.scalar(schema.SCALAR_NAMES['mode']),
        'scope': 'EXISTING_CLO_POST_DISTRIBUTION' if existing else 'CASH_PAY_ASSET_AND_CLOSING_RESEARCH', 'ledger_status': 'NOT_CONFIGURED' if ledger_request is None else 'REPLAYED_EXPLICIT_INPUTS',
        'reconciliation_status': 'NOT_CONFIGURED' if comparison is None else comparison.status.value,
        'readiness_status': status, 'message': 'Inspect Pilot Findings, Reconciliation and declared scope; this status is not transaction sign-off.'},)
    seasoned = tuple({'loan_id': p.terms.loan_id, 'projection_date': p.par_as_of_date,
        'original_anchor': p.terms.start_date, 'opening_par': p.opening_balance,
        'opening_accrued_interest': p.seasoned_state.opening_accrued_interest,
        'entitlement_policy': p.seasoned_state.entitlement_policy.value,
        'first_payment_date': next(row.payment_date for row in result.cashflows.cashflows if row.loan_id == p.terms.loan_id),
        'first_cash_interest': next(row.cash_interest for row in result.cashflows.cashflows if row.loan_id == p.terms.loan_id),
        'historical_fixing_count': len(p.seasoned_state.fixing_observations), 'source': p.seasoned_state.provenance}
        for p in positions if p.seasoned_state is not None)
    return {'run_audit': audit, 'reconciliation_catalog': catalog, 'reconciliation_results': rows,
            'readiness_findings': tuple(findings), 'seasoned_audit': seasoned, **ledger_tables}


def check_model_workbook(path: Path, *, project=False, require_reconciliation=False):
    """Inspect a saved snapshot without saving additions or calculation output."""
    import openpyxl
    from .excel import NamedWorkbook
    from .excel_model import read_model_workbook_inputs, execute_model_workbook
    book = openpyxl.load_workbook(path)
    try:
        if book._external_links:
            raise InputValidationError('External workbook links are not supported in model inputs')
        adapter = NamedWorkbook(book)
        inputs = read_model_workbook_inputs(adapter)
        from .ledger_records import ledger_request_from_workbook, ledger_reports
        ledger_input = ledger_request_from_workbook(adapter)
        ledger_reports(ledger_input)
        benchmark_records(adapter.table_records(schema.TABLE_RANGE_NAMES['benchmarks'], schema.TABLE_NAMES['benchmarks']))
        current = input_fingerprint(adapter)
        prior = adapter.table_records(schema.TABLE_RANGE_NAMES['run_audit'], schema.TABLE_NAMES['run_audit'])
        fresh = bool(prior and prior[0].get('input_sha256') == current and prior[0].get('software_version') == __version__)
        report = {'status': 'INPUT_READY', 'saved_results': 'CURRENT' if fresh else 'STALE_OR_NOT_RUN',
                  'input_sha256': current, 'asset_count': len(inputs.request.cashflow_request.positions),
                  'read_only': True, 'scope': 'INPUT_VALIDATION_ONLY'}
        report['ledger_status'] = 'NOT_CONFIGURED' if ledger_input is None else 'REPLAYED_EXPLICIT_INPUTS'
        if project:
            execute_model_workbook(adapter)
            audit = adapter.table_records(schema.TABLE_RANGE_NAMES['run_audit'], schema.TABLE_NAMES['run_audit'])[0]
            failed = audit['readiness_status'] == 'REVIEW_FAILED' or require_reconciliation and audit['reconciliation_status'] != 'MATCH'
            report.update(status='REVIEW_FAILED' if failed else 'CALCULATION_COMPLETED_FOR_REVIEW',
                          reconciliation=audit['reconciliation_status'], scope=audit['scope'])
        elif require_reconciliation:
            raise InputValidationError('--require-reconciliation requires --project to validate fresh calculated observations')
        return report
    finally:
        book.close()
