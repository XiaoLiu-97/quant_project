"""Exact monetary posting, with decimal conversion only for diagnostics."""

from decimal import Context, Decimal, Inexact, MAX_EMAX, MIN_EMIN, ROUND_HALF_EVEN, localcontext
from fractions import Fraction


def _finite_decimal(value: object, label: str) -> Decimal:
    """Keep low-level numeric utilities independent of financial domain models."""
    if not isinstance(value, Decimal) or not value.is_finite():
        raise ValueError(f"{label} must be a finite Decimal")
    return value


def basis_points_rate(value: Decimal) -> Decimal:
    """Convert basis points to an annual decimal rate without any rounding.

    Dividing by Decimal(10000) is a context-sensitive arithmetic operation.
    Shifting the finite coefficient's exponent preserves every supplied digit,
    even under a low-precision caller context with Inexact traps enabled.
    """
    value = _finite_decimal(value, "basis points")
    parts = value.as_tuple()
    return Decimal((parts.sign, parts.digits, parts.exponent - 4))


def compose_floating_rate(
    index_rate: Decimal,
    spread_bps: Decimal,
    index_floor: Decimal | None = None,
    *, index_cap: Decimal | None = None,
    all_in_floor: Decimal | None = None, all_in_cap: Decimal | None = None,
) -> Decimal:
    """Bound reference rate, add margin exactly, then bound the all-in rate.

    Reference bounds apply before margin; all-in bounds apply afterwards.
    Blank bounds mean absent, while zero is an active contractual bound. The
    two collars have distinct scopes, so a final all-in cap can override the
    economic effect of a reference floor. Never infer a universal zero floor.

    A fixed reporting precision can move a near-half-cent coupon across its
    posting boundary before Fraction arithmetic starts. Aligning complete
    operand coefficients gives an exact sum rather than a rounded diagnostic.
    Returned rates are safe financial inputs for Fraction multiplication; the
    separate decimal_fraction function remains for displayed diagnostics only.
    """
    base = bounded_rate(index_rate, index_floor, index_cap)
    margin = basis_points_rate(spread_bps)
    if not margin:
        return bounded_rate(base, all_in_floor, all_in_cap)
    if not base:
        return bounded_rate(margin, all_in_floor, all_in_cap)
    # Two spare digits accommodate a carry without dropping aligned tails.
    precision = max(base.adjusted(), margin.adjusted()) - min(
        base.as_tuple().exponent, margin.as_tuple().exponent,
    ) + 3
    with localcontext(Context(prec=max(34, precision), rounding=ROUND_HALF_EVEN,
                              Emax=MAX_EMAX, Emin=MIN_EMIN)) as context:
        context.traps[Inexact] = True
        return bounded_rate(base + margin, all_in_floor, all_in_cap)


def bounded_rate(rate: Decimal, floor: Decimal | None, cap: Decimal | None) -> Decimal:
    """Clip one annual decimal rate to an explicit, consistently ordered collar.

    This is a contractual coupon transform, not a purchased derivative or a
    mark-to-market calculation. Comparison preserves every finite input digit.
    Pair ordering is checked even when the observed rate would not bind.
    """
    rate = _finite_decimal(rate, "rate")
    floor = None if floor is None else _finite_decimal(floor, "floor")
    cap = None if cap is None else _finite_decimal(cap, "cap")
    if floor is not None and cap is not None and floor > cap:
        raise ValueError("Rate floor cannot exceed cap within the same scope")
    if floor is not None:
        rate = max(rate, floor)
    return rate if cap is None else min(rate, cap)


def post_currency(amount: Fraction) -> Decimal:
    """Round an exact signed amount to cents, ties away from zero (HALF_UP).

    Rounding a previously rounded DCF can move an exact half-cent below its tie.
    Integer quotient/remainder arithmetic preserves that boundary exactly.
    """
    if not isinstance(amount, Fraction):
        raise TypeError("Monetary posting requires an exact Fraction")
    scaled = amount * 100
    cents, remainder = divmod(abs(scaled.numerator), scaled.denominator)
    if 2 * remainder >= scaled.denominator:
        cents += 1
    if scaled < 0:
        cents = -cents
    value = Decimal(cents)
    with localcontext(Context(prec=max(34, value.adjusted() + 4), rounding=ROUND_HALF_EVEN)):
        return value / 100


def decimal_fraction(value: Fraction) -> Decimal:
    """34 significant digits for displayed factors/diagnostics, not posting."""
    with localcontext(Context(prec=34, rounding=ROUND_HALF_EVEN)):
        return Decimal(value.numerator) / Decimal(value.denominator)
