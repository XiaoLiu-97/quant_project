# Project Trident Integrated 金融验证与文档标准

更新：2026-10-07。当前方法以本目录按主题说明为准；source的版本和访问限制保留，不把历史PASS视为本次验收。当前generic policy有独立handcases及账本验证，真实deal profile、评级calibration和trustee对账仍未完成。

存续payment-boundary开账须独立核验face和capitalized coupon是否已包含在trustee outstanding中、各cash account用途、原payment/fixing grid和historical fee base。验证opening cash/claim conservation、cutoff transfer、zero-face live claim、original stub不重复、forward current equity mark及settled snapshot不重复现金。案例、executed-document来源及限制见[存续CLO方法](existing_clo_opening.md)。

## 优先级与交付标准

金融数学正确性是最高优先级。性能优化、功能增加和界面改动不能改变已确认的金融语义。本项目面向真实 portfolio management，关键计算必须能够追溯到条款、公式、输入和验证证据；已知重大计算问题不得被正常输出掩盖。

用户要求这些标准也适用于后续其他金融代码。当前要求在 [项目上下文](../project_context.md) 持续更新；独立项目仍需要带入相同要求。用户已撤销 AGENTS.md 的执行指令。

重要计算尽量同时满足三个条件：有权威参考；有独立的已知答案；有账本或经济关系校验。参考未取得或条款未确认时，应明确标记未验证，并记录解决方式。不能通过给整个模型贴一个“测试通过”标签代替逐项验证。

## 条款与 convention 的来源

| 信息 | 优先使用的证据 | 处理原则 |
| --- | --- | --- |
| 单笔贷款 | executed agreement、amendment、agent notice | 明确有效版本、实际余额、付款及 fixing 条款 |
| CLO 瀑布、IC/OC、eligibility、limits | indenture、offering circular、有效修订 | 输出关联适用条款；不能复制另一宗 CLO 的定义 |
| 期初资产、债务、现金及递延 | 对应日期的 trustee/agent records | 对账时区分状态数据和未来假设 |
| benchmark 定义及日历 | administrator、央行、交易文件指定日历 | 区分 benchmark convention 和实际贷款 convention |
| 评级、credit estimate、WARF/WARR | 适用评级机构的方法及交易定义 | 记录机构、版本、日期、notching、缺失评级处理 |
| 未确定的未来变量 | 明确批准的情景假设 | 与 observed data 分开；不得假装成已知 fixing 或可成交报价 |

当明确合同条款与常用约定不同，应实现合同，并记录差异；当文件相互冲突，不静默选一个。日期与余额也必须匹配计算所需的时点。

## 数学与单位

金额使用明确币种及单位；利率内部使用小数，spread 输入允许 bps，但边界转换唯一且可测试。价格明确是每 100 面值报价、clean price 还是 dirty price。债务 par、发行现金所得、资产成本与 equity 实缴分别保存。

契约金额及现金记账采用可控制十进制精度的实现；曲线、优化及求根可使用适当浮点计算。应单独规定 posting rounding、展示舍入、数值误差和 solver tolerance。不能用一个宽松 tolerance 掩盖资金不守恒，也不能对所有 floating-point 结果要求逐位相等。

在没有合同另行指定时，测试案例的简单计息表达为：

\[
I=N\,[\max(r_{fix},f_{index})+s]\,\mathrm{DCF}(d_0,d_1)
\]

该公式仅适用于“floor 作用于 index，spread 在其后相加”的案例。All-in floor、cap、PIK、复利 RFR、阶梯 coupon 和本金期间内变化应分别建模，不能套用同一公式。若本金期间内变化，按实际事件切段计息。

付款日调整、accrual boundary 调整、reset 日和 fixing lag 是不同字段。ACT/360 用实际天数除以 360；本金 WAL 用约定的日期基准和真实本金回收，不以最终到期日替代摊还贷款的 WAL。

现金流区分 contractual due、actual collection、default、recovery、trade settlement 和 waterfall payment。违约贷款未来合同本金与已计回收不得同时作为收款；应计利息和 PIK 也不能重复入账。

## 必须建立的验证层

| 层次 | 主要验证 | 示例 |
| --- | --- | --- |
| 输入与状态 | 类型、范围、时间、来源、关联完整性 | 重复 loan、缺失评级、负余额、未知日历、未保存输入 |
| Excel命名接口 | 所有生成Excel使用named ranges；按名称而非固定坐标读写 | 移动区域、插行列、扩容、空Table、名称scope冲突、`#REF!`、缺失列 |
| Convention | 与官方定义或合同逐例一致 | TARGET 关闭日、月末 MF、闰年、stub、fixing 前移 |
| 公式 | 独立手算或公开已知答案 | 简单息、折现、Sources & Uses、加权指标、XIRR |
| 事件与账本 | 现金、面值、债务及递延守恒 | 摊还、违约、回收、买卖、PIK、reserve release |
| 瀑布与契约 | 每节点的可用资金、支付上限和重测时点 | IC/OC threshold equality、cure、不足额、阶段切换 |
| 场景与优化 | 隔离、完整重算和约束证据 | 零变更一致、无可行解、交易费/结算、future breach |
| 迁移与真实交易 | 独立基准逐项核对 | Excel 对账、trustee reconciliation、经解释的差异 |

每个重大功能增量配套正常、边界、非法输入和相关 corner-case 测试。缺陷修复保留回归案例。已有参考案例不能由待测实现重新计算后覆盖；reference 更新需要理由和版本记录。

旧 VBA 的 PASS、Excel 缓存值或与旧模型相同的结果均只能作为证据的一部分。差异要判断是新实现缺陷、旧实现缺陷、输入版本差异还是口径修订；不能为了一致而复制已知错误。

## 关键计算的交叉核验计划

| 计算 | 独立核验及必要边界 | 重要假设 |
| --- | --- | --- |
| Loan cashflows | 小额逐日/逐期手算、旧 generator 对账 | accrual/付款调整、历史 fixing、principal event 顺序 |
| Sources & Uses | 所有资金来源与用途等额 | clean/dirty、发行折价、fees、reserve、equity 实缴 |
| IC / OC | 手工拆 numerator/denominator，精确测试 equality | haircut、应计/实收、default/低评级、账户资格、重测节点 |
| Concentration / WAS / WAL / WARF | 按单资产权重独立求和；检查空池/缺失字段 | 分母、taxonomy、评级映射、计入资产范围 |
| Equity return | 实际日期现金流与 XNPV 残差；可用时 Excel XIRR 对账 | 初始实缴、追加出资、费用、call、终值、valuation basis |
| Reinvestment / trade | 同时核验 cash/par bridge、settlement 与全部 purchase gates | 资金权限、price、accrued、未结算承诺、执行时点 |
| Optimization | 小案例可穷尽独立验证；完整 CLO 重跑最终建议 | 目标优先级、预测/压力范围、solver gap、可成交性 |

WARF 只在同一适用体系与明确映射下按权重计算；不是平均字母评级，也不等于完整信用风险。Project finance 与 corporate infra 必须区别识别，不能因为行业都属于 infrastructure 就使用同一评级风险假设。S&P 的 hybrid PF FAQ 明确区分 PF 部分与其他 corporate debt 部分的适用方法。[S&P FAQ](https://www.spglobal.com/ratings/en/regulatory/article/-/view/sourceId/101626294)

## 当前金融政策与独立反例

以下是当前 generic engine 的显式政策，不能代替目标交易的 indenture。具体证据与限制见 [信用审查](credit.md)、[waterfall 审查](waterfall.md)和 [数学/分析审查](analysis.md)。独立例子的ID是稳定的金融验收标识。

| 政策 | 当前口径、独立案例与边界 |
| --- | --- |
| V07-WF01 OC 与账户资格 | OC 包含实际持有的 principal cash，包括已收到但尚未越过 collection cutoff 的 pending principal；pending 不因此获得当期支付资格。Principal cash 100、测试债务80，现金支持为1.25倍，不能仅因 cutoff 排除实际现金。Restricted reserve 按独立政策处理。 |
| V07-WF02 IC 现金与费用 | Opening interest、已到账资产利息、银行收益及当期实际获准 reserve draw 计入适用的 realized-cash IC；senior claims 只扣一次。Interest1、实际 draw .80、senior claims1.80，净额0；未动用的 reserve 不是收入。预计利息、hedge、税项和平滑等交易特定定义仍需 profile。 |
| V07-WF03 合法递延 coupon | `interest_deferrable` 区分合法递延与cash-pay delinquency。IC默认False排除opening合法deferred本金，计当期coupon、配置下递延利息及non-deferrable arrears。Claim阻止terminal completed，funded face不double。OC资本化不选择复利：`NONE`为不复利sensitivity；参考交易的deferred compounding须 `COUPON_RATE`。已偿清IC显示NOT_APPLICABLE，OC另看capitalized claims。 |
| V07-WF04 Principal 付息权限 | 默认 `NON_DEFERRABLE_AND_CONTROLLING`：non-deferrable coupon 可按瀑布动用 principal，deferrable coupon 只有成为 controlling remaining class 后才可如此支付，并在该 class 赎本前清付。A80、B20、principal50、B合法递延2：先还 A50，B递延2保留；不能越过 A 直接付 B。`ALL_CLASSES` 是单独的 legacy sensitivity。 |
| V07-WF05 Coverage cure | Interest-funded OC 最低赎本为向上至 cent 的 `D−N/k`；principal-funded cure 对 `k>1` 是 `(kD−N)/(k−1)`，因为后者同时减少 numerator。独立边界要求13.34时，13.33不能显示已 cure。Paydown 限定于该 tested stack；不能越过未清付的 junior coupon 偿 junior par。实际节点重测，但不回溯改变已经 accrued 的当期 IC coupon。未解决 coverage 时，正常 pro-rata 不能绕过 sequential cure。 |
| V07-WF06 独立 IDT | `interest_diversion_enabled` 控制 coverage failure paydown；不是独立 Interest Diversion Test。IDT 有自己的开关、class、threshold、最大可转比例和窗口，默认关闭；generic stage 为 subordinate fee 后、incentive 前。N100、D100、k1.10，转 interest10 到 principal 可补支持10；interest-funded赎债 cure 为向上cent的9.10，9.09仍不足，不能混用。需求向上至 cent，比例 cap 向下至 cent。Earmarked principal 是 principal cash 的子集，转账不是新收款、income、赎债、已购入 par 或 equity 出资；未实际买入时保持现金，窗口结束/call/final 才按规则释放。 |
| V07-WF07 CCC/discount OC | CCC excess 使用当前 `oc_market_price_fraction`；Discount Obligation 使用 acquisition clean price，两者独立。CCC-only 手算（A/B 显式未分类为 Discount Obligations）：A20（买价95/mark50）、B20（买价60/mark90）、普通60，CCC限额10；先选最低 mark 的 A20，再选 B10，haircut11，adjusted par89。Active excess 缺当前 mark 明确失败；无 excess 不要求无用 mark。重叠分类取最低认可价值一次，不重复 haircut。当前 generic CCC denominator 为 performing pool，不自动等同所有交易定义。 |
| V07-WF08 Call/legal final | 使用真实 residual interest 和 principal，保护债务/claims 后才分 equity。Sale80＋interest20、debt90，equity10；债务110则剩余债务10、equity0，不能声称完成。未来 recovery receivable 或未解决 claim 不能提前兑现或静默删除。 |
| V07-WF09 资本化 OC/IDT | 默认 `include_deferred_interest_in_oc=True`：tested face par加实际未付deferrable claims；False为显式非资本化sensitivity，cash-pay delinquent arrears不自动计本金base。N100、face90、deferred10、k1.10时D100、OC1.00x FAIL，interest-funded cure9.10、IDT shortfall10；旧par-only错误显示PASS。Face0但deferred10仍为live coverage debt。IC默认排除opening deferred本金的政策独立，不得套用至OC。 |
| V07-CR01 Default coupon | Default 后才到账的 defaulted slice 未付 coupon 不作为实际收款；default 前实际付过的 coupon 保留。100 par、20% annual default、合同 coupon10，实际 coupon8；100% default 且 RR0，则现金0。Midpoint 用于 synthetic event/recovery 日期，不能制造半期未收 default coupon。Native、imported 和 synthetic overlay 使用同一现金原则。 |
| V07-CR02 信用应计与 posting | 应用层传入每笔原合同 day count，精确 `rate×par×DCF×survival` 后仅 posting 一次。Full coupon .005 可记 .01，但存续一半的 .0025 应记0，不能对已 rounded .01再乘一半。Standalone overlay 可缺 day-count mapping 的兼容路径使用 unrounded diagnostic；该路径不能认证任意半-cent/截断边界，正式金融验证使用显式 mapping。 |
| V07-CR03 Imported bridge/claims | 非零 CDR/CPR 要求完整未来 principal reference；不完整但 unstressed 的现金桥可使用。Default/prepay 不能双退出，default memo 不是再次现金或 loss；RR0 与 legal-final 后 recovery 仍保留 claim 状态。零面值延迟利息只有 entitlement 未被 stress 改变时可保留，改变后缺 receivable metadata 明确拒绝。 |
| V07-AN01 WAS/WAC | `WAS_BPS` 仅 floating-rate par，加权 margin；`WAC_RATE` 仅 fixed-rate par，加权 annual coupon。各100 par、浮息 spread300bps、固定 coupon8%，结果分别300bps与.08；不能混成150bps和4%。`ALL_ASSET_SPREAD_BPS` 是显式 whole-pool diagnostic，不能代替法律 WAS。缺类型/所需字段不缩小分母假装完整。 |
| V07-FU01 Funding | 输入 iterator 冻结一次后复用；purchase100、clean99.5、accrued1、fee2、reserve3，uses105.50；debt60、issue99，proceeds59.40；equity46.10。Acquired accrued 成本与显式 inherited entitlement 同时接入；不能只支付成本而丢掉可收 coupon。 |
| V07-OP01 独立 proposal 复核 | `reconcile_proposal` 重建cent ledger与全部exact mandate，不因外来 `OPTIMAL/validated=True` 放过风险限制。100新资产、factor2000，cap1999，现金/par虽合法仍必须拒绝。Float转换拒绝非零exact coefficient变0，如1e-400；不能以numeric loss改变优化问题。Static full-par quoted-spread proxy不能当作floating-only WAS。 |
| V07-OP02 IRR ranking/frontier | IRR .10000000000/.10000000006/.10000000012、factor100/200/300、resolution1e-10，不可用非传递pairwise equality得到不一致选择。全部eligible共用highest-IRR锚定buckets，ranking/frontier一致；0分辨率才按精确IRR比较。排序分辨率不能放松mandate或legal limit。 |

交易条款对 cash/proceeds、CCC current price、合法递延及独立 IDT 的支持见 [OCP Euro CLO 2017-1 January 2026 Offering Circular](https://ise-prodnr-eu-west-1-data-integration.s3-eu-west-1.amazonaws.com/202601/07d64e17-e59d-4980-b089-0096b0ee4bc1.pdf)，printed pp.130–140、165–167、201–206。该交易只是独立参考，Project Trident 的 generic stage/范围不是它的完整复制。Defaulted collections 与 purchase 后测试的独立来源见 [2024 SEC CLO indenture](https://www.sec.gov/Archives/edgar/data/1702510/000170251024000079/indenture-clo2024x1.htm)，§1.1及§12.2。

资本化采用明确的 generic payment-day profile：应计后按实际支付扣减claims，每类GATE在其coupon node后测量；full-stack retest/END也计入被block的junior当期未付coupon。本profile在同日资本化，不推断所有合同的capitalization date。Reporting的opening/closing balance及debt par仍为funded face par，coupon claims另列；coverage denominator才聚合适用的capitalized claims。Principal20先付capitalized coupon10、再赎face10时，N/D100→80、face90→80、claim10→0；付款仍分别列coupon与principal，不重复资本化。OCP printed p178与Carlyle §1.1/§2.7支持capitalized outstanding语义；actual priority/date仍需交易profile。逐项独立验证见 [waterfall 审查](waterfall.md)，最终完整验收见 [综合审查](../readiness.md)。

资本化coverage与coupon accrual必须分别配置。`include_deferred_interest_in_oc=True`不自动令deferred coupon复利；`shortfall_accrual_method=NONE`是不复利sensitivity，OCP/SEC参考deferred compounding须 `COUPON_RATE`。Generic实现分别对face coupon及opening deferred interest作cent posting，可能与合同在aggregate outstanding上一次posting相差1cent；匹配target条款/舍入前，不声称完整复现公开indenture或已完成真实交易认证。

候选 replay 的当前 scope 为 `ONE_CONFIGURED_SCENARIO_NO_EXPLICIT_BASELINE_CREDIT_EVENTS`：拒绝 explicit baseline dated credit events，但可沿用已配置的 original-pool CDR/CPR、synthetic reinvestment 和其他政策，不意味着零信用压力。`REPLAY_VALIDATED` 检查已配置必需 portfolio limits、GATE IC/OC、terminal 和 return/mandate；独立 IDT 的有效 transfer 不是自动法律 breach，也不代表 IDT 全期 PASS。有限搜索 scope 为 `FINITE_CANDIDATE_CONFIGURED_SCENARIO_CLOSING_POOL_SEARCH`，仅在本次 eligible candidates 内比较，不保证 global optimum、多情景稳健性或真实成交。



## Assumption register

每个重大假设至少记录以下信息：

| 字段 | 含义 |
| --- | --- |
| ID / version | 可被运行结果、测试和文档引用的稳定标识 |
| value / unit | 值、币种、bps/%、日期或枚举 |
| scope / effective date | 适用资产、交易、场景及有效日期 |
| category | observed input、contract term、market convention、model assumption 或 synthetic fixture |
| source / rationale | 原始来源及位置；无来源时解释选择理由 |
| impact | 影响的现金流、指标、约束与敏感性 |
| status | confirmed、proposed、test-only、unresolved 或 superseded |

运行报告显示重大假设及变化，完整 register 随输入快照保存。缺少关键定义时输出 unavailable 或 validation error，不自动用零、面值或历史代理补齐。

## 文档覆盖与更新流程

每次重大更新同步维护实际受影响的文档；不要求每次重写全部。金融公式、条款、输入输出 schema 或用户操作流程改变，无论代码量多少，均需更新对应说明。

| 文档 | 必备内容 |
| --- | --- |
| User guidance | 输入与单位、操作流程、示例、输出解读、错误处理 |
| Assumptions | 上述 register、重要未决定义、敏感性 |
| Methodology | 公式、事件顺序、规则适用范围、来源与限制 |
| Architecture | 模块职责、对象、依赖、接口、状态与schema，以及named-range/Table/列名registry |
| Flow charts | 用户流程、现金流、瀑布、what-if、优化与验证节点 |
| Validation / change record | 测试范围、参考答案、对账差异、状态、版本和影响 |

```mermaid
flowchart TD
    U[需求或重大更新] --> S[核对条款与权威来源]
    S --> A[记录假设和未决事项]
    A --> E[建立独立验收案例]
    E --> I[实现或设计修订]
    I --> V[验证数学 账本和市场约定]
    V --> G{关键问题已解决?}
    G -- 否 --> A
    G -- 是 --> D[同步 guidance methodology 架构和流程图]
    D --> R[记录版本与证据后交付]
```

## 当前验收与内部兼容测试

完整回归以本项目 [current.json](../validation/current.json) 绑定的日志、软件版本和 source hashes 为准。金融 known-answer、账户/face/claim 守恒、输入保护、完整案例输出和 native Excel 打开/保存/重开分别提供证据；单项成功不能代替其余范围。当前范围见 [readiness](../readiness.md)，部署见 [deployment](../deployment.md)。

内部 compatibility suites 保留旧格式 adapter 的数值及 metadata contract。其工作簿由本项目脚本在临时目录重新构造，不依赖其他项目环境或历史交付工作簿。Internal adapter schema `0.7` 与当前用户界面 schema `1.0` 是不同接口；软件版本为 `0.12.0`。兼容测试不把历史 native evidence 当作本次输出验收，也不要求用户操作旧格式工作簿。
