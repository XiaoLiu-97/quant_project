"""Independent portfolio examples, missing-data policy and exact limit edges."""

from dataclasses import replace
from datetime import date, timedelta
from decimal import Decimal, localcontext
import unittest

from trident.analysis import (
    AssetExposure, FactorMapping, LimitDirection, LimitSpec, LimitStatus,
    MetricStatus, PortfolioAnalyzer,
)
from trident.domain.models import CouponType, InputValidationError, LoanCashflow


D = Decimal
ASOF = date(2025, 1, 1)


def exposure(loan_id="L1", par="100", spread="300", **changes):
    values = dict(loan_id=loan_id, obligor="OB1", asset_class="INFRA", financing_type="PROJECT_FINANCE",
                  country="DE", sector="power", currency="EUR", par=D(par), spread_bps=D(spread),
                  maturity_date=date(2030, 1, 1), is_senior=True, is_secured=True,
                  is_pik=False, is_revolver=False, is_construction=False,
                  coupon_type=CouponType.FLOATING)
    values.update(changes)
    return AssetExposure(**values)


def principal(loan_id, amount, days, period=1):
    paid = ASOF + timedelta(days=days)
    return LoanCashflow(loan_id, "EUR", period, ASOF, paid, ASOF, paid, paid, None,
                        D(amount), None, D(0), D(0), D(0), D(0), D(0), D(amount), D(0), D(amount))


class PortfolioAnalysisTests(unittest.TestCase):
    def setUp(self):
        self.analyzer = PortfolioAnalyzer()

    def test_hand_weighted_spread_and_concentration(self):
        assets = [exposure(par="70"), exposure("L2", "30", "425", asset_class="BSL", obligor="OB2", country="FR")]
        report = self.analyzer.analyze(assets, ASOF)
        self.assertEqual(report.total_par, D(100))
        self.assertEqual(report.metric("WAS_BPS").value, D("337.5"))
        self.assertEqual(report.metric("LARGEST_ASSET_CLASS_FRACTION").value, D("0.7"))
        self.assertEqual(report.metric("LARGEST_OBLIGOR_FRACTION").value, D("0.7"))
        self.assertEqual(report.metric("SENIOR_FRACTION").value, D(1))
        for dimension in self.analyzer.DIMENSIONS:
            self.assertEqual(sum(row.fraction for row in report.concentrations if row.dimension == dimension), D(1))

    def test_obligor_concentration_aggregates_multiple_loans(self):
        assets = [exposure(par="40"), exposure("L2", "35"), exposure("L3", "25", obligor="OB2")]
        report = self.analyzer.analyze(assets, ASOF)
        self.assertEqual(report.metric("LARGEST_OBLIGOR_FRACTION").value, D("0.75"))

    def test_wal_uses_principal_timing_not_maturity_average(self):
        report = self.analyzer.analyze([exposure()], ASOF, [principal("L1", "50", 365), principal("L1", "50", 730, 2)])
        self.assertEqual(report.metric("WAL_YEARS").value, D("1.5"))
        self.assertEqual(report.metric("WAL_YEARS").coverage, D(1))
        self.assertGreater(report.metric("WEIGHTED_AVERAGE_MATURITY_YEARS").value, D(5))

    def test_wal_incomplete_does_not_publish_understated_life(self):
        report = self.analyzer.analyze([exposure()], ASOF, [principal("L1", "50", 365)])
        self.assertEqual(report.metric("WAL_YEARS").status, MetricStatus.INCOMPLETE)
        self.assertIsNone(report.metric("WAL_YEARS").value)
        self.assertEqual(report.metric("WAL_YEARS").coverage, D(0))

    def test_missing_spread_and_quality_never_reweight_known_subset(self):
        report = self.analyzer.analyze([exposure(par="70"), exposure("L2", "30", spread_bps=None, is_secured=None)], ASOF)
        self.assertEqual(report.metric("WAS_BPS").coverage, D("0.7"))
        self.assertIsNone(report.metric("WAS_BPS").value)
        self.assertEqual(report.metric("SECURED_FRACTION").status, MetricStatus.INCOMPLETE)

    def test_missing_group_retained_and_largest_unavailable(self):
        report = self.analyzer.analyze([exposure(par="70"), exposure("L2", "30", country=None)], ASOF,
                                      limits=[LimitSpec("DE", "concentration:country:DE", D("0.8"))])
        self.assertEqual(report.metric("LARGEST_COUNTRY_FRACTION").coverage, D("0.7"))
        self.assertIsNone(report.metric("LARGEST_COUNTRY_FRACTION").value)
        self.assertTrue(any(row.dimension == "country" and row.bucket is None and row.par == 30 for row in report.concentrations))
        self.assertEqual(report.limits[0].status, LimitStatus.UNAVAILABLE)

    def test_synthetic_factors_separate_from_agency_warf(self):
        mapping = FactorMapping("TRIDENT_TEST", "1", {"INF": D(1700), "BSL": D(3100)}, is_synthetic=True)
        report = self.analyzer.analyze([exposure(par="350", test_factor_bucket="INF"),
                                       exposure("L2", "150", test_factor_bucket="BSL")], ASOF, mapping=mapping)
        self.assertEqual(report.metric("TEST_FACTOR_AVERAGE").value, D(2120))
        self.assertIsNone(report.metric("WARF").value)
        self.assertEqual(report.metric("RATING_FACTOR_COVERAGE_FRACTION").value, D(0))

    def test_hybrid_subset_factors_and_bucket_gates(self):
        mapping = FactorMapping("TRIDENT_TEST", "1", {"INF": D(1700), "BSL": D(3100), "TEST_06": D(3100)}, is_synthetic=True)
        assets = [exposure(par="350", test_factor_bucket="INF"),
                  exposure("L2", "115", asset_class="BSL", test_factor_bucket="BSL"),
                  exposure("L3", "35", asset_class="BSL", test_factor_bucket="TEST_06")]
        limits = [LimitSpec("BSL_FACTOR", "BSL_TEST_FACTOR_AVERAGE", D(3300)),
                  LimitSpec("LOW_BUCKET", "concentration:test_factor_bucket:TEST_06", D("0.075"))]
        report = self.analyzer.analyze(assets, ASOF, mapping=mapping, limits=limits)
        self.assertEqual(report.metric("TEST_FACTOR_AVERAGE").value, D(2120))
        self.assertEqual(report.metric("BSL_TEST_FACTOR_AVERAGE").value, D(3100))
        self.assertEqual(report.metric("INFRA_TEST_FACTOR_AVERAGE").value, D(1700))
        self.assertEqual(report.metric("BSL_TEST_FACTOR_AVERAGE").coverage, D(1))
        self.assertEqual([limit.status for limit in report.limits], [LimitStatus.PASS, LimitStatus.PASS])
        self.assertEqual(report.limits[1].value, D("0.07"))

    def test_subset_missing_class_prevents_establishing_denominator(self):
        mapping = FactorMapping("TRIDENT_TEST", "1", {"R": D(100)}, is_synthetic=True)
        report = self.analyzer.analyze([exposure(test_factor_bucket="R"), exposure("L2", asset_class=None, test_factor_bucket="R")],
                                      ASOF, mapping=mapping, limits=[LimitSpec("BSL", "BSL_TEST_FACTOR_AVERAGE", D(200))])
        self.assertEqual(report.metric("TEST_FACTOR_AVERAGE").value, D(100))
        for name in ("BSL_TEST_FACTOR_AVERAGE", "INFRA_TEST_FACTOR_AVERAGE"):
            self.assertEqual(report.metric(name).status, MetricStatus.UNAVAILABLE)
            self.assertIsNone(report.metric(name).value)
            self.assertIn("asset_class", report.metric(name).message)
        self.assertEqual(report.limits[0].status, LimitStatus.UNAVAILABLE)

    def test_subset_empty_and_missing_factors_keep_full_subset_par(self):
        mapping = FactorMapping("TRIDENT_TEST", "1", {"R": D(100)}, is_synthetic=True)
        report = self.analyzer.analyze([exposure(test_factor_bucket="R")], ASOF, mapping=mapping)
        self.assertEqual(report.metric("BSL_TEST_FACTOR_AVERAGE").status, MetricStatus.UNAVAILABLE)
        self.assertIn("No BSL subset par", report.metric("BSL_TEST_FACTOR_AVERAGE").message)
        report = self.analyzer.analyze([exposure(test_factor_bucket="R"),
                                       exposure("L2", "75", asset_class="BSL", test_factor_bucket="R"),
                                       exposure("L3", "25", asset_class="BSL")], ASOF, mapping=mapping)
        self.assertEqual(report.metric("BSL_TEST_FACTOR_AVERAGE").coverage, D("0.75"))
        self.assertEqual(report.metric("BSL_TEST_FACTOR_AVERAGE").status, MetricStatus.INCOMPLETE)
        self.assertIsNone(report.metric("BSL_TEST_FACTOR_AVERAGE").value)

    def test_subset_limits_use_exact_subset_fraction(self):
        mapping = FactorMapping("TRIDENT_TEST", "1", {"HIGH": D(1), "LOW": D(0)}, is_synthetic=True)
        assets = [exposure(par="97", test_factor_bucket="LOW"),
                  exposure("L2", "1", asset_class="BSL", test_factor_bucket="HIGH"),
                  exposure("L3", "2", asset_class="BSL", test_factor_bucket="LOW")]
        threshold = D("0.3333333333333333333333333333333333")
        report = self.analyzer.analyze(assets, ASOF, mapping=mapping,
                                      limits=[LimitSpec("EXACT_BSL", "BSL_TEST_FACTOR_AVERAGE", threshold)])
        self.assertEqual(report.metric("BSL_TEST_FACTOR_AVERAGE").value, threshold)
        self.assertEqual(report.limits[0].status, LimitStatus.BREACH)

    def test_subset_actual_warf_with_one_selected_methodology(self):
        mapping = FactorMapping("AGENCY_EXPLICIT", "1", {"R1": D(100), "R2": D(300)})
        report = self.analyzer.analyze([exposure(par="75", rating_bucket="R1"),
                                       exposure("L2", "25", asset_class="BSL", rating_bucket="R2")], ASOF, mapping=mapping)
        self.assertEqual(report.metric("WARF").value, D(150))
        self.assertEqual(report.metric("BSL_WARF").value, D(300))
        self.assertEqual(report.metric("INFRA_WARF").value, D(100))

    def test_actual_selected_mapping_and_missing_coverage(self):
        mapping = FactorMapping("AGENCY_METHOD_EXPLICIT", "2026", {"R1": D(100), "R2": D(300)})
        report = self.analyzer.analyze([exposure(par="75", rating_bucket="R1"), exposure("L2", "25", rating_bucket="R2")], ASOF, mapping=mapping)
        self.assertEqual(report.metric("WARF").value, D(150))
        report = self.analyzer.analyze([exposure(par="75", rating_bucket="R1"), exposure("L2", "25")], ASOF, mapping=mapping)
        self.assertEqual(report.metric("WARF").status, MetricStatus.INCOMPLETE)
        self.assertEqual(report.metric("WARF").coverage, D("0.75"))
        self.assertIsNone(report.metric("WARF").value)

    def test_direct_factor_provenance_conflicts_fail(self):
        asset = exposure(rating_factor=D(100), rating_system="A", rating_version="1", rating_bucket="R1")
        for mapping in (FactorMapping("B", "1", {"R1": D(100)}), FactorMapping("A", "1", {"R1": D(200)})):
            with self.assertRaises(InputValidationError):
                self.analyzer.analyze([asset], ASOF, mapping=mapping)
        with self.assertRaises(InputValidationError):
            self.analyzer.analyze([asset, exposure("L2", rating_factor=D(100), rating_system="A", rating_version="2")], ASOF)

    def test_mapping_is_immutable_and_detached_from_source(self):
        values = {"R": D(100)}
        mapping = FactorMapping("A", "1", values)
        values["R"] = D(900)
        self.assertEqual(mapping.factors["R"], D(100))
        with self.assertRaises(TypeError):
            mapping.factors["R"] = D(900)

    def test_limit_inclusive_equality_headroom_and_phase(self):
        specs = [LimitSpec("WAS", "WAS_BPS", D(300), LimitDirection.MINIMUM),
                 LimitSpec("DE", "concentration:country:DE", D(1)),
                 LimitSpec("ABSENT", "concentration:country:FR", D(0)),
                 LimitSpec("PHASE", "PIK_FRACTION", D(0), phases=("REINVESTMENT",)),
                 LimitSpec("BREACH", "WAS_BPS", D(299))]
        report = self.analyzer.analyze([exposure()], ASOF, limits=specs, phase="AMORTISATION")
        self.assertEqual([item.status for item in report.limits], [LimitStatus.PASS, LimitStatus.PASS, LimitStatus.PASS, LimitStatus.NOT_APPLICABLE, LimitStatus.BREACH])
        self.assertEqual(report.limits[-1].headroom, D(-1))
        self.assertEqual(report.limits[0].headroom, D(0))

    def test_limit_compares_exact_value_not_display_rounding(self):
        threshold = D("0.3333333333333333333333333333333333")
        report = self.analyzer.analyze([exposure(par="1", spread="1"), exposure("L2", "2", "0")], ASOF,
                                      limits=[LimitSpec("EDGE", "WAS_BPS", threshold)])
        self.assertEqual(report.metric("WAS_BPS").value, threshold)
        self.assertEqual(report.limits[0].status, LimitStatus.BREACH)

    def test_empty_portfolio_is_explicitly_unavailable(self):
        report = self.analyzer.analyze([], ASOF, limits=[LimitSpec("WAS", "WAS_BPS", D(300))])
        self.assertEqual(report.total_par, 0)
        self.assertIsNone(report.currency)
        self.assertEqual(report.metric("WAS_BPS").status, MetricStatus.UNAVAILABLE)
        self.assertEqual(report.limits[0].status, LimitStatus.UNAVAILABLE)

    def test_low_caller_precision_does_not_change_results(self):
        with localcontext() as context:
            context.prec = 2
            report = self.analyzer.analyze([exposure(par="123.45"), exposure("L2", "876.55", "425")], ASOF)
        self.assertEqual(report.total_par, D(1000))
        self.assertEqual(report.metric("WAS_BPS").value, D("409.56875"))

    def test_snapshot_and_cashflow_validation(self):
        bad_calls = [([exposure(), exposure()], (), ()),
                     ([exposure(), exposure("L2", currency="USD")], (), ()),
                     ([exposure(maturity_date=date(2024, 1, 1))], (), ()),
                     ([exposure()], [principal("UNKNOWN", "100", 365)], ()),
                     ([exposure()], [principal("L1", "101", 365)], ()),
                     ([exposure()], [principal("L1", "100", -1)], ()),
                     ([exposure()], [principal("L1", "50", 365), principal("L1", "50", 730)], ()),
                     ([exposure()], (), [LimitSpec("X", "UNKNOWN", D(1))]),
                     ([exposure()], (), [LimitSpec("X", "WAS_BPS", D(1)), LimitSpec("X", "WAS_BPS", D(2))])]
        for assets, rows, limits in bad_calls:
            with self.subTest(assets=assets, rows=rows, limits=limits), self.assertRaises(InputValidationError):
                self.analyzer.analyze(assets, ASOF, rows, limits=limits)
        with self.assertRaises(InputValidationError):
            self.analyzer.analyze([exposure()], ASOF, [replace(principal("L1", "100", 365), currency="USD")])

    def test_exposure_and_factor_validation(self):
        for values in (dict(par=D(0)), dict(par=D("1.001")), dict(is_secured="TRUE"),
                       dict(rating_factor=D(100)), dict(currency=" EUR"), dict(spread_bps=float(300)), dict(loan_id="")):
            with self.subTest(values=values), self.assertRaises(InputValidationError):
                exposure(**values)
        with self.assertRaises(InputValidationError):
            FactorMapping("A", "1", {"R": D(-1)})


if __name__ == "__main__":
    unittest.main()
