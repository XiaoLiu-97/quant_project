"""Contract-date adjustment with explicit banking/settlement calendar profiles.

The euro TARGET rule projection retains its 1900--2199 range. Regional profiles
support 2000--2099, including documented rule changes and known exceptional
closures. Future rules are projections, not promises of operational availability.
See docs/methodology/regional_calendars.md for profiles, sources and assumptions.
No exchange calendar is silently substituted for a banking calendar. In
particular New York uses Federal Reserve settlement observance, not NYSE or
federal-employee observance, and Zurich uses CHF currency settlement holidays.
"""

from abc import ABC, abstractmethod
from calendar import monthrange
from dataclasses import dataclass
from datetime import date, timedelta
from enum import Enum
from functools import lru_cache
from typing import Callable

from ._validation import require_date, require_integer


class BusinessDayConvention(str, Enum):
    """Date adjustment, without changing the unadjusted schedule anchor."""

    UNADJUSTED = "UNADJUSTED"
    FOLLOWING = "FOLLOWING"
    MODIFIED_FOLLOWING = "MODIFIED_FOLLOWING"
    PRECEDING = "PRECEDING"
    MODIFIED_PRECEDING = "MODIFIED_PRECEDING"


class CalendarName(str, Enum):
    """Named profiles, selected independently for each contract date role."""

    TARGET = "TARGET"
    WEEKENDS_ONLY = "WEEKENDS_ONLY"
    LONDON = "LONDON"
    NEW_YORK = "NEW_YORK"
    TOKYO = "TOKYO"
    SYDNEY = "SYDNEY"
    TORONTO = "TORONTO"
    ZURICH = "ZURICH"

    @classmethod
    def _missing_(cls, value):
        """Accept historical display labels while retaining canonical values."""
        if not isinstance(value, str):
            return None
        identifier = value.strip().upper().replace(" ", "_")
        if identifier == "WEEKENDSONLY":
            return cls.WEEKENDS_ONLY
        return cls.__members__.get(identifier)


def calendar_from_name(
    name: CalendarName | str, *, extra_holidays: frozenset[date] = frozenset()
) -> "BusinessCalendar":
    """Resolve an explicit calendar identifier; never infer a local holiday set.

    Display aliases such as ``New York`` resolve to canonical ``NEW_YORK``.
    Additional full-day closures are immutable, instance-specific overrides;
    they never mutate cached standard holiday sets or reopen a standard holiday.
    """
    try:
        selected = CalendarName(name)
    except (ValueError, TypeError) as error:
        raise ValueError(f"Unsupported business calendar: {name!r}") from error
    if selected is CalendarName.TARGET:
        return TargetCalendar(extra_holidays)
    if selected is CalendarName.WEEKENDS_ONLY:
        return WeekendCalendar(extra_holidays)
    return RegionalCalendar(selected, extra_holidays)


class BusinessCalendar(ABC):
    """Calendar interface with common adjustment and business-day lag behavior."""

    @abstractmethod
    def is_business_day(self, value: date) -> bool:
        """Whether a valid calendar date is open for the relevant business."""

    def adjust(self, value: date, convention: BusinessDayConvention) -> date:
        """Apply a convention; modified conventions preserve the calendar month.

        FpML's scheme definitions describe these standard adjustments:
        https://www.fpml.org/spec/2002/wd-fpml-3-0-2002-04-17/html/schemeDefinitions.html
        """
        require_date(value, "value")
        if not isinstance(convention, BusinessDayConvention):
            raise TypeError("convention must be a BusinessDayConvention")
        # Validate the date against this calendar even for UNADJUSTED.
        is_open = self.is_business_day(value)
        if convention is BusinessDayConvention.UNADJUSTED or is_open:
            return value
        direction = (
            1
            if convention in (
                BusinessDayConvention.FOLLOWING,
                BusinessDayConvention.MODIFIED_FOLLOWING,
            )
            else -1
        )
        modified = convention in (
            BusinessDayConvention.MODIFIED_FOLLOWING,
            BusinessDayConvention.MODIFIED_PRECEDING,
        )
        if not modified:
            return self.add_business_days(value, direction)
        # Detect a month crossing before looking up the other month's calendar.
        # This also permits valid modified adjustment at a calendar range edge.
        result = value
        while True:
            try:
                candidate = result + timedelta(days=direction)
            except OverflowError:
                return self.add_business_days(value, -direction)
            if (candidate.year, candidate.month) != (value.year, value.month):
                return self.add_business_days(value, -direction)
            if self.is_business_day(candidate):
                return candidate
            result = candidate

    def add_business_days(self, value: date, days: int) -> date:
        """Move by open days, excluding the start date; zero keeps it unchanged.

        A nonbusiness start is permitted and is not silently normalized first.
        For example Saturday minus one business day is the preceding Friday.
        Calendar/date limits raise an explicit ValueError.
        """
        require_date(value, "value")
        require_integer(days, "days")
        self.is_business_day(value)
        if days == 0:
            return value
        direction = 1 if days > 0 else -1
        maximum_days = (date.max - value).days if direction == 1 else (value - date.min).days
        if abs(days) > maximum_days:
            raise ValueError("business-day lag exceeds the supported date range")
        remaining = abs(days)
        result = value
        while remaining:
            try:
                result += timedelta(days=direction)
            except OverflowError as exc:
                raise ValueError("business-day lag exceeds the supported date range") from exc
            if self.is_business_day(result):
                remaining -= 1
        return result


@dataclass(frozen=True)
class WeekendCalendar(BusinessCalendar):
    """Monday--Friday calendar with optional explicit full-day closures."""

    extra_holidays: frozenset[date] = frozenset()

    def __post_init__(self) -> None:
        _validate_extra_holidays(self.extra_holidays, require_date)

    def is_business_day(self, value: date) -> bool:
        require_date(value, "value")
        return value.weekday() < 5 and value not in self.extra_holidays


@lru_cache(maxsize=300)
def _easter_sunday(year: int) -> date:
    """Compute Gregorian Easter using the Meeus/Jones/Butcher integer algorithm."""
    a = year % 19
    b, c = divmod(year, 100)
    d, e = divmod(b, 4)
    f = (b + 8) // 25
    g = (b - f + 1) // 3
    h = (19 * a + b - d - g + 15) % 30
    i, k = divmod(c, 4)
    lunar_correction = (32 + 2 * e + 2 * i - h - k) % 7
    m = (a + 11 * h + 22 * lunar_correction) // 451
    month, day_minus_one = divmod(h + lunar_correction - 7 * m + 114, 31)
    return date(year, month, day_minus_one + 1)


@lru_cache(maxsize=300)
def _target_holidays(year: int) -> frozenset[date]:
    """Modern TARGET closures; weekend dates do not generate substitutes."""
    easter = _easter_sunday(year)
    return frozenset(
        {
            date(year, 1, 1),
            easter - timedelta(days=2),
            easter + timedelta(days=1),
            date(year, 5, 1),
            date(year, 12, 25),
            date(year, 12, 26),
        }
    )


@dataclass(frozen=True)
class TargetCalendar(BusinessCalendar):
    """Modern euro TARGET closures for 1900--2199, plus explicit exceptions.

    Holidays on weekends do not create substitute Monday holidays. This calendar
    deliberately excludes other ECB office holidays and non-euro TARGET rules.
    """

    extra_holidays: frozenset[date] = frozenset()

    def __post_init__(self) -> None:
        _validate_extra_holidays(self.extra_holidays, self._validate_date)

    @staticmethod
    def _validate_date(value: date, field_name: str) -> None:
        require_date(value, field_name)
        if not 1900 <= value.year <= 2199:
            raise ValueError(f"{field_name} is outside TARGET calendar range 1900--2199")

    def is_business_day(self, value: date) -> bool:
        self._validate_date(value, "value")
        return (
            value.weekday() < 5
            and value not in self.extra_holidays
            and value not in _target_holidays(value.year)
        )


def _validate_extra_holidays(
    holidays: frozenset[date], validator: Callable[[date, str], object]
) -> None:
    """Validate immutable overrides using the selected profile's date bounds."""
    if not isinstance(holidays, frozenset):
        raise TypeError("extra_holidays must be a frozenset of dates")
    for holiday in holidays:
        validator(holiday, "extra_holidays item")


def _nth_weekday(year: int, month: int, weekday: int, occurrence: int) -> date:
    """Find a weekday directly; Monday is zero, as in datetime.date."""
    first = date(year, month, 1)
    return first + timedelta(days=(weekday - first.weekday()) % 7 + 7 * (occurrence - 1))


def _last_weekday(year: int, month: int, weekday: int) -> date:
    last = date(year, month, monthrange(year, month)[1])
    return last - timedelta(days=(last.weekday() - weekday) % 7)


def _monday_observed(fixed: date) -> date:
    """Weekend holiday substituted by the following Monday."""
    return fixed + timedelta(days=7 - fixed.weekday()) if fixed.weekday() >= 5 else fixed


def _christmas_boxing(year: int) -> set[date]:
    """Paired holidays retain distinct substitutes, even when dates collide.

    Christmas on Sunday and Boxing Day on Monday close Monday and Tuesday.
    Rolling each independently to Monday would lose one holiday. The actual
    weekend dates are retained for completeness, but never count as open days.
    """
    actual = (date(year, 12, 25), date(year, 12, 26))
    holidays = set(actual)
    for holiday in actual:
        if holiday.weekday() >= 5:
            substitute = _monday_observed(holiday)
            while substitute.weekday() >= 5 or substitute in holidays:
                substitute += timedelta(days=1)
            holidays.add(substitute)
    return holidays


def _london_holidays(year: int) -> set[date]:
    """England/Wales bank holidays, including announced replacements."""
    easter = _easter_sunday(year)
    early_may = date(year, 5, 8) if year == 2020 else _nth_weekday(year, 5, 0, 1)
    # Jubilee proclamations replace the last Monday in May; they do not add it
    # to the two June holidays. Keeping both would create a false business lag.
    spring = {2002: (6, 4), 2012: (6, 4), 2022: (6, 2)}.get(year)
    holidays = {
        _monday_observed(date(year, 1, 1)), easter - timedelta(days=2),
        easter + timedelta(days=1), early_may,
        date(year, *spring) if spring else _last_weekday(year, 5, 0),
        _last_weekday(year, 8, 0),
    } | _christmas_boxing(year)
    exceptions = {
        2002: ((6, 3),), 2011: ((4, 29),), 2012: ((6, 5),),
        2022: ((6, 3), (9, 19)), 2023: ((5, 8),),
    }
    holidays.update(date(year, month, day) for month, day in exceptions.get(year, ()))
    return holidays


def _new_york_holidays(year: int) -> set[date]:
    """Federal Reserve standard settlement days, not federal employee days."""
    holidays = {
        _nth_weekday(year, 1, 0, 3), _nth_weekday(year, 2, 0, 3),
        _last_weekday(year, 5, 0), _nth_weekday(year, 9, 0, 1),
        _nth_weekday(year, 10, 0, 2), _nth_weekday(year, 11, 3, 4),
    }
    fixed = [(1, 1), (7, 4), (11, 11), (12, 25)]
    if year >= 2021:
        fixed.append((6, 19))
    for month, day in fixed:
        holiday = date(year, month, day)
        holidays.add(holiday)
        # Sunday creates a Monday closure. Saturday does NOT close Friday.
        # This is verified by the Fed's 2021 Juneteenth operational notice and
        # differs materially from the employee/NYSE observance in old VBA.
        if holiday.weekday() == 6:
            holidays.add(holiday + timedelta(days=1))
    return holidays


def _tokyo_holidays(year: int) -> set[date]:
    """Japanese national plus bank holidays and historical legal transitions."""
    # Integer microdays avoid binary-float thresholds in the standard bounded
    # equinox approximation. Future dates remain projected until gazetted by
    # NAOJ; the official 2026/2027 calendars are checked independently in tests.
    elapsed = year - 1980
    correction = 1_000_000 * (elapsed // 4)
    vernal = (20_843_100 + 242_194 * elapsed - correction) // 1_000_000
    autumn = (23_248_800 + 242_194 * elapsed - correction) // 1_000_000
    national = {
        date(year, 1, 1), _nth_weekday(year, 1, 0, 2), date(year, 2, 11),
        date(year, 3, vernal), date(year, 4, 29), date(year, 5, 3),
        date(year, 5, 5), date(year, 9, autumn), date(year, 11, 3),
        date(year, 11, 23),
    }
    if year < 2019:
        national.add(date(year, 12, 23))
    elif year >= 2020:
        national.add(date(year, 2, 23))
    if year >= 2007:
        national.add(date(year, 5, 4))
    national.add(_nth_weekday(year, 9, 0, 3) if year >= 2003 else date(year, 9, 15))
    if year in (2020, 2021):
        # Olympic legislation moved these dates rather than adding holidays.
        summer = ((7, 23), (7, 24), (8, 10)) if year == 2020 else ((7, 22), (7, 23), (8, 8))
        national.update(date(year, month, day) for month, day in summer)
    else:
        national.add(_nth_weekday(year, 7, 0, 3) if year >= 2003 else date(year, 7, 20))
        national.add(_nth_weekday(year, 10, 0, 2))
        if year >= 2016:
            national.add(date(year, 8, 11))
    if year == 2019:
        national.update((date(year, 5, 1), date(year, 10, 22)))

    holidays = set(national)
    # Citizens' holidays require adjacent NATIONAL holidays, not bank closures
    # or previously added substitutes. Only inspecting neighbors of actual
    # holidays avoids a 365-day scan and avoids recursively inventing holidays.
    for holiday in national:
        between = holiday + timedelta(days=1)
        if between.weekday() < 5 and between + timedelta(days=1) in national:
            holidays.add(between)
    for holiday in sorted(national):
        if holiday.weekday() == 6:
            substitute = holiday + timedelta(days=1)
            if year >= 2007:
                while substitute in national:
                    substitute += timedelta(days=1)
            holidays.add(substitute)
    # Jan 2/3 and Dec 31 are BANK closures. They do not generate extra substitute
    # holidays (e.g. Jan 4 is normally open when Jan 3 fell on a Sunday).
    holidays.update((date(year, 1, 2), date(year, 1, 3), date(year, 12, 31)))
    return holidays


def _sydney_holidays(year: int) -> set[date]:
    """NSW banking profile, with explicitly announced one-off closures."""
    easter = _easter_sunday(year)
    holidays = {
        _monday_observed(date(year, 1, 1)), _monday_observed(date(year, 1, 26)),
        easter - timedelta(days=2), easter + timedelta(days=1), date(year, 4, 25),
        _nth_weekday(year, 6, 0, 2), _nth_weekday(year, 8, 0, 1),
        _nth_weekday(year, 10, 0, 1),
    } | _christmas_boxing(year)
    # The 2011 Act moves Easter Monday to Tuesday to separate it from Anzac Day.
    # The NSW 2026 announcement specifies only 2026 and 2027 additional Mondays;
    # it does not enact a permanent Monday-observance rule for future years.
    exceptions = {2011: ((4, 26),), 2022: ((9, 22),), 2026: ((4, 27),), 2027: ((4, 26),)}
    holidays.update(date(year, month, day) for month, day in exceptions.get(year, ()))
    return holidays


def _toronto_holidays(year: int) -> set[date]:
    """Toronto banking/bond-market profile: national plus Ontario closures."""
    easter = _easter_sunday(year)
    victoria = date(year, 5, 24)
    holidays = {
        _monday_observed(date(year, 1, 1)), easter - timedelta(days=2),
        victoria - timedelta(days=victoria.weekday()),
        _monday_observed(date(year, 7, 1)), _nth_weekday(year, 8, 0, 1),
        _nth_weekday(year, 9, 0, 1), _nth_weekday(year, 10, 0, 2),
        _monday_observed(date(year, 11, 11)),
    } | _christmas_boxing(year)
    if year >= 2008:
        holidays.add(_nth_weekday(year, 2, 0, 3))
    if year >= 2021:
        holidays.add(_monday_observed(date(year, 9, 30)))
    # Federal day of mourning 19-Sep-2022 did not close Canadian payment
    # systems or Ontario banking; do not infer a closure from the UK calendar.
    return holidays


def _zurich_holidays(year: int) -> set[date]:
    """CHF currency settlement closures, not Swiss exchange trading closures."""
    easter = _easter_sunday(year)
    return {
        date(year, 1, 1), date(year, 1, 2), easter - timedelta(days=2),
        easter + timedelta(days=1), date(year, 5, 1), easter + timedelta(days=39),
        easter + timedelta(days=50), date(year, 8, 1), date(year, 12, 25),
        date(year, 12, 26),
    }


_REGIONAL_BUILDERS = {
    CalendarName.LONDON: _london_holidays,
    CalendarName.NEW_YORK: _new_york_holidays,
    CalendarName.TOKYO: _tokyo_holidays,
    CalendarName.SYDNEY: _sydney_holidays,
    CalendarName.TORONTO: _toronto_holidays,
    CalendarName.ZURICH: _zurich_holidays,
}


@lru_cache(maxsize=600)
def _regional_holidays(name: CalendarName, year: int) -> frozenset[date]:
    """Cache one small immutable holiday set per profile/year, not per day."""
    return frozenset(_REGIONAL_BUILDERS[name](year))


@dataclass(frozen=True)
class RegionalCalendar(BusinessCalendar):
    """Bounded regional profile with instance-specific exceptional closures.

    Modern legal rules are projected beyond published schedules; future one-off
    events remain caller supplied. Rejecting dates outside 2000--2099 prevents
    modern observance rules from being presented as complete historical data.
    Standard holidays are shared through a bounded cache. Custom closures do
    not enter that cache, so two instruments may safely use different overrides.
    """

    name: CalendarName
    extra_holidays: frozenset[date] = frozenset()

    def __post_init__(self) -> None:
        if not isinstance(self.name, CalendarName) or self.name not in _REGIONAL_BUILDERS:
            raise ValueError("RegionalCalendar requires a supported regional CalendarName")
        _validate_extra_holidays(self.extra_holidays, self._validate_date)

    def _validate_date(self, value: date, field_name: str) -> None:
        require_date(value, field_name)
        if not 2000 <= value.year <= 2099:
            raise ValueError(f"{field_name} is outside {self.name.value} calendar range 2000--2099")

    def is_business_day(self, value: date) -> bool:
        self._validate_date(value, "value")
        return (
            value.weekday() < 5
            and value not in self.extra_holidays
            and value not in _regional_holidays(self.name, value.year)
        )
