"""Independent survival, rounding and fixed-amount timing answers."""

from datetime import date, datetime, timedelta
from decimal import Context, Decimal, Inexact, ROUND_HALF_EVEN, localcontext
from fractions import Fraction
import unittest

from trident.credit.stress_rates import (
    CapacityPolicy, CreditRatePrecisionError, DefaultVectorCapacityError,
    DefaultVectorPeriod, DefaultVectorStatus, FixedCumulativeDefaultVector,
    conditional_period_probability,
)
from trident.domain.models import InputValidationError


D = Decimal
START = date(2026, 1, 1)


def periods(weights, capacities=None):
    caps = capacities if capacities is not None else [None] * len(weights)
    return tuple(DefaultVectorPeriod(
        date(2026 + index, 1, 1), date(2027 + index, 1, 1), weight, cap,
    ) for index, (weight, cap) in enumerate(zip(weights, caps)))


class ConditionalProbabilityTests(unittest.TestCase):
    def test_one_365_day_year_keeps_annual_conditional_probability(self):
        result = conditional_period_probability(D("0.2"), START, START + timedelta(days=365))
        self.assertEqual(result.elapsed_years, Fraction(1))
        self.assertEqual(result.probability, D("0.2"))
        self.assertEqual(result.apply_to_par(D("100")), D("20.00"))

    def test_two_year_survival_is_not_two_times_annual(self):
        result = conditional_period_probability(D("0.2"), START, START + timedelta(days=730))
        # 100 -> 80 -> 64; default total 36, independently hand counted.
        self.assertEqual(result.probability, D("0.36"))
        self.assertEqual(result.apply_to_par(D("100")), D("36.00"))

    def test_rate_applies_to_supplied_current_par_only(self):
        result = conditional_period_probability(D("0.1"), START, START + timedelta(days=365))
        self.assertEqual(result.apply_to_par(D("60")), D("6.00"))

    def test_actual_73_day_fifth_year_has_exact_rational_root(self):
        # Annual survival = (1/2)^5; 73/365 = 1/5, hence period exit = 1/2.
        result = conditional_period_probability(D("0.96875"), START, START + timedelta(days=73))
        self.assertEqual(result.probability, D("0.5"))
        self.assertEqual(result.apply_to_par(D("0.01")), D("0.01"))

    def test_nonperfect_root_matches_independent_float_log_survival(self):
        import math
        result = conditional_period_probability(D("0.15"), START, START + timedelta(days=91))
        expected = -math.expm1(math.log1p(-0.15) * (91 / 365))
        self.assertAlmostEqual(float(result.probability), expected, places=15)
        self.assertEqual(result.apply_to_par(D("1000000")), D("39708.52"))

    def test_monthly_survival_composes_across_calendar_year(self):
        boundaries = [date(2025, month, 1) for month in range(2, 13)] + [date(2026, 1, 1), date(2026, 2, 1)]
        with localcontext(Context(prec=90)):
            survival = D(1)
            for first, last in zip(boundaries, boundaries[1:]):
                survival *= 1 - conditional_period_probability(D("0.2"), first, last).probability
            self.assertLess(abs(survival - D("0.8")), D("1e-75"))

    def test_quarter_lengths_cross_new_year_without_resetting_hazard(self):
        boundaries = [date(2025, 10, 1), date(2026, 1, 1), date(2026, 4, 1), date(2026, 7, 1), date(2026, 10, 1)]
        with localcontext(Context(prec=90)):
            survival = D(1)
            for first, last in zip(boundaries, boundaries[1:]):
                survival *= 1 - conditional_period_probability(D("0.2"), first, last).probability
            self.assertLess(abs(survival - D("0.8")), D("1e-75"))

    def test_leap_year_uses_366_over_365(self):
        result = conditional_period_probability(D("0.2"), date(2028, 1, 1), date(2029, 1, 1))
        self.assertEqual(result.elapsed_years, Fraction(366, 365))
        self.assertGreater(result.probability, D("0.2"))
        self.assertLess(result.probability, D("0.201"))

    def test_endpoint_rates_and_zero_elapsed(self):
        for annual, days, expected in (("0", 10, "0"), ("1", 10, "1"), ("1", 0, "0"), ("0", 0, "0")):
            with self.subTest(annual=annual, days=days):
                result = conditional_period_probability(D(annual), START, START + timedelta(days=days))
                self.assertEqual(result.probability, D(expected))
                self.assertEqual(result.apply_to_par(D("12.34")), D("12.34") if expected == "1" else D("0.00"))

    def test_low_caller_precision_and_inexact_traps_do_not_affect_answer(self):
        result = conditional_period_probability(D("0.15"), START, START + timedelta(days=91))
        expected = result.probability
        with localcontext(Context(prec=2, rounding=ROUND_HALF_EVEN)) as context:
            context.traps[Inexact] = True
            self.assertEqual(result.probability, expected)
            self.assertEqual(result.apply_to_par(D("1000000")), D("39708.52"))
            self.assertEqual(context.prec, 2)
            self.assertFalse(context.flags[Inexact])

    def test_long_tail_near_half_cent_is_not_diagnostic_posting(self):
        # An exact annual tail beyond 80-digit reporting remains financial input.
        rate = D("0.005" + "0" * 100 + "1")
        result = conditional_period_probability(rate, START, START + timedelta(days=365))
        self.assertEqual(result.apply_to_par(D("1.00")), D("0.01"))
        rate_below = D("0.004" + "9" * 101)
        below = conditional_period_probability(rate_below, START, START + timedelta(days=365))
        self.assertEqual(below.apply_to_par(D("1.00")), D("0.00"))

    def test_fractional_power_near_cent_uses_interval_refinement(self):
        # 73-day q=1-survival**(1/5). Annual survival=0.995**5 produces q=.005.
        with localcontext(Context(prec=200)):
            exact_survival = D("0.995") ** 5
            above = 1 - exact_survival + D("1e-100")
            below = 1 - exact_survival - D("1e-100")
        self.assertEqual(conditional_period_probability(above, START, START + timedelta(days=73)).apply_to_par(D("1")), D("0.01"))
        self.assertEqual(conditional_period_probability(below, START, START + timedelta(days=73)).apply_to_par(D("1")), D("0.00"))

    def test_fractional_power_exact_half_cent_is_half_up(self):
        with localcontext(Context(prec=50)):
            annual = 1 - D("0.995") ** 5
        result = conditional_period_probability(annual, START, START + timedelta(days=73))
        self.assertEqual(result.probability, D(".005"))
        self.assertEqual(result.apply_to_par(D("1")), D(".01"))

    def test_very_remote_survival_near_one_does_not_build_enormous_fraction(self):
        result = conditional_period_probability(D(".9999999999"), date(1, 1, 1), date(9999, 12, 31))
        self.assertGreater(result.probability, D(".999999999"))
        self.assertEqual(result.apply_to_par(D("100.00")), D("100.00"))

    def test_tiny_conditional_probability_retains_tail(self):
        result = conditional_period_probability(D("1e-1000"), START, START + timedelta(days=73))
        self.assertGreater(result.probability, 0)
        self.assertEqual(result.apply_to_par(D("1e1000")), D("0.20"))

    def test_zero_current_par(self):
        self.assertEqual(conditional_period_probability(D("0.5"), START, START + timedelta(days=1)).apply_to_par(D(0)), D("0.00"))

    def test_unsupported_extreme_precision_raises_instead_of_guessing(self):
        result = conditional_period_probability(D("1e-10001"), START, START + timedelta(days=1))
        with self.assertRaises(CreditRatePrecisionError):
            _ = result.probability

    def test_invalid_probability_input(self):
        for value in (D("-0.1"), D("1.0001"), D("NaN"), D("Infinity"), 0.2, "0.2", None):
            with self.subTest(value=value), self.assertRaises(InputValidationError):
                conditional_period_probability(value, START, START)

    def test_invalid_dates_and_negative_interval(self):
        for first, last in ((START, START - timedelta(days=1)), (datetime(2026, 1, 1), START), (START, "2026-02-01")):
            with self.subTest(first=first, last=last), self.assertRaises(InputValidationError):
                conditional_period_probability(D("0.1"), first, last)

    def test_money_validation_is_independent_of_rate_endpoints(self):
        for value in (D("-1"), D("0.001"), D("NaN"), 1.0):
            with self.subTest(value=value), self.assertRaises(InputValidationError):
                conditional_period_probability(D(0), START, START).apply_to_par(value)


class FixedDefaultVectorTests(unittest.TestCase):
    def test_hand_allocation_preserves_fixed_total(self):
        vector = FixedCumulativeDefaultVector(D("40.95"), periods([D(".39"), D(".22"), D(".16"), D(".13"), D(".10")]))
        result = vector.compile()
        self.assertEqual([item.requested_amount for item in result.periods], [D("15.97"), D("9.01"), D("6.55"), D("5.32"), D("4.10")])
        self.assertEqual(result.total_allocated_amount, D("40.95"))
        self.assertEqual(result.total_shortfall_amount, 0)
        self.assertEqual(result.status, DefaultVectorStatus.COMPLETE)

    def test_equal_remainder_cent_goes_to_earliest_period(self):
        result = FixedCumulativeDefaultVector(D("0.01"), periods([Fraction(1, 3)] * 3)).compile()
        self.assertEqual([item.requested_amount for item in result.periods], [D("0.01"), D("0.00"), D("0.00")])

    def test_target_does_not_change_with_timing_shape(self):
        front = FixedCumulativeDefaultVector(D("20"), periods([D(".8"), D(".2")])).compile()
        back = FixedCumulativeDefaultVector(D("20"), periods([D(".2"), D(".8")])).compile()
        self.assertEqual(front.total_allocated_amount, back.total_allocated_amount)
        self.assertEqual([item.allocated_amount for item in front.periods], [D("16"), D("4")])

    def test_zero_target_and_zero_weight(self):
        result = FixedCumulativeDefaultVector(D(0), periods([D(0), D(1)], [D(0), D(0)])).compile()
        self.assertEqual(result.status, DefaultVectorStatus.COMPLETE)
        self.assertEqual([item.allocated_amount for item in result.periods], [D("0.00"), D("0.00")])

    def test_capacity_rejection_contains_explicit_compilation(self):
        vector = FixedCumulativeDefaultVector(D("20"), periods([D(".5"), D(".5")], [D("9"), D("10")]))
        with self.assertRaises(DefaultVectorCapacityError) as raised:
            vector.compile()
        self.assertEqual(raised.exception.compilation.total_shortfall_amount, D("1.00"))
        self.assertEqual(raised.exception.compilation.status, DefaultVectorStatus.TARGET_NOT_REACHED)

    def test_report_shortfall_never_silently_reassigns_capacity(self):
        result = FixedCumulativeDefaultVector(D("20"), periods([D(".5"), D(".5")], [D("9"), D("11")]), CapacityPolicy.REPORT_SHORTFALL).compile()
        self.assertEqual(result.total_allocated_amount, D("19.00"))
        self.assertEqual(result.total_shortfall_amount, D("1.00"))
        self.assertEqual([item.allocated_amount for item in result.periods], [D("9"), D("10")])

    def test_rounding_capacity_shortfall_is_explicit(self):
        result = FixedCumulativeDefaultVector(D(".01"), periods([D(".5"), D(".5")], [D(0), D(".01")]), CapacityPolicy.REPORT_SHORTFALL).compile()
        self.assertEqual(result.total_shortfall_amount, D(".01"))
        self.assertEqual(result.total_allocated_amount, 0)

    def test_low_precision_and_traps_preserve_vector_allocation(self):
        vector = FixedCumulativeDefaultVector(D("123456789.01"), periods([Fraction(1, 3)] * 3))
        with localcontext(Context(prec=2)) as context:
            context.traps[Inexact] = True
            result = vector.compile()
            self.assertEqual([item.requested_amount for item in result.periods], [D("41152263.01"), D("41152263.00"), D("41152263.00")])
            self.assertEqual(result.total_allocated_amount, D("123456789.01"))
            self.assertFalse(context.flags[Inexact])

    def test_weights_require_exact_normalization(self):
        for weights in ([D(".4"), D(".4")], [D(".3333333333")] * 3, [Fraction(1, 2)] * 3):
            with self.subTest(weights=weights), self.assertRaises(InputValidationError):
                FixedCumulativeDefaultVector(D(1), periods(weights))

    def test_invalid_weights(self):
        for weight in (D("-.1"), D("1.01"), D("NaN"), D("Infinity"), 0.5, True, None):
            with self.subTest(weight=weight), self.assertRaises(InputValidationError):
                DefaultVectorPeriod(START, START + timedelta(days=1), weight)

    def test_dates_positive_contiguous_and_ordered(self):
        with self.assertRaises(InputValidationError):
            DefaultVectorPeriod(START, START, D(1))
        first = DefaultVectorPeriod(START, START + timedelta(days=30), D(".5"))
        for second in (DefaultVectorPeriod(START + timedelta(days=31), START + timedelta(days=60), D(".5")),
                       DefaultVectorPeriod(START + timedelta(days=29), START + timedelta(days=60), D(".5"))):
            with self.assertRaises(InputValidationError):
                FixedCumulativeDefaultVector(D(1), (first, second))
        with self.assertRaises(InputValidationError):
            FixedCumulativeDefaultVector(D(1), tuple(reversed(periods([D(".5"), D(".5")]))))

    def test_invalid_money_capacity_and_collection_types(self):
        for target in (D("-.01"), D(".001"), D("NaN"), 1.0):
            with self.subTest(target=target), self.assertRaises(InputValidationError):
                FixedCumulativeDefaultVector(target, periods([D(1)]))
        for capacity in (D("-.01"), D(".001"), D("NaN"), 1.0):
            with self.subTest(capacity=capacity), self.assertRaises(InputValidationError):
                DefaultVectorPeriod(START, START + timedelta(days=1), D(1), capacity)
        for rows in ((), [], [DefaultVectorPeriod(START, START + timedelta(days=1), D(1))], ("bad",)):
            with self.subTest(rows=rows), self.assertRaises(InputValidationError):
                FixedCumulativeDefaultVector(D(1), rows)
        with self.assertRaises(InputValidationError):
            FixedCumulativeDefaultVector(D(1), periods([D(1)]), "REJECT")


if __name__ == "__main__":
    unittest.main()
