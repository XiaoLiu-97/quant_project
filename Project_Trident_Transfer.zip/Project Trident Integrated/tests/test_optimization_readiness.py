"""Independent inexpensive readiness edge cases; no Excel or financial oracle."""

from datetime import date
from decimal import Decimal
import unittest

from trident.application.optimization_readiness import OptimizationReadinessService
from trident.optimization import AssetDescriptor, AssetKind, Holding, OptimizationObjective, OptimizationRequest, PortfolioLimits, TradeQuote, TradeSide

D=Decimal


class ReadinessServiceTests(unittest.TestCase):
    @staticmethod
    def request(quotes=()):
        held=AssetDescriptor("OLD",AssetKind.BSL,"O1","GB","S",D(350),D(2000))
        return OptimizationRequest((Holding(held,D(100)),),quotes,D(100),PortfolioLimits(D(100)),
            objective=OptimizationObjective.MIN_FACTOR,
            factor_provenance="EXPLICIT_TEST_MAPPING",settlement_date=date(2026,11,20))

    def test_empty_quote_universe_has_clear_blocker(self):
        report=OptimizationReadinessService().check(self.request())
        self.assertFalse(report.ready)
        self.assertEqual(report.issues[0].code,"EMPTY_QUOTES")
        self.assertIn("SOLVER_FEASIBILITY_AND_OPTIMALITY",report.checks_not_run)

    def test_magnitude_checks_warn_without_forbidding_distressed_prices(self):
        new=AssetDescriptor("NEW",AssetKind.BSL,"O2","GB","S",D(".035"),D(1000))
        quote=TradeQuote(new,TradeSide.BUY,D(".99"),D(100),accrued_per_par=D(2))
        report=OptimizationReadinessService().check(self.request((quote,)))
        self.assertTrue(report.ready)
        codes={row.code for row in report.issues}
        self.assertTrue({"CHECK_CLEAN_PRICE_UNITS","CHECK_SPREAD_UNITS","CHECK_ACCRUED_UNITS"} <= codes)


if __name__=="__main__":
    unittest.main()
