"""Build the current Chinese waterfall reading guide from source-aligned pages.

This is documentation tooling, not a financial engine. Each page separates a
short action flow from definitions, an independent example, and scope limits.
Text is measured before drawing; overflow is an error rather than a request to
shrink the font. Intermediate PDF and PNG files stay outside the project.
"""
from __future__ import annotations

import argparse
from dataclasses import dataclass
from hashlib import sha256
import json
from pathlib import Path
import tempfile
from xml.sax.saxutils import escape

from reportlab.lib import colors
from reportlab.lib.pagesizes import A4, landscape
from reportlab.lib.styles import ParagraphStyle
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.pdfgen import canvas
from reportlab.platypus import Paragraph
from pypdf import PdfReader
import pypdfium2 as pdfium

ROOT = Path(__file__).resolve().parents[1]
OUTPUT_NAME = 'Project_Trident_Waterfall_Flowcharts_CN.pdf'

@dataclass(frozen=True)
class Card:
    title: str
    text: str
    kind: str = 'flow'

@dataclass(frozen=True)
class Page:
    title: str
    message: str
    steps: tuple[Card, ...]
    explanations: tuple[Card, ...]
    inputs: str
    outputs: str
    sources: str
    group: str


def C(title: str, text: str, kind: str = 'flow') -> Card:
    return Card(title, text, kind)

PAGES = (
Page('先看全局：资产的钱如何到达 equity',
     '先算资产实际付款，再决定 CLO 能把这些钱付给谁。资产还本与 CLO note 还本是两件事。',
     (C('计算资产实际收款', '按合同算利息和还本，再处理提前还款、违约及回收。'),
      C('整理 CLO 账户', '区分利息、本金、受限储备，以及本期尚不能使用的已收现金。'),
      C('分配利息并检查 IC / OC', '先付靠前费用；逐层付票息、测覆盖率，失败时按规则补救。'),
      C('处理本金：再投资或偿还 notes', '检查购买权限与买后测试；未用本金按优先级偿债。'),
      C('算 equity 实收，并核对期末', '先保护未付债务，再扣 incentive fee；核对资金与本金。')),
     (C('阅读路线', '第 2 页：起点。第 3-6 页：资产与账户。\n第 7-11 页：费用、IC / OC、补救与转账。\n第 12-15 页：再投资、还本、退出与收益。\n第 16-17 页：核对、输入位置和来源。', 'explain'),
      C('箭头和颜色怎样读', '资产是 CLO 持有的贷款；notes 是 CLO 发行的债务。\n箭头表示处理顺序，并非每一步都有现金转账。\n绿色：执行步骤。蓝色：定义或示例。黄色：条件、假设和适用边界。', 'explain'),
      C('本指南说明什么', '对应当前 0.12.3 的通用执行规则。所有例子都是教学例子，不是工作簿当前预测。\n交易条款不同，必须另核对，不能把模型假设当作所有 CLO 的统一规则。', 'caution')),
     'Asset Library / Asset Schedules / Market Data / CLO Assumptions / Collateral Pool / Capital Stack',
     'Asset Cashflows → Waterfall → CLO Analysis；选择 case 只显示已保存结果。',
     'clo/engine.py；docs/methodology/waterfall.md；docs/user_guide.md', '总览'),
Page('从哪里开始：新发行还是已发行 CLO',
     '开账就是告诉模型：预测开始时，资产、债务、账户及欠款分别剩下多少。',
     (C('选择新发行或存续开账', '新发行：从 closing 初始化。存续：保留原合同付款日程。'),
      C('录入资产与 notes 的当前本金', '资产持仓在 Collateral Pool；note 本金在 Capital Stack。'),
      C('录入已经存在的现金及欠款', '账户余额、用途限制、费用欠款与 note 欠息分别登记。'),
      C('确定 equity 回报的起算金额', '新发行用实际出资；存续未来回报用有来源的当前 equity 价值。')),
     (C('新发行：买资产花了多少现金', '资产购买现金包含净价（clean price）价款及购入应计利息。\n结合 note 发行所得、初始费用和所需账户资金，计算实际 equity 出资；不能直接用 equity 面值代替。', 'explain'),
      C('存续：八项余额不等于八份钱', '实际现金：利息、本金、受限储备、待释放利息、待释放本金。\n另三项标记：可用原池还本再投资、待释放原池还本再投资、暂留 IDT 资金。后三项是已有本金现金的用途子集，不能再加一遍。', 'explain'),
      C('当前开账范围', '存续起点必须是原 CLO 实际付款日完成分配后，并与下一期计息开始日相接；不支持任意期中重开。\n历史已到期未付票息与本期尚未到期的应计利息不同。存续 incentive 尚不支持，不能用 equity 市价替代历史门槛余额。', 'caution')),
     'CLO Assumptions：开账账户与费用欠款；Collateral Pool：持仓；Capital Stack：本金及欠息。',
     '期初账户、期初本金、opening claims；存续 equity forward return 的起点。',
     'clo/opening.py:16-47；clo/engine.py:377-412；clo/funding.py', '起点'),
Page('资产合同：先算借款人本来应该付什么',
     '这一页处理 collateral 中的 BSL / Infra loan，不是 CLO 发行的 notes。',
     (C('读取合同和持仓', '使用 Asset ID、持仓本金、利率条款、曲线、付款频率及计息规则。'),
      C('生成每期合同利息', '浮动利息使用对应 fixing 与 spread / floor；固定利息使用合同固定利率。'),
      C('生成每期合同本金变化', '到期一次还本、规则摊还或 BESPOKE 计划；PIK 单独增加本金。'),
      C('选择一种信用处理来源', '无新增信用处理；按年度违约率 CDR / 年度提前还款率 CPR 调整；或明确日期的退出事件。')),
     (C('现金利息与 PIK（利息转为本金）不同', '例：期初贷款本金 100，利息 6，其中现金付 4、PIK 2。\n收到现金只有 4；贷款本金增加到 102。若同时正常还本 10，期末本金为 92。\n不能把 PIK 2 同时算成现金收入。', 'explain'),
      C('Infra 的 BESPOKE 在哪里填', 'Asset Library 保留一笔资产的一行主要合同。Asset Schedules 用同一 Asset ID 的多行记录还款日期和金额。\n一笔资产有多期本金计划是正常的一对多结构，不需要复制全部合同条款。', 'explain'),
      C('不要重复加入信用影响', '同一原池不能同时使用比例信用调整和明确的违约 / 提前还款事件。\n导入的资产现金流如果已经包含信用影响，也不能再受一次比例压力。资产付款日期与 CLO note 付款日期可以不同。', 'caution')),
     'Asset Library：合同；Asset Schedules：本金计划 / fixing / 事件；Collateral Pool：持仓；Market Data：曲线。',
     'Asset Cashflows 展示合同参考；信用调整后的实际收款看 Waterfall 及信用收款明细。',
     'cashflows/engine.py:49-104；clo/engine.py:1423-1478', '资产收款'),
Page('提前还款与违约：同一期先处理什么',
     '比例情景是按比例确定计算结果，不会随机挑几笔贷款违约。',
     (C('把年度 CDR / CPR 换成本区间比例', '按资产区间实际天数换算；不会每个季度直接使用全年百分比。'),
      C('先从期初正常本金扣除违约', '违约本金转为待处理债权，不产生现金；取消该部分本期未收利息。'),
      C('剩余正常部分收息并正常还本', '合同利息、PIK 及计划还本按实际存续比例计算。'),
      C('最后对剩余本金计算提前还款', '按区间末提前还款处理；退出部分获得本期存续利息。')),
     (C('一个本金桥的例子', '单位：EUR。本期违约金额 10，区间提前还款比例 10%（不是年度 CPR）。\n期初 100 → 违约后 90 → 合同原应还 10，实际还 9 → 剩余 81 → 提前还 8.10 → 期末 72.90。\n若合同利息原为 2，实际存续利息为 1.80。', 'explain'),
      C('年度率及非均匀违约', '区间比例 = 1 - (1 - 年度率)^(实际天数 / 365)。\nFlat 对当前正常本金逐期使用该比例。非 Flat 先设五年违约目标，再分到各年；100 本金、CDR 2% 的五年目标约为 9.61。这是同一次违约计算的时间安排。', 'explain'),
      C('明确的模型假设', '违约日期设在资产区间中点。违约部分的本期未收利息全部取消，不自动收半期利息。\n非 Flat 的五年之后不新增违约；已还清本金不能再违约，未落实目标另报告。该模式不是机构校准的违约压力。', 'caution')),
     'CLO Assumptions：原池信用调整开关、CDR、CPR、违约时间分布；不要与新购资产参数混用。',
     '每期 default / scheduled principal / prepayment / ending performing principal。',
     'credit/overlay.py:256-299,306-349,621-656', '资产收款'),
Page('回收：违约本金何时变成现金',
     '违约债权、测试认可价值、回收现金和损失是四种不同金额。',
     (C('记录违约本金及违约日期', '正常资产本金减少，违约债权增加；这一天没有因此收到现金。'),
      C('确定回收金额及收款日期', '比例路径使用 recovery rate 与 lag；明确事件可输入分期回收安排。'),
      C('到回收日期才收现金', '回收款进入本金收款；不会恢复为正常资产本金。'),
      C('处理没有收回的债权', '比例路径按规则结清并记损失；明确事件按回收 / write-off 记录处理。')),
     (C('一笔违约的时间线', '例：1 月 15 日违约本金 10，回收率 60%，延迟 6 个月。\n1 月 15 日：正常本金减 10，违约债权加 10，现金为 0。\n7 月 15 日：实际回收现金 6，损失 4，债权结清。\n6 个月内不能把预计回收 6 提前花掉。', 'explain'),
      C('明确日期事件怎样处理', '指定全额提前还款：还剩余本金及已赚未收合同利息，未来流取消。\n指定全额违约：转入违约债权，未来正常付款取消。\n事件与正常付款同日时，先处理当日正常付款，再处理剩余本金，避免重复还本。', 'explain'),
      C('预测结束不等于债权消失', '比例回收率为 0，仍在设定日期结清并记损失。明确事件未回收部分须有明确 write-off，不能自动消失。\n回收日期在预测范围之后：仍是待回收权利。已出售违约债权：取消其未来回收，避免收两次。', 'caution')),
     'CLO Assumptions：比例 recovery / lag；Asset Schedules：明确事件及分期回收日期。',
     'Waterfall：defaults、recoveries、losses；资产及违约债权的期末余额。',
     'credit/overlay.py；credit/engine.py:100-181；clo/engine.py:459-510', '资产收款'),
Page('CLO 账户：收到的钱与能用的钱',
     '已收到但暂不能分配的现金仍然是真实现金；账户之间转移不会新增收款。',
     (C('按实际到账日登记收款', '通常利息进利息账户；正常还本、提前还本和回收进本金账户。'),
      C('按收款截止日确定本期可用金额', '截止日前收到的释放为可用现金；之后已收到的暂留待释放账户。'),
      C('计算已收现金的银行利息', '可用与待释放现金按实际持有时间计息；受限储备不纳入这项计息。'),
      C('进入本期分配', '只能花已释放且获准使用的现金；未收到的未来利息 / 回收不是现款。')),
     (C('截止日例子', '例：收款截止日 20 日，CLO 付款日 25 日。\n18 日收到本金 10：本期可用。23 日收到本金 5：已到账但本期正常分配不可用。\n贷款本金已减少 15；现金共增加 15。若 OC 设置纳入本金现金，待释放的 5 也计 OC，但仍不能提前花。', 'explain'),
      C('特殊情况：购入应计利息退回本金', '借款人支付利息 100、本金 20；若明确指示把利息中的 30 退回本金账户，则利息账户 70、本金账户 50。\n总现金仍是 120；贷款本金只减少 20。这个归类操作既不是新增收款，也不是额外还本。', 'explain'),
      C('归类权限及最终一期', '购入应计利息退回本金必须有来源并属于受支持组合；当前不能与原池比例信用调整一起启用，也不自动由购入成本推断。\n最后一期用付款日作为收款截止日。现金账户利息按所选方法计算，在分配日单独入账。', 'caution')),
     'CLO Assumptions：截止日、账户计息与开账余额；特殊 accrued 分类由对应有来源的输入控制。',
     'Waterfall：available / pending interest、principal、cash earnings、reserve。',
     'clo/engine.py:459-558,1210-1250；clo/proceeds.py；clo/models.py:590-612', '账户'),
Page('分配前：先算费用和每层 note 应付利息',
     '应付款先算清楚，再按现金余额决定付多少；“应付”和“实际支付”必须分开。',
     (C('计提费用及管理费', '本期费用加历史欠款；采用输入的年费率、计息天数和本金基数。'),
      C('计提每层 note 的本期票息', '用期初本金及本期合同利率；另加应支付的历史欠息与适用的欠息利息。'),
      C('处理 note 的 PIK', 'PIK 先增加 note 本金；现金票息及未付欠息另列，避免重复计算。'),
      C('先用利息付两项靠前费用', '先 senior expenses，再 senior management fee；不足时按规则使用储备补这两项。')),
     (C('管理费和票息的手算', '例：资产本金 100m，senior management fee 年率 0.15%，本期 90/360。费用 = 37,500。\nNote 期初本金 50m、年率 3%，同样 90/360，票息 = 375,000。\n付款日还本 2m，不倒改本期已计提的 375,000。', 'explain'),
      C('每种费用在什么位置', 'Senior expenses、senior management fee 靠前支付。\n超费用优先上限的部分留为递延费用，在 notes 的利息节点之后按条件支付；其后是 subordinated management fee。\n初始费用、call / refi 费用、incentive fee 另处理。', 'explain'),
      C('余额不足时发生什么', '没付清的费用及票息按政策留下欠款。费用 priority cap 改变付款位置，不免除费用。\n当前储备只能补两项靠前费用，不直接补 note 票息。欠息是否保留、是否按票息率计息由独立设置决定；关闭保留是敏感性假设。', 'caution')),
     'CLO Assumptions：各类费用、基数 / day count / cap、欠息政策；Capital Stack：note 利率与 PIK 条款。',
     'Waterfall：每种 due / paid / unpaid；每层 coupon、PIK、opening / ending principal。',
     'clo/engine.py:558-653,1104-1140,1197-1208', '费用与覆盖率'),
Page('OC：资产认可金额能否覆盖债务',
     'OC（本金覆盖率）比较“规则认可的资产及本金现金”和“该层及更优先层的债务”。',
     (C('确定正常资产的认可价值', '根据所选 OC 模式处理 CCC、折价、期限过长等资产。'),
      C('加入违约债权认可价值及本金现金', '只有配置允许的实际本金现金纳入；违约认可价值不是回收现金。'),
      C('计算该层的债务基数', '加总本层及所有更优先 notes 的剩余本金，再加配置认可的递延欠息。'),
      C('除出 OC，并与该层门槛比较', '例如 1.25 倍 = 125%；分配后的本金 / 欠息变化会改变后续 OC。')),
     (C('最简单的 OC 例子', '认可资产 110、本金现金 10、债务 100：\nOC = (110 + 10) / 100 = 1.20 倍。\n门槛 1.25 倍，所以失败。\n若测试 B 层，债务基数包括 A + B，不是只取 B。本金现金是否计入由单独开关决定。', 'explain'),
      C('逐资产估值与总体假设', '逐资产模式：CCC 超限部分优先选当前估值（mark）最低的资产折价；折价资产用购入价格；期限过长资产按输入政策认可。\n同一份本金同时触发多类调整，取最严格认可价值一次。总体比例模式按汇总假设调整，是另一种简化情景。', 'explain'),
      C('递延欠息与测试时点', '当前默认 OC 包含适用的未付可递延票息。不可递延欠息不因此变成本金基数。实际 PIK 已进入 note 本金，不能再加一次。\nGATE 测本层付息后；PERIOD_END 测全部分配后。两者不能替代。', 'caution')),
     'Collateral Pool：逐资产分类与 OC mark；CLO Assumptions：OC 政策；Capital Stack：每层门槛。',
     'Waterfall / CLO Analysis：OC numerator、denominator、ratio、limit、status、headroom。',
     'clo/lifecycle.py:94-196；clo/engine.py:1254-1323', '费用与覆盖率'),
Page('IC：本期利息够不够支付债务利息',
     'IC（利息覆盖率）检查本期利息偿付能力；它与 OC 的本金保护问题不同。',
     (C('汇总本期符合规则的可用利息', '期初可用利息、已释放资产利息、银行利息；不加入尚未收到的未来收入。'),
      C('扣两项靠前费用的应付款', '扣 senior expenses 及 senior management fee；加回实际用于这些费用的储备提款。'),
      C('汇总本层及更优先层的应付票息', '本期 coupon、适用的历史欠息及欠息利息；按递延欠息的 IC 开关处理。'),
      C('除出 IC，并与该层门槛比较', '本期债务服务金额固定，不因今天付掉票息或还本而减少。')),
     (C('IC 的手算', '可用利息 10，靠前费用应付 1，无需储备提款：IC 分子为 9。\n相关债务本期应付利息 8。IC = 9 / 8 = 1.125 倍，低于 1.20 门槛，失败。\n若利息仅 0.80、费用 1、储备补 0.20，费用付清，但 IC 分子为 0。', 'explain'),
      C('还本为什么不能立刻修复本期 IC', '今天偿还 note 本金，可以减少下一期票息。\n但本期票息已经按期初本金计提，不会因付款日还本而消失。因此不能把降低未来票息说成今天的 IC 已经通过。购买新资产的未来利息也不能补今天的 IC。', 'explain'),
      C('当前采用的利息口径', '当前模型按已收到且本期可用的现金计算；某些实际交易使用 determination date 的预期收入等合同口径，需另映射。\n“Include Deferred Interest in IC” 控制历史递延票息本金是否计入，不取消本期票息或适用的欠息利息。', 'caution')),
     'Capital Stack：每层 IC 门槛与票息；CLO Assumptions：费用、reserve、递延欠息 IC 政策。',
     'Waterfall / CLO Analysis：IC numerator、denominator、ratio、status；不等于剩余利息账户余额。',
     'clo/engine.py:611-655,1270-1323', '费用与覆盖率'),
Page('利息 waterfall：逐层付款，失败时怎样处理',
     '先付本层票息，再测本层 IC / OC；通过后才进入更靠后的层级。',
     (C('付最优先 note 的票息', '按当前可用利息付款；未付部分留在适用的欠息记录中。'),
      C('检查该层 IC / OC', '通过：进入下一层票息节点。失败：暂停更 junior 的利息分配。'),
      C('失败时按已选规则处理剩余利息', '选择全部偿债、仅修复 OC，或关闭分流。', 'caution'),
      C('允许继续时，重复下一层', 'A → B → C 的每一层，都有自己的票息节点和测试节点。'),
      C('所有允许的层级完成后', '付递延费用、subordinated management fee；余额只是初步 equity 利息，尚非最终分配。')),
     (C('仅修复 OC 并继续', '只有 IC 未失败时，才可使用 CURE_OC_AND_CONTINUE。\n例：OC 分子 120、债务 100、门槛 1.25。用剩余利息还债 4，债务降到 96，OC = 120 / 96 = 1.25。实际复测通过，才继续 junior 票息。', 'explain'),
      C('其余失败分支', 'ALL_RESIDUAL：剩余利息按优先级偿还该层及更 senior 的本金，本次不自动恢复 junior 票息。\nIC 失败：不能采用“少量还本就修复本期 IC”。\nDiversion 关闭：阻断 junior 并保留现金。', 'explain'),
      C('哪些钱不能跳过谁', '失败节点只能授权偿还该层及更优先层的 notes，不能跳过 junior 未付票息直接偿还该 junior 本金。\n需要修复的最少金额向上取到分，再按实际付款结果复测。未到达的 junior GATE 不得显示成已通过。', 'caution')),
     'CLO Assumptions：coverage / diversion 模式；Capital Stack：优先级、IC / OC 门槛。',
     'Waterfall：interest-paid coupon、interest-funded redemption、GATE / POST_DIVERSION、blocked。',
     'clo/engine.py:660-715,1142-1156', '利息分配'),
Page('独立 IDT：保留部分 equity 利息用于再投资',
     'Interest Diversion Test 的转账不是偿还 notes：钱转入本金账户，债务本金暂不改变。',
     (C('在较靠后费用支付后检查 IDT', '使用指定测试层的 OC 型门槛；只在配置的有效窗口内执行。'),
      C('若失败，计算需要转入的本金现金', '目标是提高测试分子；与“用利息还债、降低分母”不同。'),
      C('受 equity 利息余额和比例上限限制', '最多转走允许的比例；资金不足时只能部分补足，不保证完全达标。'),
      C('实际转账并保留用途标记', '利息余额减少、本金余额增加，总现金不变；随后只能按授权再投资或释放。')),
     (C('转账受到上限约束', 'OC 型分子 120、债务 100、门槛 1.25，需增加分子 5。\n初步 equity 利息 8，最多转走 50%，因此实际转 4。\n转账后分子 124、债务仍 100，仍有缺口 1。不能直接假定 IDT 一定 cure。', 'explain'),
      C('三种操作为什么金额不同', '三个独立例子；各自有足够现金且无其他消耗。均从资产 100 + 本金现金 20、债务 100、门槛 1.25 开始：\n用利息还债：还 4，得到 120 / 96。\n用已计 OC 的本金现金还债：还 20，得到 100 / 80。\n利息转本金账户：转 5，得到 125 / 100。', 'explain'),
      C('转入的钱怎样继续使用', '暂留 IDT 金额已包含在本金账户里，不能再加一次现金。\n授权购买通过才使用；窗口内未获准购买时继续保留用途标记。窗口结束、call 或最终分配时按规则释放。当前 IDT 位于 subordinated fee 之后，实际交易顺序可能不同。', 'caution')),
     'CLO Assumptions：独立 IDT 开关、测试层、门槛、最大转账比例、截止日。',
     'Waterfall：IDT status、transferred、held diversion principal；状态是转账前的测量。',
     'clo/engine.py:434-438,717-750；docs/methodology/waterfall.md', '利息分配'),
Page('再投资：先检查拟买后的状态，再真正购买',
     '新资产只在购买获准后出现；不能先花钱，再检查是否违反测试。',
     (C('检查是否有再投资权限及现金', '仅用窗口内、已释放且有权限的本金现金。'),
      C('先检查买前 IC / OC 及欠息条件', 'STOP 要求买前测试通过，且无剩余欠息。'),
      C('计算拟购买面值、价款和到期日', '先做只读计划，不扣现金、不增加资产。'),
      C('检查买后 IC / OC，再决定', '通过才购买；失败不扣款，也不新增资产。'),
      C('更新当前资产价值，预测新资产', '即时刷新 OC；新资产使用独立信用参数。')),
     (C('折价买入：现金不等于面值', '获准可用现金 99,000，购买价格 99%，可买面值 100,000。\n现金减少 99,000；新增资产本金 100,000。\n购买当天不会补出购买前的 coupon。小额舍入残余仍留账户，不会丢失。', 'explain'),
      C('买前通过，买后也可能失败', '资产 90 + 本金现金 10、债务 80、门槛 1.25：买前正好通过。\n若按 101% 用 10 买约 9.90 面值，买后约 99.90 / 80 = 1.24875，失败。STOP 拒购；普通未用本金继续按后面的本金优先级处理。', 'explain'),
      C('当前再投资是什么', '最终期或已执行退出不再投资。当前使用 synthetic 贷款模板，不是自动执行真实 BSL 交易。新购贷款的 CDR / CPR / recovery / lag 独立于原池。\nALWAYS 是测试敏感性 override，不等于法律许可；仍受日期、现金、期限及分类数据限制。拒购后当前不自动搜索较小购买量。', 'caution')),
     'CLO Assumptions：再投资窗口、模板 price / spread / WAL、信用参数、STOP / ALWAYS、循环权限。',
     'Waterfall：再投资现金 / 面值及剩余本金账户；购买明细保留舍入余款。',
     'clo/engine.py:847-925；clo/reinvestment.py:284-349,361-444', '本金分配'),
Page('本金 waterfall：补欠款，再投资，再去杠杆',
     '资产还本不会自动等额偿还 notes；先按权限支付欠款和购买，再分配剩余本金。',
     (C('先补两项 senior 费用欠款', '先补 senior expenses 与 senior management fee 欠款。'),
      C('按权限补 note 欠息', '按本金补息权限执行，不一律先付全部 junior 欠息。'),
      C('处理最终期保护与允许的再投资', '最终期先保护债务；合格再投资按第 12 页执行。'),
      C('用普通剩余本金偿还 notes', '按顺序或合格的比例模式还本；暂留 IDT 另保留。'),
      C('债务及必要欠款清偿后才向后分配', '清偿后付靠后费用，再向 equity 分配本金余款。')),
     (C('顺序与比例的手算', '假设测试通过且无欠息。A 本金 50、B 本金 40；可用还本现金 10。\n顺序：A 收 10，B 收 0。\n按比例：A 收 5.56，B 收 4.44。\n舍入差额按规则分配，保证合计 10。', 'explain'),
      C('哪些情况强制按顺序', '测试失败或仍有欠息时，普通本金按顺序分配。默认权限允许先补不可递延欠息；可递延的 junior 欠息通常等更优先本金还清、轮到该层时才补。\n利息出资的覆盖率补救始终按优先级，不受 pro rata 设置改变。', 'explain'),
      C('新购资产回款能否再次再投资', '禁止新购回款再次再投资时，仅用原池合格正常 / 提前还本、暂留 IDT 和明确获准的应计利息归回本金。\n回收与新购回款不自动获准。许可不是额外现金；买卖后先更新 OC 再还本。', 'caution')),
     'CLO Assumptions：本金偿还模式、principal coupon policy、再投资循环权限；Capital Stack：seniority。',
     'Waterfall：principal-funded coupon、principal-funded redemption、closing note principal、equity principal。',
     'clo/engine.py:806-945,1158-1195', '本金分配'),
Page('特殊事件：提前结束、再融资与法定到期',
     '卖资产、修改融资条款、到期结束是不同事件；只有实际执行的事件才改变收款和持仓。',
     (C('识别本期有没有退出或再融资安排', '请求日期对应首个不早于该日期的实际 CLO 付款日；不是任意日重开模型。'),
      C('Call 或到期出售：先算真实出售款', '正常资产与违约债权使用各自出售价格；call 要有足够资金清偿全部相关债务和费用。'),
      C('实际出售才移除资产及未来权利', '售出资产不再计 OC；售出违约债权不能继续收未来 recovery。'),
      C('另一路：未退出时处理 refi', '只有未执行 call 或最终清算时才处理。费用由 equity 当日追加出资支付，新 spread 下期生效。')),
     (C('Call 失败与成功', '资金不足：不执行出售，保留资产继续预测。本次请求只尝试一次，不在以后每期自动重试。\n资金足够：实际处置、扣 costs、按规则清偿，剩余才可分给 equity。\n不得把“假设能卖多少”直接加进 equity IRR。', 'explain'),
      C('Refi 与最终到期的区别', '当前 refi 保留 note 本金、优先级及到期日，只调整浮动 spread 并计费，不是完整重新发行。\n最终期只有设置清算价格才假设出售；0 表示按零价格出售，无价格不制造清算现金。', 'explain'),
      C('退出时仍要保护债权', '处置款进入本金分配；已实际收到的待释放现金按终止规则处理。最终剩余利息先保护未清债务。\n本金、票息、费用或回收权利仍未解决时，必须保留未解决状态；不能因预测到了最后一行就把它们抹掉。', 'caution')),
     'CLO Assumptions：optional call、出售价格、refi 日期 / spread reduction / fee、maturity liquidation price。',
     'Waterfall：call status、sale proceeds、refi fee、equity contribution、terminal status。',
     'clo/engine.py:755-844,947-986；clo/lifecycle.py', '特殊事件'),
Page('Incentive fee：超过投资者门槛回报的部分才收费',
     '当前模型维护一个“尚未收回的资本及门槛回报余额”，不是看到 IRR 达标就对全部现金收费。',
     (C('记录真实 equity 出资', '初始余额使用实际已付资金，不用 equity 名义本金。'),
      C('让尚未满足的余额按 hurdle 增长', '使用年有效门槛回报率及实际天数 / 365；当日新增出资随后加入。'),
      C('比较本次可分配现金与门槛余额', '仅超出余额的部分乘 incentive fee rate；未超出时费用为零。'),
      C('扣费用，再记录投资者实收', '费用依次从利息、本金、最终储备余款扣；净分配减少门槛余额。')),
     (C('单期例子最容易理解', '实际初始出资 100，一年 hurdle 10%，余额增至 110。\n本次可分余款 120（扣激励费前），费率 20%：\n超额 = 120 - 110 = 10；费用 = 10 × 20% = 2。\nEquity 实收 118，门槛余额归零。', 'explain'),
      C('前一期没收够，会带到下一期', '每期恰好 365 天，出资 100、hurdle 10%。\n第一期可分 8：费用 0，门槛余额为 110 - 8 = 102。\n第二期先增长到 112.20，再加当日出资 5，余额 117.20。若可分 120，费用 0.56，实收 119.44；扣新出资后净现金 114.44。', 'explain'),
      C('它不是所有交易的通用收费条款', '当前为明确的超额部分收费机制。真实合同可能达到 IRR 门槛后对全部余款收费，或另设 catch-up。\n存续开账因缺完整历史门槛初始化，当前不支持开启 incentive。IRR 使用实际日期和净现金；初步余款不是最终投资者实收。', 'caution')),
     'CLO Assumptions：incentive 开关、hurdle rate、fee rate；实际出资由资金计算 / refi 提供。',
     'Waterfall：incentive paid、hurdle balance、equity contribution / net distribution；CLO Analysis：equity IRR。',
     'clo/lifecycle.py:200-259；clo/engine.py:989-1001；clo/opening.py', 'Equity 回报'),
Page('每期结束：怎样确认结果没有漏钱或重复还本',
     '现金、本金和欠款分别核对；期末 OC 通过，不代表中间付款或购买一定正确。',
     (C('核对实际现金的来源与去向', '期初现金 + 本期收到 + 银行利息 + 新出资 = 实际支付 + 期末现金。账户转移不算新增收入。'),
      C('核对资产与违约债权', '正常本金、PIK、正常还本、提前还本、违约、购买、出售分别解释。\n回收不恢复正常本金。'),
      C('核对每层 note 本金及未付票息', '还本只减少 note 本金；票息支付减少票息欠款，不再次算还本。'),
      C('保存各阶段，再进入下一期', '记录实际到达的测试、分流后状态和期末状态；余额成为下一期期初。未解决问题继续保留。')),
     (C('最重要的三个本金 / 欠款桥', '正常资产：期初 + PIK + 购买 - 正常还本 - 提前还本 - 违约 - 出售 = 期末。\nNote：期初 + note PIK - 利息出资还本 - 本金出资还本 = 期末。\n票息欠款：期初 + 本期新增应付 - 实际票息支付 - 明确豁免 = 期末。', 'explain'),
      C('在 Excel 怎样 review', '先选同一个 case、日期及 tranche。\nAsset Cashflows 看合同参考；Waterfall 看信用调整后实收及每层 opening / ending、due / paid、IC / OC 及 diversion；CLO Analysis 看组合、限额及 equity 回报；Checks 看错误与未配置项。', 'explain'),
      C('状态不是同一个意思', 'PASS：已执行且通过。FAIL：已执行且失败。BLOCKED：被前面节点阻断。NOT_CONFIGURED：没设参数。NOT_APPLICABLE：当前不适用。UNAVAILABLE：缺必要数据。\n下拉选不同日期只筛选已保存结果，不从该日期重新计算或重置 IRR。', 'caution')),
     '本页不增加输入；必要时回到对应拥有者页核对原始条款、金额、日期和来源。',
     'Waterfall 完整每期每层记录；CLO Analysis 汇总；Checks 核对；未结清终态不得显示为已完成。',
     'clo/engine.py:967-1093；docs/user_guide.md；docs/readiness.md', '结果核对'),
Page('术语、来源和当前适用范围',
     '先用中文动作理解流程，再查英文字段、代码和具体交易条款。不要把流程图当作交易法律文件。',
     (C('Collateral / asset：CLO 持有的贷款', 'BSL 或 Infra loan 向 CLO 支付利息和本金，是资产端。'),
      C('Note / tranche：CLO 发行的债务层级', 'CLO 按优先级向 notes 付票息和还本，是负债端；equity 收最终余款。'),
      C('Cure / diversion / deleverage', 'Cure：补救失败测试。\nDiversion：改变剩余资金用途。\nDeleverage：偿还债务、降低杠杆。'),
      C('从实现追踪到输入和条款', '代码定义当前执行；输入决定参数；实际交易条款决定是否适用；独立手算与对账检验结果。')),
     (C('本指南的核对依据', '合同与信用：cashflows / credit。\n账户与付款：clo/engine.py。\nOC 及激励费：clo/lifecycle.py。\n再投资 / 开账 / 资金：对应同名模块。', 'explain'),
      C('公开交易文件的用途', 'OCP Euro CLO 2017-1，2026 年 1 月发行文件：覆盖率、付款顺序、费用条款的对照。\nInvesco Euro CLO I，2026 年 6 月发行文件：购买权限、买前 / 买后测试及具体例外的对照。\n下面两个链接可点击；并不表示当前模型逐条采用这些交易的规则。', 'explain'),
      C('范围清楚，模型才容易用', '当前无随机违约 / 相关性模拟；再投资为经济模板；存续只支持付款日分配后开账。\n真实交易仍须核对条款、评级 / recovery 来源及 trustee 数据；软件测试和通用流程不代表全部合同条件已满足。', 'caution')),
     '详细输入操作：docs/user_guide.md；完整定义：docs/methodology/waterfall.md；边界：docs/readiness.md。',
     '本指南、可搜索文字版及核验记录一致维护；本次重新说明流程，不改变模型计算或 Excel。',
     '当前实现 0.12.3；docs/waterfall_review.md；公开交易文件仅作条款交叉参考', '术语与来源'),
)

LINKS = (
('OCP 2026：发行文件', 'https://ise-prodnr-eu-west-1-data-integration.s3-eu-west-1.amazonaws.com/202601/07d64e17-e59d-4980-b089-0096b0ee4bc1.pdf'),
('Invesco 2026：发行文件', 'https://ise-prodnr-eu-west-1-data-integration.s3-eu-west-1.amazonaws.com/202606/af267c52-cb3c-4250-8e12-fa114a500e55.pdf'),
)

PALETTE = {
'flow': ('#EDF6F3', '#247968'),
'explain': ('#F1F5FA', '#195C87'),
'caution': ('#FFF5DE', '#986721'),
}
NAVY = colors.HexColor('#18334D')
GREY = colors.HexColor('#536577')

class WaterfallGuide:
    """Draw one topic per page without shrinking body text or hiding overflow."""

    def __init__(self, path: Path) -> None:
        pdfmetrics.registerFont(TTFont('GuideCN', 'C:/Windows/Fonts/msyh.ttc', subfontIndex=0))
        pdfmetrics.registerFont(TTFont('GuideCNBold', 'C:/Windows/Fonts/msyhbd.ttc', subfontIndex=0))
        pdfmetrics.registerFont(TTFont('GuideArial', 'C:/Windows/Fonts/arial.ttf'))
        self.width, self.height = landscape(A4)
        self.margin = 30
        self.canvas = canvas.Canvas(str(path), pagesize=(self.width, self.height), pageCompression=1, invariant=1)
        self.canvas.setTitle('Project Trident - Waterfall 中文阅读指南与流程图')
        self.canvas.setAuthor('')
        self.canvas.setCreator('Project Trident')
        self.canvas.setSubject('当前计算步骤、中文释义、独立例子及适用边界')
        self.measurements: list[dict] = []
        self.page_number = 0

    def para(self, text: str, width: float, size: float = 11.6, *, bold: bool = False, color=NAVY) -> tuple[Paragraph, float]:
        style = ParagraphStyle('GuideBody', fontName='GuideCNBold' if bold else 'GuideCN',
            fontSize=size, leading=size*1.36, textColor=color, wordWrap='CJK', spaceAfter=0)
        para = Paragraph(escape(text).replace('\n', '<br/>'), style)
        _, height = para.wrap(width, self.height)
        return para, height

    def text(self, text: str, x: float, top: float, width: float, size: float = 11.6, *, bold: bool = False, color=NAVY) -> float:
        p, h = self.para(text, width, size, bold=bold, color=color)
        p.drawOn(self.canvas, x, self.height-top-h)
        self.measurements.append({'page':self.page_number, 'kind':'text', 'x':x, 'top':top, 'width':width, 'height':h, 'size':size, 'text':text})
        return h

    def card_height(self, card: Card, width: float) -> float:
        _, th = self.para(card.title, width-26, 12.5, bold=True)
        _, bh = self.para(card.text, width-26)
        return 24 + th + 5 + bh

    def card(self, card: Card, x: float, top: float, width: float, height: float) -> None:
        required = self.card_height(card, width)
        if required > height + .001:
            raise ValueError(f'Page {self.page_number}: overflow in {card.title}: {required:.2f} > {height:.2f}')
        fill, stroke = map(colors.HexColor, PALETTE[card.kind])
        c = self.canvas
        c.setFillColor(fill); c.setStrokeColor(stroke); c.setLineWidth(.7)
        c.roundRect(x, self.height-top-height, width, height, 6, fill=1, stroke=1)
        th = self.text(card.title, x+13, top+10, width-26, 12.5, bold=True, color=stroke)
        self.text(card.text, x+13, top+15+th, width-26)
        self.measurements.append({'page':self.page_number,'kind':'card','title':card.title,'top':top,'height':height,'required':required,'x':x,'width':width})

    def arrow(self, x: float, start: float, end: float) -> None:
        c = self.canvas
        c.setLineWidth(1); c.setStrokeColor(colors.HexColor('#247968')); c.setFillColor(colors.HexColor('#247968'))
        c.line(x, self.height-start, x, self.height-end+4)
        p=c.beginPath(); p.moveTo(x-4,self.height-end+7); p.lineTo(x,self.height-end); p.lineTo(x+4,self.height-end+7); p.close()
        c.drawPath(p,fill=1,stroke=0)

    def coverage_branch(self, page: Page, x: float, top: float, width: float) -> None:
        first=C('先付当前层 note 的票息', '有多少可用利息就按优先级支付，未付部分另记。')
        second=C('检查本层 IC / OC', '本层与更优先层一起测；结果决定后面能否继续。')
        h1=self.card_height(first,width); self.card(first,x,top,width,h1)
        self.arrow(x+width/2,top+h1+2,top+h1+17)
        p2=top+h1+20; h2=self.card_height(second,width); self.card(second,x,p2,width,h2)
        fork=p2+h2+20; gap=14; bw=(width-gap)/2
        children=(C('通过', '有下一层：重复付息和测试。\n没有下一层：进入靠后费用。'),
                  C('失败', '暂停 junior。\n按右侧规则处理剩余利息。\n仅修复 OC 且复测通过，才可恢复。','caution'))
        bh=max(self.card_height(card,bw) for card in children)
        center=x+width/2; cy=self.height-(p2+h2+2); y=self.height-(fork-5)
        self.canvas.setStrokeColor(colors.HexColor('#247968'));self.canvas.setLineWidth(1)
        self.canvas.line(center,cy,center,y+7)
        for index,card in enumerate(children):
            cx=x+index*(bw+gap); midpoint=cx+bw/2
            self.canvas.line(center,y+7,midpoint,y+7)
            self.arrow(midpoint,fork-12,fork-2)
            self.card(card,cx,fork,bw,bh)
        caption='未被阻断：付递延费用，再付 subordinated fee。\n被阻断且未恢复：转入本金流程，不继续 junior 付息。'
        end=fork+bh+14
        height=self.text(caption,x,end,width,11.6)
        if end+height>497: raise ValueError('Coverage branch overflow')

    def event_branch(self, x: float, top: float, width: float) -> None:
        head=C('识别本期特殊事件', '退出处置与 refi 是不同路线；没有安排就继续正常分配。')
        hh=self.card_height(head,width);self.card(head,x,top,width,hh)
        fork=top+hh+28;gap=14;bw=(width-gap)/2
        children=(C('退出处置', 'Call 或最终清算。\n实际卖出才记现金。\n移除售出资产及未来回收。'),
                  C('未退出时的 refi', '保留债务结构。\n普通还本后计费用。\nEquity 追加出资支付。\n新 spread 下期生效。'))
        bh=max(self.card_height(card,bw) for card in children)
        center=x+width/2; y=self.height-(fork-5)
        self.canvas.setStrokeColor(colors.HexColor('#247968'));self.canvas.setLineWidth(1)
        self.canvas.line(center,self.height-(top+hh+2),center,y+7)
        for index,card in enumerate(children):
            cx=x+index*(bw+gap);midpoint=cx+bw/2
            self.canvas.line(center,y+7,midpoint,y+7)
            self.arrow(midpoint,fork-12,fork-2)
            self.card(card,cx,fork,bw,bh)
        note=C('执行了什么，就只记录对应变化', 'Call 未执行时保留资产。Call 成功或最终清算时不再 refi。所有实际收款和费用仍经过付款优先级，不直接当作 equity 收益。','caution')
        pos=fork+bh+23;nh=self.card_height(note,width)
        self.card(note,x,pos,width,nh)
        if pos+nh>497: raise ValueError('Event branch overflow')

    def draw_page(self, page: Page, number: int) -> None:
        self.page_number=number
        c=self.canvas; W,H=self.width,self.height; M=self.margin
        key=f'page_{number:02d}'
        c.bookmarkPage(key)
        c.addOutlineEntry(f'{number:02d} {page.title}',key,level=0)
        self.text('PROJECT TRIDENT  |  WATERFALL',M,16,450,9.0,color=GREY)
        self.text(f'{page.group}  |  0.12.3  |  2026-10-08',W-300,16,270,9.0,color=GREY)
        self.text(f'{number:02d}  {page.title}',M,38,W-2*M,22,bold=True)
        c.setStrokeColor(colors.HexColor('#D6E1EA'));c.line(M,H-77,W-M,H-77)
        mh=self.text(page.message,M,86,W-2*M,12.6,bold=True)
        if mh > 36: raise ValueError(f'Page {number}: message needs extra line')
        top=124; bottom=497; available=bottom-top
        lane=(W-2*M-24)/2
        left=M; right=M+lane+24
        required=[self.card_height(card,lane) for card in page.steps]
        gap=14 if len(page.steps)>4 else 19
        total=sum(required)+gap*(len(required)-1)
        if total>available and number not in (10,14): raise ValueError(f'Page {number}: flow needs {total}, available {available}')
        extra=min(10,(available-total)/len(required))
        pos=top
        if number==10: self.coverage_branch(page,left,top,lane)
        if number==14: self.event_branch(left,top,lane)
        for idx,(card,height) in enumerate(zip(page.steps if number not in (10,14) else (),required)):
            height+=extra
            self.card(card,left,pos,lane,height)
            end=pos+height
            if idx<len(page.steps)-1: self.arrow(left+lane/2,end+2,end+gap-2)
            pos=end+gap
        panels=[self.card_height(card,lane) for card in page.explanations]
        total=sum(panels)+12*(len(panels)-1)
        if total>available: raise ValueError(f'Page {number}: explanations need {total}, available {available}')
        pos=top
        for card,height in zip(page.explanations,panels):
            self.card(card,right,pos,lane,height)
            pos+=height+12
        if number==17:
            for idx,(label,url) in enumerate(LINKS):
                x=M+idx*(lane+24); y=505
                self.text(label,x,y,lane,10.1,color=colors.HexColor('#195C87'))
                c.linkURL(url,(x,H-y-16,x+lane,H-y),relative=0,thickness=0)
        c.setStrokeColor(colors.HexColor('#D6E1EA'));c.line(M,H-526,W-M,H-526)
        self.text('输入：'+page.inputs,M,534,W-2*M,9.1)
        self.text('输出：'+page.outputs,M,553,W-2*M,9.1)
        self.text('实现依据：'+page.sources,M,574,W-2*M-62,8.2,color=GREY)
        c.setFont('GuideArial',9.2);c.setFillColor(GREY);c.drawRightString(W-M,11,f'{number} / {len(PAGES)}')
        # Annotation gives a stable navigation route without taking flow space.
        if number>1: c.linkRect('', 'page_01',(M,H-32,M+250,H-14),relative=0,thickness=0)
        c.showPage()

    def build(self) -> None:
        for index,page in enumerate(PAGES,1): self.draw_page(page,index)
        self.canvas.save()


def markdown() -> str:
    sections=['# Waterfall 中文阅读指南与流程图','',
        '对应当前 0.12.3 实现。更新：2026-10-08。主流程、释义、独立示例和适用边界分开阅读。',
        '配套 PDF：[中文流程图](../outputs/Project_Trident_Waterfall_Flowcharts_CN.pdf)。本指南重新说明当前流程，不改变计算和工作簿。','']
    for number,page in enumerate(PAGES,1):
        sections.extend([f'## {number:02d}. {page.title}','',page.message,'','计算顺序：',''])
        for index,card in enumerate(page.steps,1): sections.extend([f'{index}. **{card.title}**：{card.text}',''])
        for card in page.explanations: sections.extend([f'### {card.title}','',card.text,''])
        sections.extend(['输入：'+page.inputs,'','输出：'+page.outputs,'','实现依据：`'+page.sources.replace('；','`；`')+'`。',''])
    sections.extend(['公开参考：','']+[f'- [{label}]({url})' for label,url in LINKS]+[''])
    return '\n'.join(sections)


def digest(path: Path) -> str:
    return sha256(path.read_bytes()).hexdigest()


def main() -> None:
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--stage-dir',type=Path,default=Path(tempfile.gettempdir())/'trident-waterfall-guide-cn-20261008')
    parser.add_argument('--write-text',action='store_true',help='Synchronize the searchable current guide.')
    args=parser.parse_args(); args.stage_dir.mkdir(parents=True,exist_ok=True)
    pdf=args.stage_dir/OUTPUT_NAME
    guide=WaterfallGuide(pdf); guide.build()
    reader=PdfReader(pdf)
    if len(reader.pages)!=len(PAGES): raise ValueError('Unexpected page count')
    records=[]
    document=pdfium.PdfDocument(str(pdf))
    for number,page in enumerate(document,1):
        out=args.stage_dir/f'page_{number:02d}.png'
        page.render(scale=2).to_pil().save(out)
        text=reader.pages[number-1].extract_text()
        if PAGES[number-1].title not in text: raise ValueError(f'Missing title on page {number}')
        records.append({'page':number,'title':PAGES[number-1].title,'characters':len(text),'png':str(out),'png_sha256':digest(out)})
        page.close()
    document.close()
    # Bounding checks cover all measured text, including navigation/footer lines.
    for item in guide.measurements:
        if item['kind']=='text' and (item['top']<0 or item['top']+item['height']>guide.height-7):
            raise ValueError(f'Text outside page: {item}')
    financial_paths=sorted((ROOT/'src'/'trident').rglob('*.py'))
    manifest={'status':'STAGED_AWAITING_REVIEW','pdf':str(pdf),'pdf_sha256':digest(pdf),
        'pages':records,'page_count':len(PAGES),'minimum_body_font':11.6,
        'measurements':guide.measurements,
        'financial_source_hashes':{str(path.relative_to(ROOT)):digest(path) for path in financial_paths},
        'workbook_sha256':digest(ROOT/'outputs'/'Project_Trident.xlsx')}
    (args.stage_dir/'review_manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
    if args.write_text: (ROOT/'docs'/'waterfall_guide_cn.md').write_text(markdown(),encoding='utf-8')
    print(json.dumps({'status':manifest['status'],'pages':len(PAGES),'pdf':str(pdf),'sha256':manifest['pdf_sha256'],'characters_per_page':[r['characters'] for r in records]},ensure_ascii=False))

if __name__=='__main__': main()
