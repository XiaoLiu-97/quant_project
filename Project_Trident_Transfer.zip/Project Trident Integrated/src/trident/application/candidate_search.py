"""Evaluate a bounded set of closing pools through the complete CLO model.

LP/MILP factor or spread proposals are candidate generators. Investor IRR is
measured from each candidate's independently projected funding and waterfall,
never substituted by spread. The selected candidate is best only within this
explicit finite set and one configured economic scenario. Dated trading, agency
rating calibration and global nonlinear optimality are outside this service.
"""

from dataclasses import dataclass, replace
from decimal import Decimal
from enum import Enum
from fractions import Fraction

from trident.analysis import MetricResult, MetricStatus, ReturnResult, ReturnStatus
from trident.domain.models import InputValidationError, require_decimal, require_money
from trident.domain.numeric import decimal_fraction
from trident.market.rates import (
    CurveRangeError, CurveRateProvider, FlatRateProvider, MissingCurveError,
    ProjectedRateCurve, RatePoint, RequiredFixingError,
)
from trident.market.cash_accounts import CashCurveRateProvider, DiscountFactorCashCurve, ZeroRatePoint
from trident.optimization import OptimizationObjective, OptimizationRequest, StaticTradeOptimizer
from trident.optimization.universe import CandidateAdmissionPolicy, CandidateUniverseSnapshot

from .clo_services import TridentModelRequest, TridentModelResult, TridentModelService, ModelProjectionRunner
from .construction import (
    ClosingPoolRedesignRequest, ClosingPoolRedesignResult, ClosingPoolRedesignService,
)


class CandidateSelectionPolicy(str, Enum):
    MAX_EQUITY_IRR = "MAX_EQUITY_IRR"
    MIN_FACTOR_THEN_IRR = "MIN_FACTOR_THEN_IRR"


class CandidateSearchStatus(str, Enum):
    COMPLETED = "COMPLETED"
    NO_ELIGIBLE_CANDIDATE = "NO_ELIGIBLE_CANDIDATE"


@dataclass(frozen=True)
class CandidateSearchVariant:
    """One named epsilon-constraint proposal; overrides only tighten a mandate.

    Factor values retain the selected methodology's units; spread is in bps,
    turnover is gross traded par in EUR. None preserves the base mandate.
    """

    candidate_id: str
    objective: OptimizationObjective
    maximum_overall_factor: Decimal | None = None
    maximum_bsl_factor: Decimal | None = None
    minimum_spread_bps: Decimal | None = None
    maximum_trade_par: Decimal | None = None

    def __post_init__(self) -> None:
        _candidate_id(self.candidate_id)
        if not isinstance(self.objective, OptimizationObjective):
            raise InputValidationError("candidate objective must be OptimizationObjective")
        for name in ("maximum_overall_factor", "maximum_bsl_factor", "minimum_spread_bps"):
            value = getattr(self, name)
            if value is not None:
                require_decimal(value, name, minimum=Decimal(0))
        if self.maximum_trade_par is not None:
            require_money(self.maximum_trade_par, "maximum_trade_par")


def _candidate_id(value: object) -> None:
    if not isinstance(value, str) or not value or value != value.strip():
        raise InputValidationError("candidate_id must be nonempty, unpadded text")
    if value.casefold() in {"baseline", "no_trades"}:
        raise InputValidationError("BASELINE and NO_TRADES candidate IDs are reserved")


@dataclass(frozen=True)
class ClosingPoolSearchRequest:
    """Frozen common mandate, finite variants and explicit selection priorities.

    ``minimum_equity_irr`` is an annual fraction and a hard optional mandate.
    ``irr_comparison_tolerance`` is only ranking resolution, never a breach
    tolerance. ``max_variants`` bounds deliberate candidate work; every distinct
    target still needs a complete CLO replay, so it is not a free solver grid.
    """
    baseline: TridentModelRequest
    base_mandate: OptimizationRequest
    candidate_snapshot: CandidateUniverseSnapshot
    admission_policy: CandidateAdmissionPolicy
    variants: tuple[CandidateSearchVariant, ...]
    selection_policy: CandidateSelectionPolicy = CandidateSelectionPolicy.MAX_EQUITY_IRR
    minimum_equity_irr: Decimal | None = None
    irr_comparison_tolerance: Decimal = Decimal("1e-10")
    max_variants: int = 100

    def __post_init__(self) -> None:
        for value, value_type, label in ((self.baseline, TridentModelRequest, "baseline"),
                (self.base_mandate, OptimizationRequest, "base_mandate"),
                (self.candidate_snapshot, CandidateUniverseSnapshot, "candidate_snapshot"),
                (self.admission_policy, CandidateAdmissionPolicy, "admission_policy")):
            if not isinstance(value, value_type):
                raise InputValidationError(f"{label} must be {value_type.__name__}")
        if type(self.variants) is not tuple or not self.variants or any(
            not isinstance(row, CandidateSearchVariant) for row in self.variants
        ):
            raise InputValidationError("variants must be a nonempty immutable tuple of CandidateSearchVariant")
        if type(self.max_variants) is not int or self.max_variants < 1 or len(self.variants) > self.max_variants:
            raise InputValidationError("Explicit candidate count exceeds positive integer max_variants")
        if len({row.candidate_id.casefold() for row in self.variants}) != len(self.variants):
            raise InputValidationError("Duplicate candidate_id")
        if not isinstance(self.selection_policy, CandidateSelectionPolicy):
            raise InputValidationError("selection_policy must be CandidateSelectionPolicy")
        if self.minimum_equity_irr is not None:
            require_decimal(self.minimum_equity_irr, "minimum_equity_irr")
            if self.minimum_equity_irr <= -1:
                raise InputValidationError("minimum_equity_irr must be greater than -1")
        require_decimal(self.irr_comparison_tolerance, "irr_comparison_tolerance", minimum=Decimal(0))


@dataclass(frozen=True)
class CandidateEvaluation:
    """One candidate plus full solver/replay evidence and explicit exclusion.

    IRR deltas are against the projected NO_TRADES baseline even if that pool
    breaches a mandate. A reported delta is not evidence of eligibility.
    Ranking and frontier include only independently replay-validated candidates.
    exact_factor is a rational comparison value, not a second factor mapping.
    """

    candidate_id: str
    status: str
    eligible: bool
    equity_irr: ReturnResult
    equity_moic: ReturnResult
    factor_metric: str
    factor: MetricResult
    exact_factor: Fraction | None
    equity_irr_delta: Decimal | None
    factor_delta: Decimal | None
    equity_cash_funding: Decimal | None
    equity_distributions: Decimal | None
    gross_trade_par: Decimal | None
    static_ending_cash: Decimal | None
    failure_message: str = ""
    rank: int | None = None
    pareto: bool = False
    replay: ClosingPoolRedesignResult | None = None


@dataclass(frozen=True)
class ClosingPoolSearchResult:
    """Named eligibility/return evidence for the evaluated finite set only."""
    status: CandidateSearchStatus
    selected_candidate_id: str | None
    evaluations: tuple[CandidateEvaluation, ...]
    selection_policy: CandidateSelectionPolicy
    factor_provenance: str
    irr_comparison_tolerance: Decimal
    scope: str = "FINITE_CANDIDATE_CONFIGURED_SCENARIO_CLOSING_POOL_SEARCH"
    optimality_scope: str = "EVALUATED_CANDIDATES_ONLY_NO_GLOBAL_EQUITY_IRR_OPTIMALITY"
    execution_status: str = "NOT_EXECUTED"

    def evaluation(self, candidate_id: str) -> CandidateEvaluation:
        """Retrieve exact named evidence, raising KeyError for an unknown ID."""
        for row in self.evaluations:
            if row.candidate_id == candidate_id:
                return row
        raise KeyError(candidate_id)


def _tightened_mandate(base: OptimizationRequest, variant: CandidateSearchVariant) -> OptimizationRequest:
    """Preserve every common restriction; epsilon rows may only make it stricter."""
    overrides: dict[str, Decimal] = {}
    for name in ("maximum_overall_factor", "maximum_bsl_factor", "minimum_spread_bps", "maximum_trade_par"):
        value, prior = getattr(variant, name), getattr(base.limits, name)
        if value is None:
            continue
        if prior is not None and (value < prior if name == "minimum_spread_bps" else value > prior):
            raise InputValidationError(f"{name}: candidate override would relax the base mandate")
        overrides[name] = value
    return replace(base, objective=variant.objective, limits=replace(base.limits, **overrides))


def _frozen_rate_snapshot(provider: object) -> bool:
    """Admit only known immutable providers, including their nested rate nodes.

    A custom/live provider can change behind the same Python identity, so full
    request equality alone is insufficient. Exact types deliberately exclude
    subclasses that override rate() or carry mutable state. Unknown providers
    still work through the normal service; they simply receive no cache reuse.
    """
    if type(provider) is FlatRateProvider:
        return True
    if type(provider) is ProjectedRateCurve:
        return all(type(point) is RatePoint for point in provider.points)
    if type(provider) is CurveRateProvider:
        return all(type(curve) is ProjectedRateCurve and _frozen_rate_snapshot(curve)
                   for curve in provider.curves.values())
    if type(provider) is CashCurveRateProvider:
        return (_frozen_rate_snapshot(provider.term_provider)
                and all(type(curve) is DiscountFactorCashCurve
                        and all(type(point) is ZeroRatePoint for point in curve.points)
                        for curve in provider.cash_curves.values()))
    return False


class ModelProjectionCache:
    """Reuse identical complete projections within one frozen calculation batch.

    Different epsilon bounds/objectives can produce exactly the same pool.
    They still need separate static validation and named evidence, but their
    funding, contractual cashflows, waterfall and investor returns are equal.
    A cheap identity/par key narrows lookup; *complete request equality* decides
    reuse, so different contracts, fees, curves or CLO policies never collide.
    Nested mapping objects need not be hashable. Callers create a fresh instance
    per workbook/search; there is no global or persistent cache. Failed runs
    are not cached. Only known immutable frozen rate providers (recursively for
    cash-curve wrappers) are reusable; custom/live providers and opaque imported
    collateral bypass the cache. A workbook can share this runner across
    scenario and candidate services to reuse its native frozen baseline.
    """

    def __init__(self, service: ModelProjectionRunner | None = None) -> None:
        self._service = service if service is not None else TridentModelService()
        self._results: dict[tuple[tuple[str, Decimal], ...],
                            list[tuple[TridentModelRequest, TridentModelResult]]] = {}

    def run(self, request: TridentModelRequest) -> TridentModelResult:
        """Compute once per equal full request; never accept an unbound result."""
        if not isinstance(request, TridentModelRequest):
            raise InputValidationError("Cached projection request must be TridentModelRequest")
        if (request.imported_collateral is not None
                or not _frozen_rate_snapshot(request.cashflow_request.rate_provider)):
            return self._service.run(request)
        key = tuple((position.terms.loan_id, position.opening_balance)
                    for position in request.cashflow_request.positions)
        bucket = self._results.setdefault(key, [])
        for prior_request, result in bucket:
            if request == prior_request:
                return result
        result = self._service.run(request)
        bucket.append((request, result))
        return result


class ClosingPoolSearchService:
    """Replay explicit LP/MILP candidates; do not enumerate possible portfolios.

    A small epsilon-constraint grid can expose IRR/factor tradeoffs while all
    common mandate restrictions stay binding. Unexpected programming failures
    propagate; only explicit model-input/numeric failures become exclusions.
    """

    def __init__(self, optimizer: StaticTradeOptimizer | None = None,
                 service: ModelProjectionRunner | None = None) -> None:
        self._optimizer = optimizer if optimizer is not None else StaticTradeOptimizer()
        self._service = service if service is not None else TridentModelService()

    def run(self, request: ClosingPoolSearchRequest) -> ClosingPoolSearchResult:
        """Validate NO_TRADES, replay finite proposals, then rank eligible pools.

        Each variant keeps its own solver status, limits, findings and trade
        plan even if its complete projection is reused. Eligibility is never
        cached: it also depends on the variant's explicit static mandate.
        """
        if not isinstance(request, ClosingPoolSearchRequest):
            raise InputValidationError("request must be ClosingPoolSearchRequest")
        # A missing common baseline/provenance is a failed search request, not N
        # independent target failures. No-trade replay validates it first.
        cache = ModelProjectionCache(self._service)
        replay_service = ClosingPoolRedesignService(self._optimizer, cache)
        no_trade_request = ClosingPoolRedesignRequest(request.baseline,
            replace(request.base_mandate, quotes=()), request.candidate_snapshot,
            request.admission_policy, "NO_TRADES", request.minimum_equity_irr)
        benchmark = replay_service.run(no_trade_request)
        metric_name = "TEST_FACTOR_AVERAGE" if request.baseline.factor_mapping.is_synthetic else "WARF"
        baseline_irr = benchmark.baseline_result.equity_irr
        baseline_factor = _exact_factor(request.base_mandate.holdings)
        evaluations = [_evaluation("NO_TRADES", benchmark, metric_name, baseline_irr, baseline_factor)]
        for variant in request.variants:
            try:
                mandate = _tightened_mandate(request.base_mandate, variant)
                candidate_request = replace(no_trade_request, optimization_request=mandate,
                                            proposal_id=variant.candidate_id)
                replay = replay_service.run(candidate_request)
                evaluations.append(_evaluation(variant.candidate_id, replay, metric_name, baseline_irr, baseline_factor))
            except (InputValidationError, ArithmeticError, CurveRangeError, MissingCurveError, RequiredFixingError) as exc:
                evaluations.append(_failed_evaluation(variant.candidate_id, metric_name, str(exc)))
        # Failed/incomplete pools remain visible to explain exclusions, but
        # cannot win or distort the frontier through a fabricated return.
        eligible = [row for row in evaluations if row.eligible]
        ordered = _rank(eligible, request.selection_policy, Fraction(request.irr_comparison_tolerance))
        ranks = {row.candidate_id: index for index, row in enumerate(ordered, 1)}
        frontier = _frontier(eligible, Fraction(request.irr_comparison_tolerance))
        output = tuple(replace(row, rank=ranks.get(row.candidate_id), pareto=row.candidate_id in frontier)
                       for row in evaluations)
        return ClosingPoolSearchResult(CandidateSearchStatus.COMPLETED if eligible else CandidateSearchStatus.NO_ELIGIBLE_CANDIDATE,
            ordered[0].candidate_id if ordered else None, output, request.selection_policy,
            request.base_mandate.factor_provenance, request.irr_comparison_tolerance)


def _exact_factor(holdings) -> Fraction | None:
    total = sum((Fraction(row.par) for row in holdings), Fraction())
    return (sum((Fraction(row.par) * Fraction(row.asset.factor) for row in holdings), Fraction()) / total
            if total else None)


def _delta(value: Decimal | None, reference: Decimal | None) -> Decimal | None:
    return decimal_fraction(Fraction(value) - Fraction(reference)) if value is not None and reference is not None else None


def _evaluation(candidate_id: str, replay: ClosingPoolRedesignResult, metric_name: str,
                baseline_irr: ReturnResult, baseline_factor: Fraction | None) -> CandidateEvaluation:
    """Keep diagnostic comparison separate from permission to select the pool."""
    # The no-trade projection remains a benchmark even if its static mandate
    # rejects it. Other failed targets never acquire baseline metrics as their
    # own output.
    model = replay.baseline_result if candidate_id == "NO_TRADES" else replay.target_result
    factor = model.opening_portfolio.metric(metric_name) if model is not None else _missing_factor(metric_name)
    irr = model.equity_irr if model is not None else ReturnResult(ReturnStatus.UNAVAILABLE, None, "Target projection unavailable")
    moic = model.equity_moic if model is not None else ReturnResult(ReturnStatus.UNAVAILABLE, None, "Target projection unavailable")
    exact = _exact_factor(replay.optimization.ending_holdings) if replay.optimization.ending_holdings else None
    eligible = (replay.validated and factor.status is MetricStatus.AVAILABLE and factor.value is not None
                and exact is not None and irr.status is ReturnStatus.AVAILABLE and irr.value is not None)
    return CandidateEvaluation(candidate_id, replay.status.value, eligible, irr, moic, metric_name, factor, exact,
        _delta(irr.value, baseline_irr.value) if irr.status is ReturnStatus.AVAILABLE and baseline_irr.status is ReturnStatus.AVAILABLE else None,
        decimal_fraction(exact - baseline_factor) if exact is not None and baseline_factor is not None else None,
        model.cashflows.funding.equity_cash_funding if model is not None else None,
        model.clo.total_equity_distributions if model is not None and model.clo is not None else None,
        decimal_fraction(sum((Fraction(row.par) for row in replay.plan.trades), Fraction())) if replay.plan is not None else None,
        replay.plan.ending_cash if replay.plan is not None else None,
        "; ".join(row.message for row in replay.findings if row.severity.value == "ERROR"), replay=replay)


def _missing_factor(metric_name: str) -> MetricResult:
    return MetricResult(metric_name, None, MetricStatus.UNAVAILABLE,
        "synthetic_factor" if metric_name == "TEST_FACTOR_AVERAGE" else "rating_factor", Decimal(0), "Target projection unavailable")


def _failed_evaluation(candidate_id: str, metric_name: str, message: str) -> CandidateEvaluation:
    missing = ReturnResult(ReturnStatus.UNAVAILABLE, None, message)
    return CandidateEvaluation(candidate_id, "INPUT_REJECTED", False, missing, missing, metric_name,
        _missing_factor(metric_name), None, None, None, None, None, None, None, message)


def _rank(rows: list[CandidateEvaluation], policy: CandidateSelectionPolicy,
          tolerance: Fraction) -> list[CandidateEvaluation]:
    """Deterministic tolerance buckets, anchored to each bucket's greatest IRR.

    Tolerance describes ranking resolution, not a contractual breach tolerance.
    Avoid a pairwise approximate comparator, which would not be transitive.
    """
    buckets = _irr_buckets(rows, tolerance)
    if policy is CandidateSelectionPolicy.MIN_FACTOR_THEN_IRR:
        return sorted(rows, key=lambda row: (row.exact_factor, buckets[row.candidate_id], row.candidate_id))
    return sorted(rows, key=lambda row: (buckets[row.candidate_id], row.exact_factor, row.candidate_id))


def _irr_buckets(rows: list[CandidateEvaluation], tolerance: Fraction) -> dict[str, int]:
    """Common transitive ranking resolution for both selection and frontier.

    Pairwise ``abs(a-b) <= tolerance`` is not an equivalence relation: an IRR
    chain can make the selected candidate appear dominated. Anchor each bucket
    to its largest IRR over the complete eligible set instead. Bucket indices
    are ordered from greatest IRR to least and shared by both policies.
    """
    ordered = sorted(rows, key=lambda row: (-Fraction(row.equity_irr.value), row.candidate_id))
    output: dict[str, int] = {}
    begin = 0
    bucket = 0
    while begin < len(ordered):
        end, anchor = begin + 1, Fraction(ordered[begin].equity_irr.value)
        while end < len(ordered) and anchor - Fraction(ordered[end].equity_irr.value) <= tolerance:
            end += 1
        output.update((row.candidate_id, bucket) for row in ordered[begin:end])
        begin = end
        bucket += 1
    return output


def _frontier(rows: list[CandidateEvaluation], tolerance: Fraction) -> set[str]:
    """O(n log n) frontier using the same IRR resolution as selection.

    Smaller factor and smaller common IRR bucket are better. Equal factor and
    bucket retain equivalent evidence; one strict improvement dominates. This
    guarantees each lexicographic policy's first choice is on this frontier.
    """
    buckets = _irr_buckets(rows, tolerance)
    ordered = sorted(rows, key=lambda row: (row.exact_factor, row.candidate_id))
    frontier: set[str] = set()
    best_lower_factor: int | None = None
    begin = 0
    while begin < len(ordered):
        end = begin + 1
        while end < len(ordered) and ordered[end].exact_factor == ordered[begin].exact_factor:
            end += 1
        group = ordered[begin:end]
        best_same_factor = min(buckets[row.candidate_id] for row in group)
        for row in group:
            bucket = buckets[row.candidate_id]
            if ((best_lower_factor is None or best_lower_factor > bucket)
                    and best_same_factor == bucket):
                frontier.add(row.candidate_id)
        best_lower_factor = min(best_same_factor, best_lower_factor) if best_lower_factor is not None else best_same_factor
        begin = end
    return frontier
