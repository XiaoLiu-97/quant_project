"""UI-owned synthetic quotes -> exact static trades -> finite full CLO replay.

No saved workbook or historical project is loaded. The TEST factors and
fictional INTERNAL credit observations below are declared test inputs, never
agency coefficients or real ratings. Default legal WARF/WARR data gaps must
block full-replay eligibility even when the static solver is feasible.
"""
from dataclasses import replace
from datetime import date
from decimal import Decimal
import unittest

from openpyxl.utils.cell import get_column_letter
from trident.adapters import interface_inputs as ui
from trident.adapters.legacy_model_records import CLOSING_COMPONENTS, RECURRING_COMPONENTS
from trident.analysis import LimitStatus, ReturnStatus
from trident.application.candidate_search import CandidateSearchStatus, ClosingPoolSearchService
from trident.application.clo_services import TridentModelService
from trident.adapters.interface_run import InterfaceCase, InterfaceRun
from trident.adapters.interface_output import _static_comparison_rows
from trident.optimization import OptimizationStatus, StaticTradeOptimizer, TradeSide
from test_interface_inputs import workbook_fixture, _cell, _name, _existing

D = Decimal
SOURCE = 'DECLARED_SYNTHETIC_TEST_NOT_AGENCY_DATA'


def _rows(w, key, rows):
    """Replace a fixture's owning table records, retaining its exact schema."""
    sheet = w[key]
    headers = [c.value for c in sheet[1]]
    if sheet.max_row > 1:
        sheet.delete_rows(2, sheet.max_row - 1)
    for record in rows:
        sheet.append([record.get(header) for header in headers])
    table = next(iter(sheet.tables.values()))
    table.ref = f'A1:{get_column_letter(len(headers))}{len(rows) + 1}'
    w.defined_names[ui.UI_PREFIX + key].attr_text = f"'{sheet.title}'!{table.ref}"


def _setting(w, key, label, value):
    label_column = 'Setting / constraint' if key == 'optimizer' else 'Constraint'
    for n in range(2, w[key].max_row + 1):
        if _cell(w, key, label_column, n).value == label:
            _cell(w, key, 'Value', n).value = value
            return
    raise AssertionError(label)


def _legacy(w, key, value):
    defined = w.defined_names[ui.UI_PREFIX + key]
    sheet, coordinate = next(defined.destinations)
    w[sheet][coordinate].value = value


def optimization_workbook(*, discrete=False, recovery=True, candidate_search=False):
    """20m toy: locked Infra10m, held BSL10m, new BSL buy quoted separately.

    The new BSL's factor1500/spread600 replaces held factor3000/spread300;
    held sale BID99 versus new purchase ASK97 releases2% cash per swapped par.
    Target par is fixed20m, gross turnover cap1m and declared starting cash0.
    LP swaps500k each way; 300k lots with EUR1000/leg fees admit one lot.
    Toy asset/note dates coincide, so the explicitly declared collection lag is
    zero; legal final coincides with complete asset redemption in November2028.
    """
    w = workbook_fixture()
    for field in CLOSING_COMPONENTS + RECURRING_COMPONENTS:
        _legacy(w, field, 0)
    for field in ('upfront_arrangement_fee', 'expected_senior_expenses_variable',
                  'initial_reserve_funding', 'other_initial_uses', 'other_initial_sources',
                  'purchased_accrued_interest', 'liability_reference_floor'):
        _legacy(w, field, 0)
    _legacy(w, 'senior_management_fee', D('.001'))
    _legacy(w, 'subordinated_management_fee', D('.001'))
    _legacy(w, 'maximum_single_obligor', D('1'))
    _legacy(w, 'maximum_industry', D('1'))
    _legacy(w, 'determination_lag', 0)
    _legacy(w, 'maturity_date', date(2028, 11, 20))
    for n in (2, 3):
        _cell(w, 'pool', 'Purchase price / 100', n).value = 100
        _cell(w, 'pool', 'Purchased accrued (EUR)', n).value = 0
    # Add a complete unheld reference contract; it is not a current holding.
    for key in ('assets', 'asset_terms', 'asset_details', 'asset_ratings'):
        sheet = w[key]
        rows = [{c.value: sheet.cell(n, i).value for i, c in enumerate(sheet[1], 1)}
                for n in (2, 3)]
        new = dict(rows[1]);new['Asset ID'] = 'U';rows.append(new)
        _rows(w, key, rows)
    for header, value in (('Obligor ID', 'OBU'), ('Country', 'NL'), ('Sector', 'energy')):
        _cell(w, 'assets', header, 4).value = value
    _cell(w, 'asset_terms', 'Spread (bps)', 4).value = 600
    _cell(w, 'asset_terms', 'Amortization reference face', 4).value = 5000000
    for n in (2, 3, 4):
        if recovery:
            _cell(w, 'asset_terms', 'Recovery assumption (%)', n).value = D('.6')
            _cell(w, 'asset_terms', 'Recovery source', n).value = SOURCE
        for header, value in (
            ('Agency', 'FICTIONAL_TEST_INTERNAL_PROVIDER'), ('Rating', 'INTERNAL_TEST'),
            ('Rating level', 'FACILITY'), ('Rating nature', 'INTERNAL'),
            ('Subject ID', ('I', 'B', 'U')[n - 2]), ('Effective date', date(2026, 11, 20)),
            ('Source', SOURCE), ('Use for model', False),
            ('Factor system', 'UI_E2E_TEST'), ('Factor version', '1.0'),
            ('Selected bucket', ('INFRA_TEST', 'HELD_TEST', 'NEW_TEST')[n - 2]),
            ('Factor source', SOURCE)):
            _cell(w, 'asset_ratings', header, n).value = value
    _rows(w, 'factor_mapping', [
        {'System': 'UI_E2E_TEST', 'Version': '1.0', 'Bucket': bucket,
         'Factor': factor, 'Is synthetic': True, 'Source': SOURCE}
        for bucket, factor in (('INFRA_TEST', 1000), ('HELD_TEST', 3000), ('NEW_TEST', 1500))])
    _setting(w, 'optimizer', 'Candidate search enabled', candidate_search)
    _setting(w, 'optimizer', 'Quote snapshot ID', 'UI_E2E_SYNTHETIC_SNAPSHOT')
    _setting(w, 'optimizer', 'Captured at (timezone)', '2026-11-20T09:00:00+00:00')
    _setting(w, 'optimizer', 'Snapshot source', SOURCE)
    w['Home']['D5'] = not candidate_search;_name(w, 'optimizer_enabled', w['Home'], 'D5')
    common = {'Settlement date': date(2026, 11, 20), 'Quote time': '2026-11-20T09:00:00+00:00',
              'Quote source': SOURCE, 'Quote quality': 'FIRM', 'Trade fees / par': 0,
              'Min ticket': 0, 'Lot size': 300000 if discrete else None}
    _rows(w, 'trade_universe', [
        dict(common, **{'Asset ID': 'B', 'Allow buy': False, 'Allow sell': True,
                        'Bid / 100': 99, 'Bid size (EUR)': 1000000,
                        'Sell accrued / par': 0, 'Fixed SELL fee (EUR)': 1000 if discrete else 0}),
        dict(common, **{'Asset ID': 'U', 'Allow buy': True, 'Allow sell': False,
                        'Ask / 100': 97, 'Ask size (EUR)': 1000000,
                        'Buy accrued / par': 0, 'Fixed BUY fee (EUR)': 1000 if discrete else 0}),
        # An apparent Infra sell permission cannot override the owning LOCKED
        # Pool row, and its price must never enter the solver's usable universe.
        dict(common, **{'Asset ID': 'I', 'Allow buy': False, 'Allow sell': True,
                        'Bid / 100': 100, 'Bid size (EUR)': 10000000,
                        'Sell accrued / par': 0, 'Fixed SELL fee (EUR)': 0})])
    return w


def synthetic_replay_profile(inputs):
    """Explicit test-only mandate with no agency rating covenant.

    Retain every measured legal requirement. Synthetic TEST factors are never
    substituted into the legacy agency WARF requirement: the separate default
    profile rejection test checks that requirement remains unavailable.
    """
    limits = tuple(limit for limit in inputs.request.limits if limit.metric != 'WARF')
    if len(limits) != len(inputs.request.limits) - 1:
        raise AssertionError('Expected exactly one explicitly omitted agency WARF covenant')
    return replace(inputs, request=replace(inputs.request, limits=limits))


class InterfaceOptimizationIntegrationTests(unittest.TestCase):
    def _static_presentation(self, *, discrete=False):
        inputs = ui.read_interface_inputs(optimization_workbook(discrete=discrete))
        baseline = TridentModelService().run(inputs.request)
        optimization = StaticTradeOptimizer().solve(ui.static_optimization_request(inputs, baseline))
        run = InterfaceRun(inputs, (InterfaceCase('BASELINE', inputs.request, baseline, 'BASELINE'),),
                           optimization=optimization)
        labels = [('Equity IRR', 'EQUITY_IRR', 'annual_fraction'),
                  ('Equity MOIC', 'EQUITY_MOIC', 'multiple'),
                  ('Equity funding', 'EQUITY_CASH_FUNDING', 'EUR'),
                  ('Collateral par', 'COLLATERAL_PAR', 'EUR'),
                  ('Synthetic factor', 'TEST_FACTOR_AVERAGE', 'synthetic_factor'),
                  ('BSL factor', 'BSL_TEST_FACTOR_AVERAGE', 'synthetic_factor'),
                  ('WAS', 'WAS_BPS', 'bps'), ('WARF', 'WARF', 'rating_factor')]
        return run, {r['Metric']: r for r in _static_comparison_rows(run, labels)}

    def test_static_presentation_keeps_matching_bases_and_no_investor_return(self):
        run, rows = self._static_presentation()
        self.assertIs(run.baseline.equity_irr.status, ReturnStatus.AVAILABLE)
        # Available projected baseline returns must not be copied into a
        # STATIC comparison: that proposal has not undergone CLO replay.
        for label in ('Equity IRR', 'Equity MOIC', 'Equity funding', 'WARF'):
            row = rows[label]
            self.assertEqual((row['Saved Base'], row['Proposed'], row['Delta']), ('n.a.', 'n.a.', 'n.a.'))
            self.assertEqual(row['Status'], 'NOT_MEASURED')
            self.assertIn('no CLO replay or investor return', row['Scope / detail'])
        expected = {'Collateral par': (D(20000000), D(20000000), D(0)),
                    'Synthetic factor': (D(2000), D('1962.5'), D('-37.5')),
                    'BSL factor': (D(3000), D(2925), D(-75)),
                    'Linear all-asset spread': (D(300), D('307.5'), D('7.5')),
                    'Available static cash': (D(0), D(10000), D(10000))}
        for label, values in expected.items():
            row = rows[label]
            self.assertEqual((row['Saved Base'], row['Proposed'], row['Delta']), values)
            self.assertEqual(row['Status'], 'AVAILABLE')
            self.assertTrue(row['Scope / detail'].startswith('STATIC_ONLY;'))
        self.assertNotIn('WAS', rows)
        self.assertEqual(rows['Linear all-asset spread']['Unit'], 'bps')
        self.assertEqual(next(h.par for h in run.optimization.ending_holdings if h.asset.asset_id == 'I'), D(10000000))

    def test_static_milp_presentation_uses_posted_fees_and_actual_integer_proposal(self):
        run, rows = self._static_presentation(discrete=True)
        self.assertEqual(run.optimization.solver_method, 'HIGHS_MILP')
        expected = {'Synthetic factor': (D(2000), D('1977.5'), D('-22.5')),
                    'BSL factor': (D(3000), D(2955), D(-45)),
                    'Linear all-asset spread': (D(300), D('304.5'), D('4.5')),
                    'Available static cash': (D(0), D(4000), D(4000))}
        for label, values in expected.items():
            row = rows[label]
            self.assertEqual((row['Saved Base'], row['Proposed'], row['Delta']), values)
        self.assertEqual(rows['Equity IRR']['Proposed'], 'n.a.')
        self.assertEqual(rows['Equity MOIC']['Proposed'], 'n.a.')
        self.assertEqual(next(h.par for h in run.optimization.ending_holdings if h.asset.asset_id == 'I'), D(10000000))

    def test_lp_uses_source_bid_ask_and_exact_cash_with_locked_infra(self):
        inputs = ui.read_interface_inputs(optimization_workbook())
        request = ui.static_optimization_request(inputs)
        self.assertEqual({(q.asset.asset_id, q.side.value, q.clean_price_pct) for q in request.quotes},
                         {('B', 'SELL', D(99)), ('U', 'BUY', D(97))})
        result = StaticTradeOptimizer().solve(request)
        self.assertEqual(result.status, OptimizationStatus.OPTIMAL)
        self.assertEqual(result.solver_method, 'HIGHS_DUAL_SIMPLEX')
        self.assertTrue(result.validated)
        self.assertEqual({(t.asset_id, t.side.value, t.par) for t in result.trades},
                         {('B', 'SELL', D(500000)), ('U', 'BUY', D(500000))})
        self.assertEqual(result.ending_cash, D(10000))
        self.assertEqual(result.ending_par, D(20000000))
        self.assertEqual(result.overall_factor, D('1962.5'))
        self.assertEqual(result.bsl_factor, D(2925))
        self.assertEqual(result.spread_bps, D('307.5'))
        self.assertEqual(next(h.par for h in result.ending_holdings if h.asset.asset_id == 'I'), D(10000000))
        self.assertEqual(result.validation_scope, 'STATIC_ONLY')
        self.assertIn('LEGACY_MAXIMUM_PORTFOLIO_WARF', inputs.controls['optimizer_unmapped_limit_ids'])

    def test_milp_lots_and_fixed_fees_are_paid_only_for_active_tickets(self):
        w = optimization_workbook(discrete=True)
        result = StaticTradeOptimizer().solve(ui.static_optimization_request(ui.read_interface_inputs(w)))
        self.assertEqual(result.solver_method, 'HIGHS_MILP')
        self.assertTrue(result.validated)
        self.assertEqual([t.par for t in result.trades], [D(300000), D(300000)])
        self.assertEqual([t.fee_cash for t in result.trades], [D(1000), D(1000)])
        self.assertEqual(result.ending_cash, D(4000))
        self.assertEqual(result.overall_factor, D('1977.5'))
        for n in (2, 3):
            _cell(w, 'trade_universe', 'Min ticket', n).value = 400000
        no_trade = StaticTradeOptimizer().solve(ui.static_optimization_request(ui.read_interface_inputs(w)))
        self.assertTrue(no_trade.validated)
        self.assertEqual(no_trade.trades, ())
        self.assertEqual(no_trade.ending_cash, D(0))

    def test_legal_sector_maximum_tightens_looser_pm_constraint(self):
        w = optimization_workbook()
        _rows(w, 'limits', [
            {'Limit ID': 'SECTOR_LEGAL', 'Metric': 'LARGEST_SECTOR_FRACTION',
             'Direction': 'MAXIMUM', 'Threshold': D('.51'), 'Applicable phase': 'CLOSING', 'Enabled': True}])
        inputs = ui.read_interface_inputs(w)
        request = ui.static_optimization_request(inputs)
        self.assertEqual(request.limits.maximum_sector_share, D('.51'))
        result = StaticTradeOptimizer().solve(request)
        self.assertTrue(result.validated)
        self.assertEqual({t.par for t in result.trades}, {D(200000)})
        self.assertEqual(result.ending_cash, D(4000))
        self.assertEqual(result.ending_par, D(20000000))

    def test_inactive_composition_bounds_are_not_reintroduced_as_pm_overrides(self):
        w = optimization_workbook()
        _rows(w, 'limits', [
            {'Limit ID': 'FUTURE_BSL', 'Metric': 'concentration:asset_class:BSL',
             'Direction': 'MAXIMUM', 'Threshold': D('.4'), 'Applicable phase': 'POST_REINVESTMENT', 'Enabled': True},
            {'Limit ID': 'FUTURE_INFRA', 'Metric': 'concentration:asset_class:INFRA',
             'Direction': 'MINIMUM', 'Threshold': D('.6'), 'Applicable phase': 'POST_REINVESTMENT', 'Enabled': True}])
        inputs = ui.read_interface_inputs(w)
        request = ui.static_optimization_request(inputs)
        self.assertIsNone(request.limits.maximum_bsl_share)
        self.assertIsNone(request.limits.minimum_infra_share)
        self.assertTrue(StaticTradeOptimizer().solve(request).validated)

    def test_existing_end_date_boundary_and_later_dates_enforce_canonical_post_limits(self):
        # This is static current-portfolio research only; full candidate IRR
        # search is disabled, and known opening balances/claims remain owned.
        for end in (date(2027, 2, 22), date(2027, 2, 21)):
            with self.subTest(reinvestment_end=end):
                w = optimization_workbook();_existing(w)
                _legacy(w, 'reinvestment_end_date', end)
                _setting(w, 'optimizer', 'Candidate search enabled', False)
                _setting(w, 'optimizer', 'Settlement / closing date', date(2027, 2, 22))
                _setting(w, 'optimizer', 'Captured at (timezone)', '2027-02-22T09:00:00+00:00')
                for n in (2, 3, 4):
                    _cell(w, 'trade_universe', 'Settlement date', n).value = date(2027, 2, 22)
                    _cell(w, 'trade_universe', 'Quote time', n).value = '2027-02-22T09:00:00+00:00'
                _rows(w, 'limits', [
                    {'Limit ID': 'POST_COUNTRY', 'Metric': 'LARGEST_COUNTRY_FRACTION',
                     'Direction': 'MAXIMUM', 'Threshold': D('.4'), 'Applicable phase': 'POST_REINVESTMENT', 'Enabled': True},
                    {'Limit ID': 'PAST_BSL', 'Metric': 'concentration:asset_class:BSL',
                     'Direction': 'MAXIMUM', 'Threshold': D('.4'), 'Applicable phase': 'REINVESTMENT', 'Enabled': True}])
                inputs = ui.read_interface_inputs(w)
                request = ui.static_optimization_request(inputs)
                self.assertEqual(inputs.controls['optimizer_limit_inheritance_scope'], 'POST_REINVESTMENT')
                self.assertEqual(request.limits.maximum_country_share, D('.4'))
                self.assertIsNone(request.limits.maximum_bsl_share)
                # Locked DE Infra already accounts for50%; the active country
                # bound is impossible, so this mandate must not be certified.
                result = StaticTradeOptimizer().solve(request)
                self.assertEqual(result.status, OptimizationStatus.INFEASIBLE)
                self.assertFalse(result.validated)

    def test_declared_cash_and_availability_bound_the_executable_trade(self):
        w = optimization_workbook()
        _cell(w, 'trade_universe', 'Ask / 100', 3).value = 100
        # With sale BID99 and purchase ASK100, each par costs one cent; zero
        # declared cash cannot fund any replacement, despite attractive factor.
        zero = StaticTradeOptimizer().solve(ui.static_optimization_request(ui.read_interface_inputs(w)))
        self.assertTrue(zero.validated)
        self.assertEqual(zero.trades, ())
        _setting(w, 'optimizer', 'Declared incremental cash', 3000)
        funded = StaticTradeOptimizer().solve(ui.static_optimization_request(ui.read_interface_inputs(w)))
        self.assertTrue(funded.validated)
        self.assertEqual({t.par for t in funded.trades}, {D(300000)})
        self.assertEqual(funded.ending_cash, D(0))
        _cell(w, 'trade_universe', 'Ask size (EUR)', 3).value = 100000
        limited = StaticTradeOptimizer().solve(ui.static_optimization_request(ui.read_interface_inputs(w)))
        self.assertTrue(limited.validated)
        self.assertEqual({t.par for t in limited.trades}, {D(100000)})
        self.assertEqual(limited.ending_cash, D(2000))

    def test_unavailable_legacy_agency_and_recovery_limits_never_become_pass(self):
        inputs = ui.read_interface_inputs(optimization_workbook(recovery=False, candidate_search=True))
        baseline = TridentModelService().run(inputs.request)
        unknown = {r.metric for r in baseline.opening_portfolio.limits if r.status is LimitStatus.UNAVAILABLE}
        self.assertTrue({'WARF', 'WARR'} <= unknown)
        self.assertTrue(StaticTradeOptimizer().solve(ui.static_optimization_request(inputs)).validated)
        search = ClosingPoolSearchService().run(ui.closing_candidate_request(inputs, baseline))
        self.assertEqual(search.status, CandidateSearchStatus.NO_ELIGIBLE_CANDIDATE)
        self.assertIsNone(search.selected_candidate_id)
        self.assertTrue(all(not row.eligible and row.rank is None for row in search.evaluations))
        self.assertTrue(all('WARF' in row.failure_message and 'WARR' in row.failure_message for row in search.evaluations))

    def test_collection_cutoff_change_excludes_cash_pay_and_coverage_failures(self):
        w = optimization_workbook(candidate_search=True)
        _legacy(w, 'determination_lag', 5)
        inputs = synthetic_replay_profile(ui.read_interface_inputs(w))
        search = ClosingPoolSearchService().run(ui.closing_candidate_request(inputs))
        self.assertEqual(search.status, CandidateSearchStatus.NO_ELIGIBLE_CANDIDATE)
        self.assertTrue(all(not row.eligible for row in search.evaluations))
        target = search.evaluation('MIN_FACTOR')
        first = target.replay.target_result.clo.periods[0]
        self.assertGreater(first.pending_interest_cash, 0)
        self.assertEqual(first.eligible_asset_interest, D(0))
        self.assertTrue(first.cash_pay_failure and first.coverage_failed)
        self.assertIn('coverage gate did not pass', target.failure_message)

    def test_finite_candidates_run_full_replay_and_rank_available_true_irr(self):
        inputs = synthetic_replay_profile(ui.read_interface_inputs(optimization_workbook(candidate_search=True)))
        result = ClosingPoolSearchService().run(ui.closing_candidate_request(inputs))
        self.assertEqual(result.status, CandidateSearchStatus.COMPLETED)
        self.assertEqual({row.candidate_id for row in result.evaluations}, {'NO_TRADES', 'MIN_FACTOR', 'MAX_SPREAD'})
        self.assertTrue(all(row.eligible and row.equity_irr.status is ReturnStatus.AVAILABLE for row in result.evaluations))
        selected = result.evaluation(result.selected_candidate_id)
        best = max(row.equity_irr.value for row in result.evaluations)
        self.assertLessEqual(best - selected.equity_irr.value, result.irr_comparison_tolerance)
        target = result.evaluation('MIN_FACTOR')
        self.assertEqual(target.gross_trade_par, D(1000000))
        self.assertEqual(target.static_ending_cash, D(10000))
        self.assertEqual(target.equity_cash_funding, D(4985000))
        self.assertEqual(target.replay.target_result.clo.status.value, 'COMPLETED')
        self.assertGreater(len(target.replay.target_result.clo.periods), 1)
        self.assertTrue(all(row.status is LimitStatus.PASS for row in target.replay.target_result.opening_portfolio.limits))
        self.assertEqual(result.execution_status, 'NOT_EXECUTED')
        self.assertEqual(result.optimality_scope, 'EVALUATED_CANDIDATES_ONLY_NO_GLOBAL_EQUITY_IRR_OPTIMALITY')
        # A requested minimum return is an explicit eligibility gate, not a
        # fabricated legal covenant or the LP's objective coefficient.
        request = replace(ui.closing_candidate_request(inputs), minimum_equity_irr=D(2))
        rejected = ClosingPoolSearchService().run(request)
        self.assertEqual(rejected.status, CandidateSearchStatus.NO_ELIGIBLE_CANDIDATE)
        self.assertIsNone(rejected.selected_candidate_id)
        self.assertTrue(all(not row.eligible for row in rejected.evaluations))


if __name__ == '__main__':
    unittest.main()
