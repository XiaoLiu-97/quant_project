"""Independent note fixing and first-stub reference-rate policies.

The interpolation policy brackets the accrual period by actual calendar tenor
dates from its start, then linearly interpolates supplied 1M/3M/6M reference
rates. It does not approximate a month by 30.4375 days or interpolate floors.
Outside the available tenor span, the nearest supplied tenor is explicitly used
(matching the limited legacy menu); these are configurable model policies, not
universal coupon terms. A transaction requiring 12M must supply an override.
"""

from datetime import date
from decimal import Decimal
from enum import Enum
from fractions import Fraction

from trident.domain.numeric import decimal_fraction
from trident.market.rates import RateProvider

from ._validation import require_date, require_integer
from .calendar import BusinessCalendar
from .schedule import AccrualPeriod, ScheduleBuilder


class FixingDateAnchor(str, Enum):
    PERIOD_START = "PERIOD_START"
    PAYMENT_DATE = "PAYMENT_DATE"


class FirstStubRateMethod(str, Enum):
    SELECTED_REFERENCE = "SELECTED_REFERENCE"
    INTERPOLATE_1M_3M_6M = "INTERPOLATE_1M_3M_6M"
    USER_OVERRIDE = "USER_OVERRIDE"


def fixing_date_for_period(
    period: AccrualPeriod, lag: int, calendar: BusinessCalendar,
    anchor: FixingDateAnchor,
) -> date:
    """Use the independently selected fixing calendar and explicit date anchor.

    Payment-date anchor intentionally permits an in-arrears fixing after the
    accrual start. It is appropriate only if this is the actual note contract;
    it must not alter the cashflow engine's in-advance loan fixing policy.
    """
    if not isinstance(period, AccrualPeriod) or not isinstance(calendar, BusinessCalendar):
        raise TypeError("Expected AccrualPeriod and BusinessCalendar")
    require_integer(lag, "lag")
    if lag < 0 or not isinstance(anchor, FixingDateAnchor):
        raise ValueError("Fixing lag must be nonnegative and anchor typed")
    start = period.accrual_start if anchor is FixingDateAnchor.PERIOD_START else period.payment_date
    return calendar.add_business_days(start, -lag)


def first_stub_reference_rate(
    provider: RateProvider, fixing_date: date, accrual_start: date,
    accrual_end: date, selected_index: str, method: FirstStubRateMethod,
    override: Decimal | None = None,
) -> Decimal:
    """Calculate the selected first-period reference before index floor/margin."""
    for value, label in ((fixing_date, "fixing_date"), (accrual_start, "accrual_start"),
                         (accrual_end, "accrual_end")):
        require_date(value, label)
    if accrual_end <= accrual_start or not isinstance(method, FirstStubRateMethod):
        raise ValueError("First-stub dates must form a positive interval and method must be typed")
    if method is FirstStubRateMethod.USER_OVERRIDE:
        if not isinstance(override, Decimal) or not override.is_finite():
            raise ValueError("USER_OVERRIDE requires a finite Decimal reference rate")
        return override
    if override is not None:
        raise ValueError("first-stub override is only active under USER_OVERRIDE")
    def supplied_rate(index: str) -> Decimal:
        """Validate a used observation, retaining every finite supplied digit."""
        rate = provider.rate(index, fixing_date)
        if not isinstance(rate, Decimal) or not rate.is_finite():
            raise ValueError("Stub reference observations must be finite Decimal values")
        return rate

    if method is FirstStubRateMethod.SELECTED_REFERENCE:
        return supplied_rate(selected_index)
    tenor_dates = tuple(ScheduleBuilder._roll(accrual_start, tenor, False) for tenor in (1, 3, 6))
    if any(value is None for value in tenor_dates):
        raise ValueError("First-stub tenor dates exceed the supported date range")
    if accrual_end <= tenor_dates[0]:
        return supplied_rate("EURIBOR_1M")
    if accrual_end >= tenor_dates[2]:
        return supplied_rate("EURIBOR_6M")
    if accrual_end == tenor_dates[1]:
        # Exact 3M needs neither adjacent tenor. Interpolating a weight of one
        # would unnecessarily require 1M and round an exact supplied fixing.
        return supplied_rate("EURIBOR_3M")
    left = 0 if accrual_end <= tenor_dates[1] else 1
    right = left + 1
    low = supplied_rate(f"EURIBOR_{(1, 3, 6)[left]}M")
    high = supplied_rate(f"EURIBOR_{(1, 3, 6)[right]}M")
    weight = Fraction((accrual_end - tenor_dates[left]).days, (tenor_dates[right] - tenor_dates[left]).days)
    return decimal_fraction(Fraction(low) + (Fraction(high) - Fraction(low)) * weight)
