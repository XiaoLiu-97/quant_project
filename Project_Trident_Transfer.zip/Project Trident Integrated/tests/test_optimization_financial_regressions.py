"""Independent mandate, ranking and scenario counterexamples for the audit.

The static evidence below is deliberately constructed without the optimizer.
OPTIMAL is only a label; its holdings, posted cash and all mandate restrictions
must be proved at reconciliation. Year-long credit oracles use 100 face, 20
default, 8 recovery, 12 loss and 80 surviving scheduled repayment.
"""

from dataclasses import replace
from datetime import date
from decimal import Decimal, Inexact, localcontext
from fractions import Fraction
from itertools import permutations
import unittest

from trident.analysis import AssetExposure, MetricResult, MetricStatus, ReturnResult, ReturnStatus
from trident.application.candidate_search import (
    CandidateSelectionPolicy, _failed_evaluation, _frontier, _rank,
)
from trident.application.clo_services import TridentModelRequest, TridentModelService
from trident.application.construction import ClosingPoolRedesignService
from trident.application.imported_cashflows import (
    CollateralCashflowInputMode, DetailedImportedCashflow, compile_imported_cashflows,
)
from trident.application.scenarios import (
    ScenarioDefinition, ScenarioEdit, ScenarioRunner, ScenarioTarget, _apply_edits, compare_model_results,
)
from trident.application.services import CashflowRunRequest
from trident.clo import CloTerms, DefaultedAssetOcTreatment, NoteTranche
from trident.clo.lifecycle import OcAssetData
from trident.clo.reinvestment import SyntheticReinvestmentPolicy
from trident.conventions import AccrualDateBasis, BusinessDayConvention, DayCount
from trident.credit.overlay import OriginalPoolOverlay
from trident.domain.models import CouponType, InputValidationError, LoanPosition, LoanTerms
from trident.funding import AssetPurchase, DebtIssue
from trident.market import FlatRateProvider
from trident.optimization import (
    AssetDescriptor, AssetKind, Holding, OptimizationObjective, OptimizationRequest,
    OptimizationResult, OptimizationStatus, PortfolioLimits, ProposedTrade, StaticTradeOptimizer,
    TradeQuote, TradeSide,
)
from trident.optimization.linear import verify_static_amounts
from trident.optimization.universe import reconcile_proposal
from test_construction import fixture as construction_fixture
from test_scenarios import request as scenario_fixture
from test_universe import candidate, policy as admission_policy, snapshot
from trident.optimization.universe import CandidateUniverseValidator


D = Decimal
START, YEAR_ONE, YEAR_TWO = date(2025, 1, 1), date(2026, 1, 1), date(2027, 1, 1)


def static_case():
    old = AssetDescriptor("OLD", AssetKind.BSL, "OLD_ISSUER", "GB", "SERVICES", D(600), D(4000))
    new = AssetDescriptor("NEW", AssetKind.BSL, "NEW_ISSUER", "FR", "SOFTWARE", D(500), D(2000))
    request = OptimizationRequest((Holding(old, D(100)),),
        (TradeQuote(old, TradeSide.SELL, D(99), D(100)), TradeQuote(new, TradeSide.BUY, D(101), D(100))),
        D(10), PortfolioLimits(D(100)), OptimizationObjective.MIN_FACTOR,
        "INDEPENDENT_SYNTHETIC_FACTOR", START)
    # Sell99, buy101: posted cash10+99-101=8. Gross turnover=200.
    result = OptimizationResult(OptimizationStatus.OPTIMAL, 0, "INDEPENDENT_TEST_EVIDENCE",
        "TEST_ONLY", None, None, None, request.factor_provenance,
        (ProposedTrade("OLD", TradeSide.SELL, D(100), D(99), D(0), D(0), D(99)),
         ProposedTrade("NEW", TradeSide.BUY, D(100), D(101), D(0), D(0), D(-101))),
        (Holding(new, D(100)),), D(8), D(100), D(2000), D(2000), D(500))
    return request, result


def ranking_row(identifier, irr, factor):
    return replace(_failed_evaluation(identifier, "TEST_FACTOR_AVERAGE", ""), eligible=True,
        equity_irr=ReturnResult(ReturnStatus.AVAILABLE, D(irr)),
        factor=MetricResult("TEST_FACTOR_AVERAGE", D(factor), MetricStatus.AVAILABLE,
                            "synthetic_factor", D(1)), exact_factor=Fraction(D(factor)))


def annual_model(*, maturity=YEAR_ONE, final=YEAR_ONE, note_rate=D(0)):
    loan = LoanTerms("L1", "EUR", START, maturity, D(100), CouponType.FIXED,
        fixed_rate=D(".1"), frequency_months=12, day_count=DayCount.ACT_365F,
        business_day_convention=BusinessDayConvention.UNADJUSTED,
        accrual_date_basis=AccrualDateBasis.UNADJUSTED)
    position = LoanPosition(loan, START, D(100))
    exposure = AssetExposure("L1", "BORROWER", "BSL", "TERM_LOAN", "GB", "SERVICES", "EUR",
        D(100), None, maturity, coupon_type=CouponType.FIXED, fixed_coupon_rate=D(".1"))
    cash = CashflowRunRequest((position,), (AssetPurchase("L1", D(100), D(100)),),
        (DebtIssue("A", D(60), D(100)),), FlatRateProvider({"EURIBOR_3M": D(0)}), D(0), D(0), "AUDIT")
    terms = CloTerms(START, final, frequency_months=12, coverage_tests_enabled=False,
        defaulted_asset_oc_treatment=DefaultedAssetOcTreatment.EXCLUDE,
        business_day_convention=BusinessDayConvention.UNADJUSTED,
        accrual_date_basis=AccrualDateBasis.UNADJUSTED)
    note = NoteTranche("A", 1, D(60), CouponType.FIXED, fixed_rate=note_rate, day_count=DayCount.ACT_365F)
    return TridentModelRequest(cash, (exposure,), clo_terms=terms, notes=(note,))


def metric_row(rows, scope, metric):
    return next(row for row in rows if row.scope == scope and row.metric == metric)


def period_row(rows, when, class_id, metric):
    return next(row for row in rows if (row.payment_date, row.class_id, row.metric) == (when, class_id, metric))


class ExactProposalBoundaryAuditTests(unittest.TestCase):
    def test_independent_cash_par_and_factor_evidence_reconciles(self):
        request, result = static_case()
        plan = reconcile_proposal(request, result)
        self.assertEqual((plan.ending_par, plan.ending_cash), (D(100), D(8)))
        self.assertEqual([(row.asset_id, row.signed_trade_par) for row in plan.changes],
                         [("NEW", D(100)), ("OLD", D(-100))])

    def test_forged_optimal_label_cannot_bypass_any_risk_mandate(self):
        request, result = static_case()
        for restriction in (
            {"maximum_obligor_share": D(".999")}, {"maximum_country_share": D(".999")},
            {"maximum_sector_share": D(".999")}, {"maximum_bsl_share": D(".999")},
            {"minimum_infra_share": D(".01")}, {"maximum_overall_factor": D(1999)},
            {"maximum_bsl_factor": D(1999)}, {"minimum_spread_bps": D(501)},
            {"maximum_trade_par": D("199.99")},
        ):
            with self.subTest(restriction=restriction), self.assertRaisesRegex(InputValidationError, "static mandate"):
                reconcile_proposal(replace(request, limits=replace(request.limits, **restriction)), result)

    def test_exact_factor_boundary_has_no_display_rounding_or_solver_tolerance(self):
        request, result = static_case()
        boundary = replace(request.limits, maximum_overall_factor=D(2000), maximum_bsl_factor=D(2000),
                           minimum_spread_bps=D(500), maximum_trade_par=D(200))
        self.assertEqual(reconcile_proposal(replace(request, limits=boundary), result).ending_cash, D(8))
        tiny_breach = replace(boundary, maximum_overall_factor=D("1999.999999999999999999999999999999999999999999999"))
        with localcontext() as context:
            context.prec = 2
            context.traps[Inexact] = True
            with self.assertRaisesRegex(InputValidationError, "Overall factor"):
                reconcile_proposal(replace(request, limits=tiny_breach), result)

    def test_reported_weighted_averages_cannot_be_forged(self):
        request, result = static_case()
        for field, value in (("overall_factor", D(1999)), ("bsl_factor", None), ("spread_bps", D(501))):
            with self.subTest(field=field), self.assertRaisesRegex(InputValidationError, "diagnostics"):
                reconcile_proposal(request, replace(result, **{field: value}))

    def test_shared_exact_verifier_posts_fee_legs_and_never_charges_inactive_quotes(self):
        request, _ = static_case()
        quotes = tuple(replace(quote, accrued_per_par=D(".02"), proportional_fee_per_par=D(".005"),
                               fixed_fee=D(".01")) for quote in request.quotes)
        request = replace(request, quotes=quotes)
        active = verify_static_amounts(request, (D(100), D(100)))
        # Sell99+2-.50-.01=100.49; buy101+2+.50+.01=103.51.
        self.assertEqual(active.ending_cash, D("6.98"))
        self.assertEqual(active.violations, ())
        inactive = verify_static_amounts(request, (D(0), D(0)))
        self.assertEqual((inactive.ending_cash, inactive.trades), (D(10), ()))

    def test_shared_verifier_rejects_noncent_or_untyped_decisions(self):
        request, _ = static_case()
        for amounts in ([D(100), D(100)], (D(100),), (D(".001"), D(0)),
                        (D(-1), D(0)), (100.0, D(0)), (D("NaN"), D(0))):
            with self.subTest(amounts=amounts), self.assertRaises(InputValidationError):
                verify_static_amounts(request, amounts)

    def test_lot_and_minimum_ticket_remain_separate_exact_restrictions(self):
        request, _ = static_case()
        lot = replace(request, quotes=tuple(replace(q, lot_size=D(1)) for q in request.quotes))
        self.assertTrue(any("lot size" in error for error in verify_static_amounts(lot, (D("99.99"), D("99.99"))).violations))
        ticket = replace(request, quotes=tuple(replace(q, minimum_ticket=D(100)) for q in request.quotes))
        self.assertTrue(any("minimum ticket" in error for error in verify_static_amounts(ticket, (D(99), D(99))).violations))

    def test_nonzero_objective_underflow_is_explicit_failure(self):
        request, _ = static_case()
        old = replace(request.holdings[0].asset, factor=D("2e-400"))
        new = replace(request.quotes[1].asset, factor=D("1e-400"))
        request = replace(request, holdings=(Holding(old, D(100)),), quotes=(
            replace(request.quotes[0], asset=old), replace(request.quotes[1], asset=new)))
        with self.assertRaisesRegex(InputValidationError, "numeric range"):
            StaticTradeOptimizer().solve(request)

    def test_custom_optimizer_cannot_replay_a_breaching_closing_pool(self):
        request = construction_fixture()
        permitted = StaticTradeOptimizer().solve(request.optimization_request)
        tightened = replace(request, optimization_request=replace(request.optimization_request,
            limits=replace(request.optimization_request.limits, maximum_overall_factor=D(1999))))
        class ForgedOptimizer:
            def solve(self, mandate):
                return permitted
        with self.assertRaisesRegex(InputValidationError, "static mandate"):
            ClosingPoolRedesignService(optimizer=ForgedOptimizer()).run(tightened)

    def test_explicit_coupon_metadata_conflict_is_quarantined_before_replay(self):
        item = candidate()
        conflicting = replace(item, exposure=replace(item.exposure, coupon_type=CouponType.FIXED,
                                                     fixed_coupon_rate=D(".05")))
        result = CandidateUniverseValidator().validate(snapshot(conflicting), admission_policy())
        self.assertEqual(result.admitted, ())
        self.assertTrue(any("coupon type" in reason for reason in result.quarantined[0].reasons))


class CandidateResolutionAuditTests(unittest.TestCase):
    def test_three_irr_tolerance_chain_keeps_selected_candidate_on_frontier(self):
        rows = [ranking_row("A", ".10000000000", 100), ranking_row("B", ".10000000006", 200),
                ranking_row("C", ".10000000012", 300)]
        tolerance = Fraction(D("1e-10"))
        for ordered in permutations(rows):
            with self.subTest(order=[row.candidate_id for row in ordered]):
                self.assertEqual(_frontier(list(ordered), tolerance), {"A", "B"})
                self.assertEqual([row.candidate_id for row in _rank(list(ordered), CandidateSelectionPolicy.MAX_EQUITY_IRR, tolerance)],
                                 ["B", "C", "A"])
                for policy in CandidateSelectionPolicy:
                    self.assertIn(_rank(list(ordered), policy, tolerance)[0].candidate_id, _frontier(list(ordered), tolerance))

    def test_zero_tolerance_retains_exact_tradeoffs_and_equal_evidence(self):
        rows = [ranking_row("A", ".1", 100), ranking_row("B", ".10000000006", 200),
                ranking_row("C", ".10000000012", 300), ranking_row("D", ".10000000012", 300)]
        self.assertEqual(_frontier(rows, Fraction(0)), {"A", "B", "C", "D"})
        self.assertEqual([row.candidate_id for row in _rank(rows, CandidateSelectionPolicy.MAX_EQUITY_IRR, Fraction(0))],
                         ["C", "D", "B", "A"])

    def test_same_factor_uses_common_bucket_then_stable_identifier(self):
        rows = [ranking_row("A", ".10000000000", 100), ranking_row("B", ".10000000006", 100),
                ranking_row("C", ".10000000012", 300)]
        tolerance = Fraction(D("1e-10"))
        self.assertEqual(_frontier(rows, tolerance), {"B"})
        self.assertEqual([row.candidate_id for row in _rank(rows, CandidateSelectionPolicy.MIN_FACTOR_THEN_IRR, tolerance)],
                         ["B", "A", "C"])


class ScenarioComparisonAuditTests(unittest.TestCase):
    def test_fixed_coupon_edits_sync_wac_without_mutating_baseline(self):
        baseline = scenario_fixture(fixed=True)
        baseline = replace(baseline, exposures=(replace(baseline.exposures[0],
            coupon_type=CouponType.FIXED, fixed_coupon_rate=D(".1")),))
        batch = ScenarioRunner().run(baseline, (
            ScenarioDefinition("HIGH", (ScenarioEdit(ScenarioTarget.ASSET, "L1", "fixed_rate", D(".12")),)),
            ScenarioDefinition("LOW", (ScenarioEdit(ScenarioTarget.ASSET, "L1", "fixed_rate", D(".08")),)),
        ))
        for scenario, rate, delta in zip(batch.scenarios, (D(".12"), D(".08")), (D(".02"), D("-.02")), strict=True):
            self.assertEqual(scenario.request.exposures[0].fixed_coupon_rate, rate)
            self.assertEqual(metric_row(scenario.comparisons, "OPENING_METRIC", "WAC_RATE").delta, delta)
            self.assertGreater(abs(metric_row(scenario.comparisons, "MODEL", "ASSET_TOTAL_INTEREST").delta), 0)
        self.assertEqual(baseline.exposures[0].fixed_coupon_rate, D(".1"))
        self.assertEqual(baseline.cashflow_request.positions[0].terms.fixed_rate, D(".1"))

    def test_acquisition_price_scenario_preserves_distinct_frozen_ccc_market_mark(self):
        baseline = annual_model()
        baseline = replace(baseline, oc_asset_data=(OcAssetData("L1", True, True, D(1), D(".55")),))
        edited = _apply_edits(baseline, ScenarioDefinition("PRICE", (
            ScenarioEdit(ScenarioTarget.ASSET, "L1", "clean_price_pct", D(90)),)))
        self.assertEqual(edited.oc_asset_data[0].clean_price_fraction, D(".9"))
        self.assertEqual(edited.oc_asset_data[0].market_price_fraction, D(".55"))
        self.assertEqual(baseline.oc_asset_data[0].clean_price_fraction, D(1))

    def test_native_and_imported_fractional_credit_comparisons_use_actual_clo_ledgers(self):
        baseline = annual_model()
        left = TridentModelService().run(baseline)
        overlay = OriginalPoolOverlay(True, D(".2"), D(0), D(".4"), 0)
        native = replace(baseline, clo_terms=replace(baseline.clo_terms, original_pool_overlay=overlay))
        imported = compile_imported_cashflows(CollateralCashflowInputMode.DETAILED, START, D(100),
            detailed_rows=(DetailedImportedCashflow("L1", 1, YEAR_ONE, D(100), D(10), D(100), D(0), D(110)),),
            overlay_enabled=True)
        for request in (native, replace(native, imported_collateral=imported)):
            with self.subTest(imported=request.imported_collateral is not None):
                right = TridentModelService().run(request)
                self.assertEqual(right.credit_projections, ())
                comparisons, periods = compare_model_results("CREDIT", baseline, left, request, right)
                for name, expected in (("TOTAL_DEFAULTED_EXPOSURE", 20), ("TOTAL_RECOVERY_COLLECTIONS", 8),
                                       ("TOTAL_RECOGNIZED_PAR_LOSS", 12), ("FINAL_DEFAULTED_PAR", 0)):
                    observation = metric_row(comparisons, "CREDIT", name)
                    self.assertEqual((observation.baseline_value, observation.scenario_value, observation.delta),
                                     (D(0), D(expected), D(expected)))
                for name, expected in (("NEWLY_DEFAULTED_PAR", 20), ("RECOVERY_PRINCIPAL_RECEIVED", 8),
                                       ("RECOGNIZED_PAR_LOSS", 12), ("SCHEDULED_PRINCIPAL_RECEIVED", 80)):
                    self.assertEqual(period_row(periods, YEAR_ONE, None, name).scenario_value, D(expected))

    def test_synthetic_cohort_credit_is_compared_without_explicit_whole_loan_events(self):
        baseline = annual_model(final=YEAR_TWO)
        policy = SyntheticReinvestmentPolicy(True, YEAR_ONE, purchase_price=D(1), bullet_wal_years=D(1),
            spread_bps=D(1000), annual_default_rate=D(".2"), annual_prepayment_rate=D(0),
            recovery_rate=D(".4"), recovery_lag_months=0, day_count=DayCount.ACT_365F)
        request = replace(baseline, clo_terms=replace(baseline.clo_terms,
            reinvestment_strategy="SYNTHETIC_TEMPLATE", synthetic_reinvestment_policy=policy))
        left, right = TridentModelService().run(baseline), TridentModelService().run(request)
        self.assertEqual(right.credit_projections, ())
        self.assertEqual(right.clo.reinvestment_purchases[0].acquired_par, D(100))
        comparisons, periods = compare_model_results("COHORT", baseline, left, request, right)
        self.assertEqual(metric_row(comparisons, "CREDIT", "TOTAL_DEFAULTED_EXPOSURE").delta, D(20))
        self.assertEqual(metric_row(comparisons, "CREDIT", "TOTAL_RECOVERY_COLLECTIONS").delta, D(8))
        self.assertEqual(metric_row(comparisons, "CREDIT", "TOTAL_RECOGNIZED_PAR_LOSS").delta, D(12))
        self.assertEqual(period_row(periods, YEAR_TWO, None, "SCHEDULED_PRINCIPAL_RECEIVED").scenario_value, D(80))
        self.assertEqual(period_row(periods, YEAR_TWO, None, "RECOVERY_PRINCIPAL_RECEIVED").scenario_value, D(8))
        self.assertEqual(period_row(periods, YEAR_ONE, "A", "CLOSING_BALANCE").scenario_value, D(60))

    def test_class_coupon_principal_and_arrears_channels_have_dated_comparisons(self):
        baseline = annual_model(note_rate=D(".04"))
        batch = ScenarioRunner().run(baseline, (ScenarioDefinition("COUPON", (
            ScenarioEdit(ScenarioTarget.NOTE, "A", "fixed_rate", D(".05")),)),))
        periods = batch.scenarios[0].period_comparisons
        for name, before, after in (("CURRENT_COUPON_DUE", "2.4", "3"),
                ("COUPON_PAID_FROM_INTEREST", "2.4", "3"), ("COUPON_PAID_FROM_PRINCIPAL", "0", "0"),
                ("PRINCIPAL_FROM_PRINCIPAL", "60", "60"), ("PRINCIPAL_FROM_INTEREST", "0", "0"),
                ("OPENING_COUPON_ARREARS", "0", "0"), ("CLOSING_COUPON_ARREARS", "0", "0")):
            row = period_row(periods, YEAR_ONE, "A", name)
            self.assertEqual((row.baseline_value, row.scenario_value), (D(before), D(after)))
        self.assertEqual(period_row(periods, YEAR_ONE, "A", "CURRENT_COUPON_DUE").delta, D(".6"))

    def test_idt_comparisons_report_cash_transfer_separately_from_note_redemption(self):
        baseline = annual_model(maturity=YEAR_TWO, final=YEAR_TWO)
        request = replace(baseline, clo_terms=replace(baseline.clo_terms,
            interest_diversion_test_enabled=True, interest_diversion_test_class_id="A",
            interest_diversion_test_oc_minimum=D(2), interest_diversion_test_max_fraction=D(".5"),
            interest_diversion_test_end_date=YEAR_ONE))
        left, right = TridentModelService().run(baseline), TridentModelService().run(request)
        _, periods = compare_model_results("IDT", baseline, left, request, right)
        # OC numerator100 needs120, but 50% of interest10 caps transfer at5.
        self.assertEqual(period_row(periods, YEAR_ONE, None, "INTEREST_DIVERSION_TEST_TRANSFERRED").delta, D(5))
        self.assertEqual(period_row(periods, YEAR_ONE, None, "INTEREST_DIVERSION_TEST_HELD_PRINCIPAL").delta, D(5))
        self.assertEqual(period_row(periods, YEAR_ONE, None, "IDT_STATUS").scenario_status, "FAIL")
        self.assertEqual(period_row(periods, YEAR_ONE, "A", "PRINCIPAL_FROM_INTEREST").scenario_value, D(0))
        self.assertEqual(period_row(periods, YEAR_ONE, "A", "CLOSING_BALANCE").scenario_value, D(60))

    def test_no_clo_does_not_manufacture_zero_credit_or_period_evidence(self):
        baseline = annual_model()
        request = replace(baseline, clo_terms=None, notes=())
        left, right = TridentModelService().run(baseline), TridentModelService().run(request)
        comparisons, periods = compare_model_results("NO_CLO", baseline, left, request, right)
        credit = metric_row(comparisons, "CREDIT", "TOTAL_DEFAULTED_EXPOSURE")
        self.assertEqual((credit.scenario_value, credit.scenario_status, credit.delta_status),
                         (None, "NOT_PRESENT", "UNAVAILABLE"))
        self.assertTrue(all(row.scenario_value is None and row.scenario_status == "NOT_PRESENT" for row in periods))


if __name__ == "__main__":
    unittest.main()
