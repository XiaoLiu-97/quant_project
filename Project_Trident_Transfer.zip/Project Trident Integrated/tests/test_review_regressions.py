"""Independent application-boundary regressions found during financial review."""

from dataclasses import replace
from datetime import date
from decimal import Decimal
import unittest

from trident.application.services import CashflowRunRequest, CashflowRunService
from trident.adapters.records import position_from_record
from trident.conventions.calendar import BusinessDayConvention
from trident.conventions.schedule import AccrualDateBasis
from trident.domain.models import CouponType, InputValidationError, LoanPosition, LoanTerms
from trident.funding.engine import AssetPurchase
from trident.market import FlatRateProvider


def fixed_position(loan_id: str, start: date, maturity: date) -> LoanPosition:
    """A small cash-pay loan with an explicit opening snapshot and no history."""
    terms = LoanTerms(
        loan_id=loan_id,
        currency="EUR",
        start_date=start,
        maturity_date=maturity,
        reference_principal=Decimal("100.00"),
        coupon_type=CouponType.FIXED,
        fixed_rate=Decimal("0.05"),
        business_day_convention=BusinessDayConvention.UNADJUSTED,
        accrual_date_basis=AccrualDateBasis.UNADJUSTED,
    )
    return LoanPosition(terms, start, Decimal("100.00"))


def request_for(positions: tuple[LoanPosition, ...]) -> CashflowRunRequest:
    """No debt or fees; equity pays exactly each loan's EUR100 purchase price."""
    return CashflowRunRequest(
        positions=positions,
        purchases=tuple(AssetPurchase(position.terms.loan_id, Decimal("100.00"), Decimal("100")) for position in positions),
        issues=(),
        rate_provider=FlatRateProvider({}),
        upfront_fees=Decimal("0"),
        cash_reserve=Decimal("0"),
        rate_provenance="SYNTHETIC_REVIEW_TEST",
    )


def fixed_record() -> dict[str, object]:
    """A valid adapter record independent of the synthetic portfolio fixtures."""
    return {
        "loan_id": "BOUNDARY_REVIEW",
        "currency": "EUR",
        "initial_par": "100.00",
        "current_par": "100.00",
        "par_as_of_date": "2026-01-20",
        "cashflow_projection_start_date": "2026-01-20",
        "maturity_date_unadjusted": "2026-04-20",
        "coupon_type": "FIXED",
        "fixed_rate": "0.05",
        "day_count": "ACT/360",
        "frequency_months": 3,
        "schedule_anchor_day": 20,
        "business_day_convention": "UNADJUSTED",
        "holiday_calendar": "TARGET",
        "accrual_date_basis": "UNADJUSTED",
        "fixing_lag_target_business_days": 2,
        "amortization_type": "BULLET",
        "credit_status": "PERFORMING",
        "pik": False,
        "revolver": False,
        "construction_risk": False,
    }


class CommonSnapshotRegressionTests(unittest.TestCase):
    def test_positions_from_different_years_cannot_be_one_closing_funding(self) -> None:
        current = fixed_position("CURRENT", date(2026, 1, 20), date(2026, 4, 20))
        future = fixed_position("FUTURE", date(2027, 1, 20), date(2027, 4, 20))
        with self.assertRaisesRegex(InputValidationError, "one projection/closing as-of date"):
            CashflowRunService().run(request_for((current, future)))

    def test_even_one_day_difference_requires_explicit_settlement_model(self) -> None:
        first = fixed_position("DAY_ONE", date(2026, 1, 20), date(2026, 4, 20))
        second = fixed_position("DAY_TWO", date(2026, 1, 21), date(2026, 4, 21))
        with self.assertRaisesRegex(InputValidationError, "one projection/closing as-of date"):
            CashflowRunService().run(request_for((first, second)))

    def test_common_snapshot_allows_heterogeneous_maturities_and_reports_as_of(self) -> None:
        short = fixed_position("SHORT", date(2026, 1, 20), date(2026, 4, 20))
        long = fixed_position("LONG", date(2026, 1, 20), date(2026, 7, 20))
        result = CashflowRunService().run(request_for((short, long)))
        self.assertEqual(result.projection_start_date, date(2026, 1, 20))
        self.assertEqual(result.first_payment_date, date(2026, 4, 20))
        # Jan 20-to-Apr 20 is 90 actual days: EUR100 * 5% * 90/360 = EUR1.25 each.
        self.assertEqual(result.first_payment_interest, Decimal("2.50"))
        self.assertEqual(result.total_principal, Decimal("200.00"))
        self.assertEqual(result.funding.equity_cash_funding, Decimal("200.00"))


class UnsupportedEconomicsRegressionTests(unittest.TestCase):
    def test_fixed_asset_cannot_silently_ignore_registered_reset_frequency(self) -> None:
        row = fixed_record()
        row["reset_frequency_months"] = 1
        with self.assertRaisesRegex(InputValidationError, "Fixed loans cannot specify floating reset frequency"):
            position_from_record(row)

    def test_coupon_cap_cannot_be_silently_ignored(self) -> None:
        row = fixed_record()
        row["coupon_cap_bps"] = "400"
        with self.assertRaisesRegex(InputValidationError, "unregistered fields.*coupon_cap_bps"):
            position_from_record(row)

    def test_classified_user_note_is_accepted_without_changing_contract(self) -> None:
        row = fixed_record()
        expected = position_from_record(row)
        row["user_note"] = "Reviewed loan; this is descriptive metadata."
        self.assertEqual(position_from_record(row), expected)


class RateProvenanceRegressionTests(unittest.TestCase):
    def test_user_label_cannot_make_a_synthetic_flat_provider_observed(self) -> None:
        position = fixed_position("LABEL_REVIEW", date(2026, 1, 20), date(2026, 4, 20))
        misleading_label = "OBSERVED_ACTUAL_FIXINGS"
        request = replace(
            request_for((position,)),
            rate_provider=FlatRateProvider({}, provenance=misleading_label),
            rate_provenance=misleading_label,
        )
        result = CashflowRunService().run(request)
        self.assertEqual(result.rate_provider_kind, "SYNTHETIC_FLAT")
        self.assertIsNone(result.market_data_as_of)


if __name__ == "__main__":
    unittest.main()
