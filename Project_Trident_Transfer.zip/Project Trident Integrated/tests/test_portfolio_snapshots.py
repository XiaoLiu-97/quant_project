"""Portfolio quality never inherits stale opening or aggregate metadata."""

from dataclasses import replace
from datetime import date
from decimal import Decimal
import unittest

from trident.adapters.credit_example import credit_example_request
from trident.analysis import AssetExposure, LimitDirection, LimitSpec, PortfolioAnalyzer
from trident.analysis.models import LimitStatus, MetricStatus
from trident.application.imported_cashflows import CollateralCashflowInputMode, DetailedImportedCashflow, SimplifiedImportedCashflow, compile_imported_cashflows
from trident.application.portfolio_snapshots import build_opening_portfolio, build_portfolio_snapshots
from trident.application.services import CashflowRunService
from trident.clo import CloRunRequest, CloTerms, DefaultedAssetOcTreatment, NoteTranche
from trident.clo.engine import DeterministicCloEngine
from trident.clo.reinvestment import SyntheticReinvestmentLedger, SyntheticReinvestmentPolicy
from trident.conventions import AccrualDateBasis, BusinessDayConvention
from trident.credit.overlay import OriginalPoolOverlay
from trident.domain.models import CouponType
from trident.market.rates import FlatRateProvider

from test_credit_overlay_reinvestment import START, row


D = Decimal


def example_projection():
    request = credit_example_request()
    reference = CashflowRunService().run(request.cashflow_request)
    result = DeterministicCloEngine(request.cashflow_request.rate_provider).run(CloRunRequest(reference.cashflows, D(100), request.notes, request.clo_terms))
    return request, reference, result


class LongDatedAnalysisTests(unittest.TestCase):
    def test_explicit_legal_final_makes_correct_fraction_and_equality_limit(self):
        short = AssetExposure("S", "O1", "BSL", "CORPORATE", "FR", "S1", "EUR", D(80), D(400), date(2027, 1, 1))
        long = replace(short, loan_id="L", obligor="O2", par=D(20), maturity_date=date(2030, 1, 1))
        limit = LimitSpec("LONG", "LONG_DATED_FRACTION", D("0.2"))
        report = PortfolioAnalyzer().analyze((short, long), START, limits=(limit,), legal_final_date=date(2029, 1, 1))
        self.assertEqual(report.metric("LONG_DATED_FRACTION").value, D("0.2"))
        self.assertIs(report.limits[0].status, LimitStatus.PASS)
        report = PortfolioAnalyzer().analyze((short, long), START, limits=(replace(limit, threshold=D("0.19999999999999999999999999999999999999")),), legal_final_date=date(2029, 1, 1))
        self.assertIs(report.limits[0].status, LimitStatus.BREACH)

    def test_legal_maturity_equality_is_not_long_dated(self):
        asset = AssetExposure("S", None, None, None, None, None, "EUR", D(100), None, date(2027, 1, 1))
        report = PortfolioAnalyzer().analyze((asset,), START, legal_final_date=date(2027, 1, 1))
        self.assertEqual(report.metric("LONG_DATED_FRACTION").value, 0)

    def test_missing_legal_final_cannot_pass_long_dated_limit(self):
        asset = AssetExposure("S", None, None, None, None, None, "EUR", D(100), None, date(2027, 1, 1))
        report = PortfolioAnalyzer().analyze((asset,), START, limits=(LimitSpec("L", "LONG_DATED_FRACTION", D(1)),))
        self.assertIs(report.metric("LONG_DATED_FRACTION").status, MetricStatus.UNAVAILABLE)
        self.assertIs(report.limits[0].status, LimitStatus.UNAVAILABLE)


class SnapshotAuditTests(unittest.TestCase):
    @staticmethod
    def external_schedule(*, pik=False, stressed=False, incomplete=False):
        asset = AssetExposure("L1", "O1", "BSL", "CORPORATE", "FR", "S1", "EUR", D(100), None, date(2028, 1, 1))
        if pik:
            rows = (DetailedImportedCashflow("L1", 1, date(2026, 1, 1), D(100), D(0), D(0), D(110), D(0), D(10)),
                    DetailedImportedCashflow("L1", 2, date(2027, 1, 1), D(110), D(0), D(110), D(0), D(110)))
        else:
            rows = (DetailedImportedCashflow("L1", 1, date(2026, 1, 1), D(100), D(10), D(50), D(50), D(60)),)
            if not incomplete:
                rows += (DetailedImportedCashflow("L1", 2, date(2027, 1, 1), D(50), D(5), D(50), D(0), D(55)),)
        source = compile_imported_cashflows(CollateralCashflowInputMode.DETAILED, START, D(100), detailed_rows=rows, credit_effects_included=stressed)
        internal = (row(START, date(2028, 1, 1), 100, 100, 30),)
        return asset, source, internal

    def test_imported_opening_wal_uses_active_principal_dates_not_internal_bullet(self):
        asset, source, internal = self.external_schedule()
        report = build_opening_portfolio((asset,), internal, START, imported_collateral=source, legal_final_date=date(2027, 1, 1))
        # Two principal50 receipts at365days and730days -> WAL1.5 years.
        # Unused internalbullet would give3years and wronglongdated100%.
        self.assertEqual(report.metric("WAL_YEARS").value, D("1.5"))
        self.assertEqual(report.metric("LONG_DATED_FRACTION").value, 0)
        self.assertIs(report.metric("WEIGHTED_AVERAGE_MATURITY_YEARS").status, MetricStatus.UNAVAILABLE)
        self.assertIn("external", report.metric("LONG_DATED_FRACTION").message)

    def test_imported_future_wal_scales_only_active_external_remaining_principal(self):
        asset, source, internal = self.external_schedule()
        terms = CloTerms(START, date(2027, 1, 1), frequency_months=12,
                         business_day_convention=BusinessDayConvention.UNADJUSTED,
                         accrual_date_basis=AccrualDateBasis.UNADJUSTED)
        result = DeterministicCloEngine(FlatRateProvider({"EURIBOR_3M": D(0)})).run(CloRunRequest((), D(100),
            (NoteTranche("A", 1, D(60), CouponType.FIXED, fixed_rate=D(0)),), terms, imported_collateral=source))
        reports = build_portfolio_snapshots((asset,), internal, result, imported_collateral=source, legal_final_date=terms.legal_final_date)
        self.assertEqual(reports[0].total_par, 50)
        self.assertEqual(reports[0].metric("WAL_YEARS").value, 1)
        self.assertEqual(reports[-1].total_par, 0)

    def test_partial_imported_overlay_keeps_external_future_timing(self):
        asset, source, internal = self.external_schedule()
        terms = CloTerms(START, date(2027, 1, 1), frequency_months=12,
                         business_day_convention=BusinessDayConvention.UNADJUSTED,
                         accrual_date_basis=AccrualDateBasis.UNADJUSTED,
                         defaulted_asset_oc_treatment=DefaultedAssetOcTreatment.EXCLUDE,
                         original_pool_overlay=OriginalPoolOverlay(True, D(".2"), D(0), D(0), 0))
        result = DeterministicCloEngine(FlatRateProvider({"EURIBOR_3M": D(0)})).run(CloRunRequest((), D(100),
            (NoteTranche("A", 1, D(60), CouponType.FIXED, fixed_rate=D(0)),), terms, imported_collateral=source))
        reports = build_portfolio_snapshots((asset,), internal, result, imported_collateral=source, legal_final_date=terms.legal_final_date)
        self.assertEqual(reports[0].total_par, 40)
        self.assertEqual(reports[0].metric("WAL_YEARS").value, 1)

    def test_imported_pik_stressed_and_incomplete_never_reuse_internal_wal(self):
        limits = (LimitSpec("WAL", "WAL_YEARS", D(10)), LimitSpec("LONG", "LONG_DATED_FRACTION", D(1)))
        for option in ("pik", "stressed", "incomplete"):
            with self.subTest(option=option):
                asset, source, internal = self.external_schedule(**{option: True})
                report = build_opening_portfolio((asset,), internal, START, imported_collateral=source,
                                                 legal_final_date=date(2027, 1, 1), limits=limits)
                self.assertIs(report.metric("WAL_YEARS").status, MetricStatus.UNAVAILABLE)
                self.assertIs(report.metric("LONG_DATED_FRACTION").status, MetricStatus.UNAVAILABLE)
                self.assertTrue(all(limit.status is LimitStatus.UNAVAILABLE for limit in report.limits))

    def test_identified_external_principal_supports_wal_without_invented_rating(self):
        _, source, internal = self.external_schedule()
        report = build_opening_portfolio((), internal, START, imported_collateral=source, legal_final_date=date(2027, 1, 1))
        self.assertEqual(report.metric("WAL_YEARS").value, D("1.5"))
        self.assertEqual(report.metric("LONG_DATED_FRACTION").value, 0)
        self.assertIs(report.metric("WARF").status, MetricStatus.UNAVAILABLE)
        self.assertIs(report.metric("WEIGHTED_AVERAGE_MATURITY_YEARS").status, MetricStatus.UNAVAILABLE)

    def test_confirmed_imported_maturity_metadata_remains_available(self):
        asset, source, internal = self.external_schedule()
        asset = replace(asset, maturity_date=date(2027, 1, 1))
        report = build_opening_portfolio((asset,), internal, START, imported_collateral=source, legal_final_date=date(2027, 1, 1))
        self.assertEqual(report.metric("WEIGHTED_AVERAGE_MATURITY_YEARS").value, 2)

    def test_zero_face_late_interest_does_not_extend_external_principal_boundary(self):
        asset, source, internal = self.external_schedule()
        tail = DetailedImportedCashflow("L1", 3, date(2029, 1, 1), D(0), D(1), D(0), D(0), D(1))
        source = compile_imported_cashflows(CollateralCashflowInputMode.DETAILED, START, D(100),
                                            detailed_rows=source.detailed_rows + (tail,))
        self.assertEqual(source.final_principal_dates["L1"], date(2027, 1, 1))
        report = build_opening_portfolio((asset,), internal, START, imported_collateral=source,
                                         legal_final_date=date(2027, 1, 1))
        self.assertEqual(report.metric("WAL_YEARS").value, D("1.5"))
        self.assertEqual(report.metric("LONG_DATED_FRACTION").value, 0)

    def test_opening_reference_includes_source_principal_received_on_closing(self):
        asset, _, internal = self.external_schedule()
        source = compile_imported_cashflows(CollateralCashflowInputMode.DETAILED, START, D(100),
            detailed_rows=(DetailedImportedCashflow("L1", 1, START, D(100), D(0), D(100), D(0), D(100)),))
        report = build_opening_portfolio((asset,), internal, START, imported_collateral=source, legal_final_date=START)
        self.assertEqual(report.metric("WAL_YEARS").value, 0)
        self.assertEqual(report.metric("LONG_DATED_FRACTION").value, 0)

    def test_existing_contractual_snapshots_reconcile_full_engine(self):
        request, reference, result = example_projection()
        snapshots = build_portfolio_snapshots(request.exposures, reference.cashflows, result, legal_final_date=request.clo_terms.legal_final_date)
        self.assertEqual(len(snapshots), len(result.periods))
        self.assertEqual([r.total_par for r in snapshots], [r.closing_collateral_par for r in result.periods])
        self.assertEqual(snapshots[0].metric("LONG_DATED_FRACTION").value, 0)

    def test_partial_default_snapshot_and_future_wal_use_surviving_slice(self):
        rows = (row(START, date(2026, 1, 1), 100, 0, 10), row(date(2026, 1, 1), date(2027, 1, 1), 100, 100, 10, number=2))
        terms = CloTerms(START, date(2027, 1, 1), frequency_months=12,
                         business_day_convention=BusinessDayConvention.UNADJUSTED,
                         accrual_date_basis=AccrualDateBasis.UNADJUSTED,
                         defaulted_asset_oc_treatment=DefaultedAssetOcTreatment.EXCLUDE,
                         original_pool_overlay=OriginalPoolOverlay(True, D("0.2"), D(0), D(0), 0))
        result = DeterministicCloEngine(FlatRateProvider({"EURIBOR_3M": D(0)})).run(CloRunRequest(rows, D(100), (NoteTranche("A", 1, D(60), CouponType.FIXED, fixed_rate=D(0)),), terms))
        exposure = AssetExposure("L1", "O1", "BSL", "CORPORATE", "FR", "S1", "EUR", D(100), None, date(2027, 1, 1))
        snapshots = build_portfolio_snapshots((exposure,), rows, result, legal_final_date=terms.legal_final_date)
        self.assertEqual(snapshots[0].total_par, 80)
        self.assertEqual(snapshots[0].metric("WAL_YEARS").value, 1)
        self.assertEqual(snapshots[-1].total_par, 0)

    def test_synthetic_cohort_keeps_unknown_classification_and_rating(self):
        request, reference, base = example_projection()
        purchase_date = base.periods[0].payment_date
        selected = SyntheticReinvestmentPolicy(True, date(2030, 1, 1), annual_default_rate=D(0), annual_prepayment_rate=D(0), purchase_price=D(1))
        book = SyntheticReinvestmentLedger(selected, request.cashflow_request.rate_provider)
        purchase = book.purchase(purchase_date, D(10))
        period = replace(base.periods[0], closing_collateral_par=D(110), reinvestment_par_acquired=D(10), reinvestment_cash_used=D(10))
        result = replace(base, periods=(period,), reinvestment_purchases=(purchase,), reinvestment_par_movements=())
        report = build_portfolio_snapshots(request.exposures, reference.cashflows, result, reinvestment_policy=selected, legal_final_date=request.clo_terms.legal_final_date)[0]
        self.assertEqual(report.total_par, 110)
        self.assertIs(report.metric("LARGEST_OBLIGOR_FRACTION").status, MetricStatus.INCOMPLETE)
        self.assertIs(report.metric("BSL_WARR").status, MetricStatus.UNAVAILABLE)
        self.assertIs(report.metric("WARF").status, MetricStatus.UNAVAILABLE)
        self.assertTrue(any(row.dimension == "asset_class" and row.bucket is None and row.par == 10 for row in report.concentrations))

    def test_imported_aggregate_opening_has_no_fabricated_wal_or_quality(self):
        source = compile_imported_cashflows(CollateralCashflowInputMode.SIMPLIFIED, START, D(100),
                                            simplified_rows=(SimplifiedImportedCashflow(date(2026, 1, 1), D(10), D(100)),))
        limits = (LimitSpec("WAL", "WAL_YEARS", D(6)), LimitSpec("LONG", "LONG_DATED_FRACTION", D(1)))
        report = build_opening_portfolio((), (), START, limits=limits, imported_collateral=source, legal_final_date=date(2027, 1, 1))
        self.assertEqual(report.total_par, 100)
        self.assertEqual(report.asset_count, 1)
        self.assertIs(report.metric("WAL_YEARS").status, MetricStatus.UNAVAILABLE)
        self.assertIs(report.metric("LONG_DATED_FRACTION").status, MetricStatus.UNAVAILABLE)
        self.assertIs(report.metric("WEIGHTED_AVERAGE_MATURITY_YEARS").status, MetricStatus.UNAVAILABLE)
        self.assertTrue(all(limit.status is LimitStatus.UNAVAILABLE for limit in report.limits))

    def test_terminal_sale_removes_holdings_without_rewriting_past(self):
        request, reference, base = example_projection()
        first = base.periods[0]
        terminal = replace(base.periods[1], collateral_sale_par=D(100), closing_collateral_par=D(0))
        result = replace(base, periods=(first, terminal))
        snapshots = build_portfolio_snapshots(request.exposures, reference.cashflows, result, legal_final_date=request.clo_terms.legal_final_date)
        self.assertEqual(snapshots[0].total_par, 100)
        self.assertEqual(snapshots[1].total_par, 0)


if __name__ == "__main__":
    unittest.main()
