"""Reconcile isolated native results against independent financial identities.

The fixture was captured by desktop Excel from copies of the supplied XLSM
files, after checking embedded VBA against the supplied source exports. It is
evidence of the source model's behavior, not an unquestioned pricing oracle.
Correct cash cases are compared after the current engine's disclosed cent
posting. Legacy PIK columns, historical OIS projection, zero interpolation and
overnight day counts are explicitly tested as differences, not reproduced bugs.
No Excel installation, original workbook or optional VBA inspector is needed
to run these deterministic, read-only reconciliation tests.
"""

import json
from datetime import date, timedelta
from decimal import Decimal, ROUND_HALF_UP, localcontext
from fractions import Fraction
from pathlib import Path
import unittest

from trident.cashflows.engine import ContractualCashflowEngine
from trident.clo import CloRunRequest, CloTerms, DeterministicCloEngine, NoteTranche, report_tranche_periods
from trident.conventions import AccrualDateBasis, BusinessDayConvention, DayCount
from trident.conventions.calendar import CalendarName
from trident.domain.models import AmortizationType, CouponType, InterestMode, LoanCashflow, LoanPosition, LoanTerms
from trident.funding import AssetPurchase, ClosingCostBudget, ClosingCostItem, DebtIssue, FundingEngine
from trident.market.cash_accounts import CashCurveRateProvider, DiscountFactorCashCurve, ZeroCompounding, ZeroRatePoint
from trident.market.rates import CurveRangeError, ExtrapolationPolicy, FlatRateProvider, ProjectedRateCurve, RatePoint


ROOT = Path(__file__).resolve().parents[1]
D = Decimal


def money(value) -> Decimal:
    """Independent currency-unit posting, retaining decimal fixture digits."""
    return D(str(value)).quantize(D(".01"), rounding=ROUND_HALF_UP)


def excel_date(serial) -> date:
    return date(1899, 12, 30) + timedelta(days=int(serial))


class LegacyNativeMigrationTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.fixture = json.loads((ROOT / "tests/fixtures/legacy_native_outputs.json").read_text(encoding="utf-8"))
        cls.proof = json.loads((ROOT / "docs/validation/legacy_migration_source.json").read_text(encoding="utf-8"))
        cls.cases = {case["case_id"]: case for case in cls.fixture["workbooks"]["cashflow_generator"]["controlled_cases"]}

    def sheet(self, workbook, name):
        return next(sheet for sheet in self.fixture["workbooks"][workbook]["sheets"] if sheet["sheet"] == name)["rows"]

    def terms(self, case_id, **changes):
        """Bind the economic inputs, rather than source worksheet cell positions."""
        inputs = self.cases[case_id]["inputs"]
        mode = InterestMode(inputs["inp_InterestPaymentType"].upper())
        amortization = {
            "Bullet": AmortizationType.BULLET, "Linear": AmortizationType.LINEAR_AUTO,
            "Annuity": AmortizationType.ANNUITY, "Accelerated": AmortizationType.ACCELERATED_AUTO,
        }[inputs["inp_AmortizationType"]]
        values = dict(loan_id=inputs["inp_AssetID"], currency=inputs["inp_Currency"],
            start_date=date(2026, 1, 1), maturity_date=date(2028, 1, 1), reference_principal=D(100),
            coupon_type=CouponType.FIXED, fixed_rate=D(".05"), frequency_months=12,
            day_count=DayCount.THIRTY_E_360, fixing_lag_business_days=0,
            business_day_convention=BusinessDayConvention.UNADJUSTED,
            accrual_date_basis=AccrualDateBasis.UNADJUSTED,
            holiday_calendar=CalendarName(inputs["inp_Calendar"]),
            interest_mode=mode, pik_fraction=D(str(inputs["inp_PIKShare"])),
            amortization_type=amortization)
        if amortization is not AmortizationType.BULLET:
            values["balloon_amount"] = D(0)
        if amortization is AmortizationType.ACCELERATED_AUTO:
            # The old 1.1 multiplier is a 10% growth fraction in the typed API.
            values["amortization_growth"] = D(".1")
        if case_id == "lagged_linear":
            values.update(business_day_convention=BusinessDayConvention.FOLLOWING, payment_lag_business_days=2)
        values.update(changes)
        return LoanTerms(**values)

    def project(self, case_id, provider=None, **changes):
        terms = self.terms(case_id, **changes)
        return ContractualCashflowEngine(provider or FlatRateProvider({"EURIBOR_3M": D(".02")})).generate(
            LoanPosition(terms, terms.start_date, terms.reference_principal))

    def assert_cash_case(self, case_id):
        current = self.project(case_id)
        native = self.cases[case_id]["rows"]
        self.assertEqual(len(current), len(native))
        for row, old in zip(current, native, strict=True):
            self.assertEqual((row.accrual_start, row.accrual_end, row.payment_date),
                tuple(excel_date(old[index]) for index in (2, 3, 4)))
            for value, column in ((row.opening_balance, 5), (row.cash_interest, 17),
                    (row.principal_repayment, 19), (row.closing_balance, 20), (row.total_cash, 21)):
                self.assertEqual(value, money(old[column]), (case_id, row.period_number, column))

    def test_capture_provenance_and_embedded_source_matches(self):
        self.assertTrue(self.proof["all_originals_unchanged"])
        self.assertEqual(self.proof["native_execution"]["status"], "COMPLETED")
        self.assertTrue(self.proof["controlled_inputs_used"])
        self.assertEqual({source["label"]: source["exported_bas_count"] for source in self.proof["sources"]},
                         {"cashflow_generator": 9, "clo_model": 15})
        for source in self.proof["sources"]:
            self.assertTrue(source["all_exported_executable_tokens_match"])
            self.assertEqual(source["original_sha256"], source["original_sha256_after"])
            self.assertFalse(source["xlm_macrosheets_present"])
        self.assertEqual(set(self.cases), {"fixed_bullet", "linear", "annuity", "accelerated", "pik_bullet",
            "mixed_bullet", "floating_euribor", "estr", "sofr", "sonia", "lagged_linear"})

    def test_native_self_tests_are_counted_without_the_summary_row(self):
        cf = [row["values"] for row in self.sheet("cashflow_generator", "Test Results") if row["row"] >= 5]
        clo = [row["values"] for row in self.sheet("clo_model", "Test Results") if row["row"] >= 6]
        self.assertEqual(sum(row[6] == "PASS" for row in cf), 191)
        self.assertEqual([row[0] for row in cf if row[6] == "FAIL"], ["IT-CLO-02", "IT-CLO-03"])
        self.assertEqual(sum(row[1] == "PASS" for row in clo), 58)
        self.assertEqual(sum(row[1] == "FAIL" for row in clo), 0)

    def test_fixed_bullet_native_dates_and_money(self):
        self.assert_cash_case("fixed_bullet")
        self.assertEqual([row.total_cash for row in self.project("fixed_bullet")], [D(5), D(105)])

    def test_linear_native_dates_and_money(self):
        self.assert_cash_case("linear")
        self.assertEqual([row.principal_repayment for row in self.project("linear")], [D(50), D(50)])

    def test_accelerated_native_and_independent_geometric_calibration(self):
        self.assert_cash_case("accelerated")
        # (100 - zero balloon)/(1 + 1.1) = 1000/21, then maturity sweeps.
        self.assertEqual(self.project("accelerated")[0].principal_repayment,
                         money(D(1000) / D(21)))

    def test_cash_annuity_native_and_independent_pmt(self):
        self.assert_cash_case("annuity")
        q = Fraction(21, 20)
        payment = Fraction(100) * Fraction(1, 20) / (1 - q ** -2)
        self.assertEqual(payment, Fraction(2205, 41))
        self.assertEqual([row.total_cash for row in self.project("annuity")], [D("53.78"), D("53.78")])
        # Independent explicit balloon case, supplementary to native capture.
        rows = self.project("annuity", balloon_amount=D(20))
        balloon_payment = (Fraction(100) - Fraction(20) / q ** 2) / (1 / q + 1 / q ** 2)
        with localcontext() as context:
            context.prec = 40
            posted = money(D(balloon_payment.numerator) / D(balloon_payment.denominator))
        self.assertEqual(rows[0].total_cash, posted)
        # Cent posting makes first principal 44.02-5=39.02 and remaining
        # face 60.98. Maturity pays that face plus 60.98*5%=3.05, including
        # the disclosed 0.01 final rounding settlement above ideal P+balloon.
        self.assertEqual(rows[1].total_cash, D("64.03"))
        self.assertEqual(rows[1].total_cash, posted + D(20) + D(".01"))
        self.assertEqual(sum(row.principal_repayment for row in rows), D(100))

    def test_pik_native_terminal_cash_is_retained_but_column_identities_are_corrected(self):
        old = self.cases["pik_bullet"]["rows"][-1]
        self.assertEqual(D(str(old[5])) + D(str(old[18])) - D(str(old[19])), D("5.25"))
        self.assertNotEqual(D(str(old[21])), D(str(old[17])) + D(str(old[19])))
        rows = self.project("pik_bullet")
        self.assertEqual(rows[-1].principal_repayment, D("110.25"))
        self.assertEqual(rows[-1].total_cash, money(old[21]))
        for row in rows:
            self.assertEqual(row.opening_balance + row.pik_interest - row.principal_repayment, row.closing_balance)
            self.assertEqual(row.total_cash, row.cash_interest + row.principal_repayment)
        self.assertEqual(sum(row.principal_repayment - row.pik_interest for row in rows), D(100))

    def test_mixed_native_cash_and_explicit_cent_residual(self):
        rows = self.project("mixed_bullet")
        # Second gross is 102.50 * 5% = 5.125. Post gross 5.13 and PIK
        # 2.5625 -> 2.56 separately; cash is the 2.57 balancing residual.
        self.assertEqual((rows[-1].gross_interest, rows[-1].pik_interest, rows[-1].cash_interest),
                         (D("5.13"), D("2.56"), D("2.57")))
        self.assertEqual(rows[-1].principal_repayment, D("105.06"))
        self.assertEqual(rows[-1].total_cash, money(self.cases["mixed_bullet"]["rows"][-1][21]))
        self.assertEqual(rows[-1].total_cash, D("107.63"))

    def test_london_payment_lag_preserves_native_nominal_coupon_and_principal(self):
        self.assert_cash_case("lagged_linear")
        rows = self.project("lagged_linear")
        self.assertEqual([row.payment_date for row in rows], [date(2027, 1, 6), date(2028, 1, 6)])
        self.assertEqual([row.cash_interest for row in rows], [D(5), D("2.50")])

    def test_euribor_multi_reset_matches_native_frozen_projected_curve(self):
        market = self.sheet("cashflow_generator", "Market - Rates")
        points = tuple(RatePoint(date.fromisoformat(row["values"][0][:10]), D(str(row["values"][2])))
                       for row in market if 6 <= row["row"] <= 245 and len(row["values"]) > 2)
        curve = ProjectedRateCurve("EURIBOR_3M", points, ExtrapolationPolicy.FLAT,
            "FROZEN_LEGACY_DUMMY_PROJECTED_CURVE_WITH_EXPLICIT_FLAT_ENDPOINTS")
        rows = self.project("floating_euribor", curve, coupon_type=CouponType.FLOATING, fixed_rate=None,
            rate_index="EURIBOR_3M", reset_frequency_months=3, spread_bps=D(350))
        for current, old in zip(rows, self.cases["floating_euribor"]["rows"], strict=True):
            self.assertEqual(len(current.coupon_segments), 4)
            self.assertLess(abs(current.interest_unrounded - D(str(old[16]))), D("1e-12"))
            self.assertEqual(current.cash_interest, money(old[17]))

    def overnight_data(self, case_id):
        market = self.sheet("cashflow_generator", "Market - Rates")
        points = [(D(str(row["values"][6])), D(str(row["values"][{"estr": 7, "sofr": 8, "sonia": 9}[case_id]])))
                  for row in market if 6 <= row["row"] <= 25]
        base = date.fromisoformat(next(row["values"][7][:10] for row in market if row["row"] == 32))
        return points, base

    def independent_legacy_df(self, case_id, value):
        """Re-perform documented legacy linear-zero/continuous-DF convention.

        Unlike the production log-DF interpolator this function is a small
        audit formula. Its pre-curve clamp is deliberately labeled as legacy
        behavior, not exposed as a valid current projection convention.
        """
        points, base = self.overnight_data(case_id)
        if value <= base:
            return D(1)
        with localcontext() as context:
            context.prec = 50
            t = D((value - base).days) / D(365)
            z = points[0][1] if t <= points[0][0] else points[-1][1]
            for (left, zl), (right, zr) in zip(points, points[1:]):
                if left < t <= right:
                    z = zl + (zr - zl) * (t - left) / (right - left)
                    break
            return (-z * t).exp()

    def test_all_three_native_overnight_factors_have_independent_discount_ratio_proof(self):
        for case_id in ("estr", "sofr", "sonia"):
            for old in self.cases[case_id]["rows"]:
                with self.subTest(case=case_id, period=old[1]), localcontext() as context:
                    context.prec = 50
                    factor = self.independent_legacy_df(case_id, excel_date(old[2])) / self.independent_legacy_df(case_id, excel_date(old[3])) - 1
                    gross = D(100) * (factor + D(".035") * D(str(old[15])))
                    self.assertLess(abs(gross - D(str(old[16]))), D("1e-12"))

    def test_overnight_current_basis_and_matched_endpoint_discount_factors(self):
        for case_id, currency, basis in (("estr", "EUR", DayCount.ACT_360),
                ("sofr", "USD", DayCount.ACT_360), ("sonia", "GBP", DayCount.ACT_365F)):
            with self.subTest(case=case_id), localcontext() as context:
                context.prec = 50
                old = self.cases[case_id]["rows"][1]
                start, end = excel_date(old[2]), excel_date(old[3])
                _, base = self.overnight_data(case_id)
                # Insert independently re-performed endpoint zeros, so the
                # comparison isolates DF-ratio coupon math from an intentionally
                # different production interpolation policy between market nodes.
                points = tuple(ZeroRatePoint(D((value - base).days) / D(365),
                    -self.independent_legacy_df(case_id, value).ln() / (D((value - base).days) / D(365)))
                    for value in (start, end))
                curve = DiscountFactorCashCurve(case_id.upper(), base, points, ZeroCompounding.CONTINUOUS,
                    DayCount.ACT_365F, provenance="INDEPENDENT_LEGACY_ENDPOINT_DF_RECONCILIATION")
                provider = CashCurveRateProvider(FlatRateProvider({"EURIBOR_3M": D(".02")}), {case_id.upper(): curve})
                rows = self.project(case_id, provider, start_date=start, maturity_date=end,
                    coupon_type=CouponType.FLOATING, fixed_rate=None, rate_index=case_id.upper(), currency=currency,
                    day_count=basis, spread_bps=D(350))
                reference_factor = self.independent_legacy_df(case_id, start) / self.independent_legacy_df(case_id, end) - 1
                expected = D(100) * (reference_factor + D(".035") * D((end - start).days) / D(365 if case_id == "sonia" else 360))
                self.assertEqual(rows[0].cash_interest, money(expected))
                self.assertLess(abs(D(rows[0].coupon_segments[0].exact_index_factor.numerator) /
                    D(rows[0].coupon_segments[0].exact_index_factor.denominator) - reference_factor), D("1e-45"))
                with self.assertRaises(CurveRangeError):
                    curve.discount_factor(date(2026, 1, 1))

    def test_native_clo_sources_uses_and_actual_equity_cash_funding(self):
        liability = [row["values"] for row in self.sheet("clo_model", "Liability") if 6 <= row["row"] <= 11]
        uses_rows = self.sheet("clo_model", "Sources & Uses")
        by_number = {row["row"]: row["values"] for row in uses_rows}
        budget = ClosingCostBudget(D("684631023"), D(".0075"), tuple(
            ClosingCostItem(f"COST_{row}", money(by_number[row][1])) for row in range(23, 31)))
        funding = FundingEngine().calculate((AssetPurchase("FROZEN_NATIVE_POOL", D("684631023"), D(100)),),
            tuple(DebtIssue(row[0], money(row[2]), D(str(row[11])) * 100) for row in liability),
            upfront_fees=D(0), cash_reserve=D(0), closing_cost_budget=budget)
        self.assertEqual(funding.arrangement_fee, D("5134732.67"))
        self.assertEqual(funding.other_upfront_costs, D("1250000"))
        self.assertEqual(funding.total_uses, money(by_number[11][1]))
        self.assertEqual(funding.debt_proceeds, money(by_number[12][6]))
        self.assertEqual(funding.equity_cash_funding, money(by_number[14][6]))
        self.assertEqual(funding.equity_cash_funding, D("109079386.12"))
        self.assertEqual(funding.total_sources, funding.total_uses)
        self.assertNotEqual(funding.equity_cash_funding, money(by_number[18][1]))

    def first_clo_projection(self, *, senior_pik_share=D(0)):
        """Isolate note coupon economics from imported pool/reinvestment behavior.

        This is a same-input first-period coupon comparison, not an end-to-end
        replay of the old aggregate default, haircut, fee or reinvestment rules.
        The supplemental PIK share is intentionally a new scenario; native
        baseline classes all have PIK disabled.
        """
        first = next(row["values"] for row in self.sheet("clo_model", "Payment Schedule") if row["row"] == 4)
        start, end = (date.fromisoformat(first[i][:10]) for i in (1, 2))
        final = date(2027, 9, 30)
        par = D("684631023")
        cash = money(first[10])
        receipts = (
            LoanCashflow("POOL", "EUR", 1, start, end, start, end, end, None, par, None, D(0), D(0),
                D(str(first[6])), cash, cash, D(0), par, cash),
            LoanCashflow("POOL", "EUR", 2, end, final, end, final, final, None, par, None, D(0), D(0),
                D(".25"), D(0), D(0), par, D(0), par),
        )
        notes = tuple(NoteTranche(row["values"][0], row["values"][8], money(row["values"][2]),
            CouponType.FLOATING, rate_index="EURIBOR_3M", spread_bps=D(str(row["values"][3])) * 10000,
            index_floor=D(0), pik_rate_fraction=senior_pik_share if row["row"] == 6 else D(0))
            for row in self.sheet("clo_model", "Liability") if 6 <= row["row"] <= 11)
        terms = CloTerms(start, final, business_day_convention=BusinessDayConvention.UNADJUSTED,
                         accrual_date_basis=AccrualDateBasis.UNADJUSTED, fixing_lag_business_days=0)
        projection = DeterministicCloEngine(FlatRateProvider({"EURIBOR_3M": D(str(first[7]))})).run(
            CloRunRequest(receipts, par, notes, terms))
        return projection, notes

    def test_all_six_native_first_period_note_coupons_match_cent_postings(self):
        projection, notes = self.first_clo_projection()
        reports = report_tranche_periods(projection)[:6]
        native = next(row["values"] for row in self.sheet("clo_model", "Waterfall") if row["row"] == 5)
        reference = D(str(native[3]))
        for report, note, column in zip(reports, notes, range(13, 19), strict=True):
            independent = note.opening_balance * (reference + note.spread_bps / 10000) * D(91) / D(360)
            self.assertEqual(report.current_coupon_due, money(independent))
            self.assertEqual(report.current_coupon_due, money(native[column]))
            self.assertEqual(report.current_coupon_due, report.total_coupon_paid)

    def test_class_pik_supplement_preserves_native_gross_coupon_and_face_cash_bridges(self):
        projection, notes = self.first_clo_projection(senior_pik_share=D(".5"))
        senior = report_tranche_periods(projection)[0]
        native = next(row["values"] for row in self.sheet("clo_model", "Waterfall") if row["row"] == 5)
        gross = money(native[13])
        self.assertEqual(senior.pik_interest_capitalized, money(gross / 2))
        self.assertEqual(senior.current_coupon_due + senior.pik_interest_capitalized, gross)
        self.assertEqual(senior.closing_balance, notes[0].opening_balance + senior.pik_interest_capitalized)
        self.assertEqual(senior.closing_coupon_arrears, D(0))
        self.assertTrue(all(period.cash_conservation_residual == 0 for period in projection.periods))


if __name__ == "__main__":
    unittest.main()
