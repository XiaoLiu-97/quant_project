"""Lifecycle applicability must never turn missing active-pool data into a pass."""

from dataclasses import replace
from decimal import Decimal
import unittest

from test_construction import fixture, FIRST, SECOND
from trident.analysis import LimitDirection, LimitSpec, LimitStatus, MetricStatus
from trident.application.clo_services import TridentModelService
from trident.application.construction import ClosingPoolRedesignService
from trident.application.portfolio_phases import ACTIVE_PORTFOLIO_PHASES, portfolio_phase

D = Decimal


class PortfolioPhaseTests(unittest.TestCase):
    def setUp(self):
        self.request = fixture()
        self.result = TridentModelService().run(self.request.baseline)

    def test_only_final_complete_snapshot_terminates(self):
        self.assertEqual(portfolio_phase(self.result.clo, FIRST, None), 'TERMINATED')
        self.assertEqual(portfolio_phase(self.result.clo, SECOND, None), 'POST_REINVESTMENT')
        self.assertEqual(self.result.portfolio_snapshots[-1].phase, 'TERMINATED')

    def test_each_outstanding_account_or_claim_blocks_terminal_exemption(self):
        for field in ('final_collateral_par', 'final_defaulted_par', 'final_debt_par',
                      'final_interest_cash', 'final_principal_cash', 'final_pending_interest_cash',
                      'final_pending_principal_cash', 'final_reserve', 'final_senior_claims',
                      'final_note_coupon_arrears', 'final_subordinated_fee_arrears',
                      'final_deferred_senior_expenses'):
            with self.subTest(field=field):
                projection = replace(self.result.clo, **{field: D('.01')})
                self.assertEqual(portfolio_phase(projection, FIRST, SECOND), 'REINVESTMENT')
        projection = replace(self.result.clo, terminal_value_available=False)
        self.assertEqual(portfolio_phase(projection, FIRST, None), 'POST_REINVESTMENT')

    def test_scoped_test_not_applicable_but_empty_metric_stays_unavailable(self):
        limit = LimitSpec('QUALITY', 'WAS_BPS', D(0), LimitDirection.MINIMUM, phases=ACTIVE_PORTFOLIO_PHASES)
        result = TridentModelService().run(replace(self.request.baseline, limits=(limit,)))
        self.assertIs(result.opening_portfolio.limits[0].status, LimitStatus.PASS)
        terminal = result.portfolio_snapshots[-1]
        self.assertIs(terminal.limits[0].status, LimitStatus.NOT_APPLICABLE)
        self.assertIs(terminal.metric('WAS_BPS').status, MetricStatus.UNAVAILABLE)

    def test_user_all_phase_limit_remains_strict_and_blocks_replay(self):
        limit = LimitSpec('USER_ALL_PHASE', 'WAS_BPS', D(0), LimitDirection.MINIMUM)
        baseline = replace(self.request.baseline, limits=(limit,))
        result = TridentModelService().run(baseline)
        self.assertIs(result.portfolio_snapshots[-1].limits[0].status, LimitStatus.UNAVAILABLE)
        self.assertFalse(ClosingPoolRedesignService().run(replace(self.request, baseline=baseline)).validated)

    def test_missing_opening_rating_does_not_become_available_after_termination(self):
        limit = LimitSpec('QUALITY', 'WARF', D(5000), LimitDirection.MAXIMUM, phases=ACTIVE_PORTFOLIO_PHASES)
        request = replace(self.request, baseline=replace(self.request.baseline, limits=(limit,)))
        result = ClosingPoolRedesignService().run(request)
        self.assertFalse(result.validated)
        self.assertIs(result.baseline_result.opening_portfolio.limits[0].status, LimitStatus.UNAVAILABLE)

    def test_phase_scoped_quality_allows_validated_full_clo_candidate_replay(self):
        limit = LimitSpec('QUALITY', 'WAS_BPS', D(0), LimitDirection.MINIMUM, phases=ACTIVE_PORTFOLIO_PHASES)
        request = replace(self.request, baseline=replace(self.request.baseline, limits=(limit,)))
        result = ClosingPoolRedesignService().run(request)
        self.assertTrue(result.validated, result.findings)
        self.assertIs(result.target_result.portfolio_snapshots[-1].limits[0].status, LimitStatus.NOT_APPLICABLE)
