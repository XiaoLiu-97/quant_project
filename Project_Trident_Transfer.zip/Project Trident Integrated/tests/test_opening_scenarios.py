"""Opening what-if known answers, immutable evidence and return-basis checks."""
from dataclasses import replace
from datetime import date
from decimal import Decimal
import unittest

from test_opening_clo_acceptance import operating_request, state, OPEN, NEXT, ORIGINAL, SOURCE
from trident.analysis import ReturnStatus
from trident.application.clo_services import TridentModelService
from trident.application.opening_scenarios import StaticOpeningScenarioService, apply_opening_scenario
from trident.application.scenarios import ScenarioDefinition, ScenarioEdit, ScenarioExecutionError, ScenarioRunner, ScenarioTarget
from trident.clo.models import DefaultedAssetOcTreatment
from trident.clo.proceeds import CouponProceedsAllocation, PrincipalAccruedBalance
from trident.credit import DefaultEvent, PrepaymentEvent, RecoveryEvent
from trident.credit.models import AssetCashSource
from trident.domain.models import AmortizationType, CouponType, InputValidationError, OpeningCouponEntitlement, OpeningFixing, PrincipalScheduleEntry, SeasonedLoanState

D = Decimal


def edit(target, field, value, identity=None):
    target = ScenarioTarget(target)
    return ScenarioEdit(target, identity or {ScenarioTarget.ASSET: "L", ScenarioTarget.NOTE: "A", ScenarioTarget.CONTROL: "DEAL"}[target], field, value)


def mark(amount):
    return (edit("CONTROL", "forward_equity_value", D(amount)),
            edit("CONTROL", "equity_value_source", "Independent counterfactual opening snapshot valuation"))


def metric(case, name):
    return next(row for row in case.comparisons if row.scope == "MODEL" and row.metric == name)


class CountingService(TridentModelService):
    def __init__(self):
        self.calls = []

    def run(self, request):
        self.calls.append(request)
        return super().run(request)


class OpeningScenarioTests(unittest.TestCase):
    def run_case(self, baseline, edits=(), name="CASE"):
        return StaticOpeningScenarioService().run(baseline, (ScenarioDefinition(name, edits),))

    def test_noop_preserves_original_grid_current_mark_and_known_cash(self):
        baseline, service = operating_request(), CountingService()
        batch = StaticOpeningScenarioService(service).run(baseline, (ScenarioDefinition("NOOP"),))
        case = batch.scenarios[0]
        self.assertEqual(len(service.calls), 2)
        self.assertIs(service.calls[0], baseline)
        self.assertIs(case.request.clo_opening_state, baseline.clo_opening_state)
        self.assertEqual(case.result.clo, batch.baseline.clo)
        self.assertIsNone(case.result.cashflows.funding)
        self.assertEqual(case.result.equity_cashflows[0].amount, D(-18))
        self.assertEqual(case.result.equity_cashflows[0].payment_date, OPEN)
        self.assertEqual(case.result.clo.periods[0].period_number, 2)
        self.assertEqual(case.result.clo.total_equity_distributions, D("21.82"))
        self.assertTrue(all(row.delta == 0 for row in case.comparisons if row.delta_status == "AVAILABLE"))

    def test_comparison_never_invents_opening_issuance_or_acquisition_cash(self):
        case = self.run_case(operating_request()).scenarios[0]
        for name in ("ASSET_CLEAN_COST", "DEBT_PROCEEDS", "EQUITY_CASH_FUNDING", "ACQUIRED_ACCRUED_INTEREST", "UPFRONT_FEES"):
            row = metric(case, name)
            self.assertEqual(row.baseline_status, "NOT_APPLICABLE")
            self.assertIsNone(row.baseline_value)
            self.assertIsNone(row.delta)
        self.assertEqual(metric(case, "COLLATERAL_PAR").baseline_value, D(100))
        self.assertEqual(metric(case, "DEBT_PAR").baseline_value, D(80))
        self.assertEqual(metric(case, "FORWARD_EQUITY_VALUE").baseline_value, D(18))
        self.assertIn("Independent equity opening market mark", metric(case, "FORWARD_EQUITY_VALUE").message)

    def test_asset_coupon_and_note_coupon_have_independent_hand_deltas(self):
        baseline = operating_request()
        cases = (ScenarioDefinition("ASSET", (edit("ASSET", "fixed_rate", D(".16")),)),
                 ScenarioDefinition("NOTE", (edit("NOTE", "fixed_rate", D(".08")),)))
        asset, note = StaticOpeningScenarioService().run(baseline, cases).scenarios
        # Apr1-Jul1 =91 days. Loan coupon rises3.03->4.04; note1.21->1.62.
        self.assertEqual(metric(asset, "TOTAL_EQUITY_DISTRIBUTIONS").delta, D("1.01"))
        self.assertEqual(metric(note, "TOTAL_EQUITY_DISTRIBUTIONS").delta, D("-.41"))
        self.assertEqual(asset.request.exposures[0].fixed_coupon_rate, D(".16"))
        self.assertEqual(baseline.cashflow_request.positions[0].terms.fixed_rate, D(".12"))
        self.assertEqual(note.request.forward_equity_value, D(18))

    def test_forward_management_fee_hand_amount_and_prior_claim_are_separate(self):
        opening = state(senior_management_fee_arrears=D(".40"))
        baseline = operating_request(opening=opening)
        case = self.run_case(baseline, (edit("CONTROL", "senior_management_fee_bps", D(360)),)).scenarios[0]
        # Existing.40 remains;100*360bps*91/360=.91 is new future fee.
        self.assertEqual(case.result.clo.periods[0].senior_management_fee_paid, D("1.31"))
        self.assertEqual(metric(case, "TOTAL_EQUITY_DISTRIBUTIONS").delta, D("-.91"))
        self.assertIs(case.request.clo_opening_state, opening)

    def test_opening_all_cash_accounts_claims_and_designations_remain_intact(self):
        opening = replace(state(claims=(("A", "1.20"),)), principal_cash=D(5), interest_cash=D(2), reserve=D(3),
            pending_interest_cash=D(".40"), pending_principal_cash=D(".60"), expense_arrears=D(".50"),
            senior_management_fee_arrears=D(".40"), subordinated_management_fee_arrears=D(".30"),
            deferred_senior_expense_arrears=D(".10"), original_principal_reinvestment_cash=D(3),
            pending_original_principal_reinvestment_cash=D(".20"), held_diversion_principal=D(1),
            initial_collateral_par=D(110))
        baseline = operating_request(opening=opening)
        baseline = replace(baseline, clo_terms=replace(baseline.clo_terms,
            interest_diversion_test_enabled=True, interest_diversion_test_class_id="A",
            interest_diversion_test_oc_minimum=D("1.06"), interest_diversion_test_end_date=NEXT))
        case = self.run_case(baseline, (edit("NOTE", "fixed_rate", D(".08")),)).scenarios[0]
        self.assertIs(case.request.clo_opening_state, opening)
        self.assertEqual(case.request.clo_opening_state.monetary_values(), opening.monetary_values())
        self.assertEqual(case.result.clo.tranche_periods[0].opening_coupon_arrears, D("1.20"))
        self.assertTrue(all(row.cash_conservation_residual == 0 for row in case.result.clo.periods))

    def test_floating_spread_edits_preserve_carried_fixing_and_bind_analytics(self):
        baseline = operating_request()
        position = baseline.cashflow_request.positions[0]
        terms = replace(position.terms, coupon_type=CouponType.FLOATING, fixed_rate=None,
            rate_index="EURIBOR_3M", spread_bps=D(950))
        carried = SeasonedLoanState(D(0), SOURCE, (OpeningFixing(OPEN, D(".025")),), OpeningCouponEntitlement.POST_ASOF_ONLY)
        position = replace(position, terms=terms, seasoned_state=carried)
        baseline = replace(baseline, cashflow_request=replace(baseline.cashflow_request, positions=(position,)),
            exposures=(replace(baseline.exposures[0], coupon_type=CouponType.FLOATING, fixed_coupon_rate=None, spread_bps=D(950)),),
            notes=(replace(baseline.notes[0], coupon_type=CouponType.FLOATING, fixed_rate=None,
                rate_index="EURIBOR_3M", spread_bps=D(350)),))
        cases = StaticOpeningScenarioService().run(baseline, (
            ScenarioDefinition("ASSET", (edit("ASSET", "spread_bps", D(1350)),)),
            ScenarioDefinition("NOTE", (edit("NOTE", "spread_bps", D(550)),)))).scenarios
        self.assertEqual(metric(cases[0], "TOTAL_EQUITY_DISTRIBUTIONS").delta, D("1.01"))
        self.assertEqual(metric(cases[1], "TOTAL_EQUITY_DISTRIBUTIONS").delta, D("-.41"))
        self.assertIs(cases[0].request.cashflow_request.positions[0].seasoned_state, carried)
        was = next(row for row in cases[0].comparisons if row.scope == "OPENING_METRIC" and row.metric == "WAS_BPS")
        self.assertEqual(was.delta, D(400))

    def test_sourced_principal_coupon_restoration_is_kept_and_resize_rejects_stale_instruction(self):
        baseline = operating_request()
        position = baseline.cashflow_request.positions[0]
        terms = replace(position.terms, start_date=date(2026, 2, 1), maturity_date=date(2026, 8, 1))
        position = replace(position, terms=terms, seasoned_state=SeasonedLoanState(D("1.97"), SOURCE))
        balances = (PrincipalAccruedBalance("L", OPEN, D(".50"), SOURCE, "Independent legal proceeds instruction"),)
        allocations = (CouponProceedsAllocation("RESTORE", "L", date(2026, 5, 1), AssetCashSource.SCHEDULED,
            D(".50"), True, SOURCE, "Independent legal proceeds instruction"),)
        baseline = replace(baseline, cashflow_request=replace(baseline.cashflow_request, positions=(position,)),
            exposures=(replace(baseline.exposures[0], maturity_date=terms.maturity_date),),
            clo_terms=replace(baseline.clo_terms, legal_final_date=date(2026, 10, 1)),
            principal_accrued_balances=balances, coupon_proceeds_allocations=allocations)
        case = self.run_case(baseline, (edit("CONTROL", "senior_management_fee_bps", D(360)),)).scenarios[0]
        self.assertIs(case.request.principal_accrued_balances, balances)
        self.assertIs(case.request.coupon_proceeds_allocations, allocations)
        self.assertTrue(all(row.cash_conservation_residual == 0 for row in case.result.clo.periods))
        with self.assertRaisesRegex(ScenarioExecutionError, "receipt-specific"):
            self.run_case(baseline, (edit("ASSET", "par", D(120)), *mark("40")))

    def test_coverage_status_and_dated_headroom_are_recomputed(self):
        batch = self.run_case(operating_request(), (edit("NOTE", "oc_minimum", D("1.3")),))
        case = batch.scenarios[0]
        self.assertEqual(metric(case, "OC_FAILED_GATE_COUNT").delta, 1)
        row = next(row for row in case.period_comparisons if row.metric == "OC_GATE_HEADROOM")
        self.assertEqual(row.scenario_value, D("-.05"))
        self.assertIsNone(row.delta)  # Baseline unconfigured threshold is not zero.
        self.assertEqual(case.request.clo_terms.closing_date, ORIGINAL)

    def test_asset_resize_requires_whole_equity_mark_and_uses_hand_return(self):
        case = self.run_case(operating_request(), (edit("ASSET", "par", D(120)), *mark("40"))).scenarios[0]
        #120*.12*91/360=3.64,80*.06*91/360=1.21;terminal120-80+3.64-1.21=42.43.
        self.assertEqual(case.result.clo.total_equity_distributions, D("42.43"))
        self.assertEqual(case.result.equity_cashflows[0].amount, D(-40))
        self.assertEqual(metric(case, "FORWARD_EQUITY_VALUE").delta, D(22))
        self.assertEqual(case.request.exposures[0].par, D(120))
        self.assertEqual(case.request.cashflow_request.purchases[0].par, D(120))
        self.assertEqual(case.request.cashflow_request.positions[0].terms.reference_principal, D(120))
        self.assertAlmostEqual(float(case.result.equity_irr.value), (42.43 / 40) ** (365 / 91) - 1, places=12)
        self.assertTrue(all(row.cash_conservation_residual == 0 for row in case.result.clo.periods))

    def test_note_resize_preserves_prior_coupon_claim_and_declared_equity_cost(self):
        opening = state(claims=(("A", "1.20"),))
        case = self.run_case(operating_request(opening=opening), (edit("NOTE", "par", D(90)), *mark("10"))).scenarios[0]
        self.assertEqual(case.request.notes[0].opening_balance, D(90))
        self.assertEqual(case.request.cashflow_request.issues[0].par, D(90))
        self.assertIs(case.request.clo_opening_state, opening)
        self.assertEqual(case.result.clo.tranche_periods[0].current_coupon_due, D("1.37"))
        self.assertEqual(case.result.clo.total_equity_distributions, D("10.46"))
        self.assertEqual(case.result.equity_cashflows[0].amount, D(-10))

    def test_resize_cases_do_not_inherit_another_case_or_change_baseline(self):
        baseline = operating_request()
        size, noop = StaticOpeningScenarioService().run(baseline, (
            ScenarioDefinition("SIZE", (edit("ASSET", "par", D(120)), *mark("40"))), ScenarioDefinition("NOOP"))).scenarios
        self.assertEqual(noop.request.cashflow_request.positions[0].opening_balance, D(100))
        self.assertEqual(noop.request.forward_equity_value, D(18))
        self.assertEqual(size.request.forward_equity_value, D(40))
        self.assertEqual(baseline.cashflow_request.positions[0].opening_balance, D(100))

    def test_resized_bespoke_schedule_conserves_cents_without_moving_dates(self):
        baseline = operating_request()
        position = baseline.cashflow_request.positions[0]
        dates = (date(2026, 7, 1), date(2026, 10, 1))
        terms = replace(position.terms, maturity_date=dates[-1], reference_principal=D("3.03"),
            amortization_type=AmortizationType.BESPOKE,
            principal_schedule=tuple(PrincipalScheduleEntry(day, amount) for day, amount in zip(dates, (D("1.01"), D("2.02")))))
        position = replace(position, terms=terms, opening_balance=D("3.03"))
        baseline = replace(baseline, cashflow_request=replace(baseline.cashflow_request, positions=(position,),
            purchases=(replace(baseline.cashflow_request.purchases[0], par=D("3.03")),),
            issues=(replace(baseline.cashflow_request.issues[0], par=D(2)),)),
            exposures=(replace(baseline.exposures[0], par=D("3.03"), maturity_date=dates[-1]),),
            notes=(replace(baseline.notes[0], opening_balance=D(2)),),
            clo_terms=replace(baseline.clo_terms, legal_final_date=dates[-1]), forward_equity_value=D("1.03"))
        case = self.run_case(baseline, (edit("ASSET", "par", D("3.04")), *mark("1.04"))).scenarios[0]
        rows = case.request.cashflow_request.positions[0].terms.principal_schedule
        self.assertEqual(tuple(row.payment_date for row in rows), dates)
        self.assertEqual(tuple(row.amount for row in rows), (D("1.01"), D("2.03")))
        self.assertEqual(case.result.cashflows.total_principal, D("3.04"))

    def test_midperiod_full_entitlement_repricing_rejects_but_resize_uses_exact_claim(self):
        baseline = operating_request()
        position = baseline.cashflow_request.positions[0]
        terms = replace(position.terms, start_date=date(2026, 2, 1), maturity_date=date(2026, 8, 1))
        position = replace(position, terms=terms, seasoned_state=SeasonedLoanState(D("1.97"), SOURCE))
        baseline = replace(baseline, cashflow_request=replace(baseline.cashflow_request, positions=(position,)),
            exposures=(replace(baseline.exposures[0], maturity_date=terms.maturity_date),))
        with self.assertRaisesRegex(ScenarioExecutionError, "historical coupon entitlement"):
            self.run_case(baseline, (edit("ASSET", "fixed_rate", D(".16")),))
        resized = apply_opening_scenario(baseline, ScenarioDefinition("SIZE", (edit("ASSET", "par", D("100.50")), *mark("18.50"))))
        self.assertEqual(resized.cashflow_request.positions[0].seasoned_state.opening_accrued_interest, D("1.98"))
        self.assertEqual(resized.cashflow_request.positions[0].seasoned_state.provenance, SOURCE)

    def test_prepaid_asset_resize_recomputes_actual_par_and_cash_instead_of_contract_totals(self):
        baseline = replace(operating_request(), credit_events=(PrepaymentEvent("L", date(2026, 6, 1)),))
        case = self.run_case(baseline, (edit("ASSET", "par", D(120)), *mark("40"))).scenarios[0]
        #61dayloan accrual=2.44; original91daynote1.21;120-80+2.44-1.21=41.23.
        self.assertEqual(case.result.clo.total_equity_distributions, D("41.23"))
        self.assertEqual(case.request.credit_events, baseline.credit_events)
        self.assertEqual(case.result.credit_projections[0].total_principal_collections, D(120))
        self.assertTrue(all(row.cash_conservation_residual == 0 for row in case.result.clo.periods))

    def test_explicit_default_resize_scales_actual_recoveries_and_loss_once(self):
        baseline = operating_request()
        baseline = replace(baseline, notes=(replace(baseline.notes[0], fixed_rate=D(0)),),
            clo_terms=replace(baseline.clo_terms, defaulted_asset_oc_treatment=DefaultedAssetOcTreatment.EXCLUDE),
            credit_events=(DefaultEvent("L", date(2026, 5, 1), (RecoveryEvent(date(2026, 6, 1), D(".8")),), date(2026, 6, 1)),))
        case = self.run_case(baseline, (edit("ASSET", "par", D(120)), *mark("30"))).scenarios[0]
        self.assertEqual(case.result.credit_projections[0].defaulted_exposure, D(120))
        self.assertEqual(case.result.clo.total_recovery_collections, D(96))
        self.assertEqual(case.result.clo.total_recognized_par_loss, D(24))
        self.assertEqual(case.result.clo.total_equity_distributions, D(16))
        self.assertEqual(case.result.clo.final_defaulted_par, 0)
        self.assertTrue(all(row.cash_conservation_residual == 0 for row in case.result.clo.periods))

    def test_unsupported_edits_and_missing_marks_abort_before_baseline_calculation(self):
        for changes in ((edit("ASSET", "par", D(120)),), (edit("NOTE", "par", D(90)),),
                        (edit("ASSET", "clean_price_pct", D(99)),), (edit("NOTE", "issue_price_pct", D(99)),),
                        (edit("CONTROL", "upfront_fees", D(1)),), (edit("CONTROL", "cash_reserve", D(1)),),
                        (edit("ASSET", "maturity_date", date(2027, 1, 1)),)):
            service = CountingService()
            with self.subTest(changes=changes), self.assertRaises(ScenarioExecutionError):
                StaticOpeningScenarioService(service).run(operating_request(), (ScenarioDefinition("BAD", changes),))
            self.assertEqual(service.calls, [])

    def test_missing_or_invalid_whole_equity_valuation_never_becomes_zero_cost(self):
        for changes in ((edit("CONTROL", "forward_equity_value", D(0)), edit("CONTROL", "equity_value_source", "SOURCE")),
                        (edit("CONTROL", "forward_equity_value", D(40)),),
                        (edit("CONTROL", "equity_value_source", "SOURCE"),)):
            with self.subTest(changes=changes), self.assertRaises(ScenarioExecutionError):
                self.run_case(operating_request(), changes)

    def test_bad_case_identity_duplicate_case_names_and_wrong_coupon_type_reject(self):
        for changes in ((edit("NOTE", "fixed_rate", D(".08"), "UNKNOWN"),),
                        (edit("ASSET", "spread_bps", D(500)),)):
            with self.subTest(changes=changes), self.assertRaises(ScenarioExecutionError):
                self.run_case(operating_request(), changes)
        with self.assertRaisesRegex(InputValidationError, "unique"):
            StaticOpeningScenarioService().run(operating_request(), (ScenarioDefinition("X"), ScenarioDefinition("x")))

    def test_closing_and_opening_scenario_boundaries_are_explicit(self):
        baseline = operating_request()
        with self.assertRaisesRegex(ScenarioExecutionError, "Closing scenario"):
            ScenarioRunner().run(baseline, (ScenarioDefinition("NOOP"),))
        with self.assertRaisesRegex(InputValidationError, "opening state"):
            StaticOpeningScenarioService().run(replace(baseline, clo_opening_state=None, forward_equity_value=None, equity_value_source=""), ())

    def test_batch_validates_all_cases_before_running_and_projection_failure_is_named(self):
        service = CountingService()
        with self.assertRaisesRegex(ScenarioExecutionError, "INVALID"):
            StaticOpeningScenarioService(service).run(operating_request(), (
                ScenarioDefinition("VALID", (edit("NOTE", "fixed_rate", D(".08")),)),
                ScenarioDefinition("INVALID", (edit("ASSET", "par", D(120)),))))
        self.assertEqual(service.calls, [])
        class FailingService(TridentModelService):
            def run(self, request):
                if request.notes[0].fixed_rate == D(".08"):
                    raise InputValidationError("independent failed projection")
                return super().run(request)
        with self.assertRaisesRegex(ScenarioExecutionError, "FAILED: independent"):
            StaticOpeningScenarioService(FailingService()).run(operating_request(), (
                ScenarioDefinition("FAILED", (edit("NOTE", "fixed_rate", D(".08")),)),))


if __name__ == "__main__":
    unittest.main()
