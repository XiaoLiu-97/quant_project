"""Frozen named-record boundary and independently checked complete search output."""

from copy import deepcopy
from dataclasses import replace
from datetime import datetime, timedelta, timezone
from decimal import Decimal, Inexact, localcontext
import unittest

from trident.adapters.candidate_records import candidate_result_record, candidate_search_from_records, timestamp_value
from trident.application.candidate_search import ClosingPoolSearchService
from trident.application.clo_services import TridentModelService
from trident.domain.models import InputValidationError
from trident.market import FlatRateProvider
from trident.optimization.universe import CandidateUniverseValidator, PriceSide, RatingLevel, RatingNature
from test_construction import fixture

D = Decimal


def asset_record(position, exposure):
    terms = position.terms
    return dict(loan_id=terms.loan_id, currency=terms.currency, initial_par=terms.reference_principal,
        current_par=position.opening_balance, par_as_of_date=position.par_as_of_date,
        cashflow_projection_start_date=terms.start_date, maturity_date_unadjusted=terms.maturity_date,
        coupon_type=terms.coupon_type.value, frequency_months=terms.frequency_months, spread_bps=terms.spread_bps,
        rate_index=terms.rate_index,
        reset_frequency_months=terms.reset_frequency_months,
        index_floor_bps=None if terms.index_floor is None else terms.index_floor * 10000,
        index_cap_bps=None if terms.index_cap is None else terms.index_cap * 10000,
        all_in_floor_bps=None if terms.all_in_floor is None else terms.all_in_floor * 10000,
        all_in_cap_bps=None if terms.all_in_cap is None else terms.all_in_cap * 10000,
        day_count=terms.day_count.value,
        schedule_anchor_day=terms.start_date.day, business_day_convention=terms.business_day_convention.value,
        holiday_calendar="TARGET", accrual_date_basis=terms.accrual_date_basis.value,
        fixing_lag_target_business_days=terms.fixing_lag_business_days, amortization_type=terms.amortization_type.value,
        amortization_fraction_initial_par_per_period=0, credit_status="PERFORMING", seniority="SENIOR",
        pik=False, revolver=False, construction_risk=False, secured=True,
        obligor_id=exposure.obligor, asset_class=exposure.asset_class, financing_type=exposure.financing_type,
        country_code=exposure.country, sector=exposure.sector, test_factor_bucket=exposure.test_factor_bucket,
        test_factor_system="TRIDENT_TEST_FACTOR", stub_convention=terms.stub_convention.value)


def records_fixture():
    single = fixture()
    result = TridentModelService().run(single.baseline)
    mandate = single.optimization_request
    controls = {"optimizer_settlement_date": mandate.settlement_date,
        "optimizer_target_par": mandate.limits.target_par, "optimizer_minimum_cash": mandate.limits.minimum_cash,
        "optimizer_starting_cash": mandate.starting_cash, "optimizer_objective": mandate.objective.value,
        "candidate_snapshot_id": single.candidate_snapshot.snapshot_id,
        "candidate_snapshot_captured_at": single.candidate_snapshot.captured_at.isoformat(),
        "candidate_snapshot_source": single.candidate_snapshot.source, "candidate_maximum_quote_age_hours": 0,
        "candidate_allowed_quote_qualities": "FIRM", "candidate_selection_policy": "MAX_EQUITY_IRR"}
    controls.update({"optimizer_" + name: getattr(mandate.limits, name) for name in (
        "maximum_obligor_share", "maximum_country_share", "maximum_sector_share", "maximum_bsl_share",
        "minimum_infra_share", "maximum_overall_factor", "maximum_bsl_factor", "minimum_spread_bps", "maximum_trade_par")})
    held = tuple(asset_record(position, exposure) for position, exposure in zip(
        single.baseline.cashflow_request.positions, single.baseline.exposures, strict=True))
    quote_rows = tuple(dict(asset_id=q.asset.asset_id, asset_class=q.asset.kind.value, side=q.side.value,
        obligor_id=q.asset.obligor, country_code=q.asset.country, sector=q.asset.sector,
        spread_bps=q.asset.spread_bps, factor_bucket="OLD_BUCKET" if q.asset.asset_id == "OLD" else "NEW_BUCKET",
        clean_price_pct=q.clean_price_pct, maximum_par=q.maximum_par, accrued_per_par=q.accrued_per_par,
        proportional_fee_per_par=q.proportional_fee_per_par, lot_size=q.lot_size,
        minimum_ticket=q.minimum_ticket, fixed_fee=q.fixed_fee, currency="EUR") for q in mandate.quotes)
    candidates = single.candidate_snapshot.candidates
    metadata = tuple(dict(loan_id=c.asset_id, facility_id=c.facility_id, bloomberg_security=c.bloomberg_security,
        contract_provenance=c.contract_provenance, classification_provenance=c.classification_provenance,
        credit_status=c.credit_status.value) for c in candidates)
    ratings = tuple(dict(loan_id=c.asset_id, agency=r.agency, rating=r.rating, level=r.level.value,
        nature=r.nature.value, subject_id=r.subject_id, as_of_date=r.as_of_date, source=r.source)
        for c in candidates for r in c.ratings)
    observations = tuple(dict(asset_id=c.asset_id, side=p.quote.side.value, price_side=p.price_side.value,
        quality=p.quality.value, observed_at=p.observed_at.isoformat(), settlement_date=p.settlement_date, source=p.source)
        for c in candidates for p in c.prices)
    new = next(c for c in candidates if c.asset_id == "NEW")
    args = dict(candidate_assets=(asset_record(new.position, new.exposure),), candidate_metadata=metadata,
        candidate_ratings=ratings, quote_observations=observations, candidate_variants=(
            dict(candidate_id="FULL_SWAP", objective="MIN_FACTOR", enabled=True),
            dict(candidate_id="HALF_SWAP", objective="MIN_FACTOR", maximum_trade_par=10000, enabled="true"),
        ))
    return single.baseline, result, held, quote_rows, controls, args


def parse_fixture(data):
    baseline, result, held, quotes, controls, args = data
    return candidate_search_from_records(baseline, result, held, quotes, controls, **args)


class CandidateRecordsReviewTests(unittest.TestCase):
    def test_candidate_independent_reset_survives_named_parse_and_full_search(self):
        data = list(records_fixture())
        baseline = data[0]
        cash = replace(baseline.cashflow_request, rate_provider=FlatRateProvider(
            {'EURIBOR_1M': D(0), 'EURIBOR_3M': D(0)}))
        data[0] = replace(baseline, cashflow_request=cash)
        data[1] = TridentModelService().run(data[0])
        data[-1]['candidate_assets'][0].update(reset_frequency_months=1, rate_index='EURIBOR_1M')
        request = parse_fixture(data)
        result = ClosingPoolSearchService().run(request)
        self.assertEqual(result.evaluation('FULL_SWAP').equity_distributions, D(2160))
        candidate = next(c for c in request.candidate_snapshot.candidates if c.asset_id == 'NEW')
        self.assertEqual(candidate.position.terms.reset_frequency_months, 1)

    def test_candidate_coupon_cap_changes_full_replay_not_raw_spread(self):
        data = records_fixture()
        data[-1]['candidate_assets'][0].update(index_cap_bps=0, all_in_cap_bps=100)
        request = parse_fixture(data)
        result = ClosingPoolSearchService().run(request)
        full = result.evaluation('FULL_SWAP')
        # 10000 * 1% * 90/360 = 25; debt coupon 40, principal equity
        # 2000. Distribution is 1985, not the unbounded 2160.
        self.assertEqual(full.equity_distributions, D(1985))
        self.assertEqual(full.equity_cash_funding, D(2107))
        candidate = next(c for c in request.candidate_snapshot.candidates if c.asset_id == 'NEW')
        self.assertEqual(candidate.exposure.spread_bps, D(800))
        self.assertEqual(candidate.position.terms.all_in_cap, D('.01'))

    def test_named_records_full_replay_uses_true_returns_and_no_trade_comparator(self):
        data = records_fixture()
        request = parse_fixture(data)
        self.assertEqual(request.admission_policy.maximum_quote_age, timedelta(0))
        self.assertEqual(request.candidate_snapshot.candidates[1].ratings[0].level, RatingLevel.FACILITY)
        self.assertEqual(request.candidate_snapshot.candidates[1].ratings[0].nature, RatingNature.INTERNAL)
        result = ClosingPoolSearchService().run(request)
        self.assertEqual(result.selected_candidate_id, "NO_TRADES")
        full = result.evaluation("FULL_SWAP")
        # Own cash oracle: ask10110k +7 -8kdebt =2107;90-day asset200,
        # note40 andprincipal equity2000 =>2160 distribution.
        self.assertEqual(full.equity_cash_funding, D(2107))
        self.assertEqual(full.equity_distributions, D(2160))
        self.assertLess(abs(float(full.equity_irr.value) - ((2160 / 2107) ** (365 / 90) - 1)), 1e-12)
        row = candidate_result_record(full, result.selected_candidate_id)
        self.assertEqual(row["equity_irr_status"], "AVAILABLE")
        self.assertEqual(row["factor_metric"], "TEST_FACTOR_AVERAGE")
        self.assertEqual(row["factor"], D(2000))
        self.assertFalse(row["selected"])
        self.assertTrue(candidate_result_record(result.evaluation("NO_TRADES"), result.selected_candidate_id)["selected"])
        self.assertFalse(any(isinstance(value, (tuple, dict)) for value in row.values()))

    def test_contract_only_candidate_columns_need_no_acquisition_price_or_accrued(self):
        data = records_fixture()
        record = data[-1]["candidate_assets"][0]
        self.assertNotIn("purchase_price_pct", record)
        self.assertNotIn("acquired_accrued_interest", record)
        request = parse_fixture(data)
        candidate = next(row for row in request.candidate_snapshot.candidates if row.asset_id == "NEW")
        self.assertEqual(candidate.position.opening_balance, D(10000))
        self.assertEqual(candidate.prices[0].quote.accrued_per_par, D(0))
        search = ClosingPoolSearchService().run(request)
        self.assertEqual(search.evaluation("FULL_SWAP").equity_cash_funding, D(2107))
        self.assertEqual(search.evaluation("FULL_SWAP").equity_distributions, D(2160))

    def test_future_market_snapshot_is_a_common_search_error(self):
        request = parse_fixture(records_fixture())
        future = replace(request.candidate_snapshot, captured_at=datetime(2026, 10, 5, 16, tzinfo=timezone.utc))
        with self.assertRaisesRegex(InputValidationError, "after settlement"):
            CandidateUniverseValidator().validate(future, request.admission_policy)
        with self.assertRaisesRegex(InputValidationError, "future market"):
            ClosingPoolSearchService().run(replace(request, candidate_snapshot=future))

    def test_chronology_uses_explicit_offset_calendar_date_at_day_granularity(self):
        request = parse_fixture(records_fixture())
        policy = replace(request.admission_policy, maximum_quote_age=timedelta(days=2))
        # No unprovided intraday closing time is inferred. These instants are
        # equal, but the declared source calendar days differ at the boundary.
        same_day = timestamp_value("2026-01-20T23:30:00Z", "capture")
        next_day_offset = timestamp_value("2026-01-21T00:30:00+01:00", "capture")
        self.assertEqual(same_day, next_day_offset)
        snapshot = replace(request.candidate_snapshot, captured_at=same_day)
        result = CandidateUniverseValidator().validate(snapshot, policy)
        self.assertEqual(len(result.admitted), 2)
        with self.assertRaisesRegex(InputValidationError, "calendar date"):
            CandidateUniverseValidator().validate(replace(snapshot, captured_at=next_day_offset), policy)

    def test_timestamps_require_real_offsets_and_preserve_instant(self):
        expected = datetime(2026, 1, 19, 16, tzinfo=timezone.utc)
        self.assertEqual(timestamp_value("2026-01-19T17:00:00+01:00", "capture"), expected)
        self.assertEqual(timestamp_value("2026-01-19T16:00:00Z", "capture"), expected)
        self.assertIs(timestamp_value(expected, "capture"), expected)
        for raw in (datetime(2026, 1, 19), "2026-01-19", "2026-01-19T16:00:00", None, True, 46041, "bad"):
            with self.subTest(raw=raw), self.assertRaisesRegex(InputValidationError, "capture"):
                timestamp_value(raw, "capture")

    def test_frozen_snapshot_does_not_change_when_transport_rows_change(self):
        data = records_fixture()
        request = parse_fixture(data)
        _, _, _, quotes, controls, args = data
        controls["candidate_snapshot_id"] = "MODIFIED"
        args["candidate_metadata"][1]["facility_id"] = "MODIFIED"
        args["candidate_ratings"][1]["rating"] = "MODIFIED"
        quotes[1]["clean_price_pct"] = D(1)
        args["candidate_assets"][0]["spread_bps"] = D(1)
        self.assertEqual(request.candidate_snapshot.snapshot_id, "SNAPSHOT")
        self.assertEqual(request.candidate_snapshot.candidates[1].facility_id, "FACILITY_OLD")
        self.assertNotEqual(request.candidate_snapshot.candidates[1].ratings[0].rating, "MODIFIED")
        self.assertEqual(request.base_mandate.quotes[1].clean_price_pct, D(101))
        self.assertEqual(request.candidate_snapshot.candidates[0].position.terms.spread_bps, D(800))

    def test_missing_contract_rating_status_or_stale_quote_is_quarantined_then_excluded(self):
        for target, field, value, message in (
            ("candidate_metadata", "contract_provenance", None, "provenance"),
            ("candidate_metadata", "credit_status", "UNKNOWN", "PERFORMING"),
            ("quote_observations", "observed_at", "2026-01-18T16:00:00+00:00", "age"),
            ("quote_observations", "price_side", "MID", "ASK"),
            ("candidate_ratings", "subject_id", "OTHER_FACILITY", "subject"),
        ):
            with self.subTest(field=field):
                data = records_fixture()
                args = data[-1]
                args[target] = tuple(dict(row, **{field: value}) if row.get("loan_id", row.get("asset_id")) == "NEW" else row
                                     for row in args[target])
                request = parse_fixture(data)
                admission = CandidateUniverseValidator().validate(request.candidate_snapshot, request.admission_policy)
                quarantine = next(row for row in admission.quarantined if row.asset_id == "NEW")
                self.assertIn(message.lower(), "; ".join(quarantine.reasons).lower())
                search = ClosingPoolSearchService().run(request)
                self.assertEqual(search.selected_candidate_id, "NO_TRADES")
                self.assertEqual(search.evaluation("FULL_SWAP").status, "INPUT_REJECTED")
                self.assertFalse(search.evaluation("FULL_SWAP").eligible)
        data = records_fixture()
        data[-1]["candidate_assets"] = ()
        data[-1]["candidate_ratings"] = tuple(row for row in data[-1]["candidate_ratings"] if row["loan_id"] != "NEW")
        request = parse_fixture(data)
        quarantine = CandidateUniverseValidator().validate(request.candidate_snapshot, request.admission_policy).quarantined[0]
        self.assertIn("contract", "; ".join(quarantine.reasons).lower())
        self.assertIn("rating", "; ".join(quarantine.reasons).lower())

    def test_unknown_or_missing_metadata_observation_and_rating_id_fail_clearly(self):
        for table, field in (("candidate_metadata", "loan_id"), ("candidate_ratings", "loan_id"),
                             ("quote_observations", "asset_id"), ("candidate_assets", "loan_id")):
            with self.subTest(table=table):
                data = records_fixture()
                data[-1][table] = (*data[-1][table], dict(data[-1][table][0], **{field: "UNKNOWN"}))
                with self.assertRaises(InputValidationError):
                    parse_fixture(data)
        data = records_fixture()
        data[-1]["candidate_metadata"] = data[-1]["candidate_metadata"][:1]
        with self.assertRaisesRegex(InputValidationError, "Missing facility identity"):
            parse_fixture(data)
        data = records_fixture()
        data[-1]["quote_observations"] = data[-1]["quote_observations"][:1]
        with self.assertRaisesRegex(InputValidationError, "match all"):
            parse_fixture(data)

    def test_duplicate_metadata_quote_rating_facility_or_variant_identity_is_rejected(self):
        for table in ("candidate_metadata", "candidate_ratings", "quote_observations", "candidate_assets", "candidate_variants"):
            with self.subTest(table=table):
                data = records_fixture()
                data[-1][table] = (*data[-1][table], deepcopy(data[-1][table][0]))
                with self.assertRaisesRegex(InputValidationError, "[Dd]uplicate|unique"):
                    parse_fixture(data)
        data = records_fixture()
        data[-1]["candidate_metadata"][1]["facility_id"] = data[-1]["candidate_metadata"][0]["facility_id"]
        with self.assertRaisesRegex(InputValidationError, "Duplicate candidate facility"):
            parse_fixture(data)

    def test_bad_enum_boolean_and_extra_fields_are_semantic_errors(self):
        for table, field, value in (("candidate_ratings", "level", "NOT_A_LEVEL"),
                ("candidate_ratings", "nature", True), ("quote_observations", "price_side", []),
                ("quote_observations", "quality", "UNKNOWN"), ("candidate_metadata", "credit_status", "INVALID"),
                ("candidate_variants", "objective", "IRR"), ("candidate_variants", "enabled", 1)):
            with self.subTest(table=table, field=field):
                data = records_fixture()
                data[-1][table][0][field] = value
                with self.assertRaises(InputValidationError):
                    parse_fixture(data)
        for table in ("candidate_metadata", "candidate_ratings", "quote_observations", "candidate_variants"):
            with self.subTest(extra_table=table):
                data = records_fixture()
                data[-1][table][0]["typo_future_term"] = "MUST_NOT_IGNORE"
                with self.assertRaisesRegex(InputValidationError, "unregistered"):
                    parse_fixture(data)

    def test_quote_policy_age_and_whitelist_corner_cases_fail(self):
        for control, value in (("candidate_maximum_quote_age_hours", -1),
                ("candidate_maximum_quote_age_hours", D("0.0000000000000001")),
                ("candidate_maximum_quote_age_hours", D("1e50")),
                ("candidate_allowed_quote_qualities", "FIRM,FIRM"),
                ("candidate_allowed_quote_qualities", "FIRM,"),
                ("candidate_selection_policy", "UNKNOWN")):
            with self.subTest(control=control, value=value):
                data = records_fixture()
                data[-2][control] = value
                with self.assertRaises(InputValidationError):
                    parse_fixture(data)

    def test_nonzero_accrued_is_never_dropped_and_quote_is_pricing_authority(self):
        data = records_fixture()
        data[-1]["candidate_assets"][0]["acquired_accrued_interest"] = D(1)
        with self.assertRaisesRegex(InputValidationError, "acquired accrued"):
            parse_fixture(data)
        data = records_fixture()
        data[3][1]["accrued_per_par"] = D(".001")
        with self.assertRaisesRegex(InputValidationError, "zero accrued"):
            parse_fixture(data)
        data = records_fixture()
        data[-1]["candidate_assets"][0]["purchase_price_pct"] = D(50)  # Legacy reference, not acquisition quote.
        search = ClosingPoolSearchService().run(parse_fixture(data))
        self.assertEqual(search.evaluation("FULL_SWAP").equity_cash_funding, D(2107))

    def test_disabled_variants_and_low_context_have_explicit_behavior(self):
        data = records_fixture()
        data[-1]["candidate_variants"] = (*data[-1]["candidate_variants"], dict(candidate_id="DISABLED", objective=None, enabled=False))
        with localcontext() as context:
            context.prec = 2
            context.traps[Inexact] = True
            request = parse_fixture(data)
        self.assertEqual([row.candidate_id for row in request.variants], ["FULL_SWAP", "HALF_SWAP"])
        data[-1]["candidate_variants"] = (dict(candidate_id="DISABLED", objective=None, enabled=False),)
        with self.assertRaisesRegex(InputValidationError, "nonempty"):
            parse_fixture(data)


if __name__ == "__main__":
    unittest.main()
