"""One orchestration path shared by CSV examples and the Excel interface."""

from dataclasses import dataclass
from datetime import date
from decimal import Decimal
from fractions import Fraction
from uuid import uuid4

from trident.cashflows.engine import ContractualCashflowEngine
from trident.domain.models import InputValidationError, LoanCashflow, LoanPosition, require_money
from trident.domain.numeric import post_currency
from trident.funding.engine import AssetPurchase, ClosingCostBudget, ClosingSourceType, DebtIssue, FundingEngine, SourcesUses
from trident.market.rates import CurveRateProvider, FlatRateProvider, RateProvider


@dataclass(frozen=True)
class CashflowRunRequest:
    """Typed application input; no worksheet, CSV header or cell dependencies."""

    positions: tuple[LoanPosition, ...]
    purchases: tuple[AssetPurchase, ...]
    issues: tuple[DebtIssue, ...]
    rate_provider: RateProvider
    upfront_fees: Decimal
    cash_reserve: Decimal
    rate_provenance: str
    other_initial_uses: Decimal = Decimal(0)
    other_initial_sources: Decimal = Decimal(0)
    other_initial_source_type: ClosingSourceType | None = None
    closing_cost_budget: ClosingCostBudget | None = None

    def __post_init__(self) -> None:
        for name, item_type in (("positions", LoanPosition), ("purchases", AssetPurchase), ("issues", DebtIssue)):
            collection = getattr(self, name)
            if not isinstance(collection, tuple) or any(not isinstance(item, item_type) for item in collection):
                raise InputValidationError(f"{name} must be an immutable tuple of {item_type.__name__}")
        if not callable(getattr(self.rate_provider, "rate", None)):
            raise InputValidationError("rate_provider must implement rate")
        if not isinstance(self.rate_provenance, str) or not self.rate_provenance.strip():
            raise InputValidationError("rate_provenance is required")
        for name in ("upfront_fees", "cash_reserve", "other_initial_uses", "other_initial_sources"):
            require_money(getattr(self, name), name)
        if self.other_initial_source_type is not None and not isinstance(self.other_initial_source_type, ClosingSourceType):
            raise InputValidationError("other_initial_source_type must be an explicit ClosingSourceType")
        if self.other_initial_sources != 0 and self.other_initial_source_type is None:
            raise InputValidationError("Nonzero other_initial_sources require explicit EXTERNAL_CONTRIBUTION classification")
        if self.closing_cost_budget is not None:
            if not isinstance(self.closing_cost_budget, ClosingCostBudget):
                raise InputValidationError("closing_cost_budget must be ClosingCostBudget")
            if self.upfront_fees != 0:
                raise InputValidationError("Use an itemized closing_cost_budget or aggregate upfront_fees; both would double count costs")


@dataclass(frozen=True)
class ProjectionResult:
    """Contractual asset schedule and closing funding, without CLO projections."""

    run_id: str
    cashflows: tuple[LoanCashflow, ...]
    funding: SourcesUses | None
    asset_count: int
    total_principal: Decimal
    total_interest: Decimal
    first_payment_date: date
    first_payment_interest: Decimal
    rate_provenance: str
    projection_start_date: date
    rate_provider_kind: str
    market_data_as_of: date | None
    opening_collateral_par: Decimal | None = None
    total_pik_interest: Decimal = Decimal(0)
    currency: str = "EUR"


class CashflowRunService:
    """Validate all inputs before producing any workbook changes."""

    def run(self, request: CashflowRunRequest, *, existing_clo: bool = False) -> ProjectionResult:
        """Validate one single-currency opening snapshot and project each loan.

        Funding is separate from contractual receipts: purchase price/accrued
        affect initial cash uses, not the loan's principal schedule. All totals
        sum exact posted rows; conservation is checked before returning output.
        Default and CLO distributions belong to higher application services.
        """
        if not isinstance(request, CashflowRunRequest):
            raise TypeError("request must be CashflowRunRequest")
        if type(existing_clo) is not bool:
            raise InputValidationError("existing_clo must be boolean")
        positions = request.positions
        if not positions:
            raise InputValidationError("Assets table is empty")
        if any(not isinstance(position, LoanPosition) for position in positions):
            raise InputValidationError("positions must contain LoanPosition")
        if len({position.terms.loan_id for position in positions}) != len(positions):
            raise InputValidationError("Duplicate loan_id in Assets")
        currencies = {position.terms.currency for position in positions}
        if len(currencies) != 1:
            raise InputValidationError("Cashflow portfolio must share one currency; no implicit FX conversion")
        currency = next(iter(currencies))
        snapshot_dates = {position.par_as_of_date for position in positions}
        if len(snapshot_dates) != 1:
            raise InputValidationError("All opening positions must share one projection/closing as-of date; ramp and future settlement are not implemented")
        projection_start = next(iter(snapshot_dates))
        balances = {position.terms.loan_id: position.opening_balance for position in positions}
        purchase_balances = {purchase.loan_id: purchase.par for purchase in request.purchases}
        if balances != purchase_balances or len(request.purchases) != len(positions):
            raise InputValidationError("Purchase par/identities must match the held positions")
        # Establish sources/uses first so a bad closing budget cannot produce
        # an apparently usable projection with the wrong equity investment.
        # A post-distribution holding snapshot does not issue debt or purchase
        # the pool again. Never construct fictitious closing sources/uses or
        # recharge historic fees when calculating its forward distributions.
        if existing_clo and (request.upfront_fees or request.other_initial_uses
                or request.other_initial_sources
                or (request.closing_cost_budget is not None and request.closing_cost_budget.total)
                or any(row.accrued_interest for row in request.purchases)):
            raise InputValidationError("Existing CLO opening requires inactive closing costs, sources and purchased accrued costs")
        funding = None if existing_clo else FundingEngine().calculate(
            request.purchases, request.issues,
            upfront_fees=request.upfront_fees, cash_reserve=request.cash_reserve,
            other_initial_uses=request.other_initial_uses,
            other_initial_sources=request.other_initial_sources,
            other_initial_source_type=request.other_initial_source_type,
            closing_cost_budget=request.closing_cost_budget,
        )
        # One stateless engine shares the frozen rate provider; each position
        # still owns its schedule, day count, balance and cent posting.
        engine = ContractualCashflowEngine(request.rate_provider)
        cashflows = tuple(row for position in positions for row in engine.generate(position))
        first_date = min(row.payment_date for row in cashflows)
        principal = post_currency(sum((Fraction(row.principal_repayment) for row in cashflows), Fraction()))
        interest = post_currency(sum((Fraction(row.cash_interest) for row in cashflows), Fraction()))
        first_interest = post_currency(sum((Fraction(row.cash_interest) for row in cashflows
                                            if row.payment_date == first_date), Fraction()))
        held_par = post_currency(sum((Fraction(row.opening_balance) for row in positions), Fraction()))
        # Capitalized borrower coupon becomes face, not collection-account
        # interest. Its eventual redemption is therefore additional principal.
        pik = post_currency(sum((Fraction(row.pik_interest) for row in cashflows), Fraction()))
        if Fraction(principal) != Fraction(held_par) + Fraction(pik):
            raise ArithmeticError("Portfolio principal conservation failed")
        if any(Fraction(row.total_cash) != Fraction(row.cash_interest) + Fraction(row.principal_repayment) for row in cashflows):
            raise ArithmeticError("Cashflow posting invariant failed")
        from trident.market.cash_accounts import CashCurveRateProvider
        provider = request.rate_provider
        cash_curves = provider.cash_curves if isinstance(provider, CashCurveRateProvider) else {}
        term_provider = provider.term_provider if isinstance(provider, CashCurveRateProvider) else provider
        kind = ("SYNTHETIC_FLAT" if isinstance(term_provider, FlatRateProvider)
                else "PROJECTED_WITH_EXACT_HISTORY" if isinstance(term_provider, CurveRateProvider)
                else f"CUSTOM:{type(term_provider).__name__}")
        market_asof = term_provider.valuation_date if isinstance(term_provider, CurveRateProvider) else None
        provenance = request.rate_provenance
        if cash_curves:
            kind += "+OIS_CASH_FORWARD"
            market_asof = next(iter(cash_curves.values())).valuation_date
            provenance += "; collection cash=DF_FORWARD; " + "; ".join(
                f"{curve.index} as_of={curve.valuation_date} zero_compounding={curve.compounding.value} zero_basis={curve.day_count.value}"
                for curve in cash_curves.values())
        return ProjectionResult(
            uuid4().hex, cashflows, funding, len(positions), principal, interest,
            first_date, first_interest, provenance, projection_start, kind, market_asof,
            held_par, pik, currency,
        )
