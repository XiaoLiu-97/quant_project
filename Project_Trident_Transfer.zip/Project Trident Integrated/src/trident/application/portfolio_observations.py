"""Independent event-date portfolio-quality observation and holdings replay.

Quality observations do not create waterfall periods. The calendar combines
known changes in actual performing holdings, effective native coupon levels,
phase boundaries and explicit caller dates. Reports use post-event held par;
the separate opening report retains the funding-date, pre-event population.
This improves modeled-date coverage without asserting continuous compliance or
inventing the legal determination calendar of an unidentified transaction.
"""

from dataclasses import dataclass
from datetime import date

from trident.analysis import AssetExposure, FactorMapping, LimitSpec, PortfolioReport
from trident.clo.models import CloProjection
from trident.clo.reinvestment import SyntheticReinvestmentPolicy
from trident.credit.models import AssetCreditProjection
from trident.credit.overlay import PoolOverlayProjection
from trident.domain.models import InputValidationError, LoanCashflow, require_date

from .coupon_timeline import CouponTimeline
from .imported_cashflows import ImportedCollateralProjection
from .portfolio_snapshots import PortfolioStateScanner


@dataclass(frozen=True)
class PortfolioObservationCalendar:
    """A bounded observation calendar independent of the CLO payment schedule.

    Automatic events outside the actual projected lifecycle are ignored. An
    explicit requested date outside it is rejected: returning a stale holding
    after an unresolved horizon would manufacture an observation. Date unions
    and one ordered ledger sweep replace a daily brute-force timeline.
    """

    closing_date: date
    horizon_date: date

    def __post_init__(self) -> None:
        require_date(self.closing_date, "portfolio closing date")
        require_date(self.horizon_date, "portfolio observation horizon")
        if self.horizon_date < self.closing_date:
            raise InputValidationError("Portfolio observation horizon cannot precede closing")

    def collect(
        self, *, payment_dates: tuple[date, ...] = (),
        holding_event_dates: tuple[date, ...] = (),
        coupon_change_dates: tuple[date, ...] = (),
        reinvestment_end_date: date | None = None,
        additional_dates: tuple[date, ...] = (),
    ) -> tuple[date, ...]:
        """Return a deterministic sorted union of modeled and caller dates.

        Requested dates may be unsorted or repeated; the semantic date union
        removes repetitions. Every entry must be an exact date, never datetime,
        text or a mutable list. A phase boundary is included at equality even
        though purchase permission can independently remain inclusive that day.
        """
        dates = {self.closing_date, self.horizon_date}
        for label, source in (("payment_dates", payment_dates),
                              ("holding_event_dates", holding_event_dates),
                              ("coupon_change_dates", coupon_change_dates),
                              ("additional_dates", additional_dates)):
            if type(source) is not tuple:
                raise InputValidationError(f"{label} must be an immutable tuple of dates")
            for day in source:
                require_date(day, label)
                if self.closing_date <= day <= self.horizon_date:
                    dates.add(day)
                elif label == "additional_dates":
                    raise InputValidationError("Additional portfolio observation date is outside the actual projection horizon")
        if reinvestment_end_date is not None:
            require_date(reinvestment_end_date, "reinvestment_end_date")
            if self.closing_date <= reinvestment_end_date <= self.horizon_date:
                dates.add(reinvestment_end_date)
        return tuple(sorted(dates))


def build_portfolio_observations(
    exposures: tuple[AssetExposure, ...], contractual_cashflows: tuple[LoanCashflow, ...],
    clo_projection: CloProjection, *, closing_date: date,
    additional_dates: tuple[date, ...] = (),
    factor_mapping: FactorMapping | None = None, limits: tuple[LimitSpec, ...] = (),
    reinvestment_end_date: date | None = None,
    credit_projections: tuple[AssetCreditProjection, ...] = (),
    original_overlay_projection: PoolOverlayProjection | None = None,
    reinvestment_policy: SyntheticReinvestmentPolicy | None = None,
    legal_final_date: date | None = None,
    imported_collateral: ImportedCollateralProjection | None = None,
    coupon_timeline: CouponTimeline | None = None,
) -> tuple[PortfolioReport, ...]:
    """Observe dated quality using the actual identified holdings subledger.

    Every included CLO payment report must still reconcile its performing face
    to the waterfall audit. Other dates replay the same asset par movements,
    credit exits, imported bridges, synthetic purchases and terminal disposals.
    Native steps use their shared schedule-aware effective dates; inactive
    native contracts never establish coupon evidence for an imported source.
    """
    require_date(closing_date, "portfolio closing date")
    if not isinstance(clo_projection, CloProjection):
        raise InputValidationError("Portfolio observations require a CloProjection")
    horizon = max((period.payment_date for period in clo_projection.periods), default=closing_date)
    calendar = PortfolioObservationCalendar(closing_date, horizon)
    scanner = PortfolioStateScanner(exposures, contractual_cashflows, clo_projection,
        factor_mapping=factor_mapping, limits=limits, reinvestment_end_date=reinvestment_end_date,
        credit_projections=credit_projections, original_overlay_projection=original_overlay_projection,
        reinvestment_policy=reinvestment_policy, legal_final_date=legal_final_date,
        imported_collateral=imported_collateral, coupon_timeline=coupon_timeline)
    coupon_dates = (coupon_timeline.effective_change_dates
                    if coupon_timeline is not None and imported_collateral is None else ())
    dates = calendar.collect(payment_dates=tuple(period.payment_date for period in clo_projection.periods),
        holding_event_dates=scanner.event_dates, coupon_change_dates=coupon_dates,
        reinvestment_end_date=reinvestment_end_date, additional_dates=additional_dates)
    return scanner.scan(dates, closing_date=closing_date)
