"""Immutable inputs and evidence for single-settlement BSL trade proposals.

Factor is a versioned input metric, not an inferred agency rating. This static
optimizer does not claim equity-IRR optimality or future CLO compliance.
"""

from dataclasses import dataclass
from datetime import date
from decimal import Decimal
from enum import Enum
from math import isfinite

from trident.domain.models import InputValidationError, require_date, require_decimal, require_money


class AssetKind(str, Enum):
    BSL = "BSL"
    INFRA = "INFRA"


class TradeSide(str, Enum):
    BUY = "BUY"
    SELL = "SELL"


class OptimizationObjective(str, Enum):
    MIN_FACTOR = "MIN_FACTOR"
    MAX_SPREAD = "MAX_SPREAD"


class OptimizationStatus(str, Enum):
    OPTIMAL = "OPTIMAL"
    FEASIBLE_TIME_LIMIT = "FEASIBLE_TIME_LIMIT"
    NO_INCUMBENT = "NO_INCUMBENT"
    INFEASIBLE = "INFEASIBLE"
    UNBOUNDED = "UNBOUNDED"
    NUMERICAL_ERROR = "NUMERICAL_ERROR"
    REJECTED_POST_VALIDATION = "REJECTED_POST_VALIDATION"


def _text(value: object, label: str) -> None:
    if not isinstance(value, str) or not value or value != value.strip():
        raise InputValidationError(f"{label} must be non-empty, unpadded text")


@dataclass(frozen=True)
class AssetDescriptor:
    """Static EUR metadata; factor and quoted-spread proxy weight by full par.

    This descriptor does not establish coupon type. Its spread proxy is not a
    contractual floating-only WAS when the input set includes fixed-rate assets.
    Closing replay separately requires verified floating collateral contracts.
    """

    asset_id: str
    kind: AssetKind
    obligor: str
    country: str
    sector: str
    spread_bps: Decimal
    factor: Decimal

    def __post_init__(self) -> None:
        for label in ("asset_id", "obligor", "country", "sector"):
            _text(getattr(self, label), label)
        if not isinstance(self.kind, AssetKind):
            raise InputValidationError("kind must be AssetKind")
        require_decimal(self.spread_bps, "spread_bps", minimum=Decimal(0))
        require_decimal(self.factor, "factor", minimum=Decimal(0))


@dataclass(frozen=True)
class Holding:
    """Positive settlement-available par of one economic facility, in EUR.

    Multiple identifiers for the same facility must be reconciled upstream;
    otherwise concentration and availability would be counted incorrectly.
    """
    asset: AssetDescriptor
    par: Decimal

    def __post_init__(self) -> None:
        if not isinstance(self.asset, AssetDescriptor):
            raise InputValidationError("asset must be AssetDescriptor")
        require_money(self.par, "holding par", positive=True)


@dataclass(frozen=True)
class TradeQuote:
    """Firm-input economics per unit par at the request's single settlement date.

    Accrued and proportional fee are EUR per EUR 1 par; clean price is per 100.
    Lots are multiples of lot_size (no minimum-plus-increment convention).
    Current assets may only be sold and new assets may only be bought.
    """

    asset: AssetDescriptor
    side: TradeSide
    clean_price_pct: Decimal
    maximum_par: Decimal
    accrued_per_par: Decimal = Decimal(0)
    proportional_fee_per_par: Decimal = Decimal(0)
    lot_size: Decimal | None = None
    minimum_ticket: Decimal = Decimal(0)
    fixed_fee: Decimal = Decimal(0)

    def __post_init__(self) -> None:
        if not isinstance(self.asset, AssetDescriptor) or self.asset.kind is not AssetKind.BSL:
            raise InputValidationError("Only BSL assets may have trade quotes")
        if not isinstance(self.side, TradeSide):
            raise InputValidationError("side must be TradeSide")
        require_decimal(self.clean_price_pct, "clean_price_pct", minimum=Decimal(0))
        if self.clean_price_pct == 0:
            raise InputValidationError("clean_price_pct must be positive")
        require_money(self.maximum_par, "maximum_par", positive=True)
        require_decimal(self.accrued_per_par, "accrued_per_par", minimum=Decimal(0))
        require_decimal(self.proportional_fee_per_par, "proportional_fee_per_par", minimum=Decimal(0))
        require_money(self.minimum_ticket, "minimum_ticket")
        require_money(self.fixed_fee, "fixed_fee")
        if self.minimum_ticket > self.maximum_par:
            raise InputValidationError("minimum_ticket exceeds quoted availability")
        if self.lot_size is not None:
            require_money(self.lot_size, "lot_size", positive=True)
            if self.lot_size > self.maximum_par:
                raise InputValidationError("lot_size exceeds quoted availability")


@dataclass(frozen=True)
class PortfolioLimits:
    """All ratios use ending performing collateral par, excluding cash.

    target_par is fixed and positive: linear factor/spread objectives therefore
    have a fixed denominator. BSL factor has its separate BSL-only denominator.
    Concentration caps apply to every group in the stated dimension.
    minimum_spread_bps bounds the descriptor's full-par quoted-spread proxy;
    use the portfolio analyzer's coupon-scoped WAS for contractual monitoring.
    """

    target_par: Decimal
    minimum_cash: Decimal = Decimal(0)
    maximum_obligor_share: Decimal | None = None
    maximum_country_share: Decimal | None = None
    maximum_sector_share: Decimal | None = None
    maximum_bsl_share: Decimal | None = None
    minimum_infra_share: Decimal | None = None
    maximum_overall_factor: Decimal | None = None
    maximum_bsl_factor: Decimal | None = None
    minimum_spread_bps: Decimal | None = None
    maximum_trade_par: Decimal | None = None

    def __post_init__(self) -> None:
        require_money(self.target_par, "target_par", positive=True)
        require_money(self.minimum_cash, "minimum_cash")
        for label in ("maximum_obligor_share", "maximum_country_share", "maximum_sector_share",
                      "maximum_bsl_share", "minimum_infra_share"):
            value = getattr(self, label)
            if value is not None:
                require_decimal(value, label, minimum=Decimal(0))
                if value > 1:
                    raise InputValidationError(f"{label} must be <= 1")
        for label in ("maximum_overall_factor", "maximum_bsl_factor", "minimum_spread_bps"):
            value = getattr(self, label)
            if value is not None:
                require_decimal(value, label, minimum=Decimal(0))
        if self.maximum_trade_par is not None:
            require_money(self.maximum_trade_par, "maximum_trade_par")


@dataclass(frozen=True)
class OptimizationRequest:
    """Explicit single-date, single-permitted-cash-account static mandate.

    starting_cash must be independently identified trading-eligible settlement
    cash. This API never imports a reserve or an interest account automatically.
    Caller must provide balances available at settlement, including commitments.
    """

    holdings: tuple[Holding, ...]
    quotes: tuple[TradeQuote, ...]
    starting_cash: Decimal
    limits: PortfolioLimits
    objective: OptimizationObjective
    factor_provenance: str
    settlement_date: date
    solver_time_limit: float | None = None
    mip_relative_gap: float = 1e-9

    def __post_init__(self) -> None:
        if type(self.holdings) is not tuple or not self.holdings or any(not isinstance(h, Holding) for h in self.holdings):
            raise InputValidationError("holdings must be a non-empty tuple of Holding")
        if type(self.quotes) is not tuple or any(not isinstance(q, TradeQuote) for q in self.quotes):
            raise InputValidationError("quotes must be a tuple of TradeQuote")
        if not isinstance(self.limits, PortfolioLimits) or not isinstance(self.objective, OptimizationObjective):
            raise InputValidationError("limits/objective have incorrect types")
        require_money(self.starting_cash, "starting_cash")
        require_date(self.settlement_date, "settlement_date")
        _text(self.factor_provenance, "factor_provenance")
        if self.mip_relative_gap is None:
            raise InputValidationError("mip_relative_gap must be finite numeric")
        for label, value in (("solver_time_limit", self.solver_time_limit), ("mip_relative_gap", self.mip_relative_gap)):
            if value is not None and (isinstance(value, bool) or not isinstance(value, (int, float)) or not isfinite(value)):
                raise InputValidationError(f"{label} must be finite numeric")
        if self.solver_time_limit is not None and self.solver_time_limit <= 0:
            raise InputValidationError("solver_time_limit must be positive")
        if not 0 <= self.mip_relative_gap <= 1:
            raise InputValidationError("mip_relative_gap must be in [0, 1]")
        existing = {h.asset.asset_id: h for h in self.holdings}
        if len(existing) != len(self.holdings):
            raise InputValidationError("Duplicate held economic asset ID")
        quoted = set()
        for quote in self.quotes:
            asset_id = quote.asset.asset_id
            if asset_id in quoted:
                raise InputValidationError("Only one quote per economic asset; simultaneous buy/sell is unsupported")
            quoted.add(asset_id)
            if quote.side is TradeSide.BUY and asset_id in existing:
                raise InputValidationError("BUY quotes must be new assets; increasing an existing asset is unsupported")
            if quote.side is TradeSide.SELL:
                if asset_id not in existing or quote.asset != existing[asset_id].asset:
                    raise InputValidationError("SELL quote metadata must exactly match a holding")
                if quote.maximum_par > existing[asset_id].par:
                    raise InputValidationError("SELL availability exceeds held settlement par")


@dataclass(frozen=True)
class ProposedTrade:
    """Cent-posted, unsigned trade components and signed settlement cash change.

    BUY cash_change is negative; SELL is clean+accrued less fees. No fields
    represent executed orders, capital gains or permitted CLO proceeds classes.
    """
    asset_id: str
    side: TradeSide
    par: Decimal
    clean_cash: Decimal
    accrued_cash: Decimal
    fee_cash: Decimal
    cash_change: Decimal


@dataclass(frozen=True)
class OptimizationResult:
    """Solver evidence and strict, independently recomputed static feasibility.

    OPTIMAL refers to the solved linear model before cent reconstruction. It is
    neither equity-IRR optimality nor an integer-cent global-optimality claim.
    validated concerns only this mandate's static single-account settlement;
    proceeds classification and future CLO replay remain separate requirements.
    Solver objective/bound are changes in the fixed-par mean factor (or negative
    mean spread), excluding the fixed baseline constant, not investor returns.
    """

    status: OptimizationStatus
    solver_status: int
    solver_message: str
    solver_method: str
    solver_objective: float | None
    solver_bound: float | None
    solver_gap: float | None
    factor_provenance: str
    trades: tuple[ProposedTrade, ...] = ()
    ending_holdings: tuple[Holding, ...] = ()
    ending_cash: Decimal | None = None
    ending_par: Decimal | None = None
    overall_factor: Decimal | None = None
    bsl_factor: Decimal | None = None
    spread_bps: Decimal | None = None
    violations: tuple[str, ...] = ()
    validation_scope: str = "STATIC_ONLY"
    clo_replay_status: str = "NOT_RUN"
    solver_optimality_scope: str = "LINEAR_MODEL_BEFORE_CENT_RECONSTRUCTION"

    @property
    def validated(self) -> bool:
        """Static exact feasibility only; OPTIMAL and limit incumbents differ."""
        return self.status in {OptimizationStatus.OPTIMAL, OptimizationStatus.FEASIBLE_TIME_LIMIT} and not self.violations
