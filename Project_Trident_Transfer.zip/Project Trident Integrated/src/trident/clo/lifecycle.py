"""Explicit legacy-compatible CLO valuation and investor fee policies.

These are configurable underwriting assumptions, not agency calibration or
universal indenture definitions. Asset-level overlap takes the lowest adjusted
value once; aggregate percentages retain the declared top-down additive proxy.
"""

from dataclasses import dataclass
from datetime import date
from decimal import Context, Decimal, DecimalException, localcontext
from enum import Enum
from fractions import Fraction

from trident.domain.models import InputValidationError, require_date, require_decimal, require_money
from trident.domain.numeric import post_currency


class ShortfallAccrualMethod(str, Enum):
    """Whether carried coupon claims earn interest; separate from OC treatment."""
    NONE = "NONE"
    COUPON_RATE = "COUPON_RATE"


@dataclass(frozen=True)
class OcAssetData:
    """Explicit asset classifications and distinct acquisition/current marks.

    Prices are decimal fractions of par. Acquisition price establishes Discount
    valuation; current market mark establishes CCC-excess ranking and value.
    A missing market mark never silently falls back to an acquisition price.
    """

    loan_id: str
    is_ccc: bool = False
    is_discount: bool = False
    clean_price_fraction: Decimal = Decimal(1)
    market_price_fraction: Decimal | None = None

    def __post_init__(self) -> None:
        if not isinstance(self.loan_id, str) or not self.loan_id or self.loan_id != self.loan_id.strip():
            raise InputValidationError("OC asset loan_id must be nonblank and unpadded")
        if type(self.is_ccc) is not bool or type(self.is_discount) is not bool:
            raise InputValidationError("OC asset classification flags must be boolean")
        require_decimal(self.clean_price_fraction, "OC clean_price_fraction", minimum=Decimal(0))
        if self.market_price_fraction is not None:
            require_decimal(self.market_price_fraction, "OC market_price_fraction", minimum=Decimal(0))


@dataclass(frozen=True)
class OcAssetBalance:
    """Identified remaining face and contract horizon at one valuation date."""
    loan_id: str
    performing_par: Decimal
    final_principal_date: date
    data: OcAssetData

    def __post_init__(self) -> None:
        require_money(self.performing_par, "OC identified performing_par")
        require_date(self.final_principal_date, "OC final principal date")
        if not isinstance(self.data, OcAssetData) or self.loan_id != self.data.loan_id:
            raise InputValidationError("OC asset balance and classification identities differ")


@dataclass(frozen=True)
class AdjustedCollateralValue:
    """Noncash OC credit and haircut attribution; no sale proceeds are posted.

    Haircut categories can overlap. ``overlap_credit`` offsets duplicate loss
    attribution under the asset-level lowest-value policy, so presentation
    categories are not independent cash deductions.
    """
    performing_par: Decimal
    adjusted_performing_par: Decimal
    ccc_haircut: Decimal
    discount_haircut: Decimal
    long_dated_haircut: Decimal
    overlap_credit: Decimal
    defaulted_value: Decimal
    long_dated_par: Decimal

    @property
    def collateral_value(self) -> Decimal:
        """Return performing plus defaulted noncash OC credit, in EUR cents."""
        return post_currency(Fraction(self.adjusted_performing_par) + Fraction(self.defaulted_value))


@dataclass(frozen=True)
class AdjustedCollateralValuePolicy:
    """Top-down proxy or asset-level lowest-value OC treatment.

    Fractions are in [0,1]. CCC haircut applies only above the configured limit.
    Asset-level CCC excess selects current lowest market values and values those
    slices at their own current marks. Discount
    classification is explicit OR clean price below threshold. Asset-level
    discount value uses acquisition price, capped at par; top-down uses the
    explicit valuation input. Long-dated means final principal after legal final.
    """

    use_asset_level_test_data: bool = False
    ccc_fraction: Decimal = Decimal(0)
    ccc_limit_fraction: Decimal = Decimal(1)
    ccc_valuation: Decimal = Decimal(1)
    discount_fraction: Decimal = Decimal(0)
    discount_valuation: Decimal = Decimal(1)
    defaulted_valuation: Decimal = Decimal(0)
    long_dated_valuation: Decimal = Decimal(1)
    discount_price_threshold: Decimal = Decimal(0)

    def __post_init__(self) -> None:
        if type(self.use_asset_level_test_data) is not bool:
            raise InputValidationError("use_asset_level_test_data must be boolean")
        for name in ("ccc_fraction", "ccc_limit_fraction", "ccc_valuation", "discount_fraction",
                     "discount_valuation", "defaulted_valuation", "long_dated_valuation", "discount_price_threshold"):
            value = require_decimal(getattr(self, name), name, minimum=Decimal(0))
            if value > 1:
                raise InputValidationError(f"{name} must be a decimal fraction no greater than 1")

    def value(self, assets: tuple[OcAssetBalance, ...], performing_par: Decimal,
              defaulted_par: Decimal, legal_final: date, *, synthetic_par: Decimal = Decimal(0),
              synthetic_long_dated_par: Decimal = Decimal(0)) -> AdjustedCollateralValue:
        """Compute noncash collateral credit with explicit classification rules.

        Original remaining balances plus synthetic par form the face total.
        Asset-level CCC excess is selected by lowest current mark; overlapping
        CCC, discount and long-date policies use the worst value on each par
        slice once. The top-down proxy instead uses configured aggregate
        fractions with a bounded additive loss; it is a disclosed sensitivity.
        Default claims receive their separately configured credit, never a
        performing balance or physical recovery inferred from that credit.
        """
        require_money(performing_par, "OC performing_par")
        require_money(defaulted_par, "OC defaulted_par")
        require_money(synthetic_par, "OC synthetic_par")
        require_money(synthetic_long_dated_par, "OC synthetic_long_dated_par")
        require_date(legal_final, "OC legal_final")
        if synthetic_long_dated_par > synthetic_par:
            raise InputValidationError("Synthetic long-dated par cannot exceed synthetic performing par")
        if type(assets) is not tuple or any(not isinstance(row, OcAssetBalance) for row in assets) or len({row.loan_id for row in assets}) != len(assets):
            raise InputValidationError("OC balances require unique immutable identified rows")
        total = Fraction(performing_par)
        long_par = sum((Fraction(row.performing_par) for row in assets if row.final_principal_date > legal_final), Fraction(0)) + Fraction(synthetic_long_dated_par)
        long_par = min(total, long_par)
        ccc_haircut = discount_haircut = overlap_credit = Fraction(0)
        long_haircut = long_par * (1 - Fraction(self.long_dated_valuation))
        if self.use_asset_level_test_data:
            if synthetic_par:
                # A cohort's existence/par does not establish that it is
                # non-CCC or purchased above the discount threshold. Until
                # cohort classifications and prices enter this interface,
                # assigning full OC credit would create false passing tests.
                raise InputValidationError(
                    "Synthetic reinvestment cohorts require explicit asset-level OC classification "
                    "and acquisition-price data; use the declared top-down OC policy meanwhile"
                )
            if sum((Fraction(row.performing_par) for row in assets), Fraction(0)) + Fraction(synthetic_par) != total:
                raise InputValidationError("Asset-level OC classifications must reconcile to performing par")
            ccc_rows = [row for row in assets if row.data.is_ccc]
            excess = max(Fraction(0), sum((Fraction(row.performing_par) for row in ccc_rows), Fraction(0)) - total * Fraction(self.ccc_limit_fraction))
            if excess and any(row.performing_par and row.data.market_price_fraction is None for row in ccc_rows):
                raise InputValidationError("Asset-level CCC excess requires current market_price_fraction for every performing CCC asset")
            ccc_rows.sort(key=lambda row: (row.data.market_price_fraction if row.data.market_price_fraction is not None else Decimal(1), row.loan_id))
            ccc_losses, ccc_selected = {}, {}
            for row in ccc_rows:
                selected = min(excess, Fraction(row.performing_par))
                mark = min(Fraction(1), Fraction(row.data.market_price_fraction)) if selected else Fraction(1)
                loss = selected * (1 - mark)
                ccc_losses[row.loan_id] = loss
                ccc_selected[row.loan_id] = selected
                ccc_haircut += loss
                excess -= selected
            adjusted_loss = Fraction(synthetic_long_dated_par) * (1 - Fraction(self.long_dated_valuation))
            for row in assets:
                par = Fraction(row.performing_par)
                ccc_loss = ccc_losses.get(row.loan_id, Fraction(0))
                discount_loss = (par * (1 - min(Fraction(1), Fraction(row.data.clean_price_fraction)))
                                 if row.data.is_discount or row.data.clean_price_fraction < self.discount_price_threshold else Fraction(0))
                long_loss = par * (1 - Fraction(self.long_dated_valuation)) if row.final_principal_date > legal_final else Fraction(0)
                discount_haircut += discount_loss
                # CCC selection can take a partial par amount. In that amount,
                # retain only the largest applicable haircut, avoiding duplicate
                # deductions where CCC, discount and long-dated flags overlap.
                selected_par = ccc_selected.get(row.loan_id, Fraction(0))
                ordinary_unit_loss = max(discount_loss, long_loss) / par if par else Fraction(0)
                selected_unit_loss = max(ordinary_unit_loss, ccc_loss / selected_par if selected_par else Fraction(0))
                adjusted_loss += selected_par * selected_unit_loss + (par - selected_par) * ordinary_unit_loss
            overlap_credit = ccc_haircut + discount_haircut + long_haircut - adjusted_loss
        else:
            ccc_haircut = max(Fraction(0), total * (Fraction(self.ccc_fraction) - Fraction(self.ccc_limit_fraction))) * (1 - Fraction(self.ccc_valuation))
            discount_haircut = total * Fraction(self.discount_fraction) * (1 - Fraction(self.discount_valuation))
            adjusted_loss = min(total, ccc_haircut + discount_haircut + long_haircut)
        return AdjustedCollateralValue(
            post_currency(total), post_currency(max(Fraction(0), total - adjusted_loss)),
            post_currency(ccc_haircut), post_currency(discount_haircut), post_currency(long_haircut),
            post_currency(overlap_credit), post_currency(Fraction(defaulted_par) * Fraction(self.defaulted_valuation)),
            post_currency(long_par),
        )


@dataclass
class EquityHurdleAccount:
    """Accruing unpaid investor hurdle used by the legacy incentive mechanism.

    The opening account is actual equity cash funding. Net distributions reduce
    it to zero. Fees charge only residual cash above the accrued hurdle, using
    actual/365 annual effective compounding; no fee is taken merely because a
    gross IRR numerical solver happens to cross a rounded threshold.
    """

    balance: Decimal
    last_date: date
    rate: Decimal
    fee_rate: Decimal

    def __post_init__(self) -> None:
        require_money(self.balance, "opening equity hurdle funding")
        require_date(self.last_date, "opening equity hurdle date")
        for label in ("rate", "fee_rate"):
            if require_decimal(getattr(self, label), label, minimum=Decimal(0)) > 1:
                raise InputValidationError("Equity hurdle and incentive fee rates must not exceed 1")

    def accrue(self, payment_date: date, extra_funding: Decimal = Decimal(0)) -> Decimal:
        """Accrue the investor hurdle to this date, then add new cash funding.

        Additional equity contribution starts earning after its actual funding
        date. It is not backdated across the interval that has just elapsed.
        """
        require_date(payment_date, "hurdle payment_date")
        require_money(extra_funding, "additional equity hurdle funding")
        if payment_date < self.last_date:
            raise InputValidationError("Hurdle dates must not go backwards")
        with localcontext(Context(prec=max(60, self.balance.adjusted() + 40))) as context:
            try:
                years = Decimal((payment_date - self.last_date).days) / 365
                self.balance = self.balance * context.power(Decimal(1) + self.rate, years) + extra_funding
            except DecimalException as exc:
                raise InputValidationError("Incentive hurdle exceeds numeric domain") from exc
        self.last_date = payment_date
        return self.balance

    def charge(self, gross_distribution: Decimal) -> Decimal:
        """Post the fee on surplus cash and reduce the hurdle by net investor cash.

        A fee consumes physical distribution cash but does not satisfy the
        investor's hurdle balance; using gross distributions here would do so.
        """
        require_money(gross_distribution, "gross equity hurdle distribution")
        fee = post_currency(max(Fraction(0), Fraction(gross_distribution) - Fraction(self.balance)) * Fraction(self.fee_rate))
        # The accrued hurdle can contain fractional cents. Preserve its finite
        # coefficient when deducting posted distributions, independent of the
        # caller's Decimal precision and Inexact traps.
        amounts = (self.balance, gross_distribution, fee)
        precision = max(value.adjusted() for value in amounts) - min(value.as_tuple().exponent for value in amounts) + 4
        with localcontext(Context(prec=max(60, precision))):
            self.balance = max(Decimal(0), self.balance - (gross_distribution - fee))
        return fee
