"""Source-to-named control completeness and independent semantic boundary checks.

These inventory tests establish missing-field/schema behavior; they do not
replace feature-specific waterfall/cashflow financial known-answer tests.
"""
from datetime import date
from decimal import Decimal
import unittest

from trident.adapters.legacy_inputs import LEGACY_INPUTS, LEGACY_BY_SOURCE, validate_legacy_controls
from trident.adapters.legacy_execution import assumption_execution_records, execution_for
from trident.adapters.legacy_model_records import legacy_values
from trident.adapters import excel_schema as schema
from trident.domain.models import InputValidationError


class LegacyCoverageTests(unittest.TestCase):
    @staticmethod
    def controls():
        return {f"legacy_{field.field_id}": field.default_value for field in LEGACY_INPUTS}

    def test_every_source_input_has_stable_unique_named_input_and_execution_row(self):
        rows = assumption_execution_records(self.controls())
        self.assertEqual(len(rows), 107)
        self.assertEqual({row["source_input"] for row in rows}, {field.source_coordinate for field in LEGACY_INPUTS})
        for field in LEGACY_INPUTS:
            with self.subTest(source=field.source_coordinate):
                key = f"legacy_{field.field_id}"
                self.assertIn(key, schema.INPUT_KEYS)
                self.assertEqual(schema.SCALAR_NAMES[key], f"trident_clo_{field.field_id}")
                path, condition = execution_for(field.field_id)
                self.assertTrue(path)
                self.assertTrue(condition)
        self.assertEqual(len({schema.SCALAR_NAMES[f"legacy_{field.field_id}"].casefold() for field in LEGACY_INPUTS}), 107)

    def test_every_missing_source_input_fails_with_its_semantic_id(self):
        controls = self.controls()
        for field in LEGACY_INPUTS:
            with self.subTest(source=field.source_coordinate), self.assertRaisesRegex(InputValidationError, field.field_id):
                legacy_values({key: value for key, value in controls.items() if key != f"legacy_{field.field_id}"})

    def test_every_input_received_its_type_and_original_unit(self):
        parsed = legacy_values(self.controls())
        independently = validate_legacy_controls({field.field_id: field.default_value for field in LEGACY_INPUTS})
        self.assertEqual(parsed, dict(independently))
        for field in LEGACY_INPUTS:
            with self.subTest(source=field.source_coordinate):
                expected_type = date if field.semantic_type == "DATE" else int if field.semantic_type == "INTEGER" else Decimal if field.semantic_type in {"MONEY", "DECIMAL"} else str
                self.assertIs(type(parsed[field.field_id]), expected_type)

    def test_disabled_parameters_still_type_checked_not_silently_dropped(self):
        controls = self.controls()
        controls["legacy_optional_call_enabled"] = "No"
        for key, value in (("call_date", "not-a-date"), ("incentive_fee_rate", "NaN"),
                           ("reinvestment_recovery_lag_months", "2.5"), ("cash_accrual_curve", "€STR typo")):
            with self.subTest(key=key), self.assertRaises(InputValidationError):
                legacy_values({**controls, f"legacy_{key}": value})

    def test_derived_outputs_are_named_and_not_editable_duplicate_inputs(self):
        for coordinate in ("B33", "B53", "B54"):
            field = LEGACY_BY_SOURCE[coordinate]
            self.assertIn(f"legacy_{field.field_id}", schema.SCALAR_NAMES)
            self.assertNotIn(f"legacy_{field.field_id}", schema.INPUT_KEYS)

    def test_unknown_policy_fails_instead_of_fabricated_done(self):
        with self.assertRaises(RuntimeError):
            execution_for("new_unimplemented_field")

    def test_root_hurdle_range_rejects_before_cashflow_only_branch(self):
        controls = {**self.controls(), "mode": "CASHFLOW_ONLY", "legacy_incentive_management_fee_enabled": "No"}
        for hurdle in ("-0.01", "1.0000000000000000000000000001"):
            with self.subTest(hurdle=hurdle), self.assertRaisesRegex(InputValidationError, "equity_irr_hurdle"):
                legacy_values({**controls, "legacy_equity_irr_hurdle": hurdle})
        for hurdle in ("0", "1"):
            self.assertEqual(legacy_values({**controls, "legacy_equity_irr_hurdle": hurdle})["equity_irr_hurdle"], Decimal(hurdle))
