"""Independent restricted-liquidity and face controls for ledger replay.

Same-day end balances cannot prove that every earlier operation was funded.
These controls challenge the declared event order, then check that earlier
cancellations and actual claim receipts can correctly release usable cash.
"""

import unittest
from datetime import date
from decimal import Decimal

from trident.domain.models import InputValidationError
from trident.portfolio import (
    CashAccount, CashBalances, CashReceivable, HoldingsLedgerRequest,
    HoldingsLedgerService, LedgerEvent, LedgerEventKind, LedgerPermissions,
    OpeningHolding, TradeCommitment, TradeSide,
)


D = Decimal
OPEN = date(2026, 1, 1)
COMMIT = date(2026, 1, 2)
PAY = date(2026, 1, 3)
HORIZON = date(2026, 1, 5)


class LedgerAdversarialTests(unittest.TestCase):
    def test_later_same_day_cancel_cannot_mask_payment_from_reserved_cash(self):
        for account in (CashAccount.PRINCIPAL, CashAccount.INTEREST):
            with self.subTest(account=account):
                is_principal = account is CashAccount.PRINCIPAL
                trade = TradeCommitment(
                    "BUY", "L", TradeSide.BUY, COMMIT, HORIZON, D(100),
                    D(99) if is_principal else D(0),
                    accrued_cash=D(0) if is_principal else D(99),
                    accrued_account=CashAccount.INTEREST,
                )
                cash = CashBalances(D(100), D(0)) if is_principal else CashBalances(D(0), D(100))
                payment = LedgerEvent(
                    "PAY", PAY, LedgerEventKind.CASH_PAYMENT, "Independent actual payment",
                    principal_cash=D(2) if is_principal else D(0),
                    interest_cash=D(0) if is_principal else D(2),
                )
                cancel = LedgerEvent("CANCEL", PAY, LedgerEventKind.TRADE_CANCEL,
                                     "Counterparty confirmation", trade_id="BUY")
                request = HoldingsLedgerRequest(
                    OPEN, HORIZON, "EUR", cash, (), trades=(trade,), events=(cancel, payment))
                # At the payment phase100actual minus99reserved leaves1;
                # cancellation later that day cannot retroactively fund2.
                with self.assertRaisesRegex(InputValidationError, "encumbered|unencumbered|reserved"):
                    HoldingsLedgerService().replay(request)

    def test_prior_day_cancel_releases_cash_for_next_day_actual_payment(self):
        trade = TradeCommitment("BUY", "L", TradeSide.BUY, COMMIT, HORIZON, D(100), D(99))
        cancel = LedgerEvent("CANCEL", PAY, LedgerEventKind.TRADE_CANCEL,
                             "Counterparty confirmation", trade_id="BUY")
        payment = LedgerEvent("PAY", date(2026, 1, 4), LedgerEventKind.CASH_PAYMENT,
                              "Actual payment", principal_cash=D(2))
        result = HoldingsLedgerService().replay(HoldingsLedgerRequest(
            OPEN, HORIZON, "EUR", CashBalances(D(100)), (),
            trades=(trade,), events=(payment, cancel)))
        self.assertEqual(result.final_snapshot.cash.principal, D(98))
        self.assertEqual(result.final_snapshot.reserved_cash, CashBalances())
        self.assertEqual(result.final_snapshot.settled_par, D(0))
        self.assertEqual([row.kind for row in result.journal], ["COMMIT", "TRADE_CANCEL", "CASH_PAYMENT"])

    def test_actual_claim_receipt_can_fund_payment_without_creating_more_face(self):
        claim = CashReceivable("R", "RETIRED", OPEN, PAY, D(20), D(3), "Known recovery and coupon allocation")
        receipt = LedgerEvent("RECEIPT", PAY, LedgerEventKind.RECEIVABLE_COLLECTION,
                              "Actual servicing statement", asset_id="RETIRED", receivable_id="R",
                              principal_cash=D(20), interest_cash=D(3))
        payment = LedgerEvent("PAY", PAY, LedgerEventKind.CASH_PAYMENT,
                              "Actual debt payment", principal_cash=D(10), interest_cash=D(2))
        result = HoldingsLedgerService().replay(HoldingsLedgerRequest(
            OPEN, HORIZON, "EUR", CashBalances(), (OpeningHolding("RETIRED", "EUR", D(0)),),
            events=(payment, receipt), opening_receivables=(claim,)))
        self.assertEqual(result.final_snapshot.cash, CashBalances(D(10), D(1)))
        self.assertEqual(result.final_snapshot.settled_par, D(0))
        self.assertEqual(result.final_snapshot.receivables, ())
        self.assertEqual([row.kind for row in result.journal], ["RECEIVABLE_COLLECTION", "CASH_PAYMENT"])

    def test_partial_sale_conserves_legal_face_and_net_component_cash(self):
        trade = TradeCommitment(
            "SALE", "L", TradeSide.SELL, COMMIT, PAY, D(80), D(95),
            accrued_cash=D("1.25"), fees_cash=D(".50"), fee_account=CashAccount.PRINCIPAL,
        )
        result = HoldingsLedgerService().replay(HoldingsLedgerRequest(
            OPEN, HORIZON, "EUR", CashBalances(), (OpeningHolding("L", "EUR", D(100)),),
            trades=(trade,), permissions=LedgerPermissions(allow_principal_for_fees=True)))
        # Selling80face for95per100 receives76clean, pays0.50fee from
        # that account, and receives1.25accrued separately:face20 remains.
        self.assertEqual(result.final_snapshot.cash, CashBalances(D("75.50"), D("1.25")))
        self.assertEqual(result.final_snapshot.settled_par, D(20))
        self.assertEqual(result.final_snapshot.available_to_sell("L"), D(20))
        settled, = tuple(row for row in result.journal if row.kind == "SETTLE")
        self.assertEqual((settled.clean_cash, settled.accrued_cash, settled.fee_cash),
                         (D(76), D("1.25"), D("-.50")))


if __name__ == "__main__":
    unittest.main()
