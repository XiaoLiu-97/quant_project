"""Immutable portfolio observations, explicit factor provenance and limit results.

Par is currency units; spreads are basis points; concentration values are
fractions. Missing descriptive data stays missing rather than gaining an
implicit production classification or being excluded from denominators.
"""

from dataclasses import dataclass
from datetime import date
from decimal import Decimal
from enum import Enum
from types import MappingProxyType
from typing import Mapping

from trident.domain.models import CouponType, InputValidationError, require_date, require_decimal, require_money


def _text(value: object, label: str, *, optional: bool = False) -> None:
    if optional and value is None:
        return
    if not isinstance(value, str) or not value or value != value.strip():
        raise InputValidationError(f"{label} must be a nonempty, unpadded string")


class MetricStatus(str, Enum):
    AVAILABLE = "AVAILABLE"
    INCOMPLETE = "INCOMPLETE"
    UNAVAILABLE = "UNAVAILABLE"


class LimitDirection(str, Enum):
    MAXIMUM = "MAXIMUM"
    MINIMUM = "MINIMUM"


class LimitStatus(str, Enum):
    PASS = "PASS"
    BREACH = "BREACH"
    UNAVAILABLE = "UNAVAILABLE"
    NOT_APPLICABLE = "NOT_APPLICABLE"


@dataclass(frozen=True)
class ScheduledMaturityReceipt:
    """Evidence of final principal awaiting its known adjusted receipt date.

    This does not move contractual maturity, recognize cash, create a default
    or authorize continued interest accrual. The analyzer independently binds
    the identity, currency, nominal boundary and full held par to one remaining
    principal-reference row before admitting a post-maturity observation.
    Amounts are currency units; both dates are exact calendar dates.
    """

    loan_id: str
    currency: str
    nominal_maturity_date: date
    receipt_date: date
    outstanding_principal: Decimal

    def __post_init__(self) -> None:
        _text(self.loan_id, "maturity receipt loan_id")
        _text(self.currency, "maturity receipt currency")
        require_date(self.nominal_maturity_date, "nominal_maturity_date")
        require_date(self.receipt_date, "maturity receipt date")
        require_money(self.outstanding_principal, "outstanding_principal", positive=True)
        if self.receipt_date <= self.nominal_maturity_date:
            raise InputValidationError("Adjusted maturity receipt must follow nominal maturity")


@dataclass(frozen=True)
class AssetExposure:
    """A held par observation, independent of coupon schedule and Excel rows.

    Direct agency factors require both a named methodology/system and version.
    The synthetic test bucket is intentionally a separate field from ratings.
    Boolean quality attributes default to missing, never implicitly compliant.
    Coupon classification is explicit: floating spread (bps) and fixed coupon
    (annual decimal fraction) define separate par populations for WAS/WAC.
    Missing coupon_type cannot silently establish either denominator.
    """

    loan_id: str
    obligor: str | None
    asset_class: str | None
    financing_type: str | None
    country: str | None
    sector: str | None
    currency: str
    par: Decimal
    spread_bps: Decimal | None
    maturity_date: date
    is_senior: bool | None = None
    is_secured: bool | None = None
    is_pik: bool | None = None
    is_revolver: bool | None = None
    is_construction: bool | None = None
    test_factor_bucket: str | None = None
    rating_bucket: str | None = None
    rating_factor: Decimal | None = None
    rating_system: str | None = None
    rating_version: str | None = None
    recovery_rate: Decimal | None = None
    recovery_rate_source: str | None = None
    coupon_type: CouponType | None = None
    fixed_coupon_rate: Decimal | None = None

    def __post_init__(self) -> None:
        _text(self.loan_id, "loan_id")
        _text(self.currency, "currency")
        for field in ("obligor", "asset_class", "financing_type", "country", "sector",
                      "test_factor_bucket", "rating_bucket", "rating_system", "rating_version", "recovery_rate_source"):
            _text(getattr(self, field), field, optional=True)
        require_money(self.par, "par", positive=True)
        require_date(self.maturity_date, "maturity_date")
        if self.spread_bps is not None:
            require_decimal(self.spread_bps, "spread_bps")
        if self.coupon_type is not None and not isinstance(self.coupon_type, CouponType):
            raise InputValidationError("coupon_type must be CouponType or missing")
        if self.fixed_coupon_rate is not None:
            require_decimal(self.fixed_coupon_rate, "fixed_coupon_rate")
            if self.coupon_type is not CouponType.FIXED:
                raise InputValidationError("fixed_coupon_rate requires an explicit FIXED coupon_type")
        for field in ("is_senior", "is_secured", "is_pik", "is_revolver", "is_construction"):
            if getattr(self, field) is not None and type(getattr(self, field)) is not bool:
                raise InputValidationError(f"{field} must be bool or missing")
        if self.rating_factor is not None:
            require_decimal(self.rating_factor, "rating_factor", minimum=Decimal(0))
            if self.rating_system is None or self.rating_version is None:
                raise InputValidationError("Direct rating factors require system and version")
        if (self.rating_system is None) != (self.rating_version is None):
            raise InputValidationError("rating_system and rating_version must be provided together")
        if self.recovery_rate is not None:
            require_decimal(self.recovery_rate, "recovery_rate", minimum=Decimal(0))
            if self.recovery_rate > 1:
                raise InputValidationError("recovery_rate must be a decimal fraction between zero and one")
        if (self.recovery_rate is None) != (self.recovery_rate_source is None):
            raise InputValidationError("recovery_rate and its explicit source must be provided together")


@dataclass(frozen=True)
class FactorMapping:
    """One explicitly selected, versioned factor methodology.

    This class supplies no agency table. Synthetic mappings must be marked and
    produce TEST_FACTOR_AVERAGE, never a metric labelled agency WARF.
    """

    system: str
    version: str
    factors: Mapping[str, Decimal]
    is_synthetic: bool = False

    def __post_init__(self) -> None:
        _text(self.system, "factor system")
        _text(self.version, "factor version")
        if type(self.is_synthetic) is not bool:
            raise InputValidationError("is_synthetic must be bool")
        if not isinstance(self.factors, Mapping) or not self.factors:
            raise InputValidationError("factor mapping must be nonempty")
        copy = dict(self.factors)
        for bucket, factor in copy.items():
            _text(bucket, "factor bucket")
            require_decimal(factor, "rating factor", minimum=Decimal(0))
        object.__setattr__(self, "factors", MappingProxyType(copy))


@dataclass(frozen=True)
class MetricResult:
    """Value and unit with coverage/status; absent data is not a zero metric."""
    name: str
    value: Decimal | None
    status: MetricStatus
    unit: str
    coverage: Decimal
    message: str = ""


@dataclass(frozen=True)
class ConcentrationResult:
    dimension: str
    bucket: str | None
    par: Decimal
    fraction: Decimal


@dataclass(frozen=True)
class LimitSpec:
    """Snapshot limit, with inclusive equality and explicit phase applicability.

    metric is a reported metric name or concentration:<dimension>:<bucket>.
    Empty phases means applicable to every phase. Limits are caller supplied;
    they are not inferred from an agency convention or a test transaction.
    """

    limit_id: str
    metric: str
    threshold: Decimal
    direction: LimitDirection = LimitDirection.MAXIMUM
    phases: tuple[str, ...] = ()

    def __post_init__(self) -> None:
        _text(self.limit_id, "limit_id")
        _text(self.metric, "limit metric")
        require_decimal(self.threshold, "threshold")
        if not isinstance(self.direction, LimitDirection):
            raise InputValidationError("direction must be LimitDirection")
        if not isinstance(self.phases, tuple) or len(set(self.phases)) != len(self.phases):
            raise InputValidationError("phases must be an immutable tuple without duplicates")
        for phase in self.phases:
            _text(phase, "phase")


@dataclass(frozen=True)
class LimitResult:
    """One inclusive limit assessment; unavailable inputs cannot count as PASS."""
    limit_id: str
    metric: str
    value: Decimal | None
    threshold: Decimal
    direction: LimitDirection
    status: LimitStatus
    headroom: Decimal | None
    message: str = ""


@dataclass(frozen=True)
class PortfolioReport:
    """One dated held-par population with metrics, concentrations and limits."""
    as_of_date: date
    currency: str | None
    asset_count: int
    total_par: Decimal
    phase: str
    metrics: tuple[MetricResult, ...]
    concentrations: tuple[ConcentrationResult, ...]
    limits: tuple[LimitResult, ...]

    def metric(self, name: str) -> MetricResult:
        """Retrieve a known metric; never silently return an absent observation."""
        for result in self.metrics:
            if result.name == name:
                return result
        raise KeyError(name)
