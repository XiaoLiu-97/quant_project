"""Dated-term transport, named relocation and independent cashflow acceptance.

The detail input is separate from the asset tape: IDs and scope bind absolute
rate levels to immutable contracts. A small loan and a full closing-pool replay
check that zero rates, elapsed accrual and optional-interface migration retain
their financial meaning rather than merely round-trip Python objects.
"""

import csv
from datetime import date
from decimal import Decimal
from pathlib import Path
import tempfile
import unittest

from openpyxl import load_workbook
from openpyxl.workbook.defined_name import DefinedName
from openpyxl.worksheet.table import Table, TableColumn

from trident.adapters import excel_schema as schema
from trident.adapters.candidate_records import candidate_search_from_records
from trident.adapters.csv_input import read_csv_records
from trident.adapters.excel import NamedWorkbook, run_workbook
from trident.adapters.excel_model import _ensure_optional_inputs, read_model_workbook_inputs
from trident.adapters.legacy_model_records import legacy_model_request_from_records
from trident.adapters.records import coupon_steps_from_records, position_from_record, run_request_from_records
from trident.application.candidate_search import ClosingPoolSearchService
from trident.application.services import CashflowRunService
from trident.domain.models import CouponStepPolicy, InputValidationError
from trident.market import FlatRateProvider
from test_assumption_execution import small_inputs
from test_candidate_records import records_fixture
from test_contract_records import _asset
from workbook_fixtures import INPUT_TEMPLATE, copy_input_template

D = Decimal


def step(identifier="CONTRACT_LOAN", *, scope="ASSET", effective_date="2027-02-20",
         fixed_rate="0", spread_bps=None, policy="ACTUAL_DATE"):
    """Raw semantic row: explicit zero and absent opposite field stay distinct."""
    return dict(scope=scope, loan_id=identifier, effective_date=effective_date,
                fixed_rate=fixed_rate, spread_bps=spread_bps, policy=policy)


class CouponStepRecordsTests(unittest.TestCase):
    def test_unsorted_csv_absolute_levels_preserve_blank_and_zero(self):
        rows = (step(effective_date="2027-05-20", fixed_rate=".02"), step(fixed_rate="0"))
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / "coupon_steps.csv"
            with path.open("w", encoding="utf-8", newline="") as stream:
                writer = csv.DictWriter(stream, fieldnames=schema.TABLE_COLUMNS["coupon_steps"])
                writer.writeheader()
                writer.writerows(rows)
            groups = coupon_steps_from_records(read_csv_records(path), (_asset(),))
        steps, policy = groups["CONTRACT_LOAN"]
        self.assertEqual(tuple(item.effective_date for item in steps), (date(2027, 2, 20), date(2027, 5, 20)))
        self.assertEqual(tuple(item.fixed_rate for item in steps), (D(0), D(".02")))
        self.assertTrue(all(item.spread_bps is None for item in steps))
        self.assertIs(policy, CouponStepPolicy.ACTUAL_DATE)

    def test_unknown_scope_id_duplicates_conflicts_and_incomplete_levels_fail(self):
        bad_cases = (
            (step(scope="OTHER"),), (step(identifier="MISSING"),), (step(), step()),
            (step(), step(effective_date="2027-05-20", policy="PAYMENT_START")),
            (step(fixed_rate=None),), (step(fixed_rate=0, spread_bps=0),),
            (step(fixed_rate="NaN"),), (step(fixed_rate=True),),
            (step(policy=""),), (dict(step(), increment=1),),
        )
        for rows in bad_cases:
            with self.subTest(rows=rows), self.assertRaises(InputValidationError):
                coupon_steps_from_records(rows, (_asset(),))

    def test_contract_date_type_and_policy_are_validated_at_typed_boundary(self):
        for row in (step(effective_date="2026-11-20"), step(effective_date="2027-11-20"),
                    step(spread_bps=100, fixed_rate=None), step(policy="RESET_START")):
            with self.subTest(row=row):
                steps, policy = coupon_steps_from_records((row,), (_asset(),))["CONTRACT_LOAN"]
                with self.assertRaises(InputValidationError):
                    position_from_record(_asset(), coupon_steps=steps, coupon_step_policy=policy)

    def test_direct_cashflow_records_apply_absolute_fixed_rate_step(self):
        # Four nominal 30E/360 quarters on EUR1,000. The first earns 8%;
        # the following three earn zero, without adding zero to the old level.
        request = run_request_from_records((_asset(amortization_type="BULLET",
            amortization_periods_remaining=None, scheduled_principal_amount=None,
            amortization_first_date_unadjusted=None),), (), FlatRateProvider({}),
            upfront_fees=D(0), cash_reserve=D(0), rate_provenance="HAND_30E360",
            coupon_step_records=(step(),))
        rows = CashflowRunService().run(request).cashflows
        self.assertEqual(tuple(row.cash_interest for row in rows), (D(20), D(0), D(0), D(0)))
        self.assertEqual(sum(row.principal_repayment for row in rows), D(1000))

    def test_legacy_entry_carries_baseline_spread_steps(self):
        assets, capital, controls, factors, provider = small_inputs(
            legacy_credit_prepayment_overlay="Off", legacy_reinvestment_enabled="No")
        request = legacy_model_request_from_records(assets, capital, provider, controls=controls,
            factors=factors, limits=(), provenance="HAND_INPUT", coupon_step_records=(
                step("HAND", effective_date="2027-02-20", fixed_rate=None, spread_bps=0),))
        self.assertEqual(request.cashflow_request.positions[0].terms.coupon_steps[0].spread_bps, D(0))

    def test_candidate_steps_survive_admission_and_complete_equity_replay(self):
        baseline, result, held, quotes, controls, args = records_fixture()
        request = candidate_search_from_records(baseline, result, held, quotes, controls, **args,
            coupon_step_records=(step("NEW", scope="CANDIDATE", effective_date="2026-02-20",
                                      fixed_rate=None, spread_bps=0),))
        candidate = next(row for row in request.candidate_snapshot.candidates if row.asset_id == "NEW")
        self.assertEqual(candidate.position.terms.coupon_steps[0].spread_bps, D(0))
        replay = ClosingPoolSearchService().run(request)
        # EUR10,000 * 8% * 31/360 = 68.89; note coupon 40, net face 2,000.
        self.assertEqual(replay.evaluation("FULL_SWAP").equity_distributions, D("2028.89"))
        preflight = candidate_search_from_records(baseline, None, held, quotes, controls, **args,
            coupon_step_records=(step("NEW", scope="CANDIDATE", effective_date="2026-02-20",
                                      fixed_rate=None, spread_bps=0),))
        self.assertEqual(preflight.candidate_snapshot, request.candidate_snapshot)

    def test_candidate_parser_rejects_unapplied_baseline_step_rows(self):
        baseline, result, held, quotes, controls, args = records_fixture()
        with self.assertRaisesRegex(InputValidationError, "differ from the supplied baseline"):
            candidate_search_from_records(baseline, result, held, quotes, controls, **args,
                coupon_step_records=(step("OLD", effective_date="2026-02-20", fixed_rate=None, spread_bps=0),))


class CouponStepNamedMigrationTests(unittest.TestCase):
    def setUp(self):
        # Optional-interface upgrades operate on a complete model workbook,
        # including its registered asset/capital/output owners. Remove only
        # Coupon Steps to test its independent absent/present migration. A bare
        # workbook now fails required-interface validation before this scope.
        self.book = load_workbook(INPUT_TEMPLATE)
        self.addCleanup(self.book.close)
        del self.book.defined_names[schema.TABLE_RANGE_NAMES["coupon_steps"]]
        del self.book["Coupon Steps"]
        self.book.create_sheet("Existing Inputs")
        self.book.active = len(self.book.sheetnames) - 1
        self.book.active["B2"] = "preserved input"
        self.adapter = NamedWorkbook(self.book)

    def test_absent_optional_table_is_empty_named_and_idempotent(self):
        _ensure_optional_inputs(self.adapter)
        before = (len(self.book.sheetnames), len(self.book.defined_names))
        self.assertEqual(self.adapter.table_records(schema.TABLE_RANGE_NAMES["coupon_steps"],
                                                   schema.TABLE_NAMES["coupon_steps"]), ())
        self.assertEqual(self.book["Coupon Steps"]["D6"].number_format, "0.0000%")
        lists = tuple((str(item.sqref), item.formula1) for item in self.book["Coupon Steps"].data_validations.dataValidation)
        self.assertEqual(lists, (("A6:A1005", '"ASSET,CANDIDATE"'),
                                ("F6:F1005", '"ACTUAL_DATE,PAYMENT_START,RESET_START"')))
        _ensure_optional_inputs(self.adapter)
        self.assertEqual((len(self.book.sheetnames), len(self.book.defined_names)), before)
        self.assertEqual(tuple((str(item.sqref), item.formula1)
            for item in self.book["Coupon Steps"].data_validations.dataValidation), lists)
        self.assertEqual(self.book["Existing Inputs"]["B2"].value, "preserved input")

    def test_native_excel_table_expansion_is_covered_by_the_name_automatically(self):
        _ensure_optional_inputs(self.adapter)
        name, table_name = schema.TABLE_RANGE_NAMES["coupon_steps"], schema.TABLE_NAMES["coupon_steps"]
        sheet = self.book["Coupon Steps"]
        definition = self.book.defined_names[name]
        self.assertEqual(definition.attr_text, f"{table_name}[#All]")
        # Emulate native Excel appending a Table row. There is intentionally no
        # name update: the first and second typed levels must both be consumed.
        for row_number, record in enumerate((step(), step(effective_date="2027-05-20", fixed_rate=".02")), 6):
            for column, field in enumerate(schema.TABLE_COLUMNS["coupon_steps"], 1):
                sheet.cell(row_number, column, record[field])
        sheet.tables[table_name].ref = "A5:F7"
        rows = self.adapter.table_records(name, table_name)
        self.assertEqual(len(rows), 2)
        self.assertEqual(coupon_steps_from_records(rows, (_asset(),))["CONTRACT_LOAN"][0][1].fixed_rate, D(".02"))
        self.adapter.write_table(name, table_name, (step(),))
        self.assertEqual(definition.attr_text, f"{table_name}[#All]")
        self.assertEqual(self.adapter.region(name)[1], (1, 5, 6, 6))

    def test_structured_input_rejects_wrong_table_and_external_names_before_write(self):
        _ensure_optional_inputs(self.adapter)
        name, table_name = schema.TABLE_RANGE_NAMES["coupon_steps"], schema.TABLE_NAMES["coupon_steps"]
        sheet = self.book["Coupon Steps"]
        # A corrupted package can carry two Tables over the same rectangle.
        # Matching coordinates must not authorize the wrong registered owner.
        sheet.add_table(Table(displayName="tbl_wrong", ref="A5:F6", tableColumns=[
            TableColumn(id=index, name=field) for index, field in enumerate(schema.TABLE_COLUMNS["coupon_steps"], 1)]))
        for reference in ("tbl_wrong[#All]", "[other.xlsx]tbl_trident_coupon_steps[#All]",
                          "tbl_trident_coupon_steps[#Data]"):
            with self.subTest(reference=reference):
                self.book.defined_names[name].attr_text = reference
                with self.assertRaises(InputValidationError):
                    self.adapter.table_records(name, table_name)
                with self.assertRaises(InputValidationError):
                    self.adapter.write_table(name, table_name, (step(),))
                self.assertIsNone(sheet["A6"].value)
                self.assertEqual(sheet.tables[table_name].ref, "A5:F6")

    def test_partial_name_or_table_does_not_invent_or_overwrite_interface(self):
        for missing in ("name", "table"):
            with self.subTest(missing=missing):
                book = load_workbook(INPUT_TEMPLATE)
                try:
                    adapter = NamedWorkbook(book)
                    _ensure_optional_inputs(adapter)
                    if missing == "name":
                        del book.defined_names[schema.TABLE_RANGE_NAMES["coupon_steps"]]
                    else:
                        del book["Coupon Steps"].tables[schema.TABLE_NAMES["coupon_steps"]]
                    with self.assertRaisesRegex(InputValidationError, "partial"):
                        _ensure_optional_inputs(adapter)
                finally:
                    book.close()

    def test_shadow_name_bad_schema_and_unowned_sheet_fail(self):
        self.book.create_sheet("Coupon Steps")["A5"] = "user content"
        with self.assertRaisesRegex(InputValidationError, "without its named interface"):
            _ensure_optional_inputs(self.adapter)
        self.assertEqual(self.book["Coupon Steps"]["A5"].value, "user content")
        del self.book["Coupon Steps"]
        _ensure_optional_inputs(self.adapter)
        self.book.active.defined_names.add(DefinedName("TRIDENT_COUPON_STEPS", attr_text="'Existing Inputs'!$B$2"))
        with self.assertRaisesRegex(InputValidationError, "conflicting"):
            _ensure_optional_inputs(self.adapter)
        self.book.active.defined_names.clear()
        sheet = self.book["Coupon Steps"]
        sheet["D5"] = "wrong_rate_field"
        sheet.tables[schema.TABLE_NAMES["coupon_steps"]].tableColumns[3].name = "wrong_rate_field"
        with self.assertRaisesRegex(InputValidationError, "registered schema"):
            _ensure_optional_inputs(self.adapter)

    def test_table_relocation_sheet_rename_and_structured_names_remain_semantic(self):
        _ensure_optional_inputs(self.adapter)
        sheet = self.book["Coupon Steps"]
        sheet.move_range("A5:F6", rows=7, cols=2)
        sheet.title = "Renamed Terms"
        sheet.tables[schema.TABLE_NAMES["coupon_steps"]].ref = "C12:H13"
        self.book.defined_names[schema.TABLE_RANGE_NAMES["coupon_steps"]].attr_text = f"{schema.TABLE_NAMES['coupon_steps']}[#All]"
        _ensure_optional_inputs(self.adapter)
        self.assertEqual(self.book.defined_names[schema.TABLE_RANGE_NAMES["coupon_steps"]].attr_text,
                         f"{schema.TABLE_NAMES['coupon_steps']}[#All]")
        self.adapter.write_table(schema.TABLE_RANGE_NAMES["coupon_steps"], schema.TABLE_NAMES["coupon_steps"], (step(),))
        self.assertEqual(self.adapter.table_records(schema.TABLE_RANGE_NAMES["coupon_steps"],
            schema.TABLE_NAMES["coupon_steps"])[0]["fixed_rate"], "0")
        self.assertEqual(self.adapter.region(schema.TABLE_RANGE_NAMES["coupon_steps"])[1], (3, 12, 8, 13))


class CouponStepWorkbookTests(unittest.TestCase):
    def setUp(self):
        self.folder = tempfile.TemporaryDirectory()
        self.addCleanup(self.folder.cleanup)
        self.path = Path(self.folder.name) / "model.xlsx"
        copy_input_template(self.path)
        book = load_workbook(self.path)
        try:
            adapter = NamedWorkbook(book)
            # Build the test from a frozen input, never from the live output.
            assets, capital, controls, factors, _ = small_inputs(
                legacy_reinvestment_enabled="No", legacy_credit_prepayment_overlay="Off")
            for key, rows in (("assets", assets), ("capital_stack", capital),
                              ("factor_mapping", factors), ("portfolio_limits", ())):
                sheet, (left, top, right, _) = adapter.region(schema.TABLE_RANGE_NAMES[key])
                headers = tuple(sheet.cell(top, col).value for col in range(left, right + 1))
                adapter.write_table(schema.TABLE_RANGE_NAMES[key], schema.TABLE_NAMES[key],
                    tuple({field: row.get(field) for field in headers} for row in rows))
            for key in schema.READ_INPUT_KEYS:
                if key in controls:
                    adapter.write_scalar(schema.SCALAR_NAMES[key], controls[key])
            adapter.write_scalar(schema.SCALAR_NAMES["scenario_enabled"], False)
            book.save(self.path)
        finally:
            book.close()

    def edit_steps(self, rows):
        book = load_workbook(self.path)
        try:
            adapter = NamedWorkbook(book)
            _ensure_optional_inputs(adapter)
            adapter.write_table(schema.TABLE_RANGE_NAMES["coupon_steps"], schema.TABLE_NAMES["coupon_steps"], rows)
            book.save(self.path)
        finally:
            book.close()

    def test_named_input_changes_cashflow_and_preserves_steps_after_atomic_write(self):
        baseline = run_workbook(self.path)
        self.edit_steps((step("HAND", effective_date="2027-02-20", fixed_rate=None, spread_bps=0),))
        changed = run_workbook(self.path)
        self.assertLess(sum(row.cash_interest for row in changed.cashflows.cashflows),
                        sum(row.cash_interest for row in baseline.cashflows.cashflows))
        book = load_workbook(self.path)
        try:
            inputs = read_model_workbook_inputs(NamedWorkbook(book))
            self.assertEqual(inputs.request.cashflow_request.positions[0].terms.coupon_steps[0].spread_bps, D(0))
            self.assertEqual(inputs.coupon_step_records[0]["spread_bps"], 0)
        finally:
            book.close()

    def test_stepped_unknown_candidate_is_rejected_even_search_disabled(self):
        self.edit_steps((step("MISSING", scope="CANDIDATE", fixed_rate=None, spread_bps=0),))
        before = self.path.read_bytes()
        with self.assertRaisesRegex(InputValidationError, "unknown loan_id"):
            run_workbook(self.path)
        self.assertEqual(self.path.read_bytes(), before)

    def test_stepped_candidate_contract_is_checked_even_search_disabled(self):
        book = load_workbook(self.path)
        try:
            adapter = NamedWorkbook(book)
            asset = dict(adapter.table_records(schema.TABLE_RANGE_NAMES["assets"], schema.TABLE_NAMES["assets"])[0],
                         loan_id="NEW_CONTRACT")
            sheet, (left, top, right, _) = adapter.region(schema.TABLE_RANGE_NAMES["candidate_assets"])
            headers = tuple(sheet.cell(top, col).value for col in range(left, right + 1))
            adapter.write_table(schema.TABLE_RANGE_NAMES["candidate_assets"], schema.TABLE_NAMES["candidate_assets"],
                                ({field: asset.get(field) for field in headers},))
            book.save(self.path)
        finally:
            book.close()
        self.edit_steps((step("NEW_CONTRACT", scope="CANDIDATE", effective_date="2027-02-20",
                              fixed_rate=None, spread_bps=0, policy="PAYMENT_START"),))
        before = self.path.read_bytes()
        with self.assertRaises(InputValidationError):
            run_workbook(self.path)
        self.assertEqual(self.path.read_bytes(), before)

    def test_failed_calculation_does_not_publish_absent_optional_interface(self):
        book = load_workbook(self.path)
        try:
            if schema.TABLE_RANGE_NAMES["coupon_steps"] in book.defined_names:
                del book.defined_names[schema.TABLE_RANGE_NAMES["coupon_steps"]]
                del book["Coupon Steps"]
            NamedWorkbook(book).write_scalar(schema.SCALAR_NAMES["legacy_clo_size"], 101)
            book.save(self.path)
        finally:
            book.close()
        before = self.path.read_bytes()
        with self.assertRaisesRegex(InputValidationError, "CLO Size"):
            run_workbook(self.path)
        self.assertEqual(self.path.read_bytes(), before)
