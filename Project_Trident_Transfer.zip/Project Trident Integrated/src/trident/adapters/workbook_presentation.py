"""One semantic Excel presentation policy for runtime and template publishing.

Financial code owns values and names; this module owns visible formatting and
navigation. Face/par display precision is deliberately separate from monetary
posting. Consolidated inputs use horizontal bands so either native Table can
grow indefinitely without colliding with the other table's rows.
"""

from copy import copy, deepcopy
from dataclasses import dataclass
import re
from xml.etree import ElementTree

from openpyxl.utils import get_column_letter, range_boundaries

from . import excel_schema as schema


POLICY_VERSION = '2'
FONT_NAME = 'Arial'
INPUT_TAB_COLOR = '1F4E78'
OUTPUT_TAB_COLOR = '548235'
FRONT_SHEETS = ('Guidance',)
FACE_NUMBER_FORMAT = '#,##0'

# Use an explicit semantic allowlist. A broad "principal"/"balance" regex
# would also round coupons, recovery cash, fee claims and physical accounts.
FACE_COLUMNS = frozenset({
    'initial_par', 'current_par', 'nominal_amount', 'opening_balance', 'closing_balance',
    'initial_collateral_par', 'maximum_par', 'maximum_trade_par', 'gross_trade_par',
    'beginning_par', 'ending_par', 'opening_par', 'par', 'acquired_par',
    # Detailed contract output uses the source vocabulary for the same face.
    # PIK coupons and principal cash retain cent display even when face does not.
    'beginning_notional', 'ending_notional',
    'settled_par', 'performing_par', 'defaulted_par', 'committed_buy_par',
    'committed_sell_par', 'trade_date_par', 'available_to_sell',
    'opening_collateral_par', 'closing_collateral_par', 'opening_debt_par', 'closing_debt_par',
    'opening_performing_par', 'closing_performing_par', 'opening_defaulted_par', 'closing_defaulted_par',
    'performing_par_before', 'performing_par_after', 'defaulted_par_before', 'defaulted_par_after',
    'opening_synthetic_defaulted_par', 'closing_synthetic_defaulted_par',
    'initial_pool_par', 'initial_performing_par', 'final_performing_par', 'final_defaulted_par',
    'initial_loan_par', 'loan_par_at_default', 'default_par', 'remaining_par',
    'performing_par_reduction', 'ending_performing_par', 'defaulted_par_memo',
    'newly_defaulted_par', 'long_dated_par', 'collateral_sale_par', 'reinvestment_par_acquired',
    'collateral_non_cash_par_change', 'non_cash_par_change', 'par_reduction', 'settled_par_change',
})
FACE_SCALARS = frozenset({
    'legacy_clo_size', 'legacy_opening_collateral_par',
    'legacy_simplified_pool_opening_performing_par', 'optimizer_target_par',
    'optimizer_maximum_trade_par', 'result_collateral_par', 'result_final_debt_par',
})
FACE_METRIC_NAMES = frozenset({'collateral_par', 'debt_par', 'ending_par', 'TOTAL_PAR',
                             'PERFORMING_PAR', 'DEFAULTED_PAR'})


@dataclass(frozen=True)
class HorizontalInputGroup:
    """Layout-only target; table identities and financial schemas are unchanged."""
    sheet_title: str
    table_keys: tuple[str, ...]


HORIZONTAL_INPUT_GROUPS = (
    HorizontalInputGroup('Seasoned Inputs', ('seasoned_positions', 'opening_fixings')),
    HorizontalInputGroup('Proceeds Inputs', ('principal_accrued_balances', 'coupon_proceeds_allocations')),
    HorizontalInputGroup('Opening Balances', ('clo_opening_accounts', 'clo_opening_claims')),
    HorizontalInputGroup('Credit Inputs', ('credit_events', 'recovery_schedule')),
    HorizontalInputGroup('Expense Inputs', ('closing_costs', 'recurring_expenses')),
)


def presentation_payload() -> dict:
    """Expose the same policy to authoring tools; no JavaScript rule matrix."""
    return dict(policy_version=POLICY_VERSION, font_name=FONT_NAME, input_tab_color=INPUT_TAB_COLOR,
        output_tab_color=OUTPUT_TAB_COLOR, front_sheets=list(FRONT_SHEETS),
        horizontal_alignment='center', vertical_alignment='center',
        face_number_format=FACE_NUMBER_FORMAT, face_columns=sorted(FACE_COLUMNS),
        face_scalars=sorted(FACE_SCALARS),
        face_metric_names=sorted(FACE_METRIC_NAMES),
        horizontal_groups=[dict(sheet_title=item.sheet_title, table_keys=list(item.table_keys))
                           for item in HORIZONTAL_INPUT_GROUPS])


def _sheet_reference(title: str):
    """Find a direct sheet token, including Excel's escaped quoted titles."""
    return re.compile(r"(?:'" + re.escape(title.replace("'", "''")) + r"'|(?<![\w])" + re.escape(title) + r")!", re.I)


THREE_DIMENSIONAL_REFERENCE = re.compile(
    r"(?:'(?:[^']|'')*:(?:[^']|'')*'|(?<![\w])[\w.\[\]]+:[\w.\[\]]+)!", re.I)


def _direct_reference_reasons(book, titles) -> tuple[dict[str, str], str | None]:
    """Index references once, examining instantiated cells rather than rectangles.

    An output sheet may contain hundreds of thousands of contract cells, while
    one distant formatted cell can make ``iter_rows()`` create a huge empty
    rectangle. The relocation preflight reads formulas, names and object references.
    Openpyxl's sparse cell store supplies those without materialising blanks;
    the small list of candidate sheet tokens is checked only on reference cells.
    """
    patterns = {title: _sheet_reference(title) for title in titles}
    reasons = {}
    retained_order_reason = None

    def retain_layout(reason):
        nonlocal retained_order_reason
        for title in patterns:
            reasons.setdefault(title, reason)
        # Unsupported references may depend on physical sheet positions too.
        # Preserving source pages while moving them is insufficient for 3D,
        # dynamic INDIRECT and opaque formula/reference objects.
        if retained_order_reason is None:
            retained_order_reason = reason

    def inspect_three_dimensional(values):
        if any(THREE_DIMENSIONAL_REFERENCE.search(str(value or '')) for value in values):
            # Excel 3D references depend on physical sheet order, including
            # sheets between the named endpoints. Retaining every candidate
            # source is safer than attempting interval/reference translation.
            retain_layout('Workbook contains a 3D sheet interval reference; original layout retained')

    def inspect_dynamic(values):
        if any(re.search(r'\b(?:_xlfn\.)?(?:INDIRECT|SHEETS?)\s*\(', str(value or ''), re.I)
               for value in values):
            retain_layout('Workbook contains dynamic or sheet-order formulas requiring a separate relocation review')

    def inspect_references(values, reason):
        values = tuple(values)
        inspect_three_dimensional(values)
        inspect_dynamic(values)
        for title, token in patterns.items():
            if any(token.search(str(value or '')) for value in values):
                reasons.setdefault(title, reason)

    def inspect_object(item, kind):
        """Read serialized formulas, without translating foreign Excel objects.

        Chart series and conditional rules can store references deep inside
        their native XML structures. Serializing their supported object model
        exposes every text/attribute reference; unknown serializers cause a
        conservative retained layout rather than deletion of a possible source.
        """
        try:
            node = item.to_tree()
            values = tuple(value for child in node.iter()
                           for value in (child.text, *child.attrib.values()) if value is not None)
        except (AttributeError, TypeError, ValueError, NotImplementedError):
            retain_layout(f'Foreign {kind} cannot be inspected safely; original layout retained')
            return
        inspect_references(values, f'Workbook contains a foreign {kind} reference to the source sheet')

    global_names = tuple(name.attr_text for name in book.defined_names.values())
    inspect_three_dimensional(global_names)
    inspect_dynamic(global_names)
    for sheet in book:
        # Names scoped to another worksheet can still point into a source.
        # Workbook-global names alone do not establish relocation safety.
        for definition in sheet.defined_names.values():
            inspect_three_dimensional((definition.attr_text,))
            inspect_dynamic((definition.attr_text,))
            for title, token in patterns.items():
                if token.search(definition.attr_text or ''):
                    reasons[title] = 'Workbook contains a foreign sheet-local named reference to the source sheet'
        for rule in sheet.data_validations.dataValidation:
            inspect_references((rule.formula1, rule.formula2),
                               'Workbook contains a foreign data validation reference to the source sheet')
        for table in sheet.tables.values():
            inspect_object(table, 'table formula metadata')
        for region in sheet.conditional_formatting:
            for rule in sheet.conditional_formatting[region]:
                inspect_object(rule, 'conditional formatting')
        # Combined charts retain additional chart instances in _charts; their
        # sources must be inspected too. Identity tracking bounds self-links.
        pending, seen = list(sheet._charts), set()
        while pending:
            chart = pending.pop()
            if id(chart) in seen:
                continue
            seen.add(id(chart))
            inspect_object(chart, 'chart')
            try:
                pending.extend(chart._charts)
            except (AttributeError, TypeError):
                retain_layout('Foreign combined chart cannot be inspected safely; original layout retained')
        for cell in tuple(sheet._cells.values()):
            formula = None
            if cell.data_type == 'f':
                formula = cell.value if isinstance(cell.value, str) else getattr(cell.value, 'text', None)
                if not isinstance(formula, str) or not formula.strip():
                    retain_layout('Workbook contains an opaque formula object requiring a separate relocation review')
                    formula = None
            hyperlink = cell.hyperlink
            if formula is None and hyperlink is None:
                continue
            if formula is not None:
                inspect_three_dimensional((formula,))
                inspect_dynamic((formula,))
            for title, token in patterns.items():
                if formula is not None and token.search(formula):
                    reasons[title] = 'Workbook contains a direct formula reference to the source sheet'
                elif title not in reasons and hyperlink is not None and any(
                        token.search(str(value or '')) for value in (hyperlink.target, hyperlink.location)):
                    reasons[title] = 'Workbook contains an internal hyperlink to the source sheet'
    return reasons, retained_order_reason


def _consolidation_reason(adapter, group, sources, reference_reasons) -> str | None:
    """Preflight preservation before moving any cells or deleting any sheet.

    Unsupported objects/references are a reason to retain the original layout,
    rather than guess how to rewrite a user's workbook. Model values stay usable
    and the returned report makes the skipped presentation action explicit.
    """
    book = adapter.workbook
    if group.sheet_title in book.sheetnames:
        return 'Target sheet already exists with an incomplete or different layout'
    allowed_names = {schema.TABLE_RANGE_NAMES[key] for key in group.table_keys}
    for key, sheet, bounds, table in sources:
        left, top, right, bottom = bounds
        if left != 1 or top != 5:
            return 'Custom table placement retained; automatic bands require the standard header row'
        if len(sheet.tables) != 1 or table.displayName != schema.TABLE_NAMES[key]:
            return 'Source contains additional or unregistered tables'
        if sheet.defined_names:
            return 'Source contains local names that require a separate relocation review'
        if sheet.sheet_state != 'visible' or sheet.protection.sheet:
            return 'Source is hidden or protected'
        if sheet._charts or sheet._images or len(sheet.conditional_formatting):
            return 'Source contains charts, drawings or conditional formatting'
        if table.totalsRowCount or table.totalsRowShown or table.sortState:
            return 'Source contains totals or custom table sorting metadata'
        if any(column.calculatedColumnFormula or column.totalsRowFormula for column in table.tableColumns):
            return 'Source contains table formulas'
        if any(dim.hidden for dim in sheet.row_dimensions.values()) or any(dim.hidden for dim in sheet.column_dimensions.values()):
            return 'Source contains hidden rows or columns'
        if any(dim.min and dim.max and dim.max > dim.min for dim in sheet.column_dimensions.values()):
            return 'Source contains grouped column dimensions requiring a separate relocation review'
        if any(range_boundaries(str(item))[2] > right for item in sheet.merged_cells.ranges):
            return 'Source merge extends beyond its independent table band'
        for cell in tuple(sheet._cells.values()):
            if cell.data_type == 'f':
                return 'Source contains formulas requiring an explicit relocation review'
            if (not left <= cell.column <= right or cell.row >= top and cell.row > bottom) and (
                    cell.value is not None or cell.comment is not None or cell.hyperlink is not None):
                return 'Source contains user content outside its registered table'
        for rule in sheet.data_validations.dataValidation:
            # Literal dropdown lists are position-independent. Relative/formula
            # validation cannot be copied to another band without translating
            # its references, which this bounded layout policy does not infer.
            if rule.formula2 or rule.formula1 and not (str(rule.formula1).startswith('"') and str(rule.formula1).endswith('"')):
                return 'Source contains nonliteral data validation'
            if any(item.min_col < left or item.max_col > right for item in rule.sqref.ranges):
                return 'Source validation extends beyond its table band'
        token = _sheet_reference(sheet.title)
        if any(name.name not in allowed_names and token.search(name.attr_text or '')
               for name in book.defined_names.values()):
            return 'Source contains a foreign named reference'
        if sheet.title in reference_reasons:
            return reference_reasons[sheet.title]
    return None


def consolidate_inputs(adapter, *, reference_index=None) -> tuple[dict, ...]:
    """Move only safe complete input pairs; return an explicit per-group report."""
    book, reports = adapter.workbook, []
    reference_reasons = None if reference_index is None else reference_index[0]
    for group in HORIZONTAL_INPUT_GROUPS:
        if any(schema.TABLE_RANGE_NAMES[key] not in book.defined_names for key in group.table_keys):
            reports.append(dict(sheet=group.sheet_title, status='NOT_PRESENT', reason='Group tables are not all registered'))
            continue
        sources = []
        for key in group.table_keys:
            sheet, bounds, table = adapter._registered_table_region(schema.TABLE_RANGE_NAMES[key], schema.TABLE_NAMES[key])
            sources.append((key, sheet, bounds, table))
        if all(sheet.title == group.sheet_title for _, sheet, _, _ in sources):
            bounds = [item[2] for item in sources]
            horizontal = all(item[1] == 5 for item in bounds) and all(
                left[2] < right[0] or right[2] < left[0]
                for index, left in enumerate(bounds) for right in bounds[index + 1:])
            reports.append(dict(sheet=group.sheet_title, status='ALREADY_GROUPED' if horizontal else 'SKIPPED',
                reason='Independent horizontal tables retained' if horizontal else 'Custom co-located layout retained'))
            continue
        if len({sheet.title for _, sheet, _, _ in sources}) != len(sources):
            reports.append(dict(sheet=group.sheet_title, status='SKIPPED', reason='Custom co-located layout retained'))
            continue
        if reference_reasons is None:
            # Standalone consolidation scans once for all potential sources.
            # The full presentation path supplies its single shared index.
            titles = {adapter.region(schema.TABLE_RANGE_NAMES[key])[0].title
                      for item in HORIZONTAL_INPUT_GROUPS for key in item.table_keys
                      if schema.TABLE_RANGE_NAMES[key] in book.defined_names}
            reference_reasons = _direct_reference_reasons(book, titles)[0]
        reason = _consolidation_reason(adapter, group, sources, reference_reasons)
        if reason:
            reports.append(dict(sheet=group.sheet_title, status='SKIPPED', reason=reason))
            continue
        target = book.create_sheet(group.sheet_title,
            index=min(book.sheetnames.index(source.title) for _, source, _, _ in sources))
        target.sheet_view.showGridLines = False
        target.freeze_panes = 'C6'
        offset = 0
        for key, source, bounds, table in sources:
            _, top, right, bottom = bounds
            for cell in tuple(source._cells.values()):
                if cell.column > right:
                    continue
                destination = target.cell(cell.row, cell.column + offset)
                if cell.value is not None:
                    destination.value = cell.value
                    # Literal identifiers or legal evidence may begin with '='.
                    # Preserve the saved cell type instead of turning that text
                    # into a new formula during the layout-only copy.
                    destination.data_type = cell.data_type
                if cell.has_style:
                    destination._style = copy(cell._style)
                if cell.comment is not None:
                    destination.comment = copy(cell.comment)
                if cell.hyperlink is not None:
                    destination.hyperlink = copy(cell.hyperlink)
            for column, dimension in source.column_dimensions.items():
                # ColumnDimension.min may still be zero until XML serialization;
                # use its actual index rather than trusting serialized bounds.
                from openpyxl.utils import column_index_from_string
                shifted = get_column_letter(column_index_from_string(column) + offset)
                copied = copy(dimension)
                copied.index, copied.min, copied.max = shifted, column_index_from_string(shifted), column_index_from_string(shifted)
                target.column_dimensions[shifted] = copied
            for number, dimension in source.row_dimensions.items():
                if dimension.height is not None:
                    target.row_dimensions[number].height = max(target.row_dimensions[number].height or 0, dimension.height)
            for merged in source.merged_cells.ranges:
                shifted = copy(merged)
                shifted.shift(col_shift=offset)
                target.merge_cells(str(shifted))
            for rule in source.data_validations.dataValidation:
                moved = deepcopy(rule)
                shifted_ranges = []
                for item in moved.sqref.ranges:
                    item = copy(item)
                    item.shift(col_shift=offset)
                    shifted_ranges.append(str(item))
                moved.sqref = ' '.join(shifted_ranges)
                target.add_data_validation(moved)
            moved_table = deepcopy(table)
            reference = f'{get_column_letter(1 + offset)}{top}:{get_column_letter(right + offset)}{bottom}'
            moved_table.ref = reference
            if moved_table.autoFilter is not None:
                moved_table.autoFilter.ref = reference
            del source.tables[table.displayName]
            target.add_table(moved_table)
            book.defined_names[schema.TABLE_RANGE_NAMES[key]].attr_text = table.displayName + '[#All]'
            offset += right + 2  # Two permanently blank columns between bands.
        for _, source, _, _ in sources:
            book.remove(source)
        reports.append(dict(sheet=group.sheet_title, status='GROUPED',
            source_sheets=tuple(source.title for _, source, _, _ in sources),
            reason='Horizontal bands; table row counts remain independent'))
    return tuple(reports)


def _center(cell, *, wrap=False) -> None:
    """Preserve every other alignment component and avoid repeat style copies."""
    if cell.alignment.horizontal == cell.alignment.vertical == 'center' and (not wrap or cell.alignment.wrap_text):
        return
    style = copy(cell.alignment)
    style.horizontal = style.vertical = 'center'
    if wrap:
        style.wrap_text = True
    cell.alignment = style


def apply_workbook_presentation(adapter) -> dict:
    """Apply the current policy without altering any model value or formula.

    Mixed selector/result pages belong to the input group because users edit
    their switches there. Guidance stays first; unknown user pages are retained
    after registered outputs. Market Data values, geometry and all number
    formats stay untouched while its actual data cells become centered.
    """
    book = adapter.workbook
    _normalize_fonts(book)
    _contract_choices(adapter)
    _result_currency_labels(adapter)
    active_title = None if book.active is None else book.active.title
    titles = {adapter.region(schema.TABLE_RANGE_NAMES[key])[0].title
              for group in HORIZONTAL_INPUT_GROUPS for key in group.table_keys
              if schema.TABLE_RANGE_NAMES[key] in book.defined_names}
    reference_index = _direct_reference_reasons(book, titles)
    consolidation = consolidate_inputs(adapter, reference_index=reference_index)
    roles, table_regions = {}, []
    for key in (*schema.INPUT_TABLE_KEYS, *schema.OUTPUT_TABLE_KEYS):
        name = schema.TABLE_RANGE_NAMES[key]
        if name not in book.defined_names:
            continue
        sheet, bounds = adapter.region(name)
        role = 'input' if key in schema.INPUT_TABLE_KEYS else 'output'
        roles.setdefault(sheet.title, set()).add(role)
        table_regions.append((key, sheet, bounds))
    for key in (*schema.INPUT_KEYS, *schema.OUTPUT_KEYS):
        if schema.SCALAR_NAMES[key] not in book.defined_names:
            continue
        sheet, (left, top, right, bottom) = adapter.region(schema.SCALAR_NAMES[key])
        roles.setdefault(sheet.title, set()).add('input' if key in schema.INPUT_KEYS else 'output')
        for row in sheet.iter_rows(min_row=top, max_row=bottom, min_col=left, max_col=right):
            for cell in row:
                _center(cell)
                if key in FACE_SCALARS and sheet.title != 'Market Data':
                    cell.number_format = FACE_NUMBER_FORMAT
    for key, sheet, (left, top, right, bottom) in table_regions:
        headers = {sheet.cell(top, column).value: column for column in range(left, right + 1)}
        for row in sheet.iter_rows(min_row=top, max_row=bottom, min_col=left, max_col=right):
            for cell in row:
                _center(cell, wrap=cell.row == top or isinstance(cell.value, str))
        if sheet.title != 'Market Data':
            for field, column in headers.items():
                if field in FACE_COLUMNS:
                    for row in range(top + 1, bottom + 1):
                        sheet.cell(row, column).number_format = FACE_NUMBER_FORMAT
            # Summary tables transport several financial units through a value
            # column. Use the semantic row name, never a blanket value format.
            if 'name' in headers and 'value' in headers:
                for row in range(top + 1, bottom + 1):
                    if sheet.cell(row, headers['name']).value in FACE_METRIC_NAMES:
                        sheet.cell(row, headers['value']).number_format = FACE_NUMBER_FORMAT
    for block in schema.CURVE_BLOCKS:
        if block.range_name not in book.defined_names:
            continue
        sheet, bounds = adapter.region(block.range_name)
        roles.setdefault(sheet.title, set()).add('input')
        left, top, right, bottom = bounds
        for row in sheet.iter_rows(min_row=top, max_row=bottom, min_col=left, max_col=right):
            for cell in row:
                _center(cell)
    if 'Market Data' in book.sheetnames:
        sheet = book['Market Data']
        roles.setdefault(sheet.title, set()).add('input')
        for row in sheet.iter_rows(min_row=1, max_row=245, min_col=1, max_col=11):
            for cell in row:
                _center(cell)
    inputs, outputs, others = [], [], []
    for sheet in book:
        if sheet.title in FRONT_SHEETS:
            continue
        role = roles.get(sheet.title, set())
        if 'input' in role:
            inputs.append(sheet.title)
            sheet.sheet_properties.tabColor = INPUT_TAB_COLOR
        elif 'output' in role:
            outputs.append(sheet.title)
            sheet.sheet_properties.tabColor = OUTPUT_TAB_COLOR
        else:
            others.append(sheet.title)
    order = [name for name in FRONT_SHEETS if name in book.sheetnames] + inputs + outputs + others
    if reference_index[1] is None:
        for index, title in enumerate(order):
            sheet = book[title]
            book.move_sheet(sheet, offset=index - book.sheetnames.index(title))
    if active_title not in book.sheetnames:
        active_title = next((item['sheet'] for item in consolidation
                            if active_title in item.get('source_sheets', ())), None)
    if active_title is not None:
        book.active = book.sheetnames.index(active_title)
    return dict(policy_version=POLICY_VERSION, consolidation=consolidation,
                input_sheets=tuple(inputs), output_sheets=tuple(outputs), retained_other_sheets=tuple(others),
                sheet_order_retained=reference_index[1] is not None, sheet_order_reason=reference_index[1])


def _normalize_fonts(book) -> None:
    """Apply Arial to cells, defaults and theme without erasing other styles.

    Excel's default font also controls newly inserted rows/cells. Updating only
    current cells leaves new input rows in a different font. The indexed font
    collection is normalized in place, preserving every font ID and each size,
    weight, color and decoration. This is O(number of fonts), not O(cells).
    Openpyxl's index cache must be rebuilt after changing indexed values; this
    narrow use of its collection API is covered by save/reload tests.
    """
    from openpyxl.utils.indexed_list import IndexedList
    fonts = []
    for existing in book._fonts:
        updated = copy(existing)
        updated.name, updated.scheme = FONT_NAME, None
        fonts.append(updated)
    book._fonts = IndexedList(fonts)
    for named_style in book._named_styles:
        updated = copy(named_style.font)
        updated.name, updated.scheme = FONT_NAME, None
        named_style.font = updated
    # Theme fonts govern theme-only text and later Excel insertions. Explicit
    # Latin/East Asian/complex-script faces keep one font policy throughout.
    if book.loaded_theme:
        namespace = 'http://schemas.openxmlformats.org/drawingml/2006/main'
        theme = ElementTree.fromstring(book.loaded_theme)
        scheme = theme.find(f'{{{namespace}}}themeElements/{{{namespace}}}fontScheme')
        if scheme is not None:
            for node in scheme.iter():
                if node.tag.rsplit('}', 1)[-1] in {'latin', 'ea', 'cs', 'font'}:
                    node.set('typeface', FONT_NAME)
            ElementTree.register_namespace('a', namespace)
            book.loaded_theme = ElementTree.tostring(theme, encoding='utf-8', xml_declaration=True)


def _contract_choices(adapter) -> None:
    """Keep supported convention menus aligned with the typed input surface.

    Names and semantic headers resolve every target. New optional columns need
    usable dropdowns in transferred workbooks as well as fresh templates; the
    helper is idempotent and preserves unrelated validation rules. Enabling a
    currency choice does not authorize FX or non-EUR CLO calculations.
    """
    from openpyxl.worksheet.datavalidation import DataValidation
    from trident.conventions.calendar import CalendarName
    choices = {
        'interest_mode': ('CASH', 'PIK', 'MIXED'),
        'currency': ('EUR', 'USD', 'GBP'),
        'holiday_calendar': tuple(item.value for item in CalendarName),
        'rate_index': ('EURIBOR_1M', 'EURIBOR_3M', 'EURIBOR_6M', 'ESTR', 'SOFR', 'SONIA'),
    }
    for key in ('assets', 'candidate_assets'):
        name = schema.TABLE_RANGE_NAMES[key]
        if name not in adapter.workbook.defined_names:
            continue
        sheet, (left, top, right, bottom) = adapter.region(name)
        headers = {sheet.cell(top, column).value: column for column in range(left, right+1)}
        for field, values in choices.items():
            if field not in headers:
                continue
            col = get_column_letter(headers[field])
            reference = f'{col}{top+1}:{col}{max(bottom, top+500)}'
            existing = next((rule for rule in sheet.data_validations.dataValidation
                             if str(rule.sqref)==reference and rule.type=='list'), None)
            if existing is None:
                existing = DataValidation(type='list', allow_blank=True, showErrorMessage=True)
                existing.error = 'Choose a supported contractual convention; see User Guide.'
                existing.add(reference)
                sheet.add_data_validation(existing)
            existing.formula1 = '"'+','.join(values)+'"'
    name = schema.SCALAR_NAMES['legacy_base_currency']
    if name in adapter.workbook.defined_names:
        sheet, (left, top, _, _) = adapter.region(name)
        coordinate = sheet.cell(top, left).coordinate
        rules = [rule for rule in sheet.data_validations.dataValidation if coordinate in rule and rule.type=='list']
        if not rules:
            rule=DataValidation(type='list',allow_blank=False,showErrorMessage=True)
            rule.add(coordinate)
            sheet.add_data_validation(rule)
            rules=[rule]
        for rule in rules:
            rule.formula1='"EUR,USD,GBP"'


def _result_currency_labels(adapter) -> None:
    """Keep shared summary labels valid for all standalone base currencies.

    The semantic name locates each result, and the adjacent label is only
    template presentation metadata. A transferred EUR workbook can also run a
    standalone USD/GBP loan; a fixed EUR label would misstate the result unit.
    Replace only the owned labels, retaining a user's customised wording.
    """
    labels = {
        'result_collateral_par': 'Collateral par',
        'result_total_principal': 'Contractual principal',
        'result_total_interest': 'Contractual interest',
        'result_debt_proceeds': 'Debt proceeds',
        'result_equity_funding': 'Equity funding',
        'result_first_payment_interest': 'First-date cash interest',
    }
    for key, label in labels.items():
        name = schema.SCALAR_NAMES[key]
        if name not in adapter.workbook.defined_names:
            continue
        sheet, (left, top, _, _) = adapter.region(name)
        if left <= 1:
            continue
        cell = sheet.cell(top, left-1)
        if cell.value in {f'{label} (EUR)', f'{label} (base currency)'}:
            cell.value = f'{label} (base currency)'
