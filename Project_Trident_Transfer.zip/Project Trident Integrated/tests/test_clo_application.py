"""CSV-to-typed-CLO integration, hand-ledger controls and adapter boundaries.

Fixture terms are synthetic, with no trades and no agency factor mapping. The
independent return residual uses float discounting instead of the model's
Decimal XNPV implementation; expected first distributions are hand controls.
"""

import csv
import json
import unittest
from dataclasses import replace
from datetime import date
from decimal import Decimal, Inexact, localcontext
from math import fsum
from pathlib import Path

from trident.adapters.model_records import factor_mapping_from_records, model_request_from_records
from trident.analysis import LimitStatus, MetricStatus, ReturnStatus
from trident.application.clo_services import TridentModelService
from trident.clo.models import ProjectionStatus
from trident.conventions import DayCount
from trident.domain.models import CouponType
from trident.market import FlatRateProvider


D = Decimal
EXAMPLE = Path(__file__).resolve().parents[1] / "data/examples/hybrid_500m"


def _rows(name: str) -> tuple[dict[str, object], ...]:
    with (EXAMPLE / name).open(encoding="utf-8", newline="") as stream:
        return tuple(dict(row) for row in csv.DictReader(stream))


def _input_data():
    """Map design fixture explicitly; do not imply a production JSON schema."""
    with (EXAMPLE / "deal_terms.json").open(encoding="utf-8") as stream:
        terms = json.load(stream)
    assets, capital = _rows("assets.csv"), _rows("capital_stack.csv")
    for row in capital:
        if row["instrument_type"] == "DEBT":
            class_id = row["class_id"]
            row["oc_minimum"] = terms["coverage"]["oc_minimum_fraction_by_class"][class_id]
            row["ic_minimum"] = terms["coverage"]["ic_minimum_fraction_by_class"][class_id]
    schedule = terms["schedule_conventions"]
    fees = terms["recurring_fees"]
    controls = {
        "mode": "CLO_BASELINE",
        "upfront_fees": terms["closing_sources_and_uses"]["upfront_fees"],
        "cash_reserve": terms["closing_sources_and_uses"]["cash_reserve_funding"],
        "legal_final_date": terms["capital_stack"]["note_legal_maturity_date_unadjusted"],
        "clo_frequency_months": schedule["coupon_frequency_months"],
        "senior_management_fee_bps": fees["senior_management_fee_bps"],
        "subordinated_management_fee_bps": fees["subordinated_management_fee_bps"],
        "annual_senior_expenses": fees["fixed_expenses_eur_per_year"],
        "clo_business_day_convention": schedule["business_day_convention"],
        "clo_accrual_date_basis": schedule["accrual_date_basis"],
        "clo_fixing_lag_business_days": schedule["fixing_lag_target_business_days"],
        "clo_end_of_month": False,
        "clo_stub_convention": "SHORT_LAST",
        "collection_cutoff_business_days": 0,
        "reinvestment_strategy": "NO_TRADES",
        "reinvestment_end_date": terms["trading_scope"]["reinvestment_end_date_exclusive"],
    }
    factors = tuple({
        "system": row["test_factor_system"], "version": row["fixture_version"],
        "is_synthetic": True, "bucket": row["test_factor_bucket"], "factor": row["synthetic_test_factor"],
    } for row in _rows("test_factor_mapping.csv"))
    gates = terms["quality_and_concentration_gates"]
    limits = tuple({"limit_id": name, "metric": metric, "threshold": threshold, "direction": direction,
                    "enabled": True, "phases": "CLOSING,REINVESTMENT"}
        for name, metric, threshold, direction in (
            ("INFRA", "concentration:asset_class:INFRA", gates["infra_minimum_fraction"], "MINIMUM"),
            ("BSL", "concentration:asset_class:BSL", gates["bsl_maximum_fraction"], "MAXIMUM"),
            ("OBLIGOR", "LARGEST_OBLIGOR_FRACTION", gates["single_obligor_maximum_fraction"], "MAXIMUM"),
            ("COUNTRY", "LARGEST_COUNTRY_FRACTION", gates["single_country_maximum_fraction"], "MAXIMUM"),
            ("SECTOR", "LARGEST_SECTOR_FRACTION", gates["single_sector_maximum_fraction"], "MAXIMUM"),
            ("TEST_FACTOR", "TEST_FACTOR_AVERAGE", gates["combined_synthetic_test_factor_maximum"], "MAXIMUM"),
        ))
    index = D(terms["market_data"]["index_rate_fraction"])
    provider = FlatRateProvider({f"EURIBOR_{tenor}M": index for tenor in (1, 3, 6)})
    return assets, capital, controls, factors, limits, provider


def _request(*, mode="CLO_BASELINE"):
    assets, capital, controls, factors, limits, provider = _input_data()
    controls["mode"] = mode
    return model_request_from_records(assets, capital, provider, controls=controls,
        factors=factors, limits=limits, provenance="SYNTHETIC_FLAT_RATE_NOT_LIVE_DATA")


class CloApplicationTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.request = _request()
        cls.result = TridentModelService().run(cls.request)

    def test_full_fixture_cashflow_funding_and_terminal_state(self):
        result = self.result
        self.assertEqual(result.cashflows.asset_count, 150)
        self.assertEqual(len(result.cashflows.cashflows), 4316)
        self.assertEqual(result.cashflows.funding.collateral_par, D("500000000"))
        self.assertEqual(result.cashflows.funding.debt_proceeds, D("449275000"))
        self.assertEqual(result.cashflows.funding.equity_cash_funding, D("53475000"))
        self.assertEqual(result.clo.status, ProjectionStatus.COMPLETED)
        self.assertTrue(result.clo.terminal_value_available)
        self.assertEqual(len(result.clo.periods), 40)
        for label in ("final_collateral_par", "final_debt_par", "final_interest_cash", "final_principal_cash",
                      "final_pending_interest_cash", "final_pending_principal_cash", "final_reserve",
                      "final_senior_claims", "final_note_coupon_arrears", "final_subordinated_fee_arrears"):
            self.assertEqual(getattr(result.clo, label), D(0), label)
        self.assertTrue(all(period.cash_conservation_residual == 0 for period in result.clo.periods))

    def test_first_distribution_matches_independent_hand_ledger(self):
        # Per-loan posted7670139, expenses77260.27, seniorfee195833.33,
        # A-E coupons5110597.22, subordinatefee391666.67 ->1894781.51.
        first = self.result.clo.periods[0]
        self.assertEqual(first.payment_date, date(2027, 2, 22))
        self.assertEqual(first.equity_from_interest, D("1894781.51"))
        self.assertEqual(first.equity_from_principal, D(0))
        self.assertEqual(first.equity_from_reserve, D(0))
        self.assertEqual(first.closing_collateral_par, D("493000000"))
        self.assertEqual(first.closing_debt_par, D("443000000"))
        self.assertFalse(first.coverage_failed)
        first_distributions = [row.amount for row in self.result.equity_cashflows if row.payment_date == first.payment_date]
        self.assertEqual(fsum(float(amount) for amount in first_distributions), 1_894_781.51)

    def test_portfolio_metrics_keep_agency_warf_unavailable(self):
        opening = self.result.opening_portfolio
        self.assertEqual(opening.total_par, D("500000000"))
        warf = opening.metric("WARF")
        self.assertEqual(warf.status, MetricStatus.UNAVAILABLE)
        self.assertIsNone(warf.value)
        self.assertEqual(opening.metric("TEST_FACTOR_AVERAGE").value, D(2120))
        self.assertEqual(opening.metric("WAS_BPS").value, D("337.5"))
        self.assertEqual(opening.metric("RATING_FACTOR_COVERAGE_FRACTION").value, D(0))
        self.assertTrue(all(limit.status is LimitStatus.PASS for limit in opening.limits))
        self.assertEqual(len(self.result.portfolio_snapshots), 40)
        for portfolio, period in zip(self.result.portfolio_snapshots, self.result.clo.periods, strict=True):
            self.assertEqual(portfolio.total_par, period.closing_collateral_par)
            self.assertIsNone(portfolio.metric("WARF").value)
        self.assertEqual(self.result.portfolio_snapshots[-1].total_par, D(0))
        self.assertTrue(all(limit.status is LimitStatus.NOT_APPLICABLE for limit in self.result.portfolio_snapshots[-1].limits))

    def test_investor_irr_has_actual_closing_funding_and_independent_residual(self):
        cashflows = self.result.equity_cashflows
        self.assertEqual(cashflows[0].payment_date, date(2026, 11, 20))
        self.assertEqual(cashflows[0].amount, D("-53475000"))
        self.assertEqual(self.result.equity_irr.status, ReturnStatus.AVAILABLE)
        self.assertEqual(self.result.equity_moic.status, ReturnStatus.AVAILABLE)
        rate = float(self.result.equity_irr.value)
        origin = cashflows[0].payment_date
        residual = fsum(float(row.amount) / (1 + rate) ** ((row.payment_date - origin).days / 365) for row in cashflows)
        self.assertLess(abs(residual), .001)
        self.assertLess(abs(float(self.result.equity_irr.residual)), .001)

    def test_full_model_is_independent_of_callers_decimal_context(self):
        with localcontext() as caller:
            caller.prec = 6
            caller.traps[Inexact] = True
            request = _request()
            actual = TridentModelService().run(request)
        self.assertEqual(request.notes, self.request.notes)
        self.assertEqual(request.cashflow_request.issues, self.request.cashflow_request.issues)
        self.assertEqual(actual.cashflows.funding, self.result.cashflows.funding)
        self.assertEqual(actual.opening_portfolio, self.result.opening_portfolio)
        self.assertEqual(actual.clo, self.result.clo)
        self.assertEqual(actual.equity_irr, self.result.equity_irr)
        self.assertEqual(actual.equity_moic, self.result.equity_moic)

    def test_note_daycount_aliases_and_floor_conversion_do_not_lose_precision(self):
        assets, capital, controls, factors, limits, provider = _input_data()
        canonical = tuple(dict(row, day_count="ACT/360") if row["instrument_type"] == "DEBT" else row for row in capital)
        canonical[0]["index_floor_bps"] = "123.456789"
        with localcontext() as caller:
            caller.prec = 6
            caller.traps[Inexact] = True
            request = model_request_from_records(assets, canonical, provider, controls=controls,
                factors=factors, limits=limits, provenance="TEST")
        self.assertTrue(all(note.day_count is DayCount.ACT_360 for note in request.notes))
        self.assertEqual(request.notes[0].index_floor, D(".0123456789"))

    def test_fixed_notes_require_rate_and_clear_index_floor_and_margin(self):
        assets, capital, controls, factors, limits, provider = _input_data()
        capital[0].update(coupon_type="FIXED", fixed_rate=".03", rate_index="", index_floor_bps="", spread_bps="0")
        request = model_request_from_records(assets, capital, provider, controls=controls,
            factors=factors, limits=limits, provenance="TEST")
        self.assertEqual(request.notes[0].coupon_type, CouponType.FIXED)
        self.assertIsNone(request.notes[0].rate_index)
        self.assertIsNone(request.notes[0].index_floor)
        self.assertEqual(request.notes[0].fixed_rate, D(".03"))
        for change in ({"fixed_rate": ""}, {"rate_index": "EURIBOR_3M"}, {"index_floor_bps": "0"}, {"spread_bps": "1"}):
            altered = tuple(dict(row) for row in capital)
            altered[0].update(change)
            with self.subTest(change=change), self.assertRaises(ValueError):
                model_request_from_records(assets, altered, provider, controls=controls,
                    factors=factors, limits=limits, provenance="TEST")

    def test_factor_mapping_requires_one_identity_and_explicit_synthetic_flag(self):
        assets, capital, controls, factors, limits, provider = _input_data()
        mapping = factor_mapping_from_records(factors)
        self.assertTrue(mapping.is_synthetic)
        self.assertEqual(mapping.factors["TEST_06"], D(6000))
        for field, value in (("system", "OTHER_SYSTEM"), ("version", "OTHER_VERSION"), ("is_synthetic", False),
                             ("version", ""), ("is_synthetic", "")):
            altered = tuple(dict(row) for row in factors)
            altered[0][field] = value
            with self.subTest(field=field, value=value), self.assertRaises(ValueError):
                factor_mapping_from_records(altered)
        altered_assets = tuple(dict(row) for row in assets)
        altered_assets[0]["test_factor_system"] = "OTHER_SYSTEM"
        with self.assertRaisesRegex(ValueError, "conflicts"):
            model_request_from_records(altered_assets, capital, provider, controls=controls,
                factors=factors, limits=limits, provenance="TEST")

    def test_note_balance_must_match_the_funded_debt_issue(self):
        notes = (replace(self.request.notes[0], opening_balance=D("314999999")), *self.request.notes[1:])
        with self.assertRaisesRegex(ValueError, "funded debt issues"):
            TridentModelService().run(replace(self.request, notes=notes))

    def test_analysis_par_and_identity_must_match_projected_positions(self):
        exposures = (replace(self.request.exposures[0], par=D("6999999")), *self.request.exposures[1:])
        with self.assertRaisesRegex(ValueError, "identities/par/currencies"):
            TridentModelService().run(replace(self.request, exposures=exposures))
        with self.assertRaisesRegex(ValueError, "identities/par/currencies"):
            TridentModelService().run(replace(self.request, exposures=self.request.exposures[1:]))

    def test_reserve_and_closing_must_reconcile_to_funding_snapshot(self):
        with self.assertRaisesRegex(ValueError, "funded closing reserve"):
            TridentModelService().run(replace(self.request, clo_terms=replace(self.request.clo_terms, initial_reserve=D("2500001"))))
        with self.assertRaisesRegex(ValueError, "closing date"):
            TridentModelService().run(replace(self.request, clo_terms=replace(self.request.clo_terms, closing_date=date(2026, 11, 21))))

    def test_note_common_schedule_and_residual_class_are_explicit(self):
        assets, capital, controls, factors, limits, provider = _input_data()
        for change in ({"frequency_months": "6"}, {"schedule_anchor_day": "21"}, {"holiday_calendar": "LONDON"},
                       {"business_day_convention": "FOLLOWING"}, {"fixing_lag_target_business_days": "0"}):
            altered = tuple(dict(row) for row in capital)
            altered[0].update(change)
            with self.subTest(change=change), self.assertRaisesRegex(ValueError, "common CLO schedule"):
                model_request_from_records(assets, altered, provider, controls=controls,
                    factors=factors, limits=limits, provenance="TEST")
        with self.assertRaisesRegex(ValueError, "one combined residual equity class"):
            model_request_from_records(assets, capital[:-1], provider, controls=controls,
                factors=factors, limits=limits, provenance="TEST")

    def test_bullet_payment_lag_keeps_face_until_actual_receipt(self):
        assets, capital, controls, factors, limits, provider = _input_data()
        row = next(row for row in assets if row["asset_class"] == "BSL")
        # First note date Feb22 lies after nominal maturity Feb20 but before
        # lagged actual asset payment Mar1: principal cannot fund February's
        # note distribution, and held face remains until the actual receipt.
        row.update(maturity_date_unadjusted="2027-02-20", payment_lag_business_days=5)
        request = model_request_from_records(assets, capital, provider, controls=controls,
            factors=factors, limits=limits, provenance="TEST")
        result = TridentModelService().run(request)
        cash_row = next(cash for cash in result.cashflows.cashflows
                        if cash.loan_id == row["loan_id"] and cash.principal_repayment > 0)
        self.assertEqual(cash_row.payment_date, date(2027, 3, 1))
        before = next(report for report in result.portfolio_snapshots if report.as_of_date == date(2027, 2, 22))
        actual = next(period for period in result.clo.periods if period.payment_date == before.as_of_date)
        self.assertEqual(before.total_par, actual.closing_collateral_par)
        self.assertEqual(result.clo.periods[-1].closing_collateral_par, Decimal(0))

    def test_cashflow_only_has_no_clo_or_fabricated_equity_return(self):
        assets, capital, _, factors, limits, provider = _input_data()
        request = model_request_from_records(assets, capital, provider,
            controls={"mode": "CASHFLOW_ONLY", "upfront_fees": "2500000", "cash_reserve": "2500000"},
            factors=factors, limits=limits, provenance="TEST")
        result = TridentModelService().run(request)
        self.assertIsNone(result.clo)
        self.assertEqual(result.equity_cashflows, ())
        self.assertEqual(result.portfolio_snapshots, ())
        self.assertEqual(result.equity_irr.status, ReturnStatus.UNAVAILABLE)
        self.assertIsNone(result.equity_irr.value)
        self.assertEqual(result.equity_moic.status, ReturnStatus.UNAVAILABLE)
        self.assertEqual(result.opening_portfolio.metric("TEST_FACTOR_AVERAGE").value, D(2120))


if __name__ == "__main__":
    unittest.main()
