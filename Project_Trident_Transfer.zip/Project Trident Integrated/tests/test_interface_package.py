"""Independent package controls: input preservation, growth, cases and atomicity."""
from datetime import date, timedelta
from decimal import Decimal
from pathlib import Path
from tempfile import TemporaryDirectory
from types import SimpleNamespace
import unittest
from unittest.mock import patch
import xml.etree.ElementTree as ET
import zipfile

from openpyxl import Workbook, load_workbook
from openpyxl.chart import BarChart, Reference
from openpyxl.styles import Alignment, Font
from openpyxl.worksheet.table import Table, TableStyleInfo
from openpyxl.worksheet.datavalidation import DataValidation
from openpyxl.workbook.defined_name import DefinedName

from trident.adapters.interface_package import WorkbookPackage, FormulaCell, MAIN, REL, PACKAGE_REL, CHART
from trident.domain.models import InputValidationError


class InterfacePackageTests(unittest.TestCase):
    def setUp(self):
        self.temporary = TemporaryDirectory()
        self.addCleanup(self.temporary.cleanup)
        self.root = Path(self.temporary.name)
        self.source = self.root / 'source.xlsx'
        book = Workbook()
        home = book.active
        home.title = 'Home'
        home['D2'] = 'BASELINE'
        home['D3'] = 100.01
        home['B5'] = 'NOT_RUN'
        book.defined_names.add(DefinedName('trident_ui_schema', attr_text='"1.0"'))
        book.defined_names.add(DefinedName('trident_ui_analysis_case', attr_text="'Home'!$D$2"))
        book.defined_names.add(DefinedName('trident_ui_cash_input', attr_text="'Home'!$D$3"))
        book.defined_names.add(DefinedName('trident_ui_run_status', attr_text="'Home'!$B$5"))
        market = book.create_sheet('Market Data')
        market['A1'], market['B1'] = date(2026, 11, 20), 0.025
        market['A1'].number_format = 'dd-mmm-yyyy'
        market['B1'].number_format = '0.00%'
        input_sheet = book.create_sheet('Inputs')
        input_sheet.append(['Asset', 'Face', 'Raw flag'])
        input_sheet.append(['A', 80.47, False])
        input_sheet.add_table(Table(displayName='tbl_trident_ui_pool', ref='A1:C2'))
        book.defined_names.add(DefinedName('trident_ui_pool', attr_text='tbl_trident_ui_pool[#All]'))
        output = book.create_sheet('Output')
        for row in [('Metric', 'Value', 'Date'), ('Cash', 2.34, date(2026, 11, 20)), ('Face', 50.67, date(2027, 2, 22))]:
            output.append(row)
        output.add_table(Table(displayName='tbl_trident_ui_output', ref='A1:C3', tableStyleInfo=TableStyleInfo(name='TableStyleMedium4', showRowStripes=True)))
        book.defined_names.add(DefinedName('trident_ui_output', attr_text="'Output'!$A$1:$C$3"))
        for row in output:
            for cell in row:
                cell.font = Font(name='Arial')
                cell.alignment = Alignment(horizontal='center', vertical='center')
        chart = BarChart()
        chart.add_data(Reference(output, min_col=2, min_row=1, max_row=3), titles_from_data=True)
        output.add_chart(chart, 'F1')
        book.save(self.source)
        book.close()

    def package(self):
        return WorkbookPackage(self.source, protected_names=('trident_ui_cash_input',), protected_tables=('tbl_trident_ui_pool',))

    def test_independent_growth_preserves_inputs_native_identity_and_market(self):
        package = self.package()
        original = package.table_inventory()['tbl_trident_ui_output']
        market_part = package._sheet_parts()['Market Data']
        market_bytes = package.parts[market_part]
        input_part = package._sheet_parts()['Inputs']
        input_bytes = package.parts[input_part]
        chart_bytes = package.parts['xl/charts/chart1.xml']
        rows = tuple({'Metric':f'R{i}', 'Value':Decimal('80.47') + i, 'Date':date(2026, 11, 20)} for i in range(12))
        updated = package.write_table(original.name, rows, number_formats={'Value':'#,##0.00', 'Date':'dd-mmm-yyyy'})
        self.assertEqual(updated.identifier, original.identifier)
        self.assertEqual(updated.part, original.part)
        self.assertEqual(updated.ref, 'A1:C13')
        self.assertEqual(package.named_region('trident_ui_output'), ('Output', (1, 1, 3, 13)))
        target = package.save(self.root / 'result.xlsx')
        with zipfile.ZipFile(target) as saved:
            self.assertEqual(saved.read(market_part), market_bytes)
            self.assertEqual(saved.read(input_part), input_bytes)
            self.assertEqual(saved.read('xl/charts/chart1.xml'), chart_bytes)
        workbook = load_workbook(target, data_only=True)
        self.addCleanup(workbook.close)
        self.assertAlmostEqual(workbook['Output']['B2'].value, 80.47)
        self.assertEqual(workbook['Output']['C2'].value.date(), date(2026, 11, 20))
        self.assertEqual(workbook['Output']['B2'].font.name, 'Arial')
        self.assertEqual(workbook['Inputs']['B2'].value, 80.47)

    def test_case_records_are_complete_keyed_and_tail_is_blank(self):
        package = self.package()
        baseline = ({'Metric':'IRR', 'Value':0.10, 'Date':date(2026, 11, 20)},)
        downside = ({'Metric':'IRR', 'Value':0.08, 'Date':date(2026, 11, 20)}, {'Metric':'No result', 'Value':'n.a.', 'Date':None})
        package.add_case_view('tbl_trident_ui_output', {'BASELINE':baseline, 'DOWN':downside}, number_formats={'Value':'0.00%', 'Date':'dd-mmm-yyyy'})
        target = package.save(self.root / 'cases.xlsx')
        data = load_workbook(target, data_only=True)
        formulas = load_workbook(target, data_only=False)
        self.addCleanup(data.close)
        self.addCleanup(formulas.close)
        self.assertEqual(data['_Results'].sheet_state, 'hidden')
        self.assertEqual(data['Output']['B2'].value, 0.10)
        self.assertIsNone(data['Output']['B3'].value)
        self.assertIn('trident_ui_analysis_case', formulas['Output']['B2'].value)
        self.assertIn('DOWN|2', [cell.value for row in data['_Results'] for cell in row])
        self.assertEqual(len(package.table_inventory()), 3)

    def test_preserves_existing_case_header_and_distinguishes_result_case(self):
        package = self.package()
        package.add_table('tbl_trident_ui_contract_cases', ('Case', 'Value'), ({'Case':'CONTRACT', 'Value':1},))
        package.add_case_view('tbl_trident_ui_contract_cases', {'BASELINE':({'Case':'CONTRACT', 'Value':2},)})
        backing = package.table_inventory()['tbl_trident_ui_results_contract_cases']
        self.assertEqual(backing.headers, ('Recordkey', 'Result case', 'Case', 'Value'))

    def test_blocks_named_input_table_market_and_unrelated_content(self):
        package = self.package()
        with self.assertRaises(InputValidationError):
            package.write_scalar('trident_ui_cash_input', 0)
        with self.assertRaises(InputValidationError):
            package.write_table('tbl_trident_ui_pool', ({'Asset':'A', 'Face':0, 'Raw flag':False},))
        with self.assertRaises(InputValidationError):
            package.write_cells('Market Data', {'A1':date(2027, 1, 1)})
        package.write_cells('Output', {'A5':'Reserved explanatory note'})
        with self.assertRaises(InputValidationError):
            package.write_table('tbl_trident_ui_output', ({'Metric':'M', 'Value':1, 'Date':None},) * 6)

    def test_atomic_bad_value_and_existing_destination_guards(self):
        package = self.package()
        before = self.source.read_bytes()
        with self.assertRaises(InputValidationError):
            package.write_scalar('trident_ui_run_status', Decimal('NaN'))
        self.assertEqual(self.source.read_bytes(), before)
        with self.assertRaises(InputValidationError):
            package.save(self.source)
        invalid = self.root / 'foreign.xlsx'
        book = Workbook()
        book.save(invalid)
        book.close()
        bad_bytes = invalid.read_bytes()
        with self.assertRaises(InputValidationError):
            package.save(invalid, overwrite=True)
        self.assertEqual(invalid.read_bytes(), bad_bytes)

    def test_output_move_retains_identity_names_and_structured_formulas(self):
        package = self.package()
        previous = package.table_inventory()['tbl_trident_ui_output']
        moved = package.move_table(previous.name)
        self.assertEqual(moved.identifier, previous.identifier)
        self.assertEqual(moved.part, previous.part)
        self.assertEqual(moved.sheet, '_Results')
        self.assertEqual(package.named_region('trident_ui_output'), ('_Results', (1, 1, 3, 3)))
        package.write_table(moved.name, ({'Metric':'New', 'Value':80.47, 'Date':None},))
        target = package.save(self.root / 'moved.xlsx')
        book = load_workbook(target, data_only=True)
        self.addCleanup(book.close)
        self.assertNotIn(previous.name, book['Output'].tables)
        self.assertIn(previous.name, book['_Results'].tables)
        self.assertIsNone(book['Output']['A1'].value)
        self.assertEqual(book['_Results']['B2'].value, 80.47)

    def test_external_financial_links_and_wrong_schema_are_rejected(self):
        package = self.package()
        package.define_name('trident_ui_schema', constant='2.0')
        with self.assertRaises(InputValidationError):
            package.save(self.root / 'wrong.xlsx')
        package = self.package()
        rels = package._xml('xl/_rels/workbook.xml.rels')
        ET.SubElement(rels, '{'+PACKAGE_REL+'}Relationship', Id='rExternal', Type=REL+'/externalLink', Target='file:///other.xlsx', TargetMode='External')
        package._put_xml('xl/_rels/workbook.xml.rels', rels)
        with self.assertRaises(InputValidationError):
            package.save(self.root / 'linked.xlsx')

    def test_literals_and_formula_caches_are_not_confused(self):
        package = self.package()
        package.write_scalar('trident_ui_run_status', '=literal source')
        package.write_cells('Output', {'E10':FormulaCell('1+1', 2)})
        target = package.save(self.root / 'literal.xlsx')
        formulas = load_workbook(target, data_only=False)
        values = load_workbook(target, data_only=True)
        self.addCleanup(formulas.close)
        self.addCleanup(values.close)
        self.assertEqual(formulas['Home']['B5'].data_type, 's')
        self.assertEqual(formulas['Output']['E10'].value, '=1+1')
        self.assertEqual(values['Output']['E10'].value, 2)

    def test_subordinate_names_follow_move_and_growth(self):
        package=self.package()
        package.define_name('trident_ui_output_values','Output','B2:C3')
        package.define_name('trident_ui_output_headers','Output','A1:C1')
        package.move_table('tbl_trident_ui_output')
        package.write_table('tbl_trident_ui_output',({'Metric':str(i),'Value':i,'Date':None} for i in range(5)))
        self.assertEqual(package.named_region('trident_ui_output_values'),('_Results',(2,2,3,6)))
        self.assertEqual(package.named_region('trident_ui_output_headers'),('_Results',(1,1,3,1)))

    def test_formats_preserve_values_and_validation_is_native_stop(self):
        package=self.package()
        package.write_cells('Output',{'E10':FormulaCell('1+1',2)})
        package.set_cell_number_formats('Output',{'B2':'#,##0.00','B3':'0.00%','E10':'#,##0'})
        options=package.add_table('tbl_trident_ui_case_options',('Case',),({'Case':'BASELINE'},{'Case':'DOWN'}))
        left,top,_,bottom=options.bounds
        package.define_name('trident_ui_case_options',options.sheet,f'A{top+1}:A{bottom}')
        package.set_list_validation('Home','D2','trident_ui_case_options',title='Saved case')
        target=package.save(self.root/'format_validation.xlsx')
        book=load_workbook(target,data_only=False)
        self.addCleanup(book.close)
        self.assertEqual(book['Output']['B2'].value,2.34)
        self.assertEqual(book['Output']['B2'].number_format,'#,##0.00')
        self.assertEqual(book['Output']['B3'].number_format,'0.00%')
        self.assertEqual(book['Output']['E10'].value,'=1+1')
        validation=book['Home'].data_validations.dataValidation[0]
        self.assertEqual(validation.errorStyle,'stop')
        self.assertTrue(validation.showErrorMessage)
        self.assertEqual(validation.formula1,'trident_ui_case_options')
        with self.assertRaises(InputValidationError):package.set_cell_number_formats('Inputs',{'B2':'0'})

    def test_growth_checks_only_added_cells_and_retains_sibling_lane(self):
        package = self.package()
        package.write_cells('Output', {'F4': 'Sibling lane', 'C8': 'Outside new rows'})
        rows = ({'Metric': 'R', 'Value': 1, 'Date': None},) * 4
        package.write_table('tbl_trident_ui_output', rows)
        saved = package.save(self.root / 'limited_growth.xlsx')
        book = load_workbook(saved, data_only=True)
        self.addCleanup(book.close)
        self.assertEqual(book['Output']['F4'].value, 'Sibling lane')
        self.assertEqual(book['Output']['C8'].value, 'Outside new rows')
        self.assertEqual(book['Output'].tables['tbl_trident_ui_output'].ref, 'A1:C5')

    def test_growth_rejects_formula_and_literal_in_the_added_rectangle(self):
        for value in (FormulaCell('IF(FALSE,1,"")', ''), '', 'Reserved content', 0):
            with self.subTest(value=value):
                package = self.package()
                package.write_cells('Output', {'B4': value})
                with self.assertRaisesRegex(InputValidationError, 'unrelated worksheet content: B4'):
                    package.write_table('tbl_trident_ui_output',
                                        ({'Metric': 'R', 'Value': 1, 'Date': None},) * 3)

    def test_growth_accepts_style_only_cell_without_claiming_a_value(self):
        package = self.package()
        package.set_cell_number_formats('Output', {'B4': '#,##0.00'})
        package.write_table('tbl_trident_ui_output',
                            ({'Metric': 'R', 'Value': 2.34, 'Date': None},) * 3)
        self.assertEqual(package._table_records('tbl_trident_ui_output')[-1]['Value'], 2.34)

    def test_table_guard_index_follows_growth_move_and_new_table(self):
        package = self.package()
        # Prime both narrow-column and wide-rectangle paths before mutation.
        package._guard('Output', (1, 4, 1, 4))
        package._guard('Output', (1, 20, 100, 20))
        package.write_table('tbl_trident_ui_output',
                            ({'Metric': 'R', 'Value': 1, 'Date': None},) * 4)
        with self.assertRaisesRegex(InputValidationError, 'overlaps native Table'):
            package.write_cells('Output', {'A4': 'Cannot overwrite a grown Table'})
        package.move_table('tbl_trident_ui_output')
        package.write_cells('Output', {'A4': 'Former lane is free'})
        with self.assertRaisesRegex(InputValidationError, 'overlaps native Table'):
            package.write_cells('_Results', {'A4': 'Moved lane remains guarded'})
        package._guard('Output', (8, 1, 8, 1))
        package.add_table('tbl_trident_ui_second_lane', ('Value',), ({'Value': 8},),
                          sheet='Output', start_cell='H1')
        with self.assertRaisesRegex(InputValidationError, 'overlaps native Table'):
            package.write_cells('Output', {'H2': 0})

    def test_vertically_stacked_table_guards_choose_exact_row_owner(self):
        package = self.package()
        package.add_table('tbl_trident_ui_second_row', ('Value',), ({'Value': 5},),
                          sheet='Output', start_cell='A6')
        package.set_cell_number_formats('Output', {'A2': 'General', 'A7': '#,##0.00'})
        with self.assertRaisesRegex(InputValidationError, 'overlaps native Table'):
            package.write_table('tbl_trident_ui_output',
                                ({'Metric': 'R', 'Value': 1, 'Date': None},) * 6)
        self.assertEqual(package._table_records('tbl_trident_ui_second_row'), [{'Value': 5}])

    def test_noop_style_requests_still_reject_protected_owners(self):
        package = self.package()
        package.set_cell_number_formats('Output', {'B2': '#,##0.00'})
        # Protection is evaluated at use time; it is not cached into the index.
        package.protected_tables = frozenset((*package.protected_tables, 'tbl_trident_ui_output'))
        with self.assertRaisesRegex(InputValidationError, 'protected input Table'):
            package.set_cell_number_formats('Output', {'B2': '#,##0.00'})
        with self.assertRaisesRegex(InputValidationError, 'protected input name'):
            package.set_cell_number_formats('Home', {'D3': 'General'})

    def test_unchanged_republication_retains_exact_formula_cache_and_cell_markup(self):
        package = self.package()
        rows = ({'Metric': 'IRR', 'Value': FormulaCell('1/10', 0.1),
                 'Date': date(2026, 11, 20)},)
        formats = {'Value': '0.00%', 'Date': 'dd-mmm-yyyy'}
        package.write_table('tbl_trident_ui_output', rows, number_formats=formats)
        package.set_cell_number_formats('Output', {'B2': '0.00%'})
        first = package.save(self.root / 'first_publish.xlsx')
        repeat = WorkbookPackage(first, protected_names=('trident_ui_cash_input',),
                                 protected_tables=('tbl_trident_ui_pool',))
        repeat.write_table('tbl_trident_ui_output', rows, number_formats=formats)
        repeat.set_cell_number_formats('Output', {'B2': '0.00%'})
        second = repeat.save(self.root / 'repeat_publish.xlsx')
        part = repeat._sheet_parts()['Output']
        with zipfile.ZipFile(first) as before, zipfile.ZipFile(second) as after:
            self.assertEqual(before.read(part), after.read(part))
        formulas = load_workbook(second, data_only=False)
        data = load_workbook(second, data_only=True)
        self.addCleanup(formulas.close)
        self.addCleanup(data.close)
        self.assertEqual(formulas['Output']['B2'].value, '=1/10')
        self.assertEqual(data['Output']['B2'].value, 0.1)
        self.assertEqual(formulas['Output']['B2'].number_format, '0.00%')

    def test_shrink_clears_old_values_and_caches_but_reuses_predefined_tail_styles(self):
        package = self.package()
        rows = ({'Metric': 'Cash', 'Value': 2.34, 'Date': date(2026, 11, 20)},
                {'Metric': 'Rate', 'Value': FormulaCell('1/10', 0.1), 'Date': date(2027, 2, 22)},
                {'Metric': 'Zero', 'Value': 0, 'Date': date(2027, 5, 20)},
                {'Metric': 'Literal', 'Value': '=source text', 'Date': date(2027, 8, 20)})
        package.write_table('tbl_trident_ui_output', rows,
                            number_formats={'Value': '#,##0.00', 'Date': 'dd-mmm-yyyy'})
        package.set_cell_number_formats('Output', {'B3': '0.00%', 'B4': '#,##0', 'B5': '@'})
        package.write_table('tbl_trident_ui_output', rows[:1])
        self.assertEqual(package.table_inventory()['tbl_trident_ui_output'].ref, 'A1:C2')
        shrunk = package.save(self.root / 'shrunk_styles.xlsx')
        formulas = load_workbook(shrunk, data_only=False)
        data = load_workbook(shrunk, data_only=True)
        self.addCleanup(formulas.close)
        self.addCleanup(data.close)
        for row in range(3, 6):
            for column in 'ABC':
                address = f'{column}{row}'
                self.assertIsNone(formulas['Output'][address].value)
                self.assertIsNone(data['Output'][address].value)
        self.assertEqual(formulas['Output']['B3'].number_format, '0.00%')
        self.assertEqual(formulas['Output']['B4'].number_format, '#,##0')
        self.assertEqual(formulas['Output']['B5'].number_format, '@')
        self.assertEqual(formulas['Output']['C5'].number_format, 'dd-mmm-yyyy')
        package.write_table('tbl_trident_ui_output', rows)
        regrown = package.save(self.root / 'regrown_styles.xlsx')
        regrown_formulas = load_workbook(regrown, data_only=False)
        regrown_data = load_workbook(regrown, data_only=True)
        self.addCleanup(regrown_formulas.close)
        self.addCleanup(regrown_data.close)
        self.assertEqual(regrown_formulas['Output'].tables['tbl_trident_ui_output'].ref, 'A1:C5')
        self.assertEqual(regrown_formulas['Output']['B3'].value, '=1/10')
        self.assertEqual(regrown_data['Output']['B3'].value, 0.1)
        self.assertEqual(regrown_data['Output']['B4'].value, 0)
        self.assertEqual(regrown_formulas['Output']['B5'].data_type, 's')
        self.assertEqual(regrown_formulas['Output']['B5'].value, '=source text')
        self.assertEqual(regrown_formulas['Output']['B3'].number_format, '0.00%')
        self.assertEqual(regrown_formulas['Output']['B4'].number_format, '#,##0')
        self.assertEqual(regrown_formulas['Output']['B5'].number_format, '@')

    def test_large_virtual_table_clears_only_physical_cells_and_old_tail_cache(self):
        package = self.package()
        info = package.table_inventory()['tbl_trident_ui_output']
        # Reserve a near-Excel-limit Table rectangle without creating hundreds
        # of thousands of blank cells. It still owns every row in that extent.
        table = package._xml(info.part)
        table.set('ref', 'A1:C1000000')
        table.find('{'+MAIN+'}autoFilter').set('ref', 'A1:C1000000')
        package._put_xml(info.part, table)
        package._adjust_table_names(info, 'Output', (1, 1, 3, 1000000))
        package._existing_cell_addresses('Output', (1, 2, 3, 1000000))
        package._replace_cells('Output', {
            'B999999': package._cell('B999999', FormulaCell('1+1', 2), 1),
            'C999998': package._cell('C999998', None, 1),
        })
        with patch.object(package, '_replace_cells', wraps=package._replace_cells) as transport:
            package.write_table(info.name, ({'Metric': 'Current', 'Value': 0, 'Date': None},))
        clear = transport.call_args.kwargs['clear']
        self.assertLess(len(clear), 12)
        self.assertIn('B999999', clear)
        self.assertEqual(package.table_inventory()[info.name].ref, 'A1:C2')
        cells = package._sheet_cells(package._xml(package._sheet_parts()['Output']))
        tail = cells['B999999']
        self.assertIsNone(tail.find('{'+MAIN+'}f'))
        self.assertIsNone(tail.find('{'+MAIN+'}v'))
        self.assertEqual(tail.attrib.get('s'), '1')
        self.assertEqual(cells['C999998'].attrib.get('s'), '1')
        self.assertLess(len(cells), 15)
        # The maintained index observes both style-only survivors and removal
        # when a subsequent relocation clears the actual Table cells entirely.
        self.assertEqual(set(package._existing_cell_addresses('Output', (2, 999998, 3, 999999))),
                         {'B999999', 'C999998'})
        package.move_table(info.name)
        self.assertEqual(package._existing_cell_addresses('Output', (1, 1, 3, 2)), ())

    def test_witness_reset_preserves_raw_types_and_tracks_growth(self):
        book=load_workbook(self.source)
        raw=book['Inputs']; raw.append(['B',0,True]);raw.tables['tbl_trident_ui_pool'].ref='A1:C3'
        hidden=book.create_sheet('_Lists');hidden.sheet_state='hidden'
        hidden.append(['Asset','Face','Raw flag']);hidden.append(['OLD',1,True])
        hidden.add_table(Table(displayName='tbl_trident_ui_frozen_pool',ref='A1:C2'))
        book.defined_names.add(DefinedName('trident_ui_fresh_current_pool_1',attr_text="'Inputs'!$A$2:$C$2"))
        book.defined_names.add(DefinedName('trident_ui_fresh_saved_pool_1',attr_text="'_Lists'!$A$2:$C$2"))
        checks=book.create_sheet('Checks')
        checks['H11']='=IFERROR(SUMPRODUCT(--(trident_ui_fresh_current_pool_1<>trident_ui_fresh_saved_pool_1))+--(ROWS(tbl_trident_ui_pool[Asset])<>1),"CHECK ERROR")'
        checks['I11']='=IF(H11=0,"UNCHANGED INPUTS","INPUTS CHANGED")'
        checks['H34']='=SUM(H11:H33)';checks['I34']='=IF(H34=0,"UNCHANGED INPUTS","INPUTS CHANGED")'
        book.save(self.source);book.close()
        package=self.package();package.refresh_input_witnesses(SimpleNamespace(input_fingerprint='recorded'))
        self.assertEqual(package.named_region('trident_ui_fresh_current_pool_1'),('Inputs',(1,2,3,3)))
        self.assertEqual(package.named_region('trident_ui_fresh_saved_pool_1'),('_Lists',(1,2,3,3)))
        target=package.save(self.root/'witness.xlsx')
        data=load_workbook(target,data_only=True);formulas=load_workbook(target,data_only=False)
        self.addCleanup(data.close);self.addCleanup(formulas.close)
        self.assertIs(data['_Lists']['C2'].value,False)
        self.assertIs(data['_Lists']['C3'].value,True)
        self.assertEqual(data['_Lists']['B3'].value,0)
        self.assertEqual(data['Checks']['H11'].value,0)
        self.assertIn('<>2',formulas['Checks']['H11'].value)

    def test_nested_native_chart_cache_is_invalidated(self):
        package=self.package()
        old='xl/charts/chart1.xml';new='xl/drawings/charts/native.xml'
        package.parts[new]=package.parts.pop(old)
        rels=package._xml('xl/drawings/_rels/drawing1.xml.rels')
        for rel in rels:
            if rel.attrib['Type'].endswith('/chart'):rel.set('Target','charts/native.xml')
        package._put_xml('xl/drawings/_rels/drawing1.xml.rels',rels)
        types=package._xml('[Content_Types].xml')
        for entry in types:
            if entry.attrib.get('PartName')=='/'+old:entry.set('PartName','/'+new)
        package._put_xml('[Content_Types].xml',types)
        chart=package._xml(new)
        numref=next(chart.iter('{'+CHART+'}numRef'))
        cache=ET.SubElement(numref,'{'+CHART+'}numCache')
        ET.SubElement(cache,'{'+CHART+'}ptCount',val='2')
        package._put_xml(new,chart)
        package.invalidate_chart_caches()
        self.assertFalse(list(package._xml(new).iter('{'+CHART+'}numCache')))
        package.save(self.root/'nested_chart.xlsx')

    def test_display_period_growth_changes_dates_names_and_native_helpers(self):
        book=load_workbook(self.source)
        wf=book.create_sheet('Waterfall');wf['D7']='A';wf['E10']=date(2026,11,20)
        wf['E12']='=INDEX(trident_ui_account_values,MATCH(1,trident_ui_account_periods,0),MATCH("opening_collateral_par",trident_ui_account_headers,0))'
        analysis=book.create_sheet('CLO Analysis')
        for column in ('JT','JU','JV','JW','JY','JZ','KA','KE','KF','KG','KJ','KK','KL','KN','KO','KP'):
            analysis[column+'11']='=INDEX(tbl_trident_ui_view_amortization[Label],1)'
        book.defined_names.add(DefinedName('trident_ui_selected_tranche',attr_text="'Waterfall'!$D$7"))
        book.defined_names.add(DefinedName('trident_ui_chart_equity_ref_1',attr_text="'CLO Analysis'!$JT$11:$JT$12"))
        book.save(self.source);book.close()
        package=self.package()
        package.add_table('tbl_trident_ui_account_records',('period_number','payment_date','opening_collateral_par'),
                          ({'period_number':i,'payment_date':date(2026,11,20),'opening_collateral_par':100-i} for i in range(1,6)))
        package.add_table('tbl_trident_ui_waterfall_records',('period_number','class_id'),
                          ({'period_number':i,'class_id':'A'} for i in range(1,6)))
        package.add_table('tbl_trident_ui_view_stack',('Tranche','Type'),({'Tranche':'SUB','Type':'EQUITY'},))
        run=SimpleNamespace(cases=(SimpleNamespace(result=SimpleNamespace(clo=SimpleNamespace(periods=(None,)*5))),))
        package.refresh_display_views(run)
        self.assertEqual(package.named_region('trident_ui_chart_equity_ref_1'),('CLO Analysis',(280,11,280,15)))
        target=package.save(self.root/'display_growth.xlsx')
        formulas=load_workbook(target,data_only=False);data=load_workbook(target,data_only=True)
        self.addCleanup(formulas.close);self.addCleanup(data.close)
        self.assertIn('[payment_date],5)',formulas['Waterfall']['I10'].value)
        self.assertIn('MATCH(INDEX(tbl_trident_ui_account_records[period_number],5),',formulas['Waterfall']['I12'].value)
        self.assertEqual(data['Waterfall']['I12'].value,95)
        self.assertIn('[Label],5)',formulas['CLO Analysis']['JT15'].value)

    def test_cashflow_selector_is_top_left_and_readonly_home_has_no_dropdown(self):
        book=load_workbook(self.source)
        cashflows=book.create_sheet('Asset Cashflows')
        cashflows['B7']='Old long instruction';cashflows.merge_cells('B7:P7')
        old=DataValidation(type='list',formula1='"BASELINE"');old.add('I7')
        book['Home'].add_data_validation(old)
        book['Home']['Z3']='1.0'
        book['Home']['Z3'].font=Font(name='Calibri')
        book.save(self.source);book.close()
        package=self.package();package.refresh_selector_layout()
        target=package.save(self.root/'selector_layout.xlsx')
        data=load_workbook(target);self.addCleanup(data.close)
        self.assertIn('D7:H7',str(data['Asset Cashflows'].merged_cells))
        self.assertNotIn('B7:P7',str(data['Asset Cashflows'].merged_cells))
        self.assertEqual(data['Asset Cashflows']['B7'].value,'Saved case')
        self.assertFalse(data['Home'].data_validations.dataValidation)
        self.assertEqual(data['Home']['Z3'].value,'1.0')
        self.assertEqual(data['Home']['Z3'].font.name,'Arial')

    def test_independent_result_lanes_keep_unrelated_rows_values_and_order(self):
        package=self.package()
        package.add_table('tbl_trident_ui_long_lane',('Period','Cash'),({'Period':i,'Cash':Decimal('10.01')} for i in range(1,2001)))
        package.add_table('tbl_trident_ui_small_lane',('Date','Flag'),({'Date':date(2026,11,20),'Flag':False},))
        package.write_table('tbl_trident_ui_small_lane',({'Date':date(2027,2,22),'Flag':True},)*10)
        target=package.save(self.root/'lanes.xlsx')
        book=load_workbook(target,data_only=True);self.addCleanup(book.close)
        lane=package.table_inventory()['tbl_trident_ui_long_lane']
        self.assertEqual(book['_Results'].cell(2001,lane.bounds[0]).value,2000)
        self.assertEqual(book['_Results'].cell(2001,lane.bounds[0]+1).value,10.01)
        # Native XML ordering is required even when a shorter lane grows after
        # the longer lane has already populated the same worksheet rows.
        from trident.adapters.interface_package import _tag,_coordinate
        rows=package._xml(package._sheet_parts()['_Results']).find(_tag('sheetData'))
        self.assertEqual([int(row.attrib['r']) for row in rows],sorted(int(row.attrib['r']) for row in rows))
        for row in rows:
            columns=[_coordinate(cell.attrib['r'])[0] for cell in row if cell.tag==_tag('c')]
            self.assertEqual(columns,sorted(columns))

    def test_protected_native_schema_hook_changes_style_and_keeps_value_locked(self):
        book=load_workbook(self.source)
        book['Home']['Z3']='1.0';book['Home']['Z3'].font=Font(name='Calibri')
        book.defined_names['trident_ui_schema'].attr_text="'Home'!$Z$3"
        book.save(self.source);book.close()
        package=WorkbookPackage(self.source,protected_names=('trident_ui_schema','trident_ui_cash_input'),
                                protected_tables=('tbl_trident_ui_pool',))
        package.refresh_selector_layout()
        self.assertEqual(package.read_scalar('trident_ui_schema'),'1.0')
        with self.assertRaises(InputValidationError):package.write_scalar('trident_ui_schema','2.0')
        with self.assertRaises(InputValidationError):package.set_cell_number_formats('Home',{'D3':'0'})
        target=package.save(self.root/'protected_schema.xlsx')
        data=load_workbook(target);self.addCleanup(data.close)
        self.assertEqual(data['Home']['Z3'].value,'1.0')
        self.assertEqual(data['Home']['Z3'].font.name,'Arial')

    def test_metric_catalog_uses_locale_safe_text_formats_and_annual_return_percent(self):
        package=self.package()
        records=tuple({'Group':'Summary','Metric':metric,'Value':value,'Unit':unit} for metric,value,unit in
                      [('IRR',0.0998,'annual return'),('Rate',0.02,'ANNUAL_RATE'),('MOIC',1.7974,'multiple'),
                       ('Cash',Decimal('10.01'),'EUR'),('Count',3,'count'),('Other',1.23456,'custom unit'),
                       ('Unavailable','n.a.','unknown')])
        package.add_table('tbl_trident_ui_analysis_details',('Group','Metric','Value','Unit'),records)
        before=package._table_records('tbl_trident_ui_analysis_details')
        package.add_table('tbl_trident_ui_analysis_options_metric',('Metric','Row index','Display format'),
                          ({'Metric':'Stale','Row index':1,'Display format':'General'},))
        package.define_name('trident_ui_analysis_metric','Home','F10')
        package.write_scalar('trident_ui_analysis_metric','Stale')
        package.refresh_metric_catalog()
        catalog=package._table_records('tbl_trident_ui_analysis_options_metric')
        self.assertEqual([row['Display format'] for row in catalog],
                         ['0.00%','0.00%','0.000"x"','#,##0.00;(#,##0.00);–','#,##0','0.###############','0.###############'])
        self.assertEqual(package.read_scalar('trident_ui_analysis_metric'),'Summary | IRR')
        self.assertEqual(package._table_records('tbl_trident_ui_analysis_details'),before)

    def test_limit_summary_tracks_current_ids_units_unavailable_and_case_tail(self):
        book=load_workbook(self.source);sheet=book.create_sheet('CLO Analysis')
        for row in range(109,129):
            for column in ('B','G','J','L','N'):
                sheet[f'{column}{row}']='=MATCH("INFRA MIN",A1:A2,0)'
        book.save(self.source);book.close()
        package=self.package()
        records=(
            {'Limit':'INFRA_MIN','Value':0.70,'Threshold':0.70,'Headroom':0,'Result':'PASS'},
            {'Limit':'LEGACY_CUSTOM_WARF','Value':'n.a.','Threshold':4500,'Headroom':'n.a.','Result':'UNAVAILABLE'},
            {'Limit':'WAL_YEARS_MAX','Value':7.1254,'Threshold':8,'Headroom':0.8746,'Result':'PASS'},
            {'Limit':'MIN_WAS_BPS','Value':370.23,'Threshold':360.5,'Headroom':9.73,'Result':'PASS'})
        package.add_table('tbl_trident_ui_limit_results',('Limit','Value','Threshold','Headroom','Result'),records)
        portfolio=SimpleNamespace(metrics=tuple(SimpleNamespace(name=name,unit=unit) for name,unit in
                                               [('INFRA_FRACTION','fraction'),('WARF','rating_factor'),('WAL_YEARS','years_ACT365F'),('WAS_BPS','bps')]),
                                  limits=tuple(SimpleNamespace(limit_id=record['Limit'],metric=metric) for record,metric in
                                               zip(records,('INFRA_FRACTION','WARF','WAL_YEARS','WAS_BPS'))))
        run=SimpleNamespace(cases=(SimpleNamespace(case_id='BASELINE',result=SimpleNamespace(opening_portfolio=portfolio)),))
        package.refresh_limit_summary(run)
        target=package.save(self.root/'limit_summary.xlsx')
        formulas=load_workbook(target,data_only=False);data=load_workbook(target,data_only=True)
        self.addCleanup(formulas.close);self.addCleanup(data.close)
        self.assertEqual(data['CLO Analysis']['B109'].value,'INFRA_MIN')
        self.assertEqual(data['CLO Analysis']['G109'].value,0.7)
        self.assertEqual(data['CLO Analysis']['L109'].value,0)
        self.assertEqual(data['CLO Analysis']['G110'].value,'n.a.')
        self.assertEqual(data['CLO Analysis']['L110'].value,'n.a.')
        self.assertIsNone(data['CLO Analysis']['B113'].value)
        self.assertEqual(data['CLO Analysis']['G109'].number_format,'0.00%')
        self.assertEqual(data['CLO Analysis']['J110'].number_format,'#,##0')
        self.assertEqual(data['CLO Analysis']['G111'].number_format,'0.000')
        self.assertEqual(data['CLO Analysis']['J112'].number_format,'0.00')
        for row in range(109,129):
            for column in ('B','G','J','L','N'):
                self.assertIn(f'[{dict(B="Limit",G="Value",J="Threshold",L="Headroom",N="Result")[column]}]',formulas['CLO Analysis'][f'{column}{row}'].value)
                self.assertNotIn('MATCH(',formulas['CLO Analysis'][f'{column}{row}'].value)

    def test_failed_gate_display_is_admitted_and_repeated_refresh_is_idempotent(self):
        book=load_workbook(self.source)
        wf=book.create_sheet('Waterfall');wf['D7']='A';wf['E10']=date(2026,11,20)
        wf['E12']='=INDEX(trident_ui_account_values,MATCH(1,trident_ui_account_periods,0),MATCH("opening_collateral_par",trident_ui_account_headers,0))'
        sheet=book.create_sheet('CLO Analysis')
        for column in ('JT','JU','JV','JW','JY','JZ','KA','KE','KF','KG','KJ','KK','KL','KN','KO','KP'):
            sheet[column+'11']='=INDEX(tbl_trident_ui_view_amortization[Label],1)'
        for column,kind in (('KK','OC'),('KO','IC')):
            status=f'INDEX(tbl_trident_ui_view_coverage[Gate {kind} status],1)'
            ratio=f'INDEX(tbl_trident_ui_view_coverage[Gate {kind} ratio],1)'
            minimum=f'INDEX(tbl_trident_ui_view_coverage[{kind} minimum],1)'
            sheet[column+'11']=f'=IF(OR({status}="PASS",{status}="BREACH"),{ratio}/{minimum}-1,NA())'
        status='INDEX(tbl_trident_ui_view_coverage[Gate OC status],1)'
        sheet['G134']=f'=IF(OR({status}="PASS",{status}="BREACH"),INDEX(tbl_trident_ui_view_coverage[Gate OC ratio],1),"n.a.")'
        sheet['N134']='=INDEX(tbl_trident_ui_view_coverage[Gate IC status],1)'
        book.defined_names.add(DefinedName('trident_ui_selected_tranche',attr_text="'Waterfall'!$D$7"))
        book.defined_names.add(DefinedName('trident_ui_analysis_tranche',attr_text="'Waterfall'!$D$7"))
        book.save(self.source);book.close()
        package=self.package()
        package.add_table('tbl_trident_ui_account_records',('period_number','payment_date','opening_collateral_par'),
                          ({'period_number':1,'payment_date':date(2027,2,22),'opening_collateral_par':100},))
        package.add_table('tbl_trident_ui_waterfall_records',('period_number','class_id'),({'period_number':1,'class_id':'A'},))
        package.add_table('tbl_trident_ui_view_amortization',('Period','Label'),({'Period':1,'Label':'Feb 27'},))
        coverage={'Key':'A|1','Gate OC status':'FAIL','Gate OC ratio':0.95,'OC minimum':1.06,
                  'Gate IC status':'FAIL','Gate IC ratio':0.98,'IC minimum':1.10}
        package.add_table('tbl_trident_ui_view_coverage',tuple(coverage),(coverage,))
        stack={'Tranche':'A','Type':'DEBT','Face (EUR)':100,'Spread (bps)':150,'OC minimum':1.06,'IC minimum':1.10}
        package.add_table('tbl_trident_ui_view_stack',tuple(stack),(stack,))
        package.add_table('tbl_trident_ui_analysis_options_tranche',('Tranche',),({'Tranche':'A'},))
        run=SimpleNamespace(cases=(SimpleNamespace(case_id='BASELINE',result=SimpleNamespace(clo=SimpleNamespace(periods=(None,)))),))
        package.refresh_display_views(run)
        from trident.adapters.interface_package import _tag
        def formulas():
            cells=package._sheet_cells(package._xml(package._sheet_parts()['CLO Analysis']))
            return {address:cells[address].findtext(_tag('f')) for address in ('KK11','KO11','JT11','G134','N134')}
        first=formulas()
        package.refresh_display_views(run)
        self.assertEqual(formulas(),first)
        for address in ('KK11','KO11','G134'):
            self.assertIn('="FAIL"',first[address])
            self.assertNotIn('="BREACH"',first[address])
        self.assertEqual(package._table_records('tbl_trident_ui_view_coverage'),[coverage])
        package.save(self.root/'failed_gate.xlsx')

    def test_existing_period_sequence_and_selected_case_date_list_exclude_blank_tail(self):
        dates=tuple(date(1899,12,30)+timedelta(days=serial) for serial in (46527,46619,46713,46804,46895,46986,47077,47169))
        longer=(*dates,dates[-1]+timedelta(days=90))
        book=load_workbook(self.source)
        wf=book.create_sheet('Waterfall');wf['D7']='A'
        for column in range(5,45):wf.cell(10,column,date(2027,2,22))
        wf['E12']='=INDEX(trident_ui_account_values,MATCH(1,trident_ui_account_periods,0),MATCH("opening_collateral_par",trident_ui_account_headers,0))'
        sheet=book.create_sheet('CLO Analysis');sheet['O6']=date(2027,2,22)
        for column in ('JT','JU','JV','JW','JY','JZ','KA','KE','KF','KG','KJ','KK','KL','KN','KO','KP'):
            sheet[column+'11']='=INDEX(tbl_trident_ui_view_amortization[Label],1)'
        sheet['KK11']='=INDEX(tbl_trident_ui_view_coverage[Gate OC ratio],MATCH(trident_ui_analysis_tranche&"|1",tbl_trident_ui_view_coverage[Key],0))'
        for name,reference in (('selected_tranche',"'Waterfall'!$D$7"),('analysis_tranche',"'Waterfall'!$D$7"),
                               ('analysis_date',"'CLO Analysis'!$O$6"),('analysis_period',"'CLO Analysis'!$IS$11")):
            book.defined_names.add(DefinedName('trident_ui_'+name,attr_text=reference))
        book.save(self.source);book.close()
        package=self.package()
        for suffix,headers in (('account_records',('period_number','payment_date','opening_collateral_par')),
                               ('waterfall_records',('period_number','class_id')),
                               ('view_amortization',('Period','Date','Label')),
                               ('view_coverage',('Key','Gate OC ratio')),
                               ('analysis_options_date',('Date',))):
            package.add_table('tbl_trident_ui_'+suffix,headers,())
        for suffix,cases in (
            ('account_records',{case:tuple({'period_number':i+2,'payment_date':d,'opening_collateral_par':100-i} for i,d in enumerate(ds)) for case,ds in [('BASELINE',dates),('LONGER',longer)]}),
            ('waterfall_records',{case:tuple({'period_number':i+2,'class_id':'A'} for i,d in enumerate(ds)) for case,ds in [('BASELINE',dates),('LONGER',longer)]}),
            ('view_amortization',{case:tuple({'Period':i+2,'Date':d,'Label':d.strftime('%b %y')} for i,d in enumerate(ds)) for case,ds in [('BASELINE',dates),('LONGER',longer)]}),
            ('view_coverage',{case:tuple({'Key':'A|'+str(i+2),'Gate OC ratio':1.1} for i,d in enumerate(ds)) for case,ds in [('BASELINE',dates),('LONGER',longer)]})):
            package.add_case_view('tbl_trident_ui_'+suffix,cases)
        package.add_table('tbl_trident_ui_view_stack',('Tranche','Type'),({'Tranche':'SUB','Type':'EQUITY'},))
        run=SimpleNamespace(cases=tuple(SimpleNamespace(case_id=case,result=SimpleNamespace(clo=SimpleNamespace(periods=tuple(
            SimpleNamespace(period_number=i+2,payment_date=d) for i,d in enumerate(ds))))) for case,ds in [('BASELINE',dates),('LONGER',longer)]))
        package.refresh_display_views(run)
        from trident.adapters.interface_package import _tag
        name=package._names()['trident_ui_analysis_options_date'].text
        self.assertIn('COUNT(tbl_trident_ui_analysis_options_date[Date])',name)
        list_bounds=package.named_region('trident_ui_analysis_options_date')[1]
        self.assertEqual(list_bounds[3]-list_bounds[1]+1,8)
        self.assertIn(package._table_records('tbl_trident_ui_analysis_options_date')[8]['Date'],('',None))
        self.assertEqual(package.read_scalar('trident_ui_analysis_period'),2)
        target=package.save(self.root/'existing_sequence.xlsx')
        data=load_workbook(target,data_only=True);formulas=load_workbook(target,data_only=False)
        self.addCleanup(data.close);self.addCleanup(formulas.close)
        self.assertEqual(data['Waterfall']['E10'].value.date(),date(1899,12,30)+timedelta(days=46527))
        self.assertEqual(data['Waterfall']['E12'].value,100)
        for column in range(13,45):self.assertIsNone(data['Waterfall'].cell(10,column).value)
        self.assertIn('trident_ui_analysis_tranche&"|"&INDEX(tbl_trident_ui_view_amortization[Period],1)',formulas['CLO Analysis']['KK11'].value)
        self.assertIn('INDEX(tbl_trident_ui_account_records[period_number],1)',formulas['Waterfall']['E12'].value)
        # The complete longer case is retained and its list includes the ninth
        # date when that case is selected, without changing Python period IDs.
        package.write_scalar('trident_ui_analysis_case','LONGER')
        package.refresh_date_options(run)
        list_bounds=package.named_region('trident_ui_analysis_options_date')[1]
        self.assertEqual(list_bounds[3]-list_bounds[1]+1,9)
        self.assertEqual(package.read_scalar('trident_ui_analysis_period'),2)

    def test_existing_measurement_statuses_and_scope_values_use_saved_sources(self):
        book=load_workbook(self.source)
        sheet=book.create_sheet('CLO Analysis')
        for row in (*range(44,55),*range(74,86)):
            sheet[f'E{row}']='n.a.';sheet[f'H{row}']='AVAILABLE'
        sheet['E141']='=NA()';sheet['M141']='=NA()'
        book['Home']['D4']='Whole';book['Home']['D5']='A'
        book.defined_names.add(DefinedName('trident_ui_analysis_scope',attr_text="'Home'!$D$4"))
        book.defined_names.add(DefinedName('trident_ui_analysis_tranche',attr_text="'Home'!$D$5"))
        book.save(self.source);book.close()
        package=self.package()
        ids=('DEBT_TO_COLLATERAL_PAR','DEBT_TO_EQUITY_CASH','WEIGHTED_FLOATING_DEBT_SPREAD_BPS',
             'ORIGINAL_CONTRACTUAL_COUPON_YIELD','ORIGINAL_REALIZED_CASH_YIELD','CASH_DEBT_COST',
             'ACCRUED_DEBT_COST','TOTAL_FEES_PAID','TOTAL_EQUITY_DISTRIBUTIONS')
        records=tuple({'Economics metric':key,'Value':'n.a.' if i in (1,7) else 0,
                       'Data status':'UNAVAILABLE' if i in (1,7) else 'AVAILABLE'} for i,key in enumerate(ids))
        package.add_table('tbl_trident_ui_economics',tuple(records[0]),records)
        package.add_table('tbl_trident_ui_dashboard',('Metric','Data status'),
                          ({'Metric':'Equity IRR','Data status':'UNAVAILABLE'},))
        scope=tuple({'Key':'Whole|'+metric,'Scope':'Whole','Metric':metric,'Value':value,'Data status':status}
                    for metric,value,status in (('WARF',900,'AVAILABLE'),('WARR',0.50,'AVAILABLE'),
                                                ('TEST_FACTOR_AVERAGE','n.a.','UNAVAILABLE')))
        package.add_table('tbl_trident_ui_view_scope_metrics',tuple(scope[0]),scope)
        package.add_table('tbl_trident_ui_view_coverage_minima',('Tranche','Minimum gate OC headroom','Minimum gate IC headroom'),())
        original=package._table_records('tbl_trident_ui_economics')
        run=SimpleNamespace(baseline=SimpleNamespace(clo_opening_state=object()),
                            cases=(SimpleNamespace(result=SimpleNamespace(clo=object())),))
        package.refresh_measurement_statuses(run)
        target=package.save(self.root/'existing_status.xlsx')
        data=load_workbook(target,data_only=True);formulas=load_workbook(target,data_only=False)
        self.addCleanup(data.close);self.addCleanup(formulas.close)
        self.assertEqual(data['CLO Analysis']['E45'].value,'n.a.')
        for address in ('H45','H51','H54','H85'):self.assertEqual(data['CLO Analysis'][address].value,'Missing data')
        self.assertEqual(data['CLO Analysis']['H44'].value,'AVAILABLE')
        self.assertEqual(data['CLO Analysis']['E44'].value,0)
        self.assertEqual(data['CLO Analysis']['E83'].value,900)
        self.assertEqual(data['CLO Analysis']['E84'].value,0.50)
        self.assertEqual(data['CLO Analysis']['H84'].value,'AVAILABLE')
        self.assertIn('tbl_trident_ui_economics[Data status]',formulas['CLO Analysis']['H45'].value)
        self.assertIn('trident_ui_analysis_scope&"|WARR"',formulas['CLO Analysis']['H84'].value)
        self.assertIn('tbl_trident_ui_dashboard[Data status]',formulas['CLO Analysis']['H54'].value)
        self.assertEqual(data['CLO Analysis']['M20'].value,'Full pool / opening snapshot')
        self.assertEqual(package._table_records('tbl_trident_ui_economics'),original)

    def test_unselected_clo_economics_and_coverage_display_absence_without_errors(self):
        book=load_workbook(self.source);sheet=book.create_sheet('CLO Analysis')
        for row in range(44,53):sheet[f'E{row}']='=NA()';sheet[f'H{row}']='AVAILABLE'
        sheet['E141']='=NA()';sheet['M141']='=NA()'
        book.save(self.source);book.close()
        package=self.package()
        package.add_table('tbl_trident_ui_economics',('Economics metric','Value','Data status'),())
        package.add_table('tbl_trident_ui_view_coverage_minima',('Tranche','Minimum gate OC headroom','Minimum gate IC headroom'),())
        package.refresh_measurement_statuses(SimpleNamespace(cases=(SimpleNamespace(result=SimpleNamespace(clo=None)),)))
        target=package.save(self.root/'asset_only_status.xlsx')
        data=load_workbook(target,data_only=True);formulas=load_workbook(target,data_only=False)
        self.addCleanup(data.close);self.addCleanup(formulas.close)
        for address in (*(f'E{row}' for row in range(44,53)),'E141','M141'):
            self.assertEqual(data['CLO Analysis'][address].value,'n.a.')
            self.assertTrue(formulas['CLO Analysis'][address].value.startswith('=IFERROR('))
        for row in range(44,53):self.assertEqual(data['CLO Analysis'][f'H{row}'].value,'Not selected')

    def test_inherited_limits_and_debt_options_follow_raw_owners_without_changing_them(self):
        package=self.package()
        raw={'Limit ID':'COUNTRY_CUSTOM','Metric':'LARGEST_COUNTRY_FRACTION','Direction':'MAXIMUM','Threshold':0.25,'Applicable phase':'','Enabled':True}
        raw_info=package.add_table('tbl_trident_ui_limits',tuple(raw),(raw,))
        package.add_table('tbl_trident_ui_inherited_limits',('Limit ID','Metric','Direction','Threshold','Enabled','Owner'),
                          ({'Limit ID':'STALE','Metric':'OLD','Direction':'OLD','Threshold':0,'Enabled':True,'Owner':'OLD'},)*13)
        stack=({'Tranche':'AA','Type':'DEBT'},{'Tranche':'RES','Type':'EQUITY'})
        package.add_table('tbl_trident_ui_stack',('Tranche','Type'),stack)
        package.add_table('tbl_trident_ui_ui_options_debt_class',('Option',),({'Option':'OLD'+str(i)} for i in range(5)))
        package.protected_tables=frozenset((*package.protected_tables,'tbl_trident_ui_limits','tbl_trident_ui_stack'))
        before_limits=package._table_records('tbl_trident_ui_limits');before_stack=package._table_records('tbl_trident_ui_stack')
        spec=SimpleNamespace(limit_id='LEGACY_MINIMUM_COLLATERAL_WAS',metric='WAS_BPS',threshold=Decimal('350'),direction='MINIMUM')
        run=SimpleNamespace(inputs=SimpleNamespace(request=SimpleNamespace(limits=(spec,))))
        package.refresh_input_derived_views(run)
        inherited=package._table_records('tbl_trident_ui_inherited_limits')
        self.assertEqual([row['Limit ID'] for row in inherited],['COUNTRY_CUSTOM','LEGACY_MINIMUM_COLLATERAL_WAS'])
        self.assertEqual(inherited[0]['Threshold'],0.25)
        self.assertEqual(inherited[1]['Threshold'],350)
        self.assertEqual(package._table_records('tbl_trident_ui_ui_options_debt_class'),[{'Option':'AA'}])
        sheet,bounds=package.named_region('trident_ui_ui_options_debt_class')
        self.assertEqual(bounds[1],bounds[3])
        self.assertEqual(package._table_records('tbl_trident_ui_limits'),before_limits)
        self.assertEqual(package._table_records('tbl_trident_ui_stack'),before_stack)


if __name__ == '__main__':
    unittest.main()
