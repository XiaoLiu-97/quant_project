"""Independent small examples for event-date quality and actual held par.

Expected concentrations, margins and par are calculated from the stated two-
holding or single-bullet fixtures. A coupon dip/recovery between waterfall
dates must be visible without adding cash distributions or rate queries.
"""

from dataclasses import replace
from datetime import date, datetime, timedelta
from decimal import Decimal
from fractions import Fraction
import unittest
from unittest.mock import patch

from trident.analysis import LimitDirection, LimitSpec, LimitStatus, MetricStatus
from trident.application.clo_services import TridentModelService
from trident.application.coupon_timeline import CouponTimeline
from trident.application.imported_cashflows import (
    CollateralCashflowInputMode, DetailedImportedCashflow, ImportedCollateralProjection,
    compile_imported_cashflows,
)
from trident.application.portfolio_observations import (
    PortfolioObservationCalendar, build_portfolio_observations,
)
from trident.application.portfolio_phases import ACTIVE_PORTFOLIO_PHASES
from trident.application.portfolio_snapshots import (
    PortfolioStateScanner, _principal_reference, build_portfolio_snapshots,
)
from trident.clo.models import DefaultedAssetOcTreatment, ProjectionStatus
from trident.clo.reinvestment import SyntheticReinvestmentLedger, SyntheticReinvestmentPolicy
from trident.credit.models import AssetCashSource, DefaultEvent, PrepaymentEvent
from trident.credit.overlay import OverlayParMovement
from trident.conventions import AccrualDateBasis, BusinessDayConvention
from trident.domain.models import AmortizationType, CouponStep, CouponStepPolicy, InputValidationError
from trident.funding import AssetPurchase
from trident.market import FlatRateProvider

from test_dated_coupon_analytics import APRIL, END, FEB, START, model_request
from test_clo import receipt


D = Decimal
DIP, RECOVERY = date(2026, 2, 1), date(2026, 3, 1)


def quarterly_request(*, steps=(), policy=CouponStepPolicy.ACTUAL_DATE, floating=True):
    """One10000par bullet; CLO pays quarterly rather than the monthly base."""
    request = model_request(floating=floating, stepped=False)
    position = request.cashflow_request.positions[0]
    position = replace(position, terms=replace(position.terms,
        coupon_steps=steps, coupon_step_policy=policy))
    return replace(request, cashflow_request=replace(request.cashflow_request, positions=(position,)),
                   clo_terms=replace(request.clo_terms, frequency_months=3))


def observe(request, result, **changes):
    """Exercise the public calendar independently of application orchestration."""
    options = dict(closing_date=START, factor_mapping=request.factor_mapping, limits=request.limits,
        reinvestment_end_date=request.reinvestment_end_date, credit_projections=result.credit_projections,
        original_overlay_projection=result.clo.original_overlay_projection,
        reinvestment_policy=request.clo_terms.synthetic_reinvestment_policy,
        legal_final_date=request.clo_terms.legal_final_date,
        imported_collateral=request.imported_collateral,
        coupon_timeline=CouponTimeline(request.cashflow_request.positions))
    options.update(changes)
    return build_portfolio_observations(request.exposures, result.cashflows.cashflows, result.clo, **options)


class PortfolioObservationCalendarTests(unittest.TestCase):
    def test_union_is_bounded_sorted_and_deduplicated(self):
        calendar = PortfolioObservationCalendar(START, APRIL)
        result = calendar.collect(payment_dates=(APRIL,), holding_event_dates=(DIP, DIP),
            coupon_change_dates=(RECOVERY, START - timedelta(days=1), END),
            reinvestment_end_date=FEB, additional_dates=(APRIL, DIP))
        self.assertEqual(result, (START, DIP, FEB, RECOVERY, APRIL))

    def test_explicit_date_outside_actual_horizon_rejects(self):
        for invalid in (START - timedelta(days=1), APRIL + timedelta(days=1)):
            with self.subTest(invalid=invalid), self.assertRaisesRegex(InputValidationError, "actual projection horizon"):
                PortfolioObservationCalendar(START, APRIL).collect(additional_dates=(invalid,))

    def test_explicit_dates_are_a_strict_immutable_date_tuple(self):
        for invalid in ([DIP], (datetime(2026, 2, 1),), ("2026-02-01",), (None,), None):
            with self.subTest(invalid=invalid), self.assertRaises(InputValidationError):
                PortfolioObservationCalendar(START, APRIL).collect(additional_dates=invalid)
        for closing, horizon in ((datetime(2026, 1, 20), APRIL), (START, datetime(2026, 4, 20)), (APRIL, START)):
            with self.subTest(closing=closing, horizon=horizon), self.assertRaises(InputValidationError):
                PortfolioObservationCalendar(closing, horizon)

    def test_outside_phase_boundary_is_not_an_extra_lifecycle_period(self):
        calendar = PortfolioObservationCalendar(START, APRIL)
        self.assertEqual(calendar.collect(reinvestment_end_date=END), (START, APRIL))


class NativeDatedQualityTests(unittest.TestCase):
    def test_dip_and_recovery_between_quarterly_payments_are_both_observed(self):
        request = quarterly_request(steps=(CouponStep(DIP, spread_bps=D(200)),
                                          CouponStep(RECOVERY, spread_bps=D(500))))
        limit = LimitSpec("WAS", "WAS_BPS", D(400), LimitDirection.MINIMUM, ACTIVE_PORTFOLIO_PHASES)
        request = replace(request, limits=(limit,))
        result = TridentModelService().run(request)
        reports = {row.as_of_date: row for row in observe(request, result)}
        self.assertEqual(reports[DIP].metric("WAS_BPS").value, D(200))
        self.assertIs(reports[DIP].limits[0].status, LimitStatus.BREACH)
        self.assertEqual(reports[RECOVERY].metric("WAS_BPS").value, D(500))
        self.assertIs(reports[RECOVERY].limits[0].status, LimitStatus.PASS)
        self.assertTrue(all(row.limits[0].status in (LimitStatus.PASS, LimitStatus.NOT_APPLICABLE)
                            for row in result.portfolio_snapshots))
        # The richer quality timeline still creates exactly four distributions.
        self.assertEqual(len(result.clo.periods), 4)
        self.assertEqual(len(result.portfolio_snapshots), 4)

    def test_original_reset_start_defers_the_observation_not_only_the_margin(self):
        request = quarterly_request(steps=(CouponStep(DIP, spread_bps=D(200)),),
                                    policy=CouponStepPolicy.RESET_START)
        position = request.cashflow_request.positions[0]
        position = replace(position, terms=replace(position.terms, reset_frequency_months=6,
                                                  rate_index="EURIBOR_6M"))
        request = replace(request, cashflow_request=replace(request.cashflow_request, positions=(position,),
            rate_provider=FlatRateProvider({"EURIBOR_6M": D(0)})))
        result = TridentModelService().run(request)
        timeline = CouponTimeline(request.cashflow_request.positions)
        self.assertEqual(timeline.effective_change_dates, (date(2026, 7, 20),))
        reports = observe(request, result)
        self.assertNotIn(DIP, tuple(row.as_of_date for row in reports))
        self.assertEqual(reports[1].metric("WAS_BPS").value, D(500))
        self.assertEqual(reports[2].metric("WAS_BPS").value, D(200))

    def test_payment_start_fixed_wac_uses_original_payment_start(self):
        request = quarterly_request(floating=False, policy=CouponStepPolicy.PAYMENT_START,
            steps=(CouponStep(DIP, fixed_rate=D(".06")),))
        result = TridentModelService().run(request)
        timeline = CouponTimeline(request.cashflow_request.positions)
        self.assertEqual(timeline.effective_change_dates, (APRIL,))
        reports = {row.as_of_date: row for row in observe(request, result, additional_dates=(DIP,))}
        self.assertEqual(reports[DIP].metric("WAC_RATE").value, D(".04"))
        self.assertEqual(reports[APRIL].metric("WAC_RATE").value, D(".06"))

    def test_superseded_deferred_dip_creates_no_fictitious_observation(self):
        request = quarterly_request(policy=CouponStepPolicy.RESET_START,
            steps=(CouponStep(DIP, spread_bps=D(200)), CouponStep(RECOVERY, spread_bps=D(500))))
        result = TridentModelService().run(request)
        self.assertEqual(CouponTimeline(request.cashflow_request.positions).effective_change_dates, ())
        self.assertEqual(tuple(row.as_of_date for row in observe(request, result)),
                         (START, *tuple(period.payment_date for period in result.clo.periods)))

    def test_deferred_first_start_uses_adjusted_target_holiday_boundary(self):
        request = quarterly_request()
        position = request.cashflow_request.positions[0]
        position = replace(position, par_as_of_date=date(2026, 4, 4), terms=replace(position.terms,
            start_date=date(2026, 4, 4), maturity_date=date(2026, 10, 4),
            business_day_convention=BusinessDayConvention.MODIFIED_FOLLOWING,
            accrual_date_basis=AccrualDateBasis.ADJUSTED,
            coupon_step_policy=CouponStepPolicy.RESET_START,
            coupon_steps=(CouponStep(date(2026, 4, 5), spread_bps=D(200)),)))
        timeline = CouponTimeline((position,))
        # Apr4Saturday / Apr5Sunday / Apr6EasterMonday defer the initial reset.
        self.assertEqual(timeline.effective_change_dates, (date(2026, 4, 7),))
        exposures = (replace(request.exposures[0], maturity_date=date(2026, 10, 4)),)
        self.assertEqual(timeline.at(exposures, date(2026, 4, 6))[0].spread_bps, D(500))
        self.assertEqual(timeline.at(exposures, date(2026, 4, 7))[0].spread_bps, D(200))

    def test_observations_never_query_additional_market_fixings(self):
        request = quarterly_request(steps=(CouponStep(DIP, spread_bps=D(200)),))
        result = TridentModelService().run(request)
        with patch.object(FlatRateProvider, "rate", side_effect=AssertionError("Quality calendar queried a fixing")):
            reports = observe(request, result, additional_dates=(FEB, RECOVERY))
        self.assertEqual(next(row for row in reports if row.as_of_date == DIP).metric("WAS_BPS").value, D(200))

    def test_other_asset_step_during_adjusted_maturity_gap_preserves_held_par(self):
        request = quarterly_request(steps=(CouponStep(date(2026, 4, 19), spread_bps=D(300)),))
        long = request.cashflow_request.positions[0]
        short = replace(long, terms=replace(long.terms, loan_id="SHORT", maturity_date=date(2026, 4, 18),
            coupon_steps=(), business_day_convention=BusinessDayConvention.MODIFIED_FOLLOWING,
            accrual_date_basis=AccrualDateBasis.ADJUSTED))
        short_exposure = replace(request.exposures[0], loan_id="SHORT", maturity_date=date(2026, 4, 18))
        request = replace(request, exposures=(request.exposures[0], short_exposure),
            cashflow_request=replace(request.cashflow_request, positions=(long, short),
                purchases=(AssetPurchase("L", D(10000), D(100)), AssetPurchase("SHORT", D(10000), D(100)))))
        # SHORT is nominally due Saturday18th, contractually pays Monday20th.
        # L's Sunday19th step still creates a legitimate quality observation;
        # neither ignoring SHORT nor replacing its maturity is economically valid.
        result = TridentModelService().run(request)
        report = next(row for row in result.portfolio_observations if row.as_of_date == date(2026, 4, 19))
        self.assertEqual(report.total_par, D(20000))
        self.assertEqual(report.metric("WAS_BPS").value, D(400))
        self.assertIs(report.metric("WAL_YEARS").status, MetricStatus.AVAILABLE)
        # Equal par, actual remaining principal receipts in1 and276days.
        self.assertLess(abs(Fraction(report.metric("WAL_YEARS").value) - Fraction(277, 730)), Fraction(1, 10**25))
        self.assertIs(report.metric("WEIGHTED_AVERAGE_MATURITY_YEARS").status, MetricStatus.UNAVAILABLE)

    def test_preceding_maturity_receipt_removes_par_before_other_asset_step(self):
        request = quarterly_request(steps=(CouponStep(date(2026, 4, 19), spread_bps=D(300)),))
        long = request.cashflow_request.positions[0]
        short = replace(long, terms=replace(long.terms, loan_id="SHORT", maturity_date=date(2026, 4, 18),
            coupon_steps=(), business_day_convention=BusinessDayConvention.PRECEDING,
            accrual_date_basis=AccrualDateBasis.ADJUSTED))
        short_exposure = replace(request.exposures[0], loan_id="SHORT", maturity_date=date(2026, 4, 18))
        request = replace(request, exposures=(request.exposures[0], short_exposure),
            cashflow_request=replace(request.cashflow_request, positions=(long, short),
                purchases=(AssetPurchase("L", D(10000), D(100)), AssetPurchase("SHORT", D(10000), D(100)))))
        # PRECEDING pays nominalSaturday18th on Friday17th. The holding is
        # already gone when L's Sunday19th step creates another observation;
        # maturity-gap evidence must neither retain nor resurrect SHORT.
        with patch("trident.application.portfolio_snapshots.ScheduledMaturityReceipt",
                   side_effect=AssertionError("Repaid PRECEDING asset needs no pending-receipt proof")):
            result = TridentModelService().run(request)
        short_row, = tuple(row for row in result.cashflows.cashflows if row.loan_id == "SHORT")
        self.assertEqual(short_row.payment_date, date(2026, 4, 17))
        self.assertEqual(short_row.principal_repayment, D(10000))
        self.assertEqual(short_row.closing_balance, D(0))
        reports = {row.as_of_date: row for row in result.portfolio_observations}
        self.assertEqual(reports[date(2026, 4, 17)].total_par, D(10000))
        after_step = reports[date(2026, 4, 19)]
        self.assertEqual(after_step.asset_count, 1)
        self.assertEqual(after_step.total_par, D(10000))
        self.assertEqual(after_step.metric("WAS_BPS").value, D(300))
        wam = after_step.metric("WEIGHTED_AVERAGE_MATURITY_YEARS")
        self.assertIs(wam.status, MetricStatus.AVAILABLE)
        self.assertLess(abs(Fraction(wam.value) - Fraction(276, 365)), Fraction(1, 10**25))
        self.assertTrue(all(row.total_par == D(10000) for row in result.portfolio_observations
                            if date(2026, 4, 17) <= row.as_of_date < END))

    def test_payment_report_subset_retains_full_previous_metrics(self):
        request = quarterly_request(steps=(CouponStep(DIP, spread_bps=D(200)),))
        result = TridentModelService().run(request)
        old = build_portfolio_snapshots(request.exposures, result.cashflows.cashflows, result.clo,
            coupon_timeline=CouponTimeline(request.cashflow_request.positions),
            legal_final_date=request.clo_terms.legal_final_date)
        new = observe(request, result)
        payments = {period.payment_date for period in result.clo.periods}
        self.assertEqual(old, tuple(report for report in new if report.as_of_date in payments))

    def test_midquarter_phase_boundary_applies_exclusive_quality_policy(self):
        request = replace(quarterly_request(), reinvestment_end_date=DIP,
            limits=(LimitSpec("LIVE", "WAS_BPS", D(400), LimitDirection.MINIMUM, ("REINVESTMENT",)),))
        result = TridentModelService().run(request)
        reports = {row.as_of_date: row for row in observe(request, result, additional_dates=(date(2026, 1, 31),))}
        self.assertEqual(reports[date(2026, 1, 31)].phase, "REINVESTMENT")
        self.assertEqual(reports[DIP].phase, "POST_REINVESTMENT")
        self.assertIs(reports[DIP].limits[0].status, LimitStatus.NOT_APPLICABLE)
        self.assertEqual(reports[START].phase, "CLOSING")


class ActualHoldingLedgerTests(unittest.TestCase):
    def test_indexed_surviving_principal_preserves_independent_cent_targets(self):
        exposure = replace(quarterly_request().exposures[0], par=D(1))
        rows = (receipt("L", 1, START, FEB, "3", "1", "0"),
                receipt("L", 2, FEB, date(2026, 3, 20), "2", "1", "0"),
                receipt("L", 3, date(2026, 3, 20), APRIL, "1", "1", "0"))
        # A surviving1/3slice has cumulative cent targets .33,.67,1.00;
        # allocation is .33,.34,.33 and totals exactly1, not three .33.
        opening = _principal_reference(rows, (exposure,), START)
        self.assertEqual([row.principal_repayment for row in opening], [D(".33"), D(".34"), D(".33")])
        self.assertEqual([row.closing_balance for row in opening], [D(".67"), D(".33"), D(0)])
        # On a post-event date, that day's receipt is excluded before scaling.
        remaining = _principal_reference(rows, (replace(exposure, par=D(".67")),), FEB)
        self.assertEqual([row.principal_repayment for row in remaining], [D(".34"), D(".33")])

    def test_midquarter_prepaid_holding_changes_concentration_immediately(self):
        request = quarterly_request()
        original = request.cashflow_request.positions[0]
        other = replace(original, terms=replace(original.terms, loan_id="C"))
        cash = replace(request.cashflow_request, positions=(original, other),
            purchases=(AssetPurchase("L", D(10000), D(100)), AssetPurchase("C", D(10000), D(100))))
        exposures = (request.exposures[0], replace(request.exposures[0], loan_id="C", country="DE", obligor="C"))
        limit = LimitSpec("FR", "concentration:country:FR", D(".6"), phases=ACTIVE_PORTFOLIO_PHASES)
        request = replace(request, cashflow_request=cash, exposures=exposures, limits=(limit,),
                          credit_events=(PrepaymentEvent("C", DIP),))
        result = TridentModelService().run(request)
        reports = {row.as_of_date: row for row in observe(request, result)}
        self.assertEqual(reports[START].total_par, D(20000))
        self.assertEqual(reports[START].limits[0].value, D(".5"))
        self.assertEqual(reports[DIP].total_par, D(10000))
        self.assertEqual(reports[DIP].limits[0].value, D(1))
        self.assertIs(reports[DIP].limits[0].status, LimitStatus.BREACH)

    def test_default_removes_performing_par_without_inventing_principal_receipt(self):
        base = quarterly_request()
        request = replace(base, credit_events=(DefaultEvent("L", DIP),),
            clo_terms=replace(base.clo_terms, defaulted_asset_oc_treatment=DefaultedAssetOcTreatment.EXCLUDE))
        result = TridentModelService().run(request)
        report = next(row for row in observe(request, result) if row.as_of_date == DIP)
        self.assertEqual(report.total_par, D(0))
        self.assertEqual(result.credit_projections[0].total_principal_collections, D(0))
        self.assertEqual(result.clo.final_defaulted_par, D(10000))
        self.assertEqual(report.phase, "POST_REINVESTMENT")
        self.assertIs(report.metric("WAS_BPS").status, MetricStatus.UNAVAILABLE)

    def test_non_clo_asset_amortisation_date_is_observed(self):
        request = quarterly_request()
        position = request.cashflow_request.positions[0]
        position = replace(position, terms=replace(position.terms, frequency_months=1, reset_frequency_months=3,
            amortization_type=AmortizationType.LINEAR_AMOUNT, scheduled_principal_amount=D(1000)))
        request = replace(request, cashflow_request=replace(request.cashflow_request, positions=(position,)))
        result = TridentModelService().run(request)
        reports = {row.as_of_date: row for row in observe(request, result)}
        self.assertEqual(reports[FEB].total_par, D(9000))
        self.assertEqual(reports[date(2026, 3, 20)].total_par, D(8000))
        self.assertEqual(reports[APRIL].total_par, D(7000))

    def test_imported_midquarter_bridge_drives_par_and_ignores_native_steps(self):
        request = quarterly_request(steps=(CouponStep(RECOVERY, spread_bps=D(200)),))
        source = compile_imported_cashflows(CollateralCashflowInputMode.DETAILED, START, D(10000),
            detailed_rows=(DetailedImportedCashflow("L", 1, DIP, D(10000), D(0), D(2000), D(8000), D(2000)),
                           DetailedImportedCashflow("L", 2, END, D(8000), D(0), D(8000), D(0), D(8000))))
        request = replace(request, imported_collateral=source)
        result = TridentModelService().run(request)
        reports = {row.as_of_date: row for row in observe(request, result)}
        self.assertEqual(reports[DIP].total_par, D(8000))
        self.assertNotIn(RECOVERY, reports)
        self.assertIs(reports[DIP].metric("WAS_BPS").status, MetricStatus.UNAVAILABLE)

    def test_same_day_purchase_precedes_its_par_movement(self):
        request = quarterly_request()
        result = TridentModelService().run(request)
        policy = SyntheticReinvestmentPolicy(True, APRIL, spread_bps=D(600), purchase_price=D(1),
            annual_default_rate=D(0), annual_prepayment_rate=D(0))
        cohort = SyntheticReinvestmentLedger(policy, request.cashflow_request.rate_provider).purchase(DIP, D(10000))
        movement = OverlayParMovement(cohort.cohort_id, DIP, AssetCashSource.SCHEDULED,
            D(10000), D(9000), D(0), D(0), D(1000), D(0))
        period = replace(result.clo.periods[0], closing_collateral_par=D(19000))
        clo = replace(result.clo, periods=(period,), reinvestment_purchases=(cohort,),
            reinvestment_par_movements=(movement,), status=ProjectionStatus.LEGAL_FINAL_UNRESOLVED,
            terminal_value_available=False, final_collateral_par=D(19000))
        reports = build_portfolio_observations(request.exposures, result.cashflows.cashflows, clo,
            closing_date=START, reinvestment_policy=policy,
            coupon_timeline=CouponTimeline(request.cashflow_request.positions))
        report = next(row for row in reports if row.as_of_date == DIP)
        self.assertEqual(report.total_par, D(19000))
        #10000at500 +9000at600, not the original10000cohort par.
        self.assertLess(abs(Fraction(report.metric("WAS_BPS").value) - Fraction(10400000, 19000)), Fraction(1, 10**25))

    def test_imported_empty_movement_audit_does_not_activate_native_par_tape(self):
        request = quarterly_request()
        position = request.cashflow_request.positions[0]
        position = replace(position, terms=replace(position.terms,
            amortization_type=AmortizationType.LINEAR_AMOUNT, scheduled_principal_amount=D(1000)))
        request = replace(request, cashflow_request=replace(request.cashflow_request, positions=(position,)))
        result = TridentModelService().run(request)
        source = ImportedCollateralProjection((), (), D(10000), {"L": D(10000)}, {"L": END},
            CollateralCashflowInputMode.DETAILED, False, projection_start_date=START)
        period = replace(result.clo.periods[0], closing_collateral_par=D(10000))
        clo = replace(result.clo, periods=(period,), terminal_value_available=False,
                      status=ProjectionStatus.LEGAL_FINAL_UNRESOLVED, final_collateral_par=D(10000))
        reports = build_portfolio_observations(request.exposures, result.cashflows.cashflows, clo,
            closing_date=START, imported_collateral=source)
        self.assertEqual([report.total_par for report in reports], [D(10000), D(10000)])
        self.assertIs(reports[-1].metric("WAL_YEARS").status, MetricStatus.UNAVAILABLE)

    def test_sale_locks_book_against_later_unused_contractual_movements(self):
        request = quarterly_request()
        result = TridentModelService().run(request)
        first = replace(result.clo.periods[0], collateral_sale_par=D(10000), closing_collateral_par=D(0))
        second = replace(result.clo.periods[1], closing_collateral_par=D(0))
        # Historical source coupon rows continue to show10000par after the
        # earlier sale; no remaining right to that reference may reappear.
        clo = replace(result.clo, periods=(first, second), final_collateral_par=D(0))
        reports = build_portfolio_observations(request.exposures, result.cashflows.cashflows, clo,
            closing_date=START, additional_dates=(date(2026, 5, 1),))
        self.assertEqual([row.total_par for row in reports], [D(10000), D(0), D(0), D(0)])
        self.assertEqual(reports[-1].phase, "TERMINATED")

    def test_reconciliation_is_required_at_every_clo_payment(self):
        request = quarterly_request()
        result = TridentModelService().run(request)
        incorrect = replace(result.clo.periods[0], closing_collateral_par=D(9999))
        clo = replace(result.clo, periods=(incorrect, *result.clo.periods[1:]))
        with self.assertRaisesRegex(ArithmeticError, "performing-par ledger"):
            build_portfolio_observations(request.exposures, result.cashflows.cashflows, clo, closing_date=START)

    def test_only_complete_zero_claim_state_suppresses_active_phase_limit(self):
        request = replace(quarterly_request(), limits=(LimitSpec("LIVE", "WAS_BPS", D(400),
            LimitDirection.MINIMUM, ACTIVE_PORTFOLIO_PHASES),))
        result = TridentModelService().run(request)
        complete = observe(request, result)[-1]
        self.assertEqual(complete.phase, "TERMINATED")
        self.assertIs(complete.limits[0].status, LimitStatus.NOT_APPLICABLE)
        for field, value in (("final_defaulted_par", D(1)), ("final_debt_par", D(1)),
                             ("final_senior_claims", D(1)), ("final_pending_principal_cash", D(1))):
            clo = replace(result.clo, **{field: value})
            report = build_portfolio_observations(request.exposures, result.cashflows.cashflows, clo,
                closing_date=START, limits=request.limits)[-1]
            self.assertEqual(report.phase, "POST_REINVESTMENT")
            self.assertIs(report.limits[0].status, LimitStatus.UNAVAILABLE)

    def test_scanner_rejects_backward_or_mutable_observation_sequence(self):
        request = quarterly_request()
        result = TridentModelService().run(request)
        for dates in ([START], (FEB, START), (START, START), (datetime(2026, 1, 20),)):
            scanner = PortfolioStateScanner(request.exposures, result.cashflows.cashflows, result.clo)
            with self.subTest(dates=dates), self.assertRaises(InputValidationError):
                scanner.scan(dates)


if __name__ == "__main__":
    unittest.main()
