"""Translate semantic dated credit inputs without guessing rating assumptions."""

from collections.abc import Mapping

from trident.credit import DefaultEvent, PrepaymentEvent, RecoveryEvent
from trident.domain.models import InputValidationError
from .records import date_value, decimal_value, text_value


def credit_events_from_records(
    event_rows: tuple[Mapping[str, object], ...], recovery_rows: tuple[Mapping[str, object], ...], *,
    loan_ids: frozenset[str],
) -> tuple[DefaultEvent | PrepaymentEvent, ...]:
    """Read one full exit/default per known held asset; dates are actual dates.

    Recovery fractions refer to remaining exposure at default. They are never
    inferred from a rating or a factor. Recovery input is sorted by actual date,
    with duplicate dates rejected by the typed schedule rather than merged.
    An empty recovery table is valid for an explicitly supplied default.
    """
    event_by_loan: dict[str, Mapping[str, object]] = {}
    for row in event_rows:
        unknown = set(row) - {"loan_id", "event_type", "event_date", "writeoff_date"}
        if unknown:
            raise InputValidationError(f"Unregistered credit event fields: {sorted(unknown)}")
        loan_id = text_value(row.get("loan_id"), "credit loan_id")
        if loan_id not in loan_ids:
            raise InputValidationError(f"Unknown credit event loan_id: {loan_id}")
        if loan_id in event_by_loan:
            raise InputValidationError(f"Duplicate terminating credit event: {loan_id}")
        event_by_loan[loan_id] = row
    recoveries: dict[str, list[RecoveryEvent]] = {}
    for row in recovery_rows:
        unknown = set(row) - {"loan_id", "recovery_date", "recovery_fraction"}
        if unknown:
            raise InputValidationError(f"Unregistered recovery fields: {sorted(unknown)}")
        loan_id = text_value(row.get("loan_id"), "recovery loan_id")
        event = event_by_loan.get(loan_id)
        if event is None or event.get("event_type") != "DEFAULT":
            raise InputValidationError(f"Recovery schedule requires a DEFAULT event for loan_id: {loan_id}")
        recoveries.setdefault(loan_id, []).append(RecoveryEvent(
            date_value(row.get("recovery_date"), "recovery_date"),
            decimal_value(row.get("recovery_fraction"), "recovery_fraction"),
        ))
    result: list[DefaultEvent | PrepaymentEvent] = []
    for loan_id, row in event_by_loan.items():
        event_type = text_value(row.get("event_type"), "event_type")
        event_date = date_value(row.get("event_date"), "event_date")
        raw_writeoff = row.get("writeoff_date")
        writeoff_date = None if raw_writeoff is None or raw_writeoff == "" else date_value(raw_writeoff, "writeoff_date")
        if event_type == "DEFAULT":
            schedule = tuple(sorted(recoveries.get(loan_id, ()), key=lambda item: item.recovery_date))
            result.append(DefaultEvent(loan_id, event_date, schedule, writeoff_date))
        elif event_type == "PREPAYMENT":
            if writeoff_date is not None:
                raise InputValidationError("PREPAYMENT cannot specify a writeoff_date")
            result.append(PrepaymentEvent(loan_id, event_date))
        else:
            raise InputValidationError(f"Unsupported credit event_type: {event_type}; expected DEFAULT or PREPAYMENT")
    return tuple(result)
