"""One immutable interface snapshot -> complete calculations -> atomic publish.

Every scenario is derived from the original request. A static trade mandate
does not execute trades; closing candidate search additionally reconstructs
funding and replays the complete CLO before ranking feasible equity returns.
"""
from dataclasses import dataclass
from pathlib import Path
from typing import Mapping

from trident.application.candidate_search import ClosingPoolSearchService, ModelProjectionCache
from trident.application.clo_services import TridentModelRequest, TridentModelResult
from trident.application.scenarios import ScenarioResult, ScenarioRunner
from trident.domain.models import InputValidationError
from trident.optimization import StaticTradeOptimizer
from .candidate_records import candidate_search_from_records
from .interface_inputs import InterfaceWorkbookInputs, read_interface_inputs
from .optimization_records import optimization_request_from_records


@dataclass(frozen=True)
class InterfaceCase:
    case_id: str
    request: TridentModelRequest
    result: TridentModelResult
    origin: str


@dataclass(frozen=True)
class InterfaceRun:
    """All outputs belong to this one input fingerprint and software policy."""
    inputs: InterfaceWorkbookInputs
    cases: tuple[InterfaceCase, ...]
    comparisons: tuple[object, ...] = ()
    period_comparisons: tuple[object, ...] = ()
    optimization: object = None
    search: object = None
    library_projection: object = None

    @property
    def baseline(self):
        return self.cases[0].result


def calculate_interface(inputs: InterfaceWorkbookInputs) -> InterfaceRun:
    """Calculate without modifying a workbook or requesting outside market data.

    A cache is scoped to this run; it checks the complete typed request, so a
    modified price, fee, curve or credit assumption cannot reuse stale results.
    Failure propagates before the writer is created, leaving old output intact.
    """
    service = ModelProjectionCache()
    request, controls = inputs.request, inputs.controls
    if request.clo_opening_state is None:
        runner = ScenarioRunner(service=service)
    else:
        from trident.application.opening_scenarios import StaticOpeningScenarioService
        runner = StaticOpeningScenarioService(service=service)
    batch = runner.run(request, inputs.scenarios)
    cases = [InterfaceCase('BASELINE', request, batch.baseline, 'BASELINE')]
    cases.extend(InterfaceCase(s.scenario_id, s.request, s.result, 'WHAT_IF') for s in batch.scenarios)
    comparisons = [row for s in batch.scenarios for row in s.comparisons]
    periods = [row for s in batch.scenarios for row in s.period_comparisons]
    optimization = search = None
    if controls['candidate_search_enabled']:
        if request.clo_terms is None:
            raise InputValidationError('Equity-return candidate search requires a full CLO workflow')
        from .interface_inputs import closing_candidate_request
        search_request = closing_candidate_request(inputs,batch.baseline)
        search = ClosingPoolSearchService(service=service).run(search_request)
        identities = {c.case_id.casefold() for c in cases}
        for evaluation in search.evaluations:
            replay = evaluation.replay
            if replay is None or replay.target_result is None or replay.target_request is None:
                continue
            case_id = 'OPT_' + evaluation.candidate_id
            if case_id.casefold() in identities:
                raise InputValidationError('Scenario name collides with optimizer result: ' + case_id)
            identities.add(case_id.casefold())
            cases.append(InterfaceCase(case_id, replay.target_request, replay.target_result,
                                       'OPTIMIZER_VALIDATED' if replay.validated else 'OPTIMIZER_REJECTED'))
            from dataclasses import replace
            comparisons.extend(replace(row, scenario_id=case_id) for row in replay.comparisons)
            periods.extend(replace(row, scenario_id=case_id) for row in replay.period_comparisons)
    elif controls.get('optimizer_enabled'):
        from .interface_inputs import static_optimization_request
        optimization = StaticTradeOptimizer().solve(static_optimization_request(inputs,batch.baseline))
    from .interface_inputs import project_library_cashflows
    library=project_library_cashflows(inputs)
    return InterfaceRun(inputs, tuple(cases), tuple(comparisons), tuple(periods), optimization, search,library)


def run_interface_workbook(path, output=None) -> InterfaceRun:
    """Publish one complete model only after every selected calculation succeeds."""
    source = Path(path).resolve()
    destination = Path(output).resolve() if output is not None else source
    inputs = read_interface_inputs(source)
    run = calculate_interface(inputs)
    from .interface_output import write_interface_run
    write_interface_run(source, destination, run)
    return run


def check_interface_workbook(path, *, project=False) -> dict:
    """Read-only preflight; unavailable analytical data is separately disclosed."""
    inputs = read_interface_inputs(path)
    report = dict(status='INPUTS_VALIDATED', input_fingerprint=inputs.input_fingerprint,
                  workflow=inputs.controls['workflow'], held_assets=len(inputs.assets),
                  library_assets=len(inputs.library_assets), scenarios=len(inputs.scenarios),
                  warnings=list(inputs.warnings), checks_scope='INPUTS_ONLY')
    if project:
        run = calculate_interface(inputs)
        report.update(status='CALCULATED', checks_scope='COMPLETE_SELECTED_SERVICES',
                      cases=[c.case_id for c in run.cases],
                      clo_status=None if run.baseline.clo is None else run.baseline.clo.status.value,
                      equity_irr=str(run.baseline.equity_irr.value),
                      unavailable_limits=[l.limit_id for l in run.baseline.opening_portfolio.limits if l.status.value=='UNAVAILABLE'],
                      breached_limits=[l.limit_id for l in run.baseline.opening_portfolio.limits if l.status.value=='BREACH'])
    return report
