"""An event-driven, cash-conserving executable H00 CLO waterfall.

The asset collection stream is sorted once. Performing-par fee integrals use
prefix par-days and binary search, rather than repeatedly scanning every loan.
Business dates/rates are shared with the standalone contractual cashflow engine.
No spreadsheet, investment optimizer, or external service enters this module.

Read ``_run`` in payment-date order: compile collections and par timelines;
receive actual cash and release the determination-date eligible portion;
accrue fees/coupons; execute the interest waterfall and coverage cures; process
independent IDT and lifecycle events; execute the principal waterfall; publish
snapshots and verify ledgers. That ordering is part of the configured model.
Splitting it into independently reordered calculations would change which
cash, debt balances and deferred claims exist at a coverage-test node.
"""

from bisect import bisect_right
from dataclasses import dataclass, replace
from datetime import date
from decimal import Context, Decimal, ROUND_HALF_EVEN, getcontext, localcontext
from fractions import Fraction
from typing import Protocol

from trident.conventions import AccrualPeriod, BusinessCalendar, DayCount, ScheduleBuilder, TargetCalendar, accrual_fraction
from trident.domain.models import CouponType, InputValidationError, LoanCashflow, require_date, require_decimal, require_money
from trident.domain.numeric import compose_floating_rate, decimal_fraction, post_currency
from trident.market.rates import RateProvider
from trident.credit.models import AssetCashSource, AssetParMovement, AssetCollection
from trident.credit.overlay import OverlayCollection, OverlayParMovement, PoolOverlayProjection
from trident.conventions.calendar import calendar_from_name
from trident.conventions.liability_rates import fixing_date_for_period, first_stub_reference_rate, FirstStubRateMethod
from .reinvestment import SyntheticReinvestmentLedger, ReinvestmentTestGate
from .lifecycle import AdjustedCollateralValuePolicy, AdjustedCollateralValue, EquityHurdleAccount, OcAssetBalance, OcAssetData, ShortfallAccrualMethod
from .opening import select_opening_periods
from .proceeds import classify_coupon_proceeds

from .models import (
    CloPeriodSummary, CloProjection, CloRunRequest, CoverageStatus,
    CoverageTestResult, DatedDistribution, NoteTranche, ProjectionStatus,
    TranchePeriodSnapshot, PrincipalRepaymentMode, PrincipalCouponPolicy, ManagementFeeBasis, InterestDiversionMode, CashAccountAccrualMode,
)


ZERO = Decimal(0)
_ParMovement = AssetParMovement | OverlayParMovement


class _ParTimeline(Protocol):
    """Minimal face/integral interface shared by original and purchased assets.

    Composition adds cohort balances without making fee logic depend on their
    implementation or forcing it to inherit from an original-pool timeline.
    """

    def balance_at(self, value: date) -> Decimal:
        """Return post-event face at the requested date."""
        ...

    def par_days(self, start: date, end: date) -> Fraction:
        """Return exact EUR face-days over the half-open interval."""
        ...


@dataclass(frozen=True)
class _Collection:
    """Keep borrower cash intact while exposing its legal account allocation.

    Restoration markers relabel coupon cash as principal proceeds; they never
    reduce loan face or fabricate a principal repayment. Keeping both views
    prevents the account routing from contaminating par, recovery, fee bases
    or bank-interest chronology.
    """

    loan_id: str
    payment_date: date
    cash_interest: Decimal
    principal_repayment: Decimal
    source: AssetCashSource = AssetCashSource.SCHEDULED
    principal_accrued_restored: Decimal = ZERO
    original_principal_accrued_permission: Decimal = ZERO

    @property
    def interest_proceeds(self) -> Decimal:
        """Coupon available to the interest account after sourced restoration."""
        return self.cash_interest - self.principal_accrued_restored

    @property
    def principal_proceeds(self) -> Decimal:
        """Actual face repayment plus the restored coupon component."""
        return self.principal_repayment + self.principal_accrued_restored


@dataclass
class _NoteState:
    """Per-run face par and opening coupon claim; public records are frozen.

    ``unpaid_coupon`` is updated only when the period snapshot is published.
    During the waterfall, the separate ``unpaid`` list is authoritative for
    payments and capitalized OC amounts at the current node.
    """

    tranche: NoteTranche
    balance: Decimal
    unpaid_coupon: Decimal = ZERO
    initially_inactive: bool = False


class _PerformingParTimeline:
    """Exact balances and integrals under repayment-at-actual-payment-date.

    The balance at an event date is the post-repayment balance. Integration is
    half-open [start, end), so principal paid on end does not reduce that day's
    preceding period fee. Prefix areas make each query O(log event dates).
    """

    def __init__(self, closing: date, opening_par: Decimal, events: dict[date, Decimal]) -> None:
        self._dates = [closing]
        self._balances = [opening_par]
        self._areas = [Fraction(0)]
        balance = opening_par
        area = Fraction(0)
        previous = closing
        for event_date, principal in sorted(events.items()):
            area += Fraction(balance) * (event_date - previous).days
            balance -= principal
            if balance < 0:
                raise InputValidationError("Asset par timeline would become negative")
            self._dates.append(event_date)
            self._balances.append(balance)
            self._areas.append(area)
            previous = event_date

    def balance_at(self, value: date) -> Decimal:
        """Return post-event par, including every movement on ``value``."""
        return self._balances[self._position(value)]

    def _position(self, value: date) -> int:
        if value < self._dates[0]:
            raise InputValidationError("Fee/coverage date precedes closing performing-par state")
        return bisect_right(self._dates, value) - 1

    def _area_to(self, value: date) -> Fraction:
        position = self._position(value)
        return self._areas[position] + Fraction(self._balances[position]) * (value - self._dates[position]).days

    def par_days(self, start: date, end: date) -> Fraction:
        """Integrate face over [start, end); units are EUR face times days."""
        return self._area_to(end) - self._area_to(start)


class _OcAssetInventory:
    """Join identified live par with immutable classification/price metadata.

    Aggregate performing par alone cannot identify which CCC or discount loan
    left the pool. Each original asset therefore has its own dated timeline;
    classification is applied to that asset's remaining par at each test date.
    Current marks are frozen scenario inputs here, not dynamically refreshed.
    """

    def __init__(self, request: CloRunRequest, movements: tuple[_ParMovement, ...]) -> None:
        grouped = {}
        for row in request.asset_cashflows:
            grouped.setdefault(row.loan_id, []).append(row)
        supplied = {row.loan_id: row for row in request.oc_asset_data}
        if request.imported_collateral is not None:
            for loan_id in request.imported_collateral.loan_opening_par:
                grouped[loan_id] = []
        if request.terms.adjusted_oc_policy is not None and request.terms.adjusted_oc_policy.use_asset_level_test_data:
            if set(supplied) != set(grouped):
                raise InputValidationError("Asset-level OC requires classification for every original asset")
        self._rows = []
        changes = {}
        for movement in movements:
            changes.setdefault(movement.loan_id, {})[movement.event_date] = (
                changes.setdefault(movement.loan_id, {}).get(movement.event_date, ZERO)
                + movement.performing_par_before - movement.performing_par_after)
        for loan_id, rows in grouped.items():
            if not rows:
                imported = request.imported_collateral
                events = changes.get(loan_id, {})
                timeline = _PerformingParTimeline(request.projection_start_date, imported.loan_opening_par[loan_id], events)
                self._rows.append((loan_id, timeline, imported.final_principal_dates[loan_id], supplied.get(loan_id, OcAssetData(loan_id))))
                continue
            rows.sort(key=lambda row: row.period_number)
            events = changes.get(loan_id)
            if events is None:
                events = {}
                for row in rows:
                    events[row.payment_date] = events.get(row.payment_date, ZERO) + row.principal_repayment
                    # PIK normally posts at accrual end; an advance-adjusted
                    # cash redemption needs that face by the earlier payment
                    # date. The contract's shared date policy never changes
                    # its nominal coupon factor or manufactures cash.
                    pik = getattr(row, "pik_interest", ZERO)
                    if pik:
                        day = row.pik_capitalization_date
                        events[day] = events.get(day, ZERO) - pik
            timeline = _PerformingParTimeline(request.projection_start_date, rows[0].opening_balance, events)
            self._rows.append((loan_id, timeline, rows[-1].payment_date, supplied.get(loan_id, OcAssetData(loan_id))))

    def balances_at(self, payment_date: date) -> tuple[OcAssetBalance, ...]:
        """Snapshot original assets for valuation; acquired cohorts are separate."""
        return tuple(OcAssetBalance(loan_id, timeline.balance_at(payment_date), final_date, data)
                     for loan_id, timeline, final_date, data in self._rows)


class _CombinedParTimeline:
    """Fee integrals include purchased cohorts only after settlement."""

    def __init__(self, original: _PerformingParTimeline, reinvestment: SyntheticReinvestmentLedger) -> None:
        self.original = original
        self.reinvestment = reinvestment

    def balance_at(self, value: date) -> Decimal:
        """Compose original and settled-cohort face at the same actual date."""
        return self.original.balance_at(value) + self.reinvestment.balance_at(value)

    def par_days(self, start: date, end: date) -> Fraction:
        """Compose fee integrals without treating acquisition cost as face."""
        return self.original.par_days(start, end) + self.reinvestment.par_days(start, end)


class DeterministicCloEngine:
    """Cash-pay EUR waterfall with explicit collection and execution policies.

    Senior expenses precede senior management fees. Restricted reserve covers
    only their priority shortfall and earns no interest. H00 sends all residual
    interest to sequential debt redemption at a failed gate. An explicit policy
    can instead cure OC and resume junior coupons, while IC retains the full
    opening-period dues. Normal principal allocation can be sequential/pro rata;
    coverage cures stay sequential. No EOD liquidation is assumed.

    Face principal, unpaid coupon claims and physical cash stay in separate
    ledgers. Mandatory PIK increases face before coverage without cash, while
    optional unpaid coupon claims can increase the selected OC denominator
    without becoming a second cash receipt or a face-par redemption. Synthetic
    reinvestment is a projection policy, not execution of proposed BSL trades.
    """

    def __init__(self, rate_provider: RateProvider, calendar: BusinessCalendar | None = None) -> None:
        if not callable(getattr(rate_provider, "rate", None)):
            raise InputValidationError("rate_provider must implement rate(index, fixing_date)")
        if calendar is not None and not isinstance(calendar, BusinessCalendar):
            raise InputValidationError("calendar must implement BusinessCalendar")
        self._rate_provider = rate_provider
        self._calendar = calendar or TargetCalendar()
        self._schedule = ScheduleBuilder(self._calendar)

    def run(self, request: CloRunRequest) -> CloProjection:
        """Project until full settlement, unresolved cash-pay failure, or final.

        Coupon and fee calculations retain exact Fraction arithmetic through
        cent posting. Ledger arithmetic uses an independent generous Decimal
        context and verifies both physical cash and principal conservation.
        """
        if not isinstance(request, CloRunRequest):
            raise InputValidationError("request must be CloRunRequest")
        # Size against EVERY monetary source/claim, including reserve and named
        # expense budgets. Ignoring an unusually large reserve silently loses
        # small posted receipts while the rounded conservation residual is 0.
        amounts = [request.opening_collateral_par, request.terms.initial_reserve,
                   request.terms.annual_senior_expenses,
                   *(row.annual_amount for row in request.terms.recurring_senior_expenses),
                   *(row.opening_balance for row in request.tranches)]
        if request.terms.annual_senior_expense_cap is not None:
            amounts.append(request.terms.annual_senior_expense_cap)
        if request.terms.incentive_initial_equity_funding is not None:
            amounts.append(request.terms.incentive_initial_equity_funding)
        if request.acquired_accrued_by_loan:
            amounts.extend(request.acquired_accrued_by_loan.values())
        if request.opening_state is not None:
            amounts.extend(request.opening_state.monetary_values())
        amounts.extend(row.amount for row in request.principal_accrued_balances)
        amounts.extend(row.principal_amount for row in request.coupon_proceeds_allocations)
        if request.imported_collateral is not None:
            amounts.extend(value for row in request.imported_collateral.collections for value in (row.cash_interest, row.principal_collection, row.total_cash))
            amounts.extend(value for row in request.imported_collateral.par_movements for value in (row.performing_par_before, row.performing_par_after))
        amounts.extend(value for row in request.asset_cashflows for value in (
            row.opening_balance, row.cash_interest, row.principal_repayment, row.total_cash))
        largest = max(require_decimal(value, "CLO monetary source/claim").adjusted() for value in amounts)
        rates = [request.terms.senior_management_fee_bps,
                 request.terms.subordinated_management_fee_bps,
                 request.terms.variable_senior_expenses_bps, request.terms.senior_expense_cap_bps,
                 request.terms.cash_account_fixed_rate or ZERO, request.terms.cash_account_spread_bps,
                 *(row.fixed_rate or ZERO for row in request.tranches),
                 *(row.spread_bps for row in request.tranches)]
        rate_digits = max(0, *(value.adjusted() for value in rates))
        with localcontext(Context(prec=max(60, largest + rate_digits + 40), rounding=ROUND_HALF_EVEN)):
            return self._run(request)

    def _run(self, request: CloRunRequest) -> CloProjection:
        """Execute one isolated scenario; policy order is intentionally explicit.

        Helper methods own reusable mathematics and atomic cash allocation.
        This method owns the sequence of account mutations and test snapshots,
        so reviewers can follow seniority and actual payment-date state in one
        place. Interest and principal are spendable cash; pending accounts are
        physically received but not yet eligible for normal distribution.
        ``held_diversion_principal`` designates part of principal cash and must
        never be added as an extra account in conservation or OC calculations.
        """
        # Stage 1 — compile a frozen reference and dated economic collections.
        # Performing/defaulted par are timelines, not cash: default moves face
        # between claims, whereas recovery reduces a claim and supplies cash.
        terms = request.terms
        payment_calendar = calendar_from_name(terms.payment_calendar) if terms.payment_calendar is not None else self._calendar
        fixing_calendar = calendar_from_name(terms.fixing_calendar) if terms.fixing_calendar is not None else self._calendar
        determination_calendar = calendar_from_name(terms.determination_calendar) if terms.determination_calendar is not None else self._calendar
        schedule = ScheduleBuilder(payment_calendar)
        if payment_calendar.adjust(terms.closing_date, terms.business_day_convention) != terms.closing_date:
            raise InputValidationError("CLO closing_date must already be a business-adjusted accrual boundary")
        original_periods, periods = select_opening_periods(request, payment_calendar)
        projection_start = request.projection_start_date
        contractual, principal_events = self._validate_assets(request) if request.imported_collateral is None else ((), {})
        native_pik_events = tuple(sorted(
            ((row.pik_capitalization_date, getattr(row, "pik_interest", ZERO)) for row in contractual
             if getattr(row, "pik_interest", ZERO)), key=lambda item: item[0]))
        cashflows, performing_reductions, default_changes, credit_movements, overlay_projection = self._collection_stream(request, contractual, principal_events)
        if request.additional_asset_collections:
            cashflows += tuple(_Collection(row.loan_id, row.payment_date, row.cash_interest, row.principal_collection, row.source)
                               for row in request.additional_asset_collections)
            cashflows = tuple(sorted(cashflows, key=lambda row: (row.payment_date, row.loan_id)))
        if request.acquired_accrued_by_loan:
            if request.imported_collateral is not None:
                raise InputValidationError("Imported full coupon streams already contain entitlement; do not append purchased accrued twice")
            if any((getattr(row, 'opening_accrued_interest', ZERO) != ZERO or
                    getattr(row, 'opening_accrued_exact', 0) != 0)
                   and row.loan_id in request.acquired_accrued_by_loan for row in contractual):
                raise InputValidationError("Seasoned coupon already contains its opening entitlement; acquired accrued is a funding cost, not a second receipt")
            from trident.application.imported_cashflows import inherited_accrued_for_overlay
            contractual_numbers = {(row.loan_id, row.payment_date): row.period_number for row in contractual}
            receipts = tuple(AssetCollection(row.loan_id, "EUR", row.payment_date, row.source, row.cash_interest,
                                            row.principal_repayment, row.cash_interest + row.principal_repayment,
                                            contractual_numbers.get((row.loan_id, row.payment_date), 1) if row.source is AssetCashSource.SCHEDULED else None)
                             for row in cashflows)
            if not set(request.acquired_accrued_by_loan).issubset({row.loan_id for row in contractual}):
                raise InputValidationError("Inherited coupon entitlement identifies an unknown loan")
            extras = inherited_accrued_for_overlay(request.acquired_accrued_by_loan, receipts, credit_movements)
            cashflows += tuple(_Collection(row.loan_id, row.payment_date, row.cash_interest, row.principal_collection, row.source) for row in extras)
            cashflows = tuple(sorted(cashflows, key=lambda row: (row.payment_date, row.loan_id)))
        # Classify only the verified native receipt stream, after inherited
        # coupon ownership has been incorporated exactly once. The compiler
        # validates loan/date/source and full restoration, then supplies cent
        # markers aligned with the original rows. Cash timing and raw face
        # movements remain authoritative for conservation and collateral.
        proceeds = classify_coupon_proceeds(
            cashflows, request.principal_accrued_balances,
            request.coupon_proceeds_allocations, as_of_date=projection_start,
        )
        if proceeds.audit_rows:
            cashflows = tuple(replace(
                row, principal_accrued_restored=restored,
                original_principal_accrued_permission=permission,
            ) for row, restored, permission in zip(
                cashflows, proceeds.restored_by_index,
                proceeds.permission_by_index, strict=True,
            ))
        par = _PerformingParTimeline(projection_start, request.opening_collateral_par, performing_reductions)
        original_par = par
        reinvestment = (SyntheticReinvestmentLedger(terms.synthetic_reinvestment_policy, self._rate_provider)
                        if terms.synthetic_reinvestment_policy is not None and terms.synthetic_reinvestment_policy.enabled else None)
        if reinvestment is not None:
            par = _CombinedParTimeline(par, reinvestment)
        defaulted = _PerformingParTimeline(projection_start, ZERO, default_changes)
        inventory = _OcAssetInventory(request, credit_movements)
        valuation_policy = terms.adjusted_oc_policy or AdjustedCollateralValuePolicy()
        is_first_stub = schedule.is_first_period_stub(original_periods[0], terms.frequency_months, terms.stub_convention, terms.end_of_month)
        has_floating_notes = any(row.coupon_type is CouponType.FLOATING for row in request.tranches)
        if terms.first_stub_rate_override is not None or terms.first_stub_rate_method is not FirstStubRateMethod.SELECTED_REFERENCE:
            if not has_floating_notes and terms.first_stub_rate_method is FirstStubRateMethod.SELECTED_REFERENCE:
                # A direct term-rate override requires a floating coupon.
                # Explicit reference-method menu selections remain inactive
                # for fixed-only notes, which have no term rate to interpolate.
                raise InputValidationError("first_stub_rate_override requires a floating note class")
            if has_floating_notes and not is_first_stub:
                raise InputValidationError("first_stub_rate_override requires an actual first nominal stub; regular first coupons use their term fixing")
        opening = request.opening_state
        opening_claims = {} if opening is None else {row.class_id: row.unpaid_coupon for row in opening.note_coupon_claims}
        notes = [_NoteState(row, row.opening_balance, opening_claims.get(row.class_id, ZERO),
                           opening is not None and row.opening_balance == 0 and opening_claims[row.class_id] == 0)
                 for row in sorted(request.tranches, key=lambda row: row.payment_priority)]
        summaries: list[CloPeriodSummary] = []
        snapshots: list[TranchePeriodSnapshot] = []
        coverage: list[CoverageTestResult] = []
        equity: list[DatedDistribution] = []
        equity_contributions: list[DatedDistribution] = []
        hurdle = (EquityHurdleAccount(terms.incentive_initial_equity_funding, terms.closing_date,
                                     terms.incentive_hurdle_rate, terms.incentive_fee_rate)
                  if terms.incentive_fee_enabled else None)
        refi_done = False
        call_done = False
        call_attempted = False
        disposed_collateral = disposed_defaulted = ZERO
        synthetic_collections: list[_Collection] = []
        synthetic_movements: list = []
        synthetic_eligible_cursor = 0
        original_principal_permission = ZERO
        interest_cash = principal_cash = ZERO
        pending_interest = pending_principal = ZERO
        expense_arrears = senior_fee_arrears = sub_fee_arrears = ZERO
        deferred_expense_arrears = ZERO
        reserve = terms.initial_reserve
        held_diversion_principal = ZERO
        unreleased_opening_interest = unreleased_opening_principal = unreleased_opening_permission = ZERO
        if opening is not None:
            # Seed verified physical balances and outstanding claims. No issue
            # proceeds, historical collection or coupon accrual is re-created.
            # Designated principal is already INSIDE principal_cash.
            interest_cash, principal_cash, reserve = opening.interest_cash, opening.principal_cash, opening.reserve
            pending_interest, pending_principal = opening.pending_interest_cash, opening.pending_principal_cash
            expense_arrears, senior_fee_arrears = opening.expense_arrears, opening.senior_management_fee_arrears
            sub_fee_arrears, deferred_expense_arrears = opening.subordinated_management_fee_arrears, opening.deferred_senior_expense_arrears
            original_principal_permission = opening.original_principal_reinvestment_cash
            held_diversion_principal = opening.held_diversion_principal
            unreleased_opening_interest, unreleased_opening_principal = pending_interest, pending_principal
            unreleased_opening_permission = opening.pending_original_principal_reinvestment_cash
        actual_cursor = eligible_cursor = credit_cursor = native_pik_cursor = 0
        prior_payment = projection_start
        status = ProjectionStatus.LEGAL_FINAL_UNRESOLVED

        for period in periods:
            # Stage 2 — advance assets through this payment date, then capture
            # opening accounts and claims before any waterfall allocation.
            status = ProjectionStatus.LEGAL_FINAL_UNRESOLVED
            note_fixing_date = fixing_date_for_period(period, terms.fixing_lag_business_days, fixing_calendar, terms.fixing_date_anchor)
            synthetic_result = (reinvestment.project(prior_payment, period.payment_date,
                                fixing_calendar.add_business_days(prior_payment, -terms.fixing_lag_business_days))
                                if reinvestment is not None else None)
            opening_interest = interest_cash
            opening_principal = principal_cash
            opening_pending_interest = pending_interest
            opening_pending_principal = pending_principal
            opening_reserve = reserve
            if (terms.interest_diversion_test_enabled
                    and period.payment_date > terms.interest_diversion_test_end_date):
                # Acquisition designation ends with the explicit window. Cash
                # still held then re-enters ordinary principal distribution.
                held_diversion_principal = ZERO
            opening_collateral = par.balance_at(prior_payment) - disposed_collateral
            opening_balances = tuple(row.balance for row in notes)
            opening_arrears = tuple(row.unpaid_coupon for row in notes)
            opening_debt = sum(opening_balances, ZERO)
            received_interest = received_principal = ZERO
            original_cash_interest = ZERO
            scheduled_received = prepayment_received = recovery_received = ZERO
            new_defaults = losses = ZERO
            non_cash_par_change = ZERO
            if (request.imported_collateral is None and not request.asset_credit_projections
                    and overlay_projection is None):
                # Native coupon PIK is a dated noncash collateral addition.
                # Imported/credit overlays already own their movement trace,
                # so the same contract increase must not be applied twice.
                while (native_pik_cursor < len(native_pik_events)
                       and native_pik_events[native_pik_cursor][0] <= period.payment_date):
                    non_cash_par_change += native_pik_events[native_pik_cursor][1]
                    native_pik_cursor += 1
            opening_synthetic_defaulted = (synthetic_result.defaulted_par - synthetic_result.default_par + synthetic_result.recovery_cash + synthetic_result.losses
                                          if synthetic_result is not None else ZERO)
            cash_par_days = Fraction(opening_interest + opening_principal + opening_pending_interest + opening_pending_principal) * (period.payment_date - prior_payment).days
            dated_cash_balances = [(prior_payment, opening_interest + opening_principal + opening_pending_interest + opening_pending_principal)]
            # Independent cursors visit each original cash/par event once.
            # Actual cash and cutoff eligibility cannot use the same cursor:
            # post-cutoff principal has already left performing collateral.
            while credit_cursor < len(credit_movements) and credit_movements[credit_cursor].event_date <= period.payment_date:
                movement = credit_movements[credit_cursor]
                if movement.source is AssetCashSource.DEFAULT:
                    new_defaults += movement.defaulted_par_after - movement.defaulted_par_before
                losses += movement.par_loss
                if movement.source in {AssetCashSource.SCHEDULED, AssetCashSource.PREPAYMENT}:
                    # Every authoritative movement stream may carry a native
                    # or imported PIK addition. Cash repayment alone cannot
                    # reproduce that face change, and the contract must not be
                    # replayed on top of the stressed surviving slice.
                    non_cash_par_change += getattr(movement, "non_cash_par_change",
                        movement.performing_par_after - movement.performing_par_before + movement.principal_receipt)
                credit_cursor += 1
            while actual_cursor < len(cashflows) and cashflows[actual_cursor].payment_date <= period.payment_date:
                row = cashflows[actual_cursor]
                received_interest += row.interest_proceeds
                original_cash_interest += row.cash_interest
                received_principal += row.principal_proceeds
                cash_par_days += (Fraction(row.cash_interest) + Fraction(row.principal_repayment)) * (period.payment_date - row.payment_date).days
                dated_cash_balances.append((row.payment_date, row.cash_interest + row.principal_repayment))
                if row.source is AssetCashSource.RECOVERY:
                    recovery_received += row.principal_repayment
                elif row.source is AssetCashSource.PREPAYMENT:
                    prepayment_received += row.principal_repayment
                else:
                    scheduled_received += row.principal_repayment
                actual_cursor += 1
            if synthetic_result is not None:
                synthetic_movements.extend(synthetic_result.par_movements)
                new_defaults += synthetic_result.default_par
                losses += synthetic_result.losses
                for row in synthetic_result.collections:
                    normalized = _Collection(row.loan_id, row.payment_date, row.cash_interest, row.principal_collection, row.source)
                    synthetic_collections.append(normalized)
                    received_interest += normalized.cash_interest
                    received_principal += normalized.principal_repayment
                    cash_par_days += (Fraction(normalized.cash_interest) + Fraction(normalized.principal_repayment)) * (period.payment_date - normalized.payment_date).days
                    dated_cash_balances.append((normalized.payment_date, normalized.cash_interest + normalized.principal_repayment))
                    if row.source is AssetCashSource.RECOVERY:
                        recovery_received += row.principal_collection
                    elif row.source is AssetCashSource.PREPAYMENT:
                        prepayment_received += row.principal_collection
                    else:
                        scheduled_received += row.principal_collection
            # A source-consistent economic yield pairs actual post-stress
            # coupon collections with the same source's live face integral.
            # Previously disposed original face earns no later exposure.
            original_exposure = decimal_fraction((original_par.par_days(prior_payment, period.payment_date)
                - Fraction(disposed_collateral) * (period.payment_date - prior_payment).days) / 365)
            reinvestment_exposure = decimal_fraction(reinvestment.par_days(prior_payment, period.payment_date) / 365) if reinvestment else ZERO
            debt_exposure = decimal_fraction(Fraction(opening_debt) * (period.payment_date - prior_payment).days / 365)
            pending_interest += received_interest
            pending_principal += received_principal
            # Stage 3 — release eligible collections, retain received late cash,
            # and remunerate the whole physical account while it was held.
            cutoff = determination_calendar.add_business_days(period.payment_date, -terms.collection_cutoff_business_days) if period is not periods[-1] else period.payment_date
            eligible_interest = eligible_principal = ZERO
            if cutoff >= projection_start:
                # These opening pending balances were physically received no
                # later than as-of. Release them once the new determination
                # date reaches as-of; release is a transfer, never a receipt.
                eligible_interest += unreleased_opening_interest
                eligible_principal += unreleased_opening_principal
                original_principal_permission += unreleased_opening_permission
                unreleased_opening_interest = unreleased_opening_principal = unreleased_opening_permission = ZERO
            while eligible_cursor < len(cashflows) and cashflows[eligible_cursor].payment_date <= cutoff:
                row = cashflows[eligible_cursor]
                eligible_interest += row.interest_proceeds
                eligible_principal += row.principal_proceeds
                if row.source in {AssetCashSource.SCHEDULED, AssetCashSource.PREPAYMENT}:
                    original_principal_permission += row.principal_repayment
                # Routing to principal does not by itself authorize synthetic
                # acquisition. Release only the explicitly granted subset at
                # the same determination cutoff as its physical cash.
                original_principal_permission += row.original_principal_accrued_permission
                eligible_cursor += 1
            while synthetic_eligible_cursor < len(synthetic_collections) and synthetic_collections[synthetic_eligible_cursor].payment_date <= cutoff:
                row = synthetic_collections[synthetic_eligible_cursor]
                eligible_interest += row.cash_interest
                eligible_principal += row.principal_repayment
                synthetic_eligible_cursor += 1
            pending_interest -= eligible_interest
            pending_principal -= eligible_principal
            interest_cash += eligible_interest
            principal_cash += eligible_principal
            if min(pending_interest, pending_principal) < 0:
                raise ArithmeticError("Eligible collections were released before actual receipt")
            cash_account_interest, cash_account_rate, cash_account_fixing = self._cash_earnings(request, prior_payment, cash_par_days,
                                                                                            dated_cash_balances, period.payment_date)
            # Bank remuneration is a distinct receipt credited on the current
            # distribution day. Asset collection cut-off does not defer this
            # bank receipt; pending asset cash nevertheless earns while held.
            interest_cash += cash_account_interest

            # Stage 4 — determine current dues from opening par and exact DCF.
            # Fee claims include opening unpaid claims without compounding.
            # Note coupons and interest-on-arrears post separately in this
            # generic profile; an aggregate legal posting rule is not inferred.
            fee_factor = self._fee_factor(par, request, period, terms.management_fee_day_count)
            expense_factor = self._fee_factor(par, request, period, terms.senior_expenses_day_count)
            annual_expenses = (sum((Fraction(row.annual_amount) for row in terms.recurring_senior_expenses), Fraction(0))
                               if terms.recurring_senior_expenses else Fraction(terms.annual_senior_expenses))
            new_expenses = post_currency(
                annual_expenses * accrual_fraction(period.accrual_start, period.accrual_end, terms.senior_expenses_day_count)
                + expense_factor * Fraction(terms.variable_senior_expenses_bps) / 10_000
            )
            expense_due = expense_arrears + new_expenses
            expense_cap = None
            deferred_expense_due = deferred_expense_arrears
            if terms.annual_senior_expense_cap is not None:
                expense_cap = post_currency(
                    Fraction(terms.annual_senior_expense_cap)
                    * accrual_fraction(period.accrual_start, period.accrual_end, terms.senior_expenses_day_count)
                    + expense_factor * Fraction(terms.senior_expense_cap_bps) / 10_000
                )
                # This is a payment-priority cap: excess obligations survive as
                # a separate junior expense claim, never as free equity cash.
                deferred_expense_due += max(ZERO, expense_due - expense_cap)
                expense_due = min(expense_due, expense_cap)
            senior_due = senior_fee_arrears + post_currency(fee_factor * Fraction(terms.senior_management_fee_bps) / 10_000)
            sub_due = sub_fee_arrears + post_currency(fee_factor * Fraction(terms.subordinated_management_fee_bps) / 10_000)
            first_override = terms.first_stub_rate_override
            if period.period_number == 1 and is_first_stub and has_floating_notes and terms.first_stub_rate_method is not FirstStubRateMethod.SELECTED_REFERENCE:
                floating = next((row for row in notes if row.tranche.coupon_type is CouponType.FLOATING), None)
                if floating is not None:
                    first_override = first_stub_reference_rate(self._rate_provider, note_fixing_date, period.accrual_start, period.accrual_end,
                                                             floating.tranche.rate_index, terms.first_stub_rate_method, terms.first_stub_rate_override)
            current_coupons, index_rates, all_in_rates, dcfs = self._coupons(notes, period, first_override, note_fixing_date,
                                accrue_coupon_arrears=terms.interest_shortfall_carry and terms.shortfall_accrual_method is ShortfallAccrualMethod.COUPON_RATE)
            # Mandatory PIK is contractual settlement of the current coupon in
            # additional face. Post the gross coupon once, post its PIK share,
            # and assign the exact residual to cash coupon; two independently
            # rounded cash/PIK shares can otherwise create or lose one cent.
            # Capitalization precedes every coverage node and redemption. No
            # PIK is added to physical cash or the optional deferred ledger.
            pik_coupons = tuple(post_currency(Fraction(coupon) * Fraction(note.tranche.pik_rate_fraction))
                                for coupon, note in zip(current_coupons, notes, strict=True))
            current_coupons = [coupon - pik for coupon, pik in zip(current_coupons, pik_coupons, strict=True)]
            for note, pik in zip(notes, pik_coupons, strict=True):
                note.balance += pik
            shortfall_interest = tuple(
                post_currency(Fraction(unpaid) * Fraction(rate) * accrual_fraction(period.accrual_start, period.accrual_end, note.tranche.day_count))
                if terms.interest_shortfall_carry and terms.shortfall_accrual_method is ShortfallAccrualMethod.COUPON_RATE else ZERO
                for unpaid, rate, note in zip(opening_arrears, all_in_rates, notes, strict=True))
            coupon_claims = tuple(current + unpaid + accrued for current, unpaid, accrued in zip(current_coupons, opening_arrears, shortfall_interest, strict=True))
            # Deferred coupon principal remains a claim, but need not be part of
            # contractual IC debt service. Interest on it is still current debt
            # service. Delinquent cash-pay senior arrears must never disappear.
            ic_coupon_claims = tuple(
                current + accrued + (unpaid if terms.include_deferred_interest_in_ic or not note.tranche.interest_deferrable else ZERO)
                for current, unpaid, accrued, note in zip(current_coupons, opening_arrears, shortfall_interest, notes, strict=True))
            # Freeze the original asset identities at today's event boundary.
            # The collateral valuation below is the *current* waterfall state:
            # an executed lifecycle sale or acquisition must replace it before
            # a later gate uses it. Future cohort face is never credited early.
            original_oc_balances = inventory.balances_at(period.payment_date)
            current_defaulted_par = defaulted.balance_at(period.payment_date) + (synthetic_result.defaulted_par if synthetic_result else ZERO)
            oc_value = valuation_policy.value(original_oc_balances,
                                              par.balance_at(period.payment_date), current_defaulted_par, terms.legal_final_date,
                                              synthetic_par=reinvestment.performing_par if reinvestment else ZERO,
                                              synthetic_long_dated_par=reinvestment.long_dated_par(terms.legal_final_date) if reinvestment else ZERO)
            unpaid = list(coupon_claims)
            paid_interest = [ZERO for _ in notes]
            paid_principal = [ZERO for _ in notes]
            principal_interest = [ZERO for _ in notes]
            principal_principal = [ZERO for _ in notes]
            blocked = [False for _ in notes]
            # IC uses all period dues; coupon payments/redemptions never lower it.
            ic_numerator = opening_interest + eligible_interest + cash_account_interest - expense_due - senior_due

            # Stage 5 — senior expenses/fees, then each own coupon and gate.
            # IC retains the period's debt-service claims; OC follows actual
            # remaining face/deferrable claims after payments at each node.
            expense_paid = min(interest_cash, expense_due)
            interest_cash -= expense_paid
            expense_arrears = expense_due - expense_paid
            senior_paid = min(interest_cash, senior_due)
            interest_cash -= senior_paid
            senior_fee_arrears = senior_due - senior_paid
            draw_expense = min(reserve, expense_arrears)
            reserve -= draw_expense
            expense_arrears -= draw_expense
            expense_paid += draw_expense
            draw_senior = min(reserve, senior_fee_arrears)
            reserve -= draw_senior
            senior_fee_arrears -= draw_senior
            senior_paid += draw_senior
            reserve_draw = draw_expense + draw_senior
            # Authorized reserve transfers pay these exact senior claims, leaving
            # the interest account available for debt service. Excluding a draw
            # while deducting the same fee creates a false IC deficit.
            ic_numerator += reserve_draw

            failed_class = None
            distribution_blocked = False
            diversion_occurred = False
            for index, note in enumerate(notes):
                paid = min(interest_cash, unpaid[index])
                interest_cash -= paid
                unpaid[index] -= paid
                paid_interest[index] += paid
                test = self._coverage(notes, index, period, "GATE", oc_value.collateral_value, principal_cash + pending_principal, ic_numerator, ic_coupon_claims,
                                      tests_enabled=terms.coverage_tests_enabled, include_principal_cash=terms.include_principal_cash_in_oc,
                                      unpaid_coupon_claims=unpaid, include_deferred_interest=terms.include_deferred_interest_in_oc)
                coverage.append(test)
                if test.oc_status is CoverageStatus.FAIL or test.ic_status is CoverageStatus.FAIL:
                    failed_class = failed_class or note.tranche.class_id
                    distribution_blocked = True
                    if terms.interest_diversion_enabled:
                        cure_cash = interest_cash
                        cure_mode = (terms.interest_diversion_mode is InterestDiversionMode.CURE_OC_AND_CONTINUE
                                     and test.ic_status is not CoverageStatus.FAIL)
                        if cure_mode:
                            cure_cash = min(interest_cash, test.minimum_interest_repayment_for_oc or ZERO)
                        # The failed gate authorizes repayment only through its
                        # tested class. Never skip a junior coupon to redeem
                        # that junior class's principal merely because excess
                        # interest outlives the senior balances.
                        leftover, payments = self._redeem(cure_cash, notes, through=index)
                        interest_cash -= cure_cash - leftover
                        principal_interest = [old + paid for old, paid in zip(principal_interest, payments, strict=True)]
                        diversion_occurred = True
                        retest = self._coverage(notes, index, period, "POST_DIVERSION", oc_value.collateral_value, principal_cash + pending_principal, ic_numerator, ic_coupon_claims,
                                                tests_enabled=terms.coverage_tests_enabled, include_principal_cash=terms.include_principal_cash_in_oc,
                                                unpaid_coupon_claims=unpaid, include_deferred_interest=terms.include_deferred_interest_in_oc)
                        if cure_mode and retest.oc_status is not CoverageStatus.FAIL and retest.ic_status is not CoverageStatus.FAIL:
                            distribution_blocked = False
                            continue
                    blocked[index + 1:] = [True] * (len(notes) - index - 1)
                    break
            if diversion_occurred:
                # One auditable post-diversion snapshot per class-period. The
                # immediate cure decision above uses the exact current state;
                # this trace records the state after the last diversion.
                for retest_index in range(len(notes)):
                    coverage.append(self._coverage(notes, retest_index, period, "POST_DIVERSION", oc_value.collateral_value, principal_cash + pending_principal, ic_numerator, ic_coupon_claims,
                                                   tests_enabled=terms.coverage_tests_enabled, include_principal_cash=terms.include_principal_cash_in_oc,
                                                   unpaid_coupon_claims=unpaid, include_deferred_interest=terms.include_deferred_interest_in_oc))

            sub_paid = ZERO
            deferred_expense_paid = ZERO
            equity_interest = ZERO
            if not distribution_blocked:
                deferred_expense_paid = min(interest_cash, deferred_expense_due)
                interest_cash -= deferred_expense_paid
                sub_paid = min(interest_cash, sub_due)
                interest_cash -= sub_paid
                if expense_arrears == senior_fee_arrears == 0 and not any(unpaid):
                    equity_interest = interest_cash
                    interest_cash = ZERO
            sub_fee_arrears = sub_due - sub_paid
            deferred_expense_arrears = deferred_expense_due - deferred_expense_paid

            # Stage 6 — the independent junior acquisition diversion. It moves
            # cash from interest to principal rather than redeeming any note.
            # A junior Interest Diversion Test is separate from rated-class
            # coverage redemptions above. It increases the principal numerator
            # by an actual transfer, so its cure is k*D-N, not D-N/k. Earmarked
            # funds can be acquired through an authorized reinvestment policy;
            # otherwise they remain cash rather than automatic debt paydown.
            idt_numerator = idt_denominator = idt_ratio = idt_minimum = None
            idt_status = CoverageStatus.NOT_CONFIGURED
            idt_transferred = ZERO
            if terms.interest_diversion_test_enabled:
                idt_minimum = terms.interest_diversion_test_oc_minimum
                idt_index = next(index for index, state in enumerate(notes) if state.tranche.class_id == terms.interest_diversion_test_class_id)
                idt_denominator = self._oc_outstanding(notes, idt_index, unpaid,
                                                      include_deferred_interest=terms.include_deferred_interest_in_oc)
                idt_numerator = oc_value.collateral_value + principal_cash + pending_principal
                idt_ratio = decimal_fraction(Fraction(idt_numerator) / Fraction(idt_denominator)) if idt_denominator else None
                active = period.payment_date <= terms.interest_diversion_test_end_date and period is not periods[-1]
                if not active or not idt_denominator:
                    idt_status = CoverageStatus.NOT_APPLICABLE
                else:
                    shortfall = max(Fraction(0), Fraction(idt_minimum) * Fraction(idt_denominator) - Fraction(idt_numerator))
                    idt_status = CoverageStatus.FAIL if shortfall else CoverageStatus.PASS
                    if shortfall and not distribution_blocked:
                        # Only executable cents may leave interest. Floor the
                        # contractual residual cap and ceil required cure cents.
                        capped = Fraction(equity_interest) * Fraction(terms.interest_diversion_test_max_fraction) * 100
                        required = shortfall * 100
                        cap_cents = capped.numerator // capped.denominator
                        required_cents = -(-required.numerator // required.denominator)
                        idt_transferred = Decimal(min(cap_cents, required_cents)) / 100
                        equity_interest -= idt_transferred
                        principal_cash += idt_transferred
                        held_diversion_principal += idt_transferred

            sale_par = sale_defaulted = sale_proceeds = call_cost = ZERO
            call_status = "NOT_REQUESTED"
            refi_fee = ZERO
            # Stage 7 — voluntary call/final-sale policy before principal uses.
            # A price assumption is not a receipt until this sale is exercised.
            # Event dates roll to the first actual distribution on/after request.
            # Sale proceeds are physical principal receipts, not an IRR add-on.
            call_requested = terms.optional_call_enabled and not call_attempted and period.payment_date >= terms.optional_call_date
            if call_requested:
                call_attempted = True
            final_liquidation = period is periods[-1] and terms.maturity_liquidation_price is not None
            if call_requested or final_liquidation:
                proposed_par = par.balance_at(period.payment_date)
                proposed_defaulted = defaulted.balance_at(period.payment_date) + (synthetic_result.defaulted_par if synthetic_result else ZERO)
                price = terms.optional_call_collateral_sale_price if call_requested else terms.maturity_liquidation_price
                proposed_proceeds = post_currency(Fraction(proposed_par) * Fraction(price)
                                                 + Fraction(proposed_defaulted) * Fraction(terms.defaulted_collateral_sale_price))
                ordinary_principal = max(ZERO, principal_cash - expense_arrears - senior_fee_arrears - sum(unpaid, ZERO))
                debt_at_call = max(ZERO, sum((row.balance for row in notes), ZERO) - ordinary_principal)
                proposed_cost = post_currency(Fraction(debt_at_call)
                                             * Fraction(terms.optional_call_cost_pct_of_debt)) if call_requested else ZERO
                necessary = sum((row.balance for row in notes), ZERO) + sum(unpaid, ZERO) + expense_arrears + senior_fee_arrears + sub_fee_arrears + deferred_expense_arrears + proposed_cost
                # A voluntary call is exercised only with sufficient available
                # cash to discharge every claim. A failed call retains assets.
                sufficient = principal_cash + interest_cash + equity_interest + pending_interest + pending_principal + proposed_proceeds >= necessary
                if call_requested and not sufficient and final_liquidation:
                    # An infeasible voluntary redemption cannot become feasible
                    # merely because legal maturity happens on the same date.
                    # Execute the separately configured mandatory sale instead.
                    proposed_proceeds = post_currency(Fraction(proposed_par) * Fraction(terms.maturity_liquidation_price)
                                                     + Fraction(proposed_defaulted) * Fraction(terms.defaulted_collateral_sale_price))
                    proposed_cost = ZERO
                    call_requested = False
                if final_liquidation or sufficient:
                    sale_par, sale_defaulted, sale_proceeds, call_cost = proposed_par, proposed_defaulted, proposed_proceeds, proposed_cost
                    disposed_collateral += sale_par
                    disposed_defaulted += sale_defaulted
                    # Liquidation releases all post-cutoff collections. Interest
                    # claims stay senior; the terminal principal account can pay
                    # the same catch-up claims before redeeming debt below.
                    principal_cash += sale_proceeds + pending_principal + pending_interest + interest_cash + equity_interest
                    pending_interest = pending_principal = interest_cash = ZERO
                    equity_interest = held_diversion_principal = ZERO
                    principal_cash -= call_cost
                    call_done = call_requested
                    call_status = "EXERCISED" if call_requested else "MATURITY_LIQUIDATION"
                    # Ownership of all collateral/recovery claims has moved
                    # to the buyer. Only the actual sale consideration remains
                    # in principal cash; adding the old noncash OC value would
                    # count the sold book twice at the principal gate.
                    oc_value = valuation_policy.value((), ZERO, ZERO, terms.legal_final_date)
                else:
                    call_status = "INSUFFICIENT_PROCEEDS"

            # Stage 8 — principal claim catch-up, permitted acquisitions, then
            # debt amortization. Coverage cures always retain seniority even
            # when ordinary principal is configured for pro-rata allocation.
            # Principal supplements cash-pay obligations before note redemption.
            principal_before_catchup = principal_cash
            principal_expense = min(principal_cash, expense_arrears)
            principal_cash -= principal_expense
            expense_arrears -= principal_expense
            expense_paid += principal_expense
            principal_senior = min(principal_cash, senior_fee_arrears)
            principal_cash -= principal_senior
            senior_fee_arrears -= principal_senior
            senior_paid += principal_senior
            for index in range(len(notes)):
                controlling = next((position for position, state in enumerate(notes) if state.balance), None)
                if (terms.principal_coupon_policy is PrincipalCouponPolicy.NON_DEFERRABLE_AND_CONTROLLING
                        and notes[index].tranche.interest_deferrable and controlling is not None and index > controlling
                        ):
                    continue
                paid = min(principal_cash, unpaid[index])
                principal_cash -= paid
                unpaid[index] -= paid
                paid_principal[index] += paid
            original_principal_permission = max(ZERO, original_principal_permission - (principal_before_catchup - principal_cash))
            held_diversion_principal = min(held_diversion_principal, principal_cash)
            # Mandatory final debt cannot be left unpaid while today's actual
            # interest is distributed to equity. This uses cash only; it never
            # invents a liquidation value for surviving collateral.
            if period is periods[-1]:
                held_diversion_principal = ZERO
                shortage = max(ZERO, sum((state.balance for state in notes), ZERO) + sum(unpaid, ZERO) - principal_cash)
                from_residual = min(equity_interest, shortage)
                equity_interest -= from_residual
                shortage -= from_residual
                from_held_interest = min(interest_cash, shortage)
                interest_cash -= from_held_interest
                _, terminal_payments, terminal_coupons = self._redeem_with_coupon_claims(from_residual + from_held_interest, notes, unpaid)
                principal_interest = [old + paid for old, paid in zip(principal_interest, terminal_payments, strict=True)]
                paid_interest = [old + paid for old, paid in zip(paid_interest, terminal_coupons, strict=True)]
            reinvestment_cash = reinvestment_par = ZERO
            purchase_failed = any(
                test.oc_status is CoverageStatus.FAIL or test.ic_status is CoverageStatus.FAIL
                for index in range(len(notes))
                for test in (self._coverage(notes, index, period, "PURCHASE_GATE", oc_value.collateral_value,
                                           principal_cash + pending_principal, ic_numerator, ic_coupon_claims,
                                           tests_enabled=terms.coverage_tests_enabled, include_principal_cash=terms.include_principal_cash_in_oc,
                                           unpaid_coupon_claims=unpaid, include_deferred_interest=terms.include_deferred_interest_in_oc),))
            if reinvestment is not None and not call_done and not final_liquidation and reinvestment.policy.eligible(period.payment_date, period is periods[-1], purchase_failed or any(unpaid)):
                purchase_cash = (principal_cash if reinvestment.policy.recycle_reinvestment_principal
                                 else min(principal_cash, original_principal_permission + held_diversion_principal))
                if purchase_cash and Fraction(purchase_cash) / Fraction(reinvestment.policy.purchase_price) >= Fraction(1, 100):
                    # Compute the exact acquisition first. Previewing must not
                    # create a cohort, advance its ID or schedule recovery. The
                    # same posted consideration/face is used for approval and
                    # settlement, so no cent can vanish between the two stages.
                    proposed_purchase = reinvestment.plan_purchase(period.payment_date, purchase_cash)
                    # A deeply discounted template can acquire more face than
                    # any original input. Extend this isolated run's precision
                    # before adding that face; retaining posted cents must not
                    # depend on the caller's Decimal context or original scale.
                    getcontext().prec = max(getcontext().prec, proposed_purchase.acquired_par.adjusted() + 40)
                    if not terms.allow_long_dated_assets and proposed_purchase.maturity_date > terms.legal_final_date:
                        raise InputValidationError("Synthetic purchase creates forbidden long-dated collateral")
                    prospective_long_dated = reinvestment.long_dated_par(terms.legal_final_date)
                    if proposed_purchase.maturity_date > terms.legal_final_date:
                        prospective_long_dated += proposed_purchase.acquired_par
                    prospective_value = valuation_policy.value(
                        original_oc_balances,
                        oc_value.performing_par + proposed_purchase.acquired_par,
                        current_defaulted_par, terms.legal_final_date,
                        synthetic_par=reinvestment.performing_par + proposed_purchase.acquired_par,
                        synthetic_long_dated_par=prospective_long_dated,
                    )
                    prospective_cash = principal_cash - proposed_purchase.cash_used
                    post_purchase_failed = any(
                        test.oc_status is CoverageStatus.FAIL or test.ic_status is CoverageStatus.FAIL
                        for index in range(len(notes))
                        for test in (self._coverage(
                            notes, index, period, "POST_PURCHASE_GATE", prospective_value.collateral_value,
                            prospective_cash + pending_principal, ic_numerator, ic_coupon_claims,
                            tests_enabled=terms.coverage_tests_enabled,
                            include_principal_cash=terms.include_principal_cash_in_oc,
                            unpaid_coupon_claims=unpaid,
                            include_deferred_interest=terms.include_deferred_interest_in_oc),)
                    )
                    # STOP requires both current and prospective tests to pass.
                    # ALWAYS is the existing explicit coverage sensitivity; it
                    # bypasses neither forbidden maturity nor the asset-level
                    # synthetic-classification guard in valuation_policy.value.
                    # A rejection leaves ordinary cash available for redemption
                    # and held IDT cash earmarked under its existing policy.
                    if not post_purchase_failed or reinvestment.policy.test_gate is ReinvestmentTestGate.ALWAYS_REINVEST:
                        new_purchase = reinvestment.commit_purchase(proposed_purchase)
                        reinvestment_cash, reinvestment_par = new_purchase.cash_used, new_purchase.acquired_par
                        principal_cash = prospective_cash
                        from_diversion = min(held_diversion_principal, reinvestment_cash)
                        held_diversion_principal -= from_diversion
                        original_principal_permission = max(ZERO, original_principal_permission - (reinvestment_cash - from_diversion))
                        # PRINCIPAL_GATE must see the settled collateral, not
                        # today's old book minus the acquisition cash. At par
                        # with full OC credit, cash-to-face conversion preserves
                        # the numerator; premiums/haircuts can genuinely reduce
                        # it. IC remains today's fixed debt-service calculation:
                        # purchased face earns no pre-settlement coupon.
                        oc_value = prospective_value
            # A failed gate's coverage repayment is sequential even if ordinary
            # amortisation is pro rata. Coupon costs always reduce cash; paid
            # capitalized deferrable claims also reduce coverage outstanding,
            # without changing face par or being counted again as redemption.
            unresolved_coverage = any(
                test.oc_status is CoverageStatus.FAIL or test.ic_status is CoverageStatus.FAIL
                for index in range(len(notes))
                for test in (self._coverage(notes, index, period, "PRINCIPAL_GATE", oc_value.collateral_value,
                                           principal_cash + pending_principal, ic_numerator, ic_coupon_claims,
                                           tests_enabled=terms.coverage_tests_enabled, include_principal_cash=terms.include_principal_cash_in_oc,
                                           unpaid_coupon_claims=unpaid, include_deferred_interest=terms.include_deferred_interest_in_oc),))
            available_principal = principal_cash - held_diversion_principal
            if terms.principal_repayment_mode is PrincipalRepaymentMode.PRO_RATA and not unresolved_coverage and not any(unpaid):
                leftover, principal_principal = self._redeem_pro_rata(available_principal, notes)
            else:
                leftover, principal_principal, controlling_coupons = self._redeem_with_coupon_claims(available_principal, notes, unpaid)
                paid_principal = [old + paid for old, paid in zip(paid_principal, controlling_coupons, strict=True)]
            principal_cash = leftover + held_diversion_principal
            original_principal_permission = min(original_principal_permission, max(ZERO, principal_cash - held_diversion_principal))
            # Remaining principal is junior only after all debt par is settled.
            if not any(row.balance for row in notes) and not any(unpaid) and expense_arrears == senior_fee_arrears == 0:
                principal_deferred_expense = min(principal_cash, deferred_expense_arrears)
                principal_cash -= principal_deferred_expense
                deferred_expense_arrears -= principal_deferred_expense
                deferred_expense_paid += principal_deferred_expense
                principal_sub = min(principal_cash, sub_fee_arrears)
                principal_cash -= principal_sub
                sub_fee_arrears -= principal_sub
                sub_paid += principal_sub
            equity_principal = ZERO
            if not any(row.balance for row in notes) and not any(unpaid) and expense_arrears == senior_fee_arrears == sub_fee_arrears == deferred_expense_arrears == 0:
                equity_principal = principal_cash
                principal_cash = ZERO

            closing_collateral = par.balance_at(period.payment_date) - disposed_collateral
            closing_debt = sum((row.balance for row in notes), ZERO)
            # Stage 9 — next-period refinancing and closing completion state.
            # Fee funding is an explicit equity contribution; amending a spread
            # does not reissue a note or create new issuance proceeds.
            if terms.refinancing_enabled and not refi_done and not call_done and not final_liquidation and period.payment_date >= terms.refinancing_date:
                # Fee base is the debt AFTER this distribution's redemptions,
                # matching the actual balance that receives the amended spread.
                refi_fee = post_currency(Fraction(closing_debt) * Fraction(terms.refinancing_fee_pct_of_debt))
                if refi_fee:
                    equity_contributions.append(DatedDistribution(period.payment_date, refi_fee, "REFINANCING_FEE_CONTRIBUTION"))
                for state in notes:
                    if state.tranche.coupon_type is CouponType.FLOATING:
                        reduced = max(ZERO, state.tranche.spread_bps - terms.refinancing_spread_reduction * 10_000)
                        state.tranche = replace(state.tranche, spread_bps=reduced)
                refi_done = True
            cash_pay_failure = expense_arrears > 0 or senior_fee_arrears > 0 or any(
                amount for amount, state in zip(unpaid, notes, strict=True) if not state.tranche.interest_deferrable)
            closing_defaulted = defaulted.balance_at(period.payment_date) + (reinvestment.defaulted_par if reinvestment else ZERO) - disposed_defaulted
            # All collateral events were committed before PRINCIPAL_GATE;
            # debt/fee payments and spread refinancing cannot change this OC
            # asset credit. Reuse the same current valuation for PERIOD_END.
            closing_valuation = oc_value
            all_assets_settled = (closing_collateral == closing_defaulted == pending_interest == pending_principal == 0
                                  and (actual_cursor == len(cashflows) and credit_cursor == len(credit_movements)
                                       or sale_par + sale_defaulted > 0)
                                  and (reinvestment is None or reinvestment.pending_recovery_amount == 0 or sale_par + sale_defaulted > 0))
            claims_settled = closing_debt == 0 and not any(unpaid) and not cash_pay_failure and sub_fee_arrears == deferred_expense_arrears == 0
            reserve_release = ZERO
            equity_reserve = ZERO
            if all_assets_settled and claims_settled:
                # Includes capped-diversion leftover cash only after final claims.
                equity_interest += interest_cash
                interest_cash = ZERO
                equity_principal += principal_cash
                principal_cash = ZERO
                reserve_release = equity_reserve = reserve
                reserve = ZERO
                status = ProjectionStatus.COMPLETED
            elif cash_pay_failure:
                status = ProjectionStatus.CASH_PAY_FAILURE
            elif period is periods[-1] and all_assets_settled and closing_debt == 0 and (sub_fee_arrears > 0 or deferred_expense_arrears > 0):
                status = ProjectionStatus.FINAL_FEES_UNSETTLED

            incentive_fee = ZERO
            # Stage 10 — investor hurdle and explicit sensitivity waivers.
            # Use actual residual cash/funding, not an IRR solver's rounded
            # crossing, to decide the incentive fee and net distributions.
            if hurdle is not None:
                hurdle.accrue(period.payment_date, refi_fee)
                incentive_fee = hurdle.charge(equity_interest + equity_principal + equity_reserve)
                fee_from_interest = min(incentive_fee, equity_interest)
                equity_interest -= fee_from_interest
                remainder = incentive_fee - fee_from_interest
                fee_from_principal = min(remainder, equity_principal)
                equity_principal -= fee_from_principal
                equity_reserve -= remainder - fee_from_principal
            waived = [ZERO for _ in notes]
            if not terms.interest_shortfall_carry:
                waived, unpaid = unpaid, [ZERO for _ in notes]

            for index, note in enumerate(notes):
                # Stage 11 — publish each class and verify independent bridges.
                # PERIOD_END is a diagnostic of the final state, never a claim
                # that an earlier blocked interest gate was reached or passed.
                note.unpaid_coupon = unpaid[index]
                snapshots.append(TranchePeriodSnapshot(
                    period.period_number, period.payment_date, note.tranche.class_id, note.tranche.payment_priority,
                    opening_balances[index], note.balance, opening_arrears[index], current_coupons[index],
                    paid_interest[index], paid_principal[index], unpaid[index], principal_interest[index], principal_principal[index],
                    note_fixing_date if index_rates[index] is not None else None,
                    index_rates[index], all_in_rates[index], dcfs[index], blocked[index],
                    shortfall_interest[index], waived[index],
                    pik_coupons[index],
                ))
                if opening_balances[index] + pik_coupons[index] - principal_interest[index] - principal_principal[index] != note.balance:
                    raise ArithmeticError(f"Debt principal conservation failed for {note.tranche.class_id}")
                if coupon_claims[index] - paid_interest[index] - paid_principal[index] - waived[index] != unpaid[index]:
                    raise ArithmeticError(f"Coupon claim conservation failed for {note.tranche.class_id}")
                closing_oc_value = closing_valuation.collateral_value
                coverage.append(self._coverage(notes, index, period, "PERIOD_END", closing_oc_value, principal_cash + pending_principal, ic_numerator, ic_coupon_claims,
                                               tests_enabled=terms.coverage_tests_enabled, include_principal_cash=terms.include_principal_cash_in_oc,
                                               unpaid_coupon_claims=unpaid, include_deferred_interest=terms.include_deferred_interest_in_oc))
            coupon_paid = sum(paid_interest, ZERO) + sum(paid_principal, ZERO)
            redemption_interest = sum(principal_interest, ZERO)
            redemption_principal = sum(principal_principal, ZERO)
            for amount, source in ((equity_interest, "INTEREST_RESIDUAL"), (equity_principal, "PRINCIPAL_RESIDUAL"), (equity_reserve, "FINAL_RESERVE_RELEASE")):
                if amount:
                    equity.append(DatedDistribution(period.payment_date, amount, source))
            physical_sources = opening_interest + opening_principal + opening_pending_interest + opening_pending_principal + opening_reserve + received_interest + received_principal + cash_account_interest + sale_proceeds + refi_fee
            uses_and_balances = expense_paid + deferred_expense_paid + senior_paid + sub_paid + coupon_paid + redemption_interest + redemption_principal + equity_interest + equity_principal + equity_reserve + interest_cash + principal_cash + pending_interest + pending_principal + reserve + incentive_fee + call_cost + refi_fee + reinvestment_cash
            residual = physical_sources - uses_and_balances
            if residual != 0:
                raise ArithmeticError(f"Physical cash conservation failed at {period.payment_date}: {residual}")
            if opening_collateral - scheduled_received - prepayment_received - new_defaults - sale_par + reinvestment_par + non_cash_par_change != closing_collateral:
                raise ArithmeticError(f"Collateral principal conservation failed at {period.payment_date}")
            if defaulted.balance_at(prior_payment) + opening_synthetic_defaulted + new_defaults - recovery_received - losses - sale_defaulted != closing_defaulted:
                raise ArithmeticError(f"Defaulted claim conservation failed at {period.payment_date}")
            if opening_debt + sum(pik_coupons, ZERO) - redemption_interest - redemption_principal != closing_debt:
                raise ArithmeticError(f"Aggregate debt principal conservation failed at {period.payment_date}")
            if min(interest_cash, principal_cash, pending_interest, pending_principal, reserve, expense_arrears, deferred_expense_arrears, senior_fee_arrears, sub_fee_arrears, *unpaid) < 0:
                raise ArithmeticError("Negative account or claim balance")
            if deferred_expense_due - deferred_expense_paid != deferred_expense_arrears:
                raise ArithmeticError("Deferred senior expense claim conservation failed")
            summaries.append(CloPeriodSummary(
                period.period_number, period.payment_date, period.accrual_start, period.accrual_end,
                opening_collateral, closing_collateral, received_interest, received_principal, eligible_interest, eligible_principal,
                opening_interest, interest_cash, opening_principal, principal_cash, pending_interest, pending_principal,
                expense_due, expense_paid, expense_arrears, senior_due, senior_paid, senior_fee_arrears,
                sub_due, sub_paid, sub_fee_arrears, sum(coupon_claims, ZERO), coupon_paid, sum(unpaid, ZERO),
                opening_debt, closing_debt, redemption_interest, redemption_principal,
                opening_reserve, reserve_draw, reserve_release, reserve,
                equity_interest, equity_principal, equity_reserve, failed_class is not None, failed_class,
                cash_pay_failure, "SYNTHETIC_TEMPLATE" if reinvestment else terms.reinvestment_strategy, residual,
                closing_defaulted, scheduled_received, prepayment_received, recovery_received, new_defaults, losses,
                new_expenses, expense_cap, deferred_expense_due, deferred_expense_paid, deferred_expense_arrears,
                cash_account_interest, cash_account_rate, cash_account_fixing,
                closing_valuation.collateral_value, closing_valuation.ccc_haircut, closing_valuation.discount_haircut,
                closing_valuation.long_dated_haircut, closing_valuation.overlap_credit, closing_valuation.defaulted_value, closing_valuation.long_dated_par,
                sum(shortfall_interest, ZERO), sum(waived, ZERO), incentive_fee, hurdle.balance if hurdle else ZERO,
                sale_par + sale_defaulted, sale_proceeds, sale_proceeds - sale_par - sale_defaulted,
                call_cost, call_status, refi_fee, refi_done,
                reinvestment_cash, reinvestment_par,
                non_cash_par_change,
                idt_numerator, idt_denominator, idt_ratio, idt_minimum, idt_status, idt_transferred, held_diversion_principal,
                sum(pik_coupons, ZERO),
                original_cash_interest, synthetic_result.interest_cash if synthetic_result else ZERO,
                original_exposure, reinvestment_exposure, debt_exposure,
                synthetic_result.reference_interest_cash if synthetic_result else ZERO,
                synthetic_result.spread_interest_cash if synthetic_result else ZERO,
            ))
            prior_payment = period.payment_date
            if status in {ProjectionStatus.COMPLETED, ProjectionStatus.FINAL_FEES_UNSETTLED} or (status is ProjectionStatus.CASH_PAY_FAILURE and not terms.continue_after_coupon_shortfall):
                break

        return CloProjection(
            tuple(summaries), tuple(snapshots), tuple(coverage), tuple(equity), status,
            status is ProjectionStatus.COMPLETED,
            summaries[-1].closing_collateral_par, sum((row.balance for row in notes), ZERO),
            interest_cash, principal_cash, pending_interest, pending_principal, reserve,
            expense_arrears + senior_fee_arrears, sum((row.unpaid_coupon for row in notes), ZERO),
            sub_fee_arrears, sum((row.amount for row in equity), ZERO),
            summaries[-1].defaulted_par,
            sum((row.newly_defaulted_par for row in summaries), ZERO),
            sum((row.recovery_principal_received for row in summaries), ZERO),
            sum((row.recognized_par_loss for row in summaries), ZERO),
            deferred_expense_arrears,
            sum((row.cash_account_interest for row in summaries), ZERO),
            tuple(equity_contributions), sum((row.incentive_fee_paid for row in summaries), ZERO),
            sum((row.collateral_sale_proceeds for row in summaries), ZERO), sum((row.refinancing_fee for row in summaries), ZERO),
            overlay_projection, reinvestment.purchases if reinvestment else (), tuple(synthetic_movements),
            first_projected_period_number=periods[0].period_number,
            # A stopped cash-pay projection may never reach a valid future
            # instruction. Receipt reconciliation must expose only cash that
            # was actually collected in this projected horizon.
            coupon_proceeds_audit=tuple(row for row in proceeds.audit_rows
                                       if row.payment_date <= summaries[-1].payment_date),
        )

    def _coupons(self, notes: list[_NoteState], period: AccrualPeriod, first_stub_rate_override: Decimal | None = None,
                  note_fixing_date: date | None = None, *, accrue_coupon_arrears: bool = False) -> tuple[list[Decimal], list[Decimal | None], list[Decimal], list[Decimal]]:
        """Resolve annual note rates and post coupon on opening face only.

        The returned parallel lists preserve payment-priority order. The
        separate arrears calculation uses these same rates when that policy is
        enabled; a zero-face class still needs a fixing if its claim accrues.
        The reference floor acts before margin, not on the all-in rate.
        """
        coupons: list[Decimal] = []
        indexes: list[Decimal | None] = []
        rates: list[Decimal] = []
        dcfs: list[Decimal] = []
        for note in notes:
            tranche = note.tranche
            index = None
            if tranche.coupon_type is CouponType.FIXED:
                rate = tranche.fixed_rate
            elif note.balance == 0 and not (accrue_coupon_arrears and note.unpaid_coupon):
                # A paid-off class has no new reset obligation or coupon.
                rate = ZERO
            else:
                index = (first_stub_rate_override if period.period_number == 1 and first_stub_rate_override is not None
                         else require_decimal(self._rate_provider.rate(tranche.rate_index, note_fixing_date or period.fixing_date), "note index rate"))
                rate = compose_floating_rate(index, tranche.spread_bps, tranche.index_floor)
            rate = require_decimal(rate, "note all-in rate", minimum=ZERO)
            exact_dcf = accrual_fraction(period.accrual_start, period.accrual_end, tranche.day_count)
            coupon = post_currency(Fraction(note.balance) * Fraction(rate) * exact_dcf)
            # External rate providers can return a magnitude not knowable when
            # the run context was sized. Retain every posted cent in its ledger.
            getcontext().prec = max(getcontext().prec, coupon.adjusted() + 40)
            coupons.append(coupon)
            indexes.append(index)
            rates.append(rate)
            dcfs.append(decimal_fraction(exact_dcf))
        return coupons, indexes, rates, dcfs

    @staticmethod
    def _redeem(cash: Decimal, notes: list[_NoteState], *, through: int | None = None) -> tuple[Decimal, list[Decimal]]:
        """Spend cash on senior face first, bounded by the tested stack.

        This atomic coverage allocation does not pay coupon claims. Its caller
        must establish the preceding coupon node and deduct the cash actually
        spent; returned residual remains owned by the originating cash account.
        """
        payments = []
        for index, note in enumerate(notes):
            paid = min(cash, note.balance) if through is None or index <= through else ZERO
            note.balance -= paid
            cash -= paid
            payments.append(paid)
        return cash, payments

    @staticmethod
    def _redeem_with_coupon_claims(cash: Decimal, notes: list[_NoteState], unpaid: list[Decimal]) -> tuple[Decimal, list[Decimal], list[Decimal]]:
        """Sequential controlling-class redemption, preserving coupon seniority.

        Senior nondeferrable coupons are supplemented before this node. A
        deferred junior claim becomes payable only as its class is reached,
        after senior debt is discharged, and precedes its own par redemption.
        """
        principals, coupons = [], []
        for index, state in enumerate(notes):
            coupon = min(cash, unpaid[index])
            cash -= coupon
            unpaid[index] -= coupon
            principal = min(cash, state.balance)
            cash -= principal
            state.balance -= principal
            coupons.append(coupon)
            principals.append(principal)
        return cash, principals, coupons

    @staticmethod
    def _redeem_pro_rata(cash: Decimal, notes: list[_NoteState]) -> tuple[Decimal, list[Decimal]]:
        """Exact largest-remainder cents; ties go to senior payment priority."""
        total = sum((Fraction(note.balance) for note in notes), Fraction(0))
        available = min(Fraction(cash), total)
        if not total:
            return cash, [ZERO for _ in notes]
        available_cents = int(available * 100)
        targets = [available * Fraction(note.balance) / total * 100 for note in notes]
        cents = [target.numerator // target.denominator for target in targets]
        residual = available_cents - sum(cents)
        order = sorted(range(len(notes)), key=lambda index: (-(targets[index] - cents[index]), notes[index].tranche.payment_priority))
        for index in order[:residual]:
            cents[index] += 1
        payments = [post_currency(Fraction(value, 100)) for value in cents]
        for note, paid in zip(notes, payments, strict=True):
            note.balance -= paid
        return cash - post_currency(available), payments

    @staticmethod
    def _fee_factor(par: _ParTimeline, request: CloRunRequest, period: AccrualPeriod, day_count: DayCount) -> Fraction:
        """Exact fee par times year fraction under the explicitly selected basis."""
        basis = request.terms.management_fee_basis
        if basis is ManagementFeeBasis.TIME_WEIGHTED_PERFORMING_PAR:
            denominator = 360 if day_count is DayCount.ACT_360 else 365
            return par.par_days(period.accrual_start, period.accrual_end) / denominator
        balance = (par.balance_at(period.accrual_start) if basis is ManagementFeeBasis.OPENING_PERFORMING_PAR else
                   par.balance_at(period.accrual_end) if basis is ManagementFeeBasis.CLOSING_PERFORMING_PAR else
                   request.opening_state.initial_collateral_par
                   if request.opening_state is not None and request.opening_state.initial_collateral_par is not None
                   else request.opening_collateral_par)
        return Fraction(balance) * accrual_fraction(period.accrual_start, period.accrual_end, day_count)

    def _cash_earnings(self, request: CloRunRequest, opening_date: date, cash_par_days: Fraction,
                       dated_cash_balances: list[tuple[date, Decimal]] | None = None,
                       payment_date: date | None = None) -> tuple[Decimal, Decimal | None, date | None]:
        """Post dated collection-account simple interest once per payment date.

        Physical cash is invested upon receipt, pending balances included;
        restricted reserve is excluded. Period credits become unrestricted
        interest proceeds on their credited distribution date. A projected term
        rate is constant over the period, with its own explicit fixing lag.
        Negative effective remuneration needs a debit-account policy and is
        rejected rather than silently floored unless a floor was supplied.
        """
        terms = request.terms
        if terms.cash_account_accrual_mode is CashAccountAccrualMode.NONE or not cash_par_days:
            return ZERO, None, None
        if terms.cash_account_accrual_mode is CashAccountAccrualMode.DF_FORWARD_SIMPLE:
            method = getattr(self._rate_provider, "accumulation_factor", None)
            if not callable(method) or dated_cash_balances is None or payment_date is None:
                raise InputValidationError("DF-forward collection cash requires an explicit discount-factor cash provider")
            exact = sum((Fraction(amount) * method(terms.cash_account_rate_index, received, payment_date,
                                                   terms.cash_account_day_count, terms.cash_account_spread_bps, terms.cash_account_rate_floor)
                         for received, amount in dated_cash_balances if amount and received < payment_date), Fraction(0))
            if exact < 0:
                raise InputValidationError("Negative cash-account remuneration requires a debit-account policy")
            earnings = post_currency(exact)
            getcontext().prec = max(getcontext().prec, earnings.adjusted() + 40)
            return earnings, None, None
        fixing = None
        if terms.cash_account_accrual_mode is CashAccountAccrualMode.FIXED_SIMPLE:
            reference = terms.cash_account_fixed_rate
        else:
            calendar = calendar_from_name(terms.fixing_calendar) if terms.fixing_calendar is not None else self._calendar
            fixing = calendar.add_business_days(opening_date, -terms.cash_account_fixing_lag_business_days)
            reference = require_decimal(self._rate_provider.rate(terms.cash_account_rate_index, fixing), "cash account term rate")
        rate = compose_floating_rate(reference, terms.cash_account_spread_bps)
        if terms.cash_account_rate_floor is not None:
            rate = max(rate, terms.cash_account_rate_floor)
        require_decimal(rate, "cash account all-in rate", minimum=ZERO)
        denominator = 360 if terms.cash_account_day_count is DayCount.ACT_360 else 365
        earnings = post_currency(cash_par_days * Fraction(rate) / denominator)
        getcontext().prec = max(getcontext().prec, earnings.adjusted() + 40)
        return earnings, rate, fixing

    @staticmethod
    def _oc_outstanding(notes: list[_NoteState], tested: int, unpaid_coupon_claims: list[Decimal], *, include_deferred_interest: bool) -> Decimal:
        """Coverage debt at the actual node, including capitalized claims once.

        The explicit unpaid list reflects payments made in this period; private
        note.unpaid_coupon still describes the opening state until snapshots.
        At its gate, a class has already received its permitted interest payment.
        Aggregate retests also include current claims of blocked junior classes:
        this explicit profile capitalizes their unpaid accrual on the same day,
        without implying every contract uses the same legal capitalization date.
        Cash-pay delinquent interest is excluded from this principal base. Face
        par and coupon cash ledgers are never mutated by this measurement.
        """
        return sum((state.balance + (unpaid if include_deferred_interest and state.tranche.interest_deferrable else ZERO)
                    for state, unpaid in zip(notes[:tested + 1], unpaid_coupon_claims[:tested + 1], strict=True)), ZERO)

    @staticmethod
    def _coverage(notes: list[_NoteState], tested: int, period: AccrualPeriod, stage: str, collateral_par: Decimal, principal_cash: Decimal, ic_numerator: Decimal, coupon_claims: tuple[Decimal, ...], *, unpaid_coupon_claims: list[Decimal], include_deferred_interest: bool, tests_enabled: bool = True, include_principal_cash: bool = True) -> CoverageTestResult:
        """Measure one class's senior-through-tested stack without mutating it.

        ``collateral_par`` is already adjusted OC credit, not necessarily face.
        OC = (adjusted credit + permitted physical principal cash) / outstanding
        tested amount; IC = fixed period interest proceeds / period debt service.
        Exact cross multiplication determines PASS/FAIL, independently of the
        displayed Decimal ratio. A missing threshold is NOT_CONFIGURED and a
        discharged stack is NOT_APPLICABLE, neither a fabricated active PASS.

        For interest-funded face redemption with unchanged numerator N, the
        minimum cure is ceil_to_cent(max(0, D - N/k)). Independent IDT instead
        increases N, so its transfer formula belongs to that separate node.
        """
        tranche = notes[tested].tranche
        oc_numerator = collateral_par + (principal_cash if include_principal_cash else ZERO)
        oc_denominator = DeterministicCloEngine._oc_outstanding(notes, tested, unpaid_coupon_claims,
                                                              include_deferred_interest=include_deferred_interest)
        ic_denominator = sum(coupon_claims[:tested + 1], ZERO)

        def assess(numerator: Decimal, denominator: Decimal, threshold: Decimal | None) -> tuple[Decimal | None, CoverageStatus]:
            ratio = decimal_fraction(Fraction(numerator) / Fraction(denominator)) if denominator else None
            if denominator == 0:
                return ratio, CoverageStatus.NOT_APPLICABLE
            if threshold is None:
                return ratio, CoverageStatus.NOT_CONFIGURED
            passed = Fraction(numerator) >= Fraction(denominator) * Fraction(threshold)
            return ratio, CoverageStatus.PASS if passed else CoverageStatus.FAIL

        oc_minimum = tranche.oc_minimum if tests_enabled else None
        ic_minimum = tranche.ic_minimum if tests_enabled else None
        oc_ratio, oc_status = assess(oc_numerator, oc_denominator, oc_minimum)
        ic_ratio, ic_status = assess(ic_numerator, ic_denominator, ic_minimum)
        if oc_denominator == 0 and not any(unpaid_coupon_claims[:tested + 1]):
            # Payment-day coupon mathematics remains visible, but a fully
            # redeemed tested debt stack has no live IC trigger. Do not label a
            # discharged class FAIL merely from its historical period coupon.
            ic_status = CoverageStatus.NOT_APPLICABLE
        if notes[tested].initially_inactive:
            # An explicitly retained settled class has no own active covenant
            # trigger. Its measured senior-prefix amounts remain diagnostics;
            # another live class's independent test is unaffected.
            oc_status = ic_status = CoverageStatus.NOT_APPLICABLE
        cure = None
        if oc_minimum is not None and oc_denominator:
            exact_cure = max(Fraction(0), Fraction(oc_denominator) - Fraction(oc_numerator) / Fraction(oc_minimum))
            # Minimum executable cent redemption rounds UP, not HALF_UP.
            scaled = exact_cure * 100
            cents = -(-scaled.numerator // scaled.denominator)
            cure = Decimal(cents) / 100
        return CoverageTestResult(
            period.period_number, period.payment_date, tranche.class_id, tranche.payment_priority, stage,
            oc_numerator, oc_denominator, oc_ratio, oc_minimum, oc_status,
            ic_numerator, ic_denominator, ic_ratio, ic_minimum, ic_status, cure,
        )

    @staticmethod
    def _normalize_projection_stream(
        collections: tuple[AssetCollection | OverlayCollection, ...],
        movements: tuple[_ParMovement, ...],
        overlay: PoolOverlayProjection | None,
    ) -> tuple[tuple[_Collection, ...], dict[date, Decimal], dict[date, Decimal], tuple[_ParMovement, ...], PoolOverlayProjection | None]:
        """Compile shared imported/overlay cash and independent par timelines.

        Each source has already validated its economic ledger. Cash uses its
        supplied receipt field, never the performing-face change: default can
        reduce performing face with no receipt, and recovery supplies cash with
        no performing-face change. Timeline inputs are signed *reductions*, so
        a new default enters the default-claim timeline as a negative reduction.
        """
        normalized = tuple(_Collection(
            row.loan_id, row.payment_date, row.cash_interest,
            row.principal_collection, row.source,
        ) for row in collections)
        performing_reductions: dict[date, Decimal] = {}
        default_reductions: dict[date, Decimal] = {}
        for row in movements:
            performing_reductions[row.event_date] = (
                performing_reductions.get(row.event_date, ZERO)
                + row.performing_par_before - row.performing_par_after
            )
            default_reductions[row.event_date] = (
                default_reductions.get(row.event_date, ZERO)
                + row.defaulted_par_before - row.defaulted_par_after
            )
        return (
            tuple(sorted(normalized, key=lambda row: (row.payment_date, row.loan_id))),
            performing_reductions, default_reductions,
            tuple(sorted(movements, key=lambda row: (row.event_date, row.loan_id))), overlay,
        )

    @staticmethod
    def _lagged_pik_overlay_reference(
        contractual: tuple[LoanCashflow, ...], opening_by_loan: dict[str, Decimal],
    ) -> tuple[tuple[OverlayCollection, ...], tuple[OverlayParMovement, ...], dict[str, frozenset[date]]]:
        """Freeze capitalization and actual cash dates for a dated PIK pool.

        A native PIK coupon adds collateral face at its shared capitalization
        date: accrual end, or an earlier advance-adjusted cash date. Principal
        and cash coupon arrive on the actual payment date. The external
        proportional profile can stress this independent dated reference, but
        its CPR dates must remain the original cash-payment boundaries: adding
        a noncash event must not invent an earlier prepayment decision.

        Reference coupons are the cent-posted native receipts, as in a Detailed
        generator export. Credit participation therefore rescales posted source
        cash, rather than silently claiming an exact unrounded native replay.
        """
        by_loan = {identity: {} for identity in opening_by_loan}
        collections = []
        prepayment_dates = {identity: set() for identity in opening_by_loan}
        for row in contractual:
            identity = row.loan_id
            pik = getattr(row, "pik_interest", ZERO)
            if pik:
                event = by_loan[identity].setdefault(row.pik_capitalization_date, [ZERO, ZERO])
                event[0] += pik
            if row.principal_repayment:
                event = by_loan[identity].setdefault(row.payment_date, [ZERO, ZERO])
                event[1] += row.principal_repayment
            collections.append(OverlayCollection(identity, "EUR", row.payment_date,
                AssetCashSource.SCHEDULED, row.cash_interest, row.principal_repayment,
                row.total_cash, row.period_number))
            prepayment_dates[identity].add(row.payment_date)
        movements = []
        for identity, events in by_loan.items():
            face = opening_by_loan[identity]
            for event_date, (pik, principal) in sorted(events.items()):
                closing = face + pik - principal
                if closing < 0:
                    raise InputValidationError("Lagged PIK reference would repay face before its capitalization")
                movements.append(OverlayParMovement(identity, event_date, AssetCashSource.SCHEDULED,
                    face, closing, ZERO, ZERO, principal, ZERO, pik))
                face = closing
            if face:
                raise InputValidationError("Lagged PIK reference requires complete final principal settlement")
        return (tuple(sorted(collections, key=lambda row: (row.payment_date, row.loan_id))),
                tuple(sorted(movements, key=lambda row: (row.event_date, row.loan_id))),
                {identity: frozenset(values) for identity, values in prepayment_dates.items()})

    @staticmethod
    def _collection_stream(
        request: CloRunRequest, contractual: tuple[LoanCashflow, ...], principal_events: dict[date, Decimal],
    ) -> tuple[tuple[_Collection, ...], dict[date, Decimal], dict[date, Decimal], tuple[_ParMovement, ...], PoolOverlayProjection | None]:
        """Separate performing-par changes from principal cash (including recovery).

        Credit projections retain the original contracts, complete event traces
        and full horizon. Missing/defaulted receipts cannot be passed off as an
        incomplete ordinary loan amortisation schedule.

        Exactly one source owns original receipts: imported records, generated
        proportional overlay, explicit event projections, or unstressed contract
        rows. Source-specific validation precedes shared normalization, so a
        second default overlay cannot double-count an already stressed stream.
        """
        if request.imported_collateral is not None:
            if request.asset_cashflows or request.asset_credit_projections:
                raise InputValidationError("Imported collateral must not be combined with duplicate generated contract or credit streams")
            projection = request.imported_collateral
            if not request.terms.allow_long_dated_assets and any(day > request.terms.legal_final_date for day in projection.final_principal_dates.values()):
                raise InputValidationError("Imported source contains forbidden long-dated principal")
            if projection.opening_performing_par != request.opening_collateral_par:
                raise InputValidationError("Imported opening performing par differs from CLO opening collateral")
            overlay_projection = None
            if request.terms.original_pool_overlay is not None and request.terms.original_pool_overlay.enabled:
                if projection.credit_effects_included:
                    raise InputValidationError("Imported already-stressed cashflows cannot receive a second credit overlay")
                from trident.credit.overlay import add_calendar_months
                horizon = add_calendar_months(max(row.payment_date for row in projection.collections), request.terms.original_pool_overlay.recovery_lag_months)
                # Detailed PIK has independent effective-date face movements.
                # Those noncash events are not additional borrower prepayment
                # decisions. Use the actual declared payment calendar and its
                # full cash-to-cash hazard intervals, just as native replay does.
                prepayment_dates = {identity: set() for identity in projection.loan_opening_par}
                for row in projection.collections:
                    if row.loan_id not in prepayment_dates:
                        raise InputValidationError("Imported payment calendar contains an unknown loan identity")
                    prepayment_dates[row.loan_id].add(row.payment_date)
                overlay_projection = request.terms.original_pool_overlay.project_external(projection.collections, projection.par_movements,
                    projection.loan_opening_par, request.projection_start_date, horizon,
                    prepayment_dates_by_loan={identity: frozenset(dates) for identity, dates in prepayment_dates.items()})
                projection = overlay_projection
            return DeterministicCloEngine._normalize_projection_stream(
                projection.collections, projection.par_movements, overlay_projection,
            )
        if request.terms.original_pool_overlay is not None and request.terms.original_pool_overlay.enabled:
            if request.asset_credit_projections:
                raise InputValidationError("Choose explicit per-asset events OR proportional pool overlay, never both")
            from trident.credit.overlay import add_calendar_months
            opening = {}
            for row in sorted(contractual, key=lambda row: row.period_number):
                opening.setdefault(row.loan_id, row.opening_balance)
            horizon = add_calendar_months(max(row.payment_date for row in contractual), request.terms.original_pool_overlay.recovery_lag_months)
            if any(getattr(row, "pik_interest", ZERO) and row.payment_date != row.accrual_end for row in contractual):
                # Keep actual capitalization date separate from collection.
                # The legacy export/import-equivalent proportional scenario
                # owns its dated cash/par reference; standalone PIK events
                # cannot create an extra CPR boundary or cash coupon receipt.
                reference_cash, reference_par, prepayment_dates = DeterministicCloEngine._lagged_pik_overlay_reference(contractual, opening)
                projection = request.terms.original_pool_overlay.project_external(
                    reference_cash, reference_par, opening, request.projection_start_date, horizon,
                    prepayment_dates_by_loan=prepayment_dates)
            else:
                projection = request.terms.original_pool_overlay.project(contractual, opening, request.projection_start_date, horizon,
                                                                       loan_day_counts=request.asset_day_counts)
            return DeterministicCloEngine._normalize_projection_stream(
                projection.collections, projection.par_movements, projection,
            )
        if not request.asset_credit_projections:
            collections = tuple(_Collection(row.loan_id, row.payment_date, row.cash_interest, row.principal_repayment) for row in contractual)
            return tuple(sorted(collections, key=lambda row: (row.payment_date, row.loan_id))), principal_events, {}, (), None
        grouped = {}
        for row in contractual:
            grouped.setdefault(row.loan_id, []).append(row)
        projections = {row.loan_id: row for row in request.asset_credit_projections}
        if len(projections) != len(request.asset_credit_projections) or projections.keys() != grouped.keys():
            raise InputValidationError("Credit projections must cover every original loan exactly once")
        collections, movements = [], []
        reductions, default_changes = {}, {}
        for loan_id, projection in projections.items():
            original = tuple(sorted(grouped[loan_id], key=lambda row: row.period_number))
            if (projection.currency != "EUR" or projection.projection_start != request.projection_start_date
                    or projection.opening_par != original[0].opening_balance
                    or projection.contractual_cashflows != original):
                raise InputValidationError(f"Credit projection differs from original loan identity/contract: {loan_id}")
            if (request.asset_day_counts is not None and loan_id in request.asset_day_counts
                    and projection.contractual_day_count is not None
                    and projection.contractual_day_count is not request.asset_day_counts[loan_id]):
                # Some conventions agree over a full regular period but differ
                # on a partial exit date. Bind the independent supplied native
                # contract convention as well as matching its frozen rows.
                raise InputValidationError(f"Credit day count differs from the identified native contract: {loan_id}")
            future_dates = [row.payment_date for row in original]
            if projection.event is not None:
                future_dates.append(projection.event.event_date)
                future_dates.extend(row.recovery_date for row in getattr(projection.event, "recoveries", ()))
                if getattr(projection.event, "writeoff_date", None) is not None:
                    future_dates.append(projection.event.writeoff_date)
            if projection.horizon_date < max(future_dates) or projection.pending_recovery_amount:
                raise InputValidationError("CLO requires a complete credit horizon; pending recovery cannot disappear")
            performing, defaulted_par = projection.opening_par, ZERO
            prior_date = request.projection_start_date
            receipt_check = {}
            for movement in projection.par_movements:
                if (movement.loan_id != loan_id or movement.event_date < prior_date
                        or movement.event_date <= request.projection_start_date
                        or movement.performing_par_before != performing
                        or movement.defaulted_par_before != defaulted_par):
                    raise InputValidationError(f"Credit movement chain is inconsistent: {loan_id}")
                for name in ("performing_par_before", "performing_par_after", "defaulted_par_before", "defaulted_par_after", "principal_receipt", "par_loss"):
                    require_money(getattr(movement, name), f"credit {name}")
                non_cash = getattr(movement, "non_cash_par_change", ZERO)
                if performing + defaulted_par + non_cash - movement.principal_receipt - movement.par_loss != movement.performing_par_after + movement.defaulted_par_after:
                    raise InputValidationError(f"Credit par/cash/loss bridge fails: {loan_id}")
                change = performing - movement.performing_par_after
                if change < 0 and not (movement.source is AssetCashSource.SCHEDULED and non_cash > 0):
                    raise InputValidationError("Recovery must not restore performing collateral")
                reductions[movement.event_date] = reductions.get(movement.event_date, ZERO) + change
                default_changes[movement.event_date] = default_changes.get(movement.event_date, ZERO) + defaulted_par - movement.defaulted_par_after
                key = movement.event_date, movement.source
                receipt_check[key] = receipt_check.get(key, ZERO) + movement.principal_receipt
                performing, defaulted_par, prior_date = movement.performing_par_after, movement.defaulted_par_after, movement.event_date
                movements.append(movement)
            if performing != projection.final_performing_par or defaulted_par != projection.final_defaulted_par:
                raise InputValidationError("Final credit states do not reconcile to movement trace")
            actual_receipts = {}
            for receipt in projection.collections:
                if receipt.loan_id != loan_id or receipt.currency != "EUR" or receipt.payment_date <= request.projection_start_date:
                    raise InputValidationError("Credit collections have an inconsistent loan/currency/date")
                for name in ("cash_interest", "principal_collection", "total_cash"):
                    require_money(getattr(receipt, name), f"credit receipt {name}")
                if receipt.cash_interest + receipt.principal_collection != receipt.total_cash:
                    raise InputValidationError("Credit receipt total_cash is inconsistent")
                key = receipt.payment_date, receipt.source
                actual_receipts[key] = actual_receipts.get(key, ZERO) + receipt.principal_collection
                collections.append(_Collection(loan_id, receipt.payment_date, receipt.cash_interest,
                                               receipt.principal_collection, receipt.source))
            if {k: v for k, v in receipt_check.items() if v} != {k: v for k, v in actual_receipts.items() if v}:
                raise InputValidationError("Credit principal receipts differ from dated par movement trace")
        return (tuple(sorted(collections, key=lambda row: (row.payment_date, row.loan_id, row.source.value))),
                reductions, default_changes, tuple(sorted(movements, key=lambda row: (row.event_date, row.loan_id))), None)

    @staticmethod
    def _validate_assets(request: CloRunRequest) -> tuple[tuple[LoanCashflow, ...], dict[date, Decimal]]:
        """Validate complete per-loan par chains before allocating any cash."""
        grouped: dict[str, list[LoanCashflow]] = {}
        events: dict[date, Decimal] = {}
        for row in request.asset_cashflows:
            if not isinstance(row.loan_id, str) or not row.loan_id or row.loan_id != row.loan_id.strip():
                raise InputValidationError("Asset cashflows require unpadded loan_id")
            if row.currency != "EUR":
                raise InputValidationError("This CLO increment supports EUR collections only")
            if type(row.period_number) is not int or row.period_number < 1:
                raise InputValidationError("Asset cashflow period_number must be a positive integer")
            for field_name in ("unadjusted_start", "unadjusted_end", "accrual_start", "accrual_end", "payment_date"):
                require_date(getattr(row, field_name), f"asset {field_name}")
            if row.fixing_date is not None:
                require_date(row.fixing_date, "asset fixing_date")
            if row.payment_date <= request.projection_start_date or row.accrual_end <= row.accrual_start or row.unadjusted_end <= row.unadjusted_start:
                raise InputValidationError("Asset cashflow dates are inconsistent with closing/positive accrual periods")
            for name in ("opening_balance", "closing_balance", "cash_interest", "principal_repayment", "total_cash"):
                require_money(getattr(row, name), f"asset {name}")
            pik = require_money(getattr(row, "pik_interest", ZERO), "asset pik_interest")
            if row.opening_balance == 0 or row.opening_balance + pik - row.principal_repayment != row.closing_balance:
                raise InputValidationError(f"Asset principal row does not conserve par: {row.loan_id}")
            if row.cash_interest + row.principal_repayment != row.total_cash:
                raise InputValidationError(f"Asset total_cash is inconsistent: {row.loan_id}")
            for name in ("spread_bps", "all_in_rate", "day_count_fraction", "interest_unrounded"):
                require_decimal(getattr(row, name), f"asset {name}")
            if row.index_rate is not None:
                require_decimal(row.index_rate, "asset index_rate")
            grouped.setdefault(row.loan_id, []).append(row)
            if row.principal_repayment:
                events[row.payment_date] = events.get(row.payment_date, ZERO) + row.principal_repayment
            if pik:
                day = row.pik_capitalization_date
                if not request.projection_start_date < day <= row.payment_date:
                    raise InputValidationError("Native PIK capitalization must follow opening and precede cash settlement")
                events[day] = events.get(day, ZERO) - pik

        initial_total = ZERO
        for loan_id, rows in grouped.items():
            rows.sort(key=lambda row: row.period_number)
            if rows[0].accrual_start != request.projection_start_date:
                raise InputValidationError(f"Asset {loan_id} must project from the CLO opening snapshot accrual boundary")
            initial_total += rows[0].opening_balance
            for index, row in enumerate(rows):
                if row.period_number != index + 1:
                    raise InputValidationError(f"Missing or duplicate asset periods: {loan_id}")
                if index:
                    prior = rows[index - 1]
                    if row.opening_balance != prior.closing_balance or row.accrual_start != prior.accrual_end or row.unadjusted_start != prior.unadjusted_end or row.payment_date < prior.payment_date:
                        raise InputValidationError(f"Asset balance/date chain is inconsistent: {loan_id}")
            if rows[-1].closing_balance != 0:
                raise InputValidationError(f"Asset {loan_id} contractual projection must include final principal repayment")
            if not request.terms.allow_long_dated_assets and rows[-1].payment_date > request.terms.legal_final_date:
                raise InputValidationError(f"Asset {loan_id} has principal after legal final while long-dated assets are forbidden")
        if initial_total != request.opening_collateral_par:
            raise InputValidationError("Opening collateral par differs from per-loan opening balances")
        return tuple(sorted(request.asset_cashflows, key=lambda row: (row.payment_date, row.loan_id, row.period_number))), events
