"""Read named legacy OIS paste blocks with explicit zero-rate conventions."""

from trident.conventions import DayCount
from trident.market.cash_accounts import CashCurveRateProvider, DiscountFactorCashCurve, ZeroCompounding, ZeroRatePoint
from trident.market.rates import ExtrapolationPolicy
from .excel_schema import CURVE_BLOCKS
from .records import date_value, decimal_value


def cash_curve_provider_from_workbook(adapter, term_provider, legacy, controls, *, asset_indices=()):
    """Resolve every selected OIS block once for assets and collection cash.

    Borrower coupons and account accrual share frozen zero curves, but retain
    their own day counts and spread. A zero rate is never a term-index fixing.
    Standalone mode also needs its selected O/N curves even without a CLO.
    """
    requested = set(asset_indices)
    if controls["mode"] == "CLO_BASELINE":
        requested.add(legacy["cash_accrual_curve"])
    indices = sorted(requested & {"ESTR", "SOFR", "SONIA"})
    if not indices:
        return term_provider
    block = CURVE_BLOCKS[1]
    sheet, (left, top, right, bottom) = adapter.region(block.range_name)
    columns = {sheet.cell(top, column).value: column for column in range(left, right + 1)}
    # Metadata columns and the bounded rectangle came from a named interface.
    tenor_column = block.columns[0]
    curves = {}
    for index in indices:
        index_column = next(label for label in block.columns if label.startswith(index))
        points = []
        for row in range(top + 1, bottom + 1):
            tenor, rate = sheet.cell(row, columns[tenor_column]).value, sheet.cell(row, columns[index_column]).value
            if tenor is None and rate is None:
                continue
            points.append(ZeroRatePoint(decimal_value(tenor, "cash zero tenor"), decimal_value(rate, "cash zero rate")))
        curves[index] = DiscountFactorCashCurve(index, date_value(controls["valuation_date"], "valuation_date"),
            tuple(points), ZeroCompounding(controls["zero_curve_compounding"]), DayCount(controls["zero_curve_day_count"]),
            ExtrapolationPolicy(controls["curve_extrapolation"]),
            "USER_PASTED_OIS_FORWARD_PROJECTION; explicit zero compounding/basis")
    return CashCurveRateProvider(term_provider, curves)
