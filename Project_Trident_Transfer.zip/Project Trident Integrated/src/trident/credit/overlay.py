"""Fractional-pool credit overlays with separate cash and claim ledgers.

This is an economic scenario for proportional slices of identified loans, not
an issuer-default simulation or an agency calibration. Defaults occur at an
interval's calendar midpoint, scheduled principal survives in the same ratio,
and CPR exits the remaining par at interval end. Surviving loans pay their
contractual coupon; an unpaid coupon on the defaulted slice is not cash.
Recovery/workout dates are actual calendar months after default, including
zero lag and zero recovery. No default claim is resolved by dividing cash by RR.
"""

from __future__ import annotations

from calendar import monthrange
from dataclasses import dataclass
from datetime import date, timedelta
from decimal import Decimal
from enum import Enum
from fractions import Fraction
from trident.cashflows.coupons import cashflow_coupon_factor
from collections.abc import Mapping

from trident.credit.models import AssetCashSource
from trident.credit.stress_rates import conditional_period_probability
from trident.conventions.day_count import DayCount, accrual_fraction
from trident.domain.models import InputValidationError, LoanCashflow, require_date, require_decimal, require_money
from trident.domain.numeric import post_currency


ZERO = Decimal(0)


def add_calendar_months(value: date, months: int) -> date:
    """Shift from the original calendar anchor, clipping only the target month."""
    require_date(value, "calendar month origin")
    if type(months) is not int or months < 0:
        raise InputValidationError("calendar months must be a nonnegative integer")
    absolute = value.year * 12 + value.month - 1 + months
    year, month_zero = divmod(absolute, 12)
    if not 1 <= year <= 9999:
        raise InputValidationError("calendar month shift exceeds the supported date range")
    month = month_zero + 1
    return date(year, month, min(value.day, monthrange(year, month)[1]))


def _sum(values) -> Decimal:
    return post_currency(sum((Fraction(value) for value in values), Fraction()))


def _difference(left: Decimal, right: Decimal) -> Decimal:
    return post_currency(Fraction(left) - Fraction(right))


def _probability(value: Decimal, label: str) -> None:
    require_decimal(value, label, minimum=ZERO)
    if value > 1:
        raise InputValidationError(f"{label} must lie in [0, 1]")


class DefaultTimingPattern(str, Enum):
    """Historical timing labels retained solely for transparent sensitivity."""

    FLAT = "Flat"
    SP_PATTERN_1 = "S&P Pattern 1"
    SP_PATTERN_2 = "S&P Pattern 2"
    SP_PATTERN_3 = "S&P Pattern 3"
    SP_PATTERN_4 = "S&P Pattern 4"


_PATTERN_WEIGHTS = {
    DefaultTimingPattern.SP_PATTERN_1: (39, 22, 16, 13, 10),
    DefaultTimingPattern.SP_PATTERN_2: (16, 23, 26, 22, 13),
    DefaultTimingPattern.SP_PATTERN_3: (12, 18, 22, 23, 25),
    DefaultTimingPattern.SP_PATTERN_4: (20, 20, 20, 20, 20),
}


@dataclass(frozen=True)
class OverlayCollection:
    """Actual dated cash; a recovery receipt cannot restore performing par."""

    loan_id: str
    currency: str
    payment_date: date
    source: AssetCashSource
    cash_interest: Decimal
    principal_collection: Decimal
    total_cash: Decimal
    contractual_period_number: int | None = None

    def __post_init__(self) -> None:
        if not isinstance(self.loan_id, str) or not self.loan_id or self.loan_id != self.loan_id.strip():
            raise InputValidationError("Overlay collection requires an unpadded loan ID")
        if self.currency != "EUR":
            raise InputValidationError("Fractional CLO overlay supports EUR only")
        require_date(self.payment_date, "overlay collection date")
        if not isinstance(self.source, AssetCashSource) or self.source not in {AssetCashSource.SCHEDULED, AssetCashSource.PREPAYMENT, AssetCashSource.RECOVERY}:
            raise InputValidationError("Overlay cash source must be scheduled, prepayment or recovery")
        for field in ("cash_interest", "principal_collection", "total_cash"):
            require_money(getattr(self, field), field)
        if Fraction(self.total_cash) != Fraction(self.cash_interest) + Fraction(self.principal_collection):
            raise InputValidationError("Overlay collection cash bridge fails")
        if self.contractual_period_number is not None and (type(self.contractual_period_number) is not int or self.contractual_period_number < 1):
            raise InputValidationError("Overlay contractual period number must be a positive integer when supplied")
        if self.source is AssetCashSource.RECOVERY and self.cash_interest:
            raise InputValidationError("Overlay recovery collects principal, not an inferred interest claim")


@dataclass(frozen=True)
class OverlayParMovement:
    """Partial exits under a proportional scenario, with cent conservation."""

    loan_id: str
    event_date: date
    source: AssetCashSource
    performing_par_before: Decimal
    performing_par_after: Decimal
    defaulted_par_before: Decimal
    defaulted_par_after: Decimal
    principal_receipt: Decimal
    par_loss: Decimal
    non_cash_par_change: Decimal = ZERO

    def __post_init__(self) -> None:
        if not isinstance(self.loan_id, str) or not self.loan_id or self.loan_id != self.loan_id.strip():
            raise InputValidationError("Overlay movement requires an unpadded loan ID")
        require_date(self.event_date, "overlay movement date")
        if not isinstance(self.source, AssetCashSource):
            raise InputValidationError("Overlay movement source must be AssetCashSource")
        for field in ("performing_par_before", "performing_par_after", "defaulted_par_before", "defaulted_par_after", "principal_receipt", "par_loss"):
            require_money(getattr(self, field), field)
        p = Fraction(self.performing_par_before) - Fraction(self.performing_par_after)
        d = Fraction(self.defaulted_par_before) - Fraction(self.defaulted_par_after)
        cash, loss = Fraction(self.principal_receipt), Fraction(self.par_loss)
        non_cash = require_decimal(self.non_cash_par_change, "overlay non_cash_par_change")
        if post_currency(Fraction(non_cash)) != non_cash:
            raise InputValidationError("Overlay noncash par change must be cent money")
        if p + d != cash + loss - Fraction(non_cash):
            raise InputValidationError("Overlay movement principal/cash/loss bridge fails")
        if self.source is AssetCashSource.DEFAULT:
            valid = p > 0 and d == -p and cash == loss == non_cash == 0
        elif self.source is AssetCashSource.SCHEDULED:
            valid = p == cash - Fraction(non_cash) and d == loss == 0
        elif self.source is AssetCashSource.PREPAYMENT:
            valid = p == cash and d == loss == non_cash == 0
        elif self.source is AssetCashSource.RECOVERY:
            valid = p == 0 and d == cash and loss == non_cash == 0
        else:
            valid = p == 0 and d == loss and cash == non_cash == 0
        if not valid:
            raise InputValidationError("Overlay economic operation is inconsistent")


@dataclass(frozen=True)
class OverlayAssetProjection:
    """An identified cash/par bridge, revalidated at its public boundary."""

    loan_id: str
    opening_par: Decimal
    collections: tuple[OverlayCollection, ...]
    par_movements: tuple[OverlayParMovement, ...]
    final_performing_par: Decimal
    final_defaulted_par: Decimal
    total_par_loss: Decimal
    pending_recovery_amount: Decimal
    unallocated_default_target: Decimal = ZERO

    def __post_init__(self) -> None:
        if not isinstance(self.loan_id, str) or not self.loan_id or self.loan_id != self.loan_id.strip():
            raise InputValidationError("Overlay asset requires an unpadded loan ID")
        require_money(self.opening_par, "overlay asset opening par", positive=True)
        for name in ("final_performing_par", "final_defaulted_par", "total_par_loss", "pending_recovery_amount", "unallocated_default_target"):
            require_money(getattr(self, name), f"overlay asset {name}")
        for rows, kind, label in ((self.collections, OverlayCollection, "collections"),
                                  (self.par_movements, OverlayParMovement, "par_movements")):
            if type(rows) is not tuple or any(not isinstance(row, kind) or row.loan_id != self.loan_id for row in rows):
                raise InputValidationError(f"Overlay asset {label} must be immutable, typed and identified")
        performing, defaulted = self.opening_par, ZERO
        previous_date = date.min
        movement_cash: dict[tuple[date, AssetCashSource], Fraction] = {}
        loss, non_cash = Fraction(), Fraction()
        for row in self.par_movements:
            if row.event_date < previous_date or row.performing_par_before != performing or row.defaulted_par_before != defaulted:
                raise InputValidationError("Overlay asset par subledgers must form an ordered continuous bridge")
            performing, defaulted, previous_date = row.performing_par_after, row.defaulted_par_after, row.event_date
            key = row.event_date, row.source
            movement_cash[key] = movement_cash.get(key, Fraction()) + Fraction(row.principal_receipt)
            loss += Fraction(row.par_loss)
            non_cash += Fraction(row.non_cash_par_change)
        collection_cash: dict[tuple[date, AssetCashSource], Fraction] = {}
        previous_date = date.min
        for row in self.collections:
            if row.payment_date < previous_date:
                raise InputValidationError("Overlay asset collections must be chronological")
            previous_date = row.payment_date
            key = row.payment_date, row.source
            collection_cash[key] = collection_cash.get(key, Fraction()) + Fraction(row.principal_collection)
        if any(collection_cash.get(key, Fraction()) != movement_cash.get(key, Fraction())
               for key in movement_cash.keys() | collection_cash.keys()):
            raise InputValidationError("Overlay asset principal receipts must match dated par movements")
        if performing != self.final_performing_par or defaulted != self.final_defaulted_par or loss != Fraction(self.total_par_loss):
            raise InputValidationError("Overlay asset final balances/loss must match its par subledgers")
        if Fraction(self.opening_par) + non_cash != Fraction(performing) + Fraction(defaulted) + loss + sum(collection_cash.values(), Fraction()):
            raise InputValidationError("Overlay asset opening/noncash par does not reconcile to cash, claims and loss")
        if self.pending_recovery_amount > defaulted:
            raise InputValidationError("Overlay pending recovery cannot exceed outstanding defaulted face")


@dataclass(frozen=True)
class PoolOverlayProjection:
    """Results retain loan identity and an explicit unattainable-target warning."""

    assets: tuple[OverlayAssetProjection, ...]
    collections: tuple[OverlayCollection, ...]
    par_movements: tuple[OverlayParMovement, ...]
    final_performing_par: Decimal
    final_defaulted_par: Decimal
    total_par_loss: Decimal
    pending_recovery_amount: Decimal
    unallocated_default_target: Decimal

    def __post_init__(self) -> None:
        if type(self.assets) is not tuple or any(not isinstance(asset, OverlayAssetProjection) for asset in self.assets):
            raise InputValidationError("Overlay pool assets must be an immutable typed tuple")
        if len({asset.loan_id for asset in self.assets}) != len(self.assets):
            raise InputValidationError("Overlay pool must identify each asset once")
        expected_cash = tuple(sorted((row for asset in self.assets for row in asset.collections),
                                     key=lambda row: (row.payment_date, row.loan_id, row.source.value)))
        expected_movements = tuple(sorted((row for asset in self.assets for row in asset.par_movements),
                                          key=lambda row: (row.event_date, row.loan_id)))
        if self.collections != expected_cash or self.par_movements != expected_movements:
            raise InputValidationError("Overlay pool ledgers must equal their identified asset ledgers")
        for name in ("final_performing_par", "final_defaulted_par", "total_par_loss", "pending_recovery_amount", "unallocated_default_target"):
            value = require_money(getattr(self, name), f"overlay pool {name}")
            if value != _sum(getattr(asset, name) for asset in self.assets):
                raise InputValidationError(f"Overlay pool {name} must reconcile to identified assets")


@dataclass(frozen=True)
class FractionalPeriodResult:
    """One interval's physical receipts and performing face, all in EUR cents.

    ``default_par`` transfers face into a separate claim; it is not a loss or
    receipt. ``unallocated_default_target`` shows capacity clipping instead of
    claiming the requested vector stress was fully realized.
    """
    opening_par: Decimal
    default_par: Decimal
    scheduled_principal: Decimal
    prepayment_principal: Decimal
    closing_par: Decimal
    cash_interest: Decimal
    unallocated_default_target: Decimal


def project_fractional_period(
    *, opening_par: Decimal, contractual_opening_par: Decimal,
    contractual_interest: Decimal, contractual_principal: Decimal,
    default_amount: Decimal, prepayment_rate: Decimal,
    start_date: date, end_date: date,
    contractual_interest_unrounded: Fraction | Decimal | None = None,
) -> FractionalPeriodResult:
    """Default → surviving scheduled principal → end-date CPR.

    Default amount may be a fixed vector target and is clipped with an explicit
    shortfall. Defaulted unpaid coupons are lost; default does not manufacture
    an accrued-interest receipt. End-date prepayment earns the full surviving
    coupon. A supplied exact unrounded coupon avoids scaling a posted cent.
    Scheduled principal is posted once; a final bullet repays every surviving
    cent. Its reference denominator is the contractual opening balance, whereas
    the hazard acts on current performing face after all previous exits.
    """
    for field, value in (("opening_par", opening_par), ("contractual_opening_par", contractual_opening_par), ("contractual_interest", contractual_interest), ("contractual_principal", contractual_principal), ("default_amount", default_amount)):
        require_money(value, field)
    require_date(start_date, "fractional period start")
    require_date(end_date, "fractional period end")
    if end_date <= start_date or contractual_opening_par <= 0:
        raise InputValidationError("Fractional periods need positive time and reference par")
    if opening_par > contractual_opening_par or contractual_principal > contractual_opening_par:
        raise InputValidationError("Performing/scheduled reference par exceeds contractual opening par")
    _probability(prepayment_rate, "prepayment_rate")
    defaulted = min(opening_par, default_amount)
    survived = _difference(opening_par, defaulted)
    scheduled = post_currency(Fraction(survived) * Fraction(contractual_principal) / Fraction(contractual_opening_par))
    remaining = _difference(survived, scheduled)
    prepaid = conditional_period_probability(prepayment_rate, start_date, end_date).apply_to_par(remaining)
    if contractual_interest_unrounded is None:
        exact_coupon = Fraction(contractual_interest)
    else:
        if not isinstance(contractual_interest_unrounded, (Fraction, Decimal)):
            raise InputValidationError("Unrounded contractual coupon must be an exact Fraction or finite Decimal")
        if isinstance(contractual_interest_unrounded, Decimal):
            require_decimal(contractual_interest_unrounded, "unrounded contractual coupon", minimum=ZERO)
        exact_coupon = Fraction(contractual_interest_unrounded)
        if exact_coupon < 0 or post_currency(exact_coupon) != contractual_interest:
            raise InputValidationError("Unrounded contractual coupon must reconcile to its posted contractual amount")
    interest = post_currency(exact_coupon * Fraction(survived) / Fraction(contractual_opening_par))
    return FractionalPeriodResult(
        opening_par, defaulted, scheduled, prepaid, _difference(remaining, prepaid), interest,
        _difference(default_amount, defaulted),
    )


@dataclass(frozen=True)
class OriginalPoolOverlay:
    """Executable legacy controls B62–65, B70 and B133, with repaired semantics.

    Flat is a conditional ACT/365F CDR. Historical S&P-label profiles allocate
    the explicit economic target initial_par × [1-(1-CDR)^5] over five original
    calendar anniversaries; they never multiply CDR by a weight. Defaults after
    year five are zero in that profile. Amortization/CPR capacity shortfalls are
    reported, never silently called a complete calibrated stress.
    """

    enabled: bool = False
    annual_default_rate: Decimal = Decimal("0.02")
    annual_prepayment_rate: Decimal = ZERO
    recovery_rate: Decimal = Decimal("0.6")
    recovery_lag_months: int = 6
    default_timing_pattern: DefaultTimingPattern = DefaultTimingPattern.FLAT

    def __post_init__(self) -> None:
        if type(self.enabled) is not bool:
            raise InputValidationError("overlay enabled must be bool")
        for name in ("annual_default_rate", "annual_prepayment_rate", "recovery_rate"):
            _probability(getattr(self, name), name)
        if type(self.recovery_lag_months) is not int or self.recovery_lag_months < 0:
            raise InputValidationError("Recovery lag must be nonnegative calendar months")
        if not isinstance(self.default_timing_pattern, DefaultTimingPattern):
            raise InputValidationError("default_timing_pattern must be DefaultTimingPattern")

    def fixed_target(self, initial_par: Decimal) -> Decimal:
        """Five 365-day conditional years, independent of coupon day count."""
        require_money(initial_par, "fixed target initial par")
        return post_currency(Fraction(initial_par) * (1 - (1 - Fraction(self.annual_default_rate)) ** 5))

    def target_through(self, initial_par: Decimal, origin: date, value: date) -> Decimal:
        """Cumulative fixed target; differences conserve every cent over time."""
        if self.default_timing_pattern is DefaultTimingPattern.FLAT:
            raise InputValidationError("Flat CDR has no fixed timing target")
        require_date(origin, "default vector origin")
        require_date(value, "default vector horizon")
        target = self.fixed_target(initial_par)
        weight = Fraction()
        for index, percentage in enumerate(_PATTERN_WEIGHTS[self.default_timing_pattern]):
            start, end = add_calendar_months(origin, 12 * index), add_calendar_months(origin, 12 * (index + 1))
            elapsed = max(0, min((value - start).days, (end - start).days))
            weight += Fraction(percentage, 100) * Fraction(elapsed, (end - start).days)
        return post_currency(Fraction(target) * weight)

    def project_external(
        self, collections: tuple, par_movements: tuple,
        opening_par_by_loan: Mapping[str, Decimal], projection_start: date,
        horizon_date: date, *, prepayment_dates_by_loan: Mapping[str, frozenset[date]] | None = None,
    ) -> PoolOverlayProjection:
        """Stress an unstressed imported cash/par reference without LoanTerms.

        Independent cash/par movements are retained, including supplied PIK
        increases. No default/recovery MEMO becomes another claim or cashflow.
        The adapter must separately prohibit already-stressed input + overlay.
        Nonzero stress needs a complete future par reference; a truncated
        horizon can still default exposure before the next unpaid source row.
        Delayed interest after complete repayment is retained if its entitlement
        is unchanged, otherwise explicit receivable metadata is required.
        """
        require_date(projection_start, "external overlay start")
        require_date(horizon_date, "external overlay horizon")
        if horizon_date < projection_start or type(collections) is not tuple or type(par_movements) is not tuple:
            raise InputValidationError("External overlay needs ordered immutable records and a valid horizon")
        cash_by_loan: dict[str, dict[date, list]] = {identity: {} for identity in opening_par_by_loan}
        par_by_loan: dict[str, dict[date, list]] = {identity: {} for identity in opening_par_by_loan}
        for item, target, date_field in ((collections, cash_by_loan, "payment_date"), (par_movements, par_by_loan, "event_date")):
            for row in item:
                if row.loan_id not in target:
                    raise InputValidationError("External overlay record has an unknown loan ID")
                value = getattr(row, date_field)
                require_date(value, "external overlay record date")
                if value < projection_start:
                    raise InputValidationError("External overlay records cannot precede projection start")
                target[row.loan_id].setdefault(value, []).append(row)
        if prepayment_dates_by_loan is not None:
            # A separate capitalization boundary is not a licensed voluntary
            # repayment date. Native PIK with lagged cash supplies its actual
            # receipt calendar here; legacy imported callers may retain the
            # existing all-source-event policy by leaving this field absent.
            if not isinstance(prepayment_dates_by_loan, Mapping) or set(prepayment_dates_by_loan) != set(opening_par_by_loan):
                raise InputValidationError("External overlay prepayment dates must identify every source loan")
            for identity, dates in prepayment_dates_by_loan.items():
                if type(dates) is not frozenset:
                    raise InputValidationError("External overlay prepayment date sets must be immutable frozensets")
                for value in dates:
                    require_date(value, "external overlay prepayment date")
                    if value not in cash_by_loan[identity]:
                        raise InputValidationError("External overlay prepayment dates must be actual source cash receipt dates")
        assets = []
        for identity, opening in opening_par_by_loan.items():
            require_money(opening, "external overlay opening par", positive=True)
            reference, performing = opening, opening
            previous = projection_start
            previous_prepayment_date = projection_start
            raw = []
            cash = []
            claims = []
            defaults_total = Fraction()
            dates = sorted(set(cash_by_loan[identity]) | set(par_by_loan[identity]))
            # Validate the entire frozen reference, including rows beyond the
            # requested horizon. Otherwise missing principal can silently stop
            # hazard while an asset still appears in later CLO snapshots.
            full_reference = opening
            for value in dates:
                principal_cash = _sum(row.principal_collection for row in cash_by_loan[identity].get(value, []))
                principal_moves = ZERO
                for movement in par_by_loan[identity].get(value, []):
                    if movement.performing_par_before != full_reference:
                        raise InputValidationError("External overlay reference par chain is inconsistent")
                    after = require_money(movement.performing_par_after, "external reference closing par")
                    if full_reference == 0 and after != 0:
                        raise InputValidationError("External reference cannot restart a fully repaid loan")
                    if movement.source is not AssetCashSource.SCHEDULED or movement.defaulted_par_before or movement.defaulted_par_after or movement.par_loss:
                        raise InputValidationError("External overlay reference cannot contain an already stressed credit ledger")
                    principal_moves = _sum((principal_moves, require_money(movement.principal_receipt, "external reference principal receipt")))
                    full_reference = after
                if principal_cash != principal_moves:
                    raise InputValidationError("External overlay cash must reconcile to dated reference principal receipts")
                for receipt in cash_by_loan[identity].get(value, []):
                    if receipt.currency != "EUR" or receipt.source is not AssetCashSource.SCHEDULED:
                        raise InputValidationError("External overlay requires unstressed scheduled EUR receipts")
                    for name in ("cash_interest", "principal_collection", "total_cash"):
                        require_money(getattr(receipt, name), f"external reference {name}")
                    if Fraction(receipt.total_cash) != Fraction(receipt.cash_interest) + Fraction(receipt.principal_collection):
                        raise InputValidationError("External overlay reference cash bridge fails")
            if self.enabled and (self.annual_default_rate or self.annual_prepayment_rate) and full_reference:
                raise InputValidationError("Nonzero imported credit/prepayment overlay requires a complete future principal reference; refresh source cashflows")
            terminal_entitlement = Fraction(1)
            for source_end in dates:
                end = min(source_end, horizon_date)
                if end < previous or (end == previous and source_end != projection_start):
                    break
                is_due = source_end <= horizon_date
                if reference <= 0:
                    if not is_due:
                        break
                    tail_interest = _sum(row.cash_interest for row in cash_by_loan[identity].get(end, []))
                    if tail_interest and terminal_entitlement != 1:
                        raise InputValidationError("Delayed imported interest after stressed principal repayment needs explicit receivable entitlement")
                    if tail_interest:
                        cash.append(OverlayCollection(identity, "EUR", end, AssetCashSource.SCHEDULED,
                                                      tail_interest, ZERO, tail_interest))
                    previous = end
                    continue
                records = par_by_loan[identity].get(end, []) if is_due else []
                closing_reference = reference
                for movement in records:
                    if movement.performing_par_before != closing_reference:
                        raise InputValidationError("External overlay reference par chain is inconsistent")
                    closing_reference = require_money(movement.performing_par_after, "external reference closing par")
                interest = _sum(row.cash_interest for row in cash_by_loan[identity].get(end, [])) if is_due else ZERO
                principal = _sum(row.principal_collection for row in cash_by_loan[identity].get(end, [])) if is_due else ZERO
                if not self.enabled:
                    requested = ZERO
                elif self.default_timing_pattern is DefaultTimingPattern.FLAT:
                    requested = conditional_period_probability(self.annual_default_rate, previous, end).apply_to_par(performing)
                else:
                    requested = _difference(self.target_through(opening, projection_start, end), self.target_through(opening, projection_start, previous))
                defaulted = min(performing, requested)
                survived = _difference(performing, defaulted)
                midpoint = previous + timedelta(days=max(1, (end - previous).days // 2))
                if defaulted:
                    raw.append((midpoint, 0, AssetCashSource.DEFAULT, defaulted, ZERO, ZERO))
                    claims.append((add_calendar_months(midpoint, self.recovery_lag_months), defaulted))
                    defaults_total += Fraction(defaulted)
                participation = Fraction(survived) / Fraction(reference)
                scheduled_cash = post_currency(Fraction(principal) * participation)
                scheduled_close = post_currency(Fraction(closing_reference) * participation)
                non_cash = post_currency(Fraction(scheduled_close) - Fraction(survived) + Fraction(scheduled_cash))
                # Source cash is a receipt at end, not an interest accrual claim
                # on a slice which defaulted before that date.
                coupon = post_currency(Fraction(interest) * participation)
                if is_due:
                    cash.append(OverlayCollection(identity, "EUR", end, AssetCashSource.SCHEDULED, coupon, scheduled_cash, _sum((coupon, scheduled_cash))))
                if scheduled_cash or non_cash:
                    raw.append((end, 2, AssetCashSource.SCHEDULED, scheduled_cash, ZERO, non_cash))
                allow_prepayment = (prepayment_dates_by_loan is None or end in prepayment_dates_by_loan[identity])
                prepaid = conditional_period_probability(self.annual_prepayment_rate
                    if self.enabled and is_due and allow_prepayment else ZERO,
                    previous_prepayment_date, end).apply_to_par(scheduled_close)
                if is_due and allow_prepayment:
                    previous_prepayment_date = end
                if prepaid:
                    raw.append((end, 3, AssetCashSource.PREPAYMENT, prepaid, ZERO, ZERO))
                    cash.append(OverlayCollection(identity, "EUR", end, AssetCashSource.PREPAYMENT, ZERO, prepaid, prepaid))
                performing = _difference(scheduled_close, prepaid)
                if closing_reference == 0:
                    terminal_entitlement = participation
                previous, reference = end, closing_reference
                if not is_due:
                    break
            pending = Fraction()
            for recovery_date, claim in claims:
                recovered = post_currency(Fraction(claim) * Fraction(self.recovery_rate))
                loss = _difference(claim, recovered)
                if recovery_date > horizon_date:
                    pending += Fraction(recovered)
                    continue
                if recovered:
                    raw.append((recovery_date, 1, AssetCashSource.RECOVERY, recovered, ZERO, ZERO))
                    cash.append(OverlayCollection(identity, "EUR", recovery_date, AssetCashSource.RECOVERY, ZERO, recovered, recovered))
                if loss:
                    raw.append((recovery_date, 1, AssetCashSource.WRITE_OFF, ZERO, loss, ZERO))
            p, d = opening, ZERO
            movements = []
            for event_date, priority, source, amount, loss, non_cash in sorted(raw, key=lambda row: (row[0], row[1])):
                before_p, before_d = p, d
                receipt = ZERO
                if source is AssetCashSource.DEFAULT:
                    p, d = _difference(p, amount), _sum((d, amount))
                elif source is AssetCashSource.SCHEDULED:
                    p = post_currency(Fraction(p) - Fraction(amount) + Fraction(non_cash))
                    receipt = amount
                elif source is AssetCashSource.PREPAYMENT:
                    p, receipt = _difference(p, amount), amount
                elif source is AssetCashSource.RECOVERY:
                    d, receipt = _difference(d, amount), amount
                else:
                    d = _difference(d, loss)
                movements.append(OverlayParMovement(identity, event_date, source, before_p, p, before_d, d, receipt, loss, non_cash))
            if p != performing:
                raise ArithmeticError("External overlay dated and economic par disagree")
            loss = _sum(row.par_loss for row in movements)
            shortfall = (_difference(self.target_through(opening, projection_start, horizon_date), post_currency(defaults_total))
                         if self.enabled and self.default_timing_pattern is not DefaultTimingPattern.FLAT else ZERO)
            assets.append(OverlayAssetProjection(identity, opening, tuple(sorted(cash, key=lambda row: (row.payment_date, row.source.value))), tuple(movements), p, d, loss, post_currency(pending), shortfall))
        return PoolOverlayProjection(
            tuple(assets), tuple(sorted((row for asset in assets for row in asset.collections), key=lambda row: (row.payment_date, row.loan_id, row.source.value))),
            tuple(sorted((row for asset in assets for row in asset.par_movements), key=lambda row: (row.event_date, row.loan_id))),
            _sum(asset.final_performing_par for asset in assets), _sum(asset.final_defaulted_par for asset in assets), _sum(asset.total_par_loss for asset in assets),
            _sum(asset.pending_recovery_amount for asset in assets), _sum(asset.unallocated_default_target for asset in assets),
        )

    def project(
        self, contractual_cashflows: tuple[LoanCashflow, ...],
        opening_par_by_loan: Mapping[str, Decimal], projection_start: date,
        horizon_date: date, *, loan_day_counts: Mapping[str, DayCount] | None = None,
    ) -> PoolOverlayProjection:
        """Compile once; partial credit slices never reappear in future coupons.

        Explicit day counts preserve exact accrual and one cent posting. The
        standalone fallback uses the frozen unrounded coupon diagnostic; it
        cannot certify an irrational/truncated diagnostic at every half-cent.

        Group the reference once by loan, carry each loan's surviving face, and
        prepare cash/default events before replaying their chronological order.
        This keeps midpoint defaults, lagged recoveries and end-date principal
        distinct even when events from different coupon intervals interleave.
        Contract coupon DCF and ACT/365F hazard time intentionally differ.
        """
        require_date(projection_start, "overlay projection start")
        require_date(horizon_date, "overlay horizon")
        if horizon_date < projection_start:
            raise InputValidationError("Overlay horizon precedes projection start")
        if type(contractual_cashflows) is not tuple or any(not isinstance(row, LoanCashflow) for row in contractual_cashflows):
            raise InputValidationError("Overlay requires typed immutable contractual cashflows")
        grouped: dict[str, list[LoanCashflow]] = {}
        for row in contractual_cashflows:
            grouped.setdefault(row.loan_id, []).append(row)
        if set(grouped) != set(opening_par_by_loan):
            raise InputValidationError("Overlay opening balances and contractual loans differ")
        if loan_day_counts is not None:
            if not isinstance(loan_day_counts, Mapping) or set(loan_day_counts) != set(grouped) or any(not isinstance(value, DayCount) for value in loan_day_counts.values()):
                raise InputValidationError("Overlay loan_day_counts must identify every loan with an explicit DayCount")
        assets = []
        for loan_id, rows in grouped.items():
            rows.sort(key=lambda row: row.period_number)
            opening = opening_par_by_loan[loan_id]
            require_money(opening, "overlay loan opening par", positive=True)
            if rows[0].opening_balance != opening or rows[0].accrual_start != projection_start:
                raise InputValidationError("Overlay contractual opening must match the position snapshot")
            performing = opening
            defaults: list[tuple[date, Decimal]] = []
            raw_events: list[tuple[date, int, AssetCashSource, Decimal, Decimal, Decimal]] = []
            collections: list[OverlayCollection] = []
            shortfall = Fraction()
            previous_end = projection_start
            previous_payment = projection_start
            previous_balance = opening
            # First compile each coupon interval's economic exit amounts. The
            # survivor state feeds the next interval; do not scale a cashflow
            # by a cumulative rate while leaving its contractual par unchanged.
            for index, row in enumerate(rows, 1):
                if row.period_number != index or row.opening_balance != previous_balance or row.accrual_start != previous_end:
                    raise InputValidationError("Overlay contractual chain has missing or inconsistent periods")
                for field in ("opening_balance", "closing_balance", "cash_interest", "pik_interest", "principal_repayment", "total_cash"):
                    require_money(getattr(row, field), f"overlay contractual {field}")
                if row.payment_date <= previous_payment or row.accrual_end <= row.accrual_start:
                    raise InputValidationError("Overlay contractual payment/accrual dates must increase")
                if row.currency != "EUR" or row.cash_interest < 0 or row.principal_repayment < 0:
                    raise InputValidationError("Fractional CLO overlay requires nonnegative EUR contractual cash")
                if Fraction(row.total_cash) != Fraction(row.cash_interest) + Fraction(row.principal_repayment):
                    raise InputValidationError("Overlay contractual cash bridge fails")
                if Fraction(row.opening_balance) + Fraction(row.pik_interest) != Fraction(row.principal_repayment) + Fraction(row.closing_balance):
                    raise InputValidationError("Overlay contractual par bridge fails")
                end = min(row.payment_date, horizon_date)
                if end <= previous_payment:
                    break
                if not self.enabled:
                    requested = ZERO
                elif self.default_timing_pattern is DefaultTimingPattern.FLAT:
                    requested = conditional_period_probability(self.annual_default_rate, previous_payment, end).apply_to_par(performing)
                else:
                    requested = _difference(self.target_through(opening, projection_start, end), self.target_through(opening, projection_start, previous_payment))
                # Before an unpaid future coupon, only defaults take effect.
                is_due = row.payment_date <= horizon_date
                # The frozen rate factor covers only forward earned coupon on
                # a seasoned first interval. Its retained historical claim is
                # explicit and scales with the same surviving slice, so default
                # forfeits that portion without paying or adding it twice.
                exact_coupon = (Fraction(row.opening_balance) * cashflow_coupon_factor(row, loan_day_counts[loan_id])
                                + row.opening_accrued_exact
                                if loan_day_counts is not None else Fraction(require_decimal(row.interest_unrounded, "overlay unrounded coupon", minimum=ZERO)))
                capitalized = ZERO
                if row.pik_fraction:
                    # Only surviving face earns/capitalizes its boundary PIK.
                    # Defaulted slices forfeit unpaid coupon; default exposure
                    # already includes PIK from earlier completed boundaries.
                    # Cash and PIK are separate postings of the scaled exact
                    # earned coupon, with a cash residual preserving gross.
                    default_amount = min(performing, requested)
                    survived = _difference(performing, default_amount)
                    share = Fraction(survived) / Fraction(row.opening_balance)
                    gross = post_currency(exact_coupon * share) if is_due else ZERO
                    capitalized = (post_currency((exact_coupon - row.opening_accrued_exact)
                        * Fraction(row.pik_fraction) * share) if is_due else ZERO)
                    coupon_cash = _difference(gross, capitalized)
                    if is_due and row.closing_balance == 0:
                        scheduled = _sum((survived, capitalized))
                    else:
                        scheduled = min(survived, post_currency(Fraction(row.principal_repayment) * share)) if is_due else ZERO
                    after_scheduled = _difference(_sum((survived, capitalized)), scheduled)
                    prepaid = conditional_period_probability(self.annual_prepayment_rate
                        if self.enabled and is_due else ZERO, previous_payment, end).apply_to_par(after_scheduled)
                    result = FractionalPeriodResult(performing, default_amount, scheduled, prepaid,
                        _difference(after_scheduled, prepaid), coupon_cash, _difference(requested, default_amount))
                else:
                    result = project_fractional_period(
                        opening_par=performing, contractual_opening_par=row.opening_balance,
                        contractual_interest=row.cash_interest if is_due else ZERO,
                        contractual_principal=row.principal_repayment if is_due else ZERO,
                        default_amount=requested,
                        prepayment_rate=self.annual_prepayment_rate if self.enabled and is_due else ZERO,
                        start_date=previous_payment, end_date=end,
                        contractual_interest_unrounded=exact_coupon if is_due else Fraction(),
                    )
                midpoint = previous_payment + timedelta(days=max(1, (end - previous_payment).days // 2))
                if result.default_par:
                    raw_events.append((midpoint, 0, AssetCashSource.DEFAULT, result.default_par, ZERO, ZERO))
                    defaults.append((add_calendar_months(midpoint, self.recovery_lag_months), result.default_par))
                if is_due:
                    collections.append(OverlayCollection(loan_id, "EUR", row.payment_date, AssetCashSource.SCHEDULED, result.cash_interest, result.scheduled_principal, _sum((result.cash_interest, result.scheduled_principal)), row.period_number))
                    if result.scheduled_principal or capitalized:
                        raw_events.append((row.payment_date, 2, AssetCashSource.SCHEDULED, result.scheduled_principal, ZERO, capitalized))
                    if result.prepayment_principal:
                        raw_events.append((row.payment_date, 3, AssetCashSource.PREPAYMENT, result.prepayment_principal, ZERO, ZERO))
                        collections.append(OverlayCollection(loan_id, "EUR", row.payment_date, AssetCashSource.PREPAYMENT, ZERO, result.prepayment_principal, result.prepayment_principal))
                shortfall += Fraction(result.unallocated_default_target)
                performing = result.closing_par
                previous_end, previous_balance = row.accrual_end, row.closing_balance
                previous_payment = row.payment_date
                if not is_due:
                    break
            pending = Fraction()
            # Recovery uses actual default face and its own calendar-month lag.
            # The unpaid fraction is written off on the workout date; a future
            # recovery stays a receivable rather than moving to the horizon.
            for recovery_date, default_par in defaults:
                recovered = post_currency(Fraction(default_par) * Fraction(self.recovery_rate))
                loss = _difference(default_par, recovered)
                if recovery_date > horizon_date:
                    pending += Fraction(recovered)
                    continue
                if recovered:
                    raw_events.append((recovery_date, 1, AssetCashSource.RECOVERY, recovered, ZERO, ZERO))
                    collections.append(OverlayCollection(loan_id, "EUR", recovery_date, AssetCashSource.RECOVERY, ZERO, recovered, recovered))
                if loss:
                    raw_events.append((recovery_date, 1, AssetCashSource.WRITE_OFF, ZERO, loss, ZERO))
            p, d = opening, ZERO
            movements = []
            total_loss = Fraction()
            # Replay in economic date/priority order so a same-day recovery
            # cannot precede its default, even when the configured lag is zero.
            for event_date, priority, source, amount, loss, non_cash in sorted(raw_events, key=lambda item: (item[0], item[1])):
                before_p, before_d = p, d
                if source is AssetCashSource.DEFAULT:
                    p, d = _difference(p, amount), _sum((d, amount))
                    receipt = ZERO
                elif source in {AssetCashSource.SCHEDULED, AssetCashSource.PREPAYMENT}:
                    p, receipt = _difference(_sum((p, non_cash)), amount), amount
                elif source is AssetCashSource.RECOVERY:
                    d, receipt = _difference(d, amount), amount
                else:
                    d, receipt = _difference(d, loss), ZERO
                total_loss += Fraction(loss)
                movements.append(OverlayParMovement(loan_id, event_date, source, before_p, p, before_d, d, receipt, loss, non_cash))
            if p != performing:
                raise ArithmeticError("Overlay economic period and dated par ledger disagree")
            if self.enabled and self.default_timing_pattern is not DefaultTimingPattern.FLAT:
                realized = _sum(par for _, par in defaults)
                shortfall = Fraction(self.target_through(opening, projection_start, horizon_date)) - Fraction(realized)
                if shortfall < 0:
                    raise ArithmeticError("Overlay defaults exceeded their fixed cumulative target")
            assets.append(OverlayAssetProjection(loan_id, opening, tuple(sorted(collections, key=lambda row: (row.payment_date, row.source.value))), tuple(movements), p, d, post_currency(total_loss), post_currency(pending), post_currency(shortfall)))
        assets_tuple = tuple(assets)
        return PoolOverlayProjection(
            assets_tuple,
            tuple(sorted((row for asset in assets for row in asset.collections), key=lambda row: (row.payment_date, row.loan_id, row.source.value))),
            tuple(sorted((row for asset in assets for row in asset.par_movements), key=lambda row: (row.event_date, row.loan_id))),
            _sum(asset.final_performing_par for asset in assets), _sum(asset.final_defaulted_par for asset in assets),
            _sum(asset.total_par_loss for asset in assets), _sum(asset.pending_recovery_amount for asset in assets),
            _sum(asset.unallocated_default_target for asset in assets),
        )
