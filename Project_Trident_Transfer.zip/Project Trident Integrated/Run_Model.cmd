@echo off
setlocal EnableExtensions DisableDelayedExpansion
title Project Trident - Model calculation
rem Keep this file ASCII with single CRLF line endings for Windows Explorer.
rem Anchor both imports and the workbook to this project, even from another cwd.
cd /d "%~dp0"
if errorlevel 1 goto directory_error
set "PYTHONPATH=%CD%\src"
set "PYTHONUNBUFFERED=1"
set "TRIDENT_EXIT=2"
set "TRIDENT_PYTHON_FLAGS="
echo Project Trident - Model calculation
echo Workbook: "%CD%\outputs\Project_Trident.xlsx"
echo Save and close the workbook in Excel before calculation.
echo.

rem Prefer the project's environment; allow an installed launcher or python
rem when this source project is moved to a workstation without a local venv.
if exist ".venv\Scripts\python.exe" (
  set "TRIDENT_PYTHON=.venv\Scripts\python.exe"
  goto interpreter_ready
)
where py.exe >nul 2>&1
if not errorlevel 1 (
  set "TRIDENT_PYTHON=py.exe"
  set "TRIDENT_PYTHON_FLAGS=-3"
  goto interpreter_ready
)
where python.exe >nul 2>&1
if not errorlevel 1 (
  set "TRIDENT_PYTHON=python.exe"
  goto interpreter_ready
)
echo ERROR: Python was not found. Install Python 3.11 or newer.
echo Then follow docs\deployment.md to install this project's packages.
goto finished

:interpreter_ready
echo Python: "%TRIDENT_PYTHON%" %TRIDENT_PYTHON_FLAGS%
echo [1/2] Checking Python and required packages...
"%TRIDENT_PYTHON%" %TRIDENT_PYTHON_FLAGS% -X utf8 -u -c "import sys; sys.exit('Python 3.11 or newer is required.') if sys.version_info < (3, 11) else None; import openpyxl"
if errorlevel 1 goto environment_error
if not exist "outputs\Project_Trident.xlsx" goto workbook_error
echo [2/2] Calculating and saving selected cases. This can take a few minutes...
"%TRIDENT_PYTHON%" %TRIDENT_PYTHON_FLAGS% -X utf8 -u -m trident workbook "outputs\Project_Trident.xlsx"
set "TRIDENT_EXIT=%ERRORLEVEL%"
if not "%TRIDENT_EXIT%"=="0" goto calculation_error
echo.
echo SUCCESS: Calculation completed. Reopen outputs\Project_Trident.xlsx.
echo Review Checks, CLO Analysis and Waterfall for the saved results.
goto finished

:directory_error
echo ERROR: The project folder could not be opened.
set "TRIDENT_EXIT=2"
goto finished

:environment_error
echo ERROR: Python or a required package could not be loaded. See the error above.
echo Install packages with the selected interpreter: pip install -e ".[excel,optimization]"
echo Follow docs\deployment.md if the environment was copied from another computer.
goto finished

:workbook_error
echo ERROR: outputs\Project_Trident.xlsx was not found in this project.
goto finished

:calculation_error
echo.
echo ERROR: Calculation failed. The last complete workbook was retained.
echo Read the error above. Save and close Excel before trying again.

:finished
echo.
echo Press any key to close this window.
pause >nul
exit /b %TRIDENT_EXIT%
