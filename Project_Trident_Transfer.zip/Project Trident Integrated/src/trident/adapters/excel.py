"""Named-range Excel boundary, with atomic complete-workbook writeback.

Physical coordinates are resolved here from names/table metadata. No financial
module imports this adapter or knows a worksheet/cell location.
"""

import os
import math
import re
import tempfile
from copy import copy
from xml.etree import ElementTree
from datetime import date
from decimal import Decimal
from pathlib import Path
from typing import Mapping, TYPE_CHECKING

if TYPE_CHECKING:
    from trident.application.clo_services import TridentModelResult

try:
    from openpyxl import load_workbook
    from openpyxl.utils.cell import absolute_coordinate, get_column_letter, quote_sheetname, range_boundaries
except ImportError as error:
    raise ValueError("Excel support requires openpyxl 3.1; install Project Trident with the [excel] extra") from error

from trident.adapters.records import date_value, decimal_value, text_value
from trident.adapters.excel_schema import (SCALAR_NAMES, TABLE_NAMES, TABLE_RANGE_NAMES,
    TERM_RATE_COLUMNS, CURVE_BLOCKS, INPUT_NAMES, OUTPUT_KEYS, OUTPUT_SCALARS,
    require_current_schema)
from trident.domain.models import InputValidationError
from trident.market.rates import CurveRateProvider, ExtrapolationPolicy, FlatRateProvider, ProjectedRateCurve, RatePoint, RateProvider
from trident.market.monthly import MonthlyProjectedRateCurve


def _overlap(first: tuple[int, int, int, int], second: tuple[int, int, int, int]) -> bool:
    left, top, right, bottom = first
    other_left, other_top, other_right, other_bottom = second
    return not (right < other_left or left > other_right or bottom < other_top or top > other_bottom)


class NamedWorkbook:
    """Strict workbook-scoped names plus named Tables and semantic columns."""

    def __init__(self, workbook: object) -> None:
        self.workbook = workbook

    def _definition(self, name: str) -> object:
        matches = [item for item in self.workbook.defined_names.values() if item.name.casefold() == name.casefold()]
        locals_ = [item for sheet in self.workbook for item in sheet.defined_names.values() if item.name.casefold() == name.casefold()]
        if len(matches) != 1 or locals_:
            raise InputValidationError(f"Missing, conflicting or sheet-local interface name: {name}")
        definition = matches[0]
        if "#REF!" in definition.attr_text.upper() or "[" in definition.attr_text and "[#All]" not in definition.attr_text:
            raise InputValidationError(f"Invalid or external reference: {name}")
        return definition

    def _table(self, table_name: str) -> tuple[object, object]:
        matches = [(sheet, table) for sheet in self.workbook for table in sheet.tables.values()
                   if table.displayName.casefold() == table_name.casefold()]
        if len(matches) != 1:
            raise InputValidationError(f"Missing/duplicate Excel Table: {table_name}")
        sheet, table = matches[0]
        if table.totalsRowShown or table.totalsRowCount:
            raise InputValidationError(f"Totals rows are not input records: {table_name}")
        return sheet, table

    def region(self, name: str) -> tuple[object, tuple[int, int, int, int]]:
        """Resolve one bounded rectangle, or one registered Table[#All]."""
        definition = self._definition(name)
        structured = re.fullmatch(r"([A-Za-z_][A-Za-z_0-9]*)\[#All\]", definition.attr_text)
        if structured:
            sheet, table = self._table(structured[1])
            return sheet, range_boundaries(table.ref)
        try:
            destinations = list(definition.destinations)
        except (AttributeError, TypeError, ValueError) as error:
            raise InputValidationError(f"Name must refer to one explicit rectangle: {name}") from error
        if len(destinations) != 1:
            raise InputValidationError(f"Name must refer to one explicit rectangle: {name}")
        title, coordinates = destinations[0]
        if title not in self.workbook.sheetnames or "[" in title:
            raise InputValidationError(f"Invalid worksheet reference for {name}")
        try:
            bounds = range_boundaries(coordinates)
        except ValueError as error:
            raise InputValidationError(f"Invalid region for {name}") from error
        if any(value is None for value in bounds):
            raise InputValidationError(f"Whole-row/column references are unsupported: {name}")
        left, top, right, bottom = bounds
        if left < 1 or top < 1 or right > 16384 or bottom > 1048576 or right < left or bottom < top:
            raise InputValidationError(f"Invalid Excel bounds for {name}")
        return self.workbook[title], bounds

    @staticmethod
    def _input_value(cell: object, label: str) -> object:
        if cell.data_type in {"f", "e"}:
            raise InputValidationError(f"{label}: paste input values, not a formula/error ({cell.coordinate})")
        return cell.value

    def scalar(self, name: str) -> object:
        sheet, (left, top, right, bottom) = self.region(name)
        if left != right or top != bottom:
            raise InputValidationError(f"Scalar name must refer to exactly one cell: {name}")
        return self._input_value(sheet.cell(top, left), name)

    def write_scalar(self, name: str, value: object) -> None:
        sheet, (left, top, right, bottom) = self.region(name)
        if left != right or top != bottom:
            raise InputValidationError(f"Scalar name must refer to exactly one cell: {name}")
        self._write_value(sheet.cell(top, left), value)

    def validate_output_layout(self, outputs: tuple[str, ...], inputs: tuple[str, ...]) -> None:
        """Reject wrong name mappings that would overwrite inputs or outputs."""
        output_regions = [(name, *self.region(name)) for name in outputs]
        input_regions = [(name, *self.region(name)) for name in inputs]
        for index, (name, sheet, bounds) in enumerate(output_regions):
            for other_name, other_sheet, other_bounds in (*input_regions, *output_regions[:index]):
                if sheet is other_sheet and _overlap(bounds, other_bounds):
                    raise InputValidationError(f"Output named region overlaps protected region: {name} / {other_name}")

    def _registered_table_region(self, name: str, table_name: str) -> tuple[object, tuple[int, int, int, int], object]:
        """Prove named-region identity, Table owner and bounds before read/write.

        Equal rectangles alone are insufficient for a structured reference:
        malformed workbooks could contain overlapping Tables with different
        identities. A Table[#All] name must name the registered Table itself,
        while an explicit rectangle must still match that Table's metadata.
        """
        definition = self._definition(name)
        structured = re.fullmatch(r"([A-Za-z_][A-Za-z_0-9]*)\[#All\]", definition.attr_text)
        if structured and structured[1].casefold() != table_name.casefold():
            raise InputValidationError(f"Named structured reference targets the wrong Table: {name} / {table_name}")
        sheet, bounds = self.region(name)
        owner, table = self._table(table_name)
        if sheet is not owner or bounds != range_boundaries(table.ref):
            raise InputValidationError(f"Named range/Table out of sync: {name} / {table_name}")
        return sheet, bounds, table

    def table_records(self, name: str, table_name: str) -> tuple[dict[str, object], ...]:
        """Read semantic columns from one registered Table, rejecting formulas.

        Physical positions follow current name/Table metadata. Blank padding
        rows do not become assets; partial rows remain inputs for typed field
        validation rather than being silently discarded.
        """
        sheet, bounds, table = self._registered_table_region(name, table_name)
        left, top, right, bottom = bounds
        headers = tuple(self._input_value(sheet.cell(top, col), name) for col in range(left, right + 1))
        if any(not isinstance(header, str) or not header.strip() or header != header.strip() for header in headers):
            raise InputValidationError(f"Missing/invalid headers: {table_name}")
        if len(set(header.casefold() for header in headers)) != len(headers):
            raise InputValidationError(f"Duplicate headers: {table_name}")
        if tuple(column.name for column in table.tableColumns) != headers:
            raise InputValidationError(f"Table column metadata does not match headers: {table_name}")
        return self.region_records(name)

    def region_records(self, name: str) -> tuple[dict[str, object], ...]:
        """Read a header-based named rectangle, including legacy paste regions."""
        sheet, (left, top, right, bottom) = self.region(name)
        headers = tuple(self._input_value(sheet.cell(top, col), name) for col in range(left, right + 1))
        if any(not isinstance(header, str) or not header.strip() or header != header.strip() for header in headers):
            raise InputValidationError(f"Missing/invalid headers: {name}")
        if len(set(header.casefold() for header in headers)) != len(headers):
            raise InputValidationError(f"Duplicate headers: {name}")
        records: list[dict[str, object]] = []
        for row in range(top + 1, bottom + 1):
            values = tuple(self._input_value(sheet.cell(row, col), f"{name} row {row}") for col in range(left, right + 1))
            if all(value is None or value == "" for value in values):
                continue
            records.append(dict(zip(headers, values)))
        return tuple(records)

    @staticmethod
    def _write_value(cell: object, value: object) -> None:
        # Excel is a display/transport boundary; the engines retain Decimal.
        if isinstance(value, Decimal):
            original = value
            try:
                value = float(value)
            except (OverflowError, ValueError) as error:
                raise InputValidationError('Excel numeric output must be finite and representable') from error
            if value == 0 and original != 0:
                raise InputValidationError('Excel numeric output underflow would replace a nonzero value with zero')
        if isinstance(value, (int, float)) and not isinstance(value, bool):
            # Openpyxl serializes nonfinite floats as empty numeric cells.
            # Reject before assigning so neither a blank result nor a partial
            # successful export can conceal an out-of-range calculation.
            try:
                finite = math.isfinite(value)
            except OverflowError:
                finite = False
            if not finite:
                raise InputValidationError('Excel numeric output must be finite and representable')
        cell.value = value
        if isinstance(value, str):
            cell.data_type = "s"  # Never turn a loan identifier into an Excel formula.
        if isinstance(value, date):
            cell.number_format = "yyyy-mm-dd"

    @staticmethod
    def _inherit_body_style(cell: object, template_style: object) -> None:
        """Fill only unset style components in a newly allocated Table row.

        A blank cell may already carry a user's font, fill or number format;
        replacing its complete style would erase that formatting. Openpyxl's
        component ID zero denotes the workbook default. Copying only those
        default components also handles template-wide baseline font styling,
        where ``has_style`` alone would incorrectly suppress wrap/format reuse.
        Independent copies prevent subsequent edits from changing the template.
        """
        if template_style is None:
            return
        if cell._style is None:
            cell._style = copy(template_style)
            return
        inherited = copy(cell._style)
        for component in ("fontId", "fillId", "borderId", "numFmtId",
                          "alignmentId", "protectionId", "xfId"):
            if getattr(inherited, component) == 0:
                setattr(inherited, component, getattr(template_style, component))
        cell._style = inherited

    def write_table(
        self, name: str, table_name: str, records: tuple[Mapping[str, object], ...],
        *, protected_names: tuple[str, ...] = (), number_formats: Mapping[str, str] | None = None,
    ) -> None:
        """Refresh named Table values while preserving its presentation.

        Only newly expanded rows inherit first-body default style components
        and unspecified row heights. Existing/custom formatting survives shrink
        and re-expansion. Explicit ``number_formats`` remains the caller's
        authoritative presentation contract; implicit formats fill General only.
        """
        sheet, (left, top, right, old_bottom), table = self._registered_table_region(name, table_name)
        headers = tuple(sheet.cell(top, col).value for col in range(left, right + 1))
        if len(headers) != len(set(headers)) or any(not isinstance(value, str) for value in headers):
            raise InputValidationError(f"Invalid output headers: {table_name}")
        if any(set(record) != set(headers) for record in records):
            raise InputValidationError(f"Output schema does not match {table_name}")
        if number_formats is not None and (set(number_formats) - set(headers) or
                any(not isinstance(value, str) or not value for value in number_formats.values())):
            raise InputValidationError(f"Number formats must use registered output headers: {table_name}")
        new_bottom = top + max(1, len(records))
        if new_bottom > 1048576:
            raise InputValidationError("Output exceeds Excel row capacity")
        expanded = (left, top, right, new_bottom)
        for protected_name in protected_names:
            protected_sheet, protected_bounds = self.region(protected_name)
            if sheet is protected_sheet and _overlap(expanded, protected_bounds):
                raise InputValidationError(f"Output expansion overlaps protected named region: {protected_name}")
        for merged_range in sheet.merged_cells.ranges:
            if _overlap(expanded, range_boundaries(str(merged_range))):
                raise InputValidationError("Output overlaps merged cells")
        for row in range(old_bottom + 1, new_bottom + 1):
            if any(sheet.cell(row, col).value is not None for col in range(left, right + 1)):
                raise InputValidationError(f"Output expansion would overwrite data in {sheet.title} row {row}")
        for other in sheet.tables.values():
            if other is table:
                continue
            other_left, other_top, other_right, other_bottom = range_boundaries(other.ref)
            if not (right < other_left or left > other_right or new_bottom < other_top or top > other_bottom):
                raise InputValidationError("Output expansion overlaps another Table")
        # Capture the per-column template before writing the first new record:
        # mixed value types may update its display format during publication.
        # Presentation remains at the transport boundary, not in financial code.
        template_styles = tuple(copy(sheet.cell(top + 1, col)._style)
                                for col in range(left, right + 1))
        template_height = sheet.row_dimensions[top + 1].height
        for row in range(top + 1, max(new_bottom, old_bottom) + 1):
            if row > old_bottom and template_height is not None and sheet.row_dimensions[row].height is None:
                sheet.row_dimensions[row].height = template_height
            for col in range(left, right + 1):
                cell = sheet.cell(row, col)
                if row > old_bottom:
                    self._inherit_body_style(cell, template_styles[col - left])
                cell.value = None
        for row_number, record in enumerate(records, top + 1):
            for col, header in enumerate(headers, left):
                cell = sheet.cell(row_number, col)
                previous_number_format = cell.number_format
                self._write_value(cell, record[header])
                if isinstance(record[header], date) and previous_number_format != "General":
                    cell.number_format = previous_number_format
                if isinstance(record[header], Decimal) and previous_number_format == "General":
                    if header in {"index_rate", "all_in_rate", "day_count_fraction", "oc_ratio", "ic_ratio", "oc_minimum", "ic_minimum", "fraction", "coverage"}:
                        cell.number_format = "0.00000000"
                    elif header in {"value", "threshold", "headroom", "baseline_value", "scenario_value", "delta"}:
                        # These columns mix factor/bps/year/fraction metrics;
                        # keep diagnostic precision rather than money formatting.
                        cell.number_format = "0.########"
                    else:
                        cell.number_format = "#,##0.00"
                if number_formats is not None and header in number_formats:
                    cell.number_format = number_formats[header]
        reference = f"{get_column_letter(left)}{top}:{get_column_letter(right)}{new_bottom}"
        table.ref = reference
        if table.autoFilter is not None:
            table.autoFilter.ref = reference
        definition = self._definition(name)
        # A native Table-based input name grows with Excel's own inserted rows.
        # region/table validation above has already proved its exact owner;
        # preserve that contract across explicit adapter writes as well.
        if not re.fullmatch(r"[A-Za-z_][A-Za-z_0-9]*\[#All\]", definition.attr_text):
            definition.attr_text = f"{quote_sheetname(sheet.title)}!{absolute_coordinate(reference)}"

    def ensure_optional_columns(
        self, name: str, table_name: str, columns: Mapping[str, str],
        *, protected_names: tuple[str, ...] = (),
    ) -> tuple[str, ...]:
        """Append registered optional input fields without replacing existing data.

        Name/Table/header metadata must agree before any mutation. New cells
        remain blank, not zero; surrounding values, comments, tables, merges
        and named regions cannot be overwritten. Coordinates are obtained only
        from the resolved interface. This is idempotent and used after successful
        financial calculation, before the caller's atomic workbook save.
        It inspects only headers/layout: disabled candidate inputs stay inactive.
        """
        from openpyxl.worksheet.table import TableColumn

        sheet, (left, top, right, bottom), table = self._registered_table_region(name, table_name)
        headers = tuple(self._input_value(sheet.cell(top, col), name) for col in range(left, right + 1))
        if (any(not isinstance(v, str) or not v or v != v.strip() for v in headers)
                or len(set(v.casefold() for v in headers)) != len(headers)
                or tuple(c.name for c in table.tableColumns) != headers):
            raise InputValidationError(f"Invalid input header metadata: {table_name}")
        if any(not isinstance(k, str) or not k or k != k.strip() or not isinstance(v, str) or not v
               for k, v in columns.items()):
            raise InputValidationError("Optional columns need semantic names and number formats")
        if len({k.casefold() for k in columns}) != len(columns):
            raise InputValidationError("Duplicate optional column names")
        if any(k.casefold() in {h.casefold() for h in headers} and k not in headers for k in columns):
            raise InputValidationError("Optional column casing conflicts with an existing header")
        missing = tuple(k for k in columns if k not in headers)
        if not missing:
            return ()
        new_right = right + len(missing)
        if new_right > 16384:
            raise InputValidationError("Optional columns exceed Excel column capacity")
        extension = (right + 1, top, new_right, bottom)
        for protected in protected_names:
            other_sheet, bounds = self.region(protected)
            if sheet is other_sheet and _overlap(extension, bounds):
                raise InputValidationError(f"Optional columns overlap protected region: {protected}")
        if any(_overlap(extension, range_boundaries(str(merged))) for merged in sheet.merged_cells.ranges):
            raise InputValidationError("Optional columns overlap merged cells")
        if any(other is not table and _overlap(extension, range_boundaries(other.ref)) for other in sheet.tables.values()):
            raise InputValidationError("Optional columns overlap another Table")
        if any(cell.value is not None or cell.comment is not None or cell.hyperlink is not None
               for row in sheet.iter_rows(min_row=top, max_row=bottom, min_col=right + 1, max_col=new_right)
               for cell in row):
            raise InputValidationError("Optional columns would overwrite adjacent content")
        next_id = max(column.id for column in table.tableColumns) + 1
        for offset, field in enumerate(missing, 1):
            col = right + offset
            header = sheet.cell(top, col)
            header.value = field
            header._style = copy(sheet.cell(top, right)._style)
            sheet.column_dimensions[get_column_letter(col)].width = 24
            for row in range(top + 1, bottom + 1):
                cell = sheet.cell(row, col)
                cell._style = copy(sheet.cell(row, right)._style)
                cell.number_format = columns[field]
            table.tableColumns.append(TableColumn(id=next_id + offset - 1, name=field))
        reference = f"{get_column_letter(left)}{top}:{get_column_letter(new_right)}{bottom}"
        table.ref = reference
        if table.autoFilter is not None:
            table.autoFilter.ref = reference
        definition = self._definition(name)
        if not re.fullmatch(r"[A-Za-z_][A-Za-z_0-9]*\[#All\]", definition.attr_text):
            definition.attr_text = f"{quote_sheetname(sheet.title)}!{absolute_coordinate(reference)}"
        return missing

    def ensure_optional_table(self, name: str, table_name: str, columns: tuple[str, ...],
                              *, sheet_title: str, title: str, instruction: str,
                              number_formats: Mapping[str, str] | None = None,
                              before_sheet: str | None = None,
                              list_options: Mapping[str, tuple[str, ...]] | None = None,
                              auto_expand: bool = False) -> bool:
        """Register an absent optional named input without rewriting existing data.

        Both workbook name and native Table must be present together or absent
        together. A partially edited interface fails rather than inventing a
        replacement. Creation uses a dedicated unused sheet, so no existing
        input, output or formatting can be overwritten. This changes only the
        in-memory workbook; read-only preflight discards it, and execution's
        outer atomic save publishes it only after every calculation succeeds.
        auto_expand binds the name to native Table[#All], so additional Excel
        rows become named inputs automatically; existing references are changed
        only after proving name/Table/header consistency for that same input.
        Physical coordinates here are template layout, never financial keys.
        """
        from openpyxl.styles import Alignment, Font, PatternFill
        from openpyxl.workbook.defined_name import DefinedName
        from openpyxl.worksheet.datavalidation import DataValidation
        from openpyxl.worksheet.table import Table, TableColumn, TableStyleInfo

        names = [item for item in self.workbook.defined_names.values()
                 if item.name.casefold() == name.casefold()]
        locals_ = [item for sheet in self.workbook for item in sheet.defined_names.values()
                   if item.name.casefold() == name.casefold()]
        tables = [(sheet, item) for sheet in self.workbook for item in sheet.tables.values()
                  if item.displayName.casefold() == table_name.casefold()
                  or item.name.casefold() == table_name.casefold()]
        if locals_ or len(names) > 1 or len(tables) > 1 or bool(names) != bool(tables):
            raise InputValidationError(f"Missing, conflicting or partial optional interface: {name} / {table_name}")
        if names:
            self.table_records(name, table_name)
            sheet, (left, top, right, _) = self.region(name)
            headers = tuple(sheet.cell(top, col).value for col in range(left, right + 1))
            if set(headers) != set(columns):
                raise InputValidationError(f"Optional Table headers do not match registered schema: {table_name}")
            if auto_expand:
                self._definition(name).attr_text = f"{table_name}[#All]"
            return False
        if any(sheet.title.casefold() == sheet_title.casefold() for sheet in self.workbook):
            raise InputValidationError(f"Optional input sheet exists without its named interface: {sheet_title}")
        if (not columns or any(not isinstance(field, str) or not field or field != field.strip() for field in columns)
                or len({field.casefold() for field in columns}) != len(columns)):
            raise InputValidationError("Optional Table requires unique semantic column names")
        for field, choices in (list_options or {}).items():
            if (field not in columns or not isinstance(choices, tuple) or not choices
                    or any(not isinstance(value, str) or not value or any(char in value for char in ',"') for value in choices)
                    or len(set(choices)) != len(choices) or len(",".join(choices)) > 255):
                raise InputValidationError("Optional Table lists require registered columns and unique literal choices")
        insertion = self.workbook.sheetnames.index(before_sheet) if before_sheet in self.workbook.sheetnames else None
        sheet = self.workbook.create_sheet(sheet_title, index=insertion)
        sheet.sheet_view.showGridLines = False
        sheet.cell(2, 1, title).font = Font(name="Arial", size=14, bold=True)
        sheet.cell(3, 1, instruction)
        sheet.merge_cells(start_row=3, start_column=1, end_row=3, end_column=len(columns))
        sheet.cell(3, 1).font = Font(name="Arial", size=10, italic=True, color="555555")
        sheet.cell(3, 1).alignment = Alignment(wrap_text=True, vertical="center")
        sheet.row_dimensions[3].height = 65
        sheet.row_dimensions[5].height = 36
        for col, field in enumerate(columns, 1):
            header, blank = sheet.cell(5, col, field), sheet.cell(6, col)
            header.font = Font(name="Arial", size=10, color="FFFFFF", bold=True)
            header.fill = PatternFill("solid", fgColor="243B53")
            header.alignment = Alignment(wrap_text=True, vertical="center")
            blank.font = Font(name="Arial", size=10, color="0000FF")
            blank.number_format = (number_formats or {}).get(field, "General")
            sheet.column_dimensions[get_column_letter(col)].width = 30 if field in {"loan_id", "policy"} else 20
        reference = f"A5:{get_column_letter(len(columns))}6"
        table = Table(displayName=table_name, ref=reference,
            tableColumns=[TableColumn(id=col, name=field) for col, field in enumerate(columns, 1)])
        table.tableStyleInfo = TableStyleInfo(name="TableStyleMedium2", showRowStripes=True)
        sheet.add_table(table)
        # Dropdowns aid the first 1,000 entries without allocating cell values
        # or limiting the named Table's supported length. Typed validation
        # remains authoritative, including rows added beyond this convenience
        # region; an Excel list is never a substitute for domain validation.
        for field, choices in (list_options or {}).items():
            validation = DataValidation(type="list", formula1='"' + ",".join(choices) + '"', allow_blank=True)
            validation.showErrorMessage = True
            validation.errorTitle = "Choose a supported value"
            validation.error = "Choose an item from the list; Python validates the full contract after save."
            sheet.add_data_validation(validation)
            col = get_column_letter(columns.index(field) + 1)
            validation.add(f"{col}6:{col}1005")
        name_reference = f"{table_name}[#All]" if auto_expand else f"{quote_sheetname(sheet_title)}!{absolute_coordinate(reference)}"
        self.workbook.defined_names.add(DefinedName(name, attr_text=name_reference))
        sheet.freeze_panes = "C6"
        self.table_records(name, table_name)
        return True


def _save_atomic(workbook: object, destination: Path) -> None:
    """Same-directory replace avoids half-written outputs; failures retain input."""
    # A library's default creator is not the model's author. Keep workbook
    # identity explicit without assigning authorship to a person or tool.
    workbook.properties.creator = None
    workbook.properties.lastModifiedBy = None
    workbook.properties.title = "Project Trident"
    if workbook.loaded_theme is not None:
        # Theme/scheme names are descriptive metadata. Font, colour and format
        # definitions remain intact, including the legacy Market Data styles.
        theme = ElementTree.fromstring(workbook.loaded_theme)
        labels = {"theme", "clrScheme", "fontScheme", "fmtScheme"}
        for element in theme.iter():
            if element.tag.rsplit("}", 1)[-1] in labels and "name" in element.attrib:
                element.set("name", "Project Trident")
        workbook.loaded_theme = ElementTree.tostring(theme, encoding="utf-8", xml_declaration=True)
    destination.parent.mkdir(parents=True, exist_ok=True)
    handle, staging_name = tempfile.mkstemp(prefix=".trident-", suffix=".xlsx", dir=destination.parent)
    os.close(handle)
    staging = Path(staging_name)
    try:
        workbook.save(staging)
        os.replace(staging, destination)
    except PermissionError as error:
        raise PermissionError("Close the workbook in Excel before running Trident; the file could not be replaced") from error
    finally:
        staging.unlink(missing_ok=True)


def _rate_provider(adapter: NamedWorkbook) -> tuple[RateProvider, str]:
    """Convert explicitly selected rate inputs into an immutable provider."""
    mode = text_value(adapter.scalar(SCALAR_NAMES["market_data_mode"]), "market_data_mode")
    if mode == "SYNTHETIC_FLAT":
        assumed = decimal_value(adapter.scalar(SCALAR_NAMES["synthetic_rate"]), "synthetic_rate")
        provenance = f"SYNTHETIC_FLAT; assumed annual rate={assumed}; not observed market data"
        return FlatRateProvider({index: assumed for index in TERM_RATE_COLUMNS}, provenance), provenance
    if mode != "MARKET_CURVES":
        raise InputValidationError(f"Unknown trident_market_data_mode: {mode!r}")
    valuation_date = date_value(adapter.scalar(SCALAR_NAMES["valuation_date"]), "valuation_date")
    method = text_value(adapter.scalar(SCALAR_NAMES["term_rate_method"]), "term_rate_method")
    curve_type = {"MONTH_BUCKET": MonthlyProjectedRateCurve, "LINEAR_DATES": ProjectedRateCurve}.get(method)
    if curve_type is None:
        raise InputValidationError(f"Unknown trident_term_rate_method: {method!r}")
    extrapolation = ExtrapolationPolicy(adapter.scalar(SCALAR_NAMES["curve_extrapolation"]))
    rows = adapter.region_records(CURVE_BLOCKS[0].range_name)
    if not rows:
        raise InputValidationError("Market Data term curves are empty")
    required = {"Curve Date", *TERM_RATE_COLUMNS.values()}
    if not required.issubset(rows[0]):
        raise InputValidationError("Market Data term-curve headers do not match the schema")
    points: dict[str, list[RatePoint]] = {index: [] for index in TERM_RATE_COLUMNS}
    for row_number, row in enumerate(rows, 1):
        fixing_date = date_value(row["Curve Date"], f"term curve row {row_number}: Curve Date")
        for index, column in TERM_RATE_COLUMNS.items():
            points[index].append(RatePoint(fixing_date, decimal_value(row[column], f"term curve row {row_number}: {column}")))
    provenance = f"USER_PROJECTED_TERM_RATES; as_of={valuation_date}; method={method}; extrapolation={extrapolation.value}"
    curves = {index: curve_type(index, tuple(nodes), extrapolation, provenance) for index, nodes in points.items()}
    fixings: dict[tuple[str, date], Decimal] = {}
    for row in adapter.table_records(TABLE_RANGE_NAMES["fixings"], TABLE_NAMES["fixings"]):
        index = text_value(row.get("rate_index"), "fixing rate_index")
        if index not in TERM_RATE_COLUMNS:
            raise InputValidationError(f"Unsupported historical fixing index: {index!r}")
        key = (index, date_value(row.get("fixing_date"), "fixing_date"))
        if key in fixings:
            raise InputValidationError(f"Duplicate historical fixing: {key}")
        fixings[key] = decimal_value(row.get("rate"), "historical fixing rate")
    return CurveRateProvider(curves, valuation_date, fixings), provenance


def run_workbook(path: Path, output: Path | None = None) -> "TridentModelResult":
    """Run a complete named-interface model; validation failure retains files.

    Input formulas are intentionally rejected rather than evaluated using a
    potentially stale Excel cache. Only the newly designed .xlsx interface is
    accepted; the legacy macro model is a read-only reference.
    """
    path = Path(path)
    destination = Path(output) if output is not None else path
    if path.suffix.lower() != ".xlsx" or destination.suffix.lower() != ".xlsx":
        raise InputValidationError("Trident requires its .xlsx template for input and output")
    workbook = load_workbook(path, data_only=False, keep_links=True)
    try:
        if workbook._external_links:
            raise InputValidationError("External workbook links are unsupported; paste approved input values into the Trident template")
        adapter = NamedWorkbook(workbook)
        # A single current interface also supports CASHFLOW_ONLY; the shared
        # model service selects its scope without keeping obsolete file readers.
        require_current_schema(str(adapter.scalar(SCALAR_NAMES["schema_version"])))
        from trident.adapters.excel_model import execute_model_workbook
        result = execute_model_workbook(adapter)
        _save_atomic(workbook, destination)
        return result
    finally:
        workbook.close()
