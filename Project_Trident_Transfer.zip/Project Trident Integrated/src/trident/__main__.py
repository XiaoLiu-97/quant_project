"""Run Project Trident using ``python -m trident``."""

from trident.cli import main

raise SystemExit(main())
