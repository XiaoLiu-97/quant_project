"""Exact accrual fractions and deterministic Decimal reporting values.

Definitions are start-inclusive and end-exclusive. ACT/ACT ISDA allocates days
to their calendar year; it is not ACT/ACT ICMA, AFB, or Excel YEARFRAC basis 1.
ISDA primary reference (2022 CDEv3 response, day-count table):
https://www.isda.org/a/HAxgE/ISDA-Response-to-ROC-CDEv3-Consultation-103122.pdf

Thirty-day definitions deliberately have distinct names: ISDA 2006 Bond Basis,
ISDA 2006 Eurobond, and fixed US February-EOM treatment. The latter is explicit
and does not inspect the schedule's month-roll flag. Reference definitions:
https://strata.opengamma.io/day_counts/
Neither a bare "30/360" label nor Excel NASD is silently assigned a variant.
"""

from calendar import isleap
from datetime import date
from decimal import Context, Decimal, ROUND_HALF_EVEN, localcontext
from enum import Enum
from fractions import Fraction

from ._validation import require_date


class DayCount(str, Enum):
    """Supported day counts; ambiguity is rejected at the input boundary."""

    ACT_360 = "ACT/360"
    ACT_365F = "ACT/365F"
    ACT_ACT_ISDA = "ACT/ACT.ISDA"
    THIRTY_360_ISDA = "30/360.ISDA"
    THIRTY_U_360_EOM = "30U/360.EOM"
    THIRTY_E_360 = "30E/360"


def accrual_fraction(start: date, end: date, convention: DayCount) -> Fraction:
    """Return the exact, nonnegative accrual fraction with no intermediate rounding.

    Cash calculations should retain this rational value through the coupon
    multiplication and round only the final posting. A rounded Decimal 1/3 can
    otherwise move an exact half-cent below its contractual rounding boundary.
    """
    require_date(start, "start")
    require_date(end, "end")
    if not isinstance(convention, DayCount):
        raise TypeError("convention must be a DayCount")
    if end < start:
        raise ValueError("end must be on or after start")
    if start == end:
        return Fraction(0)
    actual_days = (end - start).days
    if convention is DayCount.ACT_360:
        return Fraction(actual_days, 360)
    if convention is DayCount.ACT_365F:
        return Fraction(actual_days, 365)
    if convention in (
        DayCount.THIRTY_360_ISDA,
        DayCount.THIRTY_U_360_EOM,
        DayCount.THIRTY_E_360,
    ):
        return Fraction(_thirty_day_numerator(start, end, convention), 360)
    result = Fraction(0)
    segment_start = start
    while segment_start < end:
        # Avoid constructing an impossible 10000-01-01 at date.max.
        segment_end = (
            min(end, date(segment_start.year + 1, 1, 1))
            if segment_start.year < date.max.year
            else end
        )
        year_days = 366 if isleap(segment_start.year) else 365
        result += Fraction((segment_end - segment_start).days, year_days)
        segment_start = segment_end
    return result


def _thirty_day_numerator(start: date, end: date, convention: DayCount) -> int:
    """Apply the selected variant before computing synthetic 30-day months.

    Bond Basis clips a terminal 31 only when the adjusted start day is 30.
    US-EOM first adjusts a February month end to 30 and also adjusts the end
    when both dates are February month ends. Eurobond only clips each 31.
    In particular, Eurobond does not turn February 28/29 into day 30; that
    would be 30E/360 ISDA, which additionally needs a maturity-date exception.
    """
    day_start, day_end = start.day, end.day
    if convention is DayCount.THIRTY_E_360:
        day_start, day_end = min(day_start, 30), min(day_end, 30)
    else:
        if convention is DayCount.THIRTY_U_360_EOM:
            first_february_end = start.month == 2 and day_start == (29 if isleap(start.year) else 28)
            second_february_end = end.month == 2 and day_end == (29 if isleap(end.year) else 28)
            if first_february_end and second_february_end:
                day_end = 30
            if first_february_end:
                day_start = 30
        day_start = min(day_start, 30)
        if day_end == 31 and day_start == 30:
            day_end = 30
    return 360 * (end.year - start.year) + 30 * (end.month - start.month) + day_end - day_start


def year_fraction(start: date, end: date, convention: DayCount) -> Decimal:
    """Return a precision-34 Decimal representation of the exact day-count fraction.

    Conversion uses an isolated HALF_EVEN context. The exact accrual_fraction is
    authoritative for calculations near posting-rounding boundaries; this value
    supports display and Decimal-facing interfaces without duplicating formulas.
    """
    fraction = accrual_fraction(start, end, convention)
    with localcontext(Context(prec=34, rounding=ROUND_HALF_EVEN)):
        return Decimal(fraction.numerator) / Decimal(fraction.denominator)
