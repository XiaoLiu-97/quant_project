"""Anchored monthly schedules with separate accrual, payment and fixing dates.

Final stubs roll forwards from start; initial stubs roll backwards from maturity
or use an explicit nominal first-payment boundary. Every roll uses its original
anchor, never a clipped February date or a business-adjusted preceding date.
Short/long stubs follow the standard schedule construction illustrated in:
https://strata.opengamma.io/schedules/
The optional last-regular boundary has the same meaning as FpML's
lastRegularPeriodEndDate: end of regular periods, then any final stub.
"""

from calendar import monthrange
from dataclasses import dataclass
from datetime import date
from enum import Enum

from ._validation import require_date, require_integer
from .calendar import BusinessCalendar, BusinessDayConvention


class AccrualDateBasis(str, Enum):
    """Whether interest uses adjusted or contractual unadjusted boundaries."""

    ADJUSTED = "ADJUSTED"
    UNADJUSTED = "UNADJUSTED"


class StubConvention(str, Enum):
    """Select schedule direction and the side/length of any irregular period."""

    NONE = "NONE"
    SHORT_LAST = "SHORT_LAST"
    SHORT_FIRST = "SHORT_FIRST"
    LONG_FIRST = "LONG_FIRST"
    LONG_LAST = "LONG_LAST"


@dataclass(frozen=True)
class AccrualPeriod:
    """One positive accrual interval and its contractually distinct dates."""

    period_number: int
    unadjusted_start: date
    unadjusted_end: date
    accrual_start: date
    accrual_end: date
    payment_date: date
    fixing_date: date

    def __post_init__(self) -> None:
        require_integer(self.period_number, "period_number")
        if self.period_number < 1:
            raise ValueError("period_number must be positive")
        for field_name in (
            "unadjusted_start", "unadjusted_end", "accrual_start", "accrual_end",
            "payment_date", "fixing_date",
        ):
            require_date(getattr(self, field_name), field_name)
        if self.unadjusted_end <= self.unadjusted_start:
            raise ValueError("unadjusted period must have positive length")
        if self.accrual_end <= self.accrual_start:
            raise ValueError("accrual period must have positive length after date adjustment")
        if self.fixing_date > self.accrual_start:
            raise ValueError("fixing_date must be on or before accrual_start")

    @property
    def reset_date(self) -> date:
        """First increment resets at the explicitly selected accrual start."""
        return self.accrual_start


@dataclass(frozen=True)
class ScheduleBuilder:
    """Build anchored schedules using one explicitly supplied calendar."""

    calendar: BusinessCalendar

    def __post_init__(self) -> None:
        if not isinstance(self.calendar, BusinessCalendar):
            raise TypeError("calendar must implement BusinessCalendar")

    def is_first_period_stub(
        self, period: AccrualPeriod, frequency_months: int,
        stub_convention: StubConvention, end_of_month: bool = False,
    ) -> bool:
        """Classify the nominal first interval using its original roll direction.

        A business-day-adjusted 89/91-day quarter need not be a stub. Initial
        schedules roll backwards from their regular anchor, so a clipped
        February start can be regular even when forward-rolling that start
        would produce a different day. Callers must use the same convention
        that built the schedule; this helper does not infer it from day counts.
        """
        if not isinstance(period, AccrualPeriod) or period.period_number != 1:
            raise ValueError("Stub classification requires the first AccrualPeriod")
        require_integer(frequency_months, "frequency_months")
        if frequency_months not in (1, 3, 6, 12):
            raise ValueError("frequency_months must be 1, 3, 6 or 12")
        if not isinstance(stub_convention, StubConvention) or type(end_of_month) is not bool:
            raise ValueError("Stub classification requires typed convention and boolean EOM")
        if stub_convention in (StubConvention.SHORT_FIRST, StubConvention.LONG_FIRST):
            return self._roll(period.unadjusted_end, -frequency_months, end_of_month) != period.unadjusted_start
        return self._roll(period.unadjusted_start, frequency_months, end_of_month) != period.unadjusted_end

    def build(
        self,
        start_date: date,
        maturity_date: date,
        frequency_months: int,
        business_day_convention: BusinessDayConvention = BusinessDayConvention.MODIFIED_FOLLOWING,
        accrual_date_basis: AccrualDateBasis = AccrualDateBasis.ADJUSTED,
        fixing_lag_business_days: int = 2,
        payment_lag_business_days: int = 0,
        end_of_month: bool = False,
        stub_convention: StubConvention = StubConvention.SHORT_LAST,
        *,
        first_payment_date: date | None = None,
        last_regular_payment_date: date | None = None,
    ) -> tuple[AccrualPeriod, ...]:
        """Build 1/3/6/12-month periods; all assumptions are explicit arguments.

        Payment rolls the unadjusted end, then adds the nonnegative payment lag.
        Fixing precedes reset (the accrual start) by the nonnegative fixing lag.
        A zero lag retains its date. Optional date fields are UNADJUSTED
        boundaries, never the cash dates after business-day adjustment/lag.
        ``first_payment_date`` locks the initial stub end/regular roll anchor
        for initial-stub conventions; for other conventions it confirms the
        generated first boundary. ``last_regular_payment_date`` confirms the
        end of the last regular period (maturity when there is no final stub).

        Initial stubs otherwise roll backwards from maturity; final stubs roll
        forwards from start. Long stubs merge the irregular residual with one
        adjacent regular period. A long convention does not force a stub when
        dates already align, but a shorter-than-one-frequency whole schedule
        cannot form a long stub and is rejected. Explicit dates must agree
        with the chosen side/length and regular roll grid; dual stubs are not
        supported. EOM validates the regular anchor, not an irregular start.
        """
        require_date(start_date, "start_date")
        require_date(maturity_date, "maturity_date")
        require_integer(frequency_months, "frequency_months")
        require_integer(fixing_lag_business_days, "fixing_lag_business_days")
        require_integer(payment_lag_business_days, "payment_lag_business_days")
        if maturity_date <= start_date:
            raise ValueError("maturity_date must be after start_date")
        if frequency_months not in (1, 3, 6, 12):
            raise ValueError("frequency_months must be 1, 3, 6 or 12")
        if fixing_lag_business_days < 0 or payment_lag_business_days < 0:
            raise ValueError("fixing and payment lags must be nonnegative")
        if not isinstance(business_day_convention, BusinessDayConvention):
            raise TypeError("business_day_convention must be a BusinessDayConvention")
        if not isinstance(accrual_date_basis, AccrualDateBasis):
            raise TypeError("accrual_date_basis must be an AccrualDateBasis")
        if not isinstance(stub_convention, StubConvention):
            raise TypeError("stub_convention must be a StubConvention")
        if type(end_of_month) is not bool:
            raise TypeError("end_of_month must be a boolean")
        for value, field_name in (
            (first_payment_date, "first_payment_date"),
            (last_regular_payment_date, "last_regular_payment_date"),
        ):
            if value is not None:
                require_date(value, field_name)
                if not start_date < value <= maturity_date:
                    raise ValueError(f"{field_name} must be after start_date and on or before maturity_date")
        # Validate against the calendar's supported range before constructing rolls.
        self.calendar.is_business_day(start_date)
        self.calendar.is_business_day(maturity_date)
        for value in (first_payment_date, last_regular_payment_date):
            if value is not None:
                self.calendar.is_business_day(value)
        boundaries = self._boundaries(
            start_date, maturity_date, frequency_months, end_of_month, stub_convention,
            first_payment_date, last_regular_payment_date,
        )
        adjusted = tuple(self.calendar.adjust(value, business_day_convention) for value in boundaries)
        periods: list[AccrualPeriod] = []
        for index in range(len(boundaries) - 1):
            accrual_start, accrual_end = (
                (adjusted[index], adjusted[index + 1])
                if accrual_date_basis is AccrualDateBasis.ADJUSTED
                else (boundaries[index], boundaries[index + 1])
            )
            periods.append(
                AccrualPeriod(
                    period_number=index + 1,
                    unadjusted_start=boundaries[index],
                    unadjusted_end=boundaries[index + 1],
                    accrual_start=accrual_start,
                    accrual_end=accrual_end,
                    payment_date=self.calendar.add_business_days(
                        adjusted[index + 1], payment_lag_business_days,
                    ),
                    fixing_date=self.calendar.add_business_days(
                        accrual_start, -fixing_lag_business_days,
                    ),
                )
            )
        return tuple(periods)

    @staticmethod
    def _boundaries(
        start: date,
        maturity: date,
        frequency_months: int,
        end_of_month: bool,
        stub_convention: StubConvention,
        first_payment_date: date | None = None,
        last_regular_payment_date: date | None = None,
    ) -> tuple[date, ...]:
        """Generate nominal boundaries and validate all explicitly supplied dates."""
        is_initial = stub_convention in (StubConvention.SHORT_FIRST, StubConvention.LONG_FIRST)
        if is_initial:
            anchor = first_payment_date if first_payment_date is not None else maturity
        else:
            anchor = start
        if end_of_month and anchor.day != monthrange(anchor.year, anchor.month)[1]:
            raise ValueError("end_of_month requires a calendar-month-end regular schedule anchor")

        if is_initial and first_payment_date is not None:
            boundaries, has_stub = ScheduleBuilder._explicit_initial_boundaries(
                start, maturity, frequency_months, end_of_month, stub_convention,
                first_payment_date,
            )
        elif is_initial:
            backwards, has_stub = ScheduleBuilder._backward_boundaries(
                start, maturity, frequency_months, end_of_month,
            )
            boundaries = list(backwards)
            if has_stub and stub_convention is StubConvention.LONG_FIRST:
                if len(boundaries) < 3:
                    raise ValueError("LONG_FIRST requires a regular period to merge with the initial stub")
                del boundaries[1]
        else:
            forwards, has_stub = ScheduleBuilder._forward_boundaries(
                start, maturity, frequency_months, end_of_month,
            )
            boundaries = list(forwards)
            if has_stub and stub_convention is StubConvention.NONE:
                raise ValueError("maturity_date is not aligned with the schedule anchor")
            if has_stub and stub_convention is StubConvention.LONG_LAST:
                if len(boundaries) < 3:
                    raise ValueError("LONG_LAST requires a regular period to merge with the final stub")
                del boundaries[-2]

        if first_payment_date is not None and first_payment_date != boundaries[1]:
            raise ValueError("first_payment_date contradicts the generated first unadjusted payment boundary")
        if last_regular_payment_date is not None:
            if is_initial and has_stub and len(boundaries) == 2:
                raise ValueError("last_regular_payment_date is undefined for a schedule containing only an initial stub")
            expected_last_regular = boundaries[-2] if has_stub and not is_initial else maturity
            if last_regular_payment_date != expected_last_regular:
                raise ValueError("last_regular_payment_date contradicts the regular grid or requests an unsupported second stub")
        return tuple(boundaries)

    @staticmethod
    def _roll(anchor: date, month_offset: int, end_of_month: bool) -> date | None:
        """Roll an original anchor; None means the offset exceeds Python's dates."""
        month_index = (anchor.year - 1) * 12 + anchor.month - 1 + month_offset
        if not 0 <= month_index < date.max.year * 12:
            return None
        year_minus_one, month_minus_one = divmod(month_index, 12)
        year, month = year_minus_one + 1, month_minus_one + 1
        final_day = monthrange(year, month)[1]
        return date(year, month, final_day if end_of_month else min(anchor.day, final_day))

    @staticmethod
    def _forward_boundaries(
        anchor: date, end: date, frequency: int, end_of_month: bool,
    ) -> tuple[tuple[date, ...], bool]:
        """Forward roll grid plus endpoint; report whether its final period is a stub."""
        boundaries = [anchor]
        month_offset = frequency
        while True:
            rolled = ScheduleBuilder._roll(anchor, month_offset, end_of_month)
            if rolled is None or rolled > end:
                boundaries.append(end)
                return tuple(boundaries), True
            boundaries.append(rolled)
            if rolled == end:
                return tuple(boundaries), False
            month_offset += frequency

    @staticmethod
    def _backward_boundaries(
        start: date, anchor: date, frequency: int, end_of_month: bool,
    ) -> tuple[tuple[date, ...], bool]:
        """Backward roll grid plus start; report whether its initial period is a stub."""
        backwards = [anchor]
        month_offset = -frequency
        while True:
            rolled = ScheduleBuilder._roll(anchor, month_offset, end_of_month)
            if rolled is None or rolled < start:
                backwards.append(start)
                return tuple(reversed(backwards)), True
            backwards.append(rolled)
            if rolled == start:
                return tuple(reversed(backwards)), False
            month_offset -= frequency

    @staticmethod
    def _explicit_initial_boundaries(
        start: date, maturity: date, frequency: int, end_of_month: bool,
        convention: StubConvention, first: date,
    ) -> tuple[list[date], bool]:
        """Lock an initial boundary, checking short/long length against its roll grid."""
        previous = ScheduleBuilder._roll(first, -frequency, end_of_month)
        is_regular = start == previous
        if not is_regular:
            if convention is StubConvention.SHORT_FIRST:
                if previous is not None and start < previous:
                    raise ValueError("first_payment_date creates a long period under SHORT_FIRST")
            else:
                second_previous = ScheduleBuilder._roll(first, -2 * frequency, end_of_month)
                if previous is None or start >= previous or (second_previous is not None and start <= second_previous):
                    raise ValueError("first_payment_date must create a stub longer than one and shorter than two regular periods under LONG_FIRST")
        if first == maturity:
            return [start, maturity], not is_regular
        regular, final_stub = ScheduleBuilder._forward_boundaries(first, maturity, frequency, end_of_month)
        if final_stub:
            raise ValueError("maturity_date must align with first_payment_date; dual-ended stubs are unsupported")
        return [start, *regular], not is_regular
