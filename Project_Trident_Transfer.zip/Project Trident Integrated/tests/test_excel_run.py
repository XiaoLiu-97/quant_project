"""Named-interface workbook runs, independently checked through saved Excel data.

These workbooks are isolated test fixtures, copied from the uncomputed current input
template. Physical placement is confined to fixture authors; assertions
and input mutations use the semantic names and table headers.
"""

import csv
from datetime import date, datetime
from decimal import Decimal
from pathlib import Path
from tempfile import TemporaryDirectory
import unittest

from openpyxl import load_workbook
from openpyxl.utils.cell import absolute_coordinate, quote_sheetname

from trident.adapters.excel import NamedWorkbook, TERM_RATE_COLUMNS, run_workbook as _run_workbook
from trident.adapters import excel_schema as schema
from workbook_fixtures import INPUT_TEMPLATE, put_records, write_controls
from trident.domain.models import InputValidationError
from trident.market.rates import RequiredFixingError


ROOT = Path(__file__).resolve().parents[1]
EXAMPLE = ROOT / "data/examples/hybrid_500m"
D = Decimal


def _csv_fixture(name: str) -> tuple[tuple[str, ...], tuple[dict[str, object], ...]]:
    with (EXAMPLE / name).open(encoding="utf-8-sig", newline="") as stream:
        reader = csv.DictReader(stream)
        return tuple(reader.fieldnames or ()), tuple(dict(row) for row in reader)






def _one_period_asset() -> dict[str, object]:
    """A small scenario with independently hand-checkable 94-day interest."""
    _, source = _csv_fixture("assets.csv")
    row = dict(source[0])
    row.update(
        loan_id="TEST_94_DAY_BULLET", initial_par="10000", current_par="10000",
        maturity_date_unadjusted="2027-02-20", amortization_type="BULLET",
        amortization_fraction_initial_par_per_period="0",
        amortization_periods_remaining="", amortization_first_date_unadjusted="",
        purchase_price_pct="100",
    )
    return row


def _curves() -> tuple[dict[str, object], ...]:
    """Nov 1 = 2%; Dec 1 = 5% for each supported term-rate column."""
    return tuple(
        {"Curve Date": fixing_date, **{column: rate for column in TERM_RATE_COLUMNS.values()}}
        for fixing_date, rate in ((date(2026, 11, 1), 0.02), (date(2026, 12, 1), 0.05))
    )


def _make_workbook(
    path: Path,
    *,
    assets: tuple[dict[str, object], ...] | None = None,
    capital: tuple[dict[str, object], ...] | None = None,
    scalars: dict[str, object] | None = None,
    curves: tuple[dict[str, object], ...] = (),
    fixings: tuple[dict[str, object], ...] = (),
) -> None:
    _, source_assets = _csv_fixture("assets.csv")
    _, source_capital = _csv_fixture("capital_stack.csv")
    asset_rows = source_assets if assets is None else assets
    capital_rows = source_capital if capital is None else capital
    supplied = dict(scalars or {})
    valuation = supplied.get("trident_valuation_date", date(2026, 10, 2))
    values = {
        "schema_version": schema.SCHEMA_VERSION, "mode": "CASHFLOW_ONLY",
        "market_data_mode": "SYNTHETIC_FLAT", "synthetic_rate": .025,
        "valuation_date": valuation, "legacy_pricing_date": valuation,
        "legacy_clo_size": sum(D(str(row["nominal_amount"])) for row in capital_rows) or 1,
        "legacy_opening_collateral_par": sum(D(str(row["current_par"])) for row in asset_rows),
        "legacy_other_upfront_costs": supplied.pop("trident_upfront_fees", 2500000),
        "legacy_initial_reserve_funding": supplied.pop("trident_cash_reserve", 2500000),
        # A single supplied asset retains its contract purchase price.
        "legacy_collateral_purchase_price": D(str(asset_rows[0]["purchase_price_pct"])) / 100
            if len(asset_rows) == 1 else D(".9955"),
        "scenario_enabled": False, "optimizer_enabled": False, "candidate_search_enabled": False,
    }
    values.update({key: value for name, value in supplied.items()
                   for key, registered in schema.SCALAR_NAMES.items() if registered == name})
    workbook = load_workbook(INPUT_TEMPLATE)
    adapter = NamedWorkbook(workbook)
    write_controls(adapter, values)
    put_records(adapter, "assets", asset_rows)
    put_records(adapter, "capital_stack", capital_rows)
    put_records(adapter, "fixings", fixings)
    sheet, (left, top, right, bottom) = adapter.region("trident_md_term_curves")
    for row in sheet.iter_rows(min_row=top + 1, max_row=bottom, min_col=left, max_col=right):
        for cell in row:
            cell.value = None
    headers = tuple(sheet.cell(top, column).value for column in range(left, right + 1))
    for index, record in enumerate(curves, top + 1):
        for column, header in enumerate(headers, left):
            sheet.cell(index, column, record.get(header))
    workbook.save(path)
    workbook.close()


def run_workbook(path: Path, destination: Path | None = None):
    """Exercise the unified current runner, returning its standalone result."""
    return _run_workbook(path, destination).cashflows


def _make_minimal_workbook(path: Path, **options: object) -> None:
    scalars = {"trident_upfront_fees": 0, "trident_cash_reserve": 0}
    scalars.update(options.pop("scalars", {}))
    _make_workbook(path, assets=(_one_period_asset(),), capital=(), scalars=scalars, **options)


def _as_date(value: object) -> date:
    return value.date() if isinstance(value, datetime) else value


class WorkbookRunTests(unittest.TestCase):
    def setUp(self) -> None:
        self.directory = TemporaryDirectory()
        self.addCleanup(self.directory.cleanup)
        self.path = Path(self.directory.name) / "named_model.xlsx"

    def test_150_asset_run_writes_known_financial_answers(self) -> None:
        _make_workbook(self.path)
        result = run_workbook(self.path)
        self.assertEqual(result.asset_count, 150)
        self.assertEqual(result.projection_start_date, date(2026, 11, 20))
        self.assertEqual(result.total_principal, D("500000000"))
        self.assertEqual(result.first_payment_date, date(2027, 2, 22))
        self.assertEqual(result.first_payment_interest, D("7670139.00"))
        self.assertEqual(result.funding.equity_cash_funding, D("53475000"))
        workbook = load_workbook(self.path)
        try:
            adapter = NamedWorkbook(workbook)
            self.assertEqual(adapter.scalar("trident_output_status"), "COMPLETED_CASHFLOW_ONLY")
            self.assertEqual(adapter.scalar("trident_run_id"), result.run_id)
            self.assertEqual(adapter.scalar("trident_result_asset_count"), 150)
            self.assertEqual(adapter.scalar("trident_result_collateral_par"), 500000000)
            self.assertEqual(adapter.scalar("trident_result_total_principal"), 500000000)
            self.assertEqual(adapter.scalar("trident_result_debt_proceeds"), 449275000)
            self.assertEqual(adapter.scalar("trident_result_equity_funding"), 53475000)
            self.assertEqual(_as_date(adapter.scalar("trident_result_first_payment_date")), date(2027, 2, 22))
            self.assertEqual(_as_date(adapter.scalar("trident_result_projection_start_date")), date(2026, 11, 20))
            self.assertEqual(D(str(adapter.scalar("trident_result_first_payment_interest"))), D("7670139.00"))
            self.assertIn("SYNTHETIC_FLAT", adapter.scalar("trident_result_rate_provenance"))
            records = adapter.table_records("trident_asset_cashflows", "tbl_trident_asset_cashflows")
            self.assertEqual(len(records), 4316)
            # Per-loan hand calculation: 7m * 5.5% * 94/360, rounded once to cents.
            first = records[0]
            self.assertEqual(first["loan_id"], "SYN_INFRA_LOAN_001")
            self.assertEqual(D(str(first["cash_interest"])), D("100527.78"))
            self.assertEqual(first["principal_repayment"], 175000)
            self.assertEqual(first["closing_balance"], 6825000)
        finally:
            workbook.close()

    def test_repeated_run_clears_previous_longer_cashflows(self) -> None:
        _make_workbook(self.path)
        first = run_workbook(self.path)
        workbook = load_workbook(self.path)
        try:
            adapter = NamedWorkbook(workbook)
            old_sheet, (_, _, _, old_bottom) = adapter.region("trident_asset_cashflows")
            output_sheet_name = old_sheet.title
            put_records(adapter, "assets", (_one_period_asset(),))
            adapter.write_table("trident_capital_stack", "tbl_trident_capital_stack", ())
            adapter.write_scalar(schema.SCALAR_NAMES["legacy_other_upfront_costs"], 0)
            adapter.write_scalar(schema.SCALAR_NAMES["legacy_initial_reserve_funding"], 0)
            adapter.write_scalar(schema.SCALAR_NAMES["legacy_opening_collateral_par"], 10000)
            adapter.write_scalar(schema.SCALAR_NAMES["legacy_clo_size"], 1)
            adapter.write_scalar(schema.SCALAR_NAMES["legacy_collateral_purchase_price"], 1)
            workbook.save(self.path)
        finally:
            workbook.close()
        second = run_workbook(self.path)
        self.assertNotEqual(first.run_id, second.run_id)
        self.assertEqual(second.total_principal, D("10000"))
        self.assertEqual(second.first_payment_interest, D("143.61"))
        workbook = load_workbook(self.path)
        try:
            adapter = NamedWorkbook(workbook)
            records = adapter.table_records("trident_asset_cashflows", "tbl_trident_asset_cashflows")
            self.assertEqual(len(records), 1)
            self.assertEqual(records[0]["loan_id"], "TEST_94_DAY_BULLET")
            sheet, (left, _, right, new_bottom) = adapter.region("trident_asset_cashflows")
            self.assertEqual(sheet.title, output_sheet_name)
            self.assertLess(new_bottom, old_bottom)
            for row in sheet.iter_rows(min_row=new_bottom + 1, max_row=old_bottom, min_col=left, max_col=right):
                self.assertTrue(all(cell.value is None for cell in row))
            self.assertEqual(adapter.scalar("trident_result_asset_count"), 1)
            self.assertEqual(adapter.scalar("trident_result_equity_funding"), 10000)
        finally:
            workbook.close()

    def test_validation_failure_preserves_input_and_existing_destination_bytes(self) -> None:
        asset = _one_period_asset()
        asset["current_par"] = "-1"
        _make_workbook(self.path, assets=(asset,), capital=())
        destination = self.path.with_name("existing_output.xlsx")
        destination.write_bytes(b"existing-output-must-survive-validation")
        original, existing = self.path.read_bytes(), destination.read_bytes()
        with self.assertRaises(InputValidationError):
            run_workbook(self.path, destination)
        self.assertEqual(self.path.read_bytes(), original)
        self.assertEqual(destination.read_bytes(), existing)

    def test_missing_output_name_preserves_original_bytes(self) -> None:
        _make_minimal_workbook(self.path)
        workbook = load_workbook(self.path)
        try:
            del workbook.defined_names["trident_result_total_principal"]
            workbook.save(self.path)
        finally:
            workbook.close()
        original = self.path.read_bytes()
        with self.assertRaisesRegex(InputValidationError, "interface name"):
            run_workbook(self.path)
        self.assertEqual(self.path.read_bytes(), original)

    def test_output_scalar_cannot_overlap_input_scalar(self) -> None:
        _make_minimal_workbook(self.path)
        workbook = load_workbook(self.path)
        try:
            # A moved output must never turn the scenario-rate input into a result.
            workbook.defined_names["trident_result_total_interest"].attr_text = (
                workbook.defined_names["trident_synthetic_rate"].attr_text
            )
            workbook.save(self.path)
        finally:
            workbook.close()
        original = self.path.read_bytes()
        with self.assertRaisesRegex(InputValidationError, "overlaps protected region"):
            run_workbook(self.path)
        self.assertEqual(self.path.read_bytes(), original)

    def test_output_scalar_cannot_overlap_cashflow_table(self) -> None:
        _make_minimal_workbook(self.path)
        workbook = load_workbook(self.path)
        try:
            # Resolve the target from its semantic name rather than fixture layout.
            sheet, (left, top, _, _) = NamedWorkbook(workbook).region("trident_asset_cashflows")
            cell_reference = absolute_coordinate(sheet.cell(top + 1, left).coordinate)
            workbook.defined_names["trident_result_total_interest"].attr_text = (
                f"{quote_sheetname(sheet.title)}!{cell_reference}"
            )
            workbook.save(self.path)
        finally:
            workbook.close()
        original = self.path.read_bytes()
        with self.assertRaisesRegex(InputValidationError, "overlaps protected region"):
            run_workbook(self.path)
        self.assertEqual(self.path.read_bytes(), original)

    def test_common_projection_date_required_before_writeback(self) -> None:
        first = _one_period_asset()
        second = dict(first)
        second.update(loan_id="DIFFERENT_OPENING_DATE", par_as_of_date="2026-12-20",
                      cashflow_projection_start_date="2026-12-20")
        _make_workbook(self.path, assets=(first, second), capital=())
        original = self.path.read_bytes()
        with self.assertRaisesRegex(InputValidationError, "share one projection|Closing Date.*opening par snapshot"):
            run_workbook(self.path)
        self.assertEqual(self.path.read_bytes(), original)

    def test_month_bucket_and_linear_dates_have_distinct_known_answers(self) -> None:
        expectations = {
            "MONTH_BUCKET": (D("0.02"), D("130.56")),
            # Nov 18 is 17/30 of Nov 1--Dec 1: 2% + 3% * 17/30 = 3.7%.
            "LINEAR_DATES": (D("0.037"), D("174.94")),
        }
        for method, (rate, interest) in expectations.items():
            with self.subTest(method=method):
                path = self.path.with_name(f"{method}.xlsx")
                _make_minimal_workbook(path, curves=_curves(), scalars={
                    "trident_market_data_mode": "MARKET_CURVES", "trident_term_rate_method": method,
                })
                result = run_workbook(path)
                self.assertEqual(result.cashflows[0].fixing_date, date(2026, 11, 18))
                self.assertEqual(result.cashflows[0].index_rate, rate)
                self.assertEqual(result.first_payment_interest, interest)
                self.assertIn(f"method={method}", result.rate_provenance)
                workbook = load_workbook(path)
                try:
                    row = NamedWorkbook(workbook).table_records("trident_asset_cashflows", "tbl_trident_asset_cashflows")[0]
                    self.assertEqual(D(str(row["cash_interest"])), interest)
                finally:
                    workbook.close()

    def test_missing_exact_historical_fixing_fails_without_modifying_file(self) -> None:
        # Nov 17 is not a substitute for the actual Nov 18 fixing.
        _make_minimal_workbook(self.path, curves=_curves(), fixings=(
            {"rate_index": "EURIBOR_3M", "fixing_date": date(2026, 11, 17), "rate": 0.025},
        ), scalars={"trident_market_data_mode": "MARKET_CURVES", "trident_valuation_date": date(2026, 11, 18)})
        original = self.path.read_bytes()
        with self.assertRaisesRegex(RequiredFixingError, "2026-11-18"):
            run_workbook(self.path)
        self.assertEqual(self.path.read_bytes(), original)

    def test_exact_historical_fixing_overrides_projected_month_rate(self) -> None:
        _make_minimal_workbook(self.path, curves=_curves(), fixings=(
            {"rate_index": "EURIBOR_3M", "fixing_date": date(2026, 11, 18), "rate": 0.06},
        ), scalars={"trident_market_data_mode": "MARKET_CURVES", "trident_valuation_date": date(2026, 11, 18)})
        result = run_workbook(self.path)
        self.assertEqual(result.cashflows[0].index_rate, D("0.06"))
        # 10,000 * (6% + 3%) * 94/360 = 235 exactly.
        self.assertEqual(result.first_payment_interest, D("235.00"))

    def test_legacy_macro_workbook_never_overwritten(self) -> None:
        legacy = self.path.with_name("CLO_Model_v4_2_2_EUR_CLO_Fully_Reviewed.xlsm")
        legacy.write_bytes(b"read-only-legacy-macro-reference")
        original = legacy.read_bytes()
        with self.assertRaisesRegex(InputValidationError, "xlsx template"):
            run_workbook(legacy)
        self.assertEqual(legacy.read_bytes(), original)
        _make_minimal_workbook(self.path)
        input_bytes = self.path.read_bytes()
        with self.assertRaisesRegex(InputValidationError, "xlsx template"):
            run_workbook(self.path, legacy)
        self.assertEqual(legacy.read_bytes(), original)
        self.assertEqual(self.path.read_bytes(), input_bytes)


if __name__ == "__main__":
    unittest.main()
