"""Execute every legacy assumption through explicit, typed Python policies.

The unified workbook's deal controls explicitly define the selected policies.
Asset contracts remain independent; note timing/reference/floors use the deal
controls. No coordinate is used here to locate an input or compute a result.
"""

from dataclasses import replace
from decimal import Decimal
from fractions import Fraction
from typing import Mapping

from trident.analysis import LimitDirection, LimitSpec
from trident.application.portfolio_phases import ACTIVE_PORTFOLIO_PHASES
from trident.application.clo_services import TridentModelRequest
from trident.clo.models import (CloTerms, NoteTranche, RecurringSeniorExpense,
    PrincipalRepaymentMode, ManagementFeeBasis, CashAccountAccrualMode,
    DefaultedAssetOcTreatment, InterestDiversionMode, PrincipalCouponPolicy)
from trident.clo.lifecycle import AdjustedCollateralValuePolicy, OcAssetData, ShortfallAccrualMethod
from trident.clo.reinvestment import SyntheticReinvestmentPolicy, ReinvestmentTestGate
from trident.conventions import AccrualDateBasis, BusinessDayConvention, DayCount, StubConvention
from trident.conventions.calendar import CalendarName
from trident.conventions.liability_rates import FirstStubRateMethod, FixingDateAnchor
from trident.credit.overlay import OriginalPoolOverlay, DefaultTimingPattern
from trident.domain.models import CouponType, InputValidationError
from trident.domain.numeric import post_currency, decimal_fraction, basis_points_rate
from trident.funding import ClosingCostBudget, ClosingCostItem, ClosingSourceType, FundingEngine
from trident.market import RateProvider
from .legacy_inputs import LEGACY_INPUTS
from .model_records import (exposures_from_records, factor_mapping_from_records, limits_from_records,
    optional_decimal, optional_text)
from .records import (boolean_value, date_value, decimal_value, integer_value,
    run_request_from_records, text_value)


RECURRING_COMPONENTS = (
    "trustee_paying_agent_administrator", "collateral_administration_account_bank",
    "rating_agency_surveillance", "legal_advisory", "audit_accounting_tax",
    "listing_regulatory_reporting", "other_recurring_senior_expenses")
CLOSING_COMPONENTS = (
    "rating_agency_initial_fees", "legal_documentation", "trustee_administrator_issuer_setup",
    "listing_clearing", "accounting_audit_tax_setup", "warehouse_financing_unwind",
    "hedge_fx_setup", "other_upfront_costs")
_FRACTIONS = {"original_annual_default_rate", "original_recovery_rate", "original_collateral_cpr",
    "ccc_fraction", "ccc_limit_fraction", "ccc_valuation_fraction", "maturity_liquidation_fraction",
    "reinvestment_annual_prepayment_rate", "reinvestment_annual_default_rate", "reinvestment_recovery_rate",
    "discount_obligation_fraction", "discount_obligation_valuation_fraction", "defaulted_asset_valuation_fraction",
    "long_dated_asset_limit_fraction", "long_dated_oc_valuation_fraction", "discount_obligation_price_threshold",
    "minimum_collateral_warr", "maximum_single_obligor", "maximum_industry", "incentive_fee_rate",
    "call_costs_of_debt_fraction", "refi_fee_of_debt_fraction", "equity_irr_hurdle"}
_SIGNED = {"cash_account_spread", "first_stub_rate_override", "liability_reference_floor",
    "reinvestment_asset_reference_floor", "cash_account_rate_floor"}


def legacy_values(controls: Mapping[str, object]) -> dict[str, object]:
    """Require and validate all 107 editable values, including inactive inputs.

    Retained fields never fall back to an old cell or an undocumented default.
    Inactive policy values are still validated so enabling a switch is safe.
    """
    values = {}
    for field in LEGACY_INPUTS:
        key = f"legacy_{field.field_id}"
        if key not in controls:
            raise InputValidationError(f"Missing legacy input {field.field_id} ({field.label})")
        raw = controls[key]
        if field.semantic_type == "DATE":
            value = date_value(raw, field.field_id)
        elif field.semantic_type == "INTEGER":
            value = integer_value(raw, field.field_id)
            if value < 0:
                raise InputValidationError(f"{field.field_id} must be nonnegative")
        elif field.semantic_type in {"DECIMAL", "MONEY"}:
            value = decimal_value(raw, field.field_id)
            if field.field_id not in _SIGNED and value < 0:
                raise InputValidationError(f"{field.field_id} must be nonnegative")
            if field.field_id in _FRACTIONS and value > 1:
                raise InputValidationError(f"{field.field_id} must lie in [0,1]")
            if field.semantic_type == "MONEY" and Fraction(value) * 100 % 1:
                raise InputValidationError(f"{field.field_id} must be an exact EUR cent amount")
        else:
            value = text_value(raw, field.field_id)
            choices = ("EUR", "USD", "GBP") if field.field_id == "base_currency" else field.choices
            if choices and value not in choices:
                raise InputValidationError(f"{field.field_id}: choose one of {field.choices}")
        values[field.field_id] = value
    if controls.get("mode") != "CASHFLOW_ONLY" and values["base_currency"] != "EUR":
        raise InputValidationError("EUR collateral/notes only; no implicit FX conversion")
    for key in ("clo_size", "opening_collateral_par", "collateral_purchase_price",
                "reinvestment_purchase_price", "reinvestment_wal", "maximum_collateral_wal"):
        if values[key] <= 0:
            raise InputValidationError(f"{key} must be positive")
    return values


def _bps(rate: Decimal) -> Decimal:
    sign, digits, exponent = rate.as_tuple()
    return Decimal((sign, digits, exponent + 4))


def _price_percent(fraction: Decimal) -> Decimal:
    sign, digits, exponent = fraction.as_tuple()
    return Decimal((sign, digits, exponent + 2))


def _note_floor(global_floor: Decimal, per_class_bps: object) -> Decimal:
    specific = optional_decimal(per_class_bps, "index_floor_bps")
    return global_floor if specific is None else max(global_floor, basis_points_rate(specific))


def legacy_model_request_from_records(
    assets: tuple[Mapping[str, object], ...], capital: tuple[Mapping[str, object], ...],
    provider: RateProvider, *, controls: Mapping[str, object], provenance: str,
    factors: tuple[Mapping[str, object], ...], limits: tuple[Mapping[str, object], ...],
    principal_schedule_records: tuple[Mapping[str, object], ...] = (),
    coupon_step_records: tuple[Mapping[str, object], ...] = (),
    closing_cost_records: tuple[Mapping[str, object], ...] = (),
    recurring_expense_records: tuple[Mapping[str, object], ...] = (),
    detailed_records: tuple[Mapping[str, object], ...] = (),
    simplified_records: tuple[Mapping[str, object], ...] = (),
    seasoned_states: Mapping[str, object] | None = None,
    clo_opening_state=None,
    forward_equity_value=None,
    equity_value_source: str = "",
) -> TridentModelRequest:
    """Map each editable source field to execution, validation or an active policy."""
    v = legacy_values(controls)
    if any(row.get("currency") != v["base_currency"] for row in (*assets, *capital)):
        raise InputValidationError("Assets and Capital Stack must match Base Currency; no implicit FX conversion")
    if date_value(controls["valuation_date"], "Market Data as of") != v["pricing_date"]:
        raise InputValidationError("Pricing Date must match Market Data As Of Date; refresh both for a new pricing snapshot")
    if not (v["closing_date"] < v["first_note_payment_date"] <= v["maturity_date"]
            and v["pricing_date"] <= (v["closing_date"] if clo_opening_state is None else clo_opening_state.as_of_date)):
        raise InputValidationError("Pricing <= Closing < First Note Payment <= Maturity is required")
    # Standalone loan projections may be entirely equity funded without a
    # capital stack. A selected CLO or supplied stack must still reconcile.
    if (capital or controls["mode"] == "CLO_BASELINE") and sum(
            (Fraction(decimal_value(row["nominal_amount"], "nominal_amount")) for row in capital), Fraction()) != Fraction(v["clo_size"]):
        raise InputValidationError("CLO Size must reconcile to total Capital Stack nominal (debt plus equity)")
    if sum((Fraction(decimal_value(row["current_par"], "current_par")) for row in assets), Fraction()) != Fraction(v["opening_collateral_par"]):
        raise InputValidationError("Opening Collateral Par must reconcile to identified Assets current par")
    from trident.application.imported_cashflows import allocate_purchased_accrued
    allocated = allocate_purchased_accrued({text_value(row["loan_id"], "loan_id"): decimal_value(row["current_par"], "current_par")
        for row in assets}, v["purchased_accrued_interest"])
    asset_rows = tuple({**{key: value for key, value in row.items() if key not in {"is_ccc", "is_discount"}},
        "purchase_price_pct": _price_percent(v["collateral_purchase_price"]),
        "acquired_accrued_interest": allocated[row["loan_id"]]} for row in assets)
    costs = tuple(ClosingCostItem(key, v[key]) for key in CLOSING_COMPONENTS)
    costs += tuple(ClosingCostItem(text_value(row["cost_id"], "cost_id"), decimal_value(row["amount"], "amount")) for row in closing_cost_records)
    budget = ClosingCostBudget(v["clo_size"], v["upfront_arrangement_fee"], costs)
    source_type = (ClosingSourceType.EXTERNAL_CONTRIBUTION if not v["other_initial_sources"] else
        ClosingSourceType(text_value(controls.get("other_initial_source_type"), "other_initial_source_type")))
    cash = run_request_from_records(asset_rows, capital, provider, upfront_fees=Decimal(0),
        seasoned_states=seasoned_states,
        cash_reserve=v["initial_reserve_funding"], rate_provenance=provenance,
        principal_schedule_records=principal_schedule_records, coupon_step_records=coupon_step_records,
        closing_cost_budget=budget,
        existing_clo=clo_opening_state is not None,
        other_initial_uses=v["other_initial_uses"], other_initial_sources=v["other_initial_sources"],
        other_initial_source_type=source_type)
    opening_date = v["closing_date"] if clo_opening_state is None else clo_opening_state.as_of_date
    if any(position.par_as_of_date != opening_date for position in cash.positions):
        raise InputValidationError("Closing Date must match the Assets opening par snapshot")
    mapping = factor_mapping_from_records(factors)
    exposures = exposures_from_records(assets, mapping)
    # These generated quality controls monitor the live portfolio, including
    # temporary empty pools. Only engine-proved final settlement is excluded;
    # explicit user limits keep their own phases (empty means every phase).
    quality = tuple(LimitSpec(f"LEGACY_{key.upper()}", metric, _bps(v[key]) if metric == "WAS_BPS" else v[key], direction,
                             phases=ACTIVE_PORTFOLIO_PHASES)
        for key, metric, direction in (
            ("minimum_collateral_was", "WAS_BPS", LimitDirection.MINIMUM),
            ("minimum_collateral_warr", "WARR", LimitDirection.MINIMUM),
            ("maximum_collateral_wal", "WAL_YEARS", LimitDirection.MAXIMUM),
            ("maximum_portfolio_warf", "WARF", LimitDirection.MAXIMUM),
            ("maximum_single_obligor", "LARGEST_OBLIGOR_FRACTION", LimitDirection.MAXIMUM),
            ("maximum_industry", "LARGEST_SECTOR_FRACTION", LimitDirection.MAXIMUM),
            ("long_dated_asset_limit_fraction", "LONG_DATED_FRACTION", LimitDirection.MAXIMUM)))
    limit_specs = (*limits_from_records(limits), *quality)
    projection_source = controls["collateral_projection_source"]
    if projection_source not in {"INTERNAL_ENGINE", "IMPORTED"}:
        raise InputValidationError("collateral_projection_source must be INTERNAL_ENGINE or IMPORTED")
    if controls["mode"] == "CASHFLOW_ONLY":
        if clo_opening_state is not None:
            raise InputValidationError("Existing CLO Opening requires CLO_BASELINE mode")
        if projection_source != "INTERNAL_ENGINE":
            raise InputValidationError("CASHFLOW_ONLY requires INTERNAL_ENGINE; imported collateral cashflows are supported in CLO_BASELINE")
        return TridentModelRequest(cash, exposures, mapping, limit_specs)
    if controls["mode"] != "CLO_BASELINE":
        raise InputValidationError("Run mode must be CASHFLOW_ONLY or CLO_BASELINE")
    fee_base = (ManagementFeeBasis.TIME_WEIGHTED_PERFORMING_PAR if v["fee_base"] == "Average Performing Par"
                else ManagementFeeBasis.OPENING_PERFORMING_PAR)
    recurring = tuple(RecurringSeniorExpense(key, v[key]) for key in RECURRING_COMPONENTS)
    recurring += tuple(RecurringSeniorExpense(text_value(row["expense_id"], "expense_id"), decimal_value(row["annual_amount"], "annual_amount")) for row in recurring_expense_records)
    # modUtils.YearFrac clamps both days independently: its ambiguous legacy
    # "30/360" label actually executes Eurobond 30E/360, not Bond Basis/NASD.
    count = {"ACT/360": DayCount.ACT_360, "ACT/365": DayCount.ACT_365F, "30/360": DayCount.THIRTY_E_360}[v["day_count"]]
    bdc = {"Modified Following": BusinessDayConvention.MODIFIED_FOLLOWING,
           "Following": BusinessDayConvention.FOLLOWING, "Unadjusted": BusinessDayConvention.UNADJUSTED}[v["payment_date_convention"]]
    curve = v["cash_accrual_curve"].replace(" ", "_")
    account_mode = CashAccountAccrualMode.DF_FORWARD_SIMPLE if curve in {"ESTR", "SOFR", "SONIA"} else CashAccountAccrualMode.PROJECTED_TERM_SIMPLE
    funding = None if clo_opening_state is not None else FundingEngine().calculate(cash.purchases, cash.issues, upfront_fees=cash.upfront_fees,
        cash_reserve=cash.cash_reserve, other_initial_uses=cash.other_initial_uses,
        other_initial_sources=cash.other_initial_sources, other_initial_source_type=cash.other_initial_source_type,
        closing_cost_budget=cash.closing_cost_budget)
    terms = CloTerms(closing_date=v["closing_date"], legal_final_date=v["maturity_date"],
        frequency_months=int(v["payment_frequency"].replace("M", "")),
        senior_management_fee_bps=_bps(v["senior_management_fee"]),
        subordinated_management_fee_bps=_bps(v["subordinated_management_fee"]),
        initial_reserve=v["initial_reserve_funding"], business_day_convention=bdc,
        accrual_date_basis=AccrualDateBasis(controls["clo_accrual_date_basis"]),
        end_of_month=boolean_value(controls["clo_end_of_month"], "clo_end_of_month"),
        stub_convention=StubConvention.SHORT_FIRST, first_payment_date_unadjusted=v["first_note_payment_date"],
        fixing_lag_business_days=v["rate_fixing_lag"], collection_cutoff_business_days=v["determination_lag"],
        payment_calendar=CalendarName(v["payment_calendar"]), fixing_calendar=CalendarName(v["fixing_calendar"]),
        determination_calendar=CalendarName(v["determination_calendar"]),
        fixing_date_anchor=FixingDateAnchor.PERIOD_START if v["fixing_date_anchor"] == "Period Start" else FixingDateAnchor.PAYMENT_DATE,
        first_stub_rate_method={"Selected Reference": FirstStubRateMethod.SELECTED_REFERENCE,
            "Interpolate 1M/3M/6M": FirstStubRateMethod.INTERPOLATE_1M_3M_6M, "User Override": FirstStubRateMethod.USER_OVERRIDE}[v["first_stub_rate_method"]],
        first_stub_rate_override=v["first_stub_rate_override"] if v["first_stub_rate_method"] == "User Override" else None,
        independent_note_reference_tenor=True,
        coverage_tests_enabled=v["oc_ic_tests"] == "Enabled", interest_diversion_enabled=v["interest_diversion"] == "Enabled",
        principal_repayment_mode=PrincipalRepaymentMode.PRO_RATA if v["principal_waterfall"] == "Pro Rata" else PrincipalRepaymentMode.SEQUENTIAL,
        interest_diversion_mode=InterestDiversionMode(controls["interest_diversion_mode"]),
        management_fee_basis=fee_base, recurring_senior_expenses=recurring,
        management_fee_day_count=DayCount(controls["management_fee_day_count"]),
        senior_expenses_day_count=DayCount(controls["senior_expenses_day_count"]),
        variable_senior_expenses_bps=_bps(v["expected_senior_expenses_variable"]),
        annual_senior_expense_cap=v["senior_expense_cap_fixed"], senior_expense_cap_bps=_bps(v["senior_expense_cap_variable"]),
        include_principal_cash_in_oc=v["include_principal_cash_in_oc"] == "Yes",
        cash_account_accrual_mode=account_mode, cash_account_rate_index=curve,
        cash_account_spread_bps=_bps(v["cash_account_spread"]), cash_account_rate_floor=v["cash_account_rate_floor"],
        cash_account_day_count=DayCount(controls["cash_account_day_count"]),
        cash_account_fixing_lag_business_days=integer_value(controls["cash_account_fixing_lag_business_days"], "cash_account_fixing_lag_business_days"),
        incentive_fee_enabled=v["incentive_management_fee_enabled"] == "Yes", incentive_fee_rate=v["incentive_fee_rate"],
        incentive_hurdle_rate=v["equity_irr_hurdle"], incentive_initial_equity_funding=None if funding is None else funding.equity_cash_funding,
        interest_shortfall_carry=v["interest_shortfall_carry"] == "Enabled", continue_after_coupon_shortfall=True,
        shortfall_accrual_method=ShortfallAccrualMethod.NONE if v["shortfall_accrual_method"] == "None" else ShortfallAccrualMethod.COUPON_RATE,
        optional_call_enabled=v["optional_call_enabled"] == "Yes", optional_call_date=v["call_date"] if v["optional_call_enabled"] == "Yes" else None,
        optional_call_collateral_sale_price=v["call_collateral_sale_price"], optional_call_cost_pct_of_debt=v["call_costs_of_debt_fraction"],
        refinancing_enabled=v["refinancing_enabled"] == "Yes", refinancing_date=v["refinancing_date"] if v["refinancing_enabled"] == "Yes" else None,
        refinancing_spread_reduction=v["refi_spread_reduction"], refinancing_fee_pct_of_debt=v["refi_fee_of_debt_fraction"],
        maturity_liquidation_price=v["maturity_liquidation_fraction"], allow_long_dated_assets=v["allow_long_dated_assets"] == "Yes",
        long_dated_limit_fraction=v["long_dated_asset_limit_fraction"], defaulted_asset_oc_treatment=DefaultedAssetOcTreatment.ADJUSTED_POLICY,
        adjusted_oc_policy=AdjustedCollateralValuePolicy(v["use_asset_level_test_data"] == "Yes", v["ccc_fraction"],
            v["ccc_limit_fraction"], v["ccc_valuation_fraction"], v["discount_obligation_fraction"],
            v["discount_obligation_valuation_fraction"], v["defaulted_asset_valuation_fraction"],
            v["long_dated_oc_valuation_fraction"], v["discount_obligation_price_threshold"]),
        original_pool_overlay=OriginalPoolOverlay(v["credit_prepayment_overlay"] == "On", v["original_annual_default_rate"],
            v["original_collateral_cpr"], v["original_recovery_rate"], v["original_recovery_lag_months"], DefaultTimingPattern(v["default_timing_pattern"])),
        synthetic_reinvestment_policy=SyntheticReinvestmentPolicy(v["reinvestment_enabled"] == "Yes", v["reinvestment_end_date"],
            v["reinvestment_reference_curve"], _bps(v["reinvestment_asset_spread"]), v["reinvestment_purchase_price"],
            v["reinvestment_wal"], v["reinvestment_annual_prepayment_rate"], v["reinvestment_annual_default_rate"],
            v["reinvestment_recovery_rate"], v["reinvestment_recovery_lag_months"], v["recycle_reinvestment_principal"] == "Yes",
            ReinvestmentTestGate.ALWAYS_REINVEST if v["reinvestment_test_gate"] in {"Continue", "Always Reinvest"} else ReinvestmentTestGate.STOP_ON_TEST_FAILURE,
            v["reinvestment_asset_reference_floor"], day_count=count),
    )
    terms = replace(terms,
        include_deferred_interest_in_oc=boolean_value(controls["include_deferred_interest_in_oc"], "include_deferred_interest_in_oc"),
        include_deferred_interest_in_ic=boolean_value(controls["include_deferred_interest_in_ic"], "include_deferred_interest_in_ic"),
        principal_coupon_policy=PrincipalCouponPolicy(controls["principal_coupon_policy"]),
        interest_diversion_test_enabled=boolean_value(controls["interest_diversion_test_enabled"], "interest_diversion_test_enabled"),
        interest_diversion_test_class_id=optional_text(controls["interest_diversion_test_class_id"], "interest_diversion_test_class_id"),
        interest_diversion_test_oc_minimum=optional_decimal(controls["interest_diversion_test_oc_minimum"], "interest_diversion_test_oc_minimum"),
        interest_diversion_test_max_fraction=decimal_value(controls["interest_diversion_test_max_fraction"], "interest_diversion_test_max_fraction"),
        interest_diversion_test_end_date=(None if controls["interest_diversion_test_end_date"] in (None, "")
            else date_value(controls["interest_diversion_test_end_date"], "interest_diversion_test_end_date")),
    )
    if sum(row["instrument_type"] == "EQUITY" for row in capital) != 1:
        raise InputValidationError("One combined residual equity class is required")
    notes = tuple(NoteTranche(text_value(row["class_id"], "class_id"), integer_value(row["payment_priority"], "payment_priority"),
        decimal_value(row["nominal_amount"], "nominal_amount"), CouponType(row["coupon_type"]),
        v["reference_curve"].replace(" ", "_") if row["coupon_type"] == "FLOATING" else None,
        decimal_value(row["spread_bps"], "spread_bps"), optional_decimal(row.get("fixed_rate"), "fixed_rate"),
        _note_floor(v["liability_reference_floor"], row.get("index_floor_bps")) if row["coupon_type"] == "FLOATING" else None, count,
        optional_decimal(row.get("oc_minimum"), "oc_minimum"), optional_decimal(row.get("ic_minimum"), "ic_minimum"),
        interest_deferrable=boolean_value(row.get("interest_deferrable"), "interest_deferrable"),
        pik_rate_fraction=optional_decimal(row.get("pik_rate_fraction"), "pik_rate_fraction") or Decimal(0))
        for row in capital if row["instrument_type"] == "DEBT")
    if v["use_asset_level_test_data"] == "Yes":
        for row in assets:
            for classification in ("is_ccc", "is_discount"):
                if row.get(classification) in (None, ""):
                    raise InputValidationError(f"Asset-level OC requires explicit {classification} for {row['loan_id']}; unknown classification cannot pass a test")
    oc_data = tuple(OcAssetData(row["loan_id"], boolean_value(row.get("is_ccc") or False, "is_ccc"),
        boolean_value(row.get("is_discount") or False, "is_discount"),
        v["collateral_purchase_price"],
        market_price_fraction=optional_decimal(row.get("oc_market_price_fraction"), "oc_market_price_fraction"))
        for row in assets)
    imported = None
    if controls["collateral_projection_source"] == "IMPORTED":
        if (v["purchased_accrued_interest"] and not boolean_value(
                controls["imported_cashflows_include_purchased_accrued"], "imported_cashflows_include_purchased_accrued")):
            raise InputValidationError("Nonzero purchased accrued requires imported full coupon entitlement acknowledgement; include it in the supplied interest once")
        from .imported_records import imported_projection_from_records
        imported = imported_projection_from_records(v, detailed_records, simplified_records)
    elif controls["collateral_projection_source"] != "INTERNAL_ENGINE":
        raise InputValidationError("collateral_projection_source must be INTERNAL_ENGINE or IMPORTED")
    return TridentModelRequest(cash, exposures, mapping, limit_specs, terms, notes, v["reinvestment_end_date"],
        oc_asset_data=oc_data, imported_collateral=imported, clo_opening_state=clo_opening_state,
        forward_equity_value=forward_equity_value, equity_value_source=equity_value_source)
