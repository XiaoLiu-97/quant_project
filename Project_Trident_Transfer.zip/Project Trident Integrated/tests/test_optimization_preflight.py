"""Readiness, side/accrued transport and read-only CLI regression.

The workbook is an input fixture, not a financial oracle. EUR100 principal,
EUR2 acquisition accrued and a EUR60 note permit independent funding checks.
"""

from contextlib import redirect_stdout, redirect_stderr
from datetime import date
from decimal import Decimal
import hashlib
from io import StringIO
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

from openpyxl import load_workbook
from workbook_fixtures import copy_input_template

from trident.adapters import excel_schema as schema
from trident.adapters.candidate_records import candidate_search_from_records
from trident.adapters.excel import NamedWorkbook, run_workbook
from trident.adapters.excel_model import read_model_workbook_inputs, _read_table
from trident.adapters.optimization_preflight import check_optimization_workbook
from trident.adapters.excel_schema import require_current_schema
from trident.application.candidate_search import ClosingPoolSearchService
from trident.cli import main
from trident.domain.models import InputValidationError
from test_policy_transport import audited_inputs

ROOT = Path(__file__).resolve().parents[1]
D = Decimal


class OptimizationPreflightTests(unittest.TestCase):
    def setUp(self):
        folder = tempfile.TemporaryDirectory()
        self.addCleanup(folder.cleanup)
        self.path = Path(folder.name) / "inputs.xlsx"
        copy_input_template(self.path)
        self._prepare()

    def access(self, action, *, save=False):
        book = load_workbook(self.path)
        try:
            result = action(NamedWorkbook(book))
            if save:
                book.save(self.path)
            return result
        finally:
            book.close()

    @staticmethod
    def put(adapter, key, records):
        sheet, (left, top, right, _) = adapter.region(schema.TABLE_RANGE_NAMES[key])
        headers = tuple(sheet.cell(top, col).value for col in range(left, right + 1))
        adapter.write_table(schema.TABLE_RANGE_NAMES[key], schema.TABLE_NAMES[key],
            tuple({field: row.get(field) for field in headers} for row in records))

    def _prepare(self):
        assets, capital, controls, factors, _ = audited_inputs()
        old = dict(assets[0], asset_class="BSL", financing_type="TERM_LOAN", test_factor_bucket="TEST_02")
        new = dict(old, loan_id="NEW", obligor_id="NEW_ISSUER", test_factor_bucket="TEST_01", spread_bps=600)
        controls.update(scenario_enabled=False, rate_provider="SYNTHETIC_FLAT", candidate_search_enabled=True,
            optimizer_enabled=False, optimizer_target_par=100, optimizer_starting_cash=10,
            optimizer_maximum_trade_par=200, optimizer_maximum_overall_factor=2000,
            optimizer_maximum_bsl_factor=2000, optimizer_maximum_obligor_share=1,
            optimizer_maximum_country_share=1, optimizer_maximum_sector_share=1,
            optimizer_maximum_bsl_share=1, optimizer_minimum_infra_share=0,
            candidate_snapshot_id="INDEPENDENT_HAND", candidate_snapshot_captured_at="2026-11-19T16:00:00+00:00",
            candidate_snapshot_source="SYNTHETIC_NOT_BLOOMBERG")
        common = dict(asset_class="BSL", country_code=old["country_code"], sector=old["sector"], currency="EUR",
            maximum_par=100, clean_price_pct=100, accrued_per_par=0, proportional_fee_per_par=0,
            lot_size=None, minimum_ticket=0, fixed_fee=0)
        quotes = tuple(dict(common, asset_id=row["loan_id"], obligor_id=row["obligor_id"],
            factor_bucket=row["test_factor_bucket"], spread_bps=row["spread_bps"], side=side)
            for row, side in ((old,"SELL"),(new,"BUY")))
        def edit(adapter):
            for key, rows in (("assets",(old,)),("capital_stack",capital),("factor_mapping",factors),
                              ("portfolio_limits",()),("candidate_assets",(new,)),("trade_candidates",quotes),
                              ("credit_events",()),("recovery_schedule",()),("principal_schedule",())):
                self.put(adapter,key,rows)
            for key in schema.READ_INPUT_KEYS:
                if key in controls:
                    adapter.write_scalar(schema.SCALAR_NAMES[key],controls[key])
            self.put(adapter,"candidate_metadata",tuple(dict(loan_id=row["loan_id"], facility_id=f"TRANCHE_{row['loan_id']}",
                bloomberg_security=f"TEST_{row['loan_id']}", contract_provenance="HAND_CONTRACT",
                classification_provenance="HAND_CLASSIFICATION",credit_status="PERFORMING") for row in (old,new)))
            self.put(adapter,"candidate_ratings",tuple(dict(loan_id=row["loan_id"],agency="TEST",rating="TEST_RATING",
                level="FACILITY",nature="INTERNAL",subject_id=f"TRANCHE_{row['loan_id']}",as_of_date=date(2026,11,19),
                source="HAND_RATING") for row in (old,new)))
            self.put(adapter,"quote_observations",tuple(dict(asset_id=row["asset_id"],side=row["side"],
                price_side="BID" if row["side"]=="SELL" else "ASK",quality="FIRM",
                observed_at="2026-11-19T16:00:00+00:00",settlement_date=date(2026,11,20),source="HAND_QUOTE") for row in quotes))
            self.put(adapter,"candidate_variants",(dict(candidate_id="LOW_FACTOR",objective="MIN_FACTOR",enabled=True),))
        self.access(edit,save=True)

    def edit_scalar(self, key, value):
        self.access(lambda adapter: adapter.write_scalar(schema.SCALAR_NAMES[key],value),save=True)

    def edit_table(self, key, action):
        def edit(adapter):
            rows = tuple(dict(row) for row in _read_table(adapter,key))
            self.put(adapter,key,action(rows))
        self.access(edit,save=True)

    def test_readonly_check_runs_no_financial_engine_or_solver(self):
        before = hashlib.sha256(self.path.read_bytes()).hexdigest()
        with patch("trident.application.clo_services.TridentModelService.run", side_effect=AssertionError("projected")), \
             patch("trident.optimization.StaticTradeOptimizer.solve", side_effect=AssertionError("solved")):
            report = check_optimization_workbook(self.path)
        self.assertEqual(report["status"],"DATA_READY")
        self.assertEqual((report["holdings_count"],report["admitted_count"],report["variant_count"]),(1,2,1))
        self.assertIn("AGENCY_RATING_FACTOR_CALIBRATION",report["checks_not_run"])
        self.assertEqual(hashlib.sha256(self.path.read_bytes()).hexdigest(),before)

    def test_stale_quotes_report_each_asset_with_no_silent_exclusion(self):
        self.edit_table("quote_observations",lambda rows: tuple(dict(row,observed_at="2026-11-16T16:00:00+00:00") for row in rows))
        report=check_optimization_workbook(self.path)
        self.assertEqual(report["status"],"NOT_READY")
        self.assertEqual(report["quarantined_count"],2)
        errors=[row for row in report["issues"] if row["severity"]=="ERROR"]
        self.assertEqual({row["identifier"] for row in errors},{"HAND","NEW"})
        self.assertTrue(all("age" in row["message"].lower() for row in errors))

    def test_missing_rating_and_wrong_price_side_have_actionable_reasons(self):
        self.edit_table("candidate_ratings",lambda rows: tuple(row for row in rows if row["loan_id"]!="NEW"))
        self.edit_table("quote_observations",lambda rows: tuple(dict(row,price_side="MID") if row["asset_id"]=="NEW" else row for row in rows))
        report=check_optimization_workbook(self.path)
        error=next(row for row in report["issues"] if row["identifier"]=="NEW")
        self.assertEqual(error["severity"],"ERROR")
        self.assertIn("rating",error["message"].lower())
        self.assertIn("ASK",error["message"])

    def test_candidate_accrued_enters_funding_and_entitlement_once(self):
        def request(adapter):
            inputs=read_model_workbook_inputs(adapter,)
            return candidate_search_from_records(inputs.request,None,inputs.assets,inputs.quotes,inputs.controls,
                **{key:_read_table(adapter,key) for key in
                   ("candidate_assets","candidate_metadata","candidate_ratings","quote_observations","candidate_variants")})
        base=ClosingPoolSearchService().run(self.access(request)).evaluation("LOW_FACTOR")
        self.edit_table("trade_candidates",lambda rows: tuple(dict(row,accrued_per_par=.02) if row["side"]=="BUY" else row for row in rows))
        self.assertEqual(check_optimization_workbook(self.path)["status"],"DATA_READY")
        changed=ClosingPoolSearchService().run(self.access(request)).evaluation("LOW_FACTOR")
        self.assertIsNotNone(changed.replay.target_result,changed.failure_message)
        # Synthetic factors cannot satisfy the mandatory production WARF
        # mandate. That exclusion must remain while we verify accrued funding.
        self.assertFalse(changed.eligible)
        self.assertIn("WARF",changed.failure_message)
        self.assertEqual(changed.replay.target_result.cashflows.funding.equity_cash_funding,D(42))
        self.assertEqual(changed.replay.target_result.cashflows.funding.equity_cash_funding-base.replay.target_result.cashflows.funding.equity_cash_funding,D(2))
        self.assertEqual(changed.equity_distributions-base.equity_distributions,D(2))
        # The same quotes must also survive the full Excel execution boundary.
        run_workbook(self.path)
        self.assertEqual(self.access(lambda a: next(row for row in _read_table(a,"candidate_results")
            if row["candidate_id"]=="LOW_FACTOR")["equity_cash_funding"]),42)

    def test_static_budget_remains_separate_from_closing_accrued(self):
        self.edit_table("trade_candidates",lambda rows: tuple(dict(row,accrued_per_par=.02) if row["side"]=="BUY" else row for row in rows))
        with self.assertRaisesRegex(InputValidationError,"zero accrued"):
            check_optimization_workbook(self.path,mode="static")
        self.edit_scalar("optimizer_enabled",True)
        report=check_optimization_workbook(self.path)
        self.assertEqual(report["status"],"NOT_READY")
        self.assertIn("STATIC_ACCRUED_CONFLICT",{row["code"] for row in report["issues"]})

    def test_descriptor_cannot_borrow_a_lower_factor_than_full_contract(self):
        self.edit_table("candidate_assets",lambda rows: tuple(dict(row,test_factor_bucket="TEST_06") for row in rows))
        report=check_optimization_workbook(self.path)
        self.assertEqual(report["status"],"NOT_READY")
        error=next(row for row in report["issues"] if row["code"]=="COMMON_INPUT_MISMATCH")
        self.assertIn("selected factor",error["message"])

    def test_named_control_relocation_remains_supported_by_preflight(self):
        def move(adapter):
            name=schema.SCALAR_NAMES["optimizer_starting_cash"]
            sheet,(left,top,_,_)=adapter.region(name)
            moved=adapter.workbook.create_sheet("Relocated")
            moved["D8"]=10
            sheet.cell(top,left).value=None
            adapter.workbook.defined_names[name].attr_text="'Relocated'!$D$8"
        self.access(move,save=True)
        self.assertEqual(check_optimization_workbook(self.path)["status"],"DATA_READY")

    def test_cli_exit_and_json_match_data_readiness(self):
        output=StringIO()
        with redirect_stdout(output):
            code=main(["check-optimization",str(self.path)])
        self.assertEqual(code,0)
        self.assertEqual(json.loads(output.getvalue())["status"],"DATA_READY")
        self.edit_table("candidate_ratings",lambda rows: ())
        with redirect_stdout(StringIO()):
            self.assertEqual(main(["check-optimization",str(self.path)]),2)
        self.edit_scalar("schema_version","unregistered")
        errors=StringIO()
        with redirect_stderr(errors):
            self.assertEqual(main(["check-optimization",str(self.path)]),2)
        self.assertIn("Unsupported",errors.getvalue())

    def test_unknown_quote_field_and_unregistered_schema_are_rejected(self):
        from trident.adapters.optimization_records import optimization_snapshot_from_records
        def check(adapter):
            inputs=read_model_workbook_inputs(adapter,)
            quotes=tuple(dict(row,misspelled_fee=100) for row in inputs.quotes)
            with self.assertRaisesRegex(InputValidationError,"misspelled_fee"):
                optimization_snapshot_from_records(inputs.assets,quotes,inputs.controls,inputs.request.factor_mapping,
                    opening_date=date(2026,11,20))
        self.access(check)
        with self.assertRaises(InputValidationError):
            require_current_schema("../../untrusted")


if __name__ == "__main__":
    unittest.main()
