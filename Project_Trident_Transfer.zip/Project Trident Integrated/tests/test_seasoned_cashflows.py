"""Known-answer seasoned cash-pay cases with preserved original entitlements.

Small 100-par examples separately control fixing reuse, the first unpaid coupon,
single monetary posting, principal installment indices and investor slice
resizing. Expectations are direct calendar/day-count arithmetic, not outputs
copied from another call to the cashflow engine.
"""

from dataclasses import replace
from datetime import date, datetime, timedelta, timezone
from decimal import Decimal, Inexact, localcontext
from fractions import Fraction
import unittest

from trident.cashflows import ContractualCashflowEngine
from trident.cashflows.seasoned import build_position_schedule, resize_seasoned_state
from trident.conventions import AccrualDateBasis, BusinessDayConvention, DayCount
from trident.conventions.calendar import TargetCalendar
from trident.credit import CreditEventCashflowEngine, DefaultEvent, PrepaymentEvent
from trident.credit.overlay import DefaultTimingPattern, OriginalPoolOverlay
from trident.domain.models import (
    AmortizationType, CouponStep, CouponType, InputValidationError, LoanPosition,
    CouponStepPolicy, LoanTerms, OpeningCouponEntitlement, OpeningFixing, PrincipalScheduleEntry, SeasonedLoanState,
)
from trident.market import FlatRateProvider


D = Decimal
START, ASOF, FIRST, END = date(2026, 1, 1), date(2026, 2, 15), date(2026, 4, 1), date(2026, 7, 1)
FULL = OpeningCouponEntitlement.FULL_CURRENT_PERIOD
EXPLICIT = OpeningCouponEntitlement.EXPLICIT_CASH_CLAIM
POST = OpeningCouponEntitlement.POST_ASOF_ONLY


class CountingProvider:
    """Raise if an original historical fixing is unnecessarily queried."""

    def __init__(self, observations):
        self.observations, self.calls = dict(observations), []

    def rate(self, index, fixing_date):
        self.calls.append((index, fixing_date))
        if fixing_date not in self.observations:
            raise AssertionError(f"Unexpected fixing query {fixing_date}")
        return self.observations[fixing_date]


def position(*, floating=False, start=START, asof=ASOF, end=END, par=D(100),
             claim=None, policy=FULL, fixings=None, **terms_changes):
    """Original quarterly schedule; explicit seasonal opening statement."""
    terms = LoanTerms("L", "EUR", start, end, D(100),
        CouponType.FLOATING if floating else CouponType.FIXED,
        fixed_rate=None if floating else D(".12"),
        rate_index="EURIBOR_3M" if floating else None,
        spread_bps=D(300) if floating else D(0),
        day_count=DayCount.ACT_360,
        business_day_convention=BusinessDayConvention.UNADJUSTED,
        accrual_date_basis=AccrualDateBasis.UNADJUSTED,
        fixing_lag_business_days=0)
    if terms_changes:
        terms = replace(terms, **terms_changes)
    if claim is None:
        claim = D(".63") if floating else D("1.50")
    if fixings is None:
        fixings = (OpeningFixing(START, D(".02")),) if floating else ()
    return LoanPosition(terms, asof, par, SeasonedLoanState(claim, "INDEPENDENT_HAND_CONTROL", fixings, policy))


class SeasonedScheduleTests(unittest.TestCase):
    def test_original_anchor_and_single_full_coupon_posting_are_retained(self):
        held = position()
        rows = ContractualCashflowEngine(FlatRateProvider({})).generate(held)
        self.assertEqual([row.payment_date for row in rows], [FIRST, END])
        self.assertEqual(rows[0].unadjusted_start, START)
        self.assertEqual(rows[0].accrual_start, ASOF)
        self.assertEqual(rows[0].opening_accrued_interest, D("1.50"))
        self.assertEqual(rows[0].opening_accrued_exact, Fraction(3, 2))
        #45historical +45forward days at12% ->3.00, then91days ->3.03.
        self.assertEqual([row.cash_interest for row in rows], [D(3), D("3.03")])
        self.assertEqual(rows[1].opening_accrued_interest, D(0))
        self.assertEqual(rows[1].opening_accrued_exact, Fraction())
        self.assertEqual(sum(row.principal_repayment for row in rows), D(100))

    def test_rounded_historical_component_does_not_move_the_full_coupon_one_cent(self):
        held = position(start=FIRST, asof=date(2026, 5, 15), claim=D("1.47"))
        row, = ContractualCashflowEngine(FlatRateProvider({})).generate(held)
        #44days prefix=22/15;47days remainder=47/30; sum91/30=>3.03.
        #Using roundedprefix1.47 would incorrectly post3.04.
        self.assertEqual(row.opening_accrued_exact, Fraction(22, 15))
        self.assertEqual(row.interest_unrounded, D("3.033333333333333333333333333333333"))
        self.assertEqual(row.cash_interest, D("3.03"))

    def test_explicit_cash_agreement_and_post_asof_only_are_separate_policies(self):
        held = position(start=FIRST, asof=date(2026, 5, 15), claim=D("1.47"), policy=EXPLICIT)
        explicit, = ContractualCashflowEngine(FlatRateProvider({})).generate(held)
        self.assertEqual(explicit.opening_accrued_exact, Fraction(147, 100))
        self.assertEqual(explicit.cash_interest, D("3.04"))
        forward, = ContractualCashflowEngine(FlatRateProvider({})).generate(
            replace(held, seasoned_state=SeasonedLoanState(D(0), "VERIFIED_SELLER_ALLOCATION", (), POST)))
        self.assertEqual(forward.cash_interest, D("1.57"))
        self.assertEqual(forward.opening_accrued_exact, Fraction())

    def test_first_floating_coupon_carries_original_fixing_not_asof_reset(self):
        provider = CountingProvider({FIRST: D(".04")})
        rows = ContractualCashflowEngine(provider).generate(position(floating=True))
        self.assertEqual(rows[0].fixing_date, START)
        self.assertEqual(rows[0].coupon_segments[0].reset_date, START)
        self.assertEqual(rows[0].index_rate, D(".02"))
        self.assertEqual(rows[0].opening_accrued_exact, Fraction(5, 8))
        #Full90days5%=1.25; next91days7%=>1.77.
        self.assertEqual([row.cash_interest for row in rows], [D("1.25"), D("1.77")])
        self.assertEqual(provider.calls, [("EURIBOR_3M", FIRST)])

    def test_semiannual_reset_is_carried_after_an_already_settled_quarter(self):
        end = date(2027, 1, 1)
        held = position(floating=True, asof=date(2026, 5, 15), end=end, claim=D(".61"),
            rate_index="EURIBOR_6M", reset_frequency_months=6)
        provider = CountingProvider({END: D(".04")})
        rows = ContractualCashflowEngine(provider).generate(held)
        self.assertEqual([row.payment_date for row in rows], [END, date(2026, 10, 1), end])
        self.assertEqual(rows[0].unadjusted_start, FIRST)
        self.assertEqual(rows[0].fixing_date, START)
        self.assertEqual(rows[0].coupon_segments[0].reset_date, START)
        self.assertEqual([row.cash_interest for row in rows], [D("1.26"), D("1.79"), D("1.79")])
        self.assertEqual(provider.calls, [("EURIBOR_6M", END)])

    def test_all_monthly_fixings_in_the_current_full_quarter_are_explicit(self):
        feb, march = date(2026, 2, 1), date(2026, 3, 1)
        held = position(floating=True, asof=date(2026, 3, 15),
            claim=D("1.17"), rate_index="EURIBOR_1M", reset_frequency_months=1,
            fixings=(OpeningFixing(START, D(".02")), OpeningFixing(feb, D(".03")), OpeningFixing(march, D(".04"))))
        provider = CountingProvider({FIRST: D(".04"), date(2026, 5, 1): D(".04"), date(2026, 6, 1): D(".04")})
        rows = ContractualCashflowEngine(provider).generate(held)
        #31days5%+28days6%+31days7%=5.40/360*100=1.50.
        #Prefix31days5%+28days6%+14days7%=4.21/360*100=1.16944,
        #The prefix posts to 1.17, while the combined full coupon posts once.
        self.assertEqual(rows[0].cash_interest, D("1.50"))
        self.assertEqual(rows[0].opening_accrued_exact, Fraction(421, 360))
        stale = replace(held, seasoned_state=replace(held.seasoned_state, opening_accrued_interest=D("1.26")))
        with self.assertRaisesRegex(InputValidationError, "exact original"):
            ContractualCashflowEngine(provider).generate(stale)

    def test_future_reset_already_fixed_by_asof_is_carried_without_provider_queries(self):
        # Apr 1 has a two-business-day fixing on Mar 30. That reset has not
        # begun at the snapshot, but its rate is already observed and binding.
        held = position(floating=True, asof=date(2026, 3, 30), claim=D("1.22"),
            fixing_lag_business_days=2,
            fixings=(OpeningFixing(date(2025, 12, 30), D(".02")),
                     OpeningFixing(date(2026, 3, 30), D(".04"))))
        provider = CountingProvider({})
        rows = ContractualCashflowEngine(provider).generate(held)
        self.assertEqual([row.cash_interest for row in rows], [D("1.25"), D("1.77")])
        self.assertEqual(provider.calls, [])
        missing = replace(held, seasoned_state=replace(held.seasoned_state,
            fixing_observations=held.seasoned_state.fixing_observations[:1]))
        with self.assertRaisesRegex(InputValidationError, "missing=.*2026, 3, 30"):
            ContractualCashflowEngine(provider).generate(missing)
        self.assertEqual(provider.calls, [])

    def test_monthly_post_asof_ownership_needs_only_forward_rate_history(self):
        march = date(2026, 3, 1)
        held = position(floating=True, asof=date(2026, 3, 15), claim=D(0), policy=POST,
            rate_index="EURIBOR_1M", reset_frequency_months=1,
            fixings=(OpeningFixing(march, D(".04")),))
        provider = CountingProvider({FIRST: D(".04"), date(2026, 5, 1): D(".04"), date(2026, 6, 1): D(".04")})
        rows = ContractualCashflowEngine(provider).generate(held)
        # The purchaser owns 17 days of the 7% March rate; January and
        # February belonged to the seller and need no invented observations.
        self.assertEqual(rows[0].cash_interest, D(".33"))
        self.assertEqual(rows[0].opening_accrued_exact, Fraction())
        full = replace(held, seasoned_state=replace(held.seasoned_state,
            opening_accrued_interest=D("1.17"), entitlement_policy=FULL))
        with self.assertRaisesRegex(InputValidationError, "missing=.*2026, 1, 1.*2026, 2, 1"):
            ContractualCashflowEngine(provider).generate(full)

    def test_future_deferred_fixed_and_floating_steps_use_original_boundaries(self):
        step = date(2026, 3, 15)
        fixed = position(coupon_steps=(CouponStep(step, fixed_rate=D(".15")),),
            coupon_step_policy=CouponStepPolicy.PAYMENT_START)
        fixed_rows = ContractualCashflowEngine(FlatRateProvider({})).generate(fixed)
        self.assertEqual([row.cash_interest for row in fixed_rows], [D(3), D("3.79")])
        floating = position(floating=True,
            coupon_steps=(CouponStep(step, spread_bps=D(600)),),
            coupon_step_policy=CouponStepPolicy.RESET_START)
        provider = CountingProvider({FIRST: D(".02")})
        floating_rows = ContractualCashflowEngine(provider).generate(floating)
        self.assertEqual([row.cash_interest for row in floating_rows], [D("1.25"), D("2.02")])
        self.assertEqual(floating_rows[0].coupon_segments[0].reset_date, START)

    def test_boundary_snapshot_excludes_same_day_already_settled_coupon(self):
        held = position(asof=FIRST, claim=D(0))
        row, = ContractualCashflowEngine(FlatRateProvider({})).generate(held)
        self.assertEqual(row.period_number, 1)
        self.assertEqual(row.unadjusted_start, FIRST)
        self.assertEqual(row.accrual_start, FIRST)
        self.assertEqual(row.payment_date, END)
        self.assertEqual(row.cash_interest, D("3.03"))

    def test_original_accelerating_installment_index_is_not_restarted_at_asof(self):
        held = position(start=date(2025, 10, 1), asof=date(2026, 2, 1), par=D(90),
            claim=D(".93"), amortization_type=AmortizationType.ACCELERATED,
            scheduled_principal_amount=D(10), amortization_growth=D(1))
        rows = ContractualCashflowEngine(FlatRateProvider({})).generate(held)
        #OriginalJan1installment10 is in the past; Apr1stillhas installment20.
        self.assertEqual([row.principal_repayment for row in rows], [D(20), D(70)])
        self.assertEqual([row.period_number for row in rows], [1, 2])
        self.assertEqual(build_position_schedule(held, TargetCalendar()).original_indices, (1, 2))

    def test_remaining_bespoke_principal_dates_keep_the_original_schedule(self):
        held = position(start=date(2025, 10, 1), asof=date(2026, 2, 1), par=D(70),
            claim=D(".72"), amortization_type=AmortizationType.BESPOKE,
            principal_schedule=(PrincipalScheduleEntry(START, D(0)),
                                PrincipalScheduleEntry(FIRST, D(30)), PrincipalScheduleEntry(END, D(40))))
        rows = ContractualCashflowEngine(FlatRateProvider({})).generate(held)
        self.assertEqual([row.principal_repayment for row in rows], [D(30), D(40)])
        self.assertEqual([row.closing_balance for row in rows], [D(40), D(0)])

    def test_seasoned_cash_is_independent_of_hostile_decimal_context(self):
        held = position(start=FIRST, asof=date(2026, 5, 15), claim=D("1.47"))
        with localcontext() as caller:
            caller.prec = 2
            caller.traps[Inexact] = True
            row, = ContractualCashflowEngine(FlatRateProvider({})).generate(held)
        self.assertEqual(row.cash_interest, D("3.03"))


class SeasonedValidationTests(unittest.TestCase):
    def test_missing_state_and_future_or_mutable_fixings_are_rejected(self):
        held = position(floating=True)
        with self.assertRaisesRegex(InputValidationError, "explicit seasoned_state"):
            replace(held, seasoned_state=None)
        for bad in ([OpeningFixing(START, D(".02"))],
                    (OpeningFixing(START, D(".02")), OpeningFixing(START, D(".02")))):
            with self.subTest(bad=bad), self.assertRaises(InputValidationError):
                SeasonedLoanState(D(".63"), "SOURCE", bad)
        with self.assertRaisesRegex(InputValidationError, "cannot follow"):
            replace(held, seasoned_state=SeasonedLoanState(D(".63"), "SOURCE", (OpeningFixing(FIRST, D(".02")),)))
        for bad in (datetime(2026, 1, 1), "2026-01-01"):
            with self.subTest(bad=bad), self.assertRaises(InputValidationError):
                OpeningFixing(bad, D(".02"))

    def test_missing_or_stale_fixing_date_cannot_fall_back_to_a_projected_rate(self):
        held = position(floating=True)
        for observations in ((), (OpeningFixing(date(2026, 1, 2), D(".02")),)):
            with self.subTest(observations=observations), self.assertRaisesRegex(InputValidationError, "missing=.*extra="):
                ContractualCashflowEngine(FlatRateProvider({"EURIBOR_3M": D(".09")})).generate(
                    replace(held, seasoned_state=replace(held.seasoned_state, fixing_observations=observations)))

    def test_full_opening_claim_must_match_original_economics(self):
        held = position(claim=D("1.51"))
        with self.assertRaisesRegex(InputValidationError, "exact original"):
            ContractualCashflowEngine(FlatRateProvider({})).generate(held)

    def test_post_asof_only_requires_explicit_zero(self):
        with self.assertRaisesRegex(InputValidationError, "POST_ASOF_ONLY"):
            SeasonedLoanState(D(1), "SELLER_ALLOCATION", (), POST)

    def test_nonadditive_midperiod_or_ended_unpaid_coupon_requires_another_profile(self):
        for convention in (DayCount.THIRTY_360_ISDA, DayCount.THIRTY_U_360_EOM):
            with self.subTest(convention=convention), self.assertRaisesRegex(InputValidationError, "additive"):
                ContractualCashflowEngine(FlatRateProvider({})).generate(position(day_count=convention))
        held = position(asof=date(2026, 4, 3), claim=D(3), payment_lag_business_days=5)
        with self.assertRaisesRegex(InputValidationError, "ended unpaid coupon"):
            ContractualCashflowEngine(FlatRateProvider({})).generate(held)

    def test_nonzero_claim_at_a_new_already_settled_period_boundary_rejects(self):
        with self.assertRaisesRegex(InputValidationError, "already settled coupon"):
            ContractualCashflowEngine(FlatRateProvider({})).generate(position(asof=FIRST, claim=D(1)))

    def test_historical_steps_and_recast_principal_are_not_silently_rebound(self):
        for kind in (AmortizationType.ANNUITY, AmortizationType.LINEAR_AUTO):
            terms_changes = dict(amortization_type=kind, balloon_amount=D(0))
            with self.subTest(kind=kind), self.assertRaisesRegex(InputValidationError, "recasts"):
                position(**terms_changes)
        with self.assertRaisesRegex(InputValidationError, "historical coupon steps"):
            position(coupon_steps=(CouponStep(date(2026, 2, 1), fixed_rate=D(".15")),))


class SeasonedCreditAndResizeTests(unittest.TestCase):
    def test_prepaid_first_coupon_adds_exact_claim_once_and_default_collects_none(self):
        held = position(start=FIRST, asof=date(2026, 5, 15), claim=D("1.47"))
        rows = ContractualCashflowEngine(FlatRateProvider({})).generate(held)
        engine = CreditEventCashflowEngine(FlatRateProvider({}))
        prepay = engine.apply(held, rows, PrepaymentEvent("L", date(2026, 6, 1)))
        #Apr1-Jun1 has61actualdays at12% on100:61/30=>2.03.
        self.assertEqual(prepay.total_cash_interest, D("2.03"))
        self.assertEqual(prepay.total_principal_collections, D(100))
        default = engine.apply(held, rows, DefaultEvent("L", date(2026, 6, 1)))
        self.assertEqual(default.total_cash_interest, D(0))
        self.assertEqual(default.total_principal_collections, D(0))
        self.assertEqual(default.final_defaulted_par, D(100))

    def test_frozen_credit_replay_rejects_tampered_opening_exact_claim(self):
        held = position()
        rows = ContractualCashflowEngine(FlatRateProvider({})).generate(held)
        #Same posted1.50, but a different unposted claim must not survive a
        #cash/par-balanced replay. The public validator checks the exact source.
        altered = replace(rows[0], opening_accrued_exact=Fraction(1501, 1000))
        with self.assertRaisesRegex(InputValidationError, "exact opening claim"):
            CreditEventCashflowEngine(FlatRateProvider({})).apply(held, (altered, rows[1]))

    def test_fractional_overlay_scales_the_exact_historical_claim_with_survivors(self):
        held = position(start=FIRST, asof=date(2026, 5, 15), claim=D("1.47"))
        rows = ContractualCashflowEngine(FlatRateProvider({})).generate(held)
        result = OriginalPoolOverlay().project(rows, {"L": D(100)}, held.par_as_of_date, END,
                                               loan_day_counts={"L": DayCount.ACT_360})
        self.assertEqual(result.collections[0].cash_interest, D("3.03"))
        self.assertEqual(result.final_performing_par, D(0))

    def test_partial_default_forfeits_its_opening_claim_and_keeps_survivor_coupon(self):
        final = date(2027, 1, 1)
        held = position(asof=FIRST, end=final, claim=D("2.96"),
            frequency_months=12, day_count=DayCount.ACT_365F)
        rows = ContractualCashflowEngine(FlatRateProvider({})).generate(held)
        # This labeled vector is only a transparent economic sensitivity.
        # A 100% annual input sets the five-year target to 100 par. The first
        # year allocates 39%, of which 275/365 accrues in this forward window:
        # default 29.38, survive 70.62, pay full-year coupon 70.62*12%=8.47.
        overlay = OriginalPoolOverlay(enabled=True, annual_default_rate=D(1),
            recovery_lag_months=12, default_timing_pattern=DefaultTimingPattern.SP_PATTERN_1)
        result = overlay.project(rows, {"L": D(100)}, FIRST, final,
                                 loan_day_counts={"L": DayCount.ACT_365F})
        self.assertEqual(result.final_defaulted_par, D("29.38"))
        self.assertEqual(result.collections[0].cash_interest, D("8.47"))
        self.assertEqual(result.collections[0].principal_collection, D("70.62"))
        self.assertEqual(result.final_performing_par, D(0))

    def test_full_claim_resize_uses_unrounded_history_and_explicit_claim_scales_its_quote(self):
        held = position(start=FIRST, asof=date(2026, 5, 15), claim=D("1.47"))
        state = resize_seasoned_state(held, Fraction(1, 2))
        self.assertEqual(state.opening_accrued_interest, D(".73"))
        scaled = replace(held, terms=replace(held.terms, reference_principal=D(50)),
                         opening_balance=D(50), seasoned_state=state)
        row, = ContractualCashflowEngine(FlatRateProvider({})).generate(scaled)
        self.assertEqual(row.cash_interest, D("1.52"))
        explicit = replace(held, seasoned_state=replace(held.seasoned_state, entitlement_policy=EXPLICIT))
        self.assertEqual(resize_seasoned_state(explicit, Fraction(1, 2)).opening_accrued_interest, D(".74"))

    def test_half_holding_known_claim_103_posts_052_independently(self):
        held = position(asof=date(2026, 2, 1), claim=D("1.03"))
        self.assertEqual(resize_seasoned_state(held, Fraction(1, 2)).opening_accrued_interest, D(".52"))

    def test_construction_resize_preserves_exact_full_period_claim(self):
        from trident.application.construction import _resize_position
        held = position(start=FIRST, asof=date(2026, 5, 15), claim=D("1.47"))
        resized = _resize_position(held, D(50))
        self.assertEqual(resized.terms.reference_principal, D(50))
        self.assertEqual(resized.seasoned_state.opening_accrued_interest, D(".73"))
        row, = ContractualCashflowEngine(FlatRateProvider({})).generate(resized)
        self.assertEqual(row.cash_interest, D("1.52"))

    def test_verified_seasoned_buy_is_admitted_without_restarting_contract_at_settlement(self):
        from trident.analysis.models import AssetExposure
        from trident.optimization import AssetDescriptor, AssetKind, TradeQuote, TradeSide
        from trident.optimization.universe import (
            CandidateAdmissionPolicy, CandidateAssetSnapshot, CandidateCreditStatus,
            CandidateUniverseSnapshot, CandidateUniverseValidator, PriceObservation,
            PriceSide, QuoteQuality, RatingLevel, RatingNature, RatingObservation,
        )
        held = position(floating=True)
        asset = AssetDescriptor("L", AssetKind.BSL, "ISSUER", "GB", "SOFTWARE", D(300), D(2000))
        exposure = AssetExposure("L", "ISSUER", "BSL", "TERM_LOAN", "GB", "SOFTWARE",
            "EUR", D(100), D(300), END, is_senior=True, is_secured=True, is_pik=False,
            is_revolver=False, is_construction=False, test_factor_bucket="TEST_B")
        captured = datetime(2026, 2, 14, 16, tzinfo=timezone.utc)
        rating = RatingObservation("MOODYS", "B2", RatingLevel.FACILITY, RatingNature.PUBLIC,
                                   "FACILITY", date(2026, 2, 1), "VERIFIED_RATING_SOURCE")
        price = PriceObservation(TradeQuote(asset, TradeSide.BUY, D(99), D(100)), PriceSide.ASK,
                                 QuoteQuality.FIRM, captured, ASOF, "FIRM_DEALER_QUOTE")
        candidate = CandidateAssetSnapshot(asset, "FACILITY", "BBG_ID", held, exposure,
            (rating,), (price,), "VERIFIED_TERMS", "VERIFIED_CLASSIFICATION",
            CandidateCreditStatus.PERFORMING)
        snapshot = CandidateUniverseSnapshot("SNAPSHOT", captured, "FROZEN_INPUT", "TEST_FACTORS", (candidate,))
        policy = CandidateAdmissionPolicy(ASOF, timedelta(0), (QuoteQuality.FIRM,))
        admitted = CandidateUniverseValidator().validate(snapshot, policy)
        self.assertEqual(admitted.admitted, (candidate,))
        self.assertEqual(admitted.quarantined, ())
        self.assertEqual(admitted.admitted[0].position.terms.start_date, START)
        settlement = date(2026, 3, 30)
        carried = position(floating=True, asof=settlement, claim=D("1.22"),
            fixing_lag_business_days=2,
            fixings=(OpeningFixing(date(2025, 12, 30), D(".02")),
                     OpeningFixing(settlement, D(".04"))))
        prior_day = datetime(2026, 3, 29, 16, tzinfo=timezone.utc)
        future_observed = replace(candidate, position=carried,
            prices=(replace(price, settlement_date=settlement, observed_at=prior_day),))
        frozen = replace(snapshot, captured_at=prior_day, candidates=(future_observed,))
        rejected = CandidateUniverseValidator().validate(frozen, replace(policy, settlement_date=settlement))
        self.assertEqual(rejected.admitted, ())
        self.assertIn("Opening fixing observation lies after frozen", rejected.quarantined[0].reasons[0])

    def test_full_ownership_what_if_preserves_history_even_if_changed_claim_rounds_same(self):
        from trident.analysis.models import AssetExposure
        from trident.application.clo_services import TridentModelRequest
        from trident.application.scenarios import ScenarioDefinition, ScenarioEdit, ScenarioTarget, _apply_edits
        from trident.application.services import CashflowRunRequest
        from trident.funding.engine import AssetPurchase
        held = position(start=FIRST, asof=date(2026, 5, 15), claim=D("1.47"))
        exposure = AssetExposure("L", "ISSUER", "BSL", "TERM_LOAN", "GB", "SOFTWARE",
                                "EUR", D(100), None, END, coupon_type=CouponType.FIXED,
                                fixed_coupon_rate=D(".12"))
        cash = CashflowRunRequest((held,), (AssetPurchase("L", D(100), D(100)),), (),
                                 FlatRateProvider({}), D(0), D(0), "HAND_CONTROL")
        baseline = TridentModelRequest(cash, (exposure,))
        # A 12.01% historical prefix also posts to 1.47. Cent equality cannot
        # prove that rewriting the original coupon left its exact history intact.
        for field, value in (("fixed_rate", D(".1201")), ("maturity_date", date(2026, 8, 1))):
            with self.subTest(field=field), self.assertRaisesRegex(InputValidationError, "cannot replace historical"):
                _apply_edits(baseline, ScenarioDefinition("REJECT_HISTORY", (
                    ScenarioEdit(ScenarioTarget.ASSET, "L", field, value),)))
        resized = _apply_edits(baseline, ScenarioDefinition("RESIZE", (
            ScenarioEdit(ScenarioTarget.ASSET, "L", "par", D(50)),
            ScenarioEdit(ScenarioTarget.ASSET, "L", "clean_price_pct", D(99)),)))
        self.assertEqual(resized.cashflow_request.positions[0].seasoned_state.opening_accrued_interest, D(".73"))
        self.assertEqual(resized.cashflow_request.purchases[0].clean_price_pct, D(99))


if __name__ == "__main__":
    unittest.main()
