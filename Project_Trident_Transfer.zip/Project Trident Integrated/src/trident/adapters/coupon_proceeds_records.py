"""Transport explicit principal-financed accrued evidence from named inputs.

The Excel boundary parses facts, never estimates a claim from a purchase price,
Bloomberg field or payment-account choice. Economic ownership and actual receipt
validation belong to the application/core, which also own all classification.
"""

from collections.abc import Mapping

from trident.credit.models import AssetCashSource
from trident.domain.models import InputValidationError
from . import excel_schema as schema
from .pilot_schema import COLUMNS
from .records import boolean_value, date_value, decimal_value, text_value


def _registered_row(row: Mapping[str, object], key: str) -> None:
    """Reject misspelled/manual fields instead of silently dropping evidence."""
    unknown = set(row) - set(COLUMNS[key])
    if unknown:
        raise InputValidationError(f"Unregistered {key} fields: {sorted(unknown)}")


def coupon_proceeds_from_records(balance_rows, allocation_rows):
    """Return immutable typed balances and allocations with explicit booleans.

    One-to-one identity and amount reconciliation are part of this bounded input
    profile. The core repeats those invariants for callers that bypass Excel.
    Dates are actual calendar dates; no business-day adjustment is inferred.
    """
    from trident.clo.proceeds import PrincipalAccruedBalance, CouponProceedsAllocation

    balances, allocations = [], []
    for row in balance_rows:
        _registered_row(row, 'principal_accrued_balances')
        balances.append(PrincipalAccruedBalance(
            loan_id=text_value(row.get('loan_id'), 'principal accrued loan_id'),
            as_of_date=date_value(row.get('as_of_date'), 'principal accrued as_of_date'),
            amount=decimal_value(row.get('amount'), 'principal accrued amount'),
            source=text_value(row.get('source'), 'principal accrued source'),
            legal_reference=text_value(row.get('legal_reference'), 'principal accrued legal_reference')))
    for row in allocation_rows:
        _registered_row(row, 'coupon_proceeds_allocations')
        value = text_value(row.get('collection_source'), 'allocation collection_source')
        if value not in {AssetCashSource.SCHEDULED.value, AssetCashSource.PREPAYMENT.value}:
            raise InputValidationError('Proceeds allocation collection_source must be SCHEDULED or PREPAYMENT')
        allocations.append(CouponProceedsAllocation(
            allocation_id=text_value(row.get('allocation_id'), 'proceeds allocation_id'),
            loan_id=text_value(row.get('loan_id'), 'proceeds allocation loan_id'),
            payment_date=date_value(row.get('payment_date'), 'proceeds allocation payment_date'),
            collection_source=AssetCashSource(value),
            principal_amount=decimal_value(row.get('principal_amount'), 'proceeds principal_amount'),
            original_principal_permission=boolean_value(row.get('original_principal_permission'),
                                                       'original_principal_permission'),
            source=text_value(row.get('source'), 'proceeds allocation source'),
            legal_reference=text_value(row.get('legal_reference'), 'proceeds allocation legal_reference')))
    balance_ids = [row.loan_id for row in balances]
    allocation_loans = [row.loan_id for row in allocations]
    if len(set(balance_ids)) != len(balance_ids) or len(set(allocation_loans)) != len(allocation_loans):
        raise InputValidationError('Principal accrued requires one balance and one allocation per loan')
    if len({row.allocation_id for row in allocations}) != len(allocations):
        raise InputValidationError('Proceeds allocation_id must be unique')
    if set(balance_ids) != set(allocation_loans):
        raise InputValidationError('Principal accrued balances and proceeds allocations must identify the same loans')
    amounts = {row.loan_id: row.amount for row in balances}
    if any(row.principal_amount != amounts[row.loan_id] for row in allocations):
        raise InputValidationError('Proceeds allocation must restore the full matching principal accrued balance')
    return tuple(balances), tuple(allocations)


def coupon_proceeds_from_workbook(adapter, controls):
    """Read named tables and reject incompatible workflow switches early.

    The closing optimization and what-if modules resize/rebuild holdings. They
    do not yet carry this historical financed claim through those operations,
    so active evidence must not silently survive a redesigned collateral pool.
    """
    rows = tuple(adapter.table_records(schema.TABLE_RANGE_NAMES[key], schema.TABLE_NAMES[key])
                 for key in ('principal_accrued_balances', 'coupon_proceeds_allocations'))
    if any(rows):
        if controls['mode'] != 'CLO_BASELINE':
            raise InputValidationError('Proceeds allocations require CLO_BASELINE mode')
        if any(boolean_value(controls[key], key) for key in (
                'scenario_enabled', 'optimizer_enabled', 'candidate_search_enabled')):
            raise InputValidationError('Proceeds allocations require Scenario, Optimizer and Candidate Search disabled')
    return coupon_proceeds_from_records(*rows)
