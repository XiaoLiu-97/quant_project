"""Deployment diagnostics must expose failures and respect optional profiles.

The live package probes check independent financial/solver answers. Fault
injection verifies that a missing optional dependency produces a complete
report and a failing exit code, rather than aborting before useful diagnostics.
"""

from contextlib import redirect_stdout
import importlib.util
from io import StringIO
import json
from pathlib import Path
import unittest
from unittest.mock import patch


ROOT = Path(__file__).resolve().parents[1]
SPEC = importlib.util.spec_from_file_location("trident_environment_tool", ROOT / "scripts/check_environment.py")
environment = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(environment)


class EnvironmentCheckTests(unittest.TestCase):
    def test_core_has_an_independent_cashflow_known_answer(self):
        report = environment.check_environment("core")
        self.assertEqual(report["status"], "PASS")
        self.assertEqual([row["check"] for row in report["checks"]], ["python", "core_known_answer"])
        self.assertEqual(report["checks"][1]["detail"]["interest_eur"], "3.00")
        self.assertEqual(report["checks"][1]["detail"]["principal_eur"], "100.00")

    def test_core_does_not_import_optional_packages(self):
        with patch.object(environment, "_package_version", side_effect=AssertionError("Optional import")):
            self.assertEqual(environment.check_environment("core")["status"], "PASS")

    def test_model_runs_excel_and_both_native_solvers(self):
        report = environment.check_environment("model")
        self.assertEqual(report["status"], "PASS", report)
        checks = {row["check"]: row for row in report["checks"]}
        self.assertTrue(checks["named_excel_roundtrip"]["detail"]["named_range_roundtrip"])
        self.assertEqual(checks["highs_lp_milp"]["detail"], {"highs_dual_simplex_x": 1.5, "highs_milp_x": 2.0})
        self.assertNotIn("reportlab", checks)

    def test_missing_package_reports_other_components_and_skips_its_probe(self):
        def package(name):
            if name == "numpy":
                raise ModuleNotFoundError("No module named numpy")
            return environment.TESTED_VERSIONS[name]

        with patch.object(environment, "_package_version", side_effect=package), \
                patch.object(environment, "_probe_excel", return_value={"named_range_roundtrip": True}), \
                patch.object(environment, "_probe_optimization", side_effect=AssertionError("Missing NumPy")):
            report = environment.check_environment("model")
        self.assertEqual(report["status"], "FAIL")
        checks = {row["check"]: row for row in report["checks"]}
        self.assertEqual(checks["numpy"]["status"], "FAIL")
        self.assertIn("ModuleNotFoundError", checks["numpy"]["error"])
        self.assertEqual(checks["scipy"]["status"], "PASS")
        self.assertIn("named_excel_roundtrip", checks)
        self.assertNotIn("highs_lp_milp", checks)

    def test_solver_failure_fails_the_environment(self):
        with patch.object(environment, "_package_version", side_effect=lambda name: environment.TESTED_VERSIONS[name]), \
                patch.object(environment, "_probe_excel", return_value={}), \
                patch.object(environment, "_probe_optimization", side_effect=OSError("Native DLL missing")):
            report = environment.check_environment("model")
        self.assertEqual(report["status"], "FAIL")
        self.assertIn("Native DLL missing", report["checks"][-1]["error"])

    def test_different_supported_version_is_a_warning(self):
        with patch.object(environment, "_package_version", return_value="3.1.4"), \
                patch.object(environment, "_probe_excel", return_value={}):
            report = environment.check_environment("excel")
        self.assertEqual(report["status"], "PASS")
        self.assertTrue(any("differs from tested" in text for text in report["warnings"]))

    def test_unsupported_version_is_rejected(self):
        with patch.object(environment, "import_module"), patch.object(environment.metadata, "version", return_value="4.0.0"):
            with self.assertRaisesRegex(ValueError, "outside supported range"):
                environment._package_version("openpyxl")

    def test_python_below_declared_minimum_is_rejected(self):
        with patch.object(environment.sys, "version_info", (3, 10, 9)), \
                patch.object(environment, "_probe_core", return_value={}):
            report = environment.check_environment("core")
        self.assertEqual(report["status"], "FAIL")
        self.assertIn("requires Python >=3.11", report["checks"][0]["error"])

    def test_bad_profile_does_not_guess_a_default(self):
        with self.assertRaisesRegex(ValueError, "Unknown environment profile"):
            environment.check_environment("optimisation")

    def test_cli_failure_returns_two_and_machine_readable_json(self):
        output = StringIO()
        with patch.object(environment, "check_environment", return_value={"status": "FAIL"}), redirect_stdout(output):
            code = environment.main(["--profile", "core"])
        self.assertEqual(code, 2)
        self.assertEqual(json.loads(output.getvalue()), {"status": "FAIL"})


if __name__ == "__main__":
    unittest.main()
