"""Immutable financial inputs and outputs."""
