# 静态优化与 finite closing replay

版本 `0.12.0`，compact interface `1.0`。首个可用版本支持当前 snapshot 的静态研究及有限 closing candidate 的完整 replay；不求动态 lifetime trading optimum，不自动成交。

## 两个路径

| 路径 | 实际计算 | 结果含义 |
| --- | --- | --- |
| StaticTradeOptimizer | 固定 target par 下的 factor 或 quoted-spread proxy；现金、tickets 和已支持 mandate | 当前组合研究 proposal，`STATIC_NOT_REPLAYED_NOT_EXECUTED` |
| ClosingPoolSearchService | 对有限 proposal/structuring variants 构建 closing pool、capital 与 funding，再完整 CLO replay | 仅本次 validated candidates 内的 return ranking；不是全局 IRR 最优 |

当前 compact reader 要求 static optimizer 与 finite candidate search 二选一，同时启用会明确拒绝。

Existing CLO 可以做静态研究；完整 forward what-if 由 `StaticOpeningScenarioService` 提供。静态 Existing BUY/SELL proposal 不自动变成 projected trade IRR。执行或 replay 该交易需要明确的 post-settlement 账户、accrued ownership/receivables、买入 loan 的 seasoned state/fixings、保留/出售的 claims 和 whole equity value，不能从 quote 或历史 closing funding 推测。

## 输入与所有权

共同 Asset Library 提供合同与分析 metadata。Collateral Pool 提供当前持仓、deal-specific classification 和 mark。Trade Universe 提供 sourced bid/ask、有效 size、settlement、accrued、fees、minimum ticket 和 lot；Optimization 提供 target par、budget、objective 和 constraints。

未知或缺失 quote、factor、rating selection、cash permission 和合同参数不由 solver 创建。启用 `optimizer_enabled` 运行静态路径；启用 `candidate_search_enabled` 选择 closing finite replay 路径。Reader 和 application 先校验 profile；closing search 不用于 Existing opening。

## 固定分母的目标

设当前持仓 face 为 `h_i`、buy face 为 `b_i`、sell face 为 `s_i`，candidate face 为 `q_i=h_i+b_i-s_i`。静态模型要求 target par `P>0` 固定：

```text
Σ q_i = P
mean factor = Σ(q_i × factor_i) / P
quoted-spread proxy = Σ(q_i × spread_i) / P
```

固定正分母使该目标为线性目标。BSL factor 使用自己的 BSL-only 分母和对应约束；不能把 Whole factor 的分母偷偷换成 BSL par。真实 coupon scope 的 WAS/WAC 由 PortfolioAnalyzer 独立计算。静态 descriptor 的全 par quoted-spread proxy 不等于 mixed fixed/floating portfolio 的 floating-only WAS，也不是实际收款 coupon yield。

Synthetic TEST coefficients、agency rating factors 与 true agency WARF 分别标识。Mapping 非空和 source 非空不证明 agency calibration。

## 现金预算与成本

Buy 和 sell 用各自 bid/ask，而非隐含 mid-price。Price 是每100 face 的 price points，accrued 与 proportional fees 是每EUR1 face 的金额，fixed BUY/SELL fee 是货币金额。手续费不能因 ticket 数变化而被重复计算或漏掉。

静态 budget、closing equity funding 和 forward whole equity value 为不同概念。Closing replay 通过真实 Sources & Uses 重算 equity 出资；Existing forward return 从明确的当前 equity mark 开始。不能只用 collateral face 减 debt nominal 当作投资成本，也不能把 static proxy objective 当作 investor IRR。

## LP、MILP 与 cent reconciliation

连续交易量和线性限额可形成 LP。Minimum ticket、lot size、trade count、固定费用及其他离散条件需要 integer/binary decisions，即 MILP。求解器用浮点数；金融账本仍按规定 posting 到 cent。

浮点 solver success 不是最终 acceptance。方案转换为货币金额后，独立 exact verifier 重新检查持仓、预算、target par、bounds、tickets 和 mandate。对 cent rounding 后不可行的方案，模型保留失败原因，不以放宽 limit 或展示四舍五入值掩盖。运行环境的小型 LP/MILP known answers 只验证 solver 安装，不代替 portfolio/model regression。

## 完整 closing replay

1. 明确有限 candidate set、mandate 和结构 variants。
2. 读取共同资产与来源，校验 quote、合同、schedule、coupon steps、ratings 和必要的 eligibility metadata。
3. 按同一 immutable baseline 构建 target pool 与 capital，独立重算 funding。
4. 计算资产 reference、actual credit receipts、完整 waterfall、equity cash 和 dated portfolio observations。
5. 校验 admission findings、适用 limits、cash/claim bridges 和 return completeness。
6. 仅 validated replay 进入 ranking；被拒绝的 replay 记录用于审阅，不声明最优或通过。

当前 source/profile 不支持的 claim rebinding 或 acquisition history 明确拒绝。相同完整 typed request 可在本次 run 中复用 projection；不同 market、price、fee、credit、curve 或 contract 不能共享旧结果。Cache 不跨输入变化自动复用。

## What-if、reinvestment 与动态策略

完整 closing 或 supported Existing what-if 均独立从 BASELINE 建立；case 之间不累积 edits。Opening 的已有 asset/note face resize 必须同时声明 whole `forward_equity_value` 与 `equity_value_source`，保持明确的账户、claims 和原 dates。

Synthetic reinvestment 按 explicit policy 在允许的 payment date 使用有 permission 的真实 cash，按明确 price/WAL/spread/credit template 生成 future cohorts。这是预测假设，不是寻找未来真实 asset、dealer execution 或动态交易策略。静态优化与该 reinvestment assumption 足以支持首个版本的研究流程；模型没有声称 lifetime optimal trading。

## 缺失值与适用性

`LimitSpec` 是分析与 applicability 的定义，不自动生成所有 solver constraints。只有明确映射的线性/discrete rules 进入静态约束；其他 limits 在完整 portfolio/CLO replay 中验证。需要 future receipts、OC/IC、coverage cure、default/recovery或非线性收益的规则，不能靠当前 spread/factor coefficient 证明。

缺失 metric、未到达的 junior gate、empty denominator 和不完整 terminal return 保留明确 status。`UNAVAILABLE`、`BLOCKED` 或 `NOT_APPLICABLE` 不转换成0、PASS或有效 ranking score。Status-aware delta 仅在 Base 与 Proposed 都可比时计算。

## 阅读与验证

在 Trades & Comparison 查看 proposed trades、Base/Proposed/Delta 和 proposal status；在 Waterfall、CLO Analysis 和隐藏 `_Results` 查看完整 case、dated metrics 与 findings。不要只看 headline IRR、solver objective 或 average factor。

实现入口：[optimization](../../src/trident/optimization/models.py)、[static engine](../../src/trident/optimization/linear.py)、[construction](../../src/trident/application/construction.py)、[candidate search](../../src/trident/application/candidate_search.py)、[interface reader](../../src/trident/adapters/interface_inputs.py)。实际测试和工作簿验收见 [readiness](../readiness.md) 与其绑定记录；使用流程见 [用户指南](../user_guide.md)、[计算流程图](../calculation_flowcharts.md) 和 [部署](../deployment.md)。
