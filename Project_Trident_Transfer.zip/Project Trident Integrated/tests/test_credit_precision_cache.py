"""Independent rounding and isolation cases for the financial review increment.

The alternate hazard oracle uses Decimal.power, not the engine's certified
ln/exp interval algorithm. Its examples are far from a half-cent boundary;
exact rational hand cases separately cover monetary ties.
"""

from datetime import date
from decimal import Context, Decimal, Inexact, ROUND_HALF_UP, localcontext
from fractions import Fraction
import unittest

from trident.credit.stress_rates import _probability_bounds, conditional_period_probability
from trident.credit.models import AssetCashSource
from trident.credit.overlay import OverlayCollection, OverlayParMovement
from trident.clo.engine import DeterministicCloEngine, _PerformingParTimeline


class CachedHazardBoundsTests(unittest.TestCase):
    def setUp(self) -> None:
        _probability_bounds.cache_clear()
        self.addCleanup(_probability_bounds.cache_clear)

    def test_reused_bounds_still_post_each_exposure_independently(self) -> None:
        probability = conditional_period_probability(
            Decimal("0.03"), date(2026, 1, 1), date(2026, 4, 2),
        )
        exposures = (Decimal("10000000.00"), Decimal("10001499.00"), Decimal("0.05"))
        with localcontext(Context(prec=100)) as context:
            independently_computed = Decimal(1) - context.power(
                Decimal("0.97"), Decimal(91) / Decimal(365),
            )
            expected = tuple(
                (par * independently_computed).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)
                for par in exposures
            )
        self.assertEqual(tuple(probability.apply_to_par(par) for par in exposures), expected)
        self.assertEqual(expected[:2], (Decimal("75651.78"), Decimal("75663.12")))
        # Exposures with matching required precision share the transcendental
        # result, without sharing their posted monetary default amount.
        self.assertGreaterEqual(_probability_bounds.cache_info().hits, 1)

    def test_exact_half_cent_survives_warm_cache(self) -> None:
        probability = conditional_period_probability(
            Decimal("0.5"), date(2026, 1, 1), date(2027, 1, 1),
        )
        self.assertEqual(probability.apply_to_par(Decimal("100.00")), Decimal("50.00"))
        self.assertEqual(probability.apply_to_par(Decimal("0.01")), Decimal("0.01"))
        self.assertEqual(probability.apply_to_par(Decimal("0.03")), Decimal("0.02"))

    def test_callers_decimal_context_does_not_affect_cached_or_new_bounds(self) -> None:
        probability = conditional_period_probability(
            Decimal("0.03"), date(2026, 1, 1), date(2026, 4, 2),
        )
        expected = probability.apply_to_par(Decimal("10000000.00"))
        for precision in (2, 7):
            with self.subTest(precision=precision), localcontext(Context(prec=precision)) as context:
                context.traps[Inexact] = True
                self.assertEqual(probability.apply_to_par(Decimal("10000000.00")), expected)
                _probability_bounds.cache_clear()
                self.assertEqual(probability.apply_to_par(Decimal("10000000.00")), expected)

    def test_cache_key_keeps_hazard_and_precision_scenarios_isolated(self) -> None:
        first = _probability_bounds(Decimal("0.03"), Fraction(91, 365), 100)
        second = _probability_bounds(Decimal("0.06"), Fraction(91, 365), 100)
        longer = _probability_bounds(Decimal("0.03"), Fraction(182, 365), 100)
        self.assertLess(first[1], second[0])
        self.assertLess(first[1], longer[0])
        tighter = _probability_bounds(Decimal("0.03"), Fraction(91, 365), 200)
        self.assertLessEqual(first[0], tighter[0])
        self.assertGreaterEqual(first[1], tighter[1])

    def test_cache_has_bounded_cardinality(self) -> None:
        # A run may use many timing intervals. Only 128 mathematical tuples are
        # retained, so unlike a per-asset ledger cache it cannot grow forever.
        for day in range(1, 150):
            _probability_bounds(Decimal("0.5"), Fraction(day), 80)
        information = _probability_bounds.cache_info()
        self.assertEqual(information.maxsize, 128)
        self.assertEqual(information.currsize, 128)


class NormalizedCreditStreamTests(unittest.TestCase):
    def test_cash_is_not_inferred_from_default_or_recovery_face_changes(self) -> None:
        # Hand case: 100 face defaults by 20; 10 is recovered and 10 lost.
        # The surviving 80 repays at maturity with a 4 coupon. Thus principal
        # cash is 90, total interest is 4, and final performing/defaulted face 0.
        zero, twenty, eighty = Decimal("0"), Decimal("20"), Decimal("80")
        default_date, workout_date, maturity = date(2026, 1, 20), date(2026, 2, 20), date(2026, 3, 20)
        movements = (
            OverlayParMovement("L", default_date, AssetCashSource.DEFAULT, Decimal("100"), eighty, zero, twenty, zero, zero),
            OverlayParMovement("L", workout_date, AssetCashSource.RECOVERY, eighty, eighty, twenty, Decimal("10"), Decimal("10"), zero),
            OverlayParMovement("L", workout_date, AssetCashSource.WRITE_OFF, eighty, eighty, Decimal("10"), zero, zero, Decimal("10")),
            OverlayParMovement("L", maturity, AssetCashSource.SCHEDULED, eighty, zero, zero, zero, eighty, zero),
        )
        collections = (
            OverlayCollection("L", "EUR", workout_date, AssetCashSource.RECOVERY, zero, Decimal("10"), Decimal("10")),
            OverlayCollection("L", "EUR", maturity, AssetCashSource.SCHEDULED, Decimal("4"), eighty, Decimal("84")),
        )
        normalized, performing_reductions, default_reductions, trace, overlay = (
            DeterministicCloEngine._normalize_projection_stream(collections, movements, None)
        )
        self.assertIsNone(overlay)
        self.assertEqual(trace, movements)
        self.assertEqual(sum(row.principal_repayment for row in normalized), Decimal("90"))
        self.assertEqual(sum(row.cash_interest for row in normalized), Decimal("4"))
        performing = _PerformingParTimeline(date(2026, 1, 1), Decimal("100"), performing_reductions)
        defaulted = _PerformingParTimeline(date(2026, 1, 1), zero, default_reductions)
        self.assertEqual(performing.balance_at(default_date), eighty)
        self.assertEqual(defaulted.balance_at(default_date), twenty)
        self.assertEqual(defaulted.balance_at(workout_date), zero)
        self.assertEqual(performing.balance_at(maturity), zero)


if __name__ == "__main__":
    unittest.main()
