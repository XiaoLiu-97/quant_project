"""Workflow-based presentation groups, independent of source cell positions.

This registry is authoring metadata only. The financial adapter still resolves
stable names, so regrouping or relocating controls does not change economics.
"""
from dataclasses import dataclass
from types import MappingProxyType

from .legacy_inputs import LEGACY_ASSUMPTIONS


@dataclass(frozen=True, slots=True)
class AssumptionGroup:
    title: str
    field_ids: tuple[str, ...]


LEGACY_ASSUMPTION_GROUPS = (
    AssumptionGroup("1. Deal and payment schedule", (
        "base_currency", "clo_size", "opening_collateral_par", "pricing_date", "closing_date",
        "first_note_payment_date", "maturity_date", "payment_frequency", "payment_date_convention", "payment_calendar")),
    AssumptionGroup("2. Acquisition, closing costs and funding", (
        "collateral_purchase_price", "purchased_accrued_interest", "initial_reserve_funding", "other_initial_uses",
        "other_initial_sources", "upfront_arrangement_fee", "rating_agency_initial_fees", "legal_documentation",
        "trustee_administrator_issuer_setup", "listing_clearing", "accounting_audit_tax_setup", "warehouse_financing_unwind",
        "hedge_fx_setup", "other_upfront_costs", "total_other_upfront_costs", "total_upfront_fees_closing_costs")),
    AssumptionGroup("3. Collateral cashflow input", (
        "collateral_cashflow_input_mode", "simplified_cashflows_include_credit_prepayment_effects", "simplified_pool_opening_performing_par")),
    AssumptionGroup("4. Note rates, fixing and collection cutoff", (
        "reference_curve", "day_count", "liability_reference_floor", "rate_fixing_lag", "fixing_calendar", "fixing_date_anchor",
        "first_stub_rate_method", "first_stub_rate_override", "determination_lag", "determination_calendar")),
    AssumptionGroup("5. Collection cash-account earnings", (
        "cash_accrual_curve", "cash_account_spread", "cash_account_rate_floor")),
    AssumptionGroup("6. Management fees and recurring expenses", (
        "senior_management_fee", "subordinated_management_fee", "fee_base", "trustee_paying_agent_administrator",
        "collateral_administration_account_bank", "rating_agency_surveillance", "legal_advisory", "audit_accounting_tax",
        "listing_regulatory_reporting", "other_recurring_senior_expenses", "total_fixed_senior_expenses",
        "expected_senior_expenses_variable", "senior_expense_cap_fixed", "senior_expense_cap_variable")),
    AssumptionGroup("7. Incentive management fee", (
        "incentive_management_fee_enabled", "incentive_fee_rate", "equity_irr_hurdle")),
    AssumptionGroup("8. Original-pool defaults, prepayments and recoveries", (
        "credit_prepayment_overlay", "original_annual_default_rate", "original_collateral_cpr", "default_timing_pattern",
        "original_recovery_rate", "original_recovery_lag_months")),
    AssumptionGroup("9. Reinvestment and new-cohort assumptions", (
        "reinvestment_enabled", "reinvestment_end_date", "reinvestment_test_gate", "recycle_reinvestment_principal",
        "reinvestment_reference_curve", "reinvestment_asset_reference_floor", "reinvestment_asset_spread",
        "reinvestment_purchase_price", "reinvestment_wal", "reinvestment_annual_prepayment_rate", "reinvestment_annual_default_rate",
        "reinvestment_recovery_rate", "reinvestment_recovery_lag_months")),
    AssumptionGroup("10. Coverage tests, adjusted OC and principal waterfall", (
        "oc_ic_tests", "interest_diversion", "principal_waterfall", "include_principal_cash_in_oc", "use_asset_level_test_data",
        "ccc_fraction", "ccc_limit_fraction", "ccc_valuation_fraction", "discount_obligation_fraction",
        "discount_obligation_valuation_fraction", "discount_obligation_price_threshold", "defaulted_asset_valuation_fraction",
        "long_dated_oc_valuation_fraction")),
    AssumptionGroup("11. Note interest shortfalls", (
        "interest_shortfall_carry", "shortfall_accrual_method")),
    AssumptionGroup("12. Collateral quality, concentration and eligibility", (
        "minimum_collateral_was", "minimum_collateral_warr", "maximum_collateral_wal", "maximum_portfolio_warf",
        "maximum_single_obligor", "maximum_industry", "allow_long_dated_assets", "long_dated_asset_limit_fraction")),
    AssumptionGroup("13. Calls, refinancing and final sale", (
        "optional_call_enabled", "call_date", "call_collateral_sale_price", "call_costs_of_debt_fraction",
        "refinancing_enabled", "refinancing_date", "refi_spread_reduction", "refi_fee_of_debt_fraction", "maturity_liquidation_fraction")),
)
_grouped = tuple(identifier for group in LEGACY_ASSUMPTION_GROUPS for identifier in group.field_ids)
if len(_grouped) != len(set(_grouped)) or set(_grouped) != {field.field_id for field in LEGACY_ASSUMPTIONS}:
    raise RuntimeError("Presentation groups must cover every legacy assumption exactly once")
ASSUMPTION_GROUP_BY_FIELD = MappingProxyType({identifier: group.title for group in LEGACY_ASSUMPTION_GROUPS for identifier in group.field_ids})
