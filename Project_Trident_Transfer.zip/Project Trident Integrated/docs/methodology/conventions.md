# Contractual cashflows、市场约定及输入方法

更新：2026-10-05。明确合同/市场约定/情景假设；native cash-pay贷款、独立note日历、DF-forward银行收益、外部cash/par桥和opening acquired entitlement有不同职责。历史来源坐标仅用于业务mapping，新模型读写不使用旧cell位置。

## 输入口径与旧模型差异

### 独立 reset 与付款频率

`frequency_months` 决定 cash payment schedule（1/3/6/12）；可选 `reset_frequency_months` 决定浮息 reference grid（1/3/6），EURIBOR tenor 必须匹配 reset frequency。空白或明确等于 payment frequency，沿用 payment 的 stub/anchor；不同频率则从 contract/projection start 独立 anchored roll、采用 SHORT_LAST reset stub。Reset grid 共用当前资产日历、business-day convention、accrual date basis、EOM 与 fixing lag。若 independent grid 的 EOM anchor 不成立，明确拒绝，不猜测新的 roll。Fixed loans 不接受 reset frequency。

每个 cash accrual interval 与 reset grid 求交集。Rate 在原 reset 的 fixing_date 确定并沿用到该 reset interval 结束，即使中间发生一次或多次 coupon payments。以 `[start,end)` 分段：reset 当日开始新利率，到期/提前还款当日不再计息。每段先应用 reference collar、margin、all-in collar；未舍入 factor 为 `Σ(rate_j × exact_DCF(segment_j))`。同日 principal 仍在 coupon 后支付。每笔贷款每个付款日期只做一次 HALF_UP cent posting，不逐段舍入，不复利、不资本化。

Opening分两种明确profile：合同边界开端，或带`SeasonedLoanState`的已核实cash-pay存续持仓。后者保留原start、付款/reset时间轴与原fixing；as-of只截取未来accrual，不能被当作新reset。历史fixing和coupon ownership须明确给出，FULL历史exact claim与future coupon只在receipt边界posting一次。Purchase accrued是funding成本。详见[存续贷款](seasoned_loans.md)。已逾accrual end未收款、未知历史本金、seasoned自动recast和历史steps等profile拒绝；并不建立既有CLO负债/账户开账。

分段日期通过 bisect 找到重叠的 reset periods；grid 每笔贷款只建一次，fixing observations 仅在该贷款投影内缓存。提前合同全偿不查询后续 fixings；projected annuity 明确需要全部未来 factors。Credit replay 使用 immutable `CouponSegment` frozen observations，重新核验 reset dates、fixing、bounds 与本金政策，不重查市场；跨多个 cash periods 沿用的同一个 fixing 必须一致。Mid-period prepayment 累积已完成 segment 加当前 segment 的实际 partial DCF，不能乘 full-period weighted rate。Default 仍不将未付 segment coupon 记为现金；original overlay 的 survivor coupon 使用完整 exact segment factor。

Asset Cashflows 保持现有 named output layout：`fixing_date` 为本 coupon 内**首个活跃 reset 的原 fixing**，可早于本 cash accrual start；`all_in_rate` 为 factor/full-period DCF 的34-digit display，`index_rate` 为同口径 raw index component。多段显示值不是一笔真实 observed fixing，也不进入精确 monetary math。单段保留输入 rate 的全部 digits。Python 的 `LoanCashflow.coupon_segments` 保留全部分段日期、reset/fixing、raw index、spread 与有效 coupon，Excel 暂无逐 segment 明细表。独立 reset calendar/anchor/stub override 与已逾完整accrual end、尚未收取的borrower receivable仍待开发；来源明确的current-period seasoned opening entitlement已支持。

独立例（100 face、30E/360）：季度现金、月度1%/2%/3% reset → interest0.50；季度12% reset、月度现金 → 每月1.00且只查询一次 fixing；半年6% reset、季度现金 → 两季各1.50。月度12%/24%/36% reset 于2月15日提前全偿 → `100×12%/12 + 100×24%×14/360 = 1.93`，不能用季度24%平均得到2.93。三段各0.005未舍入coupon合计0.015只post0.02，不post三个0.01。Annuity 两期 factors .03/.06 → payment53、本金50/50、利息3/3。测试覆盖 EOM/MF/lag、initial/final stub、negative/capped rates、frozen metadata、early payoff及named candidate/CLO路径，见 `tests/test_cashflows_resets.py`。

[SEC credit agreement §2.8(d)](https://www.sec.gov/Archives/edgar/data/1609711/000160971124000082/ex101-53124.htm) 提供超过三个月的 EURIBOR Interest Period 中每三个月付息、并于提前还款付息的合同例，说明 reset period 不等同 cash payment period；它不证明本项目 generic grid 适用于所有贷款。[EMMI](https://www.emmi-benchmarks.eu/benchmarks/euribor/)确认 Euribor 有多种 tenor；本实现限定1M/3M/6M，仍须按实际贷款文件确认日期和条款。与旧 generator 不同，跨付款期的较长 reset 不在每个付款期起点擅自重置。

### Dated fixed coupon / floating spread steps

`CouponStep` 为**新的绝对水平**，不是在上一期加上变化额：fixed_rate 用annual fraction，spread_bps 用bps。每条只有一个有效水平；0与负值是明确条款，不等于缺失。`LoanTerms.coupon_steps` 是按日期严格递增的immutable tuple；Excel Coupon Steps按scope/loan分组排序，但拒绝同日重复、未知asset、wrong coupon type及空/双水平。日期严格满足start < effective_date < maturity；start的level写入base字段，maturity以后没有新的应计。外部generator允许重复行覆盖和无实际应计的旧日期，这些行为不作为当前接口规范。

| Policy | 实际生效规则 | 适用范围 |
| --- | --- | --- |
| ACTUAL_DATE | 从输入calendar date开始，inclusive；将当前accrual切分 | Fixed与floating；默认模型政策，必须由合同确认 |
| PAYMENT_START | 下一个payment accrual start开始；整期用该start之前最新level | Fixed only；保留外部generator的fixed lookup语义 |
| RESET_START | 下一个**original reset start**开始；期间沿用该reset的margin | Floating only；兼容外部generator的reset lookup，保留修正后的carried reset grid |

Step date不自动按BDC移动。必须输入通知、rating delay或amendment已满足后的真实legal effective date；模型不自动推断未来rating-triggered pricing grid，也不将step当作assignment、refinancing或settled trade。Deferred政策下，同一个boundary之前多次step采用最新绝对值，不累加。未配置steps时不能指定deferred policy。

ACTUAL_DATE仅支持可加的ACT/360、ACT/365F、ACT/ACT.ISDA、30E/360。**30/360.ISDA与30U/360.EOM的期内变化明确拒绝**，需使用适用的boundary policy；待合同定义的allocation rule确认后再扩展。独立反例：100face、12%、Jan29–Mar1的Bond Basis原期32/360→1.07，Jan31切分变成(2+31)/360→1.10；US-EOM Jan1–Apr1原期90/360→3.00，Feb28切分变成(57+31)/360→2.93。即使显式step水平不变，也不默许这些unsupported ACTUAL_DATE配置。可支持范围内no-op steps不增加segment。Thirty-day定义核对 [Strata day counts](https://strata.opengamma.io/day_counts/)。

Floating ACTUAL_DATE margin变化保留原reset/fixing和raw observation，不增加provider查询。每片段依次reference bounds→active margin→all-in bounds；fixed则用active fixed level。按opening face乘exact segment factors求和，在最终loan/payment boundary一次HALF_UP到cents。Annuity、partial prepayment、default reference validation与original overlay消费同一frozen segments；公开credit replay重建step policy、日期和bounds，篡改metadata或汇总margin要拒绝。Default的unpaid coupon不变成cash。

Asset Cashflows的spread_bps是以**segment DCF总和**为分母的weighted diagnostic；constant margin保留原值与全部digits。Portfolio WAS/WAC使用snapshot date当前实际生效的raw margin/fixed level，**不使用full-period平均显示值**；原池ordinary/credit/overlay及synthetic-reinvestment组合中的原持仓均更新。Synthetic cohorts用自身template，imported active sources不继承未使用native合同。Static LP/MILP仍是opening quoted-margin proxy；full candidate replay保留全部steps，并检验未来dated WAS/WAC。Closing what-if修改base coupon只改变base，已录入absolute steps保持其原level；目前没有逐条step的Scenario Edits操作。

独立100face、30E/360例：Jan1–Apr1 fixed12%→24%于Feb15实际生效，interest=100×(12%×44+24%×46)/360=4.53；PAYMENT_START当前quarter为3.00。Reference1%、margin300→400bps同日实际生效，interest=1.13；月度RESET_START为1.08，6M reset/3M payment前两quarter各1.00、Jul1才用400bps。All-in cap4.5%逐段作用后为1.06。Feb15提前还款仅计旧level到排除还款日，interest0.49；Feb16为0.50。Two-period annuity factors.03/.06→payment53、本金50/50、利息3/3。Hand regression见`tests/test_cashflows_steps.py`与`tests/test_dated_coupon_analytics.py`。

[Disney 2024 credit agreement §2.06(a)(iii)](https://www.sec.gov/Archives/edgar/data/1744489/000119312524057958/d759203dex102.htm)将interest-period EURIBO与随时间生效的margin区分，§1.01另规定rating delay，§2.13(b)规定actual-day首含末不含。它支持此种date-effective margin政策的存在，不证明所有BSL采用同一policy。External generator的fixed/浮息lookup来源见 原项目 legacy VBA review（历史来源记录）；其按payment restart reset的问题不继承。

Quality观察范围：完整模型按真正生效coupon、performing-par事件、synthetic purchase、phase boundary、closing/付款日及typed API额外日期生成post-event observations。PAYMENT_START/RESET_START复用CouponProjector.effective_change_dates，不重复推算calendar或取得fixing。两付款日间的temporary spread dip现在进入quality rejection。有限日历仍不等于continuous compliance、逐交易前后eligibility或目标交易法律measurement calendar；见[分析方法](analysis.md)。

### 浮息贷款的 reference / all-in 上下限

原始 index observation `I` 不被覆盖。先计算 `R = min(max(I, reference_floor), reference_cap)`，再加 `spread_bps/10000`，最后计算 `coupon = min(max(R + spread, all_in_floor), all_in_cap)`；缺失的端点省略对应 min/max。每个 scope 内 floor 必须不大于 cap；两种 scope 的端点可以交叉，最终 all-in collar 优先。这是合同 coupon transform，不是购买的 cap/floor 衍生品定价或 hedge cashflow。

- Assets / Candidate Assets 的四个 `*_bps` 字段均为年度基点；Python `LoanTerms` 与 Scenario Edits 的四个 bound 则为 annual decimal fraction。500 bps = 0.05。空白/None 禁用，0 是有效条款；不推断 universal zero floor。Fixed loans 拒绝这些字段。
- 本阶段 bounds 是整个投影期间不变的合同条款，按每个 reset/step segment 应用；dated bounds尚未实现。Coupon 使用 opening held face × summed bounded rate/DCF factors，最后 HALF_UP 到 cents。ANNUITY 使用相同 exact factors。
- Native credit replay 重新核验合同 bound；mid-period prepayment 使用相同有效 coupon 和实际 partial DCF，default 的未付 coupon 不变成现金。Original hazard overlay 消费相同 contractual coupon。Synthetic reinvestment cohorts 使用其独立 reinvestment terms，不自动继承原贷款 collar。
- Bounds 改变实际 coupon、IC、waterfall 和 equity IRR；通用 WAS 仍是 raw contractual floating spread 的 par-weighted average，不声称包含某份 indenture 的 floor benefit 或 cap-adjusted spread。Static spread objective 也仍是 proposal 指标，真正回报由 full CLO replay 判定。
- 同一个资产的一组 what-if bounds 一次性校验最终状态，不依赖 edit 的排列顺序。成功的 workbook writeback 会按 named Table metadata 增加缺失的三个可选列；保存已有输入值，遇到相邻内容/其他命名区冲突则明确报错，并保留磁盘原文件。内部 legacy adapter 的 schema 0.7 optional-column contract 保持兼容；当前 compact 用户界面使用 schema 1.0，由已登记 Table headers 与 named owners 读取。内部兼容规则不要求用户使用旧工作簿。

独立例：100 face、30E/360 季度，index10%、reference cap5%、margin4%、all-in cap8% → coupon2.00；改为 all-in floor10% → coupon2.50。8% coupon 在一个月后提前全偿，应计现金为0.67。100 face 两期、季度有效利率1%的 projected annuity，payment=100×1.01²/(1+1.01)，分期本金49.75/50.25、利息1.00/0.50。候选资产10000 face、all-in cap1%、90/360产生25利息，即使 raw spread 是800bps，完整候选重放也不能仍使用200利息。回归见 `tests/test_coupon_bounds.py`、named adapter/Excel/candidate tests。

[MKS 的 SEC debt disclosure](https://www.sec.gov/Archives/edgar/data/1049502/000119312526066820/R24.htm) 提供 EURIBOR 0% reference floor 加独立2.50% margin 的实际合同示例；该来源不证明本模型所有 cap 条款或全市场通用顺序。两层 collar 次序来自用户提供的 generator 业务语义、并用上述独立算例核验；生产输入必须由具体合同确认。

### 自动本金校准：LINEAR_AUTO / ACCELERATED_AUTO

这两项为明确的建模指令，不自动推断已签贷款允许在当前时点重新设定合同分期金额。若有真实 scheduled repayments，应采用显式金额或 BESPOKE。校准输入为 held opening par `P`、显式 `balloon_amount=B`（包括 0）、eligible principal dates 数目 `n`；reference/original facility size 不进入自动公式。Grace 之前本金为零、利息付现；maturity 包含在 eligible dates 内。

- LINEAR_AUTO：未舍入 regular principal 为 `(P-B)/n`。
- ACCELERATED_AUTO：growth `g` 为每个 eligible installment 的非负小数增长率；`m=1+g`，首笔 `a=(P-B)/(1+m+...+m^(n-1))`，第 k 笔为 `a*m^(k-1)`。`g=1` 表示翻倍；旧 multiplier 应先减 1，不能直接填 growth。`g=0` 严格等同自动线性。
- AUTO 不接受同时填写 `scheduled_principal_amount`；ACCELERATED_AUTO 必须明确 growth，不能将 blank 当作 0。所有金额为货币单位、balloon 不超过 held par。
- 使用精确 Fraction，无 coupon projection 或数值 root search。每期 HALF_UP 到 cents；非末期不能侵入 balloon，末期支付 remaining par（最后 regular principal、balloon 和 rounding adjustment）。若 cents 导致非末期全偿还则拒绝，不静默改变到期日。
- Numeric budget：`n * max(bit_length(m.numerator), bit_length(m.denominator)) <= 500000`（g>0）。超过时明确拒绝病态精确整数输入，不切换近似算法；这是工程资源边界，不是金融条款。

独立已知答案：EUR10m/四期/零 balloon 为每期 EUR2.5m；EUR15m/四期/growth=1 为 EUR1m、2m、4m、8m；EUR100/三期/零 balloon 为 33.33、33.33、33.34；EUR100/首期 grace/其后两期/balloon20 为 0、40、60。测试另覆盖 held/reference 差异、低精度 Decimal context、极端 growth、非法输入及 named Excel 路径。

[SEC credit agreement §2.10](https://www.sec.gov/Archives/edgar/data/1322439/000162828022005984/a400mcreditagreementfinal.htm) 提供 scheduled installments 加 maturity remaining principal 的合同例。自动校准方式取自外部 generator 的业务需求、以等额/几何级数独立推导；该合同不证明所有 BSL 都采用自动或几何摊还。实现见 `cashflows/principal.py`，独立回归见 `tests/test_cashflows_calibration.py`。

`trident.adapters.legacy_inputs` 提供不可变 `LEGACY_ASSUMPTIONS` 110 项，其中 `LEGACY_INPUTS` 107 个输入、`LEGACY_DERIVED` 3 个汇总显示值（旧 B33/B53/B54）。每项保存稳定语义 ID、原标签、类型、单位、原始默认值、有效 choices、原工作簿实际 DataValidation 公式及注释。源坐标仅为证据；新业务读写通过 named ranges，不用原 B 列位置识别参数。重复的 original/reinvestment default/recovery/lag 已拆成不同 ID。历史默认值不自动成为生产假设。

只读打开用户提供的 v4.2.2 工作簿后，发现实际 DataValidation 有错位和重叠：例如 B26（金额）附 Enabled/Disabled；B93（整数 lag）附 TARGET/Weekends Only；B104 同时附 date-convention 和 calendar 值。新模型按金融字段语义和 VBA 验证处理，不复制这些错误。B81 实际下拉为 `Stop on Test Failure,Continue`，但导出的 `modInputs.bas` 只接受 `STOP ON TEST FAILURE,ALWAYS REINVEST`；新 registry 明确接受 Continue/Always Reinvest 两个 alias，并统一为 Continue，由执行政策决定允许 test failure 的 reinvestment。不会静默将拼错的输入当作默认值。

`validate_legacy_controls` 校验完整107项、未知/缺失字段、types、cent 金额、整数 lag、decimal fractions，以及启用事件的日期。关闭的 feature 保留其 typed 参数但不执行事件。`validate_pricing_date` 要求 Pricing Date 等于 Market Data as-of 且不晚于 Closing Date；pricing 与 closing 可以不同。

Equity IRR Hurdle 按旧 VBA 的明确输入范围 `[0,1]` 校验；即使 incentive 关闭或使用 CASHFLOW_ONLY，也拒绝100%以外值。公共 validator 和实际 legacy adapter 使用同一范围，0%/100%边界均可输入；不能等到另一个运行模式构建 CloTerms 才发现非法值。

## 日历、fixing 和 first-stub

| 原输入 | 执行规则 | 关键假设和限制 |
| --- | --- | --- |
| B94/B105/B129 calendars | `CalendarName.TARGET` 或 `WEEKENDS_ONLY`，独立供 fixing、determination、payment 使用 | 旧 VBA 仅支持这两种。Weekends Only 无公共假日，不冒称 London/New York 日历。TARGET 延用有 ECB 来源的现代规则范围与额外 closure 支持 |
| B95 Fixing Date Anchor | PERIOD_START 或 PAYMENT_DATE，由选定 fixing calendar 回退 lag | PAYMENT_DATE 是明确的 in-arrears note 合同选择，可以晚于 accrual start；不因此更改资产 in-advance fixing |
| B106 Selected Reference | 使用所选 tenor 在实际 fixing date 的供给率 | actual historical boundary 仍需要 exact fixing，不用 projected monthly 值冒充 history |
| B106 Interpolate 1M/3M/6M | 从 accrual start 生成真实1M/3M/6M日历到期日，按 accrual end 所在两个 tenor 的实际日数插值 | 改进旧 `days/30.4375` 近似；只插值 reference，之后才应用 floor 和 spread；端点外用1M/6M，须按交易文件复核，>6M 可选 override |
| B106 User Override / B107 | 明确 finite Decimal reference rate，再应用 note floor/margin | Override不是all-in coupon；mode 不使用 override 时非空值明确报错，避免双重输入 |

旧 B11 的 `30/360` 实际源码将两端31日分别截成30，未应用 start-dependent terminal31 或 February-EOM规则；其真实语义是 **30E/360 Eurobond**。迁移到明确的 `DayCount.THIRTY_E_360`，不凭含糊标签误映射到Bond Basis或NASD。Jan29→Mar31的旧源码答案61/360，而Bond Basis是62/360，足以改变coupon。

例：2026-01-31 开始的1M到期2026-02-28，3M到期2026-04-30。若 stub 结束2026-03-31，插值权重为31/61，而非 approximate-month 权重。1%/3% rates 得到 `1% + (3%−1%)×31/61`。原 anchor/date-adjustment 规则仍由共享 ScheduleBuilder 控制。

## ESTR / SOFR / SONIA collection-account projection

旧 Market Data 粘贴区只有 tenor/zero 标签，未给 zero compounding、curve day count。因此需要新增明确的 `ZeroCompounding`（CONTINUOUS / ANNUAL_EFFECTIVE / SIMPLE）和 curve ACT/360或ACT/365F；不得默认猜测。现金 spread/floor 的 account day count 独立于 curve tenor 基准。

```text
continuous zero: DF(t) = exp(−z(t)×t)
annual effective zero: DF(t) = (1+z(t))^(−t)
simple zero: DF(t) = 1/(1+z(t)×t)
projected reference earnings on [s,e] = DF(s)/DF(e) − 1
projected all-in earnings = max(reference earnings + spread×accountDCF,
                               floor×accountDCF)
```

对真实 receipt date 之后的 interval 使用 DF ratio，不能把 `zero(e−s)` 当作 receipt-date deposit rate。节点采用 log-discount-factor 线性插值，隐含 DF(valuation)=1。超范围 ERROR；显式 FLAT 表示延长末端 continuously compounded zero，说明中可见。负 zero 允许正 DF；若 bank policy 无法处理负实际 earnings，waterfall 必须明确拒绝而非将其隐藏为零。

独立例：valuation 为2026-01-01，1年 simple zero10%，2年 simple zero20%，从2027-01-01收款投资至2028-01-01。DF1=1/1.1、DF2=1/1.4，收益 factor=1.4/1.1−1=3/11；EUR100 得 EUR27.27。旧“按一年tenor zero10%”做法会得到EUR10，二者显著不同。50-digit 隔离 Decimal context 用于 log/exp；将有限 DF 转成 Fraction 后做现金计算和cent posting。不能声称超越该数值精度的 arbitrary-boundary认证。

这仍是**投影的 OIS-forward bank remuneration 政策**。实际 €STR compounded index 使用历史日度 rates 及适用日数；单个静态 zero curve 不证明银行实际付息，也不是 daily-observation replay。参照 [ECB compounded €STR calculation rules](https://www.ecb.europa.eu/stats/euro-short-term-rates/interest_rate_benchmarks/WG_euro_risk-free_rates/shared/pdf/ecb.Compounded_euro_short-term_rate_calculation_rules.ro.pdf) 与 [OpenGamma DiscountFactors 官方接口](https://strata.opengamma.io/apidocs/com/opengamma/strata/pricer/DiscountFactors.html)。SOFR/SONIA 可以作为 EUR 账户明确合同的 remuneration benchmark；选择它们不产生 USD/GBP 存款、FX conversion 或 hedging cashflows。

## Detailed / Simplified / Mixed 的外部输入

`trident.adapters.imported_records` 保留旧 Detailed24列/Simplified9列 header aliases，并支持新 named Tables 的 semantic headers。`compile_imported_cashflows` 只生成实际收款与独立 performing-par 账本，不伪造 LoanTerms 或 historical fixing。来源数据、注释、pre-closing排除数量、最终 principal dates 和 source credit flag 保存在 immutable transport。

- Detailed：identified loan、period、begin/end par 和 PIK/principal必须连续；gross=cash+PIK、total cash=cash+principal。PIK是par增加，不是interest现金。外部报价/平均rate不等于已独立验证的资产 coupon math。
- Simplified：若没有 optional reduction/ending par，明确采用 principal=performing-par-reduction；若两者均提供，必须相互对账。不可增加原始aggregate performing par，也不可变负。Defaulted Par/Recovery memo是source信息，不可重复作为cash，也不足以自动造default-claim账本。
- Mixed：detailed identified openings＋simplified subpool opening必须等于总opening collateral par；使用 simplified ending par 时必须提供 B146。Reserved aggregate ID 为 `TRIDENT_SIMPLIFIED_POOL`，不能与实际贷款ID冲突。缺失评级/行业/合同WAL的 aggregate metric保持unavailable，不用虚构metadata补齐。
- Pre-closing receipts 不进入模型；opening par已经是 closing snapshot。Post-legal-final future rows保留给long-dated诊断/处置政策，不能先删除再声称池已归零。
- Already-stressed flag与再次overlay同时启用明确拒绝。外部流和生成的 contractual流分别有明确来源，不能把同一批资产从两条路径加两次。
- Duplicate simplified receipt dates因 ending-par 顺序不明确而拒绝，用户先合并当日收款和一个balance bridge；detailed可以不同资产同日，但同资产period必须有序唯一。

独立例：opening100，interest5、principal cash20、performing reduction50、ending50。Cash为25、performing par为50、external par/cash difference为30；memo recovery8不会另加cash。Difference不自动标记为realized loss或unrecovered claim，因为外部9列未提供完整 default/recovery ledger。

## Purchased Accrued Interest 的历史 coupon entitlement

旧aggregate B111在合同边界的inherited-claim profile同时代表closing purchase成本和历史coupon claim；这是显式兼容假设。带SeasonedLoanState的资产改由独立ownership政策生成claim，B111/asset accrued只作为funding成本，不能再次附加receipt。`allocate_purchased_accrued` 明确按 opening-par proportions 分配aggregate值，largest-remainder cent posting，tie按loan ID；已有asset-level准确 accrued优先。此分配是可见模型假设，不能代替实际 settlement statement。

`inherited_accrued_collections` 只产生额外历史coupon claim现金：第一次 scheduled coupon 收回；较早 prepayment 时一并收回。Default早于收款时在当前 cash-pay 政策中 forfeits claim；不假设回收missed interest。Scheduled coupon与default同日仍先scheduled现金，保持已有同日政策。它只可追加到**从closing开始生成的未来interest**；已包含full coupon entitlement的外部流不能再加一次。

Partial overlay采用 `inherited_accrued_for_overlay`：默认事件只 forfeits对应slice claim，较早partialprepayment只支付对应比例，首个scheduled coupon收回剩余。EUR10历史claim、opening100、先违约20，再对80余额prepay16：forfeit2，earlyprepay收1.60，coupon收6.40。Cumulative-target cent posting避免多次四舍五入超过原claim。

## 原anchor schedule与day count

五种stub使用同一`ScheduleBuilder`。Final stubs从原始start向前生成，initial stubs从maturity向后生成；显式`first_payment_date`在initial模式下锁定首个nominal boundary与后续regular roll anchor。Long stub把短残余与一个相邻regular period合并，已经整齐对齐的期限不会强行生成long stub。EOM校验regular anchor是否月末，允许initial stub起始日非月末；所有nominal boundaries生成完毕后才做business-day adjustment及payment lag。这符合官方schedule实现对方向、边界和调整分层的描述。[OpenGamma schedules](https://strata.opengamma.io/schedules/)

两项显式日期均为**unadjusted contractual boundaries**，不接受已调整的现金日来代替。`first_payment_date`在NONE/final模式下确认实际生成的首个boundary；`last_regular_payment_date`确认regular section结束，若有final stub则是该stub开始，若无final stub则是maturity。矛盾phase、错误short/long长度、双端stub、无法形成long stub的过短期限明确报错。仅有initial stub而没有regular period时，不接受一个伪造的last-regular date；未来需要更广泛schedule定义时再扩充接口，而不静默推断。

**Stub日期支持与stub coupon convention分开。** Reference tenor 匹配 reset frequency；blank/equal reset frequency 时，沿用 payment grid，在完整 stub 使用一次 selected reference fixing。例如frequency=3且reset空白的五个月LONG_FIRST仍使用EURIBOR3M，加spread按完整stub DCF计息；显式distinct reset frequency则使用独立reset grid逐段计息。当前不按stub长度自动选择新tenor或interpolate asset stub rate。这是显式LoanTerms配置范围，不代表所有BSL的stub coupon约定。真实使用前须核对executed agreement的initial/terminal stub定价及reset条款；日期支持不等于整笔现金流已验证。

Thirty-day accrual先调整日号，再计算以下**精确Fraction**；输入日期仍按[start,end)定义：

\[
\mathrm{DCF}=\frac{360(Y_2-Y_1)+30(M_2-M_1)+D_2'-D_1'}{360}
\]

| 明确输入 | 当前调整规则 | 特意区分的口径 |
| --- | --- | --- |
| `30/360.ISDA` | Start31→30；当adjusted start为30且end为31时，end→30 | 2006 Bond Basis；February没有特殊补长 |
| `30U/360.EOM` | Start为February月末时→30；双方均为February月末时end→30；随后应用上述31日规则 | 固定US February-EOM版本，不读取schedule的`end_of_month`flag |
| `30E/360` | Start/end各自31→30 | 2006 Eurobond；February28/29保留，不是`30E/360.ISDA` |

规则按官方maintainer的明确定义核验；该来源同时标明Bond Basis和Eurobond对应2006 ISDA §4.16(f)/(g)，US fixed-EOM与dynamic-EOM不同。项目不接受含糊`30/360`或`30US/360` alias，不把旧Excel NASD自动当作这些版本。[OpenGamma day counts](https://strata.opengamma.io/day_counts/)

独立已知日数包括：2024-02-29→2024-03-31，US-EOM/Bond/Euro分别30/32/31；2023-02-28→2023-03-31分别30/33/32；2024-01-31→2024-02-29三者均29；February-EOM周年的US版本为360。Zero-length返回0；仅相隔Jan30→Jan31也可有0的synthetic day count，不能用实际日数覆盖定义。`30E/360.ISDA`需要maturity-date例外，当前未实现，也不会用plain Eurobond代替。

## 利率精度与single posting

独立审查发现，原asset/note coupon在固定35/60位Decimal context中计算`base + spread_bps/10000`，可在进入Fraction金额计算之前丢失合法输入尾数。即使spread=0，Decimal的`index + 0`也是受context precision影响的算术操作；后续精确DCF与HALF_UP posting不能恢复已经丢失的rate digits。Python官方文档明确区分精确保留输入digits的Decimal构造与受precision/rounding/traps影响的算术。[Python3.12 Decimal](https://docs.python.org/3.12/library/decimal.html)

独立反例：`index = Decimal("0.001" + "9" * 65)`、par=10、ACT/360的90天、spread=0。该finite rate严格小于0.002，等于`0.002 - 10^-68`；精确interest为`0.005 - 2.5×10^-68`，因此cent HALF_UP应为**0.00**。旧rate composition将它先舍入为0.002，制造exact half-cent并错误记为**0.01**。这是实际可复现的金融计算缺陷；仅把interest乘法改成Fraction仍不足以解决。

纠正实现集中在 [numeric helpers](../../src/trident/domain/numeric.py)：`basis_points_rate`通过finite Decimal coefficient的exponent减4做精确bps转换，避免context-sensitive除法；`compose_floating_rate`先应用index floor，再加margin，用完整operand digits/aligned exponents推导足够precision，并启用Inexact trap防止silent rounding。Asset与note引擎均使用该helper，adapter的floor-bps转换也复用同一函数；最终coupon沿`exact all-in Decimal → Fraction(rate) × Fraction(par) × exact DCF → post_currency`计算。`decimal_fraction`的34位值只用于factor、unrounded-interest与ratio诊断展示，禁止重新作为coupon posting输入。

[Rate precision回归测试](../../tests/test_rate_precision.py)针对positive/negative near-tie、exact/above tie、long-tail index/spread/floor、floor-before-margin、cancellation tails及low-precision caller context，覆盖asset与note coupon；完整验证范围在当前机器记录与综合审查维护，不重复累计focused计数。该保证只精确保留provider实际给出的**finite Decimal**，不声称能恢复上游已经舍入的信息。曲线插值继续遵循provider明确的计算precision；Excel numeric cells/文件传输存在double精度边界，与typed API/Decimal或CSV文字输入分开记录，不能把transport已丢失的65位尾数当作engine可以重建的原始利率。原Market Data核验的`1e-15`rate传输容差仍仅用于该边界，不放宽cent posting答案。

## Cash-pay本金策略与projected annuity

`PrincipalPolicy`与schedule、rate provider和Excel分离。每期按opening posted par先计息，再执行本金策略；standalone amortizing contract已支持非零payment lag，cashdate与accrual-end earning-face roll-forward分开。Eligible amortization period由`unadjusted_end >= amortization_start_date`判断，start必须是projection start或真实nominal accrual boundary，单位是日期而非猜测的“第几期”。Grace期间按明确Cash/PIK/Mixed mode结算coupon，PIK在对应边界增加face；独立off-cycle本金事件尚未实现。Explicit full-exit credit仍要求zero paymentlag，PIK还要求accrualend与cashdate一致；独立的legacy annualoverlay支持nativePIK+lag sourceledger，见[nativecoupon方法](native_coupon_migration.md)与[credit方法](credit.md)。

`LINEAR_INITIAL_PAR`以显式reference principal乘正比例，`LINEAR_AMOUNT`使用显式currency amount。Reference principal不从held opening balance或剩余期数反推。`ACCELERATED`在每个eligible installment按`base×(1+growth)^k`增长，growth非负且必须显式输入（0有效）；amount先精确计算再cent posting，并以可偿本金/balloon floor为上限。对于这些fixedschedule，显式balloon（包括0）是pre-maturity minimum residual floor；maturity必须fullredeem全部remainingface，即使regularinstallments未刚好达到该floor。这与旧generator的finalsweep一致，不拒绝合法under-amortized residual。PIKprofile还先资本化currentPIK再赎回enlargedface。LINEAR_AUTO / ACCELERATED_AUTO及ANNUITY的balloon为calibrationtarget，语义独立，详见前述自动本金规则。

`BESPOKE`只接受unadjusted period-end本金金额，严格总和为**held opening par**，并要求maturity entry（可为0）；未列中间日期本金为0。可指定amortizationstart与pre-maturity balloonfloor，但已填scheduledamount必须与它们一致；grace前nonzeroprincipal、侵入floor、日期不匹配、重复、超额或少额均报错，不偷偷修改明确的amount。Cash-only不把未填差额自动加至maturity；PIK新增加的face则按明确profile在finalredemptionsettle。提前完整还款后停止现金流；仍需保留显式maturityrecord来证明完整schedule输入。

Microsoft PMT提供constant rate、constant P&I、end-period payment的独立reference，并明确P&I不含税、reserve或费用。其8%年息、10个月、10,000本金案例给出每期绝对付款1,037.03。本项目用30E/360 unadjusted整月产生精确`q=0.08/12`，验证首期P&I为1,037.03、interest为66.67，并验证完整本金守恒。[Microsoft PMT](https://support.microsoft.com/en-us/excel/functions/pmt-function)

Varying projected rates/stubs的annuity是项目依据balance recurrence作出的**代数扩展**，不是Microsoft PMT声称支持浮息，也不是所有BSL合同的payment recast约定。令eligible period的`q_t=Σ(segment_rate_j×segment_DCF_j)（单段时为 annual_rate_t×DCF_t）`，N为开始摊还前的held par，B为最后一次level payment后的目标balloon：

\[
b_t=b_{t-1}(1+q_t)-P,\qquad
d_t=\prod_{i=1}^{t}(1+q_i)^{-1},\qquad
P=\frac{N-Bd_n}{\sum_{t=1}^{n}d_t}
\]

精确recurrence由`b_0=N`得到`b_n=B`，B在maturity另行支付。Constant q时归约至ordinary annuity；q=0时为`(N-B)/n`。算法O(n)，使用Fraction保留完整coupon factors与running discount products，无需反复试算或穷举。每个`1+q_t`必须大于0，精确路径不得产生negative principal或侵入balloon。

实际posting采用HALF_UP cents：先把level P&I P舍入为cent；非末期principal等于**posted payment减posted interest**，interest仍按当期posted opening par计算。Maturity支付完整remaining par，因此最终P&I包含balloon及cent-rounding adjustment，不能声称所有最终现金金额仍严格等于level payment。例：零息100分三期为33.33/33.33/33.34；两期q=0.1时，独立方程`100=P/1.1+P/1.1²`给出`P=1210/21`，实际付款57.62/57.62；两期q为0.1/0.2时独立方程给出P=60、本金50/50；B=50、两期q=0.1时付款33.81/83.81。

精确或posted annuityprincipal为负、pre-maturity balloon侵入、cent rounding造成意外提前退休均拒绝。CFPB解释了“payment不足付息、未付息加入principal”的negativeamortization经济含义；本项目Cash-onlyannuity不隐含资本化。明确的PIK/Mixed契约已在独立settlementpolicy中支持，其capitalization与negativecashshortfall是不同原因。这是金融语义参考，不是声称美国mortgage监管规则适用于EUR BSL。[CFPB negative amortization](https://www.consumerfinance.gov/ask-cfpb/what-is-negative-amortization-en-103/)

### 官方 convention 来源状态

- ECB 提供 euro TARGET 关闭日规则：周末、1 月 1 日、Good Friday、Easter Monday、5 月 1 日、12 月 25/26 日。ECB 办公室的其他假日不能全部作为 TARGET 关闭日。[ECB TARGET Information Guide，§2.6](https://www.ecb.europa.eu/paym/target/consolidation/profuse/shared/pdf/2025.APR_p1_fundamentals.en.pdf)
- EMMI 官网列有 **2026-06-29** 的 Euribor methodology 更新。此前找到的 2024 PDF 只能作为历史参考，不能作为“最新方法已经核验”的证据。生产实现前应取得适用版本、实际 fixing 数据及合同 fixing/reset 规则。[EMMI methodology register](https://www.emmi-benchmarks.eu/benchmarks/euribor/methodology/)
- 评级方法、benchmark 文件和交易条款会更新。reference register 必须记录版本与访问日期；来源 unavailable 或 superseded 要在验证状态中说明。
- 资料核查于2026-10-05访问OpenGamma官方day-count/schedule说明、Microsoft PMT与CFPB negative-amortization原始说明；相关来源已读取。ISDA2022 day-count table及FpML calculation-period scheme的搜索内容可访问，但直接页面/PDF当前403；没有据此声称获得完整最新版合同定义。OpenGamma规则核验和独立日数测试保留了这一来源层次，生产前仍以目标executed terms为准。

详细实现路径见 [代码导读](../architecture.md)，typed contract字段和单位见 [用户指南](../user_guide.md)。支持5种stub日期不表示支持任意asset stub rate convention：通用loan仍是明确tenor/一次fixing；note首stub插值和override独立配置。Exact3M端点只查询3M，不读取无用1M或舍入rate尾数。当前验证见 [审查记录](../readiness.md)。
