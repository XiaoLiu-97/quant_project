"""Complete assumption transport and independent small investor cash bridges."""

from dataclasses import replace
from datetime import date
from decimal import Decimal
import unittest

from trident.adapters.excel_schema import INPUT_DEFAULTS
from trident.adapters.legacy_inputs import LEGACY_INPUTS
from trident.adapters.legacy_model_records import (legacy_model_request_from_records, legacy_values,
    CLOSING_COMPONENTS, RECURRING_COMPONENTS)
from trident.adapters.legacy_execution import assumption_execution_records
from trident.application.clo_services import TridentModelService
from trident.conventions import DayCount
from trident.domain.models import InputValidationError
from trident.market import FlatRateProvider
from test_clo_application import _input_data

D = Decimal


def small_inputs(**overrides):
    assets, capital, _, factors, _, provider = _input_data()
    asset = dict(assets[0], loan_id="HAND", obligor_id="HAND_ISSUER", current_par=100,
        initial_par=100, purchase_price_pct=100, maturity_date_unadjusted="2027-05-20",
        amortization_type="BULLET", amortization_fraction_initial_par_per_period=0,
        amortization_periods_remaining=None, amortization_first_date_unadjusted=None,
        spread_bps=400, recovery_rate=D('.4'), recovery_rate_source="EXPLICIT_TEST")
    asset.update(stub_convention="SHORT_LAST",end_of_month=False,payment_lag_business_days=0,acquired_accrued_interest=0)
    debt = dict(capital[0], interest_deferrable=False, nominal_amount=60, issue_price_pct=100, coupon_type="FIXED", fixed_rate=0,
        rate_index=None, spread_bps=0, index_floor_bps=None, oc_minimum=None, ic_minimum=None)
    equity = dict(capital[-1], interest_deferrable=False, nominal_amount=40)
    controls = dict(INPUT_DEFAULTS, schema_version="0.7", valuation_date="2026-08-20", legacy_pricing_date="2026-08-20", mode="CLO_BASELINE",
        legacy_clo_size=100, legacy_opening_collateral_par=100, legacy_maturity_date="2027-08-20",
        legacy_senior_management_fee=0, legacy_subordinated_management_fee=0,
        legacy_collateral_purchase_price=1, legacy_initial_reserve_funding=0,
        legacy_senior_expense_cap_fixed=0, legacy_cash_accrual_curve="EURIBOR 3M",
        legacy_maximum_single_obligor=1, legacy_maximum_industry=1,
        interest_diversion_test_end_date=None)
    for key in (*CLOSING_COMPONENTS, *RECURRING_COMPONENTS):
        controls[f"legacy_{key}"] = 0
    controls.update(overrides)
    return (asset,), (debt,equity), controls, factors, provider


def small_request(**overrides):
    assets, capital, controls, factors, provider = small_inputs(**overrides)
    return legacy_model_request_from_records(assets, capital, provider, controls=controls,
        factors=factors, limits=(), provenance="SYNTHETIC_HAND")


class AssumptionExecutionTests(unittest.TestCase):
    def test_all107_values_required_and_execution_trace_complete(self):
        _,_,controls,_,_=small_inputs()
        self.assertEqual(len(legacy_values(controls)),107)
        records=assumption_execution_records(controls)
        self.assertEqual({row['field_id'] for row in records},{f.field_id for f in LEGACY_INPUTS})
        for field in LEGACY_INPUTS:
            with self.subTest(field=field.field_id):
                missing=dict(controls)
                del missing[f"legacy_{field.field_id}"]
                with self.assertRaises(InputValidationError): legacy_values(missing)

    def test_fraction_and_cent_validation(self):
        for key,value in (("ccc_fraction",1.01),("original_recovery_rate",-.01),
                          ("purchased_accrued_interest",.001),("rate_fixing_lag",-1)):
            with self.subTest(key=key),self.assertRaises(InputValidationError):
                small_request(**{f'legacy_{key}':value})

    def test_economic_identities_checked_and_pricing_snapshot_explicit(self):
        for key,value in (("clo_size",101),("opening_collateral_par",99),("pricing_date","2026-08-19")):
            with self.subTest(key=key),self.assertRaises(InputValidationError):
                small_request(**{f'legacy_{key}':value})

    def test_old_thirty_label_maps_to_actual_eurobond_algorithm(self):
        self.assertIs(small_request(legacy_day_count="30/360").notes[0].day_count,DayCount.THIRTY_E_360)

    def test_source_units_converted_exactly_and_floor_separate(self):
        request=small_request(legacy_senior_management_fee=D('.00123456789'),legacy_liability_reference_floor=D('.01'))
        self.assertEqual(request.clo_terms.senior_management_fee_bps,D('12.3456789'))
        # Fixed notes do not receive a floating reference-rate floor.
        self.assertIsNone(request.notes[0].index_floor)

    def test_cashflow_only_cannot_silently_ignore_imported_or_invalid_source(self):
        for source in ("IMPORTED", "INVALID"):
            with self.subTest(source=source), self.assertRaises(InputValidationError):
                small_request(mode="CASHFLOW_ONLY", collateral_projection_source=source)

    def test_asset_level_oc_requires_known_classifications(self):
        with self.assertRaisesRegex(InputValidationError, "explicit is_ccc"):
            small_request(legacy_use_asset_level_test_data="Yes")

    def test_itemized_costs_and_reserve_drive_actual_equity(self):
        result=TridentModelService().run(small_request(legacy_upfront_arrangement_fee=D('.01'),
            legacy_legal_documentation=3,legacy_initial_reserve_funding=5,
            legacy_other_initial_uses=2))
        self.assertEqual(result.cashflows.funding.upfront_fees,D(4))
        self.assertEqual(result.cashflows.funding.equity_cash_funding,D(51))
        self.assertEqual(result.equity_cashflows[0].amount,D(-51))
        self.assertTrue(all(row.cash_conservation_residual==0 for row in result.clo.periods))

    def test_acquired_accrued_claim_collected_and_paid_once(self):
        base=TridentModelService().run(small_request())
        changed=TridentModelService().run(small_request(legacy_purchased_accrued_interest=2))
        self.assertEqual(changed.cashflows.funding.equity_cash_funding-base.cashflows.funding.equity_cash_funding,D(2))
        self.assertEqual(changed.clo.total_equity_distributions-base.clo.total_equity_distributions,D(2))
        self.assertEqual(changed.clo.periods[0].received_asset_interest-base.clo.periods[0].received_asset_interest,D(2))

    def test_overlay_changes_actual_balances_without_reviving_default_slices(self):
        result=TridentModelService().run(small_request(legacy_credit_prepayment_overlay="On",
            legacy_original_annual_default_rate=D('.1'),legacy_original_recovery_rate=D('.5'),
            legacy_original_recovery_lag_months=0))
        self.assertIsNotNone(result.clo.original_overlay_projection)
        self.assertTrue(any(row.newly_defaulted_par>0 for row in result.clo.periods))
        for report,period in zip(result.portfolio_snapshots,result.clo.periods,strict=True):
            self.assertEqual(report.total_par,period.closing_collateral_par)

    def test_reinvestment_adds_real_cash_and_par_ledger(self):
        result=TridentModelService().run(small_request(legacy_reinvestment_enabled="Yes",
            legacy_reinvestment_wal=D('.25'),legacy_reinvestment_end_date="2027-05-20",
            legacy_reinvestment_test_gate="Continue",legacy_reinvestment_annual_default_rate=0,
            legacy_reinvestment_annual_prepayment_rate=0))
        self.assertTrue(result.clo.reinvestment_purchases)
        self.assertTrue(any(row.reinvestment_cash_used>0 for row in result.clo.periods))
        for report,period in zip(result.portfolio_snapshots,result.clo.periods,strict=True):
            self.assertEqual(report.total_par,period.closing_collateral_par)

    def test_refinancing_fee_is_negative_dated_equity_contribution(self):
        result=TridentModelService().run(small_request(legacy_refinancing_enabled="Yes",
            legacy_refinancing_date="2027-02-20",legacy_refi_fee_of_debt_fraction=D('.01')))
        self.assertEqual(sum((row.amount for row in result.clo.equity_contributions),D(0)),D('.60'))
        self.assertTrue(any(row.amount==D('-.60') and row.payment_date==date(2027,2,22)
                            for row in result.equity_cashflows))

    def test_optional_call_cuts_future_holdings_and_cash(self):
        result=TridentModelService().run(small_request(legacy_optional_call_enabled="Yes",legacy_call_date="2027-02-20",
            legacy_call_costs_of_debt_fraction=0))
        self.assertEqual(len(result.clo.periods),1)
        self.assertEqual(result.portfolio_snapshots[-1].total_par,D(0))


if __name__=='__main__': unittest.main()
