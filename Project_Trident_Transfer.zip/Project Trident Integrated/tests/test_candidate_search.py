"""Finite candidate search against independent dated funding/return answers."""

from dataclasses import replace
from decimal import Decimal, Inexact, localcontext
from fractions import Fraction
import unittest

from trident.analysis import ReturnStatus
from trident.application.candidate_search import (
    CandidateSearchStatus, CandidateSearchVariant, CandidateSelectionPolicy,
    ClosingPoolSearchRequest, ClosingPoolSearchService,
)
from trident.application.clo_services import TridentModelService
from trident.application.construction import ClosingPoolRedesignService, ConstructionStatus, selected_factor_provenance
from trident.domain.models import InputValidationError
from trident.optimization import OptimizationObjective
from test_construction import fixture, replace_candidate

D = Decimal


def search_request(*, variants=None, policy=CandidateSelectionPolicy.MAX_EQUITY_IRR, **fixture_changes):
    single = fixture(**fixture_changes)
    return ClosingPoolSearchRequest(single.baseline, single.optimization_request,
        single.candidate_snapshot, single.admission_policy,
        variants if variants is not None else (
            CandidateSearchVariant("FULL_SWAP", OptimizationObjective.MIN_FACTOR),
            CandidateSearchVariant("HALF_SWAP", OptimizationObjective.MIN_FACTOR, maximum_trade_par=D(10000)),
        ), policy, single.minimum_equity_irr)


class CandidateSearchIntegrationTests(unittest.TestCase):
    def test_full_waterfall_irr_overrides_linear_factor_preference(self):
        request = search_request()
        result = ClosingPoolSearchService().run(request)
        self.assertIs(result.status, CandidateSearchStatus.COMPLETED)
        self.assertEqual(result.selected_candidate_id, "NO_TRADES")
        self.assertEqual(result.optimality_scope, "EVALUATED_CANDIDATES_ONLY_NO_GLOBAL_EQUITY_IRR_OPTIMALITY")
        self.assertEqual(result.execution_status, "NOT_EXECUTED")
        baseline, full, half = (result.evaluation(name) for name in ("NO_TRADES", "FULL_SWAP", "HALF_SWAP"))
        self.assertTrue(all(row.eligible and row.pareto for row in (baseline, full, half)))
        self.assertEqual([row.rank for row in (baseline, half, full)], [1, 2, 3])
        self.assertEqual([row.exact_factor for row in (baseline, half, full)], [Fraction(4000), Fraction(3000), Fraction(2000)])
        self.assertTrue(all(row.factor_metric == "TEST_FACTOR_AVERAGE" for row in result.evaluations))
        # Independent closing economics: original 10k at100 +7fees -8k debt
        # gives2007equity. 125 assetcoupon -40 noteinterest +2000residual=2085.
        # Fullswap ask101 gives2107equity and2160distribution after90days.
        # Half retained100 / half ask101 gives2057 and2122.50, respectively.
        for row, funding, distribution in ((baseline, D(2007), D(2085)),
                (half, D(2057), D("2122.50")), (full, D(2107), D(2160))):
            with self.subTest(candidate=row.candidate_id):
                expected = (float(distribution) / float(funding)) ** (365 / 90) - 1
                self.assertEqual(row.equity_cash_funding, funding)
                self.assertEqual(row.equity_distributions, distribution)
                self.assertLess(abs(float(row.equity_irr.value) - expected), 1e-12)
        self.assertEqual(full.gross_trade_par, D(20000))
        self.assertEqual(half.gross_trade_par, D(10000))
        self.assertLess(full.equity_irr_delta, 0)
        self.assertEqual(full.factor_delta, D(-2000))
        self.assertEqual(request.baseline.cashflow_request.positions[0].opening_balance, D(10000))

    def test_explicit_factor_first_policy_selects_lower_factor_without_irr_claim(self):
        result = ClosingPoolSearchService().run(search_request(policy=CandidateSelectionPolicy.MIN_FACTOR_THEN_IRR))
        self.assertEqual(result.selected_candidate_id, "FULL_SWAP")
        self.assertLess(result.evaluation("FULL_SWAP").equity_irr_delta, 0)
        self.assertEqual(result.evaluation("FULL_SWAP").rank, 1)

    def test_exact_common_mandate_and_explicit_minimum_return_exclude_no_trade(self):
        request = search_request()
        request = replace(request, base_mandate=replace(request.base_mandate,
            limits=replace(request.base_mandate.limits, maximum_overall_factor=D(3000))))
        result = ClosingPoolSearchService().run(request)
        self.assertFalse(result.evaluation("NO_TRADES").eligible)
        self.assertIsNotNone(result.evaluation("NO_TRADES").equity_irr.value)
        self.assertEqual(result.selected_candidate_id, "HALF_SWAP")
        self.assertEqual(result.evaluation("NO_TRADES").status, "STATIC_REJECTED")
        strict = ClosingPoolSearchService().run(replace(request, minimum_equity_irr=D(1)))
        self.assertIs(strict.status, CandidateSearchStatus.NO_ELIGIBLE_CANDIDATE)
        self.assertIsNone(strict.selected_candidate_id)
        self.assertTrue(all(row.rank is None and not row.pareto for row in strict.evaluations))

    def test_candidate_override_may_only_tighten_all_common_limits(self):
        request = search_request(variants=(
            CandidateSearchVariant("RELAX_FACTOR", OptimizationObjective.MIN_FACTOR, maximum_overall_factor=D(3001)),
            CandidateSearchVariant("RELAX_BSL", OptimizationObjective.MIN_FACTOR, maximum_bsl_factor=D(3001)),
            CandidateSearchVariant("RELAX_SPREAD", OptimizationObjective.MAX_SPREAD, minimum_spread_bps=D(400)),
            CandidateSearchVariant("RELAX_TURNOVER", OptimizationObjective.MIN_FACTOR, maximum_trade_par=D(20001)),
            CandidateSearchVariant("VALID", OptimizationObjective.MIN_FACTOR),
        ))
        request = replace(request, base_mandate=replace(request.base_mandate, limits=replace(request.base_mandate.limits,
            maximum_overall_factor=D(3000), maximum_bsl_factor=D(3000), minimum_spread_bps=D(500), maximum_trade_par=D(20000))))
        result = ClosingPoolSearchService().run(request)
        for row in result.evaluations[1:5]:
            self.assertEqual(row.status, "INPUT_REJECTED")
            self.assertIn("relax", row.failure_message)
            self.assertFalse(row.eligible)
            self.assertIsNone(row.replay)
        self.assertTrue(result.evaluation("VALID").eligible)

    def test_replay_failure_retains_static_plan_without_fake_returns(self):
        request = search_request(fees=True, accrued=True)
        result = ClosingPoolSearchService().run(request)
        self.assertEqual(result.selected_candidate_id, "NO_TRADES")
        for row in result.evaluations[1:]:
            self.assertEqual(row.status, "REPLAY_FAILED")
            self.assertFalse(row.eligible)
            self.assertIs(row.equity_irr.status, ReturnStatus.UNAVAILABLE)
            self.assertIsNone(row.equity_irr_delta)
            self.assertIsNotNone(row.replay.plan)
            self.assertIsNotNone(row.static_ending_cash)
            self.assertIn("accrued", row.failure_message)

    def test_missing_new_index_is_a_named_target_failure_with_preserved_static_plan(self):
        single = fixture()
        new = next(row for row in single.candidate_snapshot.candidates if row.asset_id == "NEW")
        changed = replace_candidate(single, "NEW", position=replace(new.position,
            terms=replace(new.position.terms, frequency_months=6, rate_index="EURIBOR_6M")))
        replay = ClosingPoolRedesignService().run(changed)
        self.assertIs(replay.status, ConstructionStatus.REPLAY_FAILED)
        self.assertIsNotNone(replay.plan)
        self.assertIn("EURIBOR_6M", replay.findings[-1].message)
        request = ClosingPoolSearchRequest(changed.baseline, changed.optimization_request,
            changed.candidate_snapshot, changed.admission_policy,
            (CandidateSearchVariant("MISSING_CURVE", OptimizationObjective.MIN_FACTOR),))
        result = ClosingPoolSearchService().run(request)
        self.assertEqual(result.evaluation("MISSING_CURVE").status, "REPLAY_FAILED")
        self.assertEqual(result.selected_candidate_id, "NO_TRADES")

    def test_baseline_is_projected_once_and_duplicate_candidates_retain_named_evidence(self):
        request = search_request(variants=(CandidateSearchVariant("Z", OptimizationObjective.MIN_FACTOR),
            CandidateSearchVariant("A", OptimizationObjective.MAX_SPREAD)))
        class CountingService:
            def __init__(self):
                self.delegate, self.baseline_calls = TridentModelService(), 0
            def run(self, model_request):
                if model_request == request.baseline:
                    self.baseline_calls += 1
                return self.delegate.run(model_request)
        service = CountingService()
        result = ClosingPoolSearchService(service=service).run(request)
        self.assertEqual(service.baseline_calls, 1)
        self.assertEqual(result.evaluation("A").replay.target_request, result.evaluation("Z").replay.target_request)
        self.assertTrue(result.evaluation("A").pareto and result.evaluation("Z").pareto)
        self.assertLess(result.evaluation("A").rank, result.evaluation("Z").rank)

    def test_dominated_candidate_is_excluded_from_frontier_not_from_validity(self):
        request = search_request(buy_price=D(103), variants=(
            CandidateSearchVariant("FULL_SWAP", OptimizationObjective.MAX_SPREAD),
            CandidateSearchVariant("HALF_SWAP", OptimizationObjective.MAX_SPREAD, maximum_trade_par=D(10000)),
        ))
        # New loan has the SAME factor4000. Its higher spread800 maximizes
        # the linear objective, but the ask103 cost consumes the extra coupon:
        # full target2160 / equity2307 < original2085 / equity2007.
        mapping = replace(request.baseline.factor_mapping, factors={"OLD_BUCKET": D(4000), "NEW_BUCKET": D(4000)})
        new = next(row for row in request.candidate_snapshot.candidates if row.asset_id == "NEW")
        asset = replace(new.asset, factor=D(4000))
        quotes = tuple(replace(q, asset=asset) if q.asset.asset_id == "NEW" else q for q in request.base_mandate.quotes)
        changed_new = replace(new, asset=asset, prices=(replace(new.prices[0], quote=quotes[1]),))
        request = replace(request, baseline=replace(request.baseline, factor_mapping=mapping),
            base_mandate=replace(request.base_mandate, quotes=quotes),
            candidate_snapshot=replace(request.candidate_snapshot, candidates=tuple(
                changed_new if row.asset_id == "NEW" else row for row in request.candidate_snapshot.candidates)))
        result = ClosingPoolSearchService().run(request)
        self.assertTrue(all(row.eligible for row in result.evaluations))
        self.assertEqual(result.selected_candidate_id, "NO_TRADES")
        self.assertTrue(result.evaluation("NO_TRADES").pareto)
        self.assertFalse(result.evaluation("FULL_SWAP").pareto)
        self.assertFalse(result.evaluation("HALF_SWAP").pareto)

    def test_caller_context_and_variant_order_do_not_change_selection_or_finance(self):
        request = search_request()
        expected = ClosingPoolSearchService().run(request)
        with localcontext() as context:
            context.prec = 2
            context.traps[Inexact] = True
            actual = ClosingPoolSearchService().run(replace(request, variants=tuple(reversed(request.variants))))
        self.assertEqual(actual.selected_candidate_id, expected.selected_candidate_id)
        for name in ("NO_TRADES", "FULL_SWAP", "HALF_SWAP"):
            self.assertEqual(replace(actual.evaluation(name), replay=None), replace(expected.evaluation(name), replay=None))
            self.assertEqual(actual.evaluation(name).replay.target_result.clo, expected.evaluation(name).replay.target_result.clo)

    def test_variant_and_search_input_corner_cases_fail_clearly(self):
        request = search_request()
        for changes in ({"candidate_id": "NO_TRADES"}, {"candidate_id": " X"}, {"objective": "MIN_FACTOR"},
                        {"maximum_trade_par": D("0.001")}, {"maximum_bsl_factor": -1.0}):
            with self.subTest(changes=changes), self.assertRaises(InputValidationError):
                replace(request.variants[0], **changes)
        for changes in ({"variants": ()}, {"variants": list(request.variants)}, {"max_variants": 1},
                        {"max_variants": True}, {"irr_comparison_tolerance": D(-1)}, {"minimum_equity_irr": D(-1)},
                        {"selection_policy": "MAX_EQUITY_IRR"},
                        {"variants": (request.variants[0], replace(request.variants[0], candidate_id="full_swap"))}):
            with self.subTest(changes=changes), self.assertRaises(InputValidationError):
                replace(request, **changes)
        with self.assertRaises(KeyError):
            ClosingPoolSearchService().run(request).evaluation("ABSENT")


if __name__ == "__main__":
    unittest.main()
