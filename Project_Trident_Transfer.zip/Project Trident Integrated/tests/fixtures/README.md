# Current workbook input fixture

[Project_Trident_inputs.xlsx](Project_Trident_inputs.xlsx) is the uncalculated schema
0.7 input template. Its 72 sheets, 306 names and 72 Tables match the current UI;
outputs are empty and run status is `NOT_RUN`. Each Excel test copies it and
calculates its own case. Tests never read the user's live output or an older
release. Expected financial amounts come from the independent cases in Python.

Five related input pairs share a sheet horizontally. Each keeps its own Table
and named business interface, so extending one does not move another below it.
The reusable presentation policy also groups and colors input/output tabs,
centers data cells, and displays face/notional/par in whole units without
rounding the underlying values. Cash postings and claims retain cents.

The current [input payload](../../data/templates/Project_Trident_inputs.json) and
unique [builder](../../scripts/build_template.mjs) define this fixture.
[Market Data reference](../../data/reference/market_data.json) is a read-only
snapshot of the original CLO v4.2.2 paste surface, shared with the builder.
The Market Data test checks types, values, formats, merges and named paste
positions against that source independently of the model output.

Current fixture, payload and Market Data SHA-256 values are maintained in
[the current validation record](../../docs/validation/current.json). That record
is the single release reference; rebuilding a fixture requires updating it.

Regenerate only for an intentional current-interface change, using Node
and the existing builder:

```text
node scripts/build_template.mjs --output=tests/fixtures/Project_Trident_inputs.xlsx --replace --skip-previews
```

Then run `test_excel_schema` and affected workbook cases. Refreshing market
data or changing sample contracts requires an explicit fixture update and new
independent expected values. The fixture does not certify a real deal.
