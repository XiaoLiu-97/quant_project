# Table 容量与报表更新

本说明区分预留的物理区域、实际业务记录和结果展示空间。所有 native Excel Tables 都按用途分配或登记容量；300是资产输入表的初始预留行数，不是每张表统一的记录上限。15个用户页保持不变，完整结果仍保存于隐藏支持页。

## 用户如何使用预留输入行

资产输入区预先提供空白行、Arial 样式、相应日期/金额格式及原生输入约束。新增资产时，直接在表内空白行填写真正拥有该字段的输入，无须先插入新工作表。尚未使用的行保持真正空白，不填写占位 Asset ID、零本金或示例评级。

| 输入 Table | 初始可用记录行数，不含表头 | 记录含义 |
| --- | ---: | --- |
| Asset Library / asset register | 300 | 每项共同资产身份一行 |
| Asset Library / asset terms | 300 | 每项合同条款一行 |
| Asset Library / asset details | 300 | 每项补充合同与资料一行 |
| Collateral Pool | 300 | 当前 CLO 的持仓与逐项成本 |
| Trade Universe | 300 | 当前可用交易报价记录；一项资产有多条报价时各占一行 |
| Asset ratings | 900 | 全部资产合计的评级记录；一项资产可对应多个 agency 或来源 |
| Bespoke principal schedule | 3,000 | 全部资产合计的 dated principal repayments；每期本金一行 |
| Asset events | 3,000 | 全部资产合计的已支持 dated events |
| Capital Stack | 12 | 每层capital tranche一行；空行不产生额外债务 |
| Portfolio limits | 100 | 当前schema支持的limit，每条约束一行 |
| Scenario Edits | 300 | 每条绝对替换edit一行；同一case可使用多条edit |
| Factor mapping | 300 | 评级/factor系统的映射记录；需保留版本、来源及synthetic标记 |

以上覆盖12类可增长owning input Tables。900与3,000均为相应整张输入表的预留行数，不是每项资产的数量，也不限制一项 Infra loan 必须只能填10期 repayment。Scenario Edits的300是edit行数，不是300个自动创建的case。Factor mapping的300是可填写空间，不提供新的agency calibration或允许任意未经支持的rating system。已有输入表大于上述数量时，保留其更大的区域。

新增资产仍需填写其必需合同信息，并在需要时提供评级、来源及 bespoke schedule。Asset Library 的资产属于候选库；是否实际进入 Base case 由 Collateral Pool 的持仓决定。把 Asset ID 填入 Library 不会自动购买该资产，也不自动产生 CLO 收款。

资产 ID 下拉框从已填写的注册身份生成紧凑选项，即使新增记录位于预留区的较后面行，也应能在 Excel 计算后被选择。空白预留行不成为可选资产。Lookup 的完整 ID 轴与其他 owning 列维持相同长度，避免扩大输入区后使 MATCH、COUNTIFS 或 freshness 比较错位。

## 所有 Tables 的不同容量类别

| 类别 | 处理方式 | 原因 |
| --- | --- | --- |
| 可增长的 owning input | 预留适当空白行、格式与输入约束；保留有效输入 | 用户可以直接填写新增业务记录 |
| 一对多 schedule / rating / event | 使用独立于资产数量的预留行数 | 300项资产并不等于300条还款或评级 |
| 固定语义表 | 保留 schema 规定的账户、费用、控制项及枚举数量 | 扩大到300条会制造不存在的账户或可选值 |
| 动态 output / 完整 case records | 按资产、期数、tranche与case预留物理容量；本轮只写真实结果 | 容量足够时重复运行后的 native Table 范围保持稳定 |
| 受固定页面布局约束的结果 | 在不覆盖邻表或说明的范围内预留；完整明细仍保存 | 不能为预留空行覆盖已有界面内容 |
| Options / lookup helper | 与真实身份、已计算 case 或支持选项相匹配 | 下拉框不应含过期身份或无意义的空尾项 |
| Frozen witness | 与对应 owning input 的行列形状一致 | 输入变更检测必须覆盖全部预留区，不能只覆盖原先已填写的行 |
| Market Data | 保留粘贴兼容布局和已有 native Tables | 容量更新不改变利率曲线的输入布局或内容 |

Opening 的八项账户/designation 和四类fee claims仍按原有schema保留；deal controls与固定费用字段不人为增加空记录。Capital Stack、limits、Scenario Edits和factor mapping分别按上表预留，其有效字段仍必须符合已支持schema。增加空白容量不能替代required source，也不能把缺失账户补成零。预留tranche行包含对应的opening coupon claim/witness范围，不能只扩note face而遗漏存续未付利息输入。

为让limits向下增长，CLO Assumptions中的OC ownership说明与导航移到同一页右侧的独立区域：`AC9:AH20`；原生Table仍为 `tbl_trident_ui_oc_ownership`，新范围为 `AC10:AE14`。标题在AC9，Pool/Credit导航在AC16/AF16，Advanced mapping入口在AC18，说明在AC20。Factor mapping的输入owner仍为W:AB，相关warning改放 `AC22:AH22`。该移动只调整已识别的说明和导航，保留原policy owning inputs与named navigation，不增加用户页，不移动有效业务输入。

## 输出容量如何确定

资产现金流的容量按300项资产与当前合同的最大实际期数确定；多case支持数据再考虑完整case数量。Waterfall、coverage和tranche结果按期数、tranche与case数量预留，期数基础至少60期、tranche基础至少12层。其他可增长明细通常按300行或不碰撞的可用页面范围预留；固定选项与固定语义表按真实schema数量保留。

这些是展示空间的初始预算，不改变资产日期、legal final、实际tranche数量或投影期数。Asset Cashflows 的未使用区域不会因此生成额外现金流，Waterfall 不会因此增加12层债务。

原生 Table 的物理范围包含预留的空白尾部；本轮只写实际结果，实际使用数量另行登记。容量足够时复用已建区域、cell styles和没有变化的展示公式，不重复建立整张报表。没有实际记录的尾部保持空白，不预填数十万条展示公式、零本金或零现金记录。结果缩短时清除过期值、公式和cache，保留可复用的空白格式。

原生 Excel Table 在零结果时保留的最小空白body行不代表一条业务记录。图表、选择项和明细的实际记录不能从物理capacity行数推断，必须按所保存的结果与使用数量解释。隐藏列、隐藏行和隐藏 `_Results` 采用同一规则，不能只检查首页。

## 在哪里查看全部 Table 的容量

取消隐藏 `_Results`，找到 `tbl_trident_ui_table_capacity`。这张表登记每张 native Table 的容量类别及范围；它是审阅信息，不能作为金融输入修改。

| 登记字段 | 含义 |
| --- | --- |
| Table | 原生 Table 的稳定名称，使用 `tbl_trident_ui_` 命名空间 |
| Sheet | 该 Table 当前所在的工作表，包括隐藏支持页 |
| Role | `INPUT`、`INPUT_WITNESS`、`CHOICE_CATALOGUE` 或 `OUTPUT`；说明该表在输入和结果输送中的责任 |
| Capacity rows | 当前 native Table 的物理body行数，不含表头，可能包含预留空白行 |
| Populated rows | 当前已填写或已保存结果使用的记录行数；不把空白容量当业务记录 |
| Requested rows | 此类表本轮请求的容量；固定布局可能限制可安全分配的空间 |
| Capacity mode | 下表中的容量处理方式 |

| Capacity mode | 含义 |
| --- | --- |
| RESERVED_INPUT | 12类可增长owning inputs：资产、持仓、报价、一对多明细、capital、limits、edits及factor mapping的预留空间 |
| FIXED_INPUT_STRUCTURE | schema定义的输入结构，如账户、控制项和固定语义字段；保留其实际数量 |
| MATCH_INPUT_CAPACITY | frozen witness与对应input保持相同容量，确保freshness覆盖新增行 |
| EXACT_CHOICES | 保留选项目录或其必要helper结构；真正下拉范围只选择有效的身份、case或枚举 |
| RESERVED_OUTPUT | 可增长结果按其记录粒度预留完整所需容量 |
| LAYOUT_BOUND_OUTPUT | 邻表、合并区、说明或named input限制了可安全预留空间；该状态不允许截断真实结果 |
| FIXED_OUTPUT_STRUCTURE | 保留的固定结果或支持结构，本轮没有按变长结果重新分配容量 |

例如，物理容量为300而实际持仓150时，Pool仍只有150条有效持仓；额外150行不加入金额、WAS、WARF或concentration分母。实际状态、金额和日期以已填写输入及已保存完整case结果为准。

## 预留容量能减少哪些工作

预留和复用减少重复的Table扩容、逐项格式建立及XML结构调整；批量写入和缓存索引减少反复扫描工作表及排序整行。增加空白容量仍可能增加读取文件与Excel lookup的工作量，因此不会靠为全部空槽预填公式来提高速度。

每次运行仍需计算所选金融情景、刷新真实结果值、input fingerprint、状态、实际数量及图表cache。预留容量不能让变化后的模型继续显示旧结果，也不能免除金融守恒和输入保护。实际性能与等价性证据见 [验收说明](readiness.md)，不将容量大小视为固定耗时承诺。

## 增长和失败保护

预留数量是初始空间，不是硬上限。更多记录可继续按Excel Table的正常方式增长，但所有命名owner、相关validation、lookup轴及witness必须包含新增行。若新结果超过原有容量，writer在安全范围内扩展；完整记录不能静默截断。

扩容前检查原生Tables、named inputs、合并区、隐藏内容和已有非空单元格。相邻数据发生冲突或超过Excel行/列限制时明确停止，不能覆盖邻表或发布部分结果。Market Data和已有有效financial inputs保持原值；格式显示不改变cents、face、rate或日期。

## 复核时应检查什么

- 空白预留行没有新增资产、现金、评级或日期，不改变typed request或输入fingerprint。
- 新增资产能够在下拉框中被选择，且未用的空行不作为可选项。
- Input owner与frozen witness的范围一致，新增行修改能产生dirty状态。
- 同一金融输入下，扩容前后的cashflow、IRR、IC/OC、claims与守恒结果一致。
- 输出增加或缩短后，实际使用数量、日期、金额、单位和状态正确，旧结果不残留。
- 在预留容量内重复运行后的Table范围保持稳定；超出容量时不覆盖相邻区域或截断记录。
- 实际Excel正常打开、计算和重开；names、Tables、validation、charts与隐藏明细保留。

容量与输送层不改变当前功能边界：优化仍为静态研究或受支持的finite closing candidate replay；synthetic reinvestment按明确假设投影，未新增动态lifetime trading optimization。用户操作见 [使用指南](user_guide.md)。

当前writer先决定实际记录数与受保护的最终容量，随后一次写入；容量内repeat不将Table先缩短再恢复。旧值、formula及cache尾部仍清除；soft reserve不能截断真实记录。真实增长须检查Tables、named input owners、merges和隐藏notes，冲突明确拒绝。source/cache复用条件见[架构](architecture.md#稳定模板与增量写出)，最新计时见[运行时间](optimization_runtime.md)。
