"""Retain original contract schedules when projecting a seasoned holding.

As-of selects future entitlements; it never creates a new term-rate reset or
restarts a contractual principal installment series. Historical coupon claims
and original known fixings are explicit opening-state inputs. This increment
does not infer unpaid old coupons, settlement receivables or recast annuities.
"""

from dataclasses import dataclass, replace
from decimal import Decimal
from fractions import Fraction

from trident.conventions.calendar import BusinessCalendar
from trident.conventions.day_count import DayCount
from trident.conventions.schedule import AccrualPeriod, ScheduleBuilder
from trident.domain.models import AmortizationType, CouponType, InputValidationError, LoanPosition, OpeningCouponEntitlement, SeasonedLoanState
from trident.domain.numeric import post_currency
from trident.market.rates import RateProvider

from .coupons import CouponProjector
from .principal import build_principal_policy


@dataclass(frozen=True)
class PositionSchedule:
    """Original grids plus numbered forward cash periods and source indices.

    original_indices identify the contractual installment before past receipts
    are removed. Forward period numbers remain 1, 2, ... for the cash/par
    transports; nominal boundaries and reset/fixing dates retain their meaning.
    """

    contractual_periods: tuple[AccrualPeriod, ...]
    projection_periods: tuple[AccrualPeriod, ...]
    original_indices: tuple[int, ...]


def build_position_schedule(position: LoanPosition, calendar: BusinessCalendar) -> PositionSchedule:
    """Build original anchors once, then select and clip the forward horizon.

    A seasoned snapshot is post-settlement on its calendar date: scheduled cash
    on that date is already received and is excluded. The first unpaid cash
    must belong to a still-active accrual interval; an old ended but unpaid
    coupon needs a separate receivable state and is rejected. Splitting a
    non-additive 30/360 convention inside a period needs a contractual allocation
    rule, so the initial seasoned extension supports additive partial accrual.
    """
    if not isinstance(position, LoanPosition):
        raise InputValidationError("Position schedule requires LoanPosition")
    terms = position.terms
    periods = ScheduleBuilder(calendar).build(
        terms.start_date, terms.maturity_date, terms.frequency_months,
        business_day_convention=terms.business_day_convention,
        accrual_date_basis=terms.accrual_date_basis,
        fixing_lag_business_days=terms.fixing_lag_business_days,
        payment_lag_business_days=terms.payment_lag_business_days,
        end_of_month=terms.end_of_month, stub_convention=terms.stub_convention,
        first_payment_date=terms.first_payment_date,
        last_regular_payment_date=terms.last_regular_payment_date,
    )
    if position.seasoned_state is None:
        return PositionSchedule(periods, periods, tuple(range(len(periods))))
    asof = position.par_as_of_date
    future = tuple((index, period) for index, period in enumerate(periods) if period.payment_date > asof)
    if not future:
        raise InputValidationError("Seasoned position has no future contractual payment")
    first = future[0][1]
    if not first.accrual_start <= asof < first.accrual_end:
        raise InputValidationError("Seasoned as-of lies outside the first unpaid accrual interval; an ended unpaid coupon requires explicit receivable state")
    if asof == first.accrual_start and position.seasoned_state.opening_accrued_interest != 0:
        raise InputValidationError("Seasoned boundary snapshot cannot carry an accrued claim from an already settled coupon")
    if asof != first.accrual_start and terms.day_count in (DayCount.THIRTY_360_ISDA, DayCount.THIRTY_U_360_EOM):
        raise InputValidationError("Mid-period seasoned accrual requires an additive day count")
    if terms.amortization_type is AmortizationType.BESPOKE:
        future_indices = {index for index, _ in future}
        settled_boundaries = {period.unadjusted_end for index, period in enumerate(periods)
                              if index not in future_indices}
        if any(entry.amount != 0 and entry.payment_date in settled_boundaries for entry in terms.principal_schedule):
            raise InputValidationError("Seasoned BESPOKE schedule includes principal already settled by as-of")
    projected = tuple(replace(period, period_number=number,
        accrual_start=asof if number == 1 else period.accrual_start)
        for number, (_, period) in enumerate(future, 1))
    return PositionSchedule(periods, projected, tuple(index for index, _ in future))


def build_position_coupon_projector(
    position: LoanPosition, schedule: PositionSchedule, calendar: BusinessCalendar,
    provider: RateProvider | None = None,
) -> CouponProjector:
    """Reuse original resets and seed exactly the needed historical fixings.

    Even a future reset may already have fixed by as-of because of its fixing
    lag. Every such original date must have an explicit observation. Missing or
    extraneous dates reject stale/misidentified input rather than querying a
    projected curve for a carried historical rate. Future fixings remain lazy.
    """
    projector = CouponProjector(position.terms, schedule.contractual_periods, calendar, provider)
    state = position.seasoned_state
    if state is None or position.terms.coupon_type is CouponType.FIXED:
        return projector
    if projector.is_overnight:
        if state.fixing_observations:
            raise InputValidationError("Projected overnight opening has no lagged term-index fixing observations")
        if state.entitlement_policy is OpeningCouponEntitlement.FULL_CURRENT_PERIOD and state.opening_accrued_interest != 0:
            raise InputValidationError("Historical overnight accrual requires a verified cash claim; a forward zero curve cannot infer realized observations")
        return projector
    # Supported seasoned strategies have rate-independent contractual principal.
    # Stop at their actual payoff, so a fixed-but-unneeded later reset does not
    # demand an irrelevant historical observation for a loan retiring earlier.
    principal = build_principal_policy(position, schedule.contractual_periods)
    balance, required = position.opening_balance, set()
    for original_index, period in zip(schedule.original_indices, schedule.projection_periods, strict=True):
        if balance == 0:
            break
        required.update(fixing for _, _, _, fixing in projector.layout(period)
                        if fixing <= position.par_as_of_date)
        balance = post_currency(Fraction(balance) - Fraction(principal.repayment(original_index, balance, Decimal(0))))
    if state.entitlement_policy is OpeningCouponEntitlement.FULL_CURRENT_PERIOD:
        first_original = schedule.contractual_periods[schedule.original_indices[0]]
        required.update(fixing for _, _, _, fixing in projector.layout(first_original)
                        if fixing <= position.par_as_of_date)
    supplied = {row.fixing_date: row.index_rate for row in state.fixing_observations}
    if set(supplied) != required:
        missing, extra = sorted(required - set(supplied)), sorted(set(supplied) - required)
        raise InputValidationError(f"Seasoned opening fixing dates do not match original forward entitlement; missing={missing}, extra={extra}")
    projector.observations.update(supplied)
    return projector


def opening_coupon_claim_exact(
    position: LoanPosition, schedule: PositionSchedule, projector: CouponProjector,
) -> Fraction:
    """Resolve unpaid opening entitlement without rounding a coupon component.

    FULL_CURRENT_PERIOD validates the posted opening claim against the original
    period's exact accrual on the held slice. It requires constant slice par
    since that period's start, which the supported cash-pay principal rules
    retain until period-end repayment. The prefix uses actual original reset
    observations and never queries a future rate merely to calculate history.
    Explicit cash allocations and post-as-of entitlement remain distinct rules.
    """
    state = position.seasoned_state
    if state is None or state.entitlement_policy is OpeningCouponEntitlement.POST_ASOF_ONLY:
        return Fraction()
    if state.entitlement_policy is OpeningCouponEntitlement.EXPLICIT_CASH_CLAIM:
        return Fraction(state.opening_accrued_interest)
    original = schedule.contractual_periods[schedule.original_indices[0]]
    if position.par_as_of_date == original.accrual_start:
        exact = Fraction()
    else:
        prefix = replace(original, accrual_end=position.par_as_of_date)
        exact = Fraction(position.opening_balance) * projector.project(prefix).exact_factor
    if post_currency(exact) != state.opening_accrued_interest:
        raise InputValidationError("FULL_CURRENT_PERIOD opening accrued claim does not match exact original rate/day-count entitlement")
    return exact


def resize_seasoned_state(position: LoanPosition, ratio: Fraction,
                          calendar: BusinessCalendar | None = None) -> SeasonedLoanState | None:
    """Resize target entitlement using its unposted source, preserving fixings.

    Scaling a rounded historical coupon can move a half-cent target across the
    wrong boundary. FULL_CURRENT_PERIOD therefore reuses the exact source claim;
    explicit agreed cash claims scale as the quoted cent amount. This function
    has no provider and fetches no market observations.
    """
    state = position.seasoned_state
    if state is None:
        return None
    if state.entitlement_policy is not OpeningCouponEntitlement.FULL_CURRENT_PERIOD:
        return state.scaled(ratio)
    from trident.conventions.calendar import calendar_from_name
    calendar = calendar or calendar_from_name(position.terms.holiday_calendar)
    schedule = build_position_schedule(position, calendar)
    projector = build_position_coupon_projector(position, schedule, calendar)
    return state.scaled(ratio, unrounded_claim=opening_coupon_claim_exact(position, schedule, projector))
