"""Unified credit projection, investor return and launcher known answers."""

from contextlib import redirect_stderr, redirect_stdout
from dataclasses import replace
from datetime import date
from decimal import Decimal
from io import StringIO
import json
import unittest

from trident.adapters.credit_example import credit_example_request, run_credit_example
from trident import __version__
from trident.analysis import ReturnStatus
from trident.application.clo_services import TridentModelService
from trident.cli import main
from trident.application.scenarios import ScenarioDefinition, ScenarioEdit, ScenarioExecutionError, ScenarioRunner, ScenarioTarget
from trident.credit import DefaultEvent, PrepaymentEvent, RecoveryEvent
from trident.domain.models import InputValidationError


class CreditApplicationTests(unittest.TestCase):
    def test_original_contract_is_reference_and_actual_credit_drives_investor_return(self):
        result = run_credit_example()
        self.assertEqual(result.cashflows.total_principal, 100)
        self.assertEqual(result.credit_projections[0].total_principal_collections, 80)
        self.assertEqual(result.credit_projections[0].total_cash_interest, 0)
        self.assertEqual(result.cashflows.funding.equity_cash_funding, 40)
        self.assertEqual(result.clo.total_equity_distributions, 20)
        self.assertIs(result.equity_irr.status, ReturnStatus.AVAILABLE)
        # Independent single-return formula: actual distribution occurs at the
        # next CLO date, not the recovery date itself: 273 days from inception.
        expected = 0.5 ** (365 / 273) - 1
        self.assertAlmostEqual(float(result.equity_irr.value), expected, places=13)
        self.assertEqual(result.equity_moic.value, Decimal("0.5"))
        self.assertTrue(all(row.total_par == 0 for row in result.portfolio_snapshots))
        self.assertIn("Contractual reference", result.opening_portfolio.metric("WAL_YEARS").message)

    def test_unresolved_default_never_has_assumed_terminal_irr(self):
        original = credit_example_request()
        event = DefaultEvent("SYN_CREDIT_100", date(2026, 3, 5),
                             (RecoveryEvent(date(2026, 8, 20), Decimal("0.8")),))
        result = TridentModelService().run(replace(original, credit_events=(event,)))
        self.assertEqual(result.clo.final_defaulted_par, 20)
        self.assertIs(result.equity_irr.status, ReturnStatus.UNAVAILABLE)
        self.assertIsNone(result.equity_irr.value)

    def test_credit_overlay_can_be_used_without_clo(self):
        request = credit_example_request()
        result = TridentModelService().run(replace(request, clo_terms=None, notes=()))
        self.assertIsNone(result.clo)
        self.assertEqual(result.credit_projections[0].total_par_loss, 20)
        self.assertIs(result.equity_irr.status, ReturnStatus.UNAVAILABLE)

    def test_unknown_event_and_multiple_exits_rejected(self):
        request = credit_example_request()
        with self.assertRaisesRegex(InputValidationError, "unknown loan_id"):
            TridentModelService().run(replace(request, credit_events=(PrepaymentEvent("UNKNOWN", date(2026, 3, 5)),)))
        with self.assertRaisesRegex(InputValidationError, "one terminating"):
            replace(request, credit_events=request.credit_events + (PrepaymentEvent("SYN_CREDIT_100", date(2026, 4, 20)),))

    def test_launcher_labels_reference_and_credit_cash_separately(self):
        output, errors = StringIO(), StringIO()
        with redirect_stdout(output), redirect_stderr(errors):
            code = main(["example-credit"])
        self.assertEqual(code, 0)
        self.assertEqual(errors.getvalue(), "")
        summary = json.loads(output.getvalue())
        self.assertEqual(summary["version"], __version__)
        self.assertEqual(summary["mode"], "CLO_CREDIT_SCENARIO")
        self.assertEqual(Decimal(summary["total_principal_eur"]), 100)
        credit = summary["credit_projection"]
        self.assertTrue(credit["contractual_cashflows_are_reference"])
        self.assertEqual(Decimal(credit["principal_collections_eur"]), 80)
        self.assertEqual(Decimal(credit["recognized_par_loss_eur"]), 20)
        self.assertEqual(Decimal(credit["final_defaulted_par_eur"]), 0)

    def test_full_clo_rejects_unmodeled_preclosing_coupon_entitlement(self):
        request = credit_example_request()
        cash = replace(request.cashflow_request, purchases=(replace(request.cashflow_request.purchases[0], accrued_interest=Decimal(1)),))
        with self.assertRaisesRegex(InputValidationError, "inherited-coupon"):
            TridentModelService().run(replace(request, cashflow_request=cash))
        costs = TridentModelService().run(replace(request, cashflow_request=cash, clo_terms=None, notes=()))
        self.assertEqual(costs.cashflows.funding.acquired_accrued_interest, 1)
        self.assertEqual(costs.cashflows.funding.equity_cash_funding, 41)
        self.assertIs(costs.equity_irr.status, ReturnStatus.UNAVAILABLE)

    def test_closing_whatif_reuses_explicit_events_and_resizes_actual_default_exposure(self):
        request = credit_example_request()
        scenario = ScenarioDefinition("SIZE", (ScenarioEdit(ScenarioTarget.ASSET, "SYN_CREDIT_100", "par", Decimal(120)),))
        batch = ScenarioRunner().run(request, (scenario,))
        case = batch.scenarios[0]
        self.assertEqual(case.request.credit_events, request.credit_events)
        self.assertEqual(case.result.credit_projections[0].defaulted_exposure, 120)
        self.assertEqual(case.result.clo.total_recovery_collections, 96)
        self.assertEqual(case.result.clo.total_recognized_par_loss, 24)
        self.assertEqual(case.result.clo.total_equity_distributions, 36)
        self.assertEqual(case.result.cashflows.funding.equity_cash_funding, 60)
        loss = next(row for row in case.comparisons if row.scope == "CREDIT" and row.metric == "TOTAL_RECOGNIZED_PAR_LOSS")
        self.assertEqual(loss.delta, 4)
        self.assertTrue(any(row.metric == "RECOVERY_PRINCIPAL_RECEIVED" and row.delta == 16 for row in case.period_comparisons))

    def test_credit_whatif_recomputes_funding_without_changing_default_receipts(self):
        scenario = ScenarioDefinition("FEE", (ScenarioEdit(ScenarioTarget.CONTROL, "DEAL", "upfront_fees", Decimal(1)),))
        batch = ScenarioRunner().run(credit_example_request(), (scenario,))
        result = batch.scenarios[0].result
        self.assertEqual(result.credit_projections, batch.baseline.credit_projections)
        self.assertEqual(result.cashflows.funding.equity_cash_funding, 41)
        self.assertLess(result.equity_irr.value, batch.baseline.equity_irr.value)

    def test_whatif_cannot_move_maturity_before_the_supplied_default(self):
        scenario = ScenarioDefinition("BAD_MATURITY", (ScenarioEdit(ScenarioTarget.ASSET, "SYN_CREDIT_100", "maturity_date", date(2026, 2, 20)),))
        with self.assertRaisesRegex(ScenarioExecutionError, "BAD_MATURITY"):
            ScenarioRunner().run(credit_example_request(), (scenario,))


if __name__ == "__main__":
    unittest.main()
