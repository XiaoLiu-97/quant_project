# Project Trident Integrated

这是独立的 Python + Excel CLO 模型项目。15 个用户页负责输入、结果展示和已计算 case 的切换；贷款现金流、资金来源与用途、组合分析、瀑布、回报和优化在 Python 中计算。工作簿为 `outputs/Project_Trident.xlsx`。源码、运行环境与输入均由本目录拥有，部署不依赖其他项目路径。

当前版本为 **0.12.3**。已修复再投资买后 coverage 校验、成交后的本金分配估值，以及清算后的 OC 双计；同时修正整体界面的日期/单位、隐藏及预留明细、冻结、状态和图表文字；最新保存输入保留，输出已经更新；assumptions 与其他长表的隔行配色已补充统一。流程、已知答案与验证见[waterfall 修复](docs/waterfall_review.md)及[验收](docs/readiness.md)。

第一次使用先阅读 [用户指南](docs/user_guide.md)。日常操作是：在 Excel 中修改输入，保存并关闭工作簿，运行 `Run_Model.cmd`，再打开工作簿查看结果。下拉框只切换已保存的完整 case 或显示范围；它不启动新的金融计算。

支持 closing 的全生命周期现金流与结构敏感性，也支持在原 payment boundary 上以已核验账户、债务和 claim 开账后的未来投影。存续 CLO 的收益基准是有来源的当前 equity value。静态优化提出研究方案；synthetic reinvestment 是明确的预测假设。首个可用版本没有动态全生命周期交易优化。

首次部署按 [安装与迁移](docs/deployment.md) 创建本项目自己的 `.venv` 并安装依赖。日常运行也使用该环境：

```powershell
.\.venv\Scripts\python.exe -m trident check-model outputs/Project_Trident.xlsx --project
.\.venv\Scripts\python.exe -m trident workbook outputs/Project_Trident.xlsx
.\.venv\Scripts\python.exe -m trident workbook outputs/Project_Trident.xlsx --output outputs/Reviewed_Case.xlsx
```

`check-model --project` 在内存中运行，不写文件。`workbook` 在所有选择的计算成功后更新结果；指定 `--output` 则写入独立结果副本。输入错误或未支持的 profile 会返回原因，不以旧结果冒充新结果。

文档入口：

- [用户指南](docs/user_guide.md)：输入位置、单位、运行与检查。
- [安装与迁移](docs/deployment.md)：pip 安装、环境检查、日常 launcher 与独立部署。
- [架构与数据流](docs/architecture.md)：所有权、模块和发布流程。
- [Waterfall中文阅读指南](docs/waterfall_guide_cn.md)：17页流程图配套文字、步骤释义、独立例子与输入位置。
- [计算流程图](docs/calculation_flowcharts.md)：资产收款、瀑布、再投资、回报及静态/finite candidate 比较。
- [界面格式规范](docs/interface_style.md)：模板、单位、下拉框和可扩展表格。
- [优化实测运行时间](docs/optimization_runtime.md)：LP/MILP、完整IRR候选比较和独立Excel读写计时。
- [Table容量与重复运行](docs/table_capacity.md)：全部表格的预留数量、空白行、扩容保护和隐藏容量登记。
- [模型假设](docs/model_assumptions.md)：金融口径和明确限制。
- [验证与使用边界](docs/readiness.md)：证据、验收和交易 profile 边界。
- [项目上下文](docs/project_context.md)：持续约定和项目隔离。

最新完整回归见 [回归记录](docs/validation/current.json) 及其绑定的日志和源码hash；本轮发布与整体界面证据见 [waterfall修复](docs/validation/waterfall_repair.json) 和 [界面验收](docs/validation/interface_formatting.json)。[writer计时](docs/validation/writer_optimization.json) 保留其冻结输入及测试范围。测试支持的 generic capabilities 通过，不等于任意真实交易已完成法律映射或 trustee reconciliation。
