"""Explicit credit events and collection ledgers, separate from receivables.

These events describe a supplied deterministic cash-flow scenario. They are
not rating-agency default probabilities, recovery assumptions or an indenture's
definition of a defaulted obligation. Cash dates are actual supplied dates and
are never silently business-day adjusted. Fractions are decimal proportions.
"""

from dataclasses import dataclass
from datetime import date
from decimal import Decimal
from enum import Enum
from fractions import Fraction

from trident.cashflows.coupons import cashflow_coupon_factor
from trident.conventions.day_count import DayCount, accrual_fraction
from trident.domain.models import (
    InputValidationError, InterestMode, LoanCashflow, require_date, require_decimal, require_money,
)
from trident.domain.numeric import decimal_fraction, post_currency


class AssetCashSource(str, Enum):
    """Economic operation; default and write-off themselves produce no cash."""

    SCHEDULED = "SCHEDULED"
    PREPAYMENT = "PREPAYMENT"
    DEFAULT = "DEFAULT"
    RECOVERY = "RECOVERY"
    WRITE_OFF = "WRITE_OFF"


class CreditProjectionStatus(str, Enum):
    """State at the explicit horizon, without inventing a terminal recovery."""

    PERFORMING = "PERFORMING"
    REPAID = "REPAID"
    PREPAID = "PREPAID"
    DEFAULT_UNRESOLVED = "DEFAULT_UNRESOLVED"
    DEFAULT_RESOLVED = "DEFAULT_RESOLVED"


def _identifier(value: object, label: str) -> None:
    if not isinstance(value, str) or not value or value != value.strip():
        raise InputValidationError(f"{label} must be a nonempty identifier without surrounding whitespace")


def _signed_money(value: object, label: str) -> Decimal:
    amount = require_decimal(value, label)
    if post_currency(Fraction(amount)) != amount:
        raise InputValidationError(f"{label} must have at most two decimal places")
    return amount


@dataclass(frozen=True)
class RecoveryEvent:
    """Principal recovery on an actual date, as a fraction of defaulted par.

    Each fraction refers to the original exposure at this scenario's default,
    not to a shrinking recovery balance. The engine posts cumulative targets
    and pays their cent differences, so installment rounding cannot recover
    more than the original defaulted principal. Explicit zero is permitted.
    """

    recovery_date: date
    recovery_fraction: Decimal

    def __post_init__(self) -> None:
        require_date(self.recovery_date, "recovery_date")
        fraction = require_decimal(self.recovery_fraction, "recovery_fraction", minimum=Decimal(0))
        if fraction > 1:
            raise InputValidationError("recovery_fraction cannot exceed 1")


@dataclass(frozen=True)
class DefaultEvent:
    """Full remaining-par default, with optional recoveries and final write-off.

    No coupon is collected at default. A writeoff_date explicitly settles the
    residual default claim as principal loss; the last recovery date alone
    never implies a write-off. No recoveries plus same-day write-off represents
    an explicit zero-recovery assumption. Scheduled cash executes first if its
    actual payment date equals event_date, then default hits remaining par.
    This same-day policy is a model assumption, not an agency stress convention.
    """

    loan_id: str
    event_date: date
    recoveries: tuple[RecoveryEvent, ...] = ()
    writeoff_date: date | None = None

    def __post_init__(self) -> None:
        _identifier(self.loan_id, "default loan_id")
        require_date(self.event_date, "default event_date")
        if type(self.recoveries) is not tuple or any(not isinstance(row, RecoveryEvent) for row in self.recoveries):
            raise InputValidationError("recoveries must be an immutable tuple of RecoveryEvent")
        previous: date | None = None
        total = Fraction()
        for recovery in self.recoveries:
            if recovery.recovery_date < self.event_date:
                raise InputValidationError("A recovery cannot precede default")
            if previous is not None and recovery.recovery_date <= previous:
                raise InputValidationError("Recovery dates must be unique and strictly increasing")
            previous = recovery.recovery_date
            total += Fraction(recovery.recovery_fraction)
        if total > 1:
            raise InputValidationError("Cumulative recovery fractions cannot exceed 1")
        if self.writeoff_date is not None:
            require_date(self.writeoff_date, "writeoff_date")
            if self.writeoff_date < self.event_date or (previous is not None and self.writeoff_date < previous):
                raise InputValidationError("writeoff_date cannot precede default or a scheduled recovery")


@dataclass(frozen=True)
class PrepaymentEvent:
    """Full par prepayment and cash coupon accrued to its actual event date.

    Accrual is start-inclusive/end-exclusive, uses the original current-period
    fixing, and posts once at prepayment. A contractual PIK share is explicitly
    capitalized and included in the same-date principal redemption; the cash
    share remains interest. There is no premium, penalty or inferred claim
    from an earlier missed coupon.
    Scheduled payment on the same actual date precedes the prepayment.
    """

    loan_id: str
    event_date: date

    def __post_init__(self) -> None:
        _identifier(self.loan_id, "prepayment loan_id")
        require_date(self.event_date, "prepayment event_date")


AssetCreditEvent = DefaultEvent | PrepaymentEvent


@dataclass(frozen=True)
class AssetCollection:
    """An actual scenario receipt, rather than a contractual LoanCashflow row.

    Principal is nonnegative. Cash interest may be negative for a legitimate
    negative coupon; signed cash is retained for the caller's explicit policy.
    Only scheduled receipts carry a contractual period number.
    """

    loan_id: str
    currency: str
    payment_date: date
    source: AssetCashSource
    cash_interest: Decimal
    principal_collection: Decimal
    total_cash: Decimal
    contractual_period_number: int | None = None

    def __post_init__(self) -> None:
        _identifier(self.loan_id, "collection loan_id")
        if self.currency not in {"EUR", "USD", "GBP"}:
            raise InputValidationError("Unsupported collection currency")
        require_date(self.payment_date, "collection payment_date")
        if not isinstance(self.source, AssetCashSource):
            raise InputValidationError("collection source must be AssetCashSource")
        if self.source not in {AssetCashSource.SCHEDULED, AssetCashSource.PREPAYMENT, AssetCashSource.RECOVERY}:
            raise InputValidationError("Only scheduled payments, prepayments and recoveries create collections")
        _signed_money(self.cash_interest, "collection cash_interest")
        require_money(self.principal_collection, "collection principal_collection")
        _signed_money(self.total_cash, "collection total_cash")
        if Fraction(self.total_cash) != Fraction(self.cash_interest) + Fraction(self.principal_collection):
            raise InputValidationError("Collection total_cash does not conserve cash")
        if self.source is AssetCashSource.SCHEDULED:
            if type(self.contractual_period_number) is not int or self.contractual_period_number < 1:
                raise InputValidationError("A scheduled collection requires its positive contractual period number")
        elif self.contractual_period_number is not None:
            raise InputValidationError("Only scheduled collections have contractual_period_number")
        if self.source is AssetCashSource.RECOVERY and self.cash_interest != 0:
            raise InputValidationError("This recovery increment collects principal only")


@dataclass(frozen=True)
class AssetParMovement:
    """One ordered operation in performing/defaulted principal subledgers.

    Explicit contractual PIK increases performing face without cash. Scheduled
    or prepaid principal reduces that enlarged face and supplies cash;
    default moves that face into a claim without cash or loss. Recovery reduces
    a claim by actual received principal, while write-off reduces it by loss.
    non_cash_par_change records actual capitalization once. The bridge
    deliberately rejects substituting claim valuation
    or expected recovery cash for those actual economic operations.
    """

    loan_id: str
    event_date: date
    source: AssetCashSource
    performing_par_before: Decimal
    performing_par_after: Decimal
    defaulted_par_before: Decimal
    defaulted_par_after: Decimal
    principal_receipt: Decimal
    par_loss: Decimal
    non_cash_par_change: Decimal = Decimal(0)

    def __post_init__(self) -> None:
        _identifier(self.loan_id, "movement loan_id")
        require_date(self.event_date, "movement event_date")
        if not isinstance(self.source, AssetCashSource):
            raise InputValidationError("movement source must be AssetCashSource")
        for name in ("performing_par_before", "performing_par_after", "defaulted_par_before", "defaulted_par_after", "principal_receipt", "par_loss"):
            require_money(getattr(self, name), name)
        performing_change = Fraction(self.performing_par_before) - Fraction(self.performing_par_after)
        defaulted_change = Fraction(self.defaulted_par_before) - Fraction(self.defaulted_par_after)
        cash, loss = Fraction(self.principal_receipt), Fraction(self.par_loss)
        non_cash = Fraction(require_money(self.non_cash_par_change, "movement non_cash_par_change"))
        if self.source in {AssetCashSource.SCHEDULED, AssetCashSource.PREPAYMENT}:
            valid = performing_change == cash - non_cash and defaulted_change == 0 and loss == 0
            if self.source is AssetCashSource.PREPAYMENT:
                valid = valid and cash > 0 and self.performing_par_after == 0
        elif self.source is AssetCashSource.DEFAULT:
            valid = performing_change > 0 and self.performing_par_after == 0 and defaulted_change == -performing_change and cash == loss == non_cash == 0
        elif self.source is AssetCashSource.RECOVERY:
            valid = performing_change == 0 and defaulted_change == cash and loss == non_cash == 0
        else:
            valid = performing_change == 0 and defaulted_change == loss and cash == non_cash == 0
        if not valid:
            raise InputValidationError(f"{self.source.value} par movement violates principal conservation")


@dataclass(frozen=True)
class AssetCreditProjection:
    """Auditable principal/cash state at one explicit projection horizon.

    Unrecovered defaulted principal is a claim balance, not performing collateral
    and not its market value. pending_recovery_amount reports only explicitly
    scheduled cash beyond the horizon, without inventing a terminal liquidation.
    """

    loan_id: str
    currency: str
    projection_start: date
    opening_par: Decimal
    horizon_date: date
    contractual_cashflows: tuple[LoanCashflow, ...]
    collections: tuple[AssetCollection, ...]
    par_movements: tuple[AssetParMovement, ...]
    event: AssetCreditEvent | None
    status: CreditProjectionStatus
    credit_event_applied: bool
    defaulted_exposure: Decimal
    final_performing_par: Decimal
    final_defaulted_par: Decimal
    total_scheduled_principal: Decimal
    total_prepayment_principal: Decimal
    total_recovery_principal: Decimal
    total_principal_collections: Decimal
    total_cash_interest: Decimal
    total_par_loss: Decimal
    pending_recovery_amount: Decimal
    # Kept explicit because several day-count conventions can coincide on a
    # full coupon yet disagree on an early exit. A displayed DCF is therefore
    # insufficient evidence for calculating a partial-period prepayment.
    contractual_day_count: DayCount | None = None

    @property
    def total_pik_interest(self) -> Decimal:
        """Actual capitalized face, separate from cash interest and claims."""
        return post_currency(sum((Fraction(row.non_cash_par_change) for row in self.par_movements), Fraction()))

    def __post_init__(self) -> None:
        _identifier(self.loan_id, "projection loan_id")
        if self.currency not in {"EUR", "USD", "GBP"}:
            raise InputValidationError("Unsupported credit projection currency")
        require_date(self.projection_start, "projection_start")
        require_date(self.horizon_date, "horizon_date")
        if self.horizon_date < self.projection_start:
            raise InputValidationError("horizon_date cannot precede projection_start")
        require_money(self.opening_par, "opening_par", positive=True)
        for name in ("defaulted_exposure", "final_performing_par", "final_defaulted_par", "total_scheduled_principal", "total_prepayment_principal", "total_recovery_principal", "total_principal_collections", "total_par_loss", "pending_recovery_amount"):
            require_money(getattr(self, name), name)
        _signed_money(self.total_cash_interest, "total_cash_interest")
        if not isinstance(self.status, CreditProjectionStatus) or type(self.credit_event_applied) is not bool:
            raise InputValidationError("Credit status/applied flag must use their declared types")
        if self.event is not None and not isinstance(self.event, (DefaultEvent, PrepaymentEvent)):
            raise InputValidationError("event must be DefaultEvent, PrepaymentEvent or None")
        if self.event is not None and (self.event.loan_id != self.loan_id or self.event.event_date <= self.projection_start):
            raise InputValidationError("Credit event must match the loan and strictly follow projection_start")
        if self.credit_event_applied != (self.event is not None and self.event.event_date <= self.horizon_date):
            raise InputValidationError("credit_event_applied is inconsistent with the horizon")
        for rows, row_type, label in (
            (self.contractual_cashflows, LoanCashflow, "contractual_cashflows"),
            (self.collections, AssetCollection, "collections"),
            (self.par_movements, AssetParMovement, "par_movements"),
        ):
            if type(rows) is not tuple or any(not isinstance(row, row_type) for row in rows):
                raise InputValidationError(f"{label} must be an immutable typed tuple")
            if any(row.loan_id != self.loan_id for row in rows):
                raise InputValidationError(f"{label} loan_id does not match projection")
        if not self.contractual_cashflows or any(row.currency != self.currency for row in self.contractual_cashflows):
            raise InputValidationError("Credit projection requires matching full contractual cashflows")
        if self.contractual_day_count is not None and not isinstance(self.contractual_day_count, DayCount):
            raise InputValidationError("contractual_day_count must be DayCount or None")
        self._validate_coupon_reference()
        self._validate_ledgers()

    def _validate_coupon_reference(self) -> None:
        """Check supplied day-count metadata against the complete raw coupons.

        Native projection construction already verifies terms, reset dates and
        frozen fixings. At this aggregate boundary, reuse those immutable
        segments to verify the declared convention's exact coupon economics.
        This also rejects replacing the convention alone to inflate an early
        exit, without fetching market rates or inferring rules from a DCF.
        """
        if self.contractual_day_count is None:
            return
        for row in self.contractual_cashflows:
            require_date(row.accrual_start, "contractual accrual_start")
            require_date(row.accrual_end, "contractual accrual_end")
            if row.accrual_start >= row.accrual_end:
                raise InputValidationError("Contractual coupon must have a positive accrual interval")
            if row.coupon_segments:
                boundaries = (row.accrual_start, *(segment.accrual_end for segment in row.coupon_segments))
                if tuple(segment.accrual_start for segment in row.coupon_segments) != boundaries[:-1] or boundaries[-1] != row.accrual_end:
                    raise InputValidationError("Frozen coupon segments must exactly partition the contractual accrual interval")
            require_money(row.opening_balance, "contractual opening_balance")
            exact_dcf = accrual_fraction(row.accrual_start, row.accrual_end, self.contractual_day_count)
            exact_interest = Fraction(row.opening_balance) * cashflow_coupon_factor(row, self.contractual_day_count) + row.opening_accrued_exact
            exact_pik = (exact_interest - row.opening_accrued_exact) * Fraction(row.pik_fraction)
            posted_pik = post_currency(exact_pik)
            posted_cash = post_currency(Fraction(post_currency(exact_interest)) - Fraction(posted_pik))
            if (exact_pik < 0 or row.pik_interest != posted_pik
                    or row.day_count_fraction != decimal_fraction(exact_dcf)
                    or row.interest_unrounded != decimal_fraction(exact_interest)
                    or row.cash_interest != posted_cash):
                raise InputValidationError("Contractual coupon does not match its explicit day-count and frozen rate economics")

    def _validate_ledgers(self) -> None:
        """Validate conservation again at the public aggregate-object boundary."""
        performing, defaulted = self.opening_par, Decimal(0)
        last_date = self.projection_start
        movements: dict[tuple[date, AssetCashSource], Fraction] = {}
        losses, default_transfer = Fraction(), Fraction()
        for row in self.par_movements:
            if not last_date <= row.event_date <= self.horizon_date:
                raise InputValidationError("Par movements must be chronologically ordered through the horizon")
            if row.performing_par_before != performing or row.defaulted_par_before != defaulted:
                raise InputValidationError("Par subledgers do not form a continuous opening-to-closing bridge")
            performing, defaulted, last_date = row.performing_par_after, row.defaulted_par_after, row.event_date
            key = (row.event_date, row.source)
            movements[key] = movements.get(key, Fraction()) + Fraction(row.principal_receipt)
            losses += Fraction(row.par_loss)
            if row.source is AssetCashSource.DEFAULT:
                default_transfer += Fraction(row.performing_par_before) - Fraction(row.performing_par_after)
        if performing != self.final_performing_par or defaulted != self.final_defaulted_par:
            raise InputValidationError("Final credit balances do not match par subledgers")
        if losses != Fraction(self.total_par_loss) or default_transfer != Fraction(self.defaulted_exposure):
            raise InputValidationError("Credit loss/defaulted exposure does not match par subledgers")
        by_source = {source: Fraction() for source in AssetCashSource}
        receipts: dict[tuple[date, AssetCashSource], Fraction] = {}
        interest = Fraction()
        previous_date = self.projection_start
        for row in self.collections:
            if row.currency != self.currency or not previous_date <= row.payment_date <= self.horizon_date:
                raise InputValidationError("Collections must use matching currency and ordered dates through horizon")
            previous_date = row.payment_date
            by_source[row.source] += Fraction(row.principal_collection)
            interest += Fraction(row.cash_interest)
            key = (row.payment_date, row.source)
            receipts[key] = receipts.get(key, Fraction()) + Fraction(row.principal_collection)
        if any(receipts.get(key, Fraction()) != value for key, value in movements.items()) or any(
            movements.get(key, Fraction()) != value for key, value in receipts.items()
        ):
            raise InputValidationError("Collection principal does not match dated par movements")
        principal = sum(by_source.values(), Fraction())
        expected = (
            (self.total_scheduled_principal, by_source[AssetCashSource.SCHEDULED]),
            (self.total_prepayment_principal, by_source[AssetCashSource.PREPAYMENT]),
            (self.total_recovery_principal, by_source[AssetCashSource.RECOVERY]),
            (self.total_principal_collections, principal),
            (self.total_cash_interest, interest),
        )
        if any(Fraction(declared) != actual for declared, actual in expected):
            raise InputValidationError("Credit collection totals do not match collection ledger")
        if Fraction(self.opening_par) + Fraction(self.total_pik_interest) != Fraction(performing) + Fraction(defaulted) + principal + losses:
            raise InputValidationError("Opening principal does not reconcile to closing claims, cash and losses")
        if self.pending_recovery_amount > self.final_defaulted_par:
            raise InputValidationError("Pending recovery cannot exceed remaining defaulted par")
        self._validate_event_operations()
        if self.credit_event_applied and isinstance(self.event, DefaultEvent):
            expected_status = CreditProjectionStatus.DEFAULT_UNRESOLVED if defaulted else CreditProjectionStatus.DEFAULT_RESOLVED
        elif self.credit_event_applied:
            expected_status = CreditProjectionStatus.PREPAID
        else:
            expected_status = CreditProjectionStatus.PERFORMING if performing else CreditProjectionStatus.REPAID
        if self.status is not expected_status:
            raise InputValidationError("Credit projection status does not match its balances/event")

    def _validate_event_operations(self) -> None:
        """Bind actual receipts and principal operations to the supplied event.

        Aggregate cash/par conservation proves that amounts add up; it does
        not prove that a receipt has an economic cause. In particular, adding
        a zero-principal ``PREPAYMENT`` coupon leaves the principal bridge
        unchanged. Validate the contractual prefix and each event's allowed
        receipt count/date/source as well as its principal operations so that
        a manually constructed result cannot introduce such cash.
        """
        expected_schedule = tuple(
            row for row in self.contractual_cashflows if row.payment_date <= self.horizon_date
            and (self.event is None or row.payment_date <= self.event.event_date)
        )
        actual_schedule = tuple(row for row in self.collections if row.source is AssetCashSource.SCHEDULED)
        if len(expected_schedule) != len(actual_schedule) or any(
            (contractual.period_number, contractual.payment_date, contractual.cash_interest,
             contractual.principal_repayment, contractual.total_cash)
            != (collected.contractual_period_number, collected.payment_date, collected.cash_interest,
                collected.principal_collection, collected.total_cash)
            for contractual, collected in zip(expected_schedule, actual_schedule)
        ):
            raise InputValidationError("Scheduled credit receipts must equal the contractual prefix before the event/horizon")
        # A zero-principal contractual coupon still has exactly one scheduled
        # ledger operation. Bind these rows individually, rather than accepting
        # duplicated/split/no-op operations merely because their dated sums
        # agree. Several genuine contractual periods may share one cash date;
        # their original order and separate rows remain valid.
        scheduled_operations = tuple(row for row in self.par_movements if row.source is AssetCashSource.SCHEDULED)
        if tuple((row.event_date, row.principal_receipt, row.non_cash_par_change) for row in scheduled_operations) != tuple(
            (row.payment_date, row.principal_repayment, row.pik_interest) for row in expected_schedule
        ):
            raise InputValidationError("Scheduled par operations must match each contractual prefix receipt")
        operations = tuple(row for row in self.par_movements if row.source is not AssetCashSource.SCHEDULED)
        event_receipts = tuple(row for row in self.collections if row.source is not AssetCashSource.SCHEDULED)
        if not self.credit_event_applied:
            if event_receipts or operations or self.defaulted_exposure or self.pending_recovery_amount:
                raise InputValidationError("A future/absent credit event cannot create nonscheduled receipts or change current credit subledgers")
            return
        if isinstance(self.event, PrepaymentEvent):
            if len(operations) != 1 or operations[0].source is not AssetCashSource.PREPAYMENT or operations[0].event_date != self.event.event_date:
                raise InputValidationError("Full prepayment requires exactly one matching dated par operation")
            # The full exit has one cash receipt, including its signed/zero
            # accrued coupon. Neither an extra interest-only prepayment nor a
            # recovery receipt is licensed by this event, even if it carries
            # zero principal and therefore passes the aggregate par bridge.
            if len(event_receipts) != 1 or event_receipts[0].source is not AssetCashSource.PREPAYMENT:
                raise InputValidationError("Full prepayment requires exactly one PREPAYMENT cash receipt")
            receipt = event_receipts[0]
            if receipt.payment_date != self.event.event_date or receipt.principal_collection != operations[0].principal_receipt:
                raise InputValidationError("Prepayment cash must match its explicit event date and full principal exit")
            self._validate_prepayment_coupon(receipt)
            self._validate_operation_order(expected_schedule, ((self.event.event_date, AssetCashSource.PREPAYMENT),))
            return
        if not isinstance(self.event, DefaultEvent):
            raise InputValidationError("An applied credit event is missing")
        expected_operations = [(self.event.event_date, AssetCashSource.DEFAULT)]
        expected_operations.extend(
            (recovery.recovery_date, AssetCashSource.RECOVERY) for recovery in self.event.recoveries
            if recovery.recovery_date <= self.horizon_date
        )
        if self.event.writeoff_date is not None and self.event.writeoff_date <= self.horizon_date:
            expected_operations.append((self.event.writeoff_date, AssetCashSource.WRITE_OFF))
        if tuple((row.event_date, row.source) for row in operations) != tuple(expected_operations):
            raise InputValidationError("Default operations do not match explicit default, recovery and write-off dates")
        self._validate_operation_order(expected_schedule, tuple(expected_operations))
        if any(row.source is not AssetCashSource.RECOVERY for row in event_receipts):
            raise InputValidationError("A default event creates only explicitly scheduled principal recovery receipts")
        cumulative, previously_recovered = Fraction(), Decimal(0)
        pending = Fraction()
        # Recovery dates are unique in DefaultEvent. Retain one receipt even
        # for an explicit zero or a rounded-zero installment: its existence
        # records the declared event, and a duplicate must never be accepted.
        received = iter(event_receipts)
        for recovery in self.event.recoveries:
            cumulative += Fraction(recovery.recovery_fraction)
            target = post_currency(Fraction(self.defaulted_exposure) * cumulative)
            amount = post_currency(Fraction(target) - Fraction(previously_recovered))
            previously_recovered = target
            if recovery.recovery_date > self.horizon_date:
                pending += Fraction(amount)
                continue
            row = next(received, None)
            if row is None or row.payment_date != recovery.recovery_date or row.principal_collection != amount:
                raise InputValidationError("Recovery cash must use cumulative targets on actual defaulted exposure")
        if next(received, None) is not None or Fraction(self.pending_recovery_amount) != pending:
            raise InputValidationError("Recovery ledger/future queue does not match its declared recovery schedule")

    def _validate_operation_order(
        self, scheduled: tuple[LoanCashflow, ...], event_operations: tuple[tuple[date, AssetCashSource], ...],
    ) -> None:
        """Preserve scheduled-first same-day execution, including no-op rows."""
        expected = tuple((row.payment_date, AssetCashSource.SCHEDULED) for row in scheduled) + event_operations
        if tuple((row.event_date, row.source) for row in self.par_movements) != expected:
            raise InputValidationError("Credit operations must execute contractual cash before same-day credit events")

    def _validate_prepayment_coupon(self, receipt: AssetCollection) -> None:
        """Prove the single exit coupon, rather than merely conserve its cash.

        The first unpaid contractual row supplies the original frozen reset
        segments and exact opening claim. Apply the explicit day count through
        the actual exit date and post their combined amount once. Previously
        received coupons are excluded; a same-day scheduled coupon executes
        first and therefore selects the next row with zero new accrual.
        """
        if self.contractual_day_count is None:
            raise InputValidationError("Applied prepayment requires explicit contractual_day_count metadata")
        unpaid = next((row for row in self.contractual_cashflows if row.payment_date > receipt.payment_date), None)
        if unpaid is None or not unpaid.accrual_start <= receipt.payment_date <= unpaid.accrual_end:
            raise InputValidationError("Prepayment requires a known unpaid contractual accrual interval")
        movement = next(row for row in self.par_movements if row.source is AssetCashSource.PREPAYMENT)
        if unpaid.opening_balance != movement.performing_par_before:
            raise InputValidationError("Prepayment principal must equal the unpaid coupon's remaining face")
        earned = Fraction(movement.performing_par_before) * cashflow_coupon_factor(
            unpaid, self.contractual_day_count, receipt.payment_date,
        )
        pik = post_currency(earned * Fraction(unpaid.pik_fraction))
        exact = earned + unpaid.opening_accrued_exact
        cash = post_currency(Fraction(post_currency(exact)) - Fraction(pik))
        if (receipt.cash_interest != cash or movement.non_cash_par_change != pik
                or receipt.principal_collection != post_currency(Fraction(movement.performing_par_before) + Fraction(pik))):
            raise InputValidationError("Prepayment cash interest must equal the exact contractual coupon through its event date")
