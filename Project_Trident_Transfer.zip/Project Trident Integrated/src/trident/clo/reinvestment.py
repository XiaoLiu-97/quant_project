"""Synthetic bullet reinvestment cohorts behind the normal CLO waterfall.

The template is an economic projection assumption, not a proposed live trade.
Purchases settle at the authorized waterfall date, spend principal cash once,
and earn no pre-purchase coupon. Cohorts mature at purchase + explicit rounded
calendar-month bullet WAL; legal final does not silently alter their contracts.
Newly defaulted par, recovery cash and workout loss remain separate quantities.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import date, timedelta
from decimal import Decimal
from enum import Enum
from fractions import Fraction
import heapq

from trident.conventions import DayCount, accrual_fraction
from trident.credit.models import AssetCashSource
from trident.credit.overlay import OverlayCollection, OverlayParMovement, add_calendar_months, _sum, _difference, _probability
from trident.credit.stress_rates import conditional_period_probability
from trident.domain.models import InputValidationError, require_date, require_decimal, require_money
from trident.domain.numeric import compose_floating_rate, post_currency, decimal_fraction
from trident.market.rates import RateProvider


ZERO = Decimal(0)


class ReinvestmentTestGate(str, Enum):
    """Synthetic acquisition permission; ALWAYS_REINVEST is a sensitivity."""
    STOP_ON_TEST_FAILURE = "Stop on Test Failure"
    ALWAYS_REINVEST = "Always Reinvest"


@dataclass(frozen=True)
class SyntheticReinvestmentPolicy:
    """Explicit controls B15/16, B72–81 and B131; rates are decimal fractions.

    ``bullet_wal_years`` is the template bullet maturity assumption, rounded to
    the nearest whole calendar month HALF_UP. It is not an amortizing asset's
    calculated WAL. With recycling disabled, eligible original scheduled and
    prepaid principal alone can fund purchases; recoveries and synthetic-cohort
    receipts do not. ``end_date`` is inclusive, final distributions excluded.
    """

    enabled: bool = False
    end_date: date | None = None
    reference_curve: str = "EURIBOR 3M"
    spread_bps: Decimal = Decimal("400")
    purchase_price: Decimal = Decimal("0.99")
    bullet_wal_years: Decimal = Decimal("4")
    annual_prepayment_rate: Decimal = Decimal("0.1")
    annual_default_rate: Decimal = Decimal("0.02")
    recovery_rate: Decimal = Decimal("0.6")
    recovery_lag_months: int = 6
    recycle_reinvestment_principal: bool = True
    test_gate: ReinvestmentTestGate = ReinvestmentTestGate.STOP_ON_TEST_FAILURE
    reference_floor: Decimal = ZERO
    day_count: DayCount = DayCount.ACT_360

    def __post_init__(self) -> None:
        if type(self.enabled) is not bool or type(self.recycle_reinvestment_principal) is not bool:
            raise InputValidationError("Reinvestment enable/recycle flags must be bool")
        if self.end_date is not None:
            require_date(self.end_date, "reinvestment end_date")
        if self.enabled and self.end_date is None:
            raise InputValidationError("Enabled reinvestment needs an explicit end date")
        if self.reference_curve not in {"EURIBOR 1M", "EURIBOR 3M", "EURIBOR 6M"}:
            raise InputValidationError("Synthetic reinvestment requires an explicit EURIBOR term reference")
        require_decimal(self.spread_bps, "reinvestment spread_bps", minimum=ZERO)
        require_decimal(self.reference_floor, "reinvestment reference_floor")
        require_decimal(self.purchase_price, "reinvestment purchase_price", minimum=ZERO)
        if self.purchase_price == 0:
            raise InputValidationError("Reinvestment purchase price must be positive")
        require_decimal(self.bullet_wal_years, "reinvestment bullet_wal_years", minimum=ZERO)
        if self.maturity_months <= 0:
            raise InputValidationError("Reinvestment bullet WAL must round to at least one calendar month")
        for name in ("annual_prepayment_rate", "annual_default_rate", "recovery_rate"):
            _probability(getattr(self, name), name)
        if type(self.recovery_lag_months) is not int or self.recovery_lag_months < 0:
            raise InputValidationError("Reinvestment recovery lag must be nonnegative calendar months")
        if not isinstance(self.test_gate, ReinvestmentTestGate) or not isinstance(self.day_count, DayCount):
            raise InputValidationError("Reinvestment gate/day count must use their declared enums")

    @property
    def maturity_months(self) -> int:
        """Exact HALF_UP whole-month rounding, independent of Decimal context."""
        months = Fraction(self.bullet_wal_years) * 12
        rounded = months + Fraction(1, 2)
        return rounded.numerator // rounded.denominator

    def eligible(self, payment_date: date, is_final: bool, any_failed: bool) -> bool:
        """Check the inclusive acquisition window and configured gate policy.

        This check is necessary, not proof of a real trade's compliance: the
        engine must also establish spendable cash, coupon obligations, legal
        maturity permission and any concrete post-trade eligibility rules.
        """
        require_date(payment_date, "reinvestment payment date")
        if type(is_final) is not bool or type(any_failed) is not bool:
            raise InputValidationError("Reinvestment final/failure flags must be bool")
        return bool(self.enabled and self.end_date is not None and payment_date <= self.end_date and not is_final
                    and (not any_failed or self.test_gate is ReinvestmentTestGate.ALWAYS_REINVEST))


@dataclass(frozen=True)
class ReinvestmentPurchase:
    """Dated consideration versus acquired face, with residual cash retained.

    ``purchase_price`` is a clean fraction of par (0.99 means 99%), not EUR or
    price points. Cash invested and par acquired can differ; neither should be
    substituted for the other in account or collateral conservation.
    """
    cohort_id: str
    purchase_date: date
    maturity_date: date
    available_cash: Decimal
    cash_used: Decimal
    acquired_par: Decimal
    unused_cash: Decimal
    purchase_price: Decimal

    @property
    def new_cash_invested(self) -> Decimal:
        """Return clean consideration consumed, not acquired face."""
        return self.cash_used

    @property
    def new_par_purchased(self) -> Decimal:
        """Return acquired face, not cash spent at the configured clean price."""
        return self.acquired_par


@dataclass(frozen=True)
class ReinvestmentPeriodResult:
    """Actual synthetic receipts and separate performing/defaulted face.

    Default reduces performing par but creates a default claim, not a cash
    payment. Recovery converts part of that claim to principal cash; loss
    resolves the remainder. Collections and movements retain the dates used
    by the waterfall's cutoff, cash remuneration and fee integrals.
    """
    opening_par: Decimal
    interest_cash: Decimal
    principal_cash: Decimal
    scheduled_principal: Decimal
    prepayment_principal: Decimal
    default_par: Decimal
    recovery_cash: Decimal
    losses: Decimal
    closing_par: Decimal
    defaulted_par: Decimal
    collections: tuple[OverlayCollection, ...]
    par_movements: tuple[OverlayParMovement, ...]
    reference_interest_cash: Decimal = ZERO
    spread_interest_cash: Decimal = ZERO


@dataclass(frozen=True)
class ReinvestmentDisposition:
    """Face removed at terminal sale; lifecycle owns its cash consideration."""

    disposal_date: date
    performing_par: Decimal
    defaulted_par: Decimal
    cancelled_pending_recovery: Decimal


@dataclass
class _Cohort:
    """Private state for one settled synthetic purchase, separate from price."""
    cohort_id: str
    purchase_date: date
    maturity_date: date
    original_par: Decimal
    performing_par: Decimal
    defaulted_par: Decimal = ZERO
    performing_changes: list[tuple[date, Decimal]] = field(default_factory=list)


class SyntheticReinvestmentLedger:
    """Per-run mutable state; immutable policies and dated audit outputs.

    ``project`` advances chronological intervals. ``plan_purchase`` computes
    an immutable acquisition without changing cash, face or recovery rights;
    ``commit_purchase`` adds a validated plan at the latest projected boundary.
    ``purchase`` retains the direct plan-and-commit convenience API. The
    recovery queue is a heap with no horizon or
    cohort-count truncation. Exact par-day queries include default/prepayment
    dates and purchase par independently of the cash spent to acquire it.
    """

    def __init__(self, policy: SyntheticReinvestmentPolicy, rate_provider: RateProvider) -> None:
        if not isinstance(policy, SyntheticReinvestmentPolicy):
            raise InputValidationError("policy must be SyntheticReinvestmentPolicy")
        if not callable(getattr(rate_provider, "rate", None)):
            raise InputValidationError("Reinvestment rate provider must implement rate")
        self.policy = policy
        self._rates = rate_provider
        self._cohorts: list[_Cohort] = []
        self._claims: list[tuple[date, int, _Cohort, Decimal]] = []
        self._claim_number = 0
        self._last_projected: date | None = None
        self._changes: list[tuple[date, Decimal]] = []
        self._purchases: list[ReinvestmentPurchase] = []

    @property
    def purchases(self) -> tuple[ReinvestmentPurchase, ...]:
        """Expose immutable dated purchase records without mutable cohort state."""
        return tuple(self._purchases)

    @property
    def performing_par(self) -> Decimal:
        """Return current surviving acquired face, excluding defaulted claims."""
        return _sum(cohort.performing_par for cohort in self._cohorts)

    @property
    def defaulted_par(self) -> Decimal:
        """Return unresolved claim face, before market value or recovery ratios."""
        return _sum(cohort.defaulted_par for cohort in self._cohorts)

    @property
    def pending_recovery_amount(self) -> Decimal:
        """Expected future cash from unresolved face; not currently held cash."""
        return _sum(post_currency(Fraction(par) * Fraction(self.policy.recovery_rate)) for _, _, _, par in self._claims)

    def balance_at(self, value: date) -> Decimal:
        """Return post-event purchased performing face at an arbitrary date."""
        require_date(value, "reinvestment balance date")
        return _sum(change for event_date, change in self._changes if event_date <= value)

    def long_dated_par(self, legal_final: date, date: date | None = None) -> Decimal:
        """Performing face whose bullet maturity is after legal final."""
        require_date(legal_final, "reinvestment legal final")
        if date is not None:
            require_date(date, "reinvestment long-dated snapshot date")
        return _sum(
            cohort.performing_par if date is None else _sum(change for event_date, change in cohort.performing_changes if event_date <= date)
            for cohort in self._cohorts if cohort.maturity_date > legal_final
        )

    def dispose(self, disposal_date: date | None = None) -> ReinvestmentDisposition:
        """Transfer all face/claims and cancel their future recovery rights.

        Cash is deliberately absent: the caller must post explicit performing
        and default-claim sale prices in the lifecycle cash ledger.
        """
        effective = disposal_date or self._last_projected
        if effective is None:
            if not self._cohorts:
                raise InputValidationError("Empty unprojected ledger needs an explicit disposal date")
            effective = max(cohort.purchase_date for cohort in self._cohorts)
        require_date(effective, "synthetic disposal date")
        boundary = self._last_projected or (self._cohorts[0].purchase_date if self._cohorts else None)
        if boundary is not None and effective != boundary:
            raise InputValidationError("Synthetic disposal must occur at the latest state boundary; project to the sale date first")
        performing, defaulted = self.performing_par, self.defaulted_par
        pending = self.pending_recovery_amount
        for cohort in self._cohorts:
            if cohort.performing_par:
                change = post_currency(-Fraction(cohort.performing_par))
                self._changes.append((effective, change))
                cohort.performing_changes.append((effective, change))
            cohort.performing_par = cohort.defaulted_par = ZERO
        self._claims.clear()
        return ReinvestmentDisposition(effective, performing, defaulted, pending)

    def par_days(self, start: date, end: date) -> Fraction:
        """Integrate purchased performing face over [start, end), in EUR-days.

        Additions earn from settlement; reductions stop earning from their
        actual default/prepayment date. Payment on ``end`` leaves the preceding
        interval intact. Fee denominators belong to the caller's convention.
        """
        require_date(start, "reinvestment par-day start")
        require_date(end, "reinvestment par-day end")
        if end < start:
            raise InputValidationError("Reinvestment par-day end precedes start")
        return sum((Fraction(change) * max(0, (end - max(start, event_date)).days)
                    for event_date, change in self._changes if event_date < end), Fraction())

    def plan_purchase(self, purchase_date: date, cash_amount: Decimal) -> ReinvestmentPurchase:
        """Calculate a prospective acquisition without mutating ledger state.

        Floor cash/price to cent face, then post clean consideration HALF_UP.
        The plan includes the retained cash residual, so the caller can test
        post-acquisition OC with face added and *posted cost* removed. Testing
        available cash alone, or replacing face with consideration, misses
        premium purchases and noncash collateral haircuts.

        The cohort is a bullet economic template with calendar-month maturity;
        it is not a full loan contract with its own business-day/reset rules.
        No invented accrued interest or settlement fee enters its cost. A
        rejected plan creates neither coupon entitlement nor recovery rights.
        """
        require_date(purchase_date, "synthetic purchase date")
        require_money(cash_amount, "synthetic purchase cash", positive=True)
        if self._last_projected is not None and purchase_date != self._last_projected:
            raise InputValidationError("Synthetic purchases settle only at the latest projected boundary")
        if self._last_projected is None and self._cohorts and purchase_date != self._cohorts[0].purchase_date:
            raise InputValidationError("Before the first projection, synthetic purchases must share one opening boundary")
        if not self.policy.enabled or self.policy.end_date is None or purchase_date > self.policy.end_date:
            raise InputValidationError("Synthetic purchase falls outside the enabled reinvestment period")
        raw_cents = Fraction(cash_amount) * 100 / Fraction(self.policy.purchase_price)
        par_cents = raw_cents.numerator // raw_cents.denominator
        if par_cents <= 0:
            raise InputValidationError("Available cash cannot purchase one cent of synthetic par")
        acquired = post_currency(Fraction(par_cents, 100))
        used = post_currency(Fraction(acquired) * Fraction(self.policy.purchase_price))
        if used <= 0 or used > cash_amount:
            raise InputValidationError("Synthetic consideration must be positive and cannot exceed available cash")
        identity = f"TRIDENT_REINV_{len(self._cohorts) + 1:06d}"
        maturity = add_calendar_months(purchase_date, self.policy.maturity_months)
        return ReinvestmentPurchase(identity, purchase_date, maturity, cash_amount,
                                    used, acquired, _difference(cash_amount, used),
                                    self.policy.purchase_price)

    def commit_purchase(self, purchase: ReinvestmentPurchase) -> ReinvestmentPurchase:
        """Settle an unaltered current plan exactly once, after caller approval.

        Recalculate the immutable plan against the current boundary, policy and
        next cohort ID before changing state. This rejects stale, reused or
        altered records without requiring rollback of face/recovery histories.
        Economic permissions belong to the waterfall; the ledger independently
        enforces dates and cent cash/face accounting.
        """
        if not isinstance(purchase, ReinvestmentPurchase):
            raise InputValidationError("Synthetic commit requires a ReinvestmentPurchase plan")
        # Numeric equality alone is insufficient at a typed domain boundary:
        # a forged float such as 1.0 compares equal to Decimal(1) in Python.
        # Validate the record before equality can authorize ledger mutation.
        for name in ("available_cash", "cash_used", "acquired_par", "unused_cash"):
            require_money(getattr(purchase, name), f"synthetic purchase plan {name}")
        require_decimal(purchase.purchase_price, "synthetic purchase plan purchase_price", minimum=ZERO)
        require_date(purchase.maturity_date, "synthetic purchase plan maturity_date")
        if not isinstance(purchase.cohort_id, str):
            raise InputValidationError("Synthetic purchase plan cohort_id must be text")
        expected = self.plan_purchase(purchase.purchase_date, purchase.available_cash)
        if purchase != expected:
            raise InputValidationError("Synthetic purchase plan is stale or differs from its calculated acquisition")
        cohort = _Cohort(purchase.cohort_id, purchase.purchase_date, purchase.maturity_date,
                         purchase.acquired_par, purchase.acquired_par)
        cohort.performing_changes.append((purchase.purchase_date, purchase.acquired_par))
        self._cohorts.append(cohort)
        self._changes.append((purchase.purchase_date, purchase.acquired_par))
        self._purchases.append(purchase)
        return purchase

    def purchase(self, purchase_date: date, cash_amount: Decimal) -> ReinvestmentPurchase:
        """Plan and immediately settle a direct ledger purchase.

        Callers needing a prospective financial/eligibility check must use
        ``plan_purchase`` and approve it before calling ``commit_purchase``.
        This wrapper preserves the standalone ledger API and the same posted
        cash, acquired face, maturity and audit record semantics.
        """
        return self.commit_purchase(self.plan_purchase(purchase_date, cash_amount))

    def project(self, start_date: date, end_date: date, fixing_date: date) -> ReinvestmentPeriodResult:
        """Advance existing cohorts; defaults midpoint, CPR end, bullet maturity.

        Maturity inside the note interval is honoured on its actual date. The
        selected term fixing is floored before margin, never an all-in floor.
        Recovery and writeoff are separate dated operations on the same claim.
        Unpaid default-slice coupon is lost; accrued interest is not a receipt.
        """
        for name, value in (("start_date", start_date), ("end_date", end_date), ("fixing_date", fixing_date)):
            require_date(value, name)
        if end_date <= start_date or fixing_date > start_date:
            raise InputValidationError("Synthetic interval needs positive time and a nonfuture fixing")
        if self._last_projected is not None and start_date != self._last_projected:
            raise InputValidationError("Synthetic projection intervals must be contiguous and chronological")
        if self._last_projected is None and self._cohorts and start_date != self._cohorts[0].purchase_date:
            raise InputValidationError("The first synthetic projection must start at the purchase opening boundary")
        if any(cohort.purchase_date > start_date for cohort in self._cohorts):
            raise InputValidationError("A purchased cohort cannot earn before its settlement")
        opening = self.performing_par
        opening_defaulted = self.defaulted_par
        collections: list[OverlayCollection] = []
        raw_events: list[tuple[date, int, _Cohort, AssetCashSource, Decimal, Decimal]] = []
        new_defaults = Fraction()
        reference_cash = Fraction()
        spread_cash = Fraction()
        # Resolve the shared template fixing once, only if live face accrues.
        # Face-zero cohorts may still have recovery claims but need no coupon.
        if any(cohort.performing_par for cohort in self._cohorts):
            index = require_decimal(self._rates.rate(self.policy.reference_curve.replace(" ", "_"), fixing_date), "synthetic reference rate")
            rate = compose_floating_rate(index, self.policy.spread_bps, self.policy.reference_floor)
            if rate < 0:
                raise InputValidationError("Synthetic CLO cohort does not support negative all-in coupon cash")
        else:
            rate = ZERO
            index = ZERO
        for cohort in self._cohorts:
            if not cohort.performing_par:
                continue
            finish = min(end_date, cohort.maturity_date)
            begin = max(start_date, cohort.purchase_date)
            if finish <= begin:
                raise InputValidationError("Unsettled synthetic bullet survived past its contractual maturity")
            defaulted = conditional_period_probability(self.policy.annual_default_rate, begin, finish).apply_to_par(cohort.performing_par)
            survived = _difference(cohort.performing_par, defaulted)
            midpoint = begin + timedelta(days=max(1, (finish - begin).days // 2))
            if defaulted:
                raw_events.append((midpoint, 0, cohort, AssetCashSource.DEFAULT, defaulted, ZERO))
                self._claim_number += 1
                heapq.heappush(self._claims, (add_calendar_months(midpoint, self.policy.recovery_lag_months), self._claim_number, cohort, defaulted))
                new_defaults += Fraction(defaulted)
            if finish == cohort.maturity_date:
                scheduled, prepaid = survived, ZERO
            else:
                scheduled = ZERO
                prepaid = conditional_period_probability(self.policy.annual_prepayment_rate, begin, finish).apply_to_par(survived)
            # One exact coupon posting on the surviving slice. Interest accrued
            # but not received before default is not an invented cash receipt.
            surviving_coupon = Fraction(survived) * Fraction(rate) * accrual_fraction(begin, finish, self.policy.day_count)
            interest = post_currency(surviving_coupon)
            # Attribute the same surviving-face coupon once. Post reference
            # interest, then give the rounding residual to spread; independently
            # posting both components can invent a cent of aggregate coupon.
            reference_component = post_currency(Fraction(survived)
                * Fraction(max(index, self.policy.reference_floor))
                * accrual_fraction(begin, finish, self.policy.day_count))
            reference_cash += Fraction(reference_component)
            spread_cash += Fraction(interest) - Fraction(reference_component)
            collections.append(OverlayCollection(cohort.cohort_id, "EUR", finish, AssetCashSource.SCHEDULED, interest, scheduled, _sum((interest, scheduled))))
            if scheduled:
                raw_events.append((finish, 2, cohort, AssetCashSource.SCHEDULED, scheduled, ZERO))
            if prepaid:
                raw_events.append((finish, 3, cohort, AssetCashSource.PREPAYMENT, prepaid, ZERO))
                collections.append(OverlayCollection(cohort.cohort_id, "EUR", finish, AssetCashSource.PREPAYMENT, ZERO, prepaid, prepaid))
        # Drain due workouts using a date heap. Future claims keep their actual
        # date and face even if the CLO legal horizon ends before their recovery.
        while self._claims and self._claims[0][0] <= end_date:
            recovery_date, _, cohort, claim = heapq.heappop(self._claims)
            recovered = post_currency(Fraction(claim) * Fraction(self.policy.recovery_rate))
            loss = _difference(claim, recovered)
            if recovered:
                collections.append(OverlayCollection(cohort.cohort_id, "EUR", recovery_date, AssetCashSource.RECOVERY, ZERO, recovered, recovered))
                raw_events.append((recovery_date, 1, cohort, AssetCashSource.RECOVERY, recovered, ZERO))
            if loss:
                raw_events.append((recovery_date, 1, cohort, AssetCashSource.WRITE_OFF, ZERO, loss))
        movements = []
        # Replay compiled events by actual date, default before same-day
        # recovery, then scheduled principal and CPR. Coupon receipts remain
        # separate from this face bridge and do not create performing par.
        for event_date, priority, cohort, source, amount, loss in sorted(raw_events, key=lambda item: (item[0], item[1])):
            before_p, before_d = cohort.performing_par, cohort.defaulted_par
            if source is AssetCashSource.DEFAULT:
                cohort.performing_par = _difference(before_p, amount)
                cohort.defaulted_par = _sum((before_d, amount))
                self._changes.append((event_date, post_currency(-Fraction(amount))))
                cohort.performing_changes.append((event_date, post_currency(-Fraction(amount))))
                receipt = ZERO
            elif source in {AssetCashSource.SCHEDULED, AssetCashSource.PREPAYMENT}:
                cohort.performing_par = _difference(before_p, amount)
                self._changes.append((event_date, post_currency(-Fraction(amount))))
                cohort.performing_changes.append((event_date, post_currency(-Fraction(amount))))
                receipt = amount
            elif source is AssetCashSource.RECOVERY:
                cohort.defaulted_par = _difference(before_d, amount)
                receipt = amount
            else:
                cohort.defaulted_par = _difference(before_d, loss)
                receipt = ZERO
            movements.append(OverlayParMovement(cohort.cohort_id, event_date, source, before_p, cohort.performing_par, before_d, cohort.defaulted_par, receipt, loss))
        self._last_projected = end_date
        scheduled = _sum(row.principal_collection for row in collections if row.source is AssetCashSource.SCHEDULED)
        prepaid = _sum(row.principal_collection for row in collections if row.source is AssetCashSource.PREPAYMENT)
        recovered = _sum(row.principal_collection for row in collections if row.source is AssetCashSource.RECOVERY)
        losses = _sum(row.par_loss for row in movements)
        # Three independent invariants catch cash/par substitution: performing
        # exits; default claim resolution; heap claims versus unresolved face.
        if Fraction(opening) != Fraction(self.performing_par) + Fraction(scheduled) + Fraction(prepaid) + new_defaults:
            raise ArithmeticError("Synthetic performing principal bridge fails")
        if Fraction(opening_defaulted) + new_defaults != Fraction(self.defaulted_par) + Fraction(recovered) + Fraction(losses):
            raise ArithmeticError("Synthetic default claim/recovery/loss bridge fails")
        if sum((Fraction(claim) for _, _, _, claim in self._claims), Fraction()) != Fraction(self.defaulted_par):
            raise ArithmeticError("Synthetic pending claims must reconcile to outstanding defaulted face")
        return ReinvestmentPeriodResult(
            opening, _sum(row.cash_interest for row in collections), _sum((scheduled, prepaid, recovered)),
            scheduled, prepaid, post_currency(new_defaults), recovered, losses, self.performing_par,
            self.defaulted_par, tuple(sorted(collections, key=lambda row: (row.payment_date, row.loan_id, row.source.value))),
            tuple(movements),
            decimal_fraction(reference_cash), decimal_fraction(spread_cash),
        )
