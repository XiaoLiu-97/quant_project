"""Independent cash, claim and exact-coupon oracles from the financial review.

Expected values follow simple loan cash budgets, rather than repeating the
production hazard, queue or waterfall implementation. Default is not a cash
receipt and pre-default unpaid interest is excluded from the generic recovery.
"""

from dataclasses import replace
from datetime import date, timedelta
from decimal import Decimal
from fractions import Fraction
import unittest

from trident.application.imported_cashflows import (
    CollateralCashflowInputMode, DetailedImportedCashflow,
    compile_imported_cashflows,
)
from trident.clo.reinvestment import SyntheticReinvestmentLedger, SyntheticReinvestmentPolicy
from trident.clo import CloRunRequest, CloTerms, DefaultedAssetOcTreatment, DeterministicCloEngine, NoteTranche
from trident.conventions import AccrualDateBasis, BusinessDayConvention, DayCount
from trident.credit.models import AssetCashSource
from trident.credit.overlay import OriginalPoolOverlay, project_fractional_period
from trident.domain.models import CouponType, InputValidationError, LoanCashflow
from trident.market.rates import FlatRateProvider


D = Decimal
START = date(2025, 1, 1)
END = date(2026, 1, 1)


def contractual(opening="100", coupon="10", unrounded="10", *, principal=None):
    """One complete cash-pay year, with ACT/365F fixed 10% coupons."""
    amount = D(opening)
    repayment = amount if principal is None else D(principal)
    return LoanCashflow(
        loan_id="L1", currency="EUR", period_number=1,
        unadjusted_start=START, unadjusted_end=END,
        accrual_start=START, accrual_end=END, payment_date=END,
        fixing_date=None, opening_balance=amount, index_rate=None,
        spread_bps=D(0), all_in_rate=D("0.1"), day_count_fraction=D(1),
        interest_unrounded=D(unrounded), cash_interest=D(coupon),
        principal_repayment=repayment, closing_balance=amount-repayment,
        total_cash=D(coupon)+repayment,
    )


def imported(*rows):
    return compile_imported_cashflows(CollateralCashflowInputMode.DETAILED, START,
                                     D(100), detailed_rows=tuple(rows))


def external(policy, source, horizon=END):
    return policy.project_external(source.collections, source.par_movements,
                                   source.loan_opening_par, START, horizon)


def book(**changes):
    values = dict(enabled=True, end_date=date(2030, 1, 1), purchase_price=D(1),
                  bullet_wal_years=D(1), spread_bps=D(1000),
                  annual_default_rate=D(0), annual_prepayment_rate=D(0),
                  recovery_rate=D(0), recovery_lag_months=0,
                  day_count=DayCount.ACT_365F)
    values.update(changes)
    ledger = SyntheticReinvestmentLedger(SyntheticReinvestmentPolicy(**values),
                                        FlatRateProvider({"EURIBOR_3M": D(0)}))
    ledger.purchase(START, D(100))
    return ledger


class ActualDefaultReceiptTests(unittest.TestCase):
    def test_actual_coupon_budget_reaches_clo_ic_and_equity_for_both_sources(self):
        terms = CloTerms(START, END, frequency_months=12,
                         business_day_convention=BusinessDayConvention.UNADJUSTED,
                         accrual_date_basis=AccrualDateBasis.UNADJUSTED,
                         defaulted_asset_oc_treatment=DefaultedAssetOcTreatment.EXCLUDE,
                         original_pool_overlay=OriginalPoolOverlay(True, D("0.2"), D(0), D(0), 0))
        note = NoteTranche("A", 1, D(60), CouponType.FIXED,
                           fixed_rate=D("0.1"), day_count=DayCount.ACT_365F,
                           ic_minimum=D(1))
        source = imported(DetailedImportedCashflow("L1", 1, END, D(100),
                                                   D(10), D(100), D(0), D(110)))
        for imported_source in (None, source):
            with self.subTest(imported=imported_source is not None):
                request = CloRunRequest((contractual(),) if imported_source is None else (),
                                        D(100), (note,), terms,
                                        imported_collateral=imported_source,
                                        asset_day_counts={"L1": DayCount.ACT_365F} if imported_source is None else None)
                result = DeterministicCloEngine(FlatRateProvider({})).run(request)
                period = result.periods[0]
                gate = next(row for row in result.coverage_tests if row.stage == "GATE")
                # Assetcash8interest+80principal. Note receives6interest+60par,
                # leaving22equity. Coverage must see8/6, rather than9/6.
                self.assertEqual((period.received_asset_interest, period.received_asset_principal), (8, 80))
                self.assertEqual((gate.ic_numerator, gate.ic_denominator), (8, 6))
                self.assertEqual(result.total_equity_distributions, 22)
                self.assertTrue(all(row.cash_conservation_residual == 0 for row in result.periods))

    def test_native_zero_recovery_full_default_receives_no_coupon(self):
        result = OriginalPoolOverlay(True, D(1), D(0), D(0), 0).project(
            (contractual(),), {"L1": D(100)}, START, END,
            loan_day_counts={"L1": DayCount.ACT_365F})
        self.assertEqual(sum(r.total_cash for r in result.collections), 0)
        self.assertEqual(result.total_par_loss, 100)
        self.assertEqual(result.final_defaulted_par, 0)

    def test_native_recovery_is_principal_without_unpaid_interest(self):
        result = OriginalPoolOverlay(True, D(1), D(0), D("0.4"), 0).project(
            (contractual(),), {"L1": D(100)}, START, END)
        self.assertEqual(sum(r.cash_interest for r in result.collections), 0)
        self.assertEqual(sum(r.principal_collection for r in result.collections), 40)
        self.assertEqual(result.total_par_loss, 60)

    def test_imported_full_default_receives_only_supplied_recovery_assumption(self):
        source = imported(DetailedImportedCashflow("L1", 1, END, D(100),
                                                   D(10), D(100), D(0), D(110)))
        result = external(OriginalPoolOverlay(True, D(1), D(0), D("0.4"), 0), source)
        self.assertEqual(sum(r.cash_interest for r in result.collections), 0)
        self.assertEqual(sum(r.total_cash for r in result.collections), 40)

    def test_synthetic_zero_recovery_full_default_receives_no_coupon(self):
        ledger = book(annual_default_rate=D(1))
        result = ledger.project(START, END, START)
        self.assertEqual((result.interest_cash, result.principal_cash, result.losses),
                         (0, 0, 100))

    def test_partial_default_scheduled_and_prepayment_budget(self):
        result = project_fractional_period(
            opening_par=D(100), contractual_opening_par=D(100),
            contractual_interest=D(10), contractual_principal=D(10),
            default_amount=D(20), prepayment_rate=D("0.5"),
            start_date=START, end_date=END)
        # Default20; remaining80 pays scheduled8 and prepaid36, leaves36.
        # The entire survivor80 earns10%; default20 provides no interest cash.
        self.assertEqual((result.default_par, result.scheduled_principal,
                          result.prepayment_principal, result.closing_par,
                          result.cash_interest), (20, 8, 36, 36, 8))

    def test_synthetic_partial_default_and_prepay_only_pay_survivor_coupon(self):
        ledger = book(bullet_wal_years=D(4), annual_default_rate=D("0.2"),
                      annual_prepayment_rate=D("0.5"), recovery_rate=D("0.4"))
        result = ledger.project(START, END, START)
        # 80 survives, prepays40; default20 recovers8 and loses12.
        self.assertEqual((result.interest_cash, result.principal_cash,
                          result.closing_par, result.losses), (8, 48, 40, 12))

    def test_recovery_past_horizon_retains_claim_without_terminal_cash(self):
        result = OriginalPoolOverlay(True, D(1), D(0), D("0.4"), 24).project(
            (contractual(),), {"L1": D(100)}, START, END)
        self.assertEqual((result.final_performing_par, result.final_defaulted_par,
                          result.pending_recovery_amount, result.total_par_loss),
                         (0, 100, 40, 0))
        self.assertEqual(sum(r.total_cash for r in result.collections), 0)

    def test_pending_zero_recovery_claim_is_not_discarded_before_workout(self):
        source = imported(DetailedImportedCashflow("L1", 1, END, D(100),
                                                   D(10), D(100), D(0), D(110)))
        result = external(OriginalPoolOverlay(True, D(1), D(0), D(0), 24), source)
        self.assertEqual((result.final_defaulted_par, result.pending_recovery_amount,
                          result.total_par_loss), (100, 0, 0))


class ImportedReferenceBoundaryTests(unittest.TestCase):
    def test_closing_date_cash_has_no_before_closing_credit_exposure(self):
        source = imported(
            DetailedImportedCashflow("L1", 1, START, D(100), D(2), D(10), D(90), D(12)),
            DetailedImportedCashflow("L1", 2, END, D(90), D(9), D(90), D(0), D(99)))
        result = external(OriginalPoolOverlay(True, D(1), D(0), D(0), 0), source)
        # Closing cash is already received: 2interest+10principal retained.
        # Remaining90 defaults before the later coupon; no later interest cash.
        self.assertEqual(sum(r.total_cash for r in result.collections), 12)
        self.assertEqual(result.total_par_loss, 90)

    def test_zero_face_later_interest_receivable_is_retained_without_stress(self):
        source = imported(
            DetailedImportedCashflow("L1", 1, date(2025, 6, 1), D(100), D(10), D(100), D(0), D(110)),
            DetailedImportedCashflow("L1", 2, END, D(0), D(2), D(0), D(0), D(2)))
        result = external(OriginalPoolOverlay(True, D(0), D(0), D(0), 0), source)
        self.assertEqual(sum(r.total_cash for r in result.collections), 112)
        self.assertEqual(result.final_performing_par, 0)

    def test_delayed_interest_with_changed_entitlement_is_explicitly_rejected(self):
        source = imported(
            DetailedImportedCashflow("L1", 1, date(2025, 6, 1), D(100), D(10), D(100), D(0), D(110)),
            DetailedImportedCashflow("L1", 2, END, D(0), D(2), D(0), D(0), D(2)))
        with self.assertRaisesRegex(InputValidationError, "receivable entitlement"):
            external(OriginalPoolOverlay(True, D("0.2"), D(0), D(0), 0), source)

    def test_unpaid_known_source_interval_still_defaults_before_short_horizon(self):
        source = imported(DetailedImportedCashflow("L1", 1, END, D(100),
                                                   D(10), D(100), D(0), D(110)))
        horizon = date(2025, 4, 2)
        result = external(OriginalPoolOverlay(True, D(1), D(0), D(0), 0), source, horizon)
        self.assertEqual((result.final_performing_par, result.total_par_loss), (0, 100))
        self.assertFalse(result.collections)
        self.assertEqual(result.par_movements[0].event_date, date(2025, 2, 15))

    def test_incomplete_nonzero_stress_reference_rejected(self):
        source = imported(DetailedImportedCashflow("L1", 1, END, D(100),
                                                   D(10), D(20), D(80), D(30)))
        for cdr, cpr in ((D("0.2"), D(0)), (D(0), D("0.1"))):
            with self.subTest(cdr=cdr, cpr=cpr):
                with self.assertRaisesRegex(InputValidationError, "complete future principal reference"):
                    external(OriginalPoolOverlay(True, cdr, cpr, D(0), 0), source)

    def test_incomplete_source_without_stress_preserves_actual_cash(self):
        source = imported(DetailedImportedCashflow("L1", 1, END, D(100),
                                                   D(10), D(20), D(80), D(30)))
        result = external(OriginalPoolOverlay(False), source)
        self.assertEqual((result.final_performing_par, sum(r.total_cash for r in result.collections)),
                         (80, 30))

    def test_stressed_source_cannot_receive_second_credit_overlay(self):
        with self.assertRaisesRegex(InputValidationError, "Already stressed"):
            compile_imported_cashflows(CollateralCashflowInputMode.DETAILED, START,
                D(100), detailed_rows=(DetailedImportedCashflow("L1", 1, END,
                D(100), D(10), D(100), D(0), D(110)),),
                credit_effects_included=True, overlay_enabled=True)


class ExactCouponAndDisposalTests(unittest.TestCase):
    def test_overlay_public_result_rejects_false_final_par(self):
        result = OriginalPoolOverlay(False).project((contractual(),), {"L1": D(100)}, START, END)
        with self.assertRaisesRegex(InputValidationError, "final balances"):
            replace(result.assets[0], final_performing_par=D(1))

    def test_overlay_public_pool_rejects_omitted_actual_receipt(self):
        result = OriginalPoolOverlay(False).project((contractual(),), {"L1": D(100)}, START, END)
        with self.assertRaisesRegex(InputValidationError, "identified asset ledgers"):
            replace(result, collections=())

    def test_survivor_coupon_does_not_scale_already_rounded_cent(self):
        # Full reference accrues half a cent, posted0.01; surviving half
        # accrues quarter of a cent, posted0.00, not half of posted0.01.
        result = project_fractional_period(
            opening_par=D(1), contractual_opening_par=D(1),
            contractual_interest=D("0.01"), contractual_principal=D(1),
            default_amount=D("0.5"), prepayment_rate=D(0),
            start_date=START, end_date=END,
            contractual_interest_unrounded=Fraction(1, 200))
        self.assertEqual(result.cash_interest, 0)

    def test_native_exact_day_count_transport_posts_one_survivor_coupon(self):
        row = replace(contractual("1", "0.01", "0.005"), all_in_rate=D("0.005"))
        result = OriginalPoolOverlay(True, D("0.5"), D(0), D(0), 0).project(
            (row,), {"L1": D(1)}, START, END,
            loan_day_counts={"L1": DayCount.ACT_365F})
        self.assertEqual(sum(r.cash_interest for r in result.collections), 0)
        self.assertEqual(sum(r.principal_collection for r in result.collections), D("0.50"))

    def test_exact_day_count_metadata_must_cover_each_loan(self):
        with self.assertRaisesRegex(InputValidationError, "every loan"):
            OriginalPoolOverlay().project((contractual(),), {"L1": D(100)},
                                         START, END, loan_day_counts={})

    def test_disposal_cannot_create_negative_historical_balance_before_purchase(self):
        ledger = book()
        with self.assertRaisesRegex(InputValidationError, "latest state boundary"):
            ledger.dispose(START-timedelta(days=1))
        self.assertEqual(ledger.balance_at(START-timedelta(days=1)), 0)
        self.assertEqual(ledger.performing_par, 100)

    def test_future_disposal_cannot_remove_current_exposure_early(self):
        ledger = book(bullet_wal_years=D(4))
        ledger.project(START, date(2025, 4, 1), START)
        with self.assertRaisesRegex(InputValidationError, "project to the sale date first"):
            ledger.dispose(date(2025, 7, 1))
        self.assertEqual(ledger.performing_par, 100)
        ledger.dispose(date(2025, 4, 1))
        self.assertEqual(ledger.balance_at(date(2025, 3, 31)), 100)
        self.assertEqual(ledger.balance_at(date(2025, 4, 1)), 0)


if __name__ == "__main__":
    unittest.main()
