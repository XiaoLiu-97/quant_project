"""Standalone credit stress compilers, without borrower or CLO simulation.

An annual conditional probability acts on surviving performing exposure. A
fixed cumulative default vector distributes an explicit *amount* over dates.
These are different quantities and must never share an ambiguous rate input.

Hazard time is ACT/365F, independent of a loan's coupon day count. Fractional
powers are generally irrational: display values use at least 80 decimal digits,
while monetary application refines certified ln/exp rounding bounds until both
bounds post to the same cent. Precision exhaustion raises instead of choosing
an uncertain cent. No agency calibration is implied by either compiler.
"""

from dataclasses import dataclass
from datetime import date
from decimal import (
    Context, Decimal, MAX_EMAX, MIN_EMIN, ROUND_CEILING, ROUND_FLOOR,
    ROUND_HALF_EVEN, localcontext,
)
from enum import Enum
from fractions import Fraction
from functools import lru_cache

from trident.domain.models import InputValidationError, require_date, require_decimal, require_money
from trident.domain.numeric import post_currency


_MIN_PRECISION = 80
_MAX_PRECISION = 10000
_EXACT_POWER_DIGIT_LIMIT = 100000
_ONE = Fraction(1)


class CreditRatePrecisionError(ArithmeticError):
    """The configured precision limit cannot determine a monetary posting."""


def _context(precision: int, rounding: str = ROUND_HALF_EVEN) -> Context:
    return Context(prec=precision, rounding=rounding, Emax=MAX_EMAX, Emin=MIN_EMIN)


def _decimal(value: Fraction, precision: int, rounding: str = ROUND_HALF_EVEN) -> Decimal:
    """Convert inside an owned context, unaffected by caller precision/traps."""
    with localcontext(_context(precision, rounding)):
        return Decimal(value.numerator) / Decimal(value.denominator)


def _initial_precision(annual: Decimal, par: Decimal | None = None) -> int:
    """Retain tiny hazard tails and the cents of even very large exposures."""
    # Subtracting a tiny finite probability from one must retain its full tail.
    parts = annual.as_tuple()
    precision = max(_MIN_PRECISION, max(len(parts.digits), max(0, -parts.exponent)) + 40)
    if par is not None:
        precision = max(precision, par.adjusted() + 1 + _MIN_PRECISION)
    if precision > _MAX_PRECISION:
        raise CreditRatePrecisionError("Credit probability requires more than 10000 significant digits")
    return precision


def _integer_root(value: int, degree: int) -> int:
    """Floor integer nth root by Newton iteration, avoiding floating estimates."""
    if value <= 1 or degree == 1:
        return value
    root = 1 << ((value.bit_length() + degree - 1) // degree)
    while True:
        updated = ((degree - 1) * root + value // root ** (degree - 1)) // degree
        if updated >= root:
            break
        root = updated
    if root ** degree > value:
        root -= 1
    return root


def _exact_probability(annual: Decimal, elapsed: Fraction) -> Fraction | None:
    """Keep endpoint and rational-root ties exact; bound other powers below."""
    if elapsed == 0 or annual == 0:
        return Fraction()
    if annual == 1:
        return _ONE
    survival = _ONE - Fraction(annual)
    denominator = elapsed.denominator
    numerator_root = _integer_root(survival.numerator, denominator)
    denominator_root = _integer_root(survival.denominator, denominator)
    if numerator_root ** denominator != survival.numerator or denominator_root ** denominator != survival.denominator:
        return None
    # Very long dates/tails can make even a rational exact power uneconomic.
    # Fall back to the same interval certificate rather than construct it.
    estimated_digits = max(numerator_root.bit_length(), denominator_root.bit_length()) * elapsed.numerator
    if estimated_digits > _EXACT_POWER_DIGIT_LIMIT * 3:
        return None
    return _ONE - Fraction(numerator_root, denominator_root) ** elapsed.numerator


@lru_cache(maxsize=128)
def _probability_bounds(annual: Decimal, elapsed: Fraction, precision: int) -> tuple[Fraction, Fraction]:
    """Enclose the true probability using correctly rounded Decimal ln/exp.

    ln and exp are documented as correctly rounded HALF_EVEN. Neighbouring
    representable values enclose their exact results. Rational multiplication
    retains those bounds; directed conversion encloses the exp arguments.
    Decimal.power is deliberately avoided (its C result is only almost always
    correctly rounded). Bound endpoints, not a rounded display, drive posting.

    Many assets share an annual rate, calendar interval and required precision.
    Reuse those immutable mathematical bounds, never a rounded monetary exit:
    each exposure still multiplies and resolves its own cent posting. The cache
    is bounded and contains no portfolio, market-provider or scenario state.
    """
    exact = _exact_probability(annual, elapsed)
    if exact is not None:
        return exact, exact
    own_context = _context(precision)
    with localcontext(own_context) as context:
        survival = _decimal(_ONE - Fraction(annual), precision)
        # Initial precision retains every finite digit of 1 - annual.
        if Fraction(survival) != _ONE - Fraction(annual):
            raise CreditRatePrecisionError("Annual survival was rounded before hazard calculation")
        logarithm = survival.ln()
        log_lower = Fraction(logarithm.next_minus(context=context))
        log_upper = Fraction(logarithm.next_plus(context=context))
        exponent_lower = _decimal(log_lower * elapsed, precision, ROUND_FLOOR)
        exponent_upper = _decimal(log_upper * elapsed, precision, ROUND_CEILING)
        survival_lower = exponent_lower.exp().next_minus(context=context)
        survival_upper = exponent_upper.exp().next_plus(context=context)
        # Very remote horizons need not create an enormous Fraction denominator.
        epsilon = Decimal((0, (1,), -precision))
        if survival_upper < epsilon:
            return _ONE - Fraction(epsilon), _ONE
        lower = max(Fraction(), _ONE - Fraction(survival_upper))
        upper = min(_ONE, _ONE - Fraction(max(Decimal(0), survival_lower)))
        if lower > upper:
            raise CreditRatePrecisionError("Credit probability interval is inconsistent")
        return lower, upper


@dataclass(frozen=True)
class PeriodProbability:
    """Conditional CDR/CPR conversion over exact calendar days / 365.

    At elapsed zero the result is zero, including annual=1 (no 0**0).
    A positive interval with annual=1 exits all exposed par. This does not
    determine default-vs-prepayment ordering or calibrate either input.
    """

    annual_probability: Decimal
    start_date: date
    end_date: date

    def __post_init__(self) -> None:
        probability = require_decimal(self.annual_probability, "annual_probability", minimum=Decimal(0))
        if probability > 1:
            raise InputValidationError("annual_probability must be <= 1")
        require_date(self.start_date, "start_date")
        require_date(self.end_date, "end_date")
        if self.end_date < self.start_date:
            raise InputValidationError("end_date must not precede start_date")

    @property
    def elapsed_years(self) -> Fraction:
        """ACT/365F hazard time; coupon conventions do not enter this value."""
        return Fraction((self.end_date - self.start_date).days, 365)

    @property
    def probability(self) -> Decimal:
        """High-precision diagnostic; use apply_to_par for cent postings."""
        if self.elapsed_years == 0 or self.annual_probability == 0:
            return Decimal(0)
        if self.annual_probability == 1:
            return Decimal(1)
        precision = _initial_precision(self.annual_probability)
        lower, upper = _probability_bounds(self.annual_probability, self.elapsed_years, precision)
        return _decimal((lower + upper) / 2, precision)

    def apply_to_par(self, performing_par: Decimal) -> Decimal:
        """Post an exit amount to cents only when its rounding is resolved.

        The caller supplies current performing par, after any earlier exits.
        No clipping, asset allocation, default event, or reinvestment occurs.
        """
        require_money(performing_par, "performing_par")
        if not performing_par:
            return Decimal("0.00")
        if self.elapsed_years == 0 or self.annual_probability == 0:
            return Decimal("0.00")
        if self.annual_probability == 1:
            return post_currency(Fraction(performing_par))
        precision = _initial_precision(self.annual_probability, performing_par)
        balance = Fraction(performing_par)
        while True:
            lower, upper = _probability_bounds(self.annual_probability, self.elapsed_years, precision)
            posted_lower = post_currency(balance * lower)
            posted_upper = post_currency(balance * upper)
            if posted_lower == posted_upper:
                return posted_lower
            if precision >= _MAX_PRECISION:
                raise CreditRatePrecisionError("Credit exit amount straddles a half-cent at the 10000-digit precision limit")
            precision = min(_MAX_PRECISION, precision * 2)


def conditional_period_probability(
    annual_probability: Decimal, start_date: date, end_date: date,
) -> PeriodProbability:
    """Compile an ACT/365F conditional probability, never a cumulative vector."""
    return PeriodProbability(annual_probability, start_date, end_date)


class CapacityPolicy(str, Enum):
    """Choose whether an unattainable fixed default target raises or is shown."""
    REJECT = "REJECT"
    REPORT_SHORTFALL = "REPORT_SHORTFALL"


class DefaultVectorStatus(str, Enum):
    """Feasibility of the requested amount, independent of simulated losses."""
    COMPLETE = "COMPLETE"
    TARGET_NOT_REACHED = "TARGET_NOT_REACHED"


@dataclass(frozen=True)
class DefaultVectorPeriod:
    """A half-open stress interval and fraction of a fixed target amount.

    capacity is the externally supplied amount available for default *in this
    interval*, not opening par. The compiler does not infer asset state or shift
    unused capacity between periods. Boundaries are explicit calendar dates.
    """

    start_date: date
    end_date: date
    weight: Fraction | Decimal
    capacity: Decimal | None = None

    def __post_init__(self) -> None:
        require_date(self.start_date, "default vector start_date")
        require_date(self.end_date, "default vector end_date")
        if self.end_date <= self.start_date:
            raise InputValidationError("Default vector periods must have positive elapsed time")
        if not isinstance(self.weight, (Fraction, Decimal)):
            raise InputValidationError("Default vector weight must be Fraction or finite Decimal")
        if isinstance(self.weight, Decimal):
            require_decimal(self.weight, "default vector weight", minimum=Decimal(0))
        if not 0 <= Fraction(self.weight) <= 1:
            raise InputValidationError("Default vector weight must lie in [0, 1]")
        if self.capacity is not None:
            require_money(self.capacity, "default vector capacity")


@dataclass(frozen=True)
class DefaultVectorAllocation:
    """Requested versus executable default amount for one capacity interval."""
    start_date: date
    end_date: date
    weight: Fraction
    requested_amount: Decimal
    allocated_amount: Decimal
    shortfall_amount: Decimal
    capacity: Decimal | None


@dataclass(frozen=True)
class DefaultVectorCompilation:
    """Compiled dated allocations and explicit unallocated target; not cash."""
    total_target_amount: Decimal
    total_allocated_amount: Decimal
    total_shortfall_amount: Decimal
    status: DefaultVectorStatus
    periods: tuple[DefaultVectorAllocation, ...]


class DefaultVectorCapacityError(InputValidationError):
    """Requested timing cannot be achieved with the supplied period capacities."""

    def __init__(self, compilation: DefaultVectorCompilation) -> None:
        self.compilation = compilation
        super().__init__(f"Default vector target not reached: capacity shortfall {compilation.total_shortfall_amount}")


@dataclass(frozen=True)
class FixedCumulativeDefaultVector:
    """Distribute a cent target exactly using largest remainders, O(n log n).

    Weights must sum to one exactly. Dates must be chronological and contiguous.
    Fractional cents go to largest remainders; equal remainders go to the earlier
    period. Capacity failure is reported or rejected, never silently clipped or
    reassigned. No agency-specific timing profile is embedded as a default.
    """

    total_default_amount: Decimal
    periods: tuple[DefaultVectorPeriod, ...]
    capacity_policy: CapacityPolicy = CapacityPolicy.REJECT

    def __post_init__(self) -> None:
        require_money(self.total_default_amount, "total_default_amount")
        if type(self.periods) is not tuple or not self.periods or any(not isinstance(item, DefaultVectorPeriod) for item in self.periods):
            raise InputValidationError("Default vector periods must be a nonempty immutable tuple")
        if not isinstance(self.capacity_policy, CapacityPolicy):
            raise InputValidationError("capacity_policy must be CapacityPolicy")
        if sum((Fraction(item.weight) for item in self.periods), Fraction()) != 1:
            raise InputValidationError("Default vector weights must sum exactly to one")
        if any(current.start_date != prior.end_date for prior, current in zip(self.periods, self.periods[1:])):
            raise InputValidationError("Default vector periods must be ordered, contiguous and non-overlapping")

    def compile(self) -> DefaultVectorCompilation:
        """Return requested allocations and explicit feasibility, without events."""
        target_cents = int(Fraction(self.total_default_amount) * 100)
        raw = tuple(target_cents * Fraction(period.weight) for period in self.periods)
        cents = [amount.numerator // amount.denominator for amount in raw]
        missing_cents = target_cents - sum(cents)
        priorities = sorted(range(len(raw)), key=lambda index: (-(raw[index] - cents[index]), index))
        for index in priorities[:missing_cents]:
            cents[index] += 1
        allocations: list[DefaultVectorAllocation] = []
        for period, amount_cents in zip(self.periods, cents):
            requested = post_currency(Fraction(amount_cents, 100))
            allocated = requested if period.capacity is None else min(requested, period.capacity)
            shortfall = post_currency(Fraction(requested) - Fraction(allocated))
            allocations.append(DefaultVectorAllocation(
                period.start_date, period.end_date, Fraction(period.weight),
                requested, allocated, shortfall, period.capacity,
            ))
        total_allocated = post_currency(sum((Fraction(item.allocated_amount) for item in allocations), Fraction()))
        total_shortfall = post_currency(sum((Fraction(item.shortfall_amount) for item in allocations), Fraction()))
        if Fraction(total_allocated) + Fraction(total_shortfall) != Fraction(self.total_default_amount):
            raise ArithmeticError("Default vector compilation does not conserve its target")
        result = DefaultVectorCompilation(
            self.total_default_amount, total_allocated, total_shortfall,
            DefaultVectorStatus.TARGET_NOT_REACHED if total_shortfall else DefaultVectorStatus.COMPLETE,
            tuple(allocations),
        )
        if total_shortfall and self.capacity_policy is CapacityPolicy.REJECT:
            raise DefaultVectorCapacityError(result)
        return result
