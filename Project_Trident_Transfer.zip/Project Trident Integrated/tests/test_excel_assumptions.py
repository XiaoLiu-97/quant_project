"""Named Excel end-to-end acceptance for the complete assumption interface."""

from datetime import date
from decimal import Decimal
from pathlib import Path
import tempfile
import unittest

from openpyxl import load_workbook
from workbook_fixtures import copy_input_template
from trident.adapters import excel_schema as schema
from trident.adapters.excel import NamedWorkbook, run_workbook
from trident.adapters.legacy_inputs import LEGACY_ASSUMPTIONS
from trident.adapters.legacy_layout import LEGACY_ASSUMPTION_GROUPS
from trident.domain.models import InputValidationError
from test_assumption_execution import small_inputs

ROOT=Path(__file__).resolve().parents[1]
# A frozen input template is independent of the user's open/edited model.
# Tests copy it and run calculations themselves; released outputs are not an
# automatic financial oracle. Provenance lives beside the fixture.
D=Decimal


class ExcelInterfaceTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.path=Path(self.temp.name)/'model.xlsx'
        copy_input_template(self.path)

    def access(self,callback,save=False):
        book=load_workbook(self.path)
        try:
            result=callback(NamedWorkbook(book))
            if save:book.save(self.path)
            return result
        finally:book.close()

    @staticmethod
    def table(adapter,key):
        return adapter.table_records(schema.TABLE_RANGE_NAMES[key],schema.TABLE_NAMES[key])

    @staticmethod
    def put(adapter,key,records):
        sheet,(left,top,right,_)=adapter.region(schema.TABLE_RANGE_NAMES[key])
        headers=tuple(sheet.cell(top,column).value for column in range(left,right+1))
        adapter.write_table(schema.TABLE_RANGE_NAMES[key],schema.TABLE_NAMES[key],
            tuple({field:record.get(field) for field in headers} for record in records))

    def small(self,**overrides):
        assets,capital,controls,factors,_=small_inputs(**overrides)
        def edit(a):
            self.put(a,'assets',assets);self.put(a,'capital_stack',capital)
            self.put(a,'factor_mapping',factors);self.put(a,'portfolio_limits',())
            for key in schema.READ_INPUT_KEYS:
                if key in controls:a.write_scalar(schema.SCALAR_NAMES[key],controls[key])
            a.write_scalar(schema.SCALAR_NAMES['scenario_enabled'],False)
        self.access(edit,True)

    def test_all107_inputs_and_three_derived_displays_in_workflow_groups(self):
        def check(a):
            self.assertEqual(a.scalar(schema.SCALAR_NAMES['schema_version']),schema.SCHEMA_VERSION)
            grouped=tuple(field for group in LEGACY_ASSUMPTION_GROUPS for field in group.field_ids)
            self.assertEqual(len(grouped),110)
            self.assertEqual(set(grouped),{field.field_id for field in LEGACY_ASSUMPTIONS})
            actual_rows={}
            for field in LEGACY_ASSUMPTIONS:
                with self.subTest(field=field.field_id):
                    sheet,(left,top,right,bottom)=a.region(schema.SCALAR_NAMES[f'legacy_{field.field_id}'])
                    self.assertEqual(sheet.title,'CLO Controls')
                    self.assertEqual((left,right,bottom),(2,2,top))
                    actual_rows[field.field_id]=top
                    self.assertEqual(sheet.cell(top,5).value,field.source_coordinate)
                    label = 'Coverage-failure Interest Diversion' if field.field_id == 'interest_diversion' else field.label
                    self.assertEqual(' '.join(sheet.cell(top,1).value.split()),' '.join(label.split()))
                    if not field.editable:
                        self.assertEqual(sheet.cell(top,2).data_type,'f')
                        self.assertIn('trident_clo_',sheet.cell(top,2).value)
            self.assertEqual(tuple(sorted(actual_rows,key=actual_rows.get)),grouped)
            self.assertEqual(len(a.workbook.defined_names),len(schema.SCALAR_NAMES)+len(schema.TABLE_RANGE_NAMES)+2)
            for key in schema.TABLE_NAMES:self.table(a,key)
        self.access(check)

    def test_auto_principal_methods_enter_through_named_asset_table(self):
        self.small(legacy_reinvestment_enabled='No', legacy_credit_prepayment_overlay='Off')
        for method, growth in (('LINEAR_AUTO', None), ('ACCELERATED_AUTO', 1)):
            def edit(adapter):
                records = [dict(row) for row in self.table(adapter, 'assets')]
                records[0].update(amortization_type=method, amortization_growth=growth,
                                  balloon_amount=20, scheduled_principal_amount=None)
                self.put(adapter, 'assets', records)
            self.access(edit, True)
            result = run_workbook(self.path)
            self.assertEqual(sum(row.principal_repayment for row in result.cashflows.cashflows), D(100))
            self.assertEqual(result.cashflows.cashflows[-1].closing_balance, D(0))

    def test_floating_bounds_enter_named_table_and_invalid_pair_is_atomic(self):
        self.small(legacy_reinvestment_enabled='No', legacy_credit_prepayment_overlay='Off')
        run_workbook(self.path)  # Missing optional columns are registered on successful writeback.
        def bounded(adapter):
            records = [dict(row) for row in self.table(adapter, 'assets')]
            records[0].update(index_floor_bps=0, index_cap_bps=0, all_in_floor_bps=500, all_in_cap_bps=500)
            self.put(adapter, 'assets', records)
        self.access(bounded, True)
        result = run_workbook(self.path)
        self.assertTrue(all(row.all_in_rate == D('.05') for row in result.cashflows.cashflows))
        self.assertTrue(all(row.spread_bps == D(400) for row in result.cashflows.cashflows))
        def invalid(adapter):
            records = [dict(row) for row in self.table(adapter, 'assets')]
            records[0].update(all_in_floor_bps=600, all_in_cap_bps=500)
            self.put(adapter, 'assets', records)
        self.access(invalid, True)
        original = self.path.read_bytes()
        with self.assertRaises(InputValidationError):
            run_workbook(self.path)
        self.assertEqual(self.path.read_bytes(), original)

    def test_independent_asset_resets_enter_named_table_and_full_clo(self):
        self.small(legacy_reinvestment_enabled='No', legacy_credit_prepayment_overlay='Off')
        baseline = run_workbook(self.path)
        def edit(adapter):
            records = [dict(row) for row in self.table(adapter, 'assets')]
            records[0].update(rate_index='EURIBOR_1M', reset_frequency_months=1)
            self.put(adapter, 'assets', records)
        self.access(edit, True)
        result = run_workbook(self.path)
        self.assertEqual(result.cashflows.total_interest, baseline.cashflows.total_interest)
        self.assertTrue(all(len(row.coupon_segments) >= 3 for row in result.cashflows.cashflows))
        self.assertEqual(result.clo.total_equity_distributions, baseline.clo.total_equity_distributions)
        self.assertEqual(result.equity_irr, baseline.equity_irr)

    def test_generated_quality_limits_stop_only_after_fully_settled_named_run(self):
        self.small(legacy_reinvestment_enabled='No', legacy_credit_prepayment_overlay='Off')
        result = run_workbook(self.path)
        from trident.analysis import LimitStatus, MetricStatus
        self.assertEqual(result.portfolio_snapshots[-1].phase, 'TERMINATED')
        self.assertTrue(all(row.status is LimitStatus.NOT_APPLICABLE
                            for row in result.portfolio_snapshots[-1].limits))
        # The fixture deliberately has no genuine direct rating factor. The
        # opening test must remain unavailable even when its final pool closes.
        self.assertIs(result.opening_portfolio.metric('WARF').status, MetricStatus.UNAVAILABLE)


    def test_execution_trace_and_each_class_period_export(self):
        self.small(legacy_purchased_accrued_interest=2)
        def relocate(a):
            name=schema.SCALAR_NAMES['legacy_purchased_accrued_interest']
            sheet,(left,top,_,_)=a.region(name)
            target=a.workbook.create_sheet('Relocated Inputs')
            target['G8']=sheet.cell(top,left).value
            sheet.cell(top,left).value=None
            a.workbook.defined_names[name].attr_text="'Relocated Inputs'!$G$8"
        self.access(relocate,True)
        result=run_workbook(self.path)
        def check(a):
            self.assertEqual(len(self.table(a,'assumption_execution')),107)
            rows=self.table(a,'tranche_waterfall')
            self.assertEqual(len(rows),len(result.clo.periods)*2)
            self.assertEqual({(row['period_number'],row['class_id']) for row in rows},
                {(p.period_number,cls) for p in result.clo.periods for cls in ('A','SUB')})
            self.assertEqual(self.table(a,'funding_summary')[0]['name'],'collateral_par')
        self.access(check)

    def test_standalone_contractual_mode_does_not_require_unused_ois_curve(self):
        self.small(mode='CASHFLOW_ONLY')
        def empty_ois(a):
            sheet,(left,top,right,bottom)=a.region('trident_md_ois_curves')
            for row in sheet.iter_rows(min_row=top+1,max_row=bottom,min_col=left,max_col=right):
                for cell in row:cell.value=None
        self.access(empty_ois,True)
        result=run_workbook(self.path)
        self.assertIsNone(result.clo)
        self.assertTrue(result.cashflows.cashflows)

    def test_refi_contribution_export_and_equity_net_cash(self):
        self.small(legacy_refinancing_enabled='Yes',legacy_refinancing_date='2027-02-20',legacy_refi_fee_of_debt_fraction=D('.01'))
        run_workbook(self.path)
        def check(a):
            self.assertTrue(any(row['amount']==-.6 for row in self.table(a,'equity_cashflows')))
            equity=next(row for row in self.table(a,'tranche_waterfall') if row['instrument_type']=='EQUITY')
            self.assertEqual(equity['equity_capital_contribution'],.6)
            self.assertAlmostEqual(equity['net_investor_cashflow'],equity['total_cash_paid']-.6,places=12)
            self.assertEqual(equity['cumulative_equity_cash_funding'],40.6)
        self.access(check)

    def test_original_overlay_and_reinvestment_audits_are_written(self):
        self.small(legacy_credit_prepayment_overlay='On',legacy_original_annual_default_rate=D('.1'),
            legacy_original_recovery_lag_months=0,legacy_reinvestment_enabled='Yes',legacy_reinvestment_wal=D('.25'),
            legacy_reinvestment_end_date='2027-05-20',legacy_reinvestment_test_gate='Continue',
            legacy_reinvestment_annual_default_rate=0,legacy_reinvestment_annual_prepayment_rate=0)
        run_workbook(self.path)
        def check(a):
            for key in ('overlay_summary','overlay_collections','overlay_par_movements','reinvestment_purchases'):
                self.assertTrue(self.table(a,key),key)
        self.access(check)

    def test_simplified_external_source_uses_actual_cash_and_unknown_quality(self):
        self.small(collateral_projection_source='IMPORTED',legacy_collateral_cashflow_input_mode='Simplified')
        self.access(lambda a:self.put(a,'collateral_simplified',({'payment_date':date(2027,5,20),
            'interest_proceeds':10,'principal_proceeds':100,'performing_par_reduction':100,
            'currency':'EUR','source_notes':'HAND_EXTERNAL'},)),True)
        result=run_workbook(self.path)
        self.assertEqual(result.clo.total_equity_distributions,D(50))
        self.assertEqual(result.equity_moic.value,D('1.25'))
        self.assertIsNone(result.opening_portfolio.metric('WAL_YEARS').value)

    def test_bad_named_assumption_does_not_overwrite_successful_file(self):
        self.small(legacy_original_recovery_rate=1.01)
        before=self.path.read_bytes()
        with self.assertRaises(InputValidationError):run_workbook(self.path)
        self.assertEqual(self.path.read_bytes(),before)


if __name__=='__main__':unittest.main()
