"""Independent hand-ledger cases for the synthetic cash-pay CLO increment."""

import csv
import unittest
from dataclasses import replace
from datetime import date, datetime
from decimal import Decimal, localcontext
from pathlib import Path

from trident.adapters.csv_input import run_synthetic_example
from trident.clo import (
    CloRunRequest, CloTerms, CoverageStatus, DeterministicCloEngine,
    NoteTranche, ProjectionStatus,
)
from trident.conventions import DayCount
from trident.domain.models import CouponType, LoanCashflow
from trident.market.rates import FlatRateProvider


D = Decimal
ZERO = D(0)
CLOSE = date(2026, 1, 20)
FIRST = date(2026, 4, 20)  # Exactly 90 days from closing.
SECOND = date(2026, 7, 20)
ROOT = Path(__file__).resolve().parents[1]


def receipt(loan: str, number: int, start: date, end: date, opening: str, principal: str, interest: str, *, paid: date | None = None) -> LoanCashflow:
    """Hand-specified receipts isolate waterfall arithmetic from loan projection."""
    par, principal_cash, interest_cash = D(opening), D(principal), D(interest)
    return LoanCashflow(
        loan, "EUR", number, start, end, start, end, paid or end, None,
        par, None, ZERO, ZERO, D("0.25"), interest_cash,
        interest_cash, principal_cash, par - principal_cash, principal_cash + interest_cash,
    )


def note(class_id: str = "A", priority: int = 1, par: str = "100", rate: str = "0", **kwargs: object) -> NoteTranche:
    return NoteTranche(class_id, priority, D(par), CouponType.FIXED, fixed_rate=D(rate), **kwargs)


def run(rows: tuple[LoanCashflow, ...], notes: tuple[NoteTranche, ...], *, par: str = "100", final: date = SECOND, **kwargs: object):
    request = CloRunRequest(rows, D(par), notes, CloTerms(CLOSE, final, **kwargs))
    return DeterministicCloEngine(FlatRateProvider({"EURIBOR_3M": D("0.025")})).run(request)


class CloHandLedgerTests(unittest.TestCase):
    def test_coupon_before_redemption_and_full_final_reserve_release(self) -> None:
        result = run((receipt("L", 1, CLOSE, FIRST, "100", "100", "5"),),
                     (note("B", 2, "20", "0.10", oc_minimum=D("1"), ic_minimum=D("1")),
                      note("A", 1, "80", "0.10", oc_minimum=D("1.25"), ic_minimum=D("2.5"))),
                     initial_reserve=D("10"))
        self.assertEqual(result.status, ProjectionStatus.COMPLETED)
        self.assertTrue(result.terminal_value_available)
        self.assertEqual(len(result.periods), 1)
        self.assertEqual([row.class_id for row in result.tranche_periods], ["A", "B"])
        self.assertEqual([row.current_coupon_due for row in result.tranche_periods], [D("2"), D("0.50")])
        self.assertEqual(result.periods[0].debt_principal_from_principal, D("100"))
        self.assertEqual(result.periods[0].equity_from_interest, D("2.50"))
        self.assertEqual(result.periods[0].equity_from_reserve, D("10"))
        self.assertEqual(result.total_equity_distributions, D("12.50"))
        self.assertTrue(all(row.oc_status is CoverageStatus.PASS for row in result.coverage_tests if row.stage == "GATE"))
        # Paid-off debt produces semantic N/A; period coupon dues remain 2.50.
        end_b = next(row for row in result.coverage_tests if row.stage == "PERIOD_END" and row.class_id == "B")
        self.assertIs(end_b.oc_status, CoverageStatus.NOT_APPLICABLE)
        self.assertIsNone(end_b.oc_ratio)
        self.assertEqual(end_b.ic_denominator, D("2.50"))

    def test_failed_gate_diverts_all_interest_and_never_resumes_junior(self) -> None:
        rows = (receipt("L", 1, CLOSE, FIRST, "100", "0.20", "40"),
                receipt("L", 2, FIRST, SECOND, "99.80", "99.80", "5"))
        result = run(rows, (note("A", 1, "80", "0.04", oc_minimum=D("1.5")), note("B", 2, "20", "0.04")))
        first = result.periods[0]
        first_a, first_b = result.tranche_periods[:2]
        # A coupon .80, then ALL remaining 39.20 repays A; cure need is 13.34.
        self.assertEqual(first.debt_principal_from_interest, D("39.20"))
        self.assertEqual(first_a.closing_balance, D("40.80"))
        self.assertEqual(first_b.coupon_paid_from_interest, ZERO)
        self.assertEqual(first_b.coupon_paid_from_principal, D("0.20"))
        self.assertTrue(first_b.interest_gate_blocked)
        self.assertFalse(first.cash_pay_failure)
        self.assertEqual(first.equity_from_interest, ZERO)
        gate_a = next(row for row in result.coverage_tests if row.period_number == 1 and row.stage == "GATE")
        self.assertIs(gate_a.oc_status, CoverageStatus.FAIL)
        self.assertEqual(gate_a.minimum_interest_repayment_for_oc, D("13.34"))
        retest_a = next(row for row in result.coverage_tests if row.period_number == 1 and row.stage == "POST_DIVERSION" and row.class_id == "A")
        self.assertIs(retest_a.oc_status, CoverageStatus.PASS)
        self.assertEqual(retest_a.ic_denominator, D("0.80"))
        self.assertEqual(result.status, ProjectionStatus.COMPLETED)

    def test_principal_coupon_cure_consumes_cash_without_reducing_same_amount_of_debt(self) -> None:
        result = run((receipt("L", 1, CLOSE, FIRST, "100", "100", "0.50"),), (note(rate="0.08"),), final=FIRST)
        tranche = result.tranche_periods[0]
        self.assertEqual(tranche.current_coupon_due, D("2"))
        self.assertEqual(tranche.coupon_paid_from_interest, D("0.50"))
        self.assertEqual(tranche.coupon_paid_from_principal, D("1.50"))
        self.assertEqual(tranche.principal_from_principal, D("98.50"))
        self.assertEqual(tranche.closing_balance, D("1.50"))
        self.assertEqual(result.status, ProjectionStatus.LEGAL_FINAL_UNRESOLVED)
        self.assertFalse(result.periods[0].cash_pay_failure)
        self.assertFalse(result.terminal_value_available)

    def test_ic_failure_is_not_cured_by_reducing_current_period_coupon_after_redemption(self) -> None:
        rows = (receipt("L", 1, CLOSE, FIRST, "100", "0.50", "1"),
                receipt("L", 2, FIRST, SECOND, "99.50", "99.50", "5"))
        result = run(rows, (note("A", 1, "80", "0.04", ic_minimum=D("1.3")), note("B", 2, "20", "0.04")))
        first = result.periods[0]
        self.assertTrue(first.coverage_failed)
        self.assertEqual(first.debt_principal_from_interest, D("0.20"))
        self.assertEqual(first.debt_principal_from_principal, D("0.30"))
        self.assertFalse(first.cash_pay_failure)
        self.assertEqual(result.tranche_periods[0].closing_balance, D("79.50"))
        for test in result.coverage_tests:
            if test.period_number == 1 and test.class_id == "A":
                self.assertEqual(test.ic_denominator, D("0.80"))
                self.assertEqual(test.ic_ratio, D("1.25"))
                self.assertIs(test.ic_status, CoverageStatus.FAIL)

    def test_fee_basis_segments_at_each_actual_principal_event(self) -> None:
        mid = date(2026, 2, 19)  # 30 days @100, then 60 days @60.
        rows = (receipt("L", 1, CLOSE, mid, "100", "40", "0"),
                receipt("L", 2, mid, FIRST, "60", "60", "5"))
        result = run(rows, (note(par="50"),), senior_management_fee_bps=D("360"),
                     subordinated_management_fee_bps=D("720"), annual_senior_expenses=D("3.65"), initial_reserve=D("5"))
        first = result.periods[0]
        self.assertEqual(first.senior_management_fee_due, D("0.66"))
        self.assertEqual(first.subordinated_management_fee_due, D("1.32"))
        self.assertEqual(first.senior_expenses_due, D("0.90"))
        self.assertEqual(first.equity_from_interest, D("2.12"))
        self.assertEqual(first.equity_from_principal, D("50"))
        self.assertEqual(first.equity_from_reserve, D("5"))

    def test_restricted_reserve_draws_only_for_senior_fees(self) -> None:
        result = run((receipt("L", 1, CLOSE, FIRST, "100", "100", "0"),), (note(),),
                     senior_management_fee_bps=D("360"), annual_senior_expenses=D("3.65"), initial_reserve=D("2"))
        first = result.periods[0]
        self.assertEqual(first.senior_expenses_paid, D("0.90"))
        self.assertEqual(first.senior_management_fee_paid, D("0.90"))
        self.assertEqual(first.reserve_draw, D("1.80"))
        self.assertEqual(first.reserve_release, D("0.20"))
        self.assertEqual(first.debt_principal_from_principal, D("100"))
        self.assertEqual(first.equity_from_reserve, D("0.20"))

    def test_reserve_never_funds_note_coupon_and_unpaid_coupon_is_not_pik(self) -> None:
        rows = (receipt("L", 1, CLOSE, FIRST, "100", "0", "0"),
                receipt("L", 2, FIRST, SECOND, "100", "100", "0"))
        result = run(rows, (note(rate="0.08"),), initial_reserve=D("10"))
        self.assertEqual(result.status, ProjectionStatus.CASH_PAY_FAILURE)
        self.assertEqual(len(result.periods), 1)
        self.assertEqual(result.final_note_coupon_arrears, D("2"))
        self.assertEqual(result.final_debt_par, D("100"))
        self.assertEqual(result.final_reserve, D("10"))
        self.assertFalse(result.terminal_value_available)

    def test_principal_cures_senior_shortfall_after_reserve_before_note_redemption(self) -> None:
        result = run((receipt("L", 1, CLOSE, FIRST, "100", "100", "0"),), (note(),), final=FIRST,
                     annual_senior_expenses=D("3.65"), initial_reserve=D("0.50"))
        first = result.periods[0]
        self.assertEqual(first.reserve_draw, D("0.50"))
        self.assertEqual(first.senior_expenses_paid, D("0.90"))
        self.assertEqual(first.debt_principal_from_principal, D("99.60"))
        self.assertEqual(result.final_debt_par, D("0.40"))
        self.assertEqual(result.final_senior_claims, ZERO)
        self.assertFalse(first.cash_pay_failure)

    def test_unresolved_senior_claim_stops_without_liquidating_assets(self) -> None:
        rows = (receipt("L", 1, CLOSE, FIRST, "100", "0", "0"), receipt("L", 2, FIRST, SECOND, "100", "100", "0"))
        result = run(rows, (note(),), annual_senior_expenses=D("3.65"))
        self.assertEqual(result.status, ProjectionStatus.CASH_PAY_FAILURE)
        self.assertEqual(result.final_collateral_par, D("100"))
        self.assertEqual(result.final_senior_claims, D("0.90"))
        self.assertEqual(result.total_equity_distributions, ZERO)

    def test_final_sub_fee_shortfall_is_disclosed_without_cash_pay_eod(self) -> None:
        result = run((receipt("L", 1, CLOSE, FIRST, "100", "100", "0"),), (note(),), final=FIRST,
                     subordinated_management_fee_bps=D("360"), initial_reserve=D("5"))
        self.assertEqual(result.status, ProjectionStatus.FINAL_FEES_UNSETTLED)
        self.assertEqual(result.final_subordinated_fee_arrears, D("0.90"))
        self.assertEqual(result.final_reserve, D("5"))
        self.assertFalse(result.periods[0].cash_pay_failure)
        self.assertFalse(result.terminal_value_available)

    def test_sub_fee_arrears_carry_without_compounding_or_premature_eod(self) -> None:
        rows = (receipt("L", 1, CLOSE, FIRST, "100", "0", "0"),
                receipt("L", 2, FIRST, SECOND, "100", "100", "5"))
        result = run(rows, (note(),), subordinated_management_fee_bps=D("360"))
        self.assertEqual(result.periods[0].subordinated_management_fee_unpaid, D("0.90"))
        self.assertFalse(result.periods[0].cash_pay_failure)
        # Next 91-day fee is .91, plus the opening .90 unpaid claim.
        self.assertEqual(result.periods[1].subordinated_management_fee_due, D("1.81"))
        self.assertEqual(result.periods[1].subordinated_management_fee_paid, D("1.81"))
        self.assertEqual(result.periods[1].equity_from_interest, D("3.19"))
        self.assertEqual(result.status, ProjectionStatus.COMPLETED)

    def test_principal_residual_pays_final_sub_fee_before_equity(self) -> None:
        result = run((receipt("L", 1, CLOSE, FIRST, "100", "100", "0"),), (note(par="90"),),
                     subordinated_management_fee_bps=D("360"))
        self.assertEqual(result.periods[0].subordinated_management_fee_paid, D("0.90"))
        self.assertEqual(result.periods[0].equity_from_principal, D("9.10"))
        self.assertEqual(result.status, ProjectionStatus.COMPLETED)

    def test_cutoff_cash_is_pending_not_performing_par_but_remains_oc_value(self) -> None:
        result = run((receipt("L", 1, CLOSE, FIRST, "100", "100", "5"),), (note(),),
                     collection_cutoff_business_days=2, initial_reserve=D("3"))
        first, second = result.periods
        self.assertEqual(first.received_asset_principal, D("100"))
        self.assertEqual(first.eligible_asset_principal, ZERO)
        self.assertEqual(first.closing_collateral_par, ZERO)
        self.assertEqual(first.pending_principal_cash, D("100"))
        gate = next(row for row in result.coverage_tests if row.period_number == 1 and row.stage == "GATE")
        # Payment eligibility does not erase issuer-owned principal cash.
        # The repaid asset is gone, but its100 actual principal stays in OC.
        self.assertEqual(gate.oc_numerator, D("100"))
        self.assertEqual(first.reserve_release, ZERO)
        self.assertEqual(second.eligible_asset_principal, D("100"))
        self.assertEqual(second.equity_from_interest, D("5"))
        self.assertEqual(second.reserve_release, D("3"))
        self.assertEqual(result.status, ProjectionStatus.COMPLETED)

    def test_coverage_equality_and_exact_fraction_threshold(self) -> None:
        result = run((receipt("L", 1, CLOSE, FIRST, "100", "100", "1"),),
                     (note(par="80", rate="0.04", oc_minimum=D("1.25"), ic_minimum=D("1.25")),))
        gate = next(row for row in result.coverage_tests if row.stage == "GATE")
        self.assertIs(gate.oc_status, CoverageStatus.PASS)
        self.assertIs(gate.ic_status, CoverageStatus.PASS)
        # Exact 100/80=1.25 does not pass a slightly higher finite threshold.
        with localcontext() as context:
            context.prec = 6
            strict = run((receipt("L", 1, CLOSE, FIRST, "100", "100", "1"),),
                         (note(par="80", rate="0.04", oc_minimum=D("1.2500000000000000000000000000000001")),))
        strict_gate = next(row for row in strict.coverage_tests if row.stage == "GATE")
        self.assertIs(strict_gate.oc_status, CoverageStatus.FAIL)
        self.assertEqual(strict_gate.oc_ratio, D("1.25"))

    def test_zero_coupon_denominator_is_semantic_not_applicable(self) -> None:
        result = run((receipt("L", 1, CLOSE, FIRST, "100", "100", "0"),), (note(ic_minimum=D("1.5")),))
        gate = next(row for row in result.coverage_tests if row.stage == "GATE")
        self.assertIs(gate.ic_status, CoverageStatus.NOT_APPLICABLE)
        self.assertIsNone(gate.ic_ratio)
        self.assertFalse(result.periods[0].coverage_failed)

    def test_fixed_and_float_coupons_use_different_day_count_and_index_floor(self) -> None:
        floating = NoteTranche("B", 2, D("20"), CouponType.FLOATING, "EURIBOR_3M", D("200"), index_floor=ZERO)
        result = run((receipt("L", 1, CLOSE, FIRST, "100", "100", "5"),),
                     (note("A", 1, "80", "0.10", day_count=DayCount.ACT_365F), floating))
        self.assertEqual(result.tranche_periods[0].current_coupon_due, D("1.97"))
        self.assertEqual(result.tranche_periods[1].current_coupon_due, D("0.23"))
        self.assertEqual(result.tranche_periods[1].index_rate, D("0.025"))
        self.assertEqual(result.tranche_periods[1].all_in_rate, D("0.045"))

    def test_exact_half_cent_coupon_posts_without_dcf_rounding_drift(self) -> None:
        end = date(2026, 5, 20)  # 120/360 is exactly 1/3, a recurring Decimal.
        result = run((receipt("L", 1, CLOSE, end, "10", "10", "1"),), (note(par="10", rate="0.0015"),),
                     par="10", final=end, frequency_months=6)
        self.assertEqual(result.tranche_periods[0].current_coupon_due, D("0.01"))

    def test_caller_decimal_context_does_not_change_ledger(self) -> None:
        args = ((receipt("L", 1, CLOSE, FIRST, "100", "100", "5"),), (note(rate="0.08"),))
        high = run(*args, senior_management_fee_bps=D("15"))
        with localcontext() as context:
            context.prec = 3
            low = run(*args, senior_management_fee_bps=D("15"))
        self.assertEqual(low, high)


class CloValidationTests(unittest.TestCase):
    def setUp(self) -> None:
        self.rows = (receipt("L", 1, CLOSE, FIRST, "100", "100", "5"),)
        self.terms = CloTerms(CLOSE, SECOND)
        self.engine = DeterministicCloEngine(FlatRateProvider({"EURIBOR_3M": D("0.025")}))

    def test_duplicate_class_and_priority_are_rejected(self) -> None:
        for notes in ((note(), note()), (note("A", 1), note("B", 1))):
            with self.subTest(notes=notes), self.assertRaises(ValueError):
                CloRunRequest(self.rows, D("100"), notes, self.terms)

    def test_untyped_mutable_or_nonfinite_inputs_are_rejected(self) -> None:
        for value in (100.0, True, D("NaN"), D("Infinity"), D("100.001")):
            with self.subTest(value=value), self.assertRaises(ValueError):
                CloRunRequest(self.rows, value, (note(),), self.terms)
        with self.assertRaises(ValueError):
            CloRunRequest(list(self.rows), D("100"), (note(),), self.terms)
        with self.assertRaises(ValueError):
            CloTerms(datetime(2026, 1, 20), SECOND)
        with self.assertRaises(ValueError):
            CloTerms(CLOSE, SECOND, reinvestment_strategy="ASSUME_PAR_REINVESTMENT")
        with self.assertRaises(ValueError):
            note(priority=True)

    def test_negative_collection_or_broken_cash_and_par_chains_are_rejected(self) -> None:
        for modified in (
            replace(self.rows[0], cash_interest=D("-1"), total_cash=D("99")),
            replace(self.rows[0], principal_repayment=D("101")),
            replace(self.rows[0], total_cash=D("104")),
            replace(self.rows[0], period_number=2),
            replace(self.rows[0], currency="USD"),
            replace(self.rows[0], closing_balance=D("1"), principal_repayment=D("99"), total_cash=D("104")),
        ):
            with self.subTest(modified=modified), self.assertRaises(ValueError):
                self.engine.run(CloRunRequest((modified,), D("100"), (note(),), self.terms))
        with self.assertRaises(ValueError):
            self.engine.run(CloRunRequest(self.rows + self.rows, D("100"), (note(),), self.terms))
        with self.assertRaises(ValueError):
            self.engine.run(CloRunRequest(self.rows, D("101"), (note(),), self.terms))

    def test_broken_multi_period_par_and_date_chain_is_rejected(self) -> None:
        first = receipt("L", 1, CLOSE, FIRST, "100", "10", "1")
        second = receipt("L", 2, FIRST, SECOND, "90", "90", "1")
        for modified in (replace(second, opening_balance=D("91"), principal_repayment=D("91"), total_cash=D("92")),
                         replace(second, accrual_start=date(2026, 4, 21))):
            with self.subTest(modified=modified), self.assertRaises(ValueError):
                self.engine.run(CloRunRequest((first, modified), D("100"), (note(),), self.terms))

    def test_floating_tenor_mismatch_and_negative_all_in_rate_are_explicit(self) -> None:
        floating = NoteTranche("A", 1, D("100"), CouponType.FLOATING, "EURIBOR_1M")
        with self.assertRaisesRegex(ValueError, "tenor"):
            CloRunRequest(self.rows, D("100"), (floating,), self.terms)
        floating = replace(floating, rate_index="EURIBOR_3M")
        negative = DeterministicCloEngine(FlatRateProvider({"EURIBOR_3M": D("-0.01")}))
        with self.assertRaisesRegex(ValueError, "all-in rate"):
            negative.run(CloRunRequest(self.rows, D("100"), (floating,), self.terms))


class HybridCloIntegrationTests(unittest.TestCase):
    def test_h00_first_period_independent_reference_and_full_lifecycle_conservation(self) -> None:
        directory = ROOT / "data/examples/hybrid_500m"
        assets = run_synthetic_example(directory)
        oc = {"A": "1.5", "B": "1.3", "C": "1.2", "D": "1.12", "E": "1.06"}
        ic = {"A": "1.5", "B": "1.4", "C": "1.3", "D": "1.2", "E": "1.1"}
        with (directory / "capital_stack.csv").open(encoding="utf-8", newline="") as stream:
            tranches = tuple(
                NoteTranche(row["class_id"], int(row["payment_priority"]), D(row["nominal_amount"]),
                            CouponType.FLOATING, row["rate_index"], D(row["spread_bps"]), index_floor=ZERO,
                            oc_minimum=D(oc[row["class_id"]]), ic_minimum=D(ic[row["class_id"]]))
                for row in csv.DictReader(stream) if row["instrument_type"] == "DEBT"
            )
        terms = CloTerms(date(2026, 11, 20), date(2039, 11, 20),
                         senior_management_fee_bps=D("15"), subordinated_management_fee_bps=D("30"),
                         annual_senior_expenses=D("300000"), initial_reserve=D("2500000"))
        result = DeterministicCloEngine(FlatRateProvider({"EURIBOR_3M": D("0.025")})).run(
            CloRunRequest(assets.cashflows, D("500000000"), tranches, terms)
        )
        first = result.periods[0]
        self.assertEqual(first.payment_date, date(2027, 2, 22))
        self.assertEqual(first.eligible_asset_interest, D("7670139.00"))
        self.assertEqual(first.senior_management_fee_due, D("195833.33"))
        self.assertEqual(first.senior_expenses_due, D("77260.27"))
        self.assertEqual(first.subordinated_management_fee_due, D("391666.67"))
        self.assertEqual([row.current_coupon_due for row in result.tranche_periods[:5]],
                         list(map(D, ["3166625", "646250", "475222.22", "594027.78", "228472.22"])))
        self.assertEqual(first.note_coupon_due, D("5110597.22"))
        self.assertEqual(first.equity_from_interest, D("1894781.51"))
        self.assertEqual(first.debt_principal_from_principal, D("7000000"))
        self.assertEqual(first.closing_collateral_par, D("493000000"))
        self.assertEqual(first.closing_debt_par, D("443000000"))
        self.assertFalse(first.coverage_failed)
        self.assertEqual(result.status, ProjectionStatus.COMPLETED)
        self.assertTrue(result.terminal_value_available)
        self.assertEqual(len(result.periods), 40)
        self.assertEqual(result.periods[-1].payment_date, date(2036, 11, 20))
        self.assertEqual(result.periods[-1].reserve_release, D("2500000"))
        self.assertEqual(sum(row.received_asset_principal for row in result.periods), D("500000000"))
        self.assertEqual(sum(row.debt_principal_from_principal + row.debt_principal_from_interest for row in result.periods), D("450000000"))
        self.assertTrue(all(row.cash_conservation_residual == ZERO for row in result.periods))
        for row in result.tranche_periods:
            self.assertEqual(row.opening_balance - row.principal_from_interest - row.principal_from_principal, row.closing_balance)


if __name__ == "__main__":
    unittest.main()
