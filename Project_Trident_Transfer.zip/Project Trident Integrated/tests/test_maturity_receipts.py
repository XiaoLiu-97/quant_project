"""Known adjusted receipts preserve par without inventing nominal maturity.

June 21 is the Sunday between a Saturday nominal maturity and Monday receipt.
Two equal EUR100 positions pay in 1 and 29 days: WAL=15/365, WAS=250bps.
Literal expected answers independently validate the narrow calendar bridge.
"""

from dataclasses import replace
from datetime import date, datetime
from decimal import Decimal, Inexact, localcontext
from fractions import Fraction
import unittest

from trident.analysis import (
    AssetExposure, LimitSpec, LimitStatus, MetricStatus, PortfolioAnalyzer, ScheduledMaturityReceipt,
)
from trident.domain.models import CouponType, InputValidationError, LoanCashflow


D = Decimal
OBSERVE = date(2026, 6, 21)
NOMINAL, RECEIPT, LATER = date(2026, 6, 20), date(2026, 6, 22), date(2026, 7, 20)


def fixture():
    """Principal-only references are analytical evidence, never coupon inputs."""
    assets = tuple(AssetExposure(identity, identity, "BSL", "TERM_LOAN", "FR", "S",
        "EUR", D(100), D(spread), maturity, coupon_type=CouponType.FLOATING)
        for identity, spread, maturity in (("A", 300, NOMINAL), ("B", 200, LATER)))
    rows = tuple(LoanCashflow(identity, "EUR", 1, date(2026, 1, 1), maturity,
        date(2026, 1, 1), maturity, paid, None, D(100), None,
        D(0), D(0), D(0), D(0), D(0), D(100), D(0), D(100))
        for identity, maturity, paid in (("A", NOMINAL, RECEIPT), ("B", LATER, LATER)))
    receipt = ScheduledMaturityReceipt("A", "EUR", NOMINAL, RECEIPT, D(100))
    return assets, rows, receipt


class ScheduledMaturityReceiptTests(unittest.TestCase):
    def test_verified_receipt_keeps_full_par_and_wal_but_not_negative_wam(self):
        assets, rows, receipt = fixture()
        with localcontext() as context:
            context.prec = 2
            context.traps[Inexact] = True
            report = PortfolioAnalyzer().analyze(assets, OBSERVE, iter(rows),
                limits=(LimitSpec("MATURITY", "WEIGHTED_AVERAGE_MATURITY_YEARS", D(10)),),
                legal_final_date=date(2027, 1, 1), scheduled_maturity_receipts=(receipt,))
        self.assertEqual(report.total_par, D(200))
        self.assertEqual(report.metric("WAS_BPS").value, D(250))
        self.assertLess(abs(Fraction(report.metric("WAL_YEARS").value) - Fraction(15, 365)),
                        Fraction(1, 10**35))
        self.assertIs(report.metric("WAL_YEARS").status, MetricStatus.AVAILABLE)
        self.assertIs(report.metric("WEIGHTED_AVERAGE_MATURITY_YEARS").status, MetricStatus.UNAVAILABLE)
        self.assertIs(report.limits[0].status, LimitStatus.UNAVAILABLE)
        self.assertEqual(report.metric("LONG_DATED_FRACTION").value, D(0))
        self.assertEqual(assets[0].maturity_date, NOMINAL)

    def test_no_evidence_does_not_waive_expired_holdings(self):
        assets, rows, _ = fixture()
        with self.assertRaises(InputValidationError):
            PortfolioAnalyzer().analyze(assets, OBSERVE, rows)

    def test_incomplete_wrong_or_expired_reference_is_rejected(self):
        assets, rows, receipt = fixture()
        for invalid in ((), (replace(rows[0], principal_repayment=D(99)), rows[1]),
                (replace(rows[0], currency="USD"), rows[1]),
                (replace(rows[0], unadjusted_end=date(2026, 6, 19)), rows[1]),
                (replace(rows[0], closing_balance=D(1)), rows[1]),
                (replace(rows[0], payment_date=OBSERVE), rows[1]),
                (*rows, replace(rows[0], period_number=2, principal_repayment=D(1)))):
            with self.subTest(invalid=invalid), self.assertRaises(InputValidationError):
                PortfolioAnalyzer().analyze(assets, OBSERVE, invalid,
                    scheduled_maturity_receipts=(receipt,))

    def test_wrong_duplicate_extra_or_partial_proof_is_rejected(self):
        assets, rows, receipt = fixture()
        for invalid in ([receipt], (receipt, receipt), (replace(receipt, loan_id="UNKNOWN"),),
                (replace(receipt, currency="USD"),),
                (replace(receipt, outstanding_principal=D(99)),),
                (replace(receipt, nominal_maturity_date=date(2026, 6, 19)),),
                (replace(receipt, receipt_date=date(2026, 6, 23)),),
                (receipt, ScheduledMaturityReceipt("B", "EUR", LATER, date(2026, 7, 21), D(100)))):
            with self.subTest(invalid=invalid), self.assertRaises(InputValidationError):
                PortfolioAnalyzer().analyze(assets, OBSERVE, rows,
                    scheduled_maturity_receipts=invalid)

    def test_receipt_domain_rejects_invalid_units_dates_and_amount(self):
        _, _, receipt = fixture()
        for changes in ({"receipt_date": NOMINAL}, {"receipt_date": datetime(2026, 6, 22)},
                {"outstanding_principal": D(0)}, {"outstanding_principal": D("NaN")},
                {"outstanding_principal": 100}, {"loan_id": " A "}):
            with self.subTest(changes=changes), self.assertRaises(InputValidationError):
                replace(receipt, **changes)

    def test_settled_principal_has_no_receipt_proof_or_remaining_face(self):
        assets, rows, _ = fixture()
        # After A's actual receipt, only B remains. An unexpired B needs no
        # bridge; its28-day future principal gives WAL28/365.
        paid = PortfolioAnalyzer().analyze(assets[1:], RECEIPT, rows[1:])
        self.assertEqual(paid.total_par, D(100))
        self.assertEqual(paid.metric("WAS_BPS").value, D(200))
        self.assertLess(abs(Fraction(paid.metric("WAL_YEARS").value) - Fraction(28, 365)),
                        Fraction(1, 10**35))


if __name__ == "__main__":
    unittest.main()
