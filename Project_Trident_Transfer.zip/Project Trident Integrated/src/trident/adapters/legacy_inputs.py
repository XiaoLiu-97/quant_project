"""Complete immutable v4.2.2 CLO Assumptions inventory, independent of layout.

Source coordinates are evidence identifiers only. Runtime adapters identify
business inputs by stable field IDs / named ranges; they never read B-row
addresses. Old workbook data validations are recorded separately because some
ranges are demonstrably misplaced. Canonical choices follow financial labels
and VBA validation, with explicit aliases handled by the current deal-input adapter.

All legacy percentages are decimal fractions, including clean purchase prices:
1.00 means 100% of par. New asset tape price-pct units are separately converted.
This inventory does not claim that a registered field has executable economics.
"""
from dataclasses import dataclass
from datetime import date
from decimal import Decimal
from types import MappingProxyType

@dataclass(frozen=True, slots=True)
class LegacyAssumptionField:
    """One source field, its type/unit, choices and original reference default."""
    field_id: str
    source_coordinate: str
    label: str
    semantic_type: str
    unit: str
    reference_default: str
    choices: tuple[str, ...] = ()
    source_validation_formulas: tuple[str, ...] = ()
    source_note: str = ""

    @property
    def editable(self) -> bool:
        return self.semantic_type != "DERIVED"

    @property
    def default_value(self) -> object:
        """Typed historical default, never silently promoted to production input."""
        if self.semantic_type == "DATE":
            return date.fromisoformat(self.reference_default[:10])
        if self.semantic_type == "INTEGER":
            return int(self.reference_default)
        if self.semantic_type in {"MONEY", "DECIMAL"}:
            return Decimal(self.reference_default)
        return self.reference_default

LEGACY_ASSUMPTIONS = (
    LegacyAssumptionField('pricing_date', 'B6', 'Pricing Date', 'DATE', 'Date', '2026-08-04T00:00:00', (), (), 'Pricing / valuation date; market-data curves are viewed as of this date'),
    LegacyAssumptionField('first_note_payment_date', 'B7', 'First Note Payment Date', 'DATE', 'Date', '2027-06-30T00:00:00', (), (), 'Dummy input'),
    LegacyAssumptionField('maturity_date', 'B8', 'Maturity Date', 'DATE', 'Date', '2034-03-31T00:00:00', (), (), 'Dummy input'),
    LegacyAssumptionField('payment_frequency', 'B9', 'Payment Frequency', 'CHOICE', 'Dropdown', '3M', ('1M', '3M', '6M', '12M'), ('"1M,3M,6M,12M"',), 'Controls note schedule'),
    LegacyAssumptionField('reference_curve', 'B10', 'Reference Curve', 'CHOICE', 'Dropdown', 'EURIBOR 3M', ('EURIBOR 1M', 'EURIBOR 3M', 'EURIBOR 6M'), ('"EURIBOR 1M,EURIBOR 3M,EURIBOR 6M"',), 'Canonical projected term reference curve for all rated CLO note coupons'),
    LegacyAssumptionField('day_count', 'B11', 'Day Count', 'CHOICE', 'Dropdown', 'ACT/360', ('ACT/360', 'ACT/365', '30/360'), ('"ACT/360,ACT/365,30/360"',), 'Coupon / account accrual'),
    LegacyAssumptionField('base_currency', 'B12', 'Base Currency', 'CHOICE', 'Dropdown', 'EUR', ('EUR', 'USD', 'GBP'), ('"EUR"',), 'CLO mode requires EUR; single-currency standalone cashflows also support USD/GBP'),
    LegacyAssumptionField('clo_size', 'B13', 'CLO Size', 'MONEY', 'EUR', '684631023', (), (), 'Capital structure total'),
    LegacyAssumptionField('opening_collateral_par', 'B14', 'Opening Collateral Par', 'MONEY', 'EUR @ Closing Date', '684631023', (), (), 'Projected collateral par at Closing Date. Pre-closing warehouse-period cash flows are excluded from the CLO waterfall and must already be reflected in this closing-date par.'),
    LegacyAssumptionField('reinvestment_end_date', 'B15', 'Reinvestment End Date', 'DATE', 'Date', '2032-03-31T00:00:00', (), (), 'Principal retained/reinvested through date'),
    LegacyAssumptionField('reinvestment_enabled', 'B16', 'Reinvestment Enabled', 'CHOICE', 'Dropdown', 'Yes', ('Yes', 'No'), ('"Yes,No"',), 'If Yes, principal cash is reinvested during reinvestment period'),
    LegacyAssumptionField('cash_accrual_curve', 'B17', 'Cash Accrual Curve', 'CHOICE', 'Dropdown', 'ESTR', ('ESTR', 'SOFR', 'SONIA', 'EURIBOR 1M', 'EURIBOR 3M', 'EURIBOR 6M'), ('"ESTR,SOFR,SONIA,EURIBOR 1M,EURIBOR 3M,EURIBOR 6M"',), 'Selected cash-account reference: ESTR / SOFR / SONIA zero curve or projected EURIBOR 1M / 3M / 6M fixing'),
    LegacyAssumptionField('cash_account_spread', 'B18', 'Cash Account Spread', 'DECIMAL', '%', '0', (), (), 'Added to the selected cash-account reference rate'),
    LegacyAssumptionField('senior_management_fee', 'B21', 'Senior Management Fee', 'DECIMAL', '% p.a.', '0.0015', (), (), 'Senior fee; applied to the selected fee base (average performing par by default)'),
    LegacyAssumptionField('subordinated_management_fee', 'B22', 'Subordinated Management Fee', 'DECIMAL', '% p.a.', '0.003', (), ('"Average Performing Par,Opening Performing Par"',), 'Subordinated fee paid after debt interest/tests; unpaid amounts carry and may be paid from residual principal after rated debt'),
    LegacyAssumptionField('fee_base', 'B23', 'Fee Base', 'CHOICE', 'Dropdown', 'Average Performing Par', ('Average Performing Par', 'Opening Performing Par'), ('"Average Performing Par,Opening Performing Par"',), 'Default fee base for senior/subordinated management fees and variable expenses'),
    LegacyAssumptionField('trustee_paying_agent_administrator', 'B26', 'Trustee / Paying Agent / Administrator', 'MONEY', 'EUR p.a.', '75000', (), ('"Enabled,Disabled"',), 'Recurring senior administration'),
    LegacyAssumptionField('collateral_administration_account_bank', 'B27', 'Collateral Administration / Account Bank', 'MONEY', 'EUR p.a.', '65000', (), ('"Enabled,Disabled"',), 'Collateral reporting and account-bank costs'),
    LegacyAssumptionField('rating_agency_surveillance', 'B28', 'Rating Agency Surveillance', 'MONEY', 'EUR p.a.', '60000', (), ('"Sequential,Pro Rata"',), 'Recurring surveillance fees'),
    LegacyAssumptionField('legal_advisory', 'B29', 'Legal / Advisory', 'MONEY', 'EUR p.a.', '35000', (), (), 'Ordinary-course legal and advisory budget'),
    LegacyAssumptionField('audit_accounting_tax', 'B30', 'Audit / Accounting / Tax', 'MONEY', 'EUR p.a.', '45000', (), (), 'Recurring audit, accounting and tax compliance'),
    LegacyAssumptionField('listing_regulatory_reporting', 'B31', 'Listing / Regulatory / Reporting', 'MONEY', 'EUR p.a.', '20000', (), ('"On,Off"',), 'Listing maintenance and regulatory reporting'),
    LegacyAssumptionField('other_recurring_senior_expenses', 'B32', 'Other Recurring Senior Expenses', 'MONEY', 'EUR p.a.', '300000', (), (), 'Residual recurring expense input'),
    LegacyAssumptionField('total_fixed_senior_expenses', 'B33', 'Total Fixed Senior Expenses', 'DERIVED', 'EUR p.a.', '=SUM(B26:B32)', (), (), 'Calculated sum of recurring fixed expense components above; loaded by VBA as the fixed expected senior-expense amount.'),
    LegacyAssumptionField('expected_senior_expenses_variable', 'B34', 'Expected Senior Expenses — Variable %', 'DECIMAL', '% p.a. of Fee Base', '0.00015', (), (), 'Expected annual spend = Total Fixed Senior Expenses + variable rate × selected Fee Base.'),
    LegacyAssumptionField('senior_expense_cap_fixed', 'B35', 'Senior Expense Cap — Fixed', 'MONEY', 'EUR p.a.', '300000', (), (), 'Annual fixed component of the maximum senior-expense cap.'),
    LegacyAssumptionField('senior_expense_cap_variable', 'B36', 'Senior Expense Cap — Variable %', 'DECIMAL', '% p.a. of Fee Base', '0.00025', (), (), 'Maximum senior-expense cap = fixed cap + variable rate × selected Fee Base.'),
    LegacyAssumptionField('incentive_management_fee_enabled', 'B39', 'Incentive Management Fee Enabled', 'CHOICE', 'Dropdown', 'No', ('Yes', 'No'), ('"Yes,No"',), 'Optional generic incentive fee; disabled by default'),
    LegacyAssumptionField('incentive_fee_rate', 'B40', 'Incentive Fee Rate', 'DECIMAL', '% of eligible excess equity distributions', '0.2', (), (), 'Applied to total eligible residual equity proceeds above the compounded hurdle'),
    LegacyAssumptionField('equity_irr_hurdle', 'B41', 'Equity IRR Hurdle', 'DECIMAL', '% p.a.', '0.12', (), (), 'Compounded ACT/365 hurdle beginning with actual equity funding on Closing Date'),
    LegacyAssumptionField('upfront_arrangement_fee', 'B44', 'Upfront Arrangement Fee', 'DECIMAL', '% of CLO size', '0.0075', (), (), 'User input; retain 75bps as base placeholder and review 50/75/100bps sensitivity'),
    LegacyAssumptionField('rating_agency_initial_fees', 'B45', 'Rating Agency Initial Fees', 'MONEY', 'EUR', '250000', (), (), 'Initial rating fees / modelling / surveillance setup'),
    LegacyAssumptionField('legal_documentation', 'B46', 'Legal & Documentation', 'MONEY', 'EUR', '350000', (), (), 'Issuer, manager, arranger and transaction-document counsel'),
    LegacyAssumptionField('trustee_administrator_issuer_setup', 'B47', 'Trustee / Administrator / Issuer Setup', 'MONEY', 'EUR', '100000', (), (), 'Initial trustee, paying agent, collateral administrator and corporate setup'),
    LegacyAssumptionField('listing_clearing', 'B48', 'Listing / Clearing', 'MONEY', 'EUR', '50000', (), (), 'Exchange admission, clearing and related launch costs'),
    LegacyAssumptionField('accounting_audit_tax_setup', 'B49', 'Accounting / Audit / Tax Setup', 'MONEY', 'EUR', '100000', (), (), 'Initial accounting, audit and tax structuring'),
    LegacyAssumptionField('warehouse_financing_unwind', 'B50', 'Warehouse Financing / Unwind', 'MONEY', 'EUR', '250000', (), (), 'Warehouse financing, unwind and transition costs'),
    LegacyAssumptionField('hedge_fx_setup', 'B51', 'Hedge / FX Setup', 'MONEY', 'EUR', '50000', (), (), 'Initial hedge or FX documentation/setup where applicable'),
    LegacyAssumptionField('other_upfront_costs', 'B52', 'Other Upfront Costs', 'MONEY', 'EUR', '100000', (), (), 'Residual buffer; replace with deal evidence'),
    LegacyAssumptionField('total_other_upfront_costs', 'B53', 'Total Other Upfront Costs', 'DERIVED', 'EUR', '=SUM(B45:B52)', (), (), 'Calculated sum of the non-arrangement upfront cost components above; loaded by VBA as Other Upfront Costs.'),
    LegacyAssumptionField('total_upfront_fees_closing_costs', 'B54', 'Total Upfront Fees & Closing Costs', 'DERIVED', 'EUR', '=B44*$B$13+B53', (), (), 'Arrangement fee × CLO size plus Total Other Upfront Costs. Display-only total; Sources & Uses retains the two components separately.'),
    LegacyAssumptionField('oc_ic_tests', 'B57', 'OC/IC Tests', 'CHOICE', 'Dropdown', 'Enabled', ('Enabled', 'Disabled'), ('"Enabled,Disabled"',), 'Enables tranche-level OC and IC tests'),
    LegacyAssumptionField('interest_diversion', 'B58', 'Interest Diversion', 'CHOICE', 'Dropdown', 'Enabled', ('Enabled', 'Disabled'), ('"Enabled,Disabled"', '"Sequential,Pro Rata"'), 'If a test fails, residual interest is diverted to principal'),
    LegacyAssumptionField('principal_waterfall', 'B59', 'Principal Waterfall', 'CHOICE', 'Dropdown', 'Sequential', ('Sequential', 'Pro Rata'), ('"Sequential,Pro Rata"',), 'Sequential or Pro Rata'),
    LegacyAssumptionField('credit_prepayment_overlay', 'B62', 'Credit / Prepayment Overlay', 'CHOICE', 'Dropdown', 'Off', ('On', 'Off'), ('"On,Off"',), 'Base case is Off. Turn On to apply original-pool CDR, CPR and recovery assumptions.'),
    LegacyAssumptionField('original_annual_default_rate', 'B63', 'Annual Default Rate', 'DECIMAL', '% p.a.', '0.02', (), (), 'Constant default rate overlay'),
    LegacyAssumptionField('original_recovery_rate', 'B64', 'Recovery Rate', 'DECIMAL', '%', '0.6', (), (), 'Applied after recovery lag'),
    LegacyAssumptionField('original_recovery_lag_months', 'B65', 'Recovery Lag Months', 'INTEGER', 'Months', '6', (), (), 'Rounded to note periods'),
    LegacyAssumptionField('ccc_fraction', 'B66', 'CCC %', 'DECIMAL', '% of collateral par', '0.05', (), (), 'Used for CCC haircut'),
    LegacyAssumptionField('ccc_limit_fraction', 'B67', 'CCC Limit', 'DECIMAL', '% of collateral par', '0.075', (), (), 'Excess CCC amount receives valuation haircut'),
    LegacyAssumptionField('ccc_valuation_fraction', 'B68', 'CCC Valuation %', 'DECIMAL', '% of par', '0.7', (), (), 'Valuation assigned to excess CCC'),
    LegacyAssumptionField('maturity_liquidation_fraction', 'B69', 'Maturity Liquidation %', 'DECIMAL', '% of remaining par', '1', (), (), 'Liquidation proceeds at legal maturity'),
    LegacyAssumptionField('original_collateral_cpr', 'B70', 'Original Collateral CPR', 'DECIMAL', '% p.a.', '0', (), (), 'Optional CPR overlay on the imported original collateral pool; active only when Credit / Prepayment Overlay is On.'),
    LegacyAssumptionField('reinvestment_reference_curve', 'B72', 'Reinvestment Reference Curve', 'CHOICE', 'Dropdown', 'EURIBOR 3M', ('EURIBOR 1M', 'EURIBOR 3M', 'EURIBOR 6M'), ('"EURIBOR 1M,EURIBOR 3M,EURIBOR 6M"',), 'Independent reinvestment curve: EURIBOR 1M / 3M / 6M.'),
    LegacyAssumptionField('reinvestment_asset_spread', 'B73', 'Reinvestment Asset Spread', 'DECIMAL', '% p.a.', '0.04', (), (), 'Spread on par'),
    LegacyAssumptionField('reinvestment_purchase_price', 'B74', 'Reinvestment Purchase Price', 'DECIMAL', '% of par', '0.99', (), (), 'Synthetic asset reference-rate floor applies before adding spread'),
    LegacyAssumptionField('reinvestment_wal', 'B75', 'Reinvestment WAL', 'DECIMAL', 'Years', '4', (), (), 'Bullet WAL, capped at CLO maturity'),
    LegacyAssumptionField('reinvestment_annual_prepayment_rate', 'B76', 'Annual Prepayment Rate', 'DECIMAL', '% p.a.', '0.1', (), (), 'Annual CPR converted to exact period rate: 1-(1-CPR)^year_fraction'),
    LegacyAssumptionField('reinvestment_annual_default_rate', 'B77', 'Annual Default Rate', 'DECIMAL', '% p.a.', '0.02', (), (), 'Annual CDR converted to exact period rate: 1-(1-CDR)^year_fraction'),
    LegacyAssumptionField('reinvestment_recovery_rate', 'B78', 'Recovery Rate', 'DECIMAL', '%', '0.6', (), (), 'Synthetic cohort recovery'),
    LegacyAssumptionField('reinvestment_recovery_lag_months', 'B79', 'Recovery Lag Months', 'INTEGER', 'Months', '6', (), ('"Yes,No"',), 'Rounded to note periods'),
    LegacyAssumptionField('recycle_reinvestment_principal', 'B80', 'Recycle Reinvestment Principal', 'CHOICE', 'Dropdown', 'Yes', ('Yes', 'No'), ('"Yes,No"',), 'Recycle principal from reinvested assets'),
    LegacyAssumptionField('reinvestment_test_gate', 'B81', 'Reinvestment Test Gate', 'CHOICE', 'Dropdown', 'Stop on Test Failure', ('Stop on Test Failure', 'Always Reinvest', 'Continue'), ('"Stop on Test Failure,Continue"',), 'Block purchases on OC/IC failure; source UI Continue and VBA Always Reinvest are aliases'),
    LegacyAssumptionField('use_asset_level_test_data', 'B84', 'Use Asset-Level Test Data', 'CHOICE', 'Dropdown', 'No', ('Yes', 'No'), ('"Yes,No"',), 'Use optional Collateral Assets inventory'),
    LegacyAssumptionField('discount_obligation_fraction', 'B85', 'Discount Obligation %', 'DECIMAL', '% of performing par', '0.05', (), (), 'Top-down mode'),
    LegacyAssumptionField('discount_obligation_valuation_fraction', 'B86', 'Discount Obligation Valuation %', 'DECIMAL', '% of par', '0.8', (), (), 'Top-down mode'),
    LegacyAssumptionField('defaulted_asset_valuation_fraction', 'B87', 'Defaulted Asset Valuation %', 'DECIMAL', '% of par', '0.4', (), ('"Yes,No"',), 'Unresolved defaults'),
    LegacyAssumptionField('include_principal_cash_in_oc', 'B88', 'Include Principal Cash in OC', 'CHOICE', 'Dropdown', 'Yes', ('Yes', 'No'), ('"Yes,No"',), 'Include principal cash in OC numerator'),
    LegacyAssumptionField('interest_shortfall_carry', 'B89', 'Interest Shortfall Carry', 'CHOICE', 'Dropdown', 'Enabled', ('Enabled', 'Disabled'), ('"Enabled,Disabled"',), 'Allow carried shortfalls'),
    LegacyAssumptionField('shortfall_accrual_method', 'B90', 'Shortfall Accrual Method', 'CHOICE', 'Dropdown', 'None', ('None', 'Coupon Rate'), ('"None,Coupon Rate"',), 'None or Coupon Rate'),
    LegacyAssumptionField('rate_fixing_lag', 'B93', 'Rate Fixing Lag', 'INTEGER', 'Business Days', '2', (), ('"TARGET,Weekends Only"',), 'Business-day lag from fixing anchor to reference-rate fixing date. Default 2 TARGET business days; use the actual transaction document convention.'),
    LegacyAssumptionField('fixing_calendar', 'B94', 'Fixing Calendar', 'CHOICE', 'Dropdown', 'TARGET', ('TARGET', 'Weekends Only'), ('"TARGET,Weekends Only"',), 'TARGET excludes weekends plus standard TARGET closing days; Weekends Only is also supported'),
    LegacyAssumptionField('fixing_date_anchor', 'B95', 'Fixing Date Anchor', 'CHOICE', 'Dropdown', 'Period Start', ('Period Start', 'Payment Date'), ('"Period Start,Payment Date"',), 'Anchor used before applying fixing lag; Period Start or Payment Date'),
    LegacyAssumptionField('allow_long_dated_assets', 'B98', 'Allow Long-Dated Assets', 'CHOICE', 'Dropdown', 'Yes', ('Yes', 'No'), ('"Yes,No"',), 'If Yes, post-CLO-maturity collateral cash flows are excluded from scheduled note cash flows and monetized through maturity liquidation.'),
    LegacyAssumptionField('long_dated_asset_limit_fraction', 'B99', 'Long-Dated Asset Limit %', 'DECIMAL', '% of opening collateral par', '0.05', (), ('"Yes,No"',), 'Diagnostic warning level only; actual transaction limits are deal-specific.'),
    LegacyAssumptionField('long_dated_oc_valuation_fraction', 'B100', 'Long-Dated OC Valuation %', 'DECIMAL', '% of long-dated par', '1', (), (), 'Value credited in generic adjusted collateral par; set below 100% to apply a haircut.'),
    LegacyAssumptionField('closing_date', 'B103', 'Closing Date', 'DATE', 'Date', '2027-03-31T00:00:00', (), (), 'CLO economic start / note accrual start. Can be later than Pricing Date for a forward-start CLO.'),
    LegacyAssumptionField('determination_lag', 'B104', 'Determination Lag', 'INTEGER', 'Business Days', '5', (), ('"Modified Following,Following,Unadjusted,TARGET,Weekends Only"', '"TARGET,Weekends Only"'), 'Collection-period cut-off before each payment date; final period runs through legal maturity.'),
    LegacyAssumptionField('determination_calendar', 'B105', 'Determination Calendar', 'CHOICE', 'Dropdown', 'TARGET', ('TARGET', 'Weekends Only'), ('"Modified Following,Following,Unadjusted,TARGET,Weekends Only"', '"TARGET,Weekends Only"'), 'Business-day calendar used to calculate Determination Date.'),
    LegacyAssumptionField('first_stub_rate_method', 'B106', 'First Stub Rate Method', 'CHOICE', 'Dropdown', 'Selected Reference', ('Selected Reference', 'Interpolate 1M/3M/6M', 'User Override'), ('"Selected Reference,Interpolate 1M/3M/6M,User Override"',), 'Selected Reference / Interpolate 1M/3M/6M / User Override.'),
    LegacyAssumptionField('first_stub_rate_override', 'B107', 'First Stub Rate Override', 'DECIMAL', '%', '0', (), (), 'Used only when First Stub Rate Method = User Override.'),
    LegacyAssumptionField('collateral_purchase_price', 'B110', 'Collateral Purchase Price', 'DECIMAL', '% of par', '1', (), ('"Average Performing Par,Opening Performing Par"',), 'Opening collateral cash purchase cost = par × purchase price.'),
    LegacyAssumptionField('purchased_accrued_interest', 'B111', 'Purchased Accrued Interest', 'MONEY', 'EUR', '0', (), (), 'Accrued interest paid at closing, if applicable.'),
    LegacyAssumptionField('initial_reserve_funding', 'B112', 'Initial Reserve Funding', 'MONEY', 'EUR', '0', (), (), 'Initial reserve / liquidity funding paid at closing.'),
    LegacyAssumptionField('other_initial_uses', 'B113', 'Other Initial Uses', 'MONEY', 'EUR', '0', (), (), 'Other transaction-specific uses not captured above.'),
    LegacyAssumptionField('other_initial_sources', 'B114', 'Other Initial Sources', 'MONEY', 'EUR', '0', (), (), 'Other transaction-specific non-equity sources.'),
    LegacyAssumptionField('optional_call_enabled', 'B117', 'Optional Call Enabled', 'CHOICE', 'Dropdown', 'No', ('Yes', 'No'), ('"Yes,No"',), 'If enabled, calculate a call IRR on the first payment date on/after Call Date.'),
    LegacyAssumptionField('call_date', 'B118', 'Call Date', 'DATE', 'Date', '2032-03-31T00:00:00', (), (), 'Scenario date only; base Hold waterfall is unchanged.'),
    LegacyAssumptionField('call_collateral_sale_price', 'B119', 'Call Collateral Sale Price', 'DECIMAL', '% of remaining par', '1', (), (), 'Sale price applied to remaining performing collateral on call.'),
    LegacyAssumptionField('call_costs_of_debt_fraction', 'B120', 'Call Costs % of Debt', 'DECIMAL', '% of outstanding debt', '0.005', (), ('"Yes,No"',), 'Transaction costs deducted from call terminal proceeds.'),
    LegacyAssumptionField('refinancing_enabled', 'B121', 'Refinancing Enabled', 'CHOICE', 'Dropdown', 'No', ('Yes', 'No'), ('"Yes,No"',), 'Simplified refinancing sensitivity; base principal path is retained.'),
    LegacyAssumptionField('refinancing_date', 'B122', 'Refinancing Date', 'DATE', 'Date', '2030-03-31T00:00:00', (), (), 'First payment date on/after this date is treated as the refinance date.'),
    LegacyAssumptionField('refi_spread_reduction', 'B123', 'Refi Spread Reduction', 'DECIMAL', '% p.a.', '0.005', (), (), 'Uniform spread reduction across rated debt, floored at zero spread.'),
    LegacyAssumptionField('refi_fee_of_debt_fraction', 'B124', 'Refi Fee % of Debt', 'DECIMAL', '% of outstanding debt', '0.005', (), (), 'Equity-funded refinancing fee.'),
    LegacyAssumptionField('payment_date_convention', 'B128', 'Payment Date Convention', 'CHOICE', 'Dropdown', 'Modified Following', ('Modified Following', 'Following', 'Unadjusted'), ('"Modified Following,Following,Unadjusted"',), 'Applied to contractual payment dates without schedule drift'),
    LegacyAssumptionField('payment_calendar', 'B129', 'Payment Calendar', 'CHOICE', 'Dropdown', 'TARGET', ('TARGET', 'Weekends Only'), ('"TARGET,Weekends Only"',), 'TARGET or Weekends Only'),
    LegacyAssumptionField('liability_reference_floor', 'B130', 'Liability Reference Floor', 'DECIMAL', '%', '0', (), (), 'Global minimum reference rate before tranche spread; tranche-specific floors may override'),
    LegacyAssumptionField('reinvestment_asset_reference_floor', 'B131', 'Reinvestment Asset Reference Floor', 'DECIMAL', '%', '0', (), (), 'Minimum reinvestment reference rate before asset spread'),
    LegacyAssumptionField('cash_account_rate_floor', 'B132', 'Cash Account Rate Floor', 'DECIMAL', '%', '0', (), ('"Flat,S&P Pattern 1,S&P Pattern 2,S&P Pattern 3,S&P Pattern 4"',), 'Minimum all-in cash-account accrual rate'),
    LegacyAssumptionField('default_timing_pattern', 'B133', 'Default Timing Pattern', 'CHOICE', 'Dropdown', 'Flat', ('Flat', 'S&P Pattern 1', 'S&P Pattern 2', 'S&P Pattern 3', 'S&P Pattern 4'), ('"Flat,S&P Pattern 1,S&P Pattern 2,S&P Pattern 3,S&P Pattern 4"',), 'Flat or S&P Pattern 1–4 annual timing vectors'),
    LegacyAssumptionField('discount_obligation_price_threshold', 'B134', 'Discount Obligation Price Threshold', 'DECIMAL', '% of par', '0.8', (), (), 'Asset price below threshold is treated as discounted even if the manual flag is stale'),
    LegacyAssumptionField('minimum_collateral_was', 'B135', 'Minimum Collateral WAS', 'DECIMAL', '% p.a.', '0.035', (), (), 'Generic underwriting threshold; calibrate to deal collateral-quality tests'),
    LegacyAssumptionField('minimum_collateral_warr', 'B136', 'Minimum Collateral WARR', 'DECIMAL', '%', '0.4', (), (), 'Generic weighted-average recovery-rate threshold'),
    LegacyAssumptionField('maximum_collateral_wal', 'B137', 'Maximum Collateral WAL', 'DECIMAL', 'Years', '5.5', (), (), 'Generic weighted-average life threshold'),
    LegacyAssumptionField('maximum_portfolio_warf', 'B138', 'Maximum Portfolio WARF', 'DECIMAL', 'Factor', '3000', (), (), 'Generic weighted-average rating factor threshold'),
    LegacyAssumptionField('maximum_single_obligor', 'B139', 'Maximum Single Obligor', 'DECIMAL', '% of par', '0.025', (), (), 'Generic concentration threshold'),
    LegacyAssumptionField('maximum_industry', 'B140', 'Maximum Industry', 'DECIMAL', '% of par', '0.15', (), (), 'Generic industry concentration threshold'),
    LegacyAssumptionField('collateral_cashflow_input_mode', 'B144', 'Collateral Cashflow Input Mode', 'CHOICE', 'Dropdown', 'Simplified', ('Detailed', 'Simplified', 'Mixed'), ('"Detailed,Simplified,Mixed"',), 'Detailed reads Collateral Portfolio Detailed; Simplified reads Collateral Portfolio Simplified; Mixed combines both sources by CLO collection period before one waterfall run.'),
    LegacyAssumptionField('simplified_cashflows_include_credit_prepayment_effects', 'B145', 'Simplified Cashflows Include Credit / Prepayment Effects', 'CHOICE', 'Dropdown', 'No', ('Yes', 'No'), ('"Yes,No"',), 'If Yes, the CLO Credit / Prepayment Overlay must be Off in Simplified or Mixed mode to prevent defaults/prepayments being applied twice.'),
    LegacyAssumptionField('simplified_pool_opening_performing_par', 'B146', 'Simplified Pool Opening Performing Par', 'MONEY', 'EUR; required for Mixed only when Ending Performing Par is used', '0', (), (), 'Opening-date performing par belonging only to the simplified subpool. It is needed to reconcile optional Ending Performing Par in Mixed mode; leave zero when using principal/par-reduction rows only.'),
)
LEGACY_INPUTS = tuple(field for field in LEGACY_ASSUMPTIONS if field.editable)
LEGACY_DERIVED = tuple(field for field in LEGACY_ASSUMPTIONS if not field.editable)
LEGACY_INPUT_BY_ID = MappingProxyType({field.field_id: field for field in LEGACY_INPUTS})
LEGACY_BY_SOURCE = MappingProxyType({field.source_coordinate: field for field in LEGACY_ASSUMPTIONS})
if len(LEGACY_INPUTS) != 107 or len(LEGACY_DERIVED) != 3 or len(LEGACY_INPUT_BY_ID) != 107:
    raise RuntimeError("Legacy assumption inventory must contain 107 unique inputs and 3 derived fields")


def validate_legacy_controls(values, *, require_complete=True):
    """Parse a semantic input mapping; source cell coordinates are never used.

    This validates units, types and economic ranges, not financial eligibility.
    Disabled feature parameters still receive type validation. Date relationships
    relevant only to enabled events are checked only when the event is active.
    The legacy 'Continue' reinvestment gate also accepts the VBA 'Always Reinvest'
    alias; the returned canonical value is Continue. No bad source DV is copied.
    """
    from collections.abc import Mapping
    from .records import date_value, decimal_value, integer_value
    from trident.domain.models import InputValidationError, require_money

    if not isinstance(values, Mapping):
        raise InputValidationError("Legacy controls must be a mapping of stable field IDs")
    unknown = set(values) - set(LEGACY_INPUT_BY_ID)
    missing = set(LEGACY_INPUT_BY_ID) - set(values) if require_complete else set()
    if unknown or missing:
        raise InputValidationError(f"Legacy controls unknown={sorted(unknown)} missing={sorted(missing)}")
    parsed = {}
    fractional = {
        "original_annual_default_rate", "original_recovery_rate", "ccc_fraction",
        "ccc_limit_fraction", "ccc_valuation_fraction", "maturity_liquidation_fraction",
        "original_collateral_cpr", "reinvestment_annual_prepayment_rate",
        "reinvestment_annual_default_rate", "reinvestment_recovery_rate",
        "discount_obligation_fraction", "discount_obligation_valuation_fraction",
        "defaulted_asset_valuation_fraction", "long_dated_asset_limit_fraction",
        "long_dated_oc_valuation_fraction", "minimum_collateral_warr",
        "maximum_single_obligor", "maximum_industry", "incentive_fee_rate", "equity_irr_hurdle",
        "discount_obligation_price_threshold", "call_costs_of_debt_fraction", "refi_fee_of_debt_fraction",
    }
    signed = {"liability_reference_floor", "reinvestment_asset_reference_floor",
              "cash_account_rate_floor", "first_stub_rate_override", "cash_account_spread",
              "reinvestment_asset_spread"}
    for identifier, value in values.items():
        field = LEGACY_INPUT_BY_ID[identifier]
        if field.semantic_type == "DATE":
            value = date_value(value, identifier)
        elif field.semantic_type == "CHOICE":
            if identifier == "reinvestment_test_gate" and value == "Always Reinvest":
                value = "Continue"
            if not isinstance(value, str) or value not in field.choices:
                raise InputValidationError(f"{identifier} must be one of {field.choices}")
        elif field.semantic_type == "INTEGER":
            value = integer_value(value, identifier)
            if value < 0:
                raise InputValidationError(f"{identifier} must be nonnegative")
        else:
            value = decimal_value(value, identifier)
            if field.semantic_type == "MONEY":
                require_money(value, identifier)
            elif identifier not in signed and value < 0:
                raise InputValidationError(f"{identifier} must be nonnegative")
            if identifier in fractional and value > 1:
                raise InputValidationError(f"{identifier} is a decimal fraction and cannot exceed 1")
            if identifier in {"collateral_purchase_price", "reinvestment_purchase_price", "call_collateral_sale_price"} and value <= 0:
                raise InputValidationError(f"{identifier} must be strictly positive")
        parsed[identifier] = value
    def after(first, second, inclusive=False):
        if first in parsed and second in parsed and (parsed[first] < parsed[second] if inclusive else parsed[first] <= parsed[second]):
            raise InputValidationError(f"{first} must be {'on or ' if inclusive else ''}after {second}")
    after("closing_date", "pricing_date", inclusive=True)
    after("first_note_payment_date", "closing_date")
    after("maturity_date", "closing_date")
    if "first_note_payment_date" in parsed and "maturity_date" in parsed and parsed["first_note_payment_date"] > parsed["maturity_date"]:
        raise InputValidationError("first_note_payment_date must be on or before maturity_date")
    if parsed.get("reinvestment_enabled") == "Yes":
        after("reinvestment_end_date", "closing_date")
    for enabled, event in (("optional_call_enabled", "call_date"), ("refinancing_enabled", "refinancing_date")):
        if parsed.get(enabled) == "Yes":
            if event not in parsed:
                raise InputValidationError(f"Enabled {enabled} requires {event}")
            after(event, "closing_date")
            if "maturity_date" in parsed and parsed[event] > parsed["maturity_date"]:
                raise InputValidationError(f"{event} must be on or before maturity_date")
    return MappingProxyType(parsed)


def validate_pricing_date(pricing_date, market_data_as_of, closing_date):
    """Cross-check a priced-forward-start CLO and its actual market snapshot."""
    from .records import date_value
    from trident.domain.models import InputValidationError
    pricing = date_value(pricing_date, "pricing_date")
    market = date_value(market_data_as_of, "market_data_as_of")
    closing = date_value(closing_date, "closing_date")
    if pricing != market:
        raise InputValidationError("Pricing Date must equal the supplied Market Data as-of date")
    if pricing > closing:
        raise InputValidationError("Pricing Date cannot follow Closing Date")
    return pricing
