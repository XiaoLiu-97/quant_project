# Principal-funded accrued interest and coupon proceeds

Project Trident can explicitly restore a verified principal-funded accrued balance from a native loan's first positive coupon receipt. Borrower coupon ownership and its raw cash remain unchanged; the instruction routes part of that existing cash to principal proceeds. This supports both closing and the [existing CLO opening profile](existing_clo_opening.md). It does not execute future real trades or initialize an unknown historical entitlement.

Implementation: [typed contracts and compiler](../../src/trident/clo/proceeds.py), [request scope](../../src/trident/clo/models.py), [waterfall integration](../../src/trident/clo/engine.py), [application binding](../../src/trident/application/clo_services.py) and [named Excel transport](../../src/trident/adapters/coupon_proceeds_records.py).

## Financial definitions and explicit implementation policy

The [Invesco Euro CLO I offering circular, 2 June 2026](https://ise-prodnr-eu-west-1-data-integration.s3-eu-west-1.amazonaws.com/202606/af267c52-cb3c-4250-8e12-fa114a500e55.pdf), printed p156, distinguishes principal-funded purchased accrued from ordinary coupon; printed p189 excludes purchased accrued from interest-account receipts, and printed pp290-291 directs qualifying amounts to principal. The [Barings Euro CLO 2023-2 circular](https://ise-prodnr-eu-west-1-data-integration.s3-eu-west-1.amazonaws.com/202312/6128fcdb-b2e0-4657-9e91-253aa0b70a4c.pdf), printed p181 and p278, similarly separates interest receipts and purchased-accrued principal deposits.

These are transaction examples supporting an explicit proceeds-classification layer. They do not establish one universal EUR CLO rule or an agency-approved model. The restriction to one full restoration at the first positive native coupon, the cent allocation rule below, and the separate synthetic reinvestment flag are Trident implementation policies. The actual deed, trustee statement and agent receipt instruction must support the supplied amounts and timing.

Three inputs remain distinct:

| Input | Purpose |
| --- | --- |
| `AssetPurchase.accrued_interest` | Actual closing purchase funding cost; not a borrower receipt |
| `SeasonedLoanState` and its entitlement policy | Verified borrower coupon ownership, including any retained exact historical prefix |
| `PrincipalAccruedBalance` and `CouponProceedsAllocation` | Remaining principal-funded classification balance and its explicit receipt/account instruction |

The classification balance creates no extra cash, loan face or coupon entitlement. It need not equal all accrued cost or all owned historical coupon. Closing application admission requires it not to exceed the identified purchased-accrued cost. An existing opening requires a sufficient positive sourced retained coupon entitlement, while historic purchased-accrued funding inputs stay zero. These are necessary numerical controls, not proof of legal authority. The standalone compiler cannot authenticate either document.

## Data contract

`CloRunRequest` and `TridentModelRequest` accept immutable tuples named `principal_accrued_balances` and `coupon_proceeds_allocations`. Both empty means ordinary configured native coupon routing remains in force. One nonempty tuple requires its matching counterpart; a missing instruction does not silently mean zero.

| Record | Mandatory fields |
| --- | --- |
| `PrincipalAccruedBalance` | `loan_id`, actual opening `as_of_date`, positive EUR-cent `amount`, `source`, `legal_reference` |
| `CouponProceedsAllocation` | Unique `allocation_id`, `loan_id`, actual `payment_date`, typed `SCHEDULED` or `PREPAYMENT` `collection_source`, positive EUR-cent `principal_amount`, explicit Boolean `original_principal_permission`, `source`, `legal_reference` |

Each claimed loan has exactly one balance and one allocation. Their amounts must equal: this profile restores the entire verified remaining classification balance, rather than partially collecting a larger balance. Dates are calendar dates; datetime values, nonfinite money, binary floats, fractional cents, blank references, duplicate identities and mutable containers reject. Balance as-of must equal the actual projection opening. Receipt must follow opening and fall on/before CLO legal final.

The named Excel tables carry these same explicit records; the separate Coupon Proceeds audit exposes what was applied. Supply a trustee/settlement source for the opening balance and the precise verified receipt/account instruction with its legal clause. The model does not derive either record from elapsed days, Bloomberg price, a ledger account permission or an aggregate funding amount.

## Physical receipt grouping and exact cash allocation

The compiler groups the already generated raw stream by `(loan_id, payment_date, source)`. Multiple component rows can represent one physical coupon, for example forward coupon and an explicit inherited-entitlement component on the same day. It retains every source row unchanged, exposes their count, and produces per-index restoration markers only within that group.

The target must be the loan's unique earliest **positive** native coupon group. A prior zero coupon pays nothing. Two positive sources on the earliest date are ambiguous and reject. A wrong date/source, missing receipt or insufficient first coupon cannot be filled from another loan or a later coupon. Scheduled cash and prepayment ownership have already been resolved by the asset/credit engine; this compiler adds no new credit-event order or fixing request.

For grouped raw borrower coupon `C`, raw face-principal receipt `P` and the supplied full restoration `R`:

```text
0 < R <= C
interest proceeds  = C - R
principal proceeds = P + R
interest proceeds + principal proceeds = C + P
remaining principal-accrued classification balance = 0
```

`R` is already an executable cent target. It is assigned exactly; the interest account receives the residual of the borrower's already posted gross cash. The module does not separately repost future earned coupon and historical accrual. This avoids creating a one-cent difference when a full borrower coupon was posted once. Stable source-index splitting is bookkeeping within one grouped receipt, not FIFO between loans, dates or independent claims. All monetary aggregation uses exact `Fraction` arithmetic, including large balances under low Decimal precision and traps.

```mermaid
flowchart TD
    A[Verified raw contractual or explicit credit receipts] --> B[Group loan / actual date / source]
    C[Sourced opening balance and full receipt instruction] --> B
    B --> D[Validate unique first positive native coupon]
    D --> E[Keep borrower coupon and face principal unchanged]
    E --> F[Restore supplied cents to principal; leave interest residual]
    F --> G[Receive into classified pending accounts]
    G --> H[Release cash and explicit permission at normal cutoff]
    H --> I[Shared IC / OC / cures / debt / equity waterfall]
    F --> J[Grouped receipt audit and independent reconciliation]
```

## Waterfall, OC/IC and reinvestment effects

The classified account amounts enter received cash and then follow the ordinary determination cutoff. Restoration creates no separate receipt or second eligibility release. It can reduce IC interest proceeds, change a cure/diversion decision and repay debt earlier. When configured, OC includes actual classified principal-account cash; performing face and face-based fees do not change merely because a coupon was reclassified. The unresolved opening classification balance is a memo, **not automatically added as OC collateral credit**. A deal requiring another accrued-receivable valuation needs that separately validated legal profile.

Raw scheduled/prepayment/recovery principal metrics, par movements and bank-interest receipt chronology retain their source economics. Restoring accrued is not a loan repayment or a new recovery. Collection-account remuneration still sees the same total physical cash on the same dates.

Account routing does not automatically grant acquisition permission. `original_principal_permission=True` adds precisely `R` to the existing original-principal permission subset when its cash becomes eligible; False adds zero. This flag grants only the modeled synthetic permission, subject to the existing window, gate and liquidity rules. It does not approve a real reinvestment trade. An enabled recycle-all synthetic policy with any noneligible restoration rejects, because that broader spending policy cannot preserve the supplied restriction.

`CloProjection.coupon_proceeds_audit` contains allocations whose receipts were reached before projection stopped. Each row shows raw coupon/principal, restored accrued, classified interest/principal, zero remaining classification balance, monetary permission subset, source row count, balance/allocation sources and the allocation's legal reference. A receipt still pending cutoff can have an audit while its cash and permission remain unavailable for acquisition. Instructions beyond an early cash-pay failure are not reported as collected restorations; their original input records remain visible.

## Independent two-period control

An original EUR100-par fixed loan accrues at 12% ACT/360 from 1 April. Closing/as-of is 15 May; the full-current-period opening prefix is independently verified as EUR1.47, posted to cents. The first borrower coupon on 1 July covers 91 days and posts **EUR3.03 once**. A new EUR80-par note at 6% ACT/360 accrues 47 days from closing and owes EUR0.63. Purchase at par plus EUR1.47 accrued, less EUR80 debt proceeds, requires EUR21.47 equity funding. No fees/reserve or reinvestment are active. All amounts in the table are EUR.

| Cash item | 1 July | 1 October |
| --- | ---: | ---: |
| Raw borrower coupon | 3.03 | 3.07 |
| Raw borrower face repayment | 0.00 | 100.00 |
| Principal-funded accrued restored | 1.47 | 0.00 |
| Interest proceeds | 1.56 | 3.07 |
| Principal proceeds | 1.47 | 100.00 |
| Note coupon paid | 0.63 | 1.20 |
| Note face paid | 1.47 | 78.53 |
| Equity distribution | 0.93 | 23.34 |

After the first distribution note face is 78.53; its next 92-day coupon is `78.53 * .06 * 92/360`, posting 1.20. Lifetime borrower cash106.10 equals debt face80, note coupon1.83 and equity24.27. Without restoration the note remains80 for the second coupon, coupon totals1.86 and equity totals24.24. That three-cent lifetime difference comes from earlier debt repayment; investor IRR additionally depends on the changed distribution timing and initial cost, so restoration does not guarantee a higher IRR.

## Supported scope and fail-closed boundaries

This release supports identified native EUR cash-pay collateral with one full first-coupon restoration. It rejects imported/additional external receipt streams, enabled proportional original-pool overlays, default on a claimed loan, optional-call sale allocation, partial collections and restoration after legal final. An unrelated loan's explicit default can remain supported. A claimed loan's explicit full prepayment can restore from its verified actual prepayment coupon if the instruction matches that source/date and sufficient cash exists. No unpaid-coupon recovery, capitalized-interest, sale-accrued, future trade-lot or default-loss policy is inferred.

Active receipt instructions also reject automatic closing what-if edits and optimizer/candidate rebinding. Changes to par, coupon, price, settlement or credit can invalidate an exact sourced instruction. Prepare a separately verified baseline and refreshed records; the system will not rescale or move a legal receipt instruction merely to make a candidate pass.

Independent controls are [compiler and scope tests](../../tests/test_coupon_proceeds.py) and [financial acceptance tests](../../tests/test_coupon_proceeds_acceptance.py). They check raw-versus-account conservation, first-receipt matching, grouping, large-money cents, cutoff, OC/IC, cure effects, permission and debt/equity timing. Independent trustee benchmarks should additionally reconcile the raw asset receipt, Coupon Proceeds audit, affected accounts and actual IC/OC stages for the intended transaction.
