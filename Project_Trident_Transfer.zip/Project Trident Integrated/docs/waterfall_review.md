# 当前 waterfall 流程图与定向审查

日期：2026-10-08。对应 Project Trident Integrated 0.12.3。本轮修复 reinvestment 的拟买后 coverage 检查、购买后即时 OC 更新，以及实际清算后的 OC 清除。

[17页中文阅读指南与流程图](../outputs/Project_Trident_Waterfall_Flowcharts_CN.pdf) 使用完整中文动作标题，每页一个主题，主流程、释义、手算及模型边界分开。可搜索文字版见[waterfall中文指南](waterfall_guide_cn.md)。图中绿色是执行步骤，蓝色是定义与示例，黄色是条件及适用边界；内容逐项对照当前代码，真实交易仍需法律映射。

PDF阅读路线：第1页总览；第2页新发行与存续起点；第3-6页合同、信用、回收及账户；第7-11页费用、OC、IC、利息优先级及独立IDT；第12-15页再投资、本金分配、特殊事件及incentive；第16-17页守恒核对、Excel入口、术语与来源。

本次为说明文档重做：模型计算、金融源码、测试及Excel工作簿未修改。全部17页渲染与文字对照完成，15项独立教学手算核对通过；未重复执行完整金融回归。证据见[文档验收](validation/waterfall_guide_cn.json)。

## 1. 资产、信用与实际收款

```mermaid
flowchart TD
  I[合同 terms / holdings / 曲线 fixing / bespoke principal] --> R[合同现金流 reference：cash 与 PIK / face 分开]
  R --> S{选择互斥 source 路径}
  S -->|无信用处理| N[合同 actual-date 收款]
  S -->|原池 overlay On| D[Midpoint proportional default：未收 coupon 不作为现金]
  S -->|明确 dated event| E[同日 scheduled-first；full exit 取消后续流]
  D --> A[Surviving coupon / PIK / scheduled amortization]
  A --> P[付款日 CPR on remaining face]
  D --> C[Default claim；无 default receipt]
  E -->|DEFAULT only| C
  C --> Q[Default date + calendar-month lag / explicit recovery installments]
  Q --> K[实际 recovery principal + loss；不恢复 performing face]
  N --> L[单一 authoritative collections / par movements]
  P --> L
  E --> L
  K --> L
  L --> J[有来源的 coupon proceeds 分类；face 与 borrower cash 不变]
  J --> F[Actual receipts 入 pending；按 determination cutoff 释放 available I/P]
  F --> B[Physical cash 生息；post-cutoff cash 保留，future cash 不提前入账]
```

Flat hazard：`q = 1 - (1 - annual_probability)^(actual_days/365)`。原池顺序为 default、surviving scheduled、CPR，确定性比例情景，不是随机 borrower default。违约 slice 的当期未收 coupon 不收；付款日预付 slice 获得 surviving coupon。五年 timing vector 使用 `P0*[1-(1-CDR)^5]` 作为本模型经济目标，未分配目标明确报告，不等同机构 SDR。

Proportional recovery 在实际违约日期加 lag 月后，收到 `default_face*RR`，余下计 loss；显式事件支持多次 recovery schedule。RR0 仍保留 / 结清真实 claim；horizon 后的权利不提前成为现金。出售 default claim 后取消其未来 recovery rights。

## 2. Interest waterfall / IC / OC

```mermaid
flowchart TD
  A[Available I/P、pending、reserve、当前 face / claims] --> F[应计 expenses / senior-sub fees / note coupons]
  F --> P[Mandatory PIK 加 face；现金 coupon 与 arrears 单独记录]
  P --> E[Interest 付 senior expenses、senior management；授权 reserve 补足]
  E --> C[依次付 tested class 的 own coupon]
  C --> T{该层 GATE：OC / IC 失败？}
  T -->|否| NEXT[继续下一层 coupon / gate]
  NEXT --> C
  T -->|是、diversion Off| BLOCK[Block junior，保留现金]
  T -->|是、diversion On| MODE{ALL_RESIDUAL 或 OC-only cure？}
  MODE -->|ALL_RESIDUAL / IC fail| ALL[Sequential 还 senior-through-tested；本次不恢复 junior]
  MODE -->|CURE_OC_AND_CONTINUE 且 IC 未失败| MIN[ceil-cent 最少 interest-funded OC 还本]
  MIN --> RE{实际 retest 通过？}
  RE -->|是| NEXT
  RE -->|否| BLOCK
  ALL --> BLOCK
  NEXT -->|所有层已完成| FEES[Deferred expense 再 subordinated fee]
  FEES --> EQUITY[无 senior / coupon claims 时 gross equity I 候选]
  EQUITY --> IDT[独立 IDT：按 cap 将实际 I 转 principal designation]
  BLOCK --> PRI[Principal waterfall]
  IDT --> PRI
```

费用：fixed annual expenses 乘明确 DCF；variable expense / management fee 使用所选 par-year basis 乘 bps/10000。Opening fee arrears 加回 due；当前 profile 不对 fee arrears 复利。Expense cap 是付款优先级限制，超出仍形成 deferred expense claim。

IC numerator 在本期固定：opening available interest + eligible receipts + bank earnings - senior expense/management dues + actual authorized reserve draw。Denominator 为 senior-through-tested 本期应付 coupon、arrears interest 与应包含的历史 cash-pay arrears；deferred principal 由独立开关决定。当日 principal redemption 不会倒改本期 coupon。

OC numerator 为 adjusted collateral credit + 按配置纳入的实际 principal cash（含 pending）；denominator 为 tested senior stack face + 配置认可的 deferrable unpaid coupon。Asset-level：CCC excess 按最低 current mark 选择，discount 按 acquisition price，long-dated 按配置；同一 face slice 取最差 valuation 一次。Top-down profile 按配置的 aggregate fractions 做有上限的加总 haircut，是明确 proxy。Default OC credit 是估值，不是现金。

Three mechanics：interest-funded debt cure `ceil_cent(max(0,D-N/k))`；principal cash 纳入 OC numerator 且直接用于 face paydown（没有 coupon claim 消耗）时，N、D 同时减少，k>1 的理论 cure 为 `(kD-N)/(k-1)`；若 principal cash 不纳入 N，则 N 不变，理论 cure 为 `D-N/k`。当前实现按本金分配而非这些公式直接强制；独立 IDT transfer 为 `min(floor_cent(alpha*residual_I),ceil_cent(max(0,kD-N)))`，增加 N 而不降低 D。

当前 IDT 位于 subordinated management fee 之后，真实 deal 可能在其之前。缺 threshold、已清偿或未到达 gate 的状态分别保留，不能伪装 PASS。

PDF 第11页的独立例子采用 `N=120, D=100, k=1.25`，假定实际支付直接降低同等金额的 tested debt，未有 coupon claim 消耗：interest-funded cure 需4；被纳入OC的principal-funded cure 需20；单纯将interest转为计入OC的principal designation需5。三种操作改变的分子与分母不同，不能用同一个shortfall公式。实际执行仍受现金、priority、cap、claims与retest约束。

PDF 第15页的 incentive 手算对应当前 `EquityHurdleAccount`：hurdle10%、manager share20%、每期恰好365天，初始已付equity100。第一期gross residual8，hurdle先长至110，fee0、equity8、未满足hurdle102。第二期先按10%增长至112.20，再加入当日equity contribution5，hurdle为117.20，gross residual120；fee为 `(120-117.20)*20%=0.56`，equity distribution119.44、扣除新增出资后的net cash114.44，hurdle结清。该计算属于明确的marginal paid-capital hurdle，不自动等于任一实际CLO的XIRR trigger合同。


## 3. Principal / reinvestment / deleverage / equity

```mermaid
flowchart TD
  A[Optional call / configured maturity sale] --> B[Principal 补 senior claims，再按权限补 coupon]
  B --> F[Final day actual residual interest 先补未清 debt]
  F --> G{Synthetic purchase eligible?}
  G -->|否| P[普通本金分配]
  G -->|是| C[只读 purchase plan：实际 cost / acquired face / maturity]
  C --> X{拟买后 adjusted OC 与本期 IC 满足 STOP？}
  X -->|通过或明确 ALWAYS override| COMMIT[验证 plan 并提交 cohort；立即更新当前 OC]
  X -->|不通过| REJECT[拒购无状态修改；held IDT 保留 earmark]
  COMMIT --> P
  REJECT --> P
  P --> M{PRO_RATA 且 test pass / no unpaid?}
  M -->|是| R[按实际face比例；最大余数法分配cents，ties按seniority]
  M -->|否| S[Sequential controlling-class claim 然后 own face]
  R --> J[清偿 debt / necessary claims 后付 junior fees，再 equity P]
  S --> J
  J --> N[Refi fee 由 extra equity contribution；下期新 spread]
  N --> V[核对 assets / claims：settled 才释放 reserve 至 gross residual]
  V --> H[Actual-funded hurdle；surplus incentive fee；net equity cash]
  H --> E[当期各层 GATE / POST_DIVERSION / PERIOD_END + 五类守恒]
  E --> Q{Assets / accounts / claims settled?}
  Q -->|是| DONE[Completed；完整 terminal return]
  Q -->|否且尚有下一期| LOOP[按 failure policy 继续下一期]
  Q -->|legal final / stop| STOP[保留 unresolved status；不编造 sale / IRR]
```

Purchase plan 不消耗 cohort ID，不创建未来 coupon 或 recovery rights。拟买后 valuation 增加实际取得的 face，扣除实际 posted cost，重新计入所选 haircut、pending cash policy 及 claims。STOP 同时要求买前、拟买后通过；整笔计划被否决时不另搜索较小购买量。ALWAYS 是明确 sensitivity，仍受分类、合同 maturity 和现金保护。

Synthetic purchases 仅使用已收到、可支配且有用途权限的 principal；`recycle=False` 使用 original principal permission + held IDT。Designation 是现款子集。Acquired face 向下取 cent，actual consideration 扣一次，残额留账户；maturity 为 purchase + WAL 转 calendar months，不静默截短至 legal final。新 cohort 的信用参数独立。

Call 只在足额清偿全部债务/claims/cost 时执行；sale 的 defaulted-collateral cash price 与 OC credit 分开。实际 sale 后立即将售出 collateral 的非现金 OC credit 清零，避免与售卖现金双计；未执行的 call 保留资产及估值。Refi 只是保留 par / priority / maturity 的 spread amendment，下期生效；费用按当前分配后 debt face，equity 增资支付。

Incentive 当前机制（不是所有合同的通用规则）：

`Hpre = Hprev*(1+h)^(actual_days/365) + new_actual_equity_funding`

`fee = post_cent(s*max(0,gross_equity_residual-Hpre))`

`net_equity = gross_equity_residual-fee`

`Hnew = max(0,Hpre-net_equity)`

Gross residual 含 interest、principal、最终 reserve；初始 hurdle 为 actual cash funding，fee 从 interest、principal、reserve 顺序扣除。真实 all-residual IRR trigger、catch-up、historical hurdle、fee VAT / accrual 等须另映射，不能声称相同。

## 修复与独立已知答案

1. **溢价购买后的 OC veto**：原 collateral100、debt80、minimum1.25，收到 scheduled principal10 后为90collateral+10cash。Price1.01拟用10cash取得9.90par，会使99.90/80=1.24875失败。当前 STOP 拒绝整笔 purchase；不创建新资产，普通10cash偿债，debt降至70。
2. **购买后即时估值与 pro-rata**：受支持 Existing 边界的 collateral100、principalcash20，其中 original permission10；A50/B40、minimum1.30、price1、recycleFalse。买10par后当前 N=110collateral+10cash=120；通过 gate，剩余10cash正确付A5.56/B4.44，而非错误全部付A。
3. **清算后的当前 collateral credit**：collateral100、A50/B40，实际清算仅收到50cash；出售资产已无 collateral OC credit。OC50/90失败，正确 sequential 付A50/B0；不再用旧100collateral造成假 PASS 和27.78/22.22的错误 pro-rata。

实现使用纯 `plan_purchase()` → prospective valuation / coverage → validated `commit_purchase()`。同一当前 valuation 随后用于 PRINCIPAL_GATE 和 PERIOD_END；已有当期 IC numerator / debt service 不因新资产未来 coupon 改变。Rejected、stale、altered plan 不污染 cohort / face / recovery；asset-level synthetic classification 与禁止 long-dated 的保护保留。

拒购不增加报告 stage。Reinvestment cash=0 也可能来自拟买后 coverage 否决，即使可见 GATE 与 PERIOD_END 都 PASS；目前没有单独保存 purchase-rejection reason，不能仅凭这两个可见 stage 判断是否应成交。保存示例 Reinvestment=No；三个完整 case 的金融结果已独立核对为精确一致。另对150资产、40期的只读内存变体启用 reinvestment，12笔购买及其后续 prepayment/default/recovery 完成投影，资金守恒通过。工作簿最终发布状态见修复记录。

## 明确适用边界

- Existing opening 只支持原付款日分配后边界；不支持 mid-period、positive opening-default inventory，enabled incentive 因缺 historical hurdle 而明确拒绝。
- Synthetic reinvestment 是经济模板，没有真实 dealer execution / dated trade ownership，当前已加入 generic post-purchase coverage；完整 legal eligibility / collateral-quality tests 与 maintained/improved exemptions 仍需具体交易映射。
- Generic IC 以实际可用 cash 为 basis；具体 deal 可用 determination-date expected income，另有 hedges / smoothing / tax。
- Rating / recovery / sector source、CCC/discount 定义与 tranche contract 的 validated mapping 仍是使用真实 CLO 的必要前提。

## 计算逻辑来源与 market convention 的验证

逻辑分三层：现金、面值、债权及 cure 使用明确金融数学；支付优先级、IC/OC 定义、费用和购买权限用真实 offering circular / indenture 交叉核对；比例 CDR/CPR、constant recovery/lag、synthetic bullet cohort 及 generic STOP 是公开记录的模型假设。旧工作簿用作业务参考，不能自动成为正确答案。

当前 references 不是一份通用法律模板。OCP 的 2026 文件包含 expected/scheduled income 口径的 IC、交易特定 IDT priority 与 incentive IRR trigger。Invesco 的 2026 文件包含部分已失败测试的 maintained/improved 例外，并可能重建 sale/prepayment 之前的基准。当前 generic IC、paid-capital marginal hurdle 和全部配置 coverage 买前/买后通过的 STOP policy 均有明确差异；ALWAYS sensitivity 不能替代实际法律许可。

判断一笔实际 CLO 是否符合条款，需要可追踪的链条：执行条款 → 拥有者 inputs → 公式及事件顺序 → 独立手算 / 压力回归 → trustee 或独立 benchmark 对账。公开文档对照和软件测试各自证明覆盖的部分，不构成所有交易、所有参数的 blanket certification。

## 核验范围与证据

新增 `test_reinvestment_acquisition_gate.py` 的 **19 项独立回归通过**，包括上述三项手算、discount/premium、long-dated haircut、ALWAYS、cash exclusion、pending cutoff、expired/final/call、IC 不变性、reject/plan 无状态修改、金额精度及分类保护。完整回归 **1,797项全部通过，零failure/error/skip**，源码、测试和日志的216项hash独立核对一致，记录见[当前验证](validation/current.json)；本轮修复交付、文件哈希及独立检查见[修复记录](validation/waterfall_repair.json)。

现金、performing face、default claims、debt face、coupon claims 各自守恒，是必要检查；cash residual=0 和期末 OC PASS 仍不足以证明中间 gate / allocation 正确。

权威 reference（解释差异，不声称所有条款复现）：

- [S&P corporate CLO default/timing guidance](https://www.spglobal.com/ratings/en/research/articles/190621-guidance-criteria-structured-finance-cdos-global-methodology-and-assumptions-for-clos-and-corporate-cdos-11005168)，2019，2024-10-25归档并将相关内容移入 criteria；default-period coupon 和 timing 的来源交叉核验，不能称当前文档版本。
- [OCP EUR January 2026 Offering Circular](https://ise-prodnr-eu-west-1-data-integration.s3-eu-west-1.amazonaws.com/202601/07d64e17-e59d-4980-b089-0096b0ee4bc1.pdf)，printed pp130-140、167、201-206、357-359：实际 valuation / coverage / priority / IDT / fees 对照，仅该 deal 例子。
- [Invesco Euro CLO I June 2026 Offering Circular](https://ise-prodnr-eu-west-1-data-integration.s3-eu-west-1.amazonaws.com/202606/af267c52-cb3c-4250-8e12-fa114a500e55.pdf)，printed pp285–288：买前与拟买后 tests、maintained/improved 以及 permissions；仅作该交易条款对照。
- [S&P PF CLO criteria FAQ](https://www.spglobal.com/ratings/en/regulatory/article/-/view/sourceId/101626294)，2025：project-finance recovery timing / criteria 与普通 corporate BSL 区分；模型 constant RR/lag 不是 hybrid agency calibration。

主要源码：`credit/overlay.py`、`credit/engine.py`、`clo/engine.py`、`clo/reinvestment.py`、`clo/lifecycle.py`、`clo/opening.py`。金融修复修改两个 CLO 模块；独立展示修复统一日期/单位，完善隐藏和预留区域、状态、冻结、列宽、字体层级及帮助文字。输入 schema 和15个用户页保持一致；模板与完整验收见[界面格式](interface_style.md)及[验收](readiness.md)。
