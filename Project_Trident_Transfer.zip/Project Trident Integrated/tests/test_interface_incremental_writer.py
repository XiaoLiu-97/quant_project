"""Stable-template publication regressions independent of the financial engine.

These small workbooks exercise the result boundary, not the production file.
The expectations distinguish unchanged formulas from changed saved results,
protect raw inputs/native metadata, and require failed publication to leave a
previous complete workbook intact. Large reserved Tables stay mostly virtual.
"""
from datetime import date
from decimal import Decimal
from types import SimpleNamespace
import unittest
import os
from unittest.mock import patch
import xml.etree.ElementTree as ET
import zipfile

from openpyxl import load_workbook

import test_interface_package as fixtures
from trident.adapters.interface_output_capacity import CapacityWorkbookPackage
from trident.adapters.interface_package import (
    WorkbookPackage, FormulaCell, ExcelError, MAIN, _tag,
)
from trident.domain.models import InputValidationError


class IncrementalWriterTests(unittest.TestCase):
    """Use hand-selected values and package bytes as independent expectations."""

    def setUp(self):
        fixtures.InterfacePackageTests.setUp(self)

    def package(self, source=None):
        return WorkbookPackage(source or self.source,
            protected_names=('trident_ui_cash_input',),
            protected_tables=('tbl_trident_ui_pool',))

    def capacity_package(self, source=None):
        cashflows = SimpleNamespace(cashflows=(SimpleNamespace(loan_id='A'),))
        run = SimpleNamespace(baseline=SimpleNamespace(cashflows=cashflows),
            library_projection=None,
            cases=(SimpleNamespace(result=SimpleNamespace(clo=None)),),
            inputs=SimpleNamespace(capital=('A',)))
        return CapacityWorkbookPackage(source or self.source, run=run,
            protected_names=('trident_ui_cash_input',),
            protected_tables=('tbl_trident_ui_pool',))

    @staticmethod
    def rows(value):
        return ({'Metric': 'Saved result', 'Value': value,
                 'Date': date(2026, 11, 20)},)

    def assert_cell_values(self, path, address, formula, value, kind=None):
        formulas = load_workbook(path, data_only=False)
        values = load_workbook(path, data_only=True)
        try:
            self.assertEqual(formulas['Output'][address].value, formula)
            self.assertEqual(values['Output'][address].value, value)
            if kind is not None:
                self.assertEqual(values['Output'][address].data_type, kind)
        finally:
            formulas.close()
            values.close()

    def assert_rejected_without_publication(self, package, destination):
        """A safe failure must retain bytes and remove temporary ZIPs."""
        original = destination.read_bytes()
        before = set(self.root.glob('.trident-ui-*.xlsx'))
        with self.assertRaises(InputValidationError):
            package.save(destination, overwrite=True)
        self.assertEqual(destination.read_bytes(), original)
        self.assertEqual(set(self.root.glob('.trident-ui-*.xlsx')), before)

    def test_same_display_formula_refreshes_changed_numeric_cache(self):
        package = self.package()
        formula = 'trident_ui_cash_input'
        package.write_table('tbl_trident_ui_output', self.rows(FormulaCell(formula, 100.01)))
        first = package.save(self.root / 'first.xlsx')
        repeat = self.package(first)
        repeat.write_table('tbl_trident_ui_output', self.rows(FormulaCell(formula, 102.34)))
        second = repeat.save(self.root / 'second.xlsx')
        self.assert_cell_values(second, 'B2', '=' + formula, 102.34, 'n')

    def test_formula_cache_type_transitions_do_not_leave_old_types_or_values(self):
        cases = (
            (0, False, False, 'b'),
            (False, 0, 0, 'n'),
            (1.25, 'NOT_AVAILABLE', 'NOT_AVAILABLE', 's'),
            ('NOT_AVAILABLE', '', None, 'str'),
            ('text', None, None, 'n'),
            (None, Decimal('0.1234'), 0.1234, 'n'),
            (1, ExcelError('#N/A'), '#N/A', 'e'),
            (ExcelError('#N/A'), 2, 2, 'n'),
        )
        for index, (old, new, expected, kind) in enumerate(cases):
            with self.subTest(old=old, new=new):
                package = self.package()
                package.write_table('tbl_trident_ui_output', self.rows(FormulaCell('1+1', old)))
                first = package.save(self.root / f'types-{index}-first.xlsx')
                repeat = self.package(first)
                repeat.write_table('tbl_trident_ui_output', self.rows(FormulaCell('1+1', new)))
                saved = repeat.save(self.root / f'types-{index}-second.xlsx')
                self.assert_cell_values(saved, 'B2', '=1+1', expected, kind)

    def test_fast_value_comparison_does_not_bypass_invalid_numeric_guards(self):
        for invalid in (Decimal('NaN'), Decimal('Infinity'), Decimal('1e-999')):
            for formula in (False, True):
                with self.subTest(invalid=invalid, formula=formula):
                    package = self.package()
                    previous = FormulaCell('1-1', 0) if formula else 0
                    incoming = FormulaCell('1-1', invalid) if formula else invalid
                    package.write_table('tbl_trident_ui_output', self.rows(previous))
                    with self.assertRaises(InputValidationError):
                        package.write_table('tbl_trident_ui_output', self.rows(incoming))

    def test_equal_value_with_changed_formula_must_replace_formula(self):
        package = self.package()
        package.write_table('tbl_trident_ui_output', self.rows(FormulaCell('1+1', 2)))
        package.write_table('tbl_trident_ui_output', self.rows(FormulaCell('2*1', 2)))
        saved = package.save(self.root / 'formula-change.xlsx')
        self.assert_cell_values(saved, 'B2', '=2*1', 2)

    def test_literal_formula_text_remains_distinct_from_a_formula_result(self):
        for index, (old, new, formula, value, kind) in enumerate((
            (FormulaCell('1+1', 2), '=1+1', '=1+1', '=1+1', 's'),
            ('=1+1', FormulaCell('1+1', 2), '=1+1', 2, 'n'),
        )):
            with self.subTest(old=old, new=new):
                package = self.package()
                package.write_table('tbl_trident_ui_output', self.rows(old))
                package.write_table('tbl_trident_ui_output', self.rows(new))
                saved = package.save(self.root / f'literal-{index}.xlsx')
                self.assert_cell_values(saved, 'B2', formula, value, kind)

    def test_unchanged_publication_keeps_native_cell_and_worksheet_extensions(self):
        package = self.package()
        rows = self.rows(FormulaCell('1/10', 0.1))
        package.write_table('tbl_trident_ui_output', rows)
        part = package._sheet_parts()['Output']
        tree = package._xml(part)
        cell = package._sheet_cells(tree)['B2']
        cell.set('ph', '1')
        extension = ET.SubElement(cell, _tag('extLst'))
        item = ET.SubElement(extension, _tag('ext'), uri='urn:trident:cell-test')
        ET.SubElement(item, '{urn:trident:preserved}state', source='native').text = 'KEEP'
        worksheet_ext = ET.SubElement(tree, _tag('extLst'))
        item = ET.SubElement(worksheet_ext, _tag('ext'), uri='urn:trident:sheet-test')
        ET.SubElement(item, '{urn:trident:preserved}state').text = 'WORKSHEET'
        package._put_xml(part, tree)
        first = package.save(self.root / 'native-first.xlsx')
        repeat = self.package(first)
        repeat.write_table('tbl_trident_ui_output', rows)
        second = repeat.save(self.root / 'native-second.xlsx')
        with zipfile.ZipFile(first) as before, zipfile.ZipFile(second) as after:
            self.assertEqual(before.read(part), after.read(part))

    def test_changed_cache_preserves_existing_native_cell_extension(self):
        package = self.package()
        package.write_table('tbl_trident_ui_output', self.rows(FormulaCell('1/10', 0.1)))
        part = package._sheet_parts()['Output']
        tree = package._xml(part)
        cell = package._sheet_cells(tree)['B2']
        cell.set('ph', '1')
        extension = ET.SubElement(cell, _tag('extLst'))
        item = ET.SubElement(extension, _tag('ext'), uri='urn:trident:cell-test')
        ET.SubElement(item, '{urn:trident:preserved}state').text = 'KEEP'
        package._put_xml(part, tree)
        first = package.save(self.root / 'cache-native-first.xlsx')
        repeat = self.package(first)
        repeat.write_table('tbl_trident_ui_output', self.rows(FormulaCell('1/10', 0.2)))
        second = repeat.save(self.root / 'cache-native-second.xlsx')
        self.assert_cell_values(second, 'B2', '=1/10', 0.2)
        with zipfile.ZipFile(second) as archive:
            root = ET.fromstring(archive.read(part))
            saved = root.find(".//{" + MAIN + "}c[@r='B2']")
            self.assertEqual(saved.attrib.get('ph'), '1')
            self.assertEqual(saved.findtext('.//{urn:trident:preserved}state'), 'KEEP')

    def test_capacity_repeat_preserves_structure_input_styles_charts_and_zip_metadata(self):
        package = self.capacity_package()
        rows = self.rows(FormulaCell('1/10', 0.1))
        package.write_table('tbl_trident_ui_output', rows)
        first = package.save(self.root / 'reserved-first.xlsx')
        repeat = self.capacity_package(first)
        before_info = repeat.table_inventory()['tbl_trident_ui_output']
        repeat.write_table('tbl_trident_ui_output', self.rows(FormulaCell('1/10', 0.2)))
        second = repeat.save(self.root / 'reserved-second.xlsx')
        after_info = repeat.table_inventory()['tbl_trident_ui_output']
        self.assertEqual(before_info, after_info)
        self.assertEqual(after_info.ref, 'A1:C301')
        with zipfile.ZipFile(first) as before, zipfile.ZipFile(second) as after:
            unchanged = (repeat._sheet_parts()['Market Data'],
                         repeat._sheet_parts()['Inputs'],
                         'xl/styles.xml', 'xl/workbook.xml', before_info.part,
                         'xl/charts/chart1.xml')
            for part in unchanged:
                with self.subTest(part=part):
                    self.assertEqual(before.read(part), after.read(part))
                    a, b = before.getinfo(part), after.getinfo(part)
                    self.assertEqual((a.date_time, a.compress_type, a.comment, a.extra, a.external_attr),
                                     (b.date_time, b.compress_type, b.comment, b.extra, b.external_attr))
        self.assert_cell_values(second, 'B2', '=1/10', 0.2)

    def test_removed_case_and_shrunk_result_leave_no_stale_backing_or_display(self):
        package = self.capacity_package()
        baseline = self.rows(0.10)
        downside = self.rows(0.08) + ({'Metric': 'Extra', 'Value': 123.45, 'Date': date(2027, 2, 22)},)
        package.add_case_view('tbl_trident_ui_output', {'BASELINE': baseline, 'DOWN': downside})
        first = package.save(self.root / 'cases-first.xlsx')
        repeat = self.capacity_package(first)
        repeat.add_case_view('tbl_trident_ui_output', {'BASELINE': self.rows(0.11)})
        second = repeat.save(self.root / 'cases-second.xlsx')
        values = load_workbook(second, data_only=True)
        formulas = load_workbook(second, data_only=False)
        try:
            self.assertEqual(values['Output']['B2'].value, 0.11)
            self.assertIsNone(values['Output']['B3'].value)
            self.assertIsNone(formulas['Output']['B3'].value)
            backing = repeat.table_inventory()['tbl_trident_ui_results_output']
            sheet = values[backing.sheet]
            records = [row for row in sheet.iter_rows(min_row=backing.bounds[1] + 1,
                       max_row=backing.bounds[3], min_col=backing.bounds[0],
                       max_col=backing.bounds[2], values_only=True) if row[0] is not None]
            self.assertEqual(len(records), 1)
            self.assertEqual(records[0][0:2], ('BASELINE|1', 'BASELINE'))
            self.assertNotIn('DOWN', [value for row in records for value in row])
        finally:
            values.close()
            formulas.close()

    def test_empty_result_clears_previous_formula_cache_without_fake_zero(self):
        package = self.capacity_package()
        package.write_table('tbl_trident_ui_output', self.rows(FormulaCell('1+1', 2)))
        package.write_table('tbl_trident_ui_output', ())
        saved = package.save(self.root / 'empty.xlsx')
        values = load_workbook(saved, data_only=True)
        formulas = load_workbook(saved, data_only=False)
        try:
            self.assertEqual(package._row_counts['tbl_trident_ui_output'], 0)
            self.assertEqual(package.table_inventory()['tbl_trident_ui_output'].ref, 'A1:C301')
            for address in ('A2', 'B2', 'C2', 'A301', 'B301', 'C301'):
                self.assertIsNone(values['Output'][address].value)
                self.assertIsNone(formulas['Output'][address].value)
        finally:
            values.close()
            formulas.close()

    def test_raw_byte_replacement_invalidates_cached_schema_scalar(self):
        package = self.package()
        package.read_scalar('trident_ui_schema')
        package.table_inventory()
        workbook = ET.fromstring(package.parts['xl/workbook.xml'])
        definition = workbook.find(".//{" + MAIN + "}definedName[@name='trident_ui_schema']")
        definition.text = '"2.0"'
        package.parts['xl/workbook.xml'] = ET.tostring(workbook)
        self.assertEqual(package.read_scalar('trident_ui_schema'), '2.0')
        with self.assertRaises(InputValidationError):
            package.save(self.root / 'wrong-schema.xlsx')
        self.assertFalse((self.root / 'wrong-schema.xlsx').exists())

    def test_raw_replacement_with_malformed_xml_rejected_atomically_after_read(self):
        package = self.package()
        destination = package.save(self.root / 'previous.xlsx')
        repeat = self.package(destination)
        part = repeat._sheet_parts()['Output']
        repeat._xml(part)
        repeat.parts[part] = b'<worksheet><unclosed>'
        self.assert_rejected_without_publication(repeat, destination)

    def test_raw_replacement_with_external_formula_rejected_after_cached_xml_read(self):
        package = self.package()
        destination = package.save(self.root / 'previous.xlsx')
        repeat = self.package(destination)
        part = repeat._sheet_parts()['Output']
        repeat._xml(part)
        tree = ET.fromstring(repeat.parts[part])
        cell = tree.find(".//{" + MAIN + "}c[@r='B2']")
        ET.SubElement(cell, _tag('f')).text = "'[other.xlsx]Cash'!A1"
        repeat.parts[part] = ET.tostring(tree)
        self.assert_rejected_without_publication(repeat, destination)

    def test_live_tree_formula_mutation_notifies_validator_and_rejects_before_publish(self):
        package = self.package()
        destination = package.save(self.root / 'previous.xlsx')
        repeat = self.package(destination)
        part = repeat._sheet_parts()['Output']
        tree = repeat._xml(part)
        cell = repeat._sheet_cells(tree)['B2']
        ET.SubElement(cell, _tag('f')).text = "'[other.xlsx]Cash'!A1"
        repeat._put_xml(part, tree)
        self.assert_rejected_without_publication(repeat, destination)

    def test_cached_relationship_mutation_cannot_publish_broken_target(self):
        package = self.package()
        destination = package.save(self.root / 'previous.xlsx')
        repeat = self.package(destination)
        part = 'xl/_rels/workbook.xml.rels'
        tree = repeat._xml(part)
        tree[0].set('Target', '/xl/worksheets/missing.xml')
        repeat._put_xml(part, tree)
        self.assert_rejected_without_publication(repeat, destination)

    def test_native_table_header_mismatch_still_rejected_after_cache_reuse(self):
        package = self.package()
        destination = package.save(self.root / 'previous.xlsx')
        repeat = self.package(destination)
        info = repeat.table_inventory()['tbl_trident_ui_output']
        tree = repeat._xml(info.part)
        tree.find(_tag('tableColumns')).remove(tree.find(_tag('tableColumns'))[-1])
        repeat._put_xml(info.part, tree)
        self.assert_rejected_without_publication(repeat, destination)

    def test_raw_table_replacement_invalidates_cached_inventory(self):
        package = self.package()
        info = package.table_inventory()['tbl_trident_ui_output']
        table = ET.fromstring(package.parts[info.part])
        table.set('name', 'foreign_output')
        table.set('displayName', 'foreign_output')
        package.parts[info.part] = ET.tostring(table)
        self.assertIn('foreign_output', package.table_inventory())
        self.assertNotIn(info.name, package.table_inventory())
        with self.assertRaises(InputValidationError):
            package.save(self.root / 'foreign-table.xlsx')
        self.assertFalse((self.root / 'foreign-table.xlsx').exists())

    def test_deferred_worksheet_changes_cannot_mask_conflicting_raw_xml(self):
        package = self.package()
        destination = package.save(self.root / 'previous.xlsx')
        repeat = self.package(destination)
        repeat.write_table('tbl_trident_ui_output', self.rows(3.45))
        part = repeat._sheet_parts()['Output']
        repeat.parts[part] = b'<worksheet><unclosed>'
        self.assert_rejected_without_publication(repeat, destination)

    def test_external_native_table_formulas_rejected_before_atomic_publish(self):
        for tag in ('calculatedColumnFormula', 'totalsRowFormula'):
            with self.subTest(tag=tag):
                package = self.package()
                destination = package.save(self.root / (tag + '.xlsx'))
                repeat = self.package(destination)
                info = repeat.table_inventory()['tbl_trident_ui_output']
                table = repeat._xml(info.part)
                column = table.find(_tag('tableColumns'))[1]
                ET.SubElement(column, _tag(tag)).text = "'[other.xlsx]Cash'!A1"
                repeat._put_xml(info.part, table)
                self.assert_rejected_without_publication(repeat, destination)

    def test_same_source_overwrite_preserves_inputs_and_updates_saved_results(self):
        package = self.package()
        original_input = package.parts[package._sheet_parts()['Inputs']]
        original_market = package.parts[package._sheet_parts()['Market Data']]
        package.write_table('tbl_trident_ui_output', self.rows(FormulaCell('1/10', 0.2)))
        saved = package.save(self.source, overwrite=True)
        self.assertEqual(saved, self.source.resolve())
        self.assert_cell_values(saved, 'B2', '=1/10', 0.2)
        with zipfile.ZipFile(saved) as archive:
            self.assertEqual(archive.read(package._sheet_parts()['Inputs']), original_input)
            self.assertEqual(archive.read(package._sheet_parts()['Market Data']), original_market)

    def test_same_source_changed_input_schema_or_malformed_xml_is_not_overwritten(self):
        for change in ('owning_input', 'schema', 'malformed'):
            with self.subTest(change=change):
                package = self.package()
                # Simulate another process changing the file after the writer
                # loaded its input snapshot. The replacement bypasses the
                # writer deliberately so its final source guard must detect it.
                with zipfile.ZipFile(self.source) as archive:
                    entries = [(info, archive.read(info.filename)) for info in archive.infolist()]
                replacement = self.root / 'externally-modified.xlsx'
                with zipfile.ZipFile(replacement, 'w') as archive:
                    for info, data in entries:
                        if change == 'schema' and info.filename == 'xl/workbook.xml':
                            tree = ET.fromstring(data)
                            marker = tree.find(".//{" + MAIN + "}definedName[@name='trident_ui_schema']")
                            marker.text = '"2.0"'
                            data = ET.tostring(tree)
                        elif change == 'owning_input' and info.filename == package._sheet_parts()['Home']:
                            tree = ET.fromstring(data)
                            cash = tree.find(".//{" + MAIN + "}c[@r='D3']/{" + MAIN + "}v")
                            cash.text = '999.95'
                            data = ET.tostring(tree)
                        elif change == 'malformed' and info.filename == package._sheet_parts()['Output']:
                            data = b'<worksheet><unclosed>'
                        archive.writestr(info, data)
                os.replace(replacement, self.source)
                self.assert_rejected_without_publication(package, self.source)
                # Restore the original bytes for the independent next subcase.
                with zipfile.ZipFile(self.source, 'w') as archive:
                    for info, data in entries:
                        archive.writestr(info, data)

    def test_late_concurrent_source_edit_during_zip_write_prevents_final_replace(self):
        package = self.package()
        package.write_table('tbl_trident_ui_output', self.rows(9.99))
        original_write = zipfile.ZipFile.writestr
        edited = False
        edited_bytes = None
        temporary_before = set(self.root.glob('.trident-ui-*.xlsx'))

        def edit_live_source_then_write(archive, info, data, *args, **kwargs):
            nonlocal edited, edited_bytes
            if not edited:
                edited = True  # Nested fixture ZIP writes must not recurse.
                with zipfile.ZipFile(self.source) as live:
                    entries = [(entry, live.read(entry.filename)) for entry in live.infolist()]
                replacement = self.root / 'late-source-edit.xlsx'
                with zipfile.ZipFile(replacement, 'w') as live:
                    for entry, content in entries:
                        if entry.filename == package._sheet_parts()['Home']:
                            tree = ET.fromstring(content)
                            tree.find(".//{" + MAIN + "}c[@r='D3']/{" + MAIN + "}v").text = '888.88'
                            content = ET.tostring(tree)
                        original_write(live, entry, content)
                os.replace(replacement, self.source)
                edited_bytes = self.source.read_bytes()
            return original_write(archive, info, data, *args, **kwargs)

        with patch.object(zipfile.ZipFile, 'writestr', edit_live_source_then_write):
            with self.assertRaises(InputValidationError):
                package.save(self.source, overwrite=True)
        self.assertTrue(edited)
        self.assertEqual(self.source.read_bytes(), edited_bytes)
        self.assertEqual(set(self.root.glob('.trident-ui-*.xlsx')), temporary_before)

    def test_changed_formula_clears_value_metadata_even_when_cache_is_equal(self):
        package = self.package()
        package.write_table('tbl_trident_ui_output', self.rows(FormulaCell('1+1', 2)))
        part = package._sheet_parts()['Output']
        tree = package._xml(part)
        package._sheet_cells(tree)['B2'].set('vm', '1')
        package._put_xml(part, tree)
        package.write_table('tbl_trident_ui_output', self.rows(FormulaCell('2*1', 2)))
        saved = package.save(self.root / 'changed-formula-metadata.xlsx')
        self.assert_cell_values(saved, 'B2', '=2*1', 2)
        with zipfile.ZipFile(saved) as archive:
            root = ET.fromstring(archive.read(part))
            cell = root.find(".//{" + MAIN + "}c[@r='B2']")
            self.assertNotIn('vm', cell.attrib)

    def test_empty_shared_formula_is_removed_when_literal_cache_value_is_reused(self):
        package = self.package()
        package.write_table('tbl_trident_ui_output', self.rows(2))
        part = package._sheet_parts()['Output']
        tree = package._xml(part)
        cell = package._sheet_cells(tree)['B2']
        ET.SubElement(cell, _tag('f'), t='shared', si='7')
        package._put_xml(part, tree)
        package.write_table('tbl_trident_ui_output', self.rows(2))
        saved = package.save(self.root / 'shared-cleared.xlsx')
        self.assert_cell_values(saved, 'B2', 2, 2, 'n')
        with zipfile.ZipFile(saved) as archive:
            root = ET.fromstring(archive.read(part))
            cell = root.find(".//{" + MAIN + "}c[@r='B2']")
            self.assertIsNone(cell.find(_tag('f')))

    def test_private_xml_control_character_still_rejected_without_second_parse(self):
        package = self.package()
        destination = package.save(self.root / 'previous.xlsx')
        repeat = self.package(destination)
        part = repeat._sheet_parts()['Output']
        tree = repeat._xml(part)
        # Mutation notification is supported, but invalid XML text cannot be
        # published merely because the DOM itself was previously validated.
        repeat._sheet_cells(tree)['B2'].find(_tag('v')).text = '123' + chr(1)
        repeat._put_xml(part, tree)
        self.assert_rejected_without_publication(repeat, destination)

    def test_raw_table_mutation_rebuilds_primed_protection_before_new_cell_write(self):
        mutations = ('assignment', 'update', 'pop_setdefault', 'delete_assignment',
                     'clear_update', 'inplace_union')
        for mutation in mutations:
            with self.subTest(mutation=mutation):
                package = self.package()
                info = package.table_inventory()['tbl_trident_ui_pool']
                # An actual rejected input write primes the guard indexes.
                # No explicit inventory refresh is permitted after mutation.
                with self.assertRaises(InputValidationError):
                    package.write_cells('Inputs', {'A2': 'FORBIDDEN'})
                table = ET.fromstring(package.parts[info.part])
                table.set('ref', 'E1:G2')
                data = ET.tostring(table)
                if mutation == 'assignment':
                    package.parts[info.part] = data
                elif mutation == 'update':
                    package.parts.update({info.part: data})
                elif mutation == 'pop_setdefault':
                    package.parts.pop(info.part)
                    package.parts.setdefault(info.part, data)
                elif mutation == 'delete_assignment':
                    del package.parts[info.part]
                    package.parts[info.part] = data
                elif mutation == 'clear_update':
                    snapshot = dict(package.parts)
                    snapshot[info.part] = data
                    package.parts.clear()
                    package.parts.update(snapshot)
                else:
                    package.parts |= {info.part: data}
                with self.assertRaisesRegex(InputValidationError, 'tbl_trident_ui_pool'):
                    package.write_cells('Inputs', {'E2': 'FORBIDDEN AT NEW OWNER'})

    def test_removed_raw_table_owner_fails_closed_before_cell_write(self):
        for mutation in ('pop', 'delete', 'popitem'):
            with self.subTest(mutation=mutation):
                package = self.package()
                info = package.table_inventory()['tbl_trident_ui_pool']
                if mutation == 'popitem':
                    owner = package.parts.pop(info.part)
                    package.parts[info.part] = owner
                with self.assertRaises(InputValidationError):
                    package.write_cells('Inputs', {'A2': 'FORBIDDEN'})
                if mutation == 'pop':
                    package.parts.pop(info.part)
                elif mutation == 'delete':
                    del package.parts[info.part]
                else:
                    removed_part, _ = package.parts.popitem()
                    self.assertEqual(removed_part, info.part)
                with self.assertRaises(InputValidationError):
                    package.write_cells('Inputs', {'E2': 'OWNER NO LONGER VERIFIABLE'})

    def test_raw_style_replacement_does_not_reuse_a_stale_format_cache(self):
        package = self.package()
        rows = self.rows(123.45)
        formats = {'Value': '#,##0.00'}
        package.write_table('tbl_trident_ui_output', rows, number_formats=formats)
        styles = ET.fromstring(package.parts['xl/styles.xml'])
        for font in styles.find(_tag('fonts')):
            name = font.find(_tag('name'))
            if name is not None and name.attrib.get('val') == 'Arial':
                name.set('val', 'Other Native Font')
        package.parts['xl/styles.xml'] = ET.tostring(styles)
        package.write_table('tbl_trident_ui_output', rows, number_formats=formats)
        saved = package.save(self.root / 'style-refresh.xlsx')
        workbook = load_workbook(saved, data_only=True)
        try:
            cell = workbook['Output']['B2']
            self.assertEqual(cell.value, 123.45)
            self.assertEqual(cell.font.name, 'Arial')
            self.assertEqual(cell.number_format, '#,##0.00')
            self.assertEqual(cell.alignment.horizontal, 'center')
        finally:
            workbook.close()

    def test_final_zip_byte_verification_rejects_valid_xml_serialization_corruption(self):
        package = self.package()
        destination = package.save(self.root / 'previous.xlsx')
        repeat = self.package(destination)
        repeat.write_scalar('trident_ui_run_status', 'COMPLETE')
        output_part = repeat._sheet_parts()['Output']
        original_write = zipfile.ZipFile.writestr

        def corrupt_one_part(archive, info, data, *args, **kwargs):
            name = info.filename if isinstance(info, zipfile.ZipInfo) else info
            if name == output_part:
                tree = ET.fromstring(data)
                value = tree.find(".//{" + MAIN + "}c[@r='B2']/{" + MAIN + "}v")
                value.text = '999999.99'
                data = ET.tostring(tree)
            return original_write(archive, info, data, *args, **kwargs)

        with patch.object(zipfile.ZipFile, 'writestr', corrupt_one_part):
            self.assert_rejected_without_publication(repeat, destination)


if __name__ == '__main__':
    unittest.main()


