"""Lossless package transport for the compact Project Trident Excel interface.

This boundary writes values and display formulas. Financial calculations stay
in the existing Python services. Untouched ZIP parts are copied byte for byte;
in particular Market Data and its existing style resources are never rewritten.
Only named output rectangles may grow, and callers supply protected input names
and Tables so layout changes cannot silently overwrite a financial input.
"""
from __future__ import annotations

from copy import deepcopy
from dataclasses import dataclass
from datetime import date, datetime, timezone
from decimal import Decimal, InvalidOperation
from fractions import Fraction
from functools import lru_cache
from io import BytesIO
import math
import os
from pathlib import Path
import posixpath
import re
import tempfile
from typing import Iterable, Mapping, Sequence
import xml.etree.ElementTree as ET
import zipfile

from trident.domain.models import InputValidationError

MAIN = "http://schemas.openxmlformats.org/spreadsheetml/2006/main"
REL = "http://schemas.openxmlformats.org/officeDocument/2006/relationships"
PACKAGE_REL = "http://schemas.openxmlformats.org/package/2006/relationships"
CONTENT = "http://schemas.openxmlformats.org/package/2006/content-types"
CHART = "http://schemas.openxmlformats.org/drawingml/2006/chart"
NS = {"s": MAIN, "r": REL}
UI_PREFIX = "trident_ui_"
TABLE_PREFIX = "tbl_" + UI_PREFIX


def _external_reference(text: str) -> bool:
    # Structured Table references have brackets but no worksheet separator.
    # Avoid regular-expression work for this overwhelmingly common safe case.
    if "[" not in text or "!" not in text:
        return False
    literal_free = re.sub(r'"(?:[^"]|"")*"', "", text)
    return bool(re.search(r"(?:'[^']*\[[^\]]+\][^']*'|\[[^\]]+\][A-Za-z_][A-Za-z0-9_. ]*)!", literal_free))


@lru_cache(maxsize=256)
def _tag(local: str) -> str:
    return "{" + MAIN + "}" + local


@lru_cache(maxsize=16384)
def _column(number: int) -> str:
    if not 1 <= number <= 16384:
        raise InputValidationError("Excel column is outside its finite bounds")
    result = ""
    while number:
        number, remainder = divmod(number - 1, 26)
        result = chr(65 + remainder) + result
    return result


@lru_cache(maxsize=131072)
def _coordinate(address: str) -> tuple[int, int]:
    match = re.fullmatch(r"\$?([A-Za-z]{1,3})\$?([1-9][0-9]*)", address)
    if not match:
        raise InputValidationError(f"Expected a finite Excel cell address: {address}")
    column = 0
    for char in match[1].upper():
        column = column * 26 + ord(char) - 64
    row = int(match[2])
    if column > 16384 or row > 1048576:
        raise InputValidationError("Excel address is outside its finite bounds")
    return column, row


@lru_cache(maxsize=16384)
def _bounds(reference: str) -> tuple[int, int, int, int]:
    sides = reference.split(":")
    if len(sides) not in (1, 2):
        raise InputValidationError(f"Expected one Excel rectangle: {reference}")
    left, top = _coordinate(sides[0])
    right, bottom = _coordinate(sides[-1])
    if right < left or bottom < top:
        raise InputValidationError("Excel rectangle has reversed bounds")
    return left, top, right, bottom


def _reference(bounds: tuple[int, int, int, int], *, absolute: bool = False) -> str:
    left, top, right, bottom = bounds
    if absolute:
        return f"${_column(left)}${top}:${_column(right)}${bottom}"
    return f"{_column(left)}{top}:{_column(right)}{bottom}"


def _overlap(first: tuple[int, int, int, int], second: tuple[int, int, int, int]) -> bool:
    left, top, right, bottom = first
    a, b, c, d = second
    return not (right < a or left > c or bottom < b or top > d)


def _sheet_reference(sheet: str, bounds: tuple[int, int, int, int]) -> str:
    return "'" + sheet.replace("'", "''") + "'!" + _reference(bounds, absolute=True)


def _root_namespaces(data: bytes) -> dict[str, str]:
    result = {}
    for event, value in ET.iterparse(BytesIO(data), events=("start-ns", "start")):
        if event == "start":
            break
        prefix, uri = value
        result[prefix or ""] = uri
    return result


_INVALID_XML_TEXT = re.compile(r"[\x00-\x08\x0b\x0c\x0e-\x1f\ud800-\udfff\ufffe\uffff]")


@lru_cache(maxsize=2048)
def _valid_xml_name(name: str) -> bool:
    """Validate expanded XML names, including non-ASCII extension names.

    The namespace URI is restored from existing declarations during rendering.
    New local names must obey XML 1.0 NCName rules; a bare colon would otherwise
    serialize an undeclared prefix that a native spreadsheet reader rejects.
    """
    local = name
    if name.startswith("{"):
        namespace, separator, local = name[1:].rpartition("}")
        if not separator or not namespace or _INVALID_XML_TEXT.search(namespace):
            return False
    def start(character: str) -> bool:
        point = ord(character)
        return (character == "_" or "A" <= character <= "Z" or "a" <= character <= "z"
                or 0xC0 <= point <= 0xD6 or 0xD8 <= point <= 0xF6
                or 0xF8 <= point <= 0x2FF or 0x370 <= point <= 0x37D
                or 0x37F <= point <= 0x1FFF or 0x200C <= point <= 0x200D
                or 0x2070 <= point <= 0x218F or 0x2C00 <= point <= 0x2FEF
                or 0x3001 <= point <= 0xD7FF or 0xF900 <= point <= 0xFDCF
                or 0xFDF0 <= point <= 0xFFFD or 0x10000 <= point <= 0xEFFFF)
    return bool(local) and start(local[0]) and all(
        start(character) or character in "-." or "0" <= character <= "9"
        or ord(character) == 0xB7 or 0x300 <= ord(character) <= 0x36F
        or 0x203F <= ord(character) <= 0x2040 for character in local[1:])


def _validate_xml_tree(root: ET.Element) -> None:
    """Check XML representability without parsing a second million-cell DOM.

    Source bytes have already passed the XML parser. Rewritten trees additionally
    need valid names/text: ElementTree can otherwise emit invalid control-code
    references or undeclared literal prefixes. All extension nodes participate.
    This is performed once per serialized worksheet, not once per changed cell.
    """
    for node in root.iter():
        if not isinstance(node.tag, str) or not _valid_xml_name(node.tag):
            raise InputValidationError("Invalid XML element name in output package")
        for name, value in node.attrib.items():
            if not _valid_xml_name(name) or not isinstance(value, str) or _INVALID_XML_TEXT.search(value):
                raise InputValidationError("Invalid XML attribute in output package")
        if any(text is not None and (not isinstance(text, str) or _INVALID_XML_TEXT.search(text))
               for text in (node.text, node.tail)):
            raise InputValidationError("Invalid XML text in output package")


def _serialize(root: ET.Element, original: bytes | None = None) -> bytes:
    """Keep root namespace declarations used by mc:Ignorable and extensions.

    ElementTree omits declarations that occur only inside attribute values.
    Restoring them prevents an otherwise valid XML rewrite from breaking native
    Excel compatibility. Existing style indices and extension attributes stay
    unchanged; this function does not flatten unknown children.
    """
    _validate_xml_tree(root)
    namespaces = _root_namespaces(original) if original else {}
    if not namespaces:
        namespaces = {"": root.tag.split("}")[0].lstrip("{")}
        if any("{" + REL + "}" in key for child in root.iter() for key in child.attrib):
            namespaces["r"] = REL
    for prefix, uri in namespaces.items():
        if not re.fullmatch(r"ns[0-9]+", prefix):
            ET.register_namespace(prefix, uri)
    data = ET.tostring(root, encoding="utf-8", xml_declaration=True)
    match = re.search(br"<[^!?][^>]*>", data)
    if match is None:
        raise InputValidationError("Cannot serialize the package XML root")
    first = match[0]
    additions = []
    for prefix, uri in namespaces.items():
        attribute = "xmlns" + (":" + prefix if prefix else "")
        if re.search(rb"\s" + re.escape(attribute.encode()) + rb"=", first) is None:
            escaped = uri.replace("&", "&amp;").replace('"', "&quot;")
            additions.append(f' {attribute}="{escaped}"'.encode())
    if additions:
        ending = b"/>" if first.endswith(b"/>") else b">"
        updated = first[:-len(ending)] + b"".join(additions) + ending
        data = data[:match.start()] + updated + data[match.end():]
    return data


@dataclass(frozen=True)
class FormulaCell:
    """A display formula with an optional cache; ordinary strings stay literal."""
    formula: str
    cached_value: object = None


@dataclass(frozen=True)
class ExcelError:
    value: str

    def __post_init__(self) -> None:
        if self.value not in {"#N/A", "#VALUE!", "#DIV/0!", "#REF!", "#NAME?", "#NUM!", "#NULL!"}:
            raise InputValidationError("Unknown Excel error cache")


@dataclass(frozen=True)
class TableInfo:
    name: str
    sheet: str
    ref: str
    headers: tuple[str, ...]
    part: str
    identifier: int

    @property
    def bounds(self) -> tuple[int, int, int, int]:
        return _bounds(self.ref)


class _PackageParts(dict[str, bytes]):
    """Track immutable raw-part mutations while retaining the dictionary API.

    A revision lets hot cell/owner guards discover raw byte changes in O(1).
    XML-source identity still decides which indexes need rebuilding. Every
    mutating dict entry point participates, so update/pop/union cannot bypass
    the same protection applied to direct item assignment.
    """
    def __init__(self, *args, **kwargs) -> None:
        values = dict(*args, **kwargs)
        self._check_values(values)
        super().__init__(values)
        self.revision = 0

    @staticmethod
    def _check_values(values: Mapping[str, bytes]) -> None:
        if any(not isinstance(key, str) or not isinstance(value, bytes) for key, value in values.items()):
            raise InputValidationError("Package parts require text names and immutable bytes")

    def __setitem__(self, key: str, value: bytes) -> None:
        self._check_values({key: value})
        changed = key not in self or self[key] is not value
        super().__setitem__(key, value)
        if changed:
            self.revision += 1

    def __delitem__(self, key: str) -> None:
        super().__delitem__(key)
        self.revision += 1

    def update(self, *args, **kwargs) -> None:
        values = dict(*args, **kwargs)
        self._check_values(values)
        for key, value in values.items():
            self[key] = value

    def setdefault(self, key: str, default: bytes | None = None) -> bytes:
        if key not in self:
            self[key] = default
        return self[key]

    def pop(self, key: str, *default) -> bytes:
        existed = key in self
        result = super().pop(key, *default)
        if existed:
            self.revision += 1
        return result

    def popitem(self) -> tuple[str, bytes]:
        result = super().popitem()
        self.revision += 1
        return result

    def clear(self) -> None:
        if self:
            super().clear()
            self.revision += 1

    def __ior__(self, other):
        self.update(other)
        return self


class WorkbookPackage:
    """Edit only explicit compact-interface outputs in an in-memory ZIP.

    Input protection is semantic: the presenter passes input names and Tables
    from its manifest. No sheet position or financial policy is inferred here.
    Saving validates the full XML package and relationships before an atomic
    replacement. A failed write leaves the destination unchanged.
    """

    def __init__(self, source: str | Path, *, protected_names: Iterable[str] = (),
                 protected_tables: Iterable[str] = (), schema_name: str = "trident_ui_schema") -> None:
        self.source = Path(source).resolve()
        try:
            with zipfile.ZipFile(self.source) as archive:
                infos = archive.infolist()
                if len({info.filename for info in infos}) != len(infos):
                    raise InputValidationError("Duplicate package parts are unsafe")
                self.parts = _PackageParts({info.filename: archive.read(info.filename) for info in infos})
                self._infos = {info.filename: info for info in infos}
                self._zip_comment = archive.comment
        except (OSError, zipfile.BadZipFile) as error:
            raise InputValidationError(f"Cannot open interface package: {self.source}") from error
        self._original = dict(self.parts)
        self.changed_parts: set[str] = set()
        self.protected_names = frozenset(protected_names)
        self.protected_tables = frozenset(protected_tables)
        self.schema_name = schema_name
        self._style_cache: dict[tuple[int, str, bool], int] = {}
        self._inventory_cache: dict[str, TableInfo] | None = None
        self._inventory_sources: dict[str, bytes] = {}
        self._inventory_revision: int | None = None
        self._worksheet_table_signatures: dict[str, tuple[tuple[tuple[str, str], ...], ...]] = {}
        # Output Tables occupy independent column lanes. Index their actual
        # sheet/columns once instead of finding their owner among every Table
        # for each formatted cell. The same invalidation boundary as inventory
        # covers new Tables, moved lanes, resized rectangles and relationships.
        self._table_sheet_index: dict[str, tuple[TableInfo, ...]] | None = None
        self._table_column_index: dict[str, dict[int, tuple[TableInfo, ...]]] | None = None
        self._xml_cache: dict[str, ET.Element] = {}
        # Cached DOMs belong to the exact bytes that produced them. Most parts
        # remain unchanged, but callers may replace a raw part; such replacements
        # must invalidate parsed roots and every dependent semantic index.
        self._xml_sources: dict[str, bytes] = {}
        self._shared_string_cache: dict[int, str] = {}
        self._cell_cache: dict[int, dict[str, ET.Element]] = {}
        self._column_cell_cache: dict[int, dict[int, dict[int, str]]] = {}
        self._row_cache: dict[int, dict[int, ET.Element]] = {}
        self._names_cache: dict[str, ET.Element] | None = None
        self._sheets_cache: dict[str, str] | None = None
        self._deferred_parts: set[str] = set()
        self._protected_regions: tuple[tuple[str, tuple[int,int,int,int], str], ...] | None = None
        self._protected_sheet_index: dict[str, tuple[tuple[tuple[int,int,int,int], str], ...]] | None = None
        self._validate_package()
        self._validate_namespace()
        self._market_parts = {part: self.parts[part] for title, part in self._sheet_parts().items() if title == "Market Data"}

    def _invalidate_part_indexes(self, part: str, previous: ET.Element | None = None) -> None:
        """Discard only indexes derived from a replaced XML owner."""
        if previous is not None:
            self._cell_cache.pop(id(previous), None)
            self._column_cell_cache.pop(id(previous), None)
            self._row_cache.pop(id(previous), None)
        if (part == "xl/workbook.xml" or part.startswith("xl/tables/") or part.endswith(".rels")
                or part.startswith("xl/worksheets/") and previous is not None):
            self._inventory_cache = None
            self._inventory_sources.clear()
            self._table_sheet_index = None
            self._table_column_index = None
        if part == "xl/workbook.xml":
            self._names_cache = None
            self._protected_regions = None
            self._protected_sheet_index = None
        if part in ("xl/workbook.xml", "xl/_rels/workbook.xml.rels"):
            self._sheets_cache = None
        if part == "xl/styles.xml":
            self._style_cache.clear()
        if part == "xl/sharedStrings.xml":
            self._shared_string_cache.clear()

    def _xml(self, part: str) -> ET.Element:
        try:
            data = self.parts[part]
        except KeyError as error:
            raise InputValidationError(f"Missing or invalid package XML: {part}") from error
        previous = self._xml_cache.get(part)
        if previous is not None and self._xml_sources.get(part) is data:
            return previous
        if part in self._deferred_parts:
            raise InputValidationError("Raw XML replacement conflicts with pending worksheet changes")
        self._invalidate_part_indexes(part, previous)
        try:
            root = ET.fromstring(data)
        except ET.ParseError as error:
            raise InputValidationError(f"Missing or invalid package XML: {part}") from error
        self._xml_cache[part] = root
        self._xml_sources[part] = data
        return root

    def _put_xml(self, part: str, root: ET.Element) -> None:
        previous = self._xml_cache.get(part)
        if part in self._worksheet_table_signatures:
            entries = root.find(_tag("tableParts"))
            signature = tuple(tuple(sorted(entry.attrib.items())) for entry in entries) if entries is not None else ()
            if signature != self._worksheet_table_signatures[part]:
                self._inventory_cache = None
                self._table_sheet_index = None
                self._table_column_index = None
        # Ordinary edits keep the same DOM and its physical-cell indexes. A
        # complete root replacement invalidates those indexes before use.
        self._invalidate_part_indexes(part, previous if previous is not root else None)
        self._xml_cache[part] = root
        if part.startswith("xl/worksheets/") and part.endswith(".xml") and part in self.parts:
            # Repeated independent lanes may contain tens of thousands of rows.
            # Keep one DOM and serialize once at the publication boundary.
            self._xml_sources[part] = self.parts[part]
            self._deferred_parts.add(part)
        else:
            self.parts[part] = _serialize(root, self.parts.get(part))
            self._xml_sources[part] = self.parts[part]
        self.changed_parts.add(part)

    def _flush_xml(self) -> None:
        for part in tuple(self._deferred_parts):
            if self._xml_sources.get(part) is not self.parts.get(part):
                raise InputValidationError("Raw XML replacement conflicts with pending worksheet changes")
            self.parts[part] = _serialize(self._xml_cache[part], self.parts.get(part))
            self._xml_sources[part] = self.parts[part]
        self._deferred_parts.clear()

    @staticmethod
    def _relationship_part(part: str) -> str:
        directory, filename = posixpath.split(part)
        return posixpath.join(directory, "_rels", filename + ".rels")

    def _relationships(self, part: str) -> dict[str, str]:
        rel_part = self._relationship_part(part)
        if rel_part not in self.parts:
            return {}
        return {item.attrib["Id"]: item.attrib["Target"] for item in self._xml(rel_part)}

    @staticmethod
    def _resolved_part(owner: str, target: str) -> str:
        if target.startswith("/"):
            result = target.lstrip("/")
        else:
            result = posixpath.normpath(posixpath.join(posixpath.dirname(owner), target))
        if result.startswith("../") or "\\" in result or ":" in result:
            raise InputValidationError("Relationship target escapes the package")
        return result

    def _sheet_parts(self) -> dict[str, str]:
        # Synchronize raw metadata replacements before returning a cached index.
        self._xml("xl/workbook.xml")
        relationship_part = self._relationship_part("xl/workbook.xml")
        if relationship_part in self.parts:
            self._xml(relationship_part)
        if self._sheets_cache is not None:
            return dict(self._sheets_cache)
        relationships = self._relationships("xl/workbook.xml")
        result = {}
        for sheet in self._xml("xl/workbook.xml").find(_tag("sheets")):
            relationship = sheet.attrib.get("{" + REL + "}id")
            if relationship not in relationships:
                raise InputValidationError("Worksheet relationship is missing")
            result[sheet.attrib["name"]] = self._resolved_part("xl/workbook.xml", relationships[relationship])
        self._sheets_cache = result
        return dict(result)

    def _names(self) -> dict[str, ET.Element]:
        self._xml("xl/workbook.xml")
        if self._names_cache is not None:
            return dict(self._names_cache)
        names = self._xml("xl/workbook.xml").find(_tag("definedNames"))
        result = {}
        if names is not None:
            for name in names:
                if 'localSheetId' in name.attrib and not name.attrib.get('name','').startswith(UI_PREFIX):
                    continue
                if "localSheetId" in name.attrib and name.attrib.get("name", "").startswith(UI_PREFIX):
                    raise InputValidationError("UI names must be workbook scoped")
                key = name.attrib["name"]
                if key in result:
                    raise InputValidationError(f"Duplicate workbook name: {key}")
                result[key] = name
        self._names_cache = result
        return dict(result)

    def _validate_namespace(self) -> None:
        names = self._names()
        if self.schema_name not in names:
            raise InputValidationError(f"Missing compact interface marker: {self.schema_name}")
        all_names=self._xml('xl/workbook.xml').find(_tag('definedNames'))
        for item in all_names if all_names is not None else ():
            name=item.attrib['name']
            if name.startswith("trident_") and not name.startswith(UI_PREFIX):
                raise InputValidationError(f"Foreign model namespace cannot be written: {name}")
        for name in self.table_inventory():
            if not name.startswith(TABLE_PREFIX):
                raise InputValidationError(f"Foreign Table namespace cannot be written: {name}")
        if str(self.read_scalar(self.schema_name)) != "1.0":
            raise InputValidationError("Unsupported compact interface schema version")

    def _validate_package(self) -> None:
        self._flush_xml()
        for part, data in self.parts.items():
            if part.startswith("/") or "\\" in part or ".." in part.split("/"):
                raise InputValidationError("Unsafe package part name")
            if part.endswith(".xml") or part.endswith(".rels"):
                # Initial validation populates the same DOM cache later used
                # by inventory and writes. Final validation checks every current
                # relationship and formula again, without reparsing those trees.
                root = self._xml(part)
                if part.endswith(".rels"):
                    owner = "" if part == "_rels/.rels" else posixpath.join(posixpath.dirname(posixpath.dirname(part)), posixpath.basename(part)[:-5])
                    ids = set()
                    for relationship in root:
                        identifier = relationship.attrib["Id"]
                        if identifier in ids:
                            raise InputValidationError("Duplicate relationship identifier")
                        ids.add(identifier)
                        if relationship.attrib.get("TargetMode") == "External":
                            if not relationship.attrib.get("Type", "").endswith("/hyperlink"):
                                raise InputValidationError("External financial references are unsupported")
                            continue
                        target = self._resolved_part(owner, relationship.attrib["Target"])
                        if target not in self.parts:
                            raise InputValidationError(f"Broken relationship: {part} -> {target}")
                # Native Table formulas, validation and conditional-formatting
                # formulas are executable too; they share the same prohibition
                # on financial references to another workbook.
                formula_tags = {_tag(tag) for tag in ("f", "formula", "formula1", "formula2",
                                                      "calculatedColumnFormula", "totalsRowFormula")}
                formula_tags.add("{" + CHART + "}f")
                for formula in (node for node in root.iter() if node.tag in formula_tags):
                    if formula.text and _external_reference(formula.text):
                        raise InputValidationError("External workbook formula is unsupported")
        if any(part.startswith("xl/externalLinks/") for part in self.parts):
            raise InputValidationError("External workbook links are unsupported")
        workbook_names=self._xml('xl/workbook.xml').find(_tag('definedNames'))
        for name in workbook_names if workbook_names is not None else ():
            text = name.text or ""
            if "#REF!" in text or _external_reference(text):
                raise InputValidationError("Broken or external workbook name")

    def table_inventory(self) -> dict[str, TableInfo]:
        if self._inventory_cache is not None:
            # A store revision makes unchanged inventory lookups constant-time.
            # On a mutation, exact owner-part identities determine whether a
            # Table/header/ownership rebuild is necessary. A replaced ordinary
            # mapping still receives the conservative identity scan.
            revision = getattr(self.parts, "revision", None)
            if revision is None or revision != self._inventory_revision:
                for part, source in tuple(self._inventory_sources.items()):
                    if self.parts.get(part) is not source:
                        self._xml(part)
                        self._inventory_cache = None
                        self._table_sheet_index = None
                        self._table_column_index = None
                        break
                self._inventory_revision = revision
            if self._inventory_cache is not None:
                return dict(self._inventory_cache)
        result = {}
        identifiers = set()
        for sheet, part in self._sheet_parts().items():
            relationships = self._relationships(part)
            entries = self._xml(part).find(_tag("tableParts"))
            if entries is None:
                continue
            for entry in entries:
                key = entry.attrib["{" + REL + "}id"]
                if key not in relationships:
                    raise InputValidationError("Table relationship is missing")
                table_part = self._resolved_part(part, relationships[key])
                table = self._xml(table_part)
                name = table.attrib.get("displayName", table.attrib.get("name", ""))
                identifier = int(table.attrib["id"])
                if name in result or identifier in identifiers:
                    raise InputValidationError("Duplicate native Table name or identifier")
                identifiers.add(identifier)
                columns = table.find(_tag("tableColumns"))
                headers = tuple(column.attrib["name"] for column in columns)
                info = TableInfo(name, sheet, table.attrib["ref"], headers, table_part, identifier)
                left, _, right, _ = info.bounds
                if right - left + 1 != len(headers) or len(set(headers)) != len(headers):
                    raise InputValidationError(f"Invalid native Table columns: {name}")
                result[name] = info
        self._inventory_cache = result
        metadata = {"xl/workbook.xml", self._relationship_part("xl/workbook.xml")}
        for part in self._sheet_parts().values():
            metadata.add(part)
            metadata.add(self._relationship_part(part))
        metadata.update(info.part for info in result.values())
        self._inventory_sources = {part: self.parts[part] for part in metadata if part in self.parts}
        self._inventory_revision = getattr(self.parts, "revision", None)
        self._worksheet_table_signatures = {}
        for part in self._sheet_parts().values():
            entries = self._xml(part).find(_tag("tableParts"))
            self._worksheet_table_signatures[part] = (
                tuple(tuple(sorted(entry.attrib.items())) for entry in entries) if entries is not None else ())
        return dict(result)

    def _tables_by_sheet(self) -> dict[str, tuple[TableInfo, ...]]:
        """Return run-local rectangle indexes rebuilt after inventory changes.

        A column may contain several vertically separated Tables. Keeping all
        candidates preserves overlap detection instead of assuming one owner.
        The public inventory still returns a defensive copy; hot per-cell
        paths use these private immutable tuples and avoid repeated copying.
        """
        revision = getattr(self.parts, "revision", None)
        if revision is None or revision != self._inventory_revision:
            self.table_inventory()
        if self._table_sheet_index is None:
            grouped: dict[str, list[TableInfo]] = {}
            columns: dict[str, dict[int, list[TableInfo]]] = {}
            for info in self.table_inventory().values():
                grouped.setdefault(info.sheet, []).append(info)
                lane = columns.setdefault(info.sheet, {})
                left, _, right, _ = info.bounds
                for column in range(left, right + 1):
                    lane.setdefault(column, []).append(info)
            self._table_sheet_index = {sheet: tuple(infos) for sheet, infos in grouped.items()}
            self._table_column_index = {
                sheet: {column: tuple(infos) for column, infos in lane.items()}
                for sheet, lane in columns.items()
            }
        return self._table_sheet_index

    def _table_intersections(self, sheet: str, bounds: tuple[int, int, int, int]) -> tuple[TableInfo, ...]:
        """Find every Table intersecting a rectangle without scanning other sheets."""
        index = self._tables_by_sheet()
        left, _, right, _ = bounds
        # Narrow cell/column updates dominate semantic formatting. For wide
        # rectangles a sheet scan is cheaper than expanding thousands of
        # column entries; both paths apply the same exact rectangle predicate.
        if right - left < 64:
            candidates: dict[str, TableInfo] = {}
            lane = self._table_column_index.get(sheet, {})
            for column in range(left, right + 1):
                for info in lane.get(column, ()):
                    candidates.setdefault(info.name, info)
            values = candidates.values()
        else:
            values = index.get(sheet, ())
        return tuple(info for info in values if _overlap(bounds, info.bounds))

    def _table_owner(self, sheet: str, bounds: tuple[int, int, int, int]) -> str | None:
        """Keep the existing first-owner convention; _guard rejects other overlaps."""
        intersections = self._table_intersections(sheet, bounds)
        return intersections[0].name if intersections else None

    def read_scalar(self, name: str) -> object:
        definition = self._names().get(name)
        if definition is None:
            raise InputValidationError(f"Missing workbook name: {name}")
        text = (definition.text or "").lstrip("=")
        if re.fullmatch(r'"(?:[^"]|"")*"', text):
            return text[1:-1].replace('""', '"')
        sheet, bounds = self.named_region(name)
        left, top, right, bottom = bounds
        if left != right or top != bottom:
            raise InputValidationError("Scalar name must refer to one cell")
        cell = self._sheet_cells(self._xml(self._sheet_parts()[sheet])).get(f"{_column(left)}{top}")
        if cell is None:
            return None
        value = cell.findtext(_tag("v"))
        kind = cell.attrib.get("t", "n")
        if kind == "inlineStr":
            return "".join(cell.find(_tag("is")).itertext())
        if kind == "s":
            strings = self._xml("xl/sharedStrings.xml")
            return "".join(strings[int(value)].itertext())
        if kind in {"str", "e"}:
            return value
        if kind == "b":
            return value == "1"
        return None if value is None else float(value)

    def define_name(self, name: str, sheet: str | None = None, reference: str | None = None, *, constant: str | None = None) -> None:
        if not name.startswith(UI_PREFIX) or name in self.protected_names:
            raise InputValidationError("New output name must use the compact UI namespace")
        if constant is not None:
            if sheet is not None or reference is not None:
                raise InputValidationError("A name is a constant or a rectangle")
            value = '"' + constant.replace('"', '""') + '"'
        else:
            if sheet not in self._sheet_parts() or reference is None:
                raise InputValidationError("Named output rectangle needs an existing worksheet")
            value = _sheet_reference(sheet, _bounds(reference))
        workbook = self._xml("xl/workbook.xml")
        names = workbook.find(_tag("definedNames"))
        if names is None:
            names = ET.Element(_tag("definedNames"))
            before = next((i for i, child in enumerate(workbook) if child.tag in {_tag("calcPr"), _tag("extLst")}), len(workbook))
            workbook.insert(before, names)
        item = next((item for item in names if item.attrib["name"] == name), None)
        if item is None:
            item = ET.SubElement(names, _tag("definedName"), name=name)
        if item.text == value:
            return
        item.text = value
        self._put_xml("xl/workbook.xml", workbook)

    def named_region(self, name: str) -> tuple[str, tuple[int, int, int, int]]:
        names = self._names()
        if name not in names:
            raise InputValidationError(f"Missing workbook name: {name}")
        text = (names[name].text or "").lstrip("=")
        dynamic=re.fullmatch(r'INDEX\((tbl_trident_ui_[A-Za-z_0-9]+)\[([^\[\]]+)\],1\):INDEX\(\1\[\2\],MAX\(1,COUNT\(\1\[\2\]\)\)\)',text)
        if dynamic:
            info=self.table_inventory().get(dynamic[1])
            if info is None or dynamic[2] not in info.headers:
                raise InputValidationError('Dynamic saved-date list references an unknown Table column')
            count=sum(isinstance(row[dynamic[2]],(int,float)) and not isinstance(row[dynamic[2]],bool)
                      for row in self._table_records(dynamic[1]))
            left,top,_,_=info.bounds
            column=left+info.headers.index(dynamic[2])
            return info.sheet,(column,top+1,column,top+max(1,count))
        structured = re.fullmatch(r"([A-Za-z_][A-Za-z_0-9]*)\[([^\[\]]+)\]", text, re.IGNORECASE)
        if structured:
            info = self.table_inventory().get(structured[1])
            if info is None:
                raise InputValidationError("Named Table does not exist")
            left, top, right, bottom = info.bounds
            field = structured[2]
            if field.lower() == '#all':
                return info.sheet, info.bounds
            if field.lower() == '#headers':
                return info.sheet, (left,top,right,top)
            if field.lower() == '#data':
                return info.sheet, (left,top+1,right,bottom)
            if field not in info.headers:
                raise InputValidationError('Named Table column does not exist')
            column = left+info.headers.index(field)
            return info.sheet, (column,top+1,column,bottom)
        match = re.fullmatch(r"(?:'((?:[^']|'')+)'|([^'!]+))!(.+)", text)
        if not match:
            raise InputValidationError(f"Name is not one finite rectangle: {name}")
        sheet = match[1].replace("''", "'") if match[1] else match[2]
        if sheet not in self._sheet_parts():
            raise InputValidationError("Named worksheet does not exist")
        return sheet, _bounds(match[3])

    def _guard(self, sheet: str, bounds: tuple[int, int, int, int], *, own_table: str | None = None,
               style_only_names: frozenset[str] = frozenset(),
               style_only_tables: frozenset[str] = frozenset()) -> None:
        if sheet == "Market Data":
            raise InputValidationError("Market Data XML is immutable")
        # Only intersecting Tables can be overwritten. The column index is an
        # acceleration of this exact predicate, not a waiver of input guards.
        for info in self._table_intersections(sheet, bounds):
            if info.name == own_table:
                if info.name in self.protected_tables and info.name not in style_only_tables:
                    raise InputValidationError("Cannot overwrite a protected input Table")
                continue
            raise InputValidationError(f"Output overlaps native Table: {info.name}")
        if self._protected_regions is None:
            self._protected_regions = tuple((*self.named_region(name), name) for name in self.protected_names)
        if self._protected_sheet_index is None:
            grouped = {}
            for title, region, name in self._protected_regions:
                grouped.setdefault(title, []).append((region, name))
            self._protected_sheet_index = {title: tuple(regions) for title, regions in grouped.items()}
        for region, name in self._protected_sheet_index.get(sheet, ()):
            if name not in style_only_names and _overlap(bounds, region):
                raise InputValidationError(f"Output overlaps protected input name: {name}")

    def _adjust_table_names(self, info: TableInfo, sheet: str, bounds: tuple[int, int, int, int]) -> None:
        """Retain subordinate finite aliases when an output Table moves/grows."""
        if info.sheet == sheet and info.bounds == bounds:
            return
        workbook = self._xml("xl/workbook.xml")
        names = workbook.find(_tag("definedNames"))
        changed = False
        left, top, right, bottom = info.bounds
        new_left, new_top, _, new_bottom = bounds
        for item in names if names is not None else ():
            name = item.attrib["name"]
            if not name.startswith(UI_PREFIX) or name in self.protected_names or name.startswith(UI_PREFIX+'fresh_'):
                continue
            text = (item.text or "").lstrip("=")
            if not "!" in text:
                continue
            try:
                title, region = self.named_region(name)
            except InputValidationError:
                continue
            a, b, c, d = region
            if title != info.sheet or not (left <= a <= c <= right and top <= b <= d <= bottom):
                continue
            # Header aliases retain one row; complete-body aliases follow row
            # growth. A smaller intentional subsection remains unchanged.
            end = new_bottom if d == bottom and (b > top or region == info.bounds) else new_top + d - top
            moved = (new_left + a - left, new_top + b - top, new_left + c - left, end)
            value = _sheet_reference(sheet, moved)
            if item.text != value:
                item.text = value
                changed = True
        if changed:
            self._put_xml("xl/workbook.xml", workbook)

    def _style(self, base: int, number_format: str = "General", *, output: bool = True) -> int:
        # Raw style-part replacements invalidate cached style IDs before they
        # can be reused; unchanged bytes make this synchronization constant-time.
        styles = self._xml("xl/styles.xml")
        key = (base, number_format, output)
        if key in self._style_cache:
            return self._style_cache[key]
        fonts = styles.find(_tag("fonts"))
        xfs = styles.find(_tag("cellXfs"))
        if base >= len(xfs):
            raise InputValidationError("Cell style index is outside the style table")
        changed = False
        clone = deepcopy(xfs[base])
        font = deepcopy(fonts[int(clone.attrib.get("fontId", "0"))])
        font_name = font.find(_tag("name"))
        if font_name is None:
            font_name = ET.SubElement(font, _tag("name"))
        font_name.set("val", "Arial")
        font_xml = ET.tostring(font)
        font_index = next((i for i, existing in enumerate(fonts) if ET.tostring(existing) == font_xml), None)
        if font_index is None:
            font_index = len(fonts)
            fonts.append(font)
            fonts.set("count", str(len(fonts)))
            changed = True
        clone.set("fontId", str(font_index))
        alignment = clone.find(_tag("alignment"))
        if alignment is None:
            alignment = ET.SubElement(clone, _tag("alignment"))
        alignment.attrib.update(horizontal="center", vertical="center", wrapText="1")
        clone.set("applyAlignment", "1")
        formats = styles.find(_tag("numFmts"))
        if number_format == "General":
            format_id = 0
        else:
            if formats is None:
                formats = ET.Element(_tag("numFmts"), {"count": "0"})
                styles.insert(0, formats)
            existing = next((item for item in formats if item.attrib.get("formatCode") == number_format), None)
            if existing is None:
                format_id = max([163, *(int(item.attrib["numFmtId"]) for item in formats)]) + 1
                ET.SubElement(formats, _tag("numFmt"), numFmtId=str(format_id), formatCode=number_format)
                formats.set("count", str(len(formats)))
                changed = True
            else:
                format_id = int(existing.attrib["numFmtId"])
        clone.set("numFmtId", str(format_id))
        clone.set("applyNumberFormat", "1")
        clone_xml = ET.tostring(clone)
        index = next((i for i, existing in enumerate(xfs) if ET.tostring(existing) == clone_xml), None)
        if index is None:
            index = len(xfs)
            xfs.append(clone)
            xfs.set("count", str(len(xfs)))
            changed = True
        if changed:
            self._put_xml("xl/styles.xml", styles)
        self._style_cache[key] = index
        self._style_cache[(index, number_format, output)] = index
        return index

    def _date_serial(self, value: date | datetime) -> float:
        if isinstance(value, datetime):
            if value.tzinfo is not None:
                value = value.astimezone(timezone.utc).replace(tzinfo=None)
            stamp = value
        else:
            stamp = datetime.combine(value, datetime.min.time())
        properties = self._xml("xl/workbook.xml").find(_tag("workbookPr"))
        use_1904 = properties is not None and properties.attrib.get("date1904") in {"1", "true"}
        epoch = datetime(1904, 1, 1) if use_1904 else datetime(1899, 12, 30)
        serial = (stamp - epoch).total_seconds() / 86400
        if not use_1904 and stamp < datetime(1900, 3, 1):
            serial -= 1
        if serial < 0:
            raise InputValidationError("Excel cannot display this pre-epoch date")
        return serial

    def _value_payload(self, value: object, *, formula_cache: bool = False) -> tuple[str | None, str | None]:
        """Encode a scalar once, preserving the established Excel value policy.

        Financial Decimals become finite Excel double caches only at this UI
        boundary. No tolerance is used to declare two numeric payloads equal;
        a displayed zero, absent value and empty string remain distinct states.
        """
        if value is None:
            return None, None
        if isinstance(value, ExcelError):
            return "e", value.value
        if isinstance(value, bool):
            return "b", "1" if value else "0"
        if isinstance(value, (date, datetime)):
            return None, repr(self._date_serial(value))
        if isinstance(value, (int, float, Decimal, Fraction)):
            numeric = float(value)
            if not math.isfinite(numeric) or value != 0 and numeric == 0:
                raise InputValidationError("Numeric Excel value is nonfinite or underflows to zero")
            return None, str(value) if isinstance(value, int) else repr(numeric)
        text = str(value)
        if len(text) > 32767 or _INVALID_XML_TEXT.search(text):
            raise InputValidationError("Excel text has invalid characters or exceeds its limit")
        return ("str" if formula_cache else "inlineStr"), text

    def _shared_string(self, index: int) -> str:
        # Synchronize raw shared-string replacements before trusting a decoded
        # value. The cache is local to this package and freed with the writer.
        tree = self._xml("xl/sharedStrings.xml")
        if index not in self._shared_string_cache:
            self._shared_string_cache[index] = "".join(tree[index].itertext())
        return self._shared_string_cache[index]

    def _same_payload(self, cell: ET.Element, kind: str | None, text: str | None) -> bool:
        existing_kind = cell.attrib.get("t", "n")
        if kind == "inlineStr":
            if existing_kind == "inlineStr":
                inline = cell.find(_tag("is"))
                return inline is not None and "".join(inline.itertext()) == text
            if existing_kind == "s":
                return self._shared_string(int(cell.findtext(_tag("v")))) == text
            return False
        if existing_kind != (kind or "n"):
            return False
        cached = cell.find(_tag("v"))
        if text is None:
            return cached is None and cell.find(_tag("is")) is None
        if cached is None:
            return False
        previous = cached.text or ""
        if previous == text:
            return True
        # Native Excel may save 1.0 as 1 or dates without a decimal point. Exact
        # decimal equality preserves that harmless lexical representation while
        # never concealing a cent, date, rate or formula-cache change.
        if kind is None:
            try:
                return Decimal(previous) == Decimal(text)
            except (InvalidOperation, ValueError):
                return False
        return False

    def _updated_cell(self, address: str, value: object, style: int,
                      previous: ET.Element | None = None) -> ET.Element:
        """Reuse unchanged cells and patch only changed payloads/formula caches.

        Comparing the requested formula and encoded value before constructing
        XML eliminates most repeated cell allocations. Existing cell metadata,
        unknown extension children and unchanged shared/array formula attributes
        survive cache updates. A new expression receives a new plain formula;
        stale value metadata is discarded when its payload or formula changes.
        """
        formula = value.formula.lstrip("=") if isinstance(value, FormulaCell) else None
        if formula is not None and (not formula or "\n" in formula or "\r" in formula):
            raise InputValidationError("Display formula must be one nonempty expression")
        kind, text = self._value_payload(value.cached_value if isinstance(value, FormulaCell) else value,
                                         formula_cache=formula is not None)
        prior_formula = previous.find(_tag("f")) if previous is not None else None
        same_formula = ((prior_formula is None and formula is None)
                        or formula is not None and prior_formula is not None and prior_formula.text == formula)
        same_payload = previous is not None and self._same_payload(previous, kind, text)
        if (previous is not None and same_formula and same_payload
                and int(previous.attrib.get("s", "0")) == style):
            return previous
        cell = deepcopy(previous) if previous is not None else ET.Element(_tag("c"), r=address)
        cell.set("r", address)
        cell.set("s", str(style))
        if same_formula and same_payload:
            return cell  # Style-only change retains the original payload exactly.
        if not same_payload or not same_formula:
            cell.attrib.pop("vm", None)
        for child in list(cell):
            if child.tag in {_tag("v"), _tag("is")} or child.tag == _tag("f") and not same_formula:
                cell.remove(child)
        if formula is not None and not same_formula:
            node = ET.Element(_tag("f")); node.text = formula
            cell.insert(0, node)
        if kind is None:
            cell.attrib.pop("t", None)
        else:
            cell.set("t", kind)
        if text is not None:
            if kind == "inlineStr":
                inline = ET.Element(_tag("is"))
                node = ET.SubElement(inline, _tag("t")); node.text = text
                if text != text.strip():
                    node.set("{http://www.w3.org/XML/1998/namespace}space", "preserve")
                cell.insert(0, inline)
            else:
                cached = ET.Element(_tag("v")); cached.text = text
                cell.insert(1 if cell.find(_tag("f")) is not None else 0, cached)
        return cell

    def _cell(self, address: str, value: object, style: int) -> ET.Element:
        """Construct a new cell; internal updates pass their existing cell instead."""
        return self._updated_cell(address, value, style)

    def _sheet_cells(self, tree: ET.Element) -> dict[str, ET.Element]:
        key=id(tree)
        if key not in self._cell_cache:
            self._cell_cache[key]={cell.attrib['r']:cell for cell in tree.findall('s:sheetData/s:row/s:c',NS)}
        return self._cell_cache[key]

    def _existing_cell_addresses(self, sheet: str, bounds: tuple[int, int, int, int]) -> tuple[str, ...]:
        """Return only physical cells in a rectangle, including styled blanks.

        A native Table may reserve thousands of empty rows without storing a
        cell at every address. Clear/growth checks must not enumerate that
        virtual grid. Indexing physical cells by column makes the cost follow
        occupied cells in the affected lane; _replace_cells maintains it when
        cells are inserted or removed, including moves to another sheet.
        """
        tree = self._xml(self._sheet_parts()[sheet])
        key = id(tree)
        if key not in self._column_cell_cache:
            columns: dict[int, dict[int, str]] = {}
            for address in self._sheet_cells(tree):
                column, row = _coordinate(address)
                columns.setdefault(column, {})[row] = address
            self._column_cell_cache[key] = columns
        left, top, right, bottom = bounds
        return tuple(address for column in range(left, right + 1)
                     for row, address in self._column_cell_cache[key].get(column, {}).items()
                     if top <= row <= bottom)

    @staticmethod
    def _same_xml(left: ET.Element, right: ET.Element) -> bool:
        """Compare full cell markup before touching an unchanged worksheet row.

        Number format, formula, cached value and unknown cell extensions all
        participate. An equal financial value alone is insufficient: selectors
        and their saved caches must remain bound to the exact display formula.
        Avoid serializing both cells solely for this in-memory equality check.
        """
        if left is right:
            return True
        if (left.tag != right.tag or left.attrib != right.attrib
                or left.text != right.text or left.tail != right.tail or len(left) != len(right)):
            return False
        return all(WorkbookPackage._same_xml(a, b) for a, b in zip(left, right))

    def _replace_cells(self, sheet: str, updates: Mapping[str, ET.Element], *, clear: Iterable[str] = ()) -> None:
        part = self._sheet_parts()[sheet]
        tree = self._xml(part)
        data = tree.find(_tag("sheetData"))
        if data is None:
            raise InputValidationError("Worksheet sheetData is missing")
        key=id(tree)
        if key not in self._row_cache:
            self._row_cache[key]={int(row.attrib['r']):row for row in data}
        rows=self._row_cache[key]
        all_cells=self._sheet_cells(tree)
        column_cells = self._column_cell_cache.get(key)
        by_row={}
        for address in clear:
            if address in updates or address not in all_cells:
                continue
            _,number=_coordinate(address)
            by_row.setdefault(number,{})[address]=None
        for address, cell in updates.items():
            previous = all_cells.get(address)
            if previous is not None and self._same_xml(previous, cell):
                continue
            _, number = _coordinate(address)
            by_row.setdefault(number, {})[address] = cell
        if not by_row:
            return
        inserted=False
        for number,changes in by_row.items():
            row=rows.get(number)
            if row is None:
                row=ET.Element(_tag('row'),r=str(number));rows[number]=row;inserted=True
            retained=[]
            extras=[]
            for cell in row:
                if cell.tag != _tag('c'):
                    extras.append(cell)
                elif cell.attrib['r'] not in changes:
                    retained.append(cell)
            for address,cell in changes.items():
                column, row_number = _coordinate(address)
                if cell is None:
                    all_cells.pop(address,None)
                    if column_cells is not None:
                        column_cells.get(column, {}).pop(row_number, None)
                else:
                    retained.append(cell);all_cells[address]=cell
                    if column_cells is not None:
                        column_cells.setdefault(column, {})[row_number] = address
            retained.sort(key=lambda cell:_coordinate(cell.attrib['r'])[0])
            row[:]=retained+extras
        if inserted:
            data[:]=[rows[number] for number in sorted(rows)]
        dimension = tree.find(_tag("dimension"))
        if dimension is not None and updates:
            left,top,right,bottom=_bounds(dimension.attrib.get('ref','A1'))
            coordinates=[_coordinate(address) for address in updates]
            # A used-range dimension may include formatted empty cells. Keep
            # its old extent on clear and expand only for new output cells.
            dimension.set('ref',_reference((min(left,min(c for c,_ in coordinates)),min(top,min(r for _,r in coordinates)),
                                            max(right,max(c for c,_ in coordinates)),max(bottom,max(r for _,r in coordinates)))))
        self._put_xml(part, tree)

    @staticmethod
    def _records(records: Iterable[Mapping[str, object] | Sequence[object]], headers: tuple[str, ...]) -> list[tuple[object, ...]]:
        result = []
        for record in records:
            if isinstance(record, Mapping):
                if set(record) != set(headers):
                    raise InputValidationError("Output record headers do not match the native Table")
                values = tuple(record[header] for header in headers)
            else:
                values = tuple(record)
                if len(values) != len(headers):
                    raise InputValidationError("Output row width does not match the native Table")
            result.append(values)
        return result

    def write_table(self, name: str, records: Iterable[Mapping[str, object] | Sequence[object]], *,
                    headers: Sequence[str] | None = None, number_formats: Mapping[str, str] | None = None,
                    autoexpand: bool = True, _reserved_bottom: int | None = None) -> TableInfo:
        """Publish actual records into one protected, named native Table lane.

        Capacity wrappers pass a private reserved bottom so final Table/name
        bounds are published once, without temporarily shrinking and regrowing
        a stable template. Only actual records receive values/formulas; physical
        old result tails lose their payloads while retaining styles/extensions.
        Full final bounds are guarded even when every value is a no-op.
        """
        inventory = self.table_inventory()
        if name not in inventory:
            raise InputValidationError(f"Missing native output Table: {name}")
        info = inventory[name]
        if headers is not None and tuple(headers) != info.headers:
            raise InputValidationError("Existing Table headers cannot be replaced")
        table = self._xml(info.part)
        if table.attrib.get("totalsRowCount", "0") != "0" or table.attrib.get("totalsRowShown") in {"1", "true"}:
            raise InputValidationError("Output transport does not rewrite totals-row Tables")
        rows = self._records(records, info.headers)
        left, top, right, old_bottom = info.bounds
        actual_bottom = top + max(len(rows), 1)
        if _reserved_bottom is not None and (isinstance(_reserved_bottom, bool)
                or not isinstance(_reserved_bottom, int) or _reserved_bottom <= top):
            raise InputValidationError("Reserved native Table bottom must be a valid body row")
        bottom = max(actual_bottom, _reserved_bottom or actual_bottom)
        if bottom > 1048576 or not autoexpand and bottom > old_bottom:
            raise InputValidationError("Output exceeds its allowed native Table rows")
        bounds = (left, top, right, bottom)
        self._guard(info.sheet, bounds, own_table=name)
        cells = self._sheet_cells(self._xml(self._sheet_parts()[info.sheet]))
        # Replacing/shrinking an owned Table cannot claim a new cell. Check
        # only the added rectangle on growth; scanning every independent lane
        # on the sheet made publication scale with unrelated output volume.
        if bottom > old_bottom:
            for address in self._existing_cell_addresses(info.sheet, (left, old_bottom + 1, right, bottom)):
                existing = cells[address]
                if any(existing.find(_tag(kind)) is not None for kind in ("v", "is", "f")):
                    raise InputValidationError(f"Table growth would overwrite unrelated worksheet content: {address}")
        formats = dict(number_formats or {})
        if set(formats) - set(info.headers):
            raise InputValidationError("Number format names an unknown output header")
        styles = []
        for offset, header in enumerate(info.headers):
            sample = cells.get(f"{_column(left + offset)}{top + 1}")
            base = int(sample.attrib.get("s", "0")) if sample is not None else 0
            styles.append(self._style(base, formats[header]) if header in formats else base)
        updates = {}
        for row_index, record in enumerate(rows or [tuple(None for _ in info.headers)], top + 1):
            for offset, value in enumerate(record):
                address = f"{_column(left + offset)}{row_index}"
                previous = cells.get(address)
                # A semantic format changes numeric display only. Preserve
                # each existing row's manual fill/font/border instead of copying
                # the first row's entire style; genuinely new cells inherit it.
                style = int(previous.attrib.get("s", "0")) if previous is not None else styles[offset]
                if info.headers[offset] in formats:
                    style = self._style(style, formats[info.headers[offset]])
                updates[address] = self._updated_cell(address, value, style, previous)
        clear = self._existing_cell_addresses(info.sheet, (left, top + 1, right, old_bottom))
        cleared_tail = []
        for address in clear:
            if _coordinate(address)[1] <= actual_bottom:
                continue
            previous = cells[address]
            if previous.attrib.get("t") is None and "vm" not in previous.attrib and not any(
                    child.tag in {_tag("f"), _tag("v"), _tag("is")} for child in previous):
                continue
            # Shrinking removes every old value, formula and cache while
            # retaining reusable presentation capacity outside the actual
            # Table ref. Value-metadata flags also belong to the removed
            # result; styles and nonvalue cell extensions remain intact.
            blank = deepcopy(previous)
            for child in list(blank):
                if child.tag in {_tag("f"), _tag("v"), _tag("is")}:
                    blank.remove(child)
            blank.attrib.pop("t", None)
            blank.attrib.pop("vm", None)
            updates[address] = blank
            cleared_tail.append(address)
        self._replace_cells(info.sheet, updates, clear=cleared_tail)
        reference = _reference(bounds)
        metadata_changed = table.attrib.get("ref") != reference
        table.set("ref", reference)
        filtering = table.find(_tag("autoFilter"))
        if filtering is not None and filtering.attrib.get("ref") != reference:
            filtering.set("ref", reference)
            metadata_changed = True
        columns = table.find(_tag("tableColumns"))
        for offset, column in enumerate(columns):
            expected = None
            if rows and bottom == actual_bottom and isinstance(rows[0][offset], FormulaCell):
                first = rows[0][offset].formula
                if all(isinstance(row[offset], FormulaCell) and row[offset].formula == first for row in rows):
                    expected = first.lstrip("=")
            existing = [child for child in column if child.tag == _tag("calculatedColumnFormula")]
            if (expected is None and not existing
                    or expected is not None and len(existing) == 1 and existing[0].text == expected):
                continue
            for child in existing:
                column.remove(child)
            if expected is not None:
                ET.SubElement(column, _tag("calculatedColumnFormula")).text = expected
            metadata_changed = True
        if metadata_changed:
            self._put_xml(info.part, table)
        self._adjust_table_names(info, info.sheet, bounds)
        return self.table_inventory()[name]

    def write_scalar(self, name: str, value: object, *, number_format: str | None = None) -> None:
        if not name.startswith(UI_PREFIX) or name in self.protected_names:
            raise InputValidationError("Cannot overwrite an input or foreign scalar name")
        sheet, bounds = self.named_region(name)
        left, top, right, bottom = bounds
        if left != right or top != bottom:
            raise InputValidationError("Scalar name must refer to exactly one cell")
        # Scalar output may sit inside its own output Table; other input guards
        # still apply. This is common for selectors and run-status displays.
        own_table = self._table_owner(sheet, bounds)
        self._guard(sheet, bounds, own_table=own_table)
        address = f"{_column(left)}{top}"
        old = self._sheet_cells(self._xml(self._sheet_parts()[sheet])).get(address)
        style = int(old.attrib.get("s", "0")) if old is not None else 0
        if number_format is not None:
            style = self._style(style, number_format)
        self._replace_cells(sheet, {address: self._updated_cell(address, value, style, old)})

    def write_cells(self, sheet: str, values: Mapping[str, object], *, number_formats: Mapping[str, str] | None = None) -> None:
        cells = self._sheet_cells(self._xml(self._sheet_parts()[sheet]))
        updates = {}
        for address, value in values.items():
            column, row = _coordinate(address)
            self._guard(sheet, (column, row, column, row))
            prior = cells.get(address)
            style = int(prior.attrib.get("s", "0")) if prior is not None else 0
            if number_formats and address in number_formats:
                style = self._style(style, number_formats[address])
            updates[address] = self._updated_cell(address, value, style, prior)
        self._replace_cells(sheet, updates)

    def set_cell_number_formats(self, sheet: str, formats: Mapping[str, str], *,
                                allow_protected_names: Iterable[str] = (),
                                allow_protected_tables: Iterable[str] = ()) -> None:
        """Change display styles without changing a cell value or formula.

        Mixed metric columns need row-specific formats. Existing style resources
        retain their indices; copied output styles use Arial and centered text.
        Explicit style-only permission may cover a protected input Table or
        name, but is never forwarded to a value/formula writer. This permits a
        mixed limit Threshold column to display its actual units without
        weakening owning-input payload protection.
        """
        cells = self._sheet_cells(self._xml(self._sheet_parts()[sheet]))
        style_only_names=frozenset(allow_protected_names)
        style_only_tables=frozenset(allow_protected_tables)
        if style_only_names-set(self.protected_names) or style_only_tables-set(self.protected_tables):
            raise InputValidationError('Style-only permission must name an existing protected owner')
        updates = {}
        for address, number_format in formats.items():
            column, row = _coordinate(address)
            owner = self._table_owner(sheet, (column, row, column, row))
            self._guard(sheet, (column, row, column, row), own_table=owner,
                        style_only_names=style_only_names, style_only_tables=style_only_tables)
            previous = cells.get(address)
            base = int(previous.attrib.get("s", "0")) if previous is not None else 0
            desired = self._style(base, number_format)
            # Run the full protection check above even for a no-op request.
            # Published rows already carry their semantic styles; retaining
            # equal cells avoids copying and re-sorting every wide result row.
            if previous is not None and base == desired:
                continue
            cell = deepcopy(previous) if previous is not None else ET.Element(_tag("c"), r=address)
            cell.set("s", str(desired))
            updates[address] = cell
        self._replace_cells(sheet, updates)

    def set_list_validation(self, sheet: str, reference: str, options_name: str, *, title: str = "Saved option",
                            prompt: str = "Select an available saved case.") -> None:
        """Install a finite named list with a native Stop error and prompt."""
        bounds = _bounds(reference)
        if options_name not in self._names() or len(title) > 32 or len(prompt)>255:
            raise InputValidationError("Validation needs a registered options name and short title")
        owner = self._table_owner(sheet, bounds)
        self._guard(sheet, bounds, own_table=owner)
        self.named_region(options_name)
        part = self._sheet_parts()[sheet]
        tree = self._xml(part)
        validations = tree.find(_tag("dataValidations"))
        if validations is None:
            validations = ET.Element(_tag("dataValidations"), count="0")
            following = {_tag(x) for x in ("hyperlinks", "printOptions", "pageMargins", "pageSetup", "headerFooter",
                                           "rowBreaks", "colBreaks", "customProperties", "cellWatches", "ignoredErrors",
                                           "smartTags", "drawing", "legacyDrawing", "legacyDrawingHF", "picture",
                                           "oleObjects", "controls", "webPublishItems", "tableParts", "extLst")}
            index = next((i for i, child in enumerate(tree) if child.tag in following), len(tree))
            tree.insert(index, validations)
        for validation in list(validations):
            refs = validation.attrib.get("sqref", "").split()
            if any(_overlap(bounds, _bounds(ref)) for ref in refs):
                if len(refs)!=1 or _bounds(refs[0])!=bounds:
                    raise InputValidationError("New validation overlaps a different native validation region")
                validations.remove(validation)
        validation = ET.SubElement(validations, _tag("dataValidation"), type="list", errorStyle="stop",
                                   allowBlank="0", showDropDown="0", showInputMessage="1", showErrorMessage="1",
                                   errorTitle="Choose a saved option", error="Choose an item from the dropdown.",
                                   promptTitle=title, prompt=prompt, sqref=_reference(bounds))
        ET.SubElement(validation, _tag("formula1")).text = options_name
        validations.set("count", str(len(validations)))
        self._put_xml(part, tree)

    def define_table_date_list(self, name: str, table_name: str, header: str = 'Date') -> None:
        """Name the selected case's contiguous numeric dates, excluding tails."""
        info=self.table_inventory().get(table_name)
        if not name.startswith(UI_PREFIX) or name in self.protected_names or info is None or header not in info.headers or any(c in header for c in '[]'):
            raise InputValidationError('Dynamic date list needs an existing output Table column')
        column=f'{table_name}[{header}]'
        value=f'INDEX({column},1):INDEX({column},MAX(1,COUNT({column})))'
        workbook=self._xml('xl/workbook.xml');names=workbook.find(_tag('definedNames'))
        item=next((item for item in names if item.attrib['name']==name),None)
        if item is None:item=ET.SubElement(names,_tag('definedName'),name=name)
        if item.text != value:
            item.text=value;self._put_xml('xl/workbook.xml',workbook)

    def _set_column_widths(self, sheet: str, widths: Mapping[int, float], *, hidden: bool = False) -> None:
        part = self._sheet_parts()[sheet]
        tree = self._xml(part)
        columns = tree.find(_tag("cols"))
        if columns is None:
            columns = ET.Element(_tag("cols"))
            index = next((i for i, child in enumerate(tree) if child.tag == _tag("sheetData")), len(tree))
            tree.insert(index, columns)
        for number, width in widths.items():
            _column(number)
            if not math.isfinite(width) or not 0 < width <= 255:
                raise InputValidationError("Column width is outside Excel bounds")
            for item in list(columns):
                first, last = int(item.attrib["min"]), int(item.attrib["max"])
                if first <= number <= last:
                    columns.remove(item)
                    for left, right in ((first, number - 1), (number + 1, last)):
                        if left <= right:
                            clone = deepcopy(item); clone.set("min", str(left)); clone.set("max", str(right)); columns.append(clone)
            ET.SubElement(columns, _tag("col"), min=str(number), max=str(number), width=str(width),
                          customWidth="1", hidden="1" if hidden else "0")
        columns[:] = sorted(columns, key=lambda item: int(item.attrib["min"]))
        self._put_xml(part, tree)

    def remove_validation(self, sheet: str, reference: str) -> None:
        """Remove an inherited dropdown from an explicitly read-only cell."""
        bounds=_bounds(reference)
        self._guard(sheet,bounds)
        part=self._sheet_parts()[sheet]
        tree=self._xml(part)
        validations=tree.find(_tag('dataValidations'))
        if validations is None:
            return
        for validation in list(validations):
            remaining=[]
            for item in validation.attrib.get('sqref','').split():
                region=_bounds(item)
                if _overlap(bounds,region):
                    if bounds != region:
                        raise InputValidationError('Read-only validation removal must name its complete rectangle')
                else:
                    remaining.append(item)
            if remaining:
                validation.set('sqref',' '.join(remaining))
            else:
                validations.remove(validation)
        if len(validations):
            validations.set('count',str(len(validations)))
        else:
            tree.remove(validations)
        self._put_xml(part,tree)

    def refresh_selector_layout(self) -> None:
        """Keep the cashflow selector usable and the Home case display read only."""
        if 'Asset Cashflows' in self._sheet_parts():
            part=self._sheet_parts()['Asset Cashflows']
            tree=self._xml(part)
            merges=tree.find(_tag('mergeCells'))
            if merges is not None:
                for merge in list(merges):
                    if _overlap(_bounds(merge.attrib['ref']),(2,7,16,7)):
                        merges.remove(merge)
                for reference in ('B7:C7','D7:H7','J7:P7'):
                    ET.SubElement(merges,_tag('mergeCell'),ref=reference)
                merges.set('count',str(len(merges)))
                self._put_xml(part,tree)
            self.write_cells('Asset Cashflows',{'B7':'Saved case','J7':'Choose a complete model case or Library reference.'})
        self.remove_validation('Home','I7')
        self.set_cell_number_formats('Home',{'Z3':'General'},
                                     allow_protected_names=(self.schema_name,) if self.schema_name in self.protected_names else ())

    def add_hidden_results_sheet(self, title: str = "_Results") -> str:
        if title in self._sheet_parts():
            workbook = self._xml("xl/workbook.xml")
            sheet = next(item for item in workbook.find(_tag("sheets")) if item.attrib["name"] == title)
            if sheet.attrib.get("state") not in {"hidden", "veryHidden"}:
                raise InputValidationError("Results backing sheet must remain hidden")
            return title
        if len(title) > 31 or re.search(r"[\[\]:*?/\\]", title):
            raise InputValidationError("Invalid hidden worksheet title")
        workbook = self._xml("xl/workbook.xml")
        sheets = workbook.find(_tag("sheets"))
        identifier = max(int(sheet.attrib["sheetId"]) for sheet in sheets) + 1
        part_index = 1
        while f"xl/worksheets/sheet{part_index}.xml" in self.parts:
            part_index += 1
        part = f"xl/worksheets/sheet{part_index}.xml"
        rel_part = self._relationship_part("xl/workbook.xml")
        relationships = self._xml(rel_part)
        keys = {item.attrib["Id"] for item in relationships}
        number = 1
        while f"rId{number}" in keys:
            number += 1
        key = f"rId{number}"
        ET.SubElement(relationships, "{" + PACKAGE_REL + "}Relationship", Id=key, Type=REL + "/worksheet", Target=f"worksheets/sheet{part_index}.xml")
        ET.SubElement(sheets, _tag("sheet"), {"name": title, "sheetId": str(identifier), "state": "hidden", "{" + REL + "}id": key})
        self._put_xml(rel_part, relationships)
        self._put_xml("xl/workbook.xml", workbook)
        tree = ET.Element(_tag("worksheet"))
        ET.SubElement(tree, _tag("dimension"), ref="A1")
        ET.SubElement(tree, _tag("sheetData"))
        self._put_xml(part, tree)
        types = self._xml("[Content_Types].xml")
        ET.SubElement(types, "{" + CONTENT + "}Override", PartName="/" + part, ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml")
        self._put_xml("[Content_Types].xml", types)
        return title

    def add_table(self, name: str, headers: Sequence[str], records: Iterable[Mapping[str, object] | Sequence[object]], *,
                  sheet: str = "_Results", start_cell: str | None = None,
                  number_formats: Mapping[str, str] | None = None) -> TableInfo:
        if not name.startswith(TABLE_PREFIX) or not re.fullmatch(r"[A-Za-z_][A-Za-z_0-9]*", name):
            raise InputValidationError("New output Table must use the compact UI namespace")
        inventory = self.table_inventory()
        if name in inventory:
            return self.write_table(name, records, headers=headers, number_formats=number_formats)
        headers = tuple(headers)
        if not headers or len(set(headers)) != len(headers) or any(not isinstance(h, str) or not h or len(h) > 255 for h in headers):
            raise InputValidationError("New Table requires unique nonempty text headers")
        if sheet not in self._sheet_parts():
            self.add_hidden_results_sheet(sheet)
        if start_cell is None:
            last = max([0, *(info.bounds[2] for info in inventory.values() if info.sheet == sheet)])
            left, top = last + (3 if last else 1), 1
        else:
            left, top = _coordinate(start_cell)
        rows = self._records(records, headers)
        right, bottom = left + len(headers) - 1, top + max(len(rows), 1)
        _coordinate(f"{_column(right)}{bottom}")
        self._guard(sheet, (left, top, right, bottom))
        identifier = max([0, *(info.identifier for info in inventory.values())]) + 1
        table_part = f"xl/tables/trident_ui_result_{identifier}.xml"
        while table_part in self.parts:
            identifier += 1
            table_part = f"xl/tables/trident_ui_result_{identifier}.xml"
        table = ET.Element(_tag("table"), id=str(identifier), name=name, displayName=name, ref=_reference((left, top, right, bottom)), headerRowCount="1", totalsRowShown="0")
        ET.SubElement(table, _tag("autoFilter"), ref=table.attrib["ref"])
        columns = ET.SubElement(table, _tag("tableColumns"), count=str(len(headers)))
        for index, header in enumerate(headers, 1):
            ET.SubElement(columns, _tag("tableColumn"), id=str(index), name=header)
        ET.SubElement(table, _tag("tableStyleInfo"), name="TableStyleMedium4", showFirstColumn="0", showLastColumn="0", showRowStripes="1", showColumnStripes="0")
        self._put_xml(table_part, table)
        sheet_part = self._sheet_parts()[sheet]
        rel_part = self._relationship_part(sheet_part)
        relationships = self._xml(rel_part) if rel_part in self.parts else ET.Element("{" + PACKAGE_REL + "}Relationships")
        keys = {item.attrib["Id"] for item in relationships}
        index = 1
        while f"rId{index}" in keys:
            index += 1
        key = f"rId{index}"
        ET.SubElement(relationships, "{" + PACKAGE_REL + "}Relationship", Id=key, Type=REL + "/table", Target=posixpath.relpath(table_part, posixpath.dirname(sheet_part)))
        self._put_xml(rel_part, relationships)
        tree = self._xml(sheet_part)
        table_parts = tree.find(_tag("tableParts"))
        if table_parts is None:
            table_parts = ET.Element(_tag("tableParts"), count="0")
            extension_index = next((i for i, child in enumerate(tree) if child.tag == _tag("extLst")), len(tree))
            tree.insert(extension_index, table_parts)
        ET.SubElement(table_parts, _tag("tablePart"), {"{" + REL + "}id": key})
        table_parts.set("count", str(len(table_parts)))
        self._put_xml(sheet_part, tree)
        types = self._xml("[Content_Types].xml")
        ET.SubElement(types, "{" + CONTENT + "}Override", PartName="/" + table_part, ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.table+xml")
        self._put_xml("[Content_Types].xml", types)
        workbook = self._xml("xl/workbook.xml")
        names = workbook.find(_tag("definedNames"))
        if names is None:
            names = ET.SubElement(workbook, _tag("definedNames"))
        alias = name.removeprefix("tbl_")
        if alias in self._names():
            raise InputValidationError("New output alias conflicts with a workbook name")
        ET.SubElement(names, _tag("definedName"), name=alias).text = name + "[#All]"
        self._put_xml("xl/workbook.xml", workbook)
        header_style = self._style(0, "General")
        body_style = self._style(0, "General")
        updates = {f"{_column(left + i)}{top}": self._cell(f"{_column(left + i)}{top}", header, header_style) for i, header in enumerate(headers)}
        for i in range(len(headers)):
            address = f"{_column(left + i)}{top + 1}"
            updates[address] = self._cell(address, None, body_style)
        self._replace_cells(sheet, updates)
        self._set_column_widths(sheet, {left+i: 16 if any(k in header.lower() for k in ("date", "maturity", "settlement")) else 24
                                      for i, header in enumerate(headers)})
        return self.write_table(name, rows, number_formats=number_formats)

    def move_table(self, name: str, sheet: str = "_Results", *, start_cell: str | None = None) -> TableInfo:
        """Relocate an output Table without replacing its identity or formulas."""
        inventory = self.table_inventory()
        if name not in inventory or name in self.protected_tables:
            raise InputValidationError("Cannot relocate an unknown or input Table")
        info = inventory[name]
        if sheet not in self._sheet_parts():
            self.add_hidden_results_sheet(sheet)
        if start_cell is None:
            last = max([0, *(item.bounds[2] for item in self.table_inventory().values() if item.sheet == sheet and item.name != name)])
            left, top = last + (3 if last else 1), 1
        else:
            left, top = _coordinate(start_cell)
        old_left, old_top, old_right, old_bottom = info.bounds
        bounds = (left, top, left + old_right - old_left, top + old_bottom - old_top)
        _coordinate(f"{_column(bounds[2])}{bounds[3]}")
        self._guard(sheet, bounds, own_table=name)
        old_sheet_part = self._sheet_parts()[info.sheet]
        cells = self._sheet_cells(self._xml(old_sheet_part))
        updates = {}
        clear = []
        for address, cell in cells.items():
            column, row = _coordinate(address)
            if old_left <= column <= old_right and old_top <= row <= old_bottom:
                new_address = f"{_column(left + column - old_left)}{top + row - old_top}"
                clone = deepcopy(cell)
                clone.set("r", new_address)
                updates[new_address] = clone
                clear.append(address)
        self._replace_cells(info.sheet, {}, clear=clear)
        self._replace_cells(sheet, updates)
        old_tree = self._xml(old_sheet_part)
        old_parts = old_tree.find(_tag("tableParts"))
        old_rel_part = self._relationship_part(old_sheet_part)
        old_relationships = self._xml(old_rel_part)
        old_id = next(item.attrib["Id"] for item in old_relationships if self._resolved_part(old_sheet_part, item.attrib["Target"]) == info.part)
        for item in list(old_relationships):
            if item.attrib["Id"] == old_id:
                old_relationships.remove(item)
        for item in list(old_parts):
            if item.attrib["{" + REL + "}id"] == old_id:
                old_parts.remove(item)
        if len(old_parts):
            old_parts.set("count", str(len(old_parts)))
        else:
            old_tree.remove(old_parts)
        self._put_xml(old_rel_part, old_relationships)
        self._put_xml(old_sheet_part, old_tree)
        new_sheet_part = self._sheet_parts()[sheet]
        new_rel_part = self._relationship_part(new_sheet_part)
        relationships = self._xml(new_rel_part) if new_rel_part in self.parts else ET.Element("{" + PACKAGE_REL + "}Relationships")
        keys = {item.attrib["Id"] for item in relationships}
        number = 1
        while f"rId{number}" in keys:
            number += 1
        new_id = f"rId{number}"
        ET.SubElement(relationships, "{" + PACKAGE_REL + "}Relationship", Id=new_id, Type=REL + "/table", Target=posixpath.relpath(info.part, posixpath.dirname(new_sheet_part)))
        self._put_xml(new_rel_part, relationships)
        new_tree = self._xml(new_sheet_part)
        parts = new_tree.find(_tag("tableParts"))
        if parts is None:
            parts = ET.Element(_tag("tableParts"), count="0")
            extension_index = next((i for i, child in enumerate(new_tree) if child.tag == _tag("extLst")), len(new_tree))
            new_tree.insert(extension_index, parts)
        ET.SubElement(parts, _tag("tablePart"), {"{" + REL + "}id": new_id})
        parts.set("count", str(len(parts)))
        self._put_xml(new_sheet_part, new_tree)
        table = self._xml(info.part)
        table.set("ref", _reference(bounds))
        filter_ = table.find(_tag("autoFilter"))
        if filter_ is not None:
            filter_.set("ref", table.attrib["ref"])
        self._put_xml(info.part, table)
        self._adjust_table_names(info, sheet, bounds)
        return self.table_inventory()[name]

    def add_case_view(self, table_name: str, cases: Mapping[str, Sequence[Mapping[str, object]]], *,
                      selector_name: str = "trident_ui_analysis_case", number_formats: Mapping[str, str] | None = None) -> TableInfo:
        """Store complete case data and replace one UI reader with keyed lookups."""
        inventory = self.table_inventory()
        if table_name not in inventory or not cases:
            raise InputValidationError("Case view requires an existing reader and complete case mapping")
        info = inventory[table_name]
        if selector_name not in self._names():
            raise InputValidationError("Case selector name is missing")
        key_header = "Result record key" if "Recordkey" in info.headers else "Recordkey"
        case_header = "Result case" if "Case" in info.headers else "Case"
        backing = TABLE_PREFIX + "results_" + table_name.removeprefix(TABLE_PREFIX)
        complete = []
        maximum = 0
        for case, rows in cases.items():
            if not isinstance(case, str) or not case or "|" in case:
                raise InputValidationError("Case identifier must be nonempty and cannot contain the key delimiter")
            normalized = self._records(rows, info.headers)
            maximum = max(maximum, len(normalized))
            for ordinal, row in enumerate(normalized, 1):
                complete.append((case + "|" + str(ordinal), case, *row))
        self.add_table(backing, (key_header, case_header, *info.headers), complete, number_formats=number_formats)
        selected = str(self.read_scalar(selector_name))
        selected_rows = cases.get(selected, ())
        rows = []
        for ordinal in range(1, maximum + 1):
            record = {}
            for header in info.headers:
                if any(char in header for char in "[]"):
                    raise InputValidationError("Case header needs a reviewed structured-reference escape")
                lookup = f'INDEX({backing}[{header}],MATCH({selector_name}&"|"&{ordinal},{backing}[{key_header}],0))'
                formula = f'IFERROR(IF({lookup}="","",{lookup}),"")'
                cache = selected_rows[ordinal - 1].get(header) if ordinal <= len(selected_rows) else ""
                record[header] = FormulaCell(formula, cache)
            rows.append(record)
        return self.write_table(table_name, rows, number_formats=number_formats)

    def install_case_reader(self, name: str, backing_table: str, case_name: str, *, row_count: int,
                            selected_records: Sequence[Mapping[str, object]] = (),
                            number_formats: Mapping[str, str] | None = None) -> TableInfo:
        """Wrap case-record lookups; no financial result is calculated in Excel."""
        inventory = self.table_inventory()
        if backing_table not in inventory or name not in inventory:
            raise InputValidationError("Case reader references an unknown Table")
        if case_name not in self._names() or "Recordkey" not in inventory[backing_table].headers:
            raise InputValidationError("Case reader requires its registered selector and Recordkey")
        info = inventory[name]
        if set(info.headers) - set(inventory[backing_table].headers):
            raise InputValidationError("Case backing data lacks reader fields")
        if row_count < 0:
            raise InputValidationError("Case row count cannot be negative")
        rows = []
        for ordinal in range(1, row_count + 1):
            record = {}
            for header in info.headers:
                if any(char in header for char in "[]"):
                    raise InputValidationError("Case reader header needs a reviewed structured-reference escape")
                lookup = f'INDEX({backing_table}[{header}],MATCH({case_name}&"|"&{ordinal},{backing_table}[Recordkey],0))'
                formula = f'IFERROR(IF({lookup}="","",{lookup}),"")'
                cache = selected_records[ordinal - 1].get(header) if ordinal <= len(selected_records) else None
                record[header] = FormulaCell(formula, cache)
            rows.append(record)
        return self.write_table(name, rows, number_formats=number_formats)

    def _cached_value(self, cell: ET.Element | None) -> object:
        if cell is None:
            return None
        kind = cell.attrib.get("t", "n")
        value = cell.findtext(_tag("v"))
        if kind == "inlineStr":
            return "".join(cell.find(_tag("is")).itertext())
        if kind == "s":
            return self._shared_string(int(value))
        if kind == "b":
            return value == "1"
        if kind == "e":
            return ExcelError(value)
        if kind == "str":
            return value
        return None if value is None else float(value)

    def _table_records(self, name: str) -> list[dict[str, object]]:
        info = self.table_inventory()[name]
        cells = self._sheet_cells(self._xml(self._sheet_parts()[info.sheet]))
        left, top, _, bottom = info.bounds
        return [{header: self._cached_value(cells.get(f"{_column(left+i)}{row}")) for i, header in enumerate(info.headers)}
                for row in range(top+1, bottom+1)]

    def refresh_input_witnesses(self, inputs: object) -> None:
        """Freeze the just-calculated raw input values for the next edit check.

        Witnesses carry typed values, never links back to live inputs. The
        recorded owning rectangles deliberately exclude display-only lookups.
        A complete-table rectangle follows user row growth; partial controls
        retain their declared subsection. Market Data is read only throughout.
        """
        inventory = self.table_inventory()
        original_frozen = {}
        for name, frozen in inventory.items():
            if not name.startswith(TABLE_PREFIX + "frozen_"):
                continue
            source_name = TABLE_PREFIX + name.removeprefix(TABLE_PREFIX + "frozen_")
            if source_name not in inventory:
                continue
            source = inventory[source_name]
            if source.headers != frozen.headers:
                raise InputValidationError("Input witness headers differ from their owning Table")
            original_frozen[source_name] = frozen
            source_cells = self._sheet_cells(self._xml(self._sheet_parts()[source.sheet]))
            records = self._table_records(source_name)
            updated = self.write_table(name, records)
            left,top,_,bottom = source.bounds
            target_left,target_top,_,_ = updated.bounds
            copied = {}
            for row in range(top+1,bottom+1):
                for offset in range(len(source.headers)):
                    address=f'{_column(target_left+offset)}{target_top+row-top}'
                    original=source_cells.get(f'{_column(left+offset)}{row}')
                    if original is None:
                        copied[address]=self._cell(address,None,0)
                    else:
                        clone=deepcopy(original);clone.set('r',address)
                        formula=clone.find(_tag('f'))
                        if formula is not None:
                            clone.remove(formula)
                        copied[address]=clone
            self._replace_cells(updated.sheet,copied)
        sheet_cells = {sheet: self._sheet_cells(self._xml(part)) for sheet, part in self._sheet_parts().items()}
        updates_by_sheet = {}
        for name in tuple(self._names()):
            if not name.startswith(UI_PREFIX + "fresh_current_"):
                continue
            saved_name = name.replace("fresh_current_", "fresh_saved_", 1)
            source_sheet, source_bounds = self.named_region(name)
            saved_sheet, saved_bounds = self.named_region(saved_name)
            a, b, c, d = source_bounds
            e, f, g, h = saved_bounds
            if c-a != g-e or d-b != h-f:
                raise InputValidationError("Input witness rectangle dimensions disagree")
            for source_name, frozen in original_frozen.items():
                source = inventory[source_name]
                left, top, right, bottom = source.bounds
                if source.sheet == source_sheet and left <= a <= c <= right and b == top+1 and d-b+1 == frozen.bounds[3]-frozen.bounds[1]:
                    d = bottom; h = f+d-b
                    self.define_name(name, source_sheet, _reference((a,b,c,d)))
                    self.define_name(saved_name, saved_sheet, _reference((e,f,g,h)))
                    break
            updates = updates_by_sheet.setdefault(saved_sheet, {})
            for row in range(b,d+1):
                for column in range(a,c+1):
                    source_address = f"{_column(column)}{row}"
                    target_address = f"{_column(e+column-a)}{f+row-b}"
                    prior = sheet_cells[saved_sheet].get(target_address)
                    base = int(prior.attrib.get("s", "0")) if prior is not None else 0
                    updates[target_address] = self._updated_cell(target_address, self._cached_value(sheet_cells[source_sheet].get(source_address)), base, prior)
        for sheet, updates in updates_by_sheet.items():
            self._replace_cells(sheet, updates)
        if "Checks" in self._sheet_parts():
            updates = {}
            for address, cell in self._sheet_cells(self._xml(self._sheet_parts()["Checks"])).items():
                formula = cell.findtext(_tag("f"))
                if not formula or "trident_ui_fresh_" not in formula and address not in {"H34", "I34"}:
                    continue
                def size(match):
                    info = self.table_inventory().get(match[2])
                    if info is None:
                        raise InputValidationError("Freshness dimension check references a missing Table")
                    expected = info.bounds[3]-info.bounds[1] if match[1] == "ROWS" else len(info.headers)
                    return match[0][:match[0].rfind("<>")+2] + str(expected)
                formula = re.sub(r'(ROWS|COLUMNS)\((tbl_trident_ui_[A-Za-z_0-9]+)\[[^)]*\]\)<>[0-9]+', size, formula)
                cache = "UNCHANGED INPUTS" if address.startswith("I") else 0
                updates[address] = self._updated_cell(address, FormulaCell(formula, cache), int(cell.attrib.get("s", "0")), cell)
            self._replace_cells("Checks", updates)

    def refresh_display_views(self, run: object) -> None:
        """Extend existing native display wrappers to every saved period.

        Only presentation joins and ranges change. The complete account and
        tranche records are supplied by Python, including each case's dates.
        """
        self.refresh_selector_layout()
        self.refresh_input_derived_views(run)
        self.refresh_date_options(run)
        self.refresh_measurement_statuses(run)
        cases = tuple(run.cases)
        period_count = max((len(case.result.clo.periods) if case.result.clo is not None else 0 for case in cases), default=0)
        # A run that did not select CLO still refreshes the visible wrappers;
        # one empty native chart slot replaces every old cached projection.
        period_count=max(1,period_count)
        inventory = self.table_inventory()
        account_name, wf_name = TABLE_PREFIX+"account_records", TABLE_PREFIX+"waterfall_records"
        if inventory[account_name].sheet == "Waterfall" or inventory[wf_name].sheet == "Waterfall":
            raise InputValidationError("Move raw output Tables before extending the Waterfall display")
        account_rows = self._table_records(account_name)
        wf_rows = self._table_records(wf_name)
        by_period = {int(row['period_number']):row for row in account_rows if isinstance(row.get('period_number'), (int,float))}
        by_tranche = {(str(row['class_id']),int(row['period_number'])):row for row in wf_rows
                      if isinstance(row.get('period_number'), (int,float))}
        tranche = str(self.read_scalar(UI_PREFIX+'selected_tranche'))
        sheet = "Waterfall"
        cells = self._sheet_cells(self._xml(self._sheet_parts()[sheet]))
        templates = {row: cell for address, cell in cells.items() for column,row in [_coordinate(address)]
                     if column == 5 and row >= 10 and row <= 83}
        old_count = max([0,*(_coordinate(address)[0]-4 for address,cell in cells.items()
                            if _coordinate(address)[1] == 10 and 5 <= _coordinate(address)[0] < 1000
                            and (cell.find(_tag('v')) is not None or cell.find(_tag('f')) is not None))])
        maximum = max(period_count,old_count)
        updates = {}
        for ordinal in range(1,maximum+1):
            actual_period=account_rows[ordinal-1].get('period_number') if ordinal<=len(account_rows) else None
            account_period=f'INDEX({account_name}[period_number],{ordinal})'
            for row, template in templates.items():
                address = f"{_column(ordinal+4)}{row}"
                self._guard(sheet,(ordinal+4,row,ordinal+4,row))
                style = int(template.attrib.get('s','0'))
                formula = template.findtext(_tag('f'))
                if row == 10:
                    formula = f'IFERROR(IF({account_period}="","",INDEX({account_name}[payment_date],{ordinal})),"")'
                    cache = account_rows[ordinal-1].get('payment_date') if ordinal<=len(account_rows) else None
                elif formula:
                    while formula.startswith('IFERROR(') and formula.endswith(',"")'):
                        formula=formula[len('IFERROR('):-len(',"")')]
                    formula = re.sub(r'MATCH\([0-9]+,trident_ui_account_periods',f'MATCH({account_period},trident_ui_account_periods',formula)
                    formula = re.sub(r'trident_ui_selected_tranche&"\|[0-9]+"',f'trident_ui_selected_tranche&"|"&{account_period}',formula)
                    # Regenerated workbooks already contain a sequence lookup;
                    # update its ordinal while retaining the actual period ID.
                    formula = re.sub(r'(INDEX\('+account_name+r'\[period_number\],)[0-9]+(\))',lambda m:m[1]+str(ordinal)+m[2],formula)
                    field = re.search(r'MATCH\("([^"]+)",trident_ui_(account|wf)_headers',formula)
                    record = by_period.get(actual_period,{}) if field and field[2]=='account' else by_tranche.get((tranche,actual_period),{})
                    cache = record.get(field[1]) if field else None
                    formula = f'IFERROR({formula},"")'
                else:
                    updates[address] = self._cell(address,None,style)
                    continue
                updates[address] = self._cell(address,FormulaCell(formula,cache),style)
        self._replace_cells(sheet,updates)
        self._set_column_widths(sheet,{ordinal+4: 22 for ordinal in range(1,maximum+1)})
        tree=self._xml(self._sheet_parts()[sheet])
        merges=tree.find(_tag('mergeCells'))
        if merges is not None:
            for merge in merges:
                left,top,right,bottom=_bounds(merge.attrib['ref'])
                if left==2 and top==bottom and 11<=top<=83 and right==old_count+4:
                    merge.set('ref',_reference((left,top,maximum+4,bottom)))
            self._put_xml(self._sheet_parts()[sheet],tree)
        # Native series refer to workbook names. Extending those finite names
        # preserves chart IDs, drawing anchors, titles, and series formatting.
        sheet = "CLO Analysis"
        cells = self._sheet_cells(self._xml(self._sheet_parts()[sheet]))
        time_columns = tuple(_coordinate(column+'1')[0] for column in
                             ('JT','JU','JV','JW','JY','JZ','KA','KE','KF','KG','KJ','KK','KL','KN','KO','KP'))
        updates = {}
        for column in time_columns:
            sample = cells.get(f'{_column(column)}11')
            if sample is None:
                raise InputValidationError('Native chart helper template is missing')
            template = sample.findtext(_tag('f'))
            if template:
                base_period=f'INDEX({TABLE_PREFIX}view_amortization[Period],1)'
                prefix=f'IFERROR(IF(AND(ISNUMBER({base_period}),{base_period}>0),'
                suffix=',NA()),NA())'
                while template.startswith(prefix) and template.endswith(suffix):
                    template=template[len(prefix):-len(suffix)]
                if TABLE_PREFIX+'view_coverage[' in template:
                    template=template.replace('="BREACH"','="FAIL"')
            for ordinal in range(1,period_count+1):
                address = f'{_column(column)}{ordinal+10}'
                self._guard(sheet,(column,ordinal+10,column,ordinal+10))
                style = int(sample.attrib.get('s','0'))
                if template:
                    formula = re.sub(r'(INDEX\(tbl_trident_ui_[A-Za-z_0-9]+\[[^]]+\],)([12])(\))',
                                     lambda m: m[1]+str(ordinal+(int(m[2])-1))+m[3],template)
                    period=f'INDEX({TABLE_PREFIX}view_amortization[Period],{ordinal})'
                    formula=re.sub(r'trident_ui_analysis_tranche&"\|[0-9]+"',f'trident_ui_analysis_tranche&"|"&{period}',formula)
                    formula = f'IFERROR(IF(AND(ISNUMBER({period}),{period}>0),{formula},NA()),NA())'
                    updates[address] = self._cell(address,FormulaCell(formula),style)
                else:
                    updates[address] = self._cell(address,self._cached_value(sample),style)
        self._replace_cells(sheet,updates)
        for name in tuple(self._names()):
            if re.match(r'trident_ui_chart_(equity|amort|principal|oc|ic)_ref_',name):
                title,bounds = self.named_region(name)
                left,top,right,bottom = bounds
                if title == sheet and top == 11:
                    self.define_name(name,sheet,_reference((left,top,right,10+period_count)))
        # Fixed composition and fee helpers must follow the selected full case,
        # rather than retaining the old prototype's literal baseline values.
        fixed = {}
        for ordinal, kind in enumerate(('BSL','INFRA'),11):
            lookup=(f'SUMIFS({TABLE_PREFIX}view_composition[Share],{TABLE_PREFIX}view_composition[Scope],"Whole",'
                    f'{TABLE_PREFIX}view_composition[Dimension],"asset_class",{TABLE_PREFIX}view_composition[Bucket],"{kind}")')
            fixed[f'KW{ordinal}']=FormulaCell(f'IFERROR({lookup},NA())')
        for ordinal, field in enumerate(('senior_expenses_paid','senior_management_fee_paid','subordinated_management_fee_paid','incentive_fee_paid'),11):
            lookup=f'SUM({account_name}[{field}])'
            if field=='senior_expenses_paid':
                lookup+=f'+SUM({account_name}[deferred_senior_expenses_paid])'
            fixed[f'LA{ordinal}']=FormulaCell(f'IFERROR({lookup},NA())')
        # Closing costs are a typed economics result, not the previous seed's
        # literal EUR value. A unavailable record stays explicitly unavailable.
        economics = TABLE_PREFIX+'economics'
        total=f'INDEX({economics}[Value],MATCH("TOTAL_FEES_PAID",{economics}[Economics metric],0))'
        life=f'INDEX({economics}[Value],MATCH("TOTAL_LIFECYCLE_FEES_PAID",{economics}[Economics metric],0))'
        fixed['LA15']=FormulaCell(f'IFERROR(IF(AND(ISNUMBER({total}),ISNUMBER({life})),{total}-{life},NA()),NA())')
        self.write_cells(sheet,fixed)
        stack_name = TABLE_PREFIX+'view_stack'
        stack_rows = self._table_records(stack_name)
        stack_fields = {'J':'Tranche','K':'Face (EUR)','M':'Spread (bps)','N':'OC minimum','O':'IC minimum','P':'Type'}
        updates = {}
        for ordinal in range(1,7):
            for column,field in stack_fields.items():
                lookup=f'INDEX({stack_name}[{field}],{ordinal})'
                cache=stack_rows[ordinal-1].get(field) if ordinal<=len(stack_rows) else ''
                updates[f'{column}{ordinal+44}']=FormulaCell(f'IFERROR({lookup},"")',cache)
        self.write_cells(sheet,updates)
        debt_rows = [row for row in stack_rows if row.get('Type') != 'EQUITY' and row.get('Tranche') not in ('',None)]
        tranche_options = TABLE_PREFIX+'analysis_options_tranche'
        if debt_rows:
            self.write_table(tranche_options,({'Tranche':row['Tranche']} for row in debt_rows))
            for selector in (UI_PREFIX+'analysis_tranche',UI_PREFIX+'selected_tranche'):
                allowed=debt_rows if selector==UI_PREFIX+'analysis_tranche' else stack_rows
                if self.read_scalar(selector) not in {row['Tranche'] for row in allowed}:
                    self.write_scalar(selector,debt_rows[0]['Tranche'])
        updates = {}
        summary_fields = ('B','C','E','G','H','J','K','L','N')
        for index in range(5):
            row = 134+index
            identity = str(debt_rows[index]['Tranche']) if index<len(debt_rows) else ''
            updates[f'B{row}']=identity
            for column in summary_fields[1:]:
                address=f'{column}{row}'
                template = cells.get(address)
                formula = template.findtext(_tag('f')) if template is not None else None
                if identity and formula:
                    while formula.startswith('IFERROR(') and formula.endswith(',"n.a.")'):
                        formula=formula[len('IFERROR('):-len(',"n.a.")')]
                    formula=formula.replace('="BREACH"','="FAIL"')
                    formula = re.sub(r'MATCH\("[^"]+\|"&trident_ui_analysis_period',
                                     f'MATCH("{identity}|"&trident_ui_analysis_period',formula)
                    updates[address]=FormulaCell(f'IFERROR({formula},"n.a.")')
                else:
                    updates[address]=''
        self.write_cells(sheet,updates)
        # Coverage statuses are Python PASS/FAIL. Other limit results retain
        # their separate BREACH vocabulary. Only coverage display wrappers are
        # adjusted, including the currently selected tranche's visible ratios.
        coverage_updates={}
        for address,cell in self._sheet_cells(self._xml(self._sheet_parts()[sheet])).items():
            formula=cell.findtext(_tag('f'))
            if formula and TABLE_PREFIX+'view_coverage[' in formula:
                updated=formula.replace('="BREACH"','="FAIL"')
                column,row=_coordinate(address)
                if 2<=column<=16:
                    while updated.startswith('IFERROR(') and updated.endswith(',"n.a.")'):
                        updated=updated[len('IFERROR('):-len(',"n.a.")')]
                    updated=f'IFERROR({updated},"n.a.")'
                if updated==formula:
                    continue
                clone=deepcopy(cell);clone.find(_tag('f')).text=updated
                coverage_updates[address]=clone
        if coverage_updates:
            self._replace_cells(sheet,coverage_updates)
        self.refresh_limit_summary(run)
        self.refresh_metric_catalog()

    def refresh_date_options(self, run: object) -> None:
        """Expose only actual future payment dates from each complete case."""
        table=TABLE_PREFIX+'analysis_options_date'
        if table not in self.table_inventory():
            return
        cases={case.case_id:tuple({'Date':period.payment_date} for period in case.result.clo.periods)
               if case.result.clo is not None else () for case in run.cases}
        self.add_case_view(table,cases,number_formats={'Date':'dd-mmm-yyyy'})
        options=UI_PREFIX+'analysis_options_date'
        self.define_table_date_list(options,table)
        selector=UI_PREFIX+'analysis_date'
        if selector in self._names():
            selected=str(self.read_scalar(UI_PREFIX+'analysis_case'))
            dates=cases.get(selected,())
            self.write_scalar(selector,dates[0]['Date'] if dates else None,number_format='dd-mmm-yyyy')
            sheet,bounds=self.named_region(selector)
            self.set_list_validation(sheet,_reference(bounds),options,title='Saved future payment date',
                                     prompt='Select a payment date from the current saved case.')
        period_name=UI_PREFIX+'analysis_period'
        if period_name in self._names():
            selected=str(self.read_scalar(UI_PREFIX+'analysis_case'))
            case=next((case for case in run.cases if case.case_id==selected),None)
            periods=case.result.clo.periods if case is not None and case.result.clo is not None else ()
            cache=periods[0].period_number if periods else 'n.a.'
            view=TABLE_PREFIX+'view_amortization'
            self.write_scalar(period_name,FormulaCell(f'IFERROR(INDEX({view}[Period],MATCH({UI_PREFIX}analysis_date,{view}[Date],0)),"n.a.")',cache))

    def refresh_measurement_statuses(self, run: object) -> None:
        """Bind compact measurements and statuses to the same saved records.

        Friendly labels affect display only. Source status enums, financial
        values and case/scope identities remain unchanged in native Tables.
        An unselected CLO has no economics or coverage rows; its old template
        caches must not become available observations or visible lookup errors.
        """
        sheet='CLO Analysis'
        if sheet not in self._sheet_parts():
            return
        inventory=self.table_inventory()
        cells=self._sheet_cells(self._xml(self._sheet_parts()[sheet]))
        updates={}
        friendly_labels={'UNAVAILABLE':'Missing data','NOT_CONFIGURED':'Not set',
                         'NOT_SELECTED':'Not selected','NOT_APPLICABLE':'n.a.'}
        def friendly(formula):
            for source,label in friendly_labels.items():
                formula=f'SUBSTITUTE({formula},"{source}","{label}")'
            return formula
        def status_cell(address, formula, status):
            updates[address]=FormulaCell(friendly(formula),friendly_labels.get(status,status))
        cases=tuple(getattr(run,'cases',()))
        has_clo=any(getattr(getattr(case,'result',None),'clo',None) is not None for case in cases)
        fallback='UNAVAILABLE' if has_clo else 'NOT_SELECTED'
        economics=TABLE_PREFIX+'economics'
        if economics in inventory:
            rows={row.get('Economics metric'):row for row in self._table_records(economics)}
            for row,metric in enumerate(('DEBT_TO_COLLATERAL_PAR','DEBT_TO_EQUITY_CASH',
                    'WEIGHTED_FLOATING_DEBT_SPREAD_BPS','ORIGINAL_CONTRACTUAL_COUPON_YIELD',
                    'ORIGINAL_REALIZED_CASH_YIELD','CASH_DEBT_COST','ACCRUED_DEBT_COST',
                    'TOTAL_FEES_PAID','TOTAL_EQUITY_DISTRIBUTIONS'),44):
                lookup=f'MATCH("{metric}",{economics}[Economics metric],0)'
                record=rows.get(metric,{})
                updates[f'E{row}']=FormulaCell(f'IFERROR(INDEX({economics}[Value],{lookup}),"n.a.")',record.get('Value','n.a.'))
                status_cell(f'H{row}',f'IFERROR(INDEX({economics}[Data status],{lookup}),"{fallback}")',record.get('Data status',fallback))
        dashboard=TABLE_PREFIX+'dashboard'
        if dashboard in inventory and 'E54' in cells:
            baseline=getattr(run,'baseline',None)
            existing=getattr(baseline,'clo_opening_state',None) is not None
            if existing:
                record=next((row for row in self._table_records(dashboard) if row.get('Metric')=='Equity IRR'),{})
                lookup=f'MATCH("Equity IRR",{dashboard}[Metric],0)'
                status_cell('H54',f'IFERROR(INDEX({dashboard}[Data status],{lookup}),"UNAVAILABLE")',record.get('Data status','UNAVAILABLE'))
            else:
                status_cell('H54','"NOT_APPLICABLE"','NOT_APPLICABLE')
        scope=TABLE_PREFIX+'view_scope_metrics'
        if scope in inventory:
            selected_scope=str(self.read_scalar(UI_PREFIX+'analysis_scope'))
            records={row.get('Key'):row for row in self._table_records(scope)}
            metrics=('ASSET_COUNT','WAS_BPS','WAL_YEARS','WEIGHTED_AVERAGE_MATURITY_YEARS',
                     'SENIOR_FRACTION','SECURED_FRACTION','PIK_FRACTION','CONSTRUCTION_FRACTION',
                     'SELECTED_RATING_COVERAGE','WARF','WARR','TEST_FACTOR_AVERAGE')
            for row,metric in enumerate(metrics,74):
                lookup=f'MATCH({UI_PREFIX}analysis_scope&"|{metric}",{scope}[Key],0)'
                record=records.get(selected_scope+'|'+metric,{})
                updates[f'E{row}']=FormulaCell(f'IFERROR(INDEX({scope}[Value],{lookup}),"n.a.")',record.get('Value','n.a.'))
                status_cell(f'H{row}',f'IFERROR(INDEX({scope}[Data status],{lookup}),"UNAVAILABLE")',record.get('Data status','UNAVAILABLE'))
        minima=TABLE_PREFIX+'view_coverage_minima'
        if minima in inventory:
            tranche=str(self.read_scalar(UI_PREFIX+'analysis_tranche')) if UI_PREFIX+'analysis_tranche' in self._names() else ''
            record=next((row for row in self._table_records(minima) if row.get('Tranche')==tranche),{})
            for address,field in (('E141','Minimum gate OC headroom'),('M141','Minimum gate IC headroom')):
                if address in cells:
                    lookup=f'MATCH({UI_PREFIX}analysis_tranche,{minima}[Tranche],0)'
                    updates[address]=FormulaCell(f'IFERROR(INDEX({minima}[{field}],{lookup}),"n.a.")',record.get(field,'n.a.'))
        updates.update({'M20':'Full pool / opening snapshot',
                        'B40':'Coverage chart headroom = ratio / minimum - 1. Retired tests are omitted. Distributions exclude the initial investment cashflow.'})
        self.write_cells(sheet,updates)

    def refresh_input_derived_views(self, run: object) -> None:
        """Refresh read-only legal-limit and debt-class catalogues from owners."""
        inventory=self.table_inventory()
        raw_name=TABLE_PREFIX+'limits';view_name=TABLE_PREFIX+'inherited_limits'
        if raw_name in inventory and view_name in inventory:
            headers=inventory[view_name].headers
            raw_rows=[row for row in self._table_records(raw_name) if row.get('Limit ID') not in ('',None)]
            rows=[]
            for ordinal,raw in enumerate(raw_rows,1):
                label=f'INDEX({raw_name}[Limit ID],{ordinal})'
                row={}
                for header in headers:
                    if header=='Owner':row[header]='CLO Assumptions'
                    else:
                        lookup=f'INDEX({raw_name}[{header}],{ordinal})'
                        row[header]=FormulaCell(f'IFERROR(IF({label}="","",{lookup}),"n.a.")',raw.get(header))
                rows.append(row)
            ids={row['Limit ID'] for row in raw_rows}
            request=getattr(getattr(run,'inputs',None),'request',None)
            for spec in getattr(request,'limits',()):
                if spec.limit_id in ids:
                    continue
                source=UI_PREFIX+spec.limit_id.removeprefix('LEGACY_').lower()
                threshold=spec.threshold
                if source in self._names():
                    # This display changes units only; the admitted limit and
                    # its threshold are calculated in the typed Python request.
                    formula=source+('*10000' if spec.metric=='WAS_BPS' else '')
                    threshold=FormulaCell(formula,spec.threshold)
                row={'Limit ID':spec.limit_id,'Metric':spec.metric,
                     'Direction':getattr(spec.direction,'value',spec.direction),'Threshold':threshold,
                     'Enabled':True,'Owner':'CLO Assumptions'}
                rows.append({header:row[header] for header in headers})
            self.write_table(view_name,rows)
            info=self.table_inventory()[view_name]
            left,top,_,_=info.bounds
            formats={}
            for ordinal,row in enumerate(rows,1):
                metric=row['Metric']
                metric=str(metric.cached_value) if isinstance(metric,FormulaCell) else str(metric)
                from .interface_reporting import metric_format
                fmt=metric_format(metric)
                formats[f'{_column(left+headers.index("Threshold"))}{top+ordinal}']=fmt
            self.set_cell_number_formats(info.sheet,formats)
        stack_name=TABLE_PREFIX+'stack';option_name=TABLE_PREFIX+'ui_options_debt_class'
        if stack_name in inventory and option_name in inventory:
            stack=[row for row in self._table_records(stack_name) if row.get('Tranche') not in ('',None)]
            debt=[row for row in stack if str(row.get('Type','')).upper() not in ('EQUITY','RESIDUAL')]
            info=self.write_table(option_name,({'Option':row['Tranche']} for row in debt))
            left,top,_,bottom=info.bounds
            self.define_name(UI_PREFIX+'ui_options_debt_class',info.sheet,_reference((left,top+1,left,bottom)))

    def refresh_limit_summary(self, run: object) -> None:
        """Bind all visible limit fields to the selected saved result rows.

        Limit identifiers belong to the input/results contract. The compact
        summary makes no assumptions about their spelling or enabled count;
        additional rows remain accessible in the complete native result Table.
        """
        name=TABLE_PREFIX+'limit_results'
        if name not in self.table_inventory() or 'CLO Analysis' not in self._sheet_parts():
            return
        records=self._table_records(name)
        selected=str(self.read_scalar(UI_PREFIX+'analysis_case'))
        case=next((item for item in run.cases if getattr(item,'case_id',None)==selected),None)
        portfolio=getattr(getattr(case,'result',None),'opening_portfolio',None)
        if portfolio is None:
            portfolio=getattr(getattr(run,'baseline',None),'opening_portfolio',None)
        units={metric.name:str(metric.unit).lower() for metric in getattr(portfolio,'metrics',())}
        metrics={limit.limit_id:limit.metric for limit in getattr(portfolio,'limits',())}
        from .interface_reporting import metric_format
        def number_format(identity):
            metric=metrics.get(identity,'')
            return metric_format(metric,units.get(metric))
        updates={};formats={}
        for ordinal in range(1,21):
            row=108+ordinal
            record=records[ordinal-1] if ordinal<=len(records) else {}
            identity=record.get('Limit')
            label=f'INDEX({name}[Limit],{ordinal})'
            for column,field in (('B','Limit'),('G','Value'),('J','Threshold'),('L','Headroom'),('N','Result')):
                lookup=f'INDEX({name}[{field}],{ordinal})'
                formula=f'IFERROR(IF({label}="","",{lookup}),"")'
                cache=record.get(field) if identity not in ('',None) else ''
                updates[f'{column}{row}']=FormulaCell(formula,cache)
            for column in ('G','J','L'):
                formats[f'{column}{row}']=number_format(identity)
        self.write_cells('CLO Analysis',updates)
        self.set_cell_number_formats('CLO Analysis',formats)

    def refresh_metric_catalog(self) -> None:
        """Populate the reader dropdown from the completed detail records."""
        detail_name = TABLE_PREFIX+'analysis_details'
        if detail_name not in self.table_inventory():
            return
        rows = self._table_records(detail_name)
        from .interface_reporting import metric_format
        def display_format(row):
            fmt=metric_format(row.get('Metric'),row.get('Unit'))
            # Native TEXT's General token is locale-dependent. Unknown numeric
            # units use a finite decimal fallback; n.a./status text bypasses
            # TEXT in the existing reader formula. Known units reuse exactly
            # the same precision as the saved detail and hidden audit records.
            return '0.###############' if fmt=='General' else fmt
        records = tuple({'Metric':str(row['Group'])+' | '+str(row['Metric']),'Row index':ordinal,
                         'Display format':display_format(row)} for ordinal,row in enumerate(rows,1)
                        if row.get('Metric') not in ('',None))
        if records:
            self.write_table(TABLE_PREFIX+'analysis_options_metric',records)
            selector=UI_PREFIX+'analysis_metric'
            if self.read_scalar(selector) not in {row['Metric'] for row in records}:
                self.write_scalar(selector,records[0]['Metric'])

    def invalidate_chart_caches(self) -> None:
        for part in list(self.parts):
            if "chart" not in part.lower() or not part.endswith(".xml"):
                continue
            tree = self._xml(part)
            if tree.tag != "{" + CHART + "}chartSpace":
                continue
            changed = False
            for parent in tree.iter():
                for child in list(parent):
                    if child.tag in {"{" + CHART + "}" + name for name in ("numCache", "strCache", "multiLvlStrCache")}:
                        parent.remove(child)
                        changed = True
            if changed:
                self._put_xml(part, tree)
        workbook = self._xml("xl/workbook.xml")
        calculation = workbook.find(_tag("calcPr"))
        if calculation is None:
            calculation = ET.SubElement(workbook, _tag("calcPr"))
        calculation.attrib.update(calcMode="auto", fullCalcOnLoad="1", forceFullCalc="1")
        self._put_xml("xl/workbook.xml", workbook)
        chain = "xl/calcChain.xml"
        if chain in self.parts:
            del self.parts[chain]
            rel_part = self._relationship_part("xl/workbook.xml")
            relationships = self._xml(rel_part)
            for item in list(relationships):
                if item.attrib.get("Type", "").endswith("/calcChain"):
                    relationships.remove(item)
            self._put_xml(rel_part, relationships)
            types = self._xml("[Content_Types].xml")
            for item in list(types):
                if item.attrib.get("PartName") == "/" + chain:
                    types.remove(item)
            self._put_xml("[Content_Types].xml", types)

    def _verify_written_archive(self, path: str | Path, *,
                                expected_parts: Mapping[str, bytes] | None = None) -> None:
        """Prove the staged ZIP contains the exact validated in-memory package.

        Reading every entry invokes ZIP CRC checks as well as byte equality;
        duplicate/missing entries, lost metadata and changed payloads reject
        publication. Reconstructing another WorkbookPackage would parse all XML
        a third time despite byte equality to the fully validated package.
        The same proof establishes that an in-place destination still contains
        the initial, fully validated source parts. Any source change is a write
        conflict: a loaded snapshot must never overwrite newer workbook edits.
        """
        parts = self.parts if expected_parts is None else expected_parts
        try:
            with zipfile.ZipFile(path) as archive:
                infos = archive.infolist()
                if tuple(info.filename for info in infos) != tuple(parts):
                    raise InputValidationError("Saved package parts differ from the validated package")
                if archive.comment != self._zip_comment:
                    raise InputValidationError("Saved package comment differs from the source")
                for info in infos:
                    if archive.read(info.filename) != parts[info.filename]:
                        raise InputValidationError(f"Saved package part differs from validated XML: {info.filename}")
                    expected = self._infos.get(info.filename)
                    if expected is not None and any(getattr(info, attribute) != getattr(expected, attribute)
                            for attribute in ("date_time", "compress_type", "comment", "extra", "create_system",
                                              "create_version", "extract_version", "internal_attr", "external_attr")):
                        raise InputValidationError(f"Saved package metadata differs from the source: {info.filename}")
        except (OSError, zipfile.BadZipFile, RuntimeError) as error:
            raise InputValidationError("Cannot verify saved interface package") from error

    def save(self, destination: str | Path, *, overwrite: bool = False) -> Path:
        destination = Path(destination).resolve()
        same_source = destination == self.source
        if destination.exists():
            if not overwrite:
                raise InputValidationError("Output already exists; explicit overwrite is required")
            # A wrong namespace or linked workbook can never be overwritten by
            # an otherwise successful result run. A different destination may
            # have changed independently since this source was loaded.
            if same_source:
                try:
                    self._verify_written_archive(destination, expected_parts=self._original)
                except InputValidationError as error:
                    raise InputValidationError(
                        "Source workbook changed after loading; output was not published. "
                        "Save/close the workbook and rerun from the current inputs.") from error
            else:
                WorkbookPackage(destination, schema_name=self.schema_name)
        self._validate_package()
        self._validate_namespace()
        for part, original in self._market_parts.items():
            if self.parts.get(part) != original:
                raise InputValidationError("Market Data XML changed during output transport")
        destination.parent.mkdir(parents=True, exist_ok=True)
        handle, temporary = tempfile.mkstemp(prefix=".trident-ui-", suffix=".xlsx", dir=destination.parent)
        os.close(handle)
        try:
            with zipfile.ZipFile(temporary, "w", compression=zipfile.ZIP_DEFLATED) as archive:
                archive.comment = self._zip_comment
                for part, data in self.parts.items():
                    info = self._infos.get(part)
                    archive.writestr(info if info is not None else part, data)
            self._verify_written_archive(temporary)
            if same_source:
                # Protect an edit that arrived while XML/ZIP output was built,
                # not only an edit already present at the start of save().
                try:
                    self._verify_written_archive(destination, expected_parts=self._original)
                except InputValidationError as error:
                    raise InputValidationError(
                        "Source workbook changed during output save; output was not published. "
                        "Save/close the workbook and rerun from the current inputs.") from error
            os.replace(temporary, destination)
        finally:
            if os.path.exists(temporary):
                os.unlink(temporary)
        return destination
