"""Opening holdings and frozen quotes → an explicit LP/MILP cash mandate.

Static principal-account research must not spend sale accrued as principal.
Closing-pool redesign instead uses a declared total economic cash budget and
must separately reconstruct acquisition cost and inherited coupon entitlement.
Neither path infers trading cash from a CLO reserve or settles actual trades.
"""

from datetime import date
from decimal import Decimal
from enum import Enum
from typing import Mapping

from trident.analysis import FactorMapping
from trident.application.clo_services import TridentModelResult
from trident.domain.models import InputValidationError, require_date
from trident.optimization import (
    AssetDescriptor, AssetKind, Holding, OptimizationObjective, OptimizationRequest,
    PortfolioLimits, TradeQuote, TradeSide,
)
from .model_records import optional_decimal
from .records import _validate_fields, date_value, decimal_value, text_value


class OptimizationBudgetScope(str, Enum):
    """Adapter permissions; they do not certify a real CLO proceeds account."""

    PRINCIPAL_ACCOUNT = "PRINCIPAL_ACCOUNT"
    CLOSING_ECONOMIC_BUDGET = "CLOSING_ECONOMIC_BUDGET"


TRADE_QUOTE_FIELDS = frozenset({
    "asset_id", "side", "asset_class", "obligor_id", "country_code", "sector", "currency",
    "spread_bps", "factor_bucket", "clean_price_pct", "maximum_par", "accrued_per_par",
    "proportional_fee_per_par", "lot_size", "minimum_ticket", "fixed_fee",
})


def optimization_request_from_records(
    assets: tuple[Mapping[str, object], ...], quotes: tuple[Mapping[str, object], ...],
    controls: Mapping[str, object], mapping: FactorMapping | None, result: TridentModelResult,
    *, budget_scope: OptimizationBudgetScope = OptimizationBudgetScope.PRINCIPAL_ACCOUNT,
) -> OptimizationRequest:
    """Require a completed baseline before creating an executable proposal run.

    Preflight uses the snapshot parser below, with an explicit NOT_RUN scope;
    it cannot fabricate a completed projection to bypass this validation.
    """
    if not isinstance(result, TridentModelResult):
        raise InputValidationError("Optimization execution requires an actual TridentModelResult")
    if result.clo is not None and result.clo.status.value != "COMPLETED":
        raise InputValidationError("Optimization is unavailable for an unresolved CLO baseline")
    return optimization_snapshot_from_records(assets, quotes, controls, mapping,
        opening_date=result.cashflows.projection_start_date, budget_scope=budget_scope)


def optimization_snapshot_from_records(
    assets: tuple[Mapping[str, object], ...], quotes: tuple[Mapping[str, object], ...],
    controls: Mapping[str, object], mapping: FactorMapping | None, *, opening_date: date,
    budget_scope: OptimizationBudgetScope = OptimizationBudgetScope.PRINCIPAL_ACCOUNT,
) -> OptimizationRequest:
    """Validate snapshot data and units without solving or projecting cashflows.

    The fixed target par makes weighted factor/spread inequalities linear.
    Prices are percent of par (99), whereas accrued/fees are EUR per EUR1 par
    (0.02). The domain validates cent par, availability, tickets and lot rules.
    A valid request still needs solver feasibility and independent full replay.
    """
    require_date(opening_date, "optimization opening_date")
    if not isinstance(budget_scope, OptimizationBudgetScope):
        raise InputValidationError("budget_scope must be an explicit OptimizationBudgetScope")
    if mapping is None:
        raise InputValidationError("Optimization requires an explicit versioned factor mapping")
    settlement = date_value(controls["optimizer_settlement_date"], "optimizer_settlement_date")
    if settlement != opening_date:
        raise InputValidationError("Static optimizer settlement must match opening holdings date; future reinvestment requires event-state replay")
    by_id = {}
    holdings = []
    for row in assets:
        bucket = row.get("test_factor_bucket") if mapping.is_synthetic else row.get("rating_bucket") or row.get("agency_rating")
        if bucket not in mapping.factors:
            raise InputValidationError(f"Missing optimization factor: {row.get('loan_id')} / {bucket}")
        asset = AssetDescriptor(text_value(row.get("loan_id"), "loan_id"), AssetKind(row.get("asset_class")),
                                text_value(row.get("obligor_id"), "obligor_id"), text_value(row.get("country_code"), "country_code"),
                                text_value(row.get("sector"), "sector"), decimal_value(row.get("spread_bps"), "spread_bps"), mapping.factors[bucket])
        if row.get("coupon_type") != "FLOATING":
            raise InputValidationError("Static spread optimization requires explicit floating spread for every held asset")
        by_id[asset.asset_id] = asset
        holdings.append(Holding(asset, decimal_value(row.get("current_par"), "current_par")))
    trade_quotes = []
    for row in quotes:
        if not isinstance(row, Mapping):
            raise InputValidationError("Trade Candidates rows must be semantic field mappings")
        _validate_fields(row, TRADE_QUOTE_FIELDS, "Trade Candidates")
        accrued = decimal_value(row.get("accrued_per_par"), "accrued_per_par")
        if accrued != 0 and budget_scope is OptimizationBudgetScope.PRINCIPAL_ACCOUNT:
            raise InputValidationError("CLO principal-budget optimizer currently requires zero accrued; separate interest/principal settlement accounts are not implemented")
        if row.get("currency") != "EUR":
            raise InputValidationError("Trade quotes must be EUR; no implicit FX")
        bucket = text_value(row.get("factor_bucket"), "factor_bucket")
        if bucket not in mapping.factors:
            raise InputValidationError(f"Unmapped candidate factor bucket: {bucket}")
        asset = AssetDescriptor(text_value(row.get("asset_id"), "asset_id"), AssetKind(row.get("asset_class")),
                                text_value(row.get("obligor_id"), "obligor_id"), text_value(row.get("country_code"), "country_code"),
                                text_value(row.get("sector"), "sector"), decimal_value(row.get("spread_bps"), "spread_bps"), mapping.factors[bucket])
        if row.get("side") == "SELL" and by_id.get(asset.asset_id) != asset:
            raise InputValidationError("Sell quote metadata/factor must match the held asset")
        trade_quotes.append(TradeQuote(
            asset=asset, side=TradeSide(row.get("side")), clean_price_pct=decimal_value(row.get("clean_price_pct"), "clean_price_pct"),
            maximum_par=decimal_value(row.get("maximum_par"), "maximum_par"), accrued_per_par=accrued,
            proportional_fee_per_par=decimal_value(row.get("proportional_fee_per_par"), "proportional_fee_per_par"),
            lot_size=optional_decimal(row.get("lot_size"), "lot_size"),
            minimum_ticket=decimal_value(row.get("minimum_ticket"), "minimum_ticket"),
            fixed_fee=decimal_value(row.get("fixed_fee"), "fixed_fee"),
        ))
    # Values are deliberately supplied by the user. No cash is copied from the
    # reserve, interest account, or principal already redeemed through the CLO.
    kwargs = {name: optional_decimal(controls[f"optimizer_{name}"], name) for name in (
        "maximum_obligor_share", "maximum_country_share", "maximum_sector_share", "maximum_bsl_share", "minimum_infra_share",
        "maximum_overall_factor", "maximum_bsl_factor", "minimum_spread_bps", "maximum_trade_par",
    )}
    limits = PortfolioLimits(decimal_value(controls["optimizer_target_par"], "optimizer_target_par"),
                             decimal_value(controls["optimizer_minimum_cash"], "optimizer_minimum_cash"), **kwargs)
    return OptimizationRequest(tuple(holdings), tuple(trade_quotes),
                               decimal_value(controls["optimizer_starting_cash"], "optimizer_starting_cash"), limits,
                               OptimizationObjective(controls["optimizer_objective"]),
                               f"{mapping.system}/{mapping.version}; {'SYNTHETIC_TEST_ONLY' if mapping.is_synthetic else 'USER_SUPPLIED_UNVERIFIED_AGENCY_MAPPING'}",
                               settlement)
