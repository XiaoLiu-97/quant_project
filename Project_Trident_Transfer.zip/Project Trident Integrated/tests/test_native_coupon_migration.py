"""Independent contract migration examples for noncash coupon and O/N forwards.

PIK examples use 30E/360 quarters so the multiplication is hand-checkable.
The two-node O/N example has DF(90d)=1/1.01 and DF(180d)=1/1.04;
its forward factor is exactly 3/101, not either input annual zero rate.
"""

import unittest
from dataclasses import replace
from datetime import date
from decimal import Decimal, Inexact, ROUND_DOWN, localcontext
from fractions import Fraction

from trident.cashflows.coupons import CouponProjector, cashflow_coupon_factor
from trident.cashflows.engine import ContractualCashflowEngine
from trident.conventions.calendar import BusinessDayConvention, CalendarName, WeekendCalendar
from trident.conventions.day_count import DayCount
from trident.conventions.schedule import AccrualDateBasis, ScheduleBuilder
from trident.domain.models import (
    AmortizationType, CouponStep, CouponStepPolicy, CouponType, InterestMode,
    InputValidationError, LoanPosition, LoanTerms, OpeningCouponEntitlement,
    SeasonedLoanState,
    PrincipalScheduleEntry,
)
from trident.market.cash_accounts import CashCurveRateProvider, DiscountFactorCashCurve, ZeroCompounding, ZeroRatePoint
from trident.market.rates import FlatRateProvider

D = Decimal


def fixed_terms(**changes: object) -> LoanTerms:
    """Use identical dates/conventions so changes expose one economic feature."""
    values = dict(loan_id="MIGRATION", currency="EUR", start_date=date(2026, 1, 1),
        maturity_date=date(2027, 1, 1), reference_principal=D(100),
        coupon_type=CouponType.FIXED, fixed_rate=D(".12"), day_count=DayCount.THIRTY_E_360,
        business_day_convention=BusinessDayConvention.UNADJUSTED,
        accrual_date_basis=AccrualDateBasis.UNADJUSTED)
    values.update(changes)
    return LoanTerms(**values)


class NativePikMigrationTests(unittest.TestCase):
    def setUp(self) -> None:
        self.engine = ContractualCashflowEngine(FlatRateProvider({"EURIBOR_3M": D(".025")}))

    def project(self, **changes: object):
        terms = fixed_terms(**changes)
        return self.engine.generate(LoanPosition(terms, terms.start_date, terms.reference_principal))

    def assert_bridges(self, rows, opening=D(100)) -> None:
        for row in rows:
            self.assertEqual(row.opening_balance + row.pik_interest - row.principal_repayment, row.closing_balance)
            self.assertEqual(row.gross_interest, row.cash_interest + row.pik_interest)
            self.assertEqual(row.total_cash, row.cash_interest + row.principal_repayment)
        self.assertEqual(sum(r.principal_repayment - r.pik_interest for r in rows), opening)
        self.assertEqual(rows[-1].closing_balance, 0)

    def test_pik_compounds_and_current_maturity_pik_is_redeemed_once(self) -> None:
        rows = self.project(interest_mode=InterestMode.PIK, pik_fraction=D(1))
        self.assertEqual([r.pik_interest for r in rows], [D("3"), D("3.09"), D("3.18"), D("3.28")])
        self.assertEqual([r.opening_balance for r in rows], [D(100), D(103), D("106.09"), D("109.27")])
        self.assertTrue(all(r.cash_interest == 0 for r in rows))
        self.assertEqual(rows[-1].principal_repayment, D("112.55"))
        self.assertEqual(rows[-1].total_cash, D("112.55"))
        self.assert_bridges(rows)

    def test_mixed_half_coupon_capitalizes_only_one_half(self) -> None:
        rows = self.project(interest_mode=InterestMode.MIXED, pik_fraction=D(".5"))
        self.assertEqual(rows[0].cash_interest, D("1.50"))
        self.assertEqual(rows[0].pik_interest, D("1.50"))
        self.assertEqual(rows[1].opening_balance, D("101.50"))
        self.assertEqual(rows[1].gross_interest, D("3.05"))
        self.assertEqual(rows[1].pik_interest, D("1.52"))
        self.assertEqual(rows[1].cash_interest, D("1.53"))
        self.assert_bridges(rows)

    def test_cent_tie_cash_residual_preserves_one_posted_gross_coupon(self) -> None:
        row, = self.project(maturity_date=date(2026, 4, 1), reference_principal=D(1),
            fixed_rate=D(".06"), interest_mode=InterestMode.MIXED, pik_fraction=D(".5"))
        self.assertEqual(row.gross_interest, D(".02"))  # gross .015 -> .02.
        self.assertEqual(row.pik_interest, D(".01"))
        self.assertEqual(row.cash_interest, D(".01"))
        self.assert_bridges((row,), D(1))

    def test_scheduled_principal_uses_original_reference_not_growing_pik_face(self) -> None:
        rows = self.project(interest_mode=InterestMode.PIK, pik_fraction=D(1),
            amortization_type=AmortizationType.LINEAR_INITIAL_PAR, amortization_fraction=D(".25"))
        self.assertEqual([r.principal_repayment for r in rows[:-1]], [D(25)] * 3)
        self.assertEqual(rows[1].opening_balance, D(78))
        self.assertEqual(rows[-1].principal_repayment, D("32.96"))
        self.assert_bridges(rows)

    def test_automatic_pik_amortization_redemption_sweeps_accreted_face(self) -> None:
        rows = self.project(interest_mode=InterestMode.PIK, pik_fraction=D(1),
            amortization_type=AmortizationType.LINEAR_AUTO, balloon_amount=D(20))
        self.assertEqual([r.principal_repayment for r in rows[:-1]], [D(20)] * 3)
        self.assertGreater(rows[-1].principal_repayment, D(40))
        self.assert_bridges(rows)

    def test_all_non_annuity_pik_schedules_preserve_grace_and_balloon_floor(self) -> None:
        grace = date(2026, 7, 1)
        strategies = [
            dict(amortization_type=AmortizationType.BULLET),
            dict(amortization_type=AmortizationType.LINEAR_INITIAL_PAR, amortization_fraction=D(".25")),
            dict(amortization_type=AmortizationType.LINEAR_AMOUNT, scheduled_principal_amount=D(10)),
            dict(amortization_type=AmortizationType.ACCELERATED, scheduled_principal_amount=D(10), amortization_growth=D(1)),
            dict(amortization_type=AmortizationType.LINEAR_AUTO),
            dict(amortization_type=AmortizationType.ACCELERATED_AUTO, amortization_growth=D(1)),
            dict(amortization_type=AmortizationType.BESPOKE, principal_schedule=(
                PrincipalScheduleEntry(date(2026, 4, 1), D(0)),
                PrincipalScheduleEntry(date(2026, 7, 1), D(20)),
                PrincipalScheduleEntry(date(2026, 10, 1), D(20)),
                PrincipalScheduleEntry(date(2027, 1, 1), D(60)))),
        ]
        for mode, share in ((InterestMode.PIK, D(1)), (InterestMode.MIXED, D(".4"))):
            for strategy in strategies:
                values = dict(strategy)
                if strategy["amortization_type"] is not AmortizationType.BULLET:
                    values.update(amortization_start_date=grace, balloon_amount=D(20))
                with self.subTest(mode=mode, strategy=strategy):
                    rows = self.project(interest_mode=mode, pik_fraction=share, **values)
                    self.assertEqual(rows[0].principal_repayment, 0)
                    self.assertTrue(all(row.closing_balance >= D(20) for row in rows[:-1]))
                    self.assert_bridges(rows)

    def test_bespoke_grace_and_balloon_require_consistent_explicit_amounts(self) -> None:
        schedule = (PrincipalScheduleEntry(date(2026, 4, 1), D(40)),
                    PrincipalScheduleEntry(date(2026, 7, 1), D(40)),
                    PrincipalScheduleEntry(date(2027, 1, 1), D(20)))
        with self.assertRaisesRegex(InputValidationError, "before its explicit amortization start"):
            fixed_terms(amortization_type=AmortizationType.BESPOKE, principal_schedule=schedule,
                amortization_start_date=date(2026, 7, 1))
        with self.assertRaisesRegex(InputValidationError, "balloon floor"):
            self.project(amortization_type=AmortizationType.BESPOKE, principal_schedule=schedule,
                balloon_amount=D(30))

    def test_pik_amount_does_not_depend_on_callers_decimal_context(self) -> None:
        with localcontext() as context:
            context.prec, context.rounding = 2, ROUND_DOWN
            context.traps[Inexact] = True
            rows = self.project(interest_mode=InterestMode.PIK, pik_fraction=D(1))
        self.assertEqual(rows[-1].total_cash, D("112.55"))

    def test_negative_coupon_cannot_reduce_face_as_negative_pik(self) -> None:
        with self.assertRaisesRegex(InputValidationError, "negative PIK"):
            self.project(interest_mode=InterestMode.PIK, pik_fraction=D(1), fixed_rate=D("-.01"))

    def test_pik_requires_explicit_valid_share_and_cash_annuity(self) -> None:
        for values in [dict(interest_mode="PIK"), dict(interest_mode=InterestMode.PIK),
            dict(interest_mode=InterestMode.CASH, pik_fraction=D(".1")),
            dict(interest_mode=InterestMode.MIXED, pik_fraction=D(0)),
            dict(interest_mode=InterestMode.MIXED, pik_fraction=D(1)),
            dict(interest_mode=InterestMode.MIXED, pik_fraction=.5),
            dict(interest_mode=InterestMode.PIK, pik_fraction=D("1.01")),
            dict(interest_mode=InterestMode.PIK, pik_fraction=D(1),
                 amortization_type=AmortizationType.ANNUITY, balloon_amount=D(0))]:
            with self.subTest(values=values), self.assertRaises(InputValidationError):
                fixed_terms(**values)

    def test_verified_historical_pik_opening_can_exceed_original_reference(self) -> None:
        terms = fixed_terms(interest_mode=InterestMode.PIK, pik_fraction=D(1))
        state = SeasonedLoanState(D(0), "Agent statement: capitalized face 106.09",
            entitlement_policy=OpeningCouponEntitlement.POST_ASOF_ONLY)
        rows = self.engine.generate(LoanPosition(terms, date(2026, 7, 1), D("106.09"), state))
        self.assertEqual(rows[-1].total_cash, D("112.55"))
        self.assert_bridges(rows, D("106.09"))

    def test_cash_claim_at_seasoned_opening_is_not_capitalized_again(self) -> None:
        terms = fixed_terms(day_count=DayCount.ACT_360, interest_mode=InterestMode.PIK, pik_fraction=D(1))
        state = SeasonedLoanState(D(2), "Verified historical cash claim",
            entitlement_policy=OpeningCouponEntitlement.EXPLICIT_CASH_CLAIM)
        rows = self.engine.generate(LoanPosition(terms, date(2026, 2, 1), D(100), state))
        self.assertEqual(rows[0].pik_interest, D("1.97"))  # forward 59 days.
        self.assertEqual(rows[0].cash_interest, D(2))
        self.assertEqual(rows[1].cash_interest, 0)

    def test_nonzero_historical_pik_entitlement_requires_explicit_state(self) -> None:
        terms = fixed_terms(interest_mode=InterestMode.PIK, pik_fraction=D(1))
        with self.assertRaisesRegex(InputValidationError, "historical uncapitalized PIK"):
            LoanPosition(terms, date(2026, 2, 1), D(100), SeasonedLoanState(D(1), "Agent"))

    def test_zero_posted_pik_still_retains_contractual_interest_mode(self) -> None:
        row, = self.project(maturity_date=date(2026, 4, 1), reference_principal=D(".01"),
            fixed_rate=D(".01"), interest_mode=InterestMode.PIK, pik_fraction=D(1))
        self.assertEqual(row.pik_interest, 0)
        self.assertEqual(row.interest_mode, InterestMode.PIK)
        self.assertEqual(row.pik_fraction, 1)
        self.assertEqual(row.total_cash, D(".01"))

    def test_payment_lag_does_not_accrue_pik_after_nominal_maturity(self) -> None:
        row, = self.project(maturity_date=date(2026, 4, 1), payment_lag_business_days=2,
            interest_mode=InterestMode.PIK, pik_fraction=D(1))
        self.assertEqual(row.accrual_end, date(2026, 4, 1))
        self.assertEqual(row.payment_date, date(2026, 4, 7))
        self.assertEqual(row.pik_interest, D(3))
        self.assertEqual(row.total_cash, D(103))

    def test_dated_pik_fixed_steps_keep_existing_contract_entitlement(self) -> None:
        rows = self.project(day_count=DayCount.ACT_360, interest_mode=InterestMode.PIK, pik_fraction=D(1),
            maturity_date=date(2026, 4, 1), coupon_steps=(CouponStep(date(2026, 2, 1), fixed_rate=D(".24")),))
        self.assertEqual(rows[0].pik_interest, D("4.97"))  # 100*(.12*31+.24*59)/360.
        self.assertEqual(rows[0].principal_repayment, D("104.97"))

    def test_per_loan_calendar_and_explicit_api_calendar_precedence(self) -> None:
        terms = fixed_terms(start_date=date(2026, 7, 12), maturity_date=date(2026, 10, 12),
            business_day_convention=BusinessDayConvention.FOLLOWING,
            accrual_date_basis=AccrualDateBasis.ADJUSTED, holiday_calendar=CalendarName.NEW_YORK)
        row, = self.engine.generate(LoanPosition(terms, terms.start_date, D(100)))
        self.assertEqual(row.payment_date, date(2026, 10, 13))  # Federal Columbus Day.
        row, = ContractualCashflowEngine(self.engine._rate_provider, WeekendCalendar()).generate(
            LoanPosition(terms, terms.start_date, D(100)))
        self.assertEqual(row.payment_date, date(2026, 10, 12))


class NativeOvernightMigrationTests(unittest.TestCase):
    def provider(self, index="ESTR"):
        curve = DiscountFactorCashCurve(index, date(2026, 1, 1),
            (ZeroRatePoint(D(".25"), D(".04")), ZeroRatePoint(D(".5"), D(".08"))),
            ZeroCompounding.SIMPLE, DayCount.ACT_360)
        return CashCurveRateProvider(FlatRateProvider({"EURIBOR_3M": D(".025")}), {index: curve})

    def terms(self, **changes):
        return fixed_terms(start_date=date(2026, 4, 1), maturity_date=date(2026, 6, 30),
            reference_principal=D(10100), coupon_type=CouponType.FLOATING, fixed_rate=None,
            rate_index="ESTR", day_count=DayCount.ACT_360, **changes)

    def test_two_node_forward_compounding_matches_independent_300_coupon(self) -> None:
        terms = self.terms()
        row, = ContractualCashflowEngine(self.provider()).generate(LoanPosition(terms, terms.start_date, D(10100)))
        self.assertEqual(row.cash_interest, D(300))
        self.assertEqual(row.total_cash, D(10400))
        self.assertIsNotNone(row.coupon_segments[0].exact_factor)
        self.assertEqual(row.fixing_date, terms.start_date)  # no lagged term observation.

    def test_spread_is_added_outside_compounding(self) -> None:
        terms = self.terms(spread_bps=D(100))
        row, = ContractualCashflowEngine(self.provider()).generate(LoanPosition(terms, terms.start_date, D(10100)))
        self.assertEqual(row.cash_interest, D("325.25"))  # 300+10100*.01*.25.

    def test_reference_floor_before_spread_and_all_in_cap_after_spread(self) -> None:
        terms = self.terms(index_floor=D(".20"), spread_bps=D(100), all_in_cap=D(".15"))
        row, = ContractualCashflowEngine(self.provider()).generate(LoanPosition(terms, terms.start_date, D(10100)))
        self.assertEqual(row.cash_interest, D("378.75"))  # 10100*.15*.25.

    def test_exact_step_spread_does_not_recompound_the_reference(self) -> None:
        terms = self.terms(spread_bps=D(100), coupon_steps=(CouponStep(date(2026, 5, 1), spread_bps=D(200)),))
        row, = ContractualCashflowEngine(self.provider()).generate(LoanPosition(terms, terms.start_date, D(10100)))
        self.assertEqual(row.cash_interest, D("342.08"))  # 300+10100*(.01*30+.02*60)/360.
        self.assertEqual(len(row.coupon_segments), 2)

    def test_reset_start_steps_wait_for_next_payment_period(self) -> None:
        terms = self.terms(spread_bps=D(100), coupon_step_policy=CouponStepPolicy.RESET_START,
            coupon_steps=(CouponStep(date(2026, 5, 1), spread_bps=D(200)),))
        row, = ContractualCashflowEngine(self.provider()).generate(LoanPosition(terms, terms.start_date, D(10100)))
        self.assertEqual(row.cash_interest, D("325.25"))

    def test_overnight_frozen_replay_keeps_exact_factor(self) -> None:
        terms = self.terms()
        row, = ContractualCashflowEngine(self.provider()).generate(LoanPosition(terms, terms.start_date, D(10100)))
        calendar = WeekendCalendar()
        periods = ScheduleBuilder(calendar).build(terms.start_date, terms.maturity_date, terms.frequency_months,
            business_day_convention=terms.business_day_convention, accrual_date_basis=terms.accrual_date_basis)
        coupon = CouponProjector(terms, periods, calendar).project(periods[0], row.coupon_segments)
        self.assertEqual(coupon.exact_factor, row.coupon_segments[0].exact_factor)
        self.assertEqual(cashflow_coupon_factor(row, terms.day_count, date(2026, 5, 1)), coupon.exact_factor / 3)
        bad = (replace(row.coupon_segments[0], exact_factor=Fraction(1)),)
        with self.assertRaisesRegex(InputValidationError, "frozen factor differs"):
            CouponProjector(terms, periods, calendar).project(periods[0], bad)

    def test_projected_overnight_pik_preserves_terminal_par_and_cash(self) -> None:
        terms = self.terms(interest_mode=InterestMode.PIK, pik_fraction=D(1))
        row, = ContractualCashflowEngine(self.provider()).generate(LoanPosition(terms, terms.start_date, D(10100)))
        self.assertEqual(row.cash_interest, 0)
        self.assertEqual(row.pik_interest, D(300))
        self.assertEqual(row.principal_repayment, D(10400))
        self.assertEqual(row.total_cash, D(10400))

    def test_no_zero_curve_cannot_fall_back_to_term_rate(self) -> None:
        terms = self.terms()
        with self.assertRaisesRegex(InputValidationError, "discount-factor curve provider"):
            ContractualCashflowEngine(FlatRateProvider({"ESTR": D(".04")})).generate(
                LoanPosition(terms, terms.start_date, D(10100)))

    def test_currency_basis_and_reset_type_are_explicit(self) -> None:
        for changes in (dict(currency="USD"), dict(day_count=DayCount.ACT_365F),
                        dict(reset_frequency_months=1), dict(rate_index="SOFR")):
            values = dict(start_date=date(2026, 4, 1), maturity_date=date(2026, 6, 30),
                coupon_type=CouponType.FLOATING, fixed_rate=None, rate_index="ESTR", day_count=DayCount.ACT_360)
            values.update(changes)
            with self.subTest(changes=changes), self.assertRaises(InputValidationError):
                fixed_terms(**values)

    def test_all_three_currency_matched_overnight_indices(self) -> None:
        for index, currency, day_count in [("ESTR", "EUR", DayCount.ACT_360),
                ("SOFR", "USD", DayCount.ACT_360), ("SONIA", "GBP", DayCount.ACT_365F)]:
            with self.subTest(index=index):
                terms = fixed_terms(start_date=date(2026, 4, 1), maturity_date=date(2026, 6, 30),
                    reference_principal=D(10100), coupon_type=CouponType.FLOATING, fixed_rate=None,
                    rate_index=index, currency=currency, day_count=day_count)
                row, = ContractualCashflowEngine(self.provider(index)).generate(LoanPosition(terms, terms.start_date, D(10100)))
                self.assertEqual(row.cash_interest, D(300))  # curve basis separate from coupon basis.

    def test_annual_overnight_payment_is_not_restricted_by_euribor_tenors(self) -> None:
        terms = fixed_terms(coupon_type=CouponType.FLOATING, fixed_rate=None, rate_index="SONIA",
            currency="GBP", day_count=DayCount.ACT_365F, frequency_months=12)
        self.assertEqual(terms.frequency_months, 12)

    def test_overnight_mixed_cent_split_is_context_independent(self) -> None:
        terms = self.terms(interest_mode=InterestMode.MIXED, pik_fraction=D(".375"), spread_bps=D(100))
        with localcontext() as caller:
            caller.prec, caller.rounding = 2, ROUND_DOWN
            caller.traps[Inexact] = True
            row, = ContractualCashflowEngine(self.provider()).generate(LoanPosition(terms, terms.start_date, D(10100)))
        self.assertEqual(row.gross_interest, D("325.25"))
        self.assertEqual(row.pik_interest, D("121.97"))
        self.assertEqual(row.cash_interest, D("203.28"))
        self.assertEqual(row.principal_repayment, D("10221.97"))

    def test_overnight_frozen_missing_exact_factor_rejects_display_proxy(self) -> None:
        terms = self.terms()
        row, = ContractualCashflowEngine(self.provider()).generate(LoanPosition(terms, terms.start_date, D(10100)))
        calendar = WeekendCalendar()
        periods = ScheduleBuilder(calendar).build(terms.start_date, terms.maturity_date, terms.frequency_months,
            business_day_convention=terms.business_day_convention, accrual_date_basis=terms.accrual_date_basis)
        segment = replace(row.coupon_segments[0], exact_factor=None, exact_index_factor=None)
        with self.assertRaisesRegex(InputValidationError, "original exact frozen factors"):
            CouponProjector(terms, periods, calendar).project(periods[0], (segment,))


if __name__ == "__main__":
    unittest.main()
