"""Forward what-if projections from an unchanged, sourced CLO opening state.

This service changes future fee, coupon and coverage assumptions. It neither
reissues debt nor buys/sells collateral. Holding/face edits require an explicit
counterfactual equity valuation and source for the complete changed snapshot.
Opening cash, unpaid claims, original schedules and principal permissions are
retained; each case is an independent projection from the same snapshot.
"""

from dataclasses import replace
from fractions import Fraction
from types import MappingProxyType

from trident.cashflows.seasoned import build_position_schedule, resize_seasoned_state
from trident.clo.models import InterestDiversionMode, ManagementFeeBasis, PrincipalRepaymentMode
from trident.conventions import DayCount
from trident.conventions.calendar import calendar_from_name
from trident.domain.models import CouponType, InputValidationError, OpeningCouponEntitlement, require_money
from trident.domain.numeric import post_currency

from .clo_services import ModelProjectionRunner, TridentModelRequest, TridentModelService
from .scenarios import (
    ScenarioBatchResult, ScenarioDefinition, ScenarioExecutionError, ScenarioResult,
    ScenarioTarget, compare_model_results, resize_principal_schedule,
)


# Explicit transport capabilities, shared by readers and callers. Unsupported
# edits fail even when a closing-only input would have no effect on this run.
OPENING_SCENARIO_FIELDS = MappingProxyType({
    ScenarioTarget.ASSET: frozenset({
        "par", "spread_bps", "fixed_rate", "index_floor", "index_cap", "all_in_floor", "all_in_cap",
    }),
    ScenarioTarget.NOTE: frozenset({
        "par", "spread_bps", "fixed_rate", "index_floor", "oc_minimum", "ic_minimum",
    }),
    ScenarioTarget.CONTROL: frozenset({
        "senior_management_fee_bps", "subordinated_management_fee_bps", "annual_senior_expenses",
        "variable_senior_expenses_bps", "senior_expense_cap_bps", "annual_senior_expense_cap",
        "coverage_tests_enabled", "interest_diversion_enabled", "include_principal_cash_in_oc",
        "principal_repayment_mode", "interest_diversion_mode", "management_fee_basis",
        "management_fee_day_count", "senior_expenses_day_count",
        "forward_equity_value", "equity_value_source",
    }),
})


def apply_opening_scenario(baseline: TridentModelRequest, scenario: ScenarioDefinition) -> TridentModelRequest:
    """Build a future-assumption request without removing any opening evidence.

    FULL_CURRENT_PERIOD asset entitlement retains its historical rate/fixings;
    rebinding that contract would rewrite an earned coupon prefix. Such edits
    require a separately verified future dated contract and fail here.
    """
    if not isinstance(baseline, TridentModelRequest):
        raise TypeError("baseline must be TridentModelRequest")
    if baseline.clo_opening_state is None:
        raise InputValidationError("Opening scenarios require an existing CLO opening state")
    if not isinstance(scenario, ScenarioDefinition):
        raise InputValidationError("scenario must be ScenarioDefinition")
    positions = {row.terms.loan_id: row for row in baseline.cashflow_request.positions}
    exposures = {row.loan_id: row for row in baseline.exposures}
    notes = {row.class_id: row for row in baseline.notes}
    purchases = {row.loan_id: row for row in baseline.cashflow_request.purchases}
    issues = {row.class_id: row for row in baseline.cashflow_request.issues}
    asset_changes: dict[str, dict[str, object]] = {}
    note_changes: dict[str, dict[str, object]] = {}
    term_changes: dict[str, object] = {}
    valuation_changes: dict[str, object] = {}
    resized = any(edit.target in {ScenarioTarget.ASSET, ScenarioTarget.NOTE} and edit.field == "par"
                  for edit in scenario.edits)
    declared = {edit.field for edit in scenario.edits if edit.target is ScenarioTarget.CONTROL}
    if resized and not {"forward_equity_value", "equity_value_source"} <= declared:
        raise InputValidationError("Opening holding/face resizing requires explicit forward_equity_value and equity_value_source for the counterfactual snapshot")
    if bool("forward_equity_value" in declared) != bool("equity_value_source" in declared):
        raise InputValidationError("Opening forward_equity_value and equity_value_source must be declared together")
    enums = {
        "principal_repayment_mode": PrincipalRepaymentMode,
        "interest_diversion_mode": InterestDiversionMode,
        "management_fee_basis": ManagementFeeBasis,
        "management_fee_day_count": DayCount,
        "senior_expenses_day_count": DayCount,
    }
    for edit in scenario.edits:
        key, field, value = edit.identifier, edit.field, edit.value
        if field not in OPENING_SCENARIO_FIELDS[edit.target]:
            reason = "only explicit holding/face, equity valuation, forward fee, coupon and coverage assumptions are supported; closing economics and schedule anchors remain unchanged"
            raise InputValidationError(f"Opening {edit.target.value} {field} is unsupported: {reason}")
        if edit.target is ScenarioTarget.ASSET:
            if key not in positions or key not in exposures or key not in purchases:
                raise InputValidationError(f"Unknown or unreconciled opening asset identifier: {key}")
            position = positions[key]
            if (field != "par" and position.seasoned_state is not None
                    and position.seasoned_state.entitlement_policy is OpeningCouponEntitlement.FULL_CURRENT_PERIOD):
                schedule = build_position_schedule(position, calendar_from_name(position.terms.holiday_calendar))
                original = schedule.contractual_periods[schedule.original_indices[0]]
                if position.par_as_of_date != original.accrual_start or position.seasoned_state.opening_accrued_interest != 0:
                    raise InputValidationError(
                        f"Asset {key}: FULL_CURRENT_PERIOD historical coupon entitlement cannot be repriced; "
                        "a verified future dated contract is required"
                    )
            if field not in {"par", "fixed_rate"} and position.terms.coupon_type is not CouponType.FLOATING:
                raise InputValidationError(f"Asset {key}: {field} requires a floating coupon")
            if field == "fixed_rate" and position.terms.coupon_type is not CouponType.FIXED:
                raise InputValidationError(f"Asset {key}: fixed_rate requires a fixed coupon")
            if field == "par":
                require_money(value, "Opening scenario asset par", positive=True)
                if any(row.loan_id == key for row in baseline.coupon_proceeds_allocations):
                    raise InputValidationError(f"Asset {key}: resizing requires refreshed principal-accrued balance and receipt-specific coupon proceeds instructions")
            asset_changes.setdefault(key, {})[field] = value
        elif edit.target is ScenarioTarget.NOTE:
            if key not in notes:
                raise InputValidationError(f"Unknown opening note identifier: {key}")
            note = notes[key]
            if field in {"spread_bps", "index_floor"} and note.coupon_type is not CouponType.FLOATING:
                raise InputValidationError(f"Note {key}: {field} requires a floating coupon")
            if field == "fixed_rate" and note.coupon_type is not CouponType.FIXED:
                raise InputValidationError(f"Note {key}: fixed_rate requires a fixed coupon")
            if field == "par":
                require_money(value, "Opening scenario note par", positive=True)
                if key not in issues:
                    raise InputValidationError(f"Note {key}: resizing a zero-face retained claim requires explicit new capital metadata")
            note_changes.setdefault(key, {})[field] = value
        else:
            if field in {"forward_equity_value", "equity_value_source"}:
                valuation_changes[field] = value
            else:
                term_changes[field] = enums[field](value) if field in enums else value
    # Validate final conditions once, so a simultaneous collar or cap change
    # cannot be rejected merely because one old endpoint was still in place.
    for key, changes in asset_changes.items():
        position = positions[key]
        changes = dict(changes)
        new_par = changes.pop("par", position.opening_balance)
        if new_par != position.opening_balance:
            ratio = Fraction(new_par) / Fraction(position.opening_balance)
            contract = position.terms
            amounts = {name: post_currency(Fraction(getattr(contract, name)) * ratio)
                       for name in ("reference_principal", "scheduled_principal_amount", "balloon_amount")
                       if getattr(contract, name) is not None}
            amounts["principal_schedule"] = resize_principal_schedule(contract.principal_schedule, ratio, new_par)
            position = replace(position, opening_balance=new_par,
                terms=replace(contract, **amounts), seasoned_state=resize_seasoned_state(position, ratio))
            purchases[key] = replace(purchases[key], par=new_par,
                accrued_interest=post_currency(Fraction(purchases[key].accrued_interest) * ratio))
            exposures[key] = replace(exposures[key], par=new_par)
        positions[key] = replace(position, terms=replace(position.terms, **changes))
        quality = {}
        if "spread_bps" in changes:
            quality["spread_bps"] = changes["spread_bps"]
        if "fixed_rate" in changes:
            quality.update(coupon_type=CouponType.FIXED, fixed_coupon_rate=changes["fixed_rate"])
        if quality:
            exposures[key] = replace(exposures[key], **quality)
    for key, changes in note_changes.items():
        changes = dict(changes)
        if "par" in changes:
            new_par = changes.pop("par")
            notes[key] = replace(notes[key], opening_balance=new_par)
            issues[key] = replace(issues[key], par=new_par)
        notes[key] = replace(notes[key], **changes)
    return replace(baseline,
        cashflow_request=replace(baseline.cashflow_request,
            positions=tuple(positions[row.terms.loan_id] for row in baseline.cashflow_request.positions),
            purchases=tuple(purchases[row.loan_id] for row in baseline.cashflow_request.purchases),
            issues=tuple(issues[row.class_id] for row in baseline.cashflow_request.issues)),
        exposures=tuple(exposures[row.loan_id] for row in baseline.exposures),
        notes=tuple(notes[row.class_id] for row in baseline.notes),
        clo_terms=replace(baseline.clo_terms, **term_changes) if term_changes else baseline.clo_terms,
        **valuation_changes,
    )


class StaticOpeningScenarioService:
    """Run independent lifetime projections from one unchanged opening state.

    Validate every case before projecting anything. Failure identifies its
    case and aborts the batch; callers publish only complete results.
    """

    def __init__(self, service: ModelProjectionRunner | None = None) -> None:
        self._service = service if service is not None else TridentModelService()

    def run(self, baseline: TridentModelRequest, scenarios: tuple[ScenarioDefinition, ...]) -> ScenarioBatchResult:
        if not isinstance(baseline, TridentModelRequest):
            raise TypeError("baseline must be TridentModelRequest")
        if baseline.clo_opening_state is None:
            raise InputValidationError("Opening scenarios require an existing CLO opening state")
        if not isinstance(scenarios, tuple) or any(not isinstance(row, ScenarioDefinition) for row in scenarios):
            raise InputValidationError("scenarios must be an immutable tuple of ScenarioDefinition")
        if len({row.scenario_id.casefold() for row in scenarios}) != len(scenarios):
            raise InputValidationError("Scenario names must be unique, ignoring case")
        requests = []
        for scenario in scenarios:
            try:
                requests.append(apply_opening_scenario(baseline, scenario))
            except (ValueError, ArithmeticError) as exc:
                raise ScenarioExecutionError(scenario.scenario_id, str(exc)) from exc
        baseline_result = self._service.run(baseline)
        results = []
        for scenario, request in zip(scenarios, requests, strict=True):
            try:
                result = self._service.run(request)
                comparisons, periods = compare_model_results(scenario.scenario_id, baseline, baseline_result, request, result)
            except (ValueError, ArithmeticError) as exc:
                raise ScenarioExecutionError(scenario.scenario_id, str(exc)) from exc
            results.append(ScenarioResult(scenario.scenario_id, request, result, comparisons, periods))
        return ScenarioBatchResult(baseline_result, tuple(results))
