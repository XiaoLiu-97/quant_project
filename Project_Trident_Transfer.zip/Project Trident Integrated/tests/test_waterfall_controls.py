"""Hand-sized independent ledgers for explicit waterfall policies and fixes."""

import unittest
from dataclasses import replace
from datetime import date
from decimal import Decimal, Inexact, localcontext
from fractions import Fraction

from trident.clo import (
    CloRunRequest, CloTerms, CoverageStatus, DeterministicCloEngine,
    InterestDiversionMode, ManagementFeeBasis, NoteTranche, PrincipalRepaymentMode,
    ProjectionStatus, RecurringSeniorExpense, report_tranche_periods,
)
from trident.conventions import DayCount, StubConvention, ScheduleBuilder, TargetCalendar
from trident.domain.models import CouponType, InputValidationError
from trident.market.rates import FlatRateProvider
from test_clo import CLOSE, FIRST, SECOND, note, receipt, run


D = Decimal


class WaterfallControlsTests(unittest.TestCase):
    def test_disabled_coverage_keeps_ratios_but_never_diverts(self) -> None:
        projection = run(
            (receipt("L", 1, CLOSE, FIRST, "100", "100", "5"),),
            (note("A", 1, "80", "0.04", oc_minimum=D("2")), note("B", 2, "20", "0.04")),
            coverage_tests_enabled=False,
        )
        self.assertFalse(projection.periods[0].coverage_failed)
        self.assertEqual(projection.periods[0].debt_principal_from_interest, D(0))
        gate = projection.coverage_tests[0]
        self.assertEqual(gate.oc_ratio, D("1.25"))
        self.assertIs(gate.oc_status, CoverageStatus.NOT_CONFIGURED)
        self.assertIsNone(gate.oc_minimum)

    def test_disabled_diversion_blocks_junior_and_keeps_cash_until_terminal(self) -> None:
        projection = run(
            (receipt("L", 1, CLOSE, FIRST, "100", "0.20", "40"),
             receipt("L", 2, FIRST, SECOND, "99.80", "99.80", "5")),
            (note("A", 1, "80", "0.04", oc_minimum=D("1.5")), note("B", 2, "20", "0.04")),
            interest_diversion_enabled=False,
        )
        first = projection.periods[0]
        self.assertEqual(first.closing_interest_cash, D("39.20"))
        self.assertEqual(first.debt_principal_from_interest, D(0))
        self.assertEqual(projection.tranche_periods[1].coupon_paid_from_principal, D("0.20"))
        self.assertTrue(projection.tranche_periods[1].interest_gate_blocked)
        self.assertFalse(any(test.stage == "POST_DIVERSION" for test in projection.coverage_tests))
        report_tranche_periods(projection)

    def test_minimum_oc_cure_rounds_up_and_resumes_junior_coupon(self) -> None:
        projection = run(
            (receipt("L", 1, CLOSE, FIRST, "100", "0", "40"),
             receipt("L", 2, FIRST, SECOND, "100", "100", "5")),
            (note("A", 1, "80", "0.04", oc_minimum=D("1.5")), note("B", 2, "20", "0.04")),
            interest_diversion_mode=InterestDiversionMode.CURE_OC_AND_CONTINUE,
        )
        first = projection.periods[0]
        # 80 -100/1.5 =13.333...; executable cure 13.34, remaining
        # interest 40 -.80 -13.34 -.20 =25.66 is paid to equity.
        self.assertEqual(first.debt_principal_from_interest, D("13.34"))
        self.assertEqual(first.equity_from_interest, D("25.66"))
        self.assertEqual(projection.tranche_periods[1].coupon_paid_from_interest, D("0.20"))
        self.assertFalse(projection.tranche_periods[1].interest_gate_blocked)
        self.assertTrue(first.coverage_failed)  # records the ORIGINAL failed gate
        rows = report_tranche_periods(projection)
        self.assertIs(rows[0].gate_oc_status, CoverageStatus.FAIL)
        self.assertIs(rows[0].post_diversion_oc_status, CoverageStatus.PASS)
        self.assertTrue(rows[1].gate_evaluated)

    def test_insufficient_oc_cure_cash_still_blocks_junior(self) -> None:
        projection = run(
            (receipt("L", 1, CLOSE, FIRST, "100", "1", "5"),
             receipt("L", 2, FIRST, SECOND, "99", "99", "5")),
            (note("A", 1, "80", "0.04", oc_minimum=D("1.5")), note("B", 2, "20", "0.04")),
            interest_diversion_mode=InterestDiversionMode.CURE_OC_AND_CONTINUE,
        )
        self.assertEqual(projection.periods[0].debt_principal_from_interest, D("4.20"))
        self.assertTrue(projection.tranche_periods[1].interest_gate_blocked)
        self.assertEqual(projection.tranche_periods[1].coupon_paid_from_principal, D("0.20"))

    def test_ic_failure_retains_opening_dues_and_all_residual_diversion(self) -> None:
        projection = run(
            (receipt("L", 1, CLOSE, FIRST, "100", "1", "1"),
             receipt("L", 2, FIRST, SECOND, "99", "99", "5")),
            (note("A", 1, "80", "0.04", ic_minimum=D("1.3")), note("B", 2, "20", "0.04")),
            interest_diversion_mode=InterestDiversionMode.CURE_OC_AND_CONTINUE,
        )
        self.assertEqual(projection.periods[0].debt_principal_from_interest, D("0.20"))
        row = report_tranche_periods(projection)[0]
        self.assertEqual(row.gate_ic_denominator, D("0.80"))
        self.assertEqual(row.post_diversion_ic_denominator, D("0.80"))
        self.assertIs(row.post_diversion_ic_status, CoverageStatus.FAIL)

    def test_multiple_successful_cures_have_unique_post_diversion_reports(self) -> None:
        projection = run(
            (receipt("L", 1, CLOSE, FIRST, "100", "0", "50"),
             receipt("L", 2, FIRST, SECOND, "100", "100", "5")),
            (note("A", 1, "80", "0.04", oc_minimum=D("1.5")),
             note("B", 2, "20", "0.04", oc_minimum=D("1.4"))),
            interest_diversion_mode=InterestDiversionMode.CURE_OC_AND_CONTINUE,
        )
        # First A cure13.34; through-B balance86.66 requires another15.24.
        self.assertEqual(projection.periods[0].debt_principal_from_interest, D("28.58"))
        post = [test for test in projection.coverage_tests if test.period_number == 1 and test.stage == "POST_DIVERSION"]
        self.assertEqual(len(post), 2)
        report_tranche_periods(projection)

    def test_pro_rata_principal_and_cents_tie_to_seniority(self) -> None:
        projection = run(
            (receipt("L", 1, CLOSE, FIRST, "100", "0.01", "0"),
             receipt("L", 2, FIRST, SECOND, "99.99", "99.99", "0")),
            (note("A", 1, "50"), note("B", 2, "50")),
            principal_repayment_mode=PrincipalRepaymentMode.PRO_RATA,
        )
        a, b = projection.tranche_periods[:2]
        self.assertEqual(a.principal_from_principal, D("0.01"))
        self.assertEqual(b.principal_from_principal, D(0))
        self.assertEqual(projection.status, ProjectionStatus.COMPLETED)
        report_tranche_periods(projection)

    def test_pro_rata_and_sequential_have_distinct_normal_principal_paths(self) -> None:
        rows = (receipt("L", 1, CLOSE, FIRST, "100", "30", "0"),
                receipt("L", 2, FIRST, SECOND, "70", "70", "0"))
        notes = (note("A", 1, "80"), note("B", 2, "20"))
        pro = run(rows, notes, principal_repayment_mode=PrincipalRepaymentMode.PRO_RATA)
        seq = run(rows, notes)
        self.assertEqual([row.closing_balance for row in pro.tranche_periods[:2]], [D("56"), D("14")])
        self.assertEqual([row.closing_balance for row in seq.tranche_periods[:2]], [D("50"), D("20")])

    def test_coverage_cure_is_sequential_even_with_pro_rata_normal_redemption(self) -> None:
        projection = run(
            (receipt("L", 1, CLOSE, FIRST, "100", "10", "40"),
             receipt("L", 2, FIRST, SECOND, "90", "90", "5")),
            (note("A", 1, "80", "0.04", oc_minimum=D("1.5")), note("B", 2, "20", "0.04")),
            principal_repayment_mode=PrincipalRepaymentMode.PRO_RATA,
        )
        a, b = projection.tranche_periods[:2]
        self.assertEqual(a.principal_from_interest, D("39.20"))
        self.assertEqual(b.principal_from_interest, D(0))
        self.assertEqual(a.principal_from_principal + b.principal_from_principal, D("9.80"))

    def test_include_principal_cash_in_oc_is_explicit(self) -> None:
        rows = (receipt("L", 1, CLOSE, FIRST, "100", "100", "5"),)
        notes = (note(par="80", oc_minimum=D("1.25")),)
        included = run(rows, notes)
        excluded = run(rows, notes, include_principal_cash_in_oc=False)
        self.assertEqual(included.coverage_tests[0].oc_numerator, D("100"))
        self.assertEqual(excluded.coverage_tests[0].oc_numerator, D(0))
        self.assertIs(excluded.coverage_tests[0].oc_status, CoverageStatus.FAIL)

    def test_four_fee_bases_are_distinct_and_exact(self) -> None:
        mid = date(2026, 2, 19)
        rows = (receipt("L", 1, CLOSE, mid, "100", "40", "0"),
                receipt("L", 2, mid, FIRST, "60", "60", "5"))
        expected = {
            ManagementFeeBasis.TIME_WEIGHTED_PERFORMING_PAR: D("0.66"),
            ManagementFeeBasis.OPENING_PERFORMING_PAR: D("0.90"),
            ManagementFeeBasis.CLOSING_PERFORMING_PAR: D(0),
            ManagementFeeBasis.INITIAL_COLLATERAL_PAR: D("0.90"),
        }
        for basis, fee in expected.items():
            with self.subTest(basis=basis):
                projection = run(rows, (note(par="50"),), senior_management_fee_bps=D("360"), management_fee_basis=basis)
                self.assertEqual(projection.periods[0].senior_management_fee_due, fee)

    def test_management_fee_day_count_independent_of_coupon_day_count(self) -> None:
        projection = run((receipt("L", 1, CLOSE, FIRST, "100", "100", "5"),), (note(par="50"),),
                         senior_management_fee_bps=D("360"), management_fee_day_count=DayCount.ACT_365F)
        self.assertEqual(projection.periods[0].senior_management_fee_due, D("0.89"))

    def test_named_fixed_and_variable_expenses_are_not_double_counted(self) -> None:
        projection = run(
            (receipt("L", 1, CLOSE, FIRST, "100", "100", "5"),), (note(par="50"),),
            recurring_senior_expenses=(RecurringSeniorExpense("TRUSTEE", D("1.46")), RecurringSeniorExpense("AUDIT", D("2.19"))),
            variable_senior_expenses_bps=D("365"),
        )
        # Fixed3.65 ×90/365=.90; variable100 ×.0365 ×90/365=.90.
        first = projection.periods[0]
        self.assertEqual(first.newly_incurred_senior_expenses, D("1.80"))
        self.assertEqual(first.senior_expenses_due, D("1.80"))
        self.assertEqual(first.equity_from_interest, D("3.20"))

    def test_expense_cap_preserves_excess_and_pays_before_equity(self) -> None:
        projection = run(
            (receipt("L", 1, CLOSE, FIRST, "100", "100", "5"),), (note(par="50"),),
            annual_senior_expenses=D("3.65"), annual_senior_expense_cap=D("1.82"),
        )
        first = projection.periods[0]
        self.assertEqual(first.newly_incurred_senior_expenses, D("0.90"))
        self.assertEqual(first.senior_expense_priority_cap, D("0.45"))
        self.assertEqual(first.senior_expenses_paid, D("0.45"))
        self.assertEqual(first.deferred_senior_expenses_due, D("0.45"))
        self.assertEqual(first.deferred_senior_expenses_paid, D("0.45"))
        self.assertEqual(first.equity_from_interest, D("4.10"))
        self.assertEqual(first.cash_conservation_residual, D(0))

    def test_cap_excess_can_be_paid_from_principal_only_after_debt(self) -> None:
        projection = run((receipt("L", 1, CLOSE, FIRST, "100", "100", "0"),), (note(par="90"),),
                         annual_senior_expenses=D("3.65"), annual_senior_expense_cap=D("0"))
        first = projection.periods[0]
        self.assertEqual(first.debt_principal_from_principal, D("90"))
        self.assertEqual(first.deferred_senior_expenses_paid, D("0.90"))
        self.assertEqual(first.equity_from_principal, D("9.10"))

    def test_cap_excess_unpaid_has_explicit_final_claim(self) -> None:
        projection = run((receipt("L", 1, CLOSE, FIRST, "100", "100", "0"),), (note(),), final=FIRST,
                         annual_senior_expenses=D("3.65"), annual_senior_expense_cap=D("0"))
        self.assertEqual(projection.status, ProjectionStatus.FINAL_FEES_UNSETTLED)
        self.assertEqual(projection.final_deferred_senior_expenses, D("0.90"))
        self.assertFalse(projection.terminal_value_available)
        self.assertFalse(projection.periods[0].cash_pay_failure)

    def test_cap_variable_component_uses_explicit_fee_basis(self) -> None:
        projection = run((receipt("L", 1, CLOSE, FIRST, "100", "100", "5"),), (note(par="50"),),
                         annual_senior_expenses=D("3.65"), annual_senior_expense_cap=D("0"), senior_expense_cap_bps=D("182.5"))
        self.assertEqual(projection.periods[0].senior_expense_priority_cap, D("0.45"))

    def test_deferred_expense_arrears_carry_without_compounding(self) -> None:
        projection = run((receipt("L", 1, CLOSE, FIRST, "100", "0", "0"),
                          receipt("L", 2, FIRST, SECOND, "100", "100", "5")), (note(par="90"),),
                         annual_senior_expenses=D("3.65"), annual_senior_expense_cap=D("0"))
        first, second = projection.periods
        self.assertEqual(first.deferred_senior_expenses_unpaid, D("0.90"))
        self.assertEqual(second.deferred_senior_expenses_due, D("1.81"))
        self.assertEqual(second.deferred_senior_expenses_paid, D("1.81"))

    def test_first_payment_anchor_and_override_only_first_floating_coupon(self) -> None:
        first = date(2026, 3, 20)
        final = date(2026, 6, 20)
        rows = (receipt("L", 1, CLOSE, first, "100", "0", "1"),
                receipt("L", 2, first, date(2026, 6, 22), "100", "100", "5"))
        tranche = NoteTranche("A", 1, D("80"), CouponType.FLOATING, "EURIBOR_3M", D("100"), index_floor=D("0.01"))
        projection = run(rows, (tranche,), final=final,
                         stub_convention=StubConvention.SHORT_FIRST,
                         first_payment_date_unadjusted=first, first_stub_rate_override=D("0"))
        # Explicit zero is an override, then index floor1% +spread1%.
        self.assertEqual(projection.periods[0].payment_date, first)
        self.assertEqual(projection.tranche_periods[0].index_rate, D(0))
        self.assertEqual(projection.tranche_periods[0].all_in_rate, D("0.02"))
        self.assertEqual(projection.tranche_periods[0].current_coupon_due, D("0.26"))
        self.assertEqual(projection.tranche_periods[1].index_rate, D("0.025"))

    def test_first_stub_override_rejects_a_regular_quarter_and_fixed_only_stack(self) -> None:
        floating = NoteTranche("A", 1, D("80"), CouponType.FLOATING, "EURIBOR_3M", D("100"))
        rows = (receipt("L", 1, CLOSE, FIRST, "100", "100", "5"),)
        with self.assertRaisesRegex(InputValidationError, "actual first nominal stub"):
            run(rows, (floating,), first_stub_rate_override=D(0))
        with self.assertRaisesRegex(InputValidationError, "floating note"):
            run(rows, (note(),), first_stub_rate_override=D(0))

    def test_regular_backwards_anchor_clipped_february_is_not_a_stub(self) -> None:
        calendar = ScheduleBuilder(TargetCalendar())
        periods = calendar.build(date(2027, 2, 28), date(2027, 8, 31), 3,
                                 stub_convention=StubConvention.SHORT_FIRST,
                                 first_payment_date=date(2027, 5, 31))
        self.assertFalse(calendar.is_first_period_stub(periods[0], 3, StubConvention.SHORT_FIRST))
        # Business-day adjustment changes accrual days without changing stub.
        self.assertNotEqual(periods[0].accrual_start, periods[0].unadjusted_start)

    def test_short_and_long_first_stub_classification_uses_nominal_grid(self) -> None:
        calendar = ScheduleBuilder(TargetCalendar())
        short = calendar.build(CLOSE, date(2026, 6, 20), 3, stub_convention=StubConvention.SHORT_FIRST,
                               first_payment_date=date(2026, 3, 20))
        long = calendar.build(CLOSE, date(2026, 9, 20), 3, stub_convention=StubConvention.LONG_FIRST,
                              first_payment_date=date(2026, 6, 20))
        self.assertTrue(calendar.is_first_period_stub(short[0], 3, StubConvention.SHORT_FIRST))
        self.assertTrue(calendar.is_first_period_stub(long[0], 3, StubConvention.LONG_FIRST))

    def test_large_reserve_plus_small_receipt_keeps_every_cent(self) -> None:
        reserve = D("1e80")
        projection = run((receipt("L", 1, CLOSE, FIRST, "100", "100", "5"),), (note(),), initial_reserve=reserve)
        expected = D("1" + "0" * 79 + "5")
        self.assertEqual(projection.total_equity_distributions, expected)
        self.assertEqual(Fraction(projection.total_equity_distributions), Fraction(reserve) + 5)

    def test_large_senior_claim_keeps_small_partial_payment_in_final_arrears(self) -> None:
        budget = D("1e80")
        projection = run((receipt("L", 1, CLOSE, FIRST, "100", "100", "5"),), (note(),), final=FIRST,
                         annual_senior_expenses=budget)
        # Expense claims are rounded cents on exact90/365. Subtract105 actual
        # cash using independent rational cents, rather than decimal arithmetic.
        due_cents = (Fraction(budget) * Fraction(90, 365) * 100 + Fraction(1, 2)).numerator // (Fraction(budget) * Fraction(90, 365) * 100 + Fraction(1, 2)).denominator
        self.assertEqual(Fraction(projection.final_senior_claims), Fraction(due_cents, 100) - 105)

    def test_new_controls_ignore_low_caller_context_and_traps(self) -> None:
        args = ((receipt("L", 1, CLOSE, FIRST, "100", "100", "5"),), (note(par="90"),))
        kwargs = dict(variable_senior_expenses_bps=D("365"), annual_senior_expense_cap=D(0),
                      principal_repayment_mode=PrincipalRepaymentMode.PRO_RATA)
        high = run(*args, **kwargs)
        with localcontext() as context:
            context.prec = 2
            context.traps[Inexact] = True
            self.assertEqual(run(*args, **kwargs), high)


class WaterfallControlsValidationTests(unittest.TestCase):
    def test_stub_classification_rejects_nonfirst_or_untyped_schedule_metadata(self) -> None:
        calendar = ScheduleBuilder(TargetCalendar())
        period = calendar.build(CLOSE, SECOND, 3)[0]
        for args in (
            (replace(period, period_number=2), 3, StubConvention.SHORT_LAST, False),
            (period, True, StubConvention.SHORT_LAST, False),
            (period, 2, StubConvention.SHORT_LAST, False),
            (period, 3, "SHORT_FIRST", False), (period, 3, StubConvention.SHORT_LAST, 1),
        ):
            with self.subTest(args=args), self.assertRaises((ValueError, TypeError)):
                calendar.is_first_period_stub(*args)

    def test_boolean_enums_and_day_count_require_typed_values(self) -> None:
        for kwargs in (
            {"coverage_tests_enabled": "False"}, {"interest_diversion_enabled": 0},
            {"include_principal_cash_in_oc": 1}, {"principal_repayment_mode": "PRO_RATA"},
            {"interest_diversion_mode": "ALL_RESIDUAL"}, {"management_fee_basis": "INITIAL_COLLATERAL_PAR"},
            {"management_fee_day_count": DayCount.THIRTY_E_360}, {"senior_expenses_day_count": "ACT/360"},
        ):
            with self.subTest(kwargs=kwargs), self.assertRaises(InputValidationError):
                CloTerms(CLOSE, SECOND, **kwargs)

    def test_components_are_named_unique_typed_and_exclusive_with_aggregate(self) -> None:
        component = RecurringSeniorExpense("TRUSTEE", D("3.65"))
        for kwargs in (
            {"recurring_senior_expenses": [component]},
            {"recurring_senior_expenses": (component, component)},
            {"recurring_senior_expenses": (component,), "annual_senior_expenses": D(1)},
        ):
            with self.subTest(kwargs=kwargs), self.assertRaises(InputValidationError):
                CloTerms(CLOSE, SECOND, **kwargs)
        for expense_id, annual_amount in ((" ", D(1)), ("X", D(-1)), ("X", 1.0)):
            with self.subTest(expense_id=expense_id), self.assertRaises(InputValidationError):
                RecurringSeniorExpense(expense_id, annual_amount)

    def test_caps_rates_dates_and_override_reject_invalid_values(self) -> None:
        for kwargs in (
            {"variable_senior_expenses_bps": D(-1)}, {"senior_expense_cap_bps": D(1)},
            {"annual_senior_expense_cap": D(-1)}, {"annual_senior_expense_cap": D("1.001")},
            {"first_payment_date_unadjusted": CLOSE}, {"last_regular_date_unadjusted": date(2027, 1, 1)},
            {"first_stub_rate_override": D("NaN")},
        ):
            with self.subTest(kwargs=kwargs), self.assertRaises(InputValidationError):
                CloTerms(CLOSE, SECOND, **kwargs)


if __name__ == "__main__":
    unittest.main()
