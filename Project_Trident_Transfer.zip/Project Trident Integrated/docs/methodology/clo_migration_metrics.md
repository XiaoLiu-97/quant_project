# Liability PIK and CLO economics

This note documents the executable liability PIK and economics definitions. It
distinguishes current mandatory PIK from an optional deferred cash-pay coupon,
and separates contractual coupon diagnostics from receipts after credit stress.
The source of truth is the typed request and the emitted waterfall records;
Excel cells present those records rather than recalculating them.

## 1. Mandatory PIK versus optional deferral

`NoteTranche.pik_rate_fraction` is a decimal fraction between 0 and 1. Zero is a
cash-pay coupon; 1 capitalizes the entire current coupon; an intermediate value
is a contractual Cash/PIK split. The legacy PIK flag means mandatory current
coupon capitalization and must not be mapped to `interest_deferrable`.

`interest_deferrable` describes a different permission: an otherwise cash-pay
coupon can survive as a legally deferred coupon claim when the waterfall cannot
pay it. It does not add actual face. The selected OC definition may include that
claim in coverage debt; the selected IC definition may exclude its opening
principal while retaining interest on the claim. Those choices do not convert
it into a second PIK-face addition.

| Ledger | Mandatory PIK | Optional deferred cash coupon |
|---|---|---|
| Face principal | Increases on the configured payment date | Unchanged |
| Outstanding coupon claim | No claim for the capitalized current component | Increases by current unpaid cash coupon |
| Physical cash at capitalization/deferral | No cash | No cash |
| Next-period face coupon | Includes the capitalized face | Uses face only |
| Interest on opening unpaid claim | Separate policy | Separate policy |
| OC debt | Face includes PIK once | Actual deferred claim included only under the selected OC policy |
| IC cash debt service | Current capitalized component excluded | Current cash dues plus permitted arrears treatment |
| Final settlement | Enlarged face redeemed from actual cash | Outstanding claim paid before its own face |

The legal principal concept of a PIK note can include amounts added at scheduled
PIK payments, with subsequent interest on the enlarged principal. A redemption
also distinguishes already capitalized principal from accrued, uncapitalized
interest. These concepts are illustrated by [Anagram Indenture §§2.14–2.15 and
3.07](https://www.sec.gov/Archives/edgar/data/1592058/000119312520207189/d43127dex43.htm).
That document is a corporate-note example, not a European CLO template: its
whole-dollar rounding, optional redemption clauses and cash/PIK rate levels
are not inferred as universal conventions.

## 2. Liability execution order and identities

For opening face `B`, annual all-in rate `r` and exact contractual day-count
fraction `a`, define:

```text
gross_current_coupon = post_currency(B × r × a)
mandatory_PIK = post_currency(gross_current_coupon × pik_rate_fraction)
current_cash_coupon = gross_current_coupon − mandatory_PIK
face_before_distribution = B + mandatory_PIK
closing_face = B + mandatory_PIK − principal_paid_from_all_cash_sources
```

The gross coupon is posted once to currency cents; the PIK component is posted
once, and the cash residual makes the split exact. Posting both components
independently can lose or add a cent. Liability PIK capitalization occurs before
all interest-waterfall coverage nodes. A blocked junior cash-payment node still
capitalizes its contractual current PIK: a cash diversion does not waive the
contractual noncash settlement.

The cash claim ledger obeys its own equation:

```text
opening_unpaid_cash_coupon + current_cash_coupon + interest_on_opening_claim
    − coupon_cash_paid − explicit_waiver = closing_unpaid_cash_coupon
```

No mandatory PIK amount enters this equation or physical cash conservation.
It is included in face for OC and independent IDT coverage without depending
on `include_deferred_interest_in_oc`. The current cash component enters IC;
capitalized current PIK does not become an additional cash coupon due.

At legal final, current PIK is first capitalized and the enlarged face is then
redeemed from available principal and authorized terminal interest cash. If
cash is insufficient, the remaining actual face stays outstanding and the
projection is unresolved. Capitalization is never treated as cash payment or
an invented terminal payoff. Optional deferral waivers do not waive mandatory
PIK face.

Actual CLO test definitions are contractual. For example, the [Barrow Hanley
CLO I executed reset indenture, Interest Coverage Ratio definition](https://www.csx.ky/Attachments/13523/Barrow%20Hanley%20CLO%20I%20-%20Notice%20of%20Executed%20Supplemental%20Indenture%20%282025%29%28129051748.2%29.pdf)
separates deferred interest principal from interest on deferred interest. The
[Ares Direct Lending CLO 1 amended indenture dated 17 July 2026, Interest Coverage Ratio definition](https://www.sec.gov/Archives/edgar/data/1287750/000110465926085912/tm2620889d1_ex4-1.htm)
excludes noncash PIK asset interest from cash interest proceeds. These examples
support the ledger separation; each real deal still requires its own test,
valuation, dates and priority profile.

## 3. Native asset PIK and payment lag

Native asset records carry a separate `pik_interest` field. Their row identities
are:

```text
closing_balance = opening_balance + pik_interest − principal_repayment
total_cash = cash_interest + principal_repayment
```

The asset PIK face addition occurs at
`LoanCashflow.pik_capitalization_date = min(accrual_end, payment_date)`; principal
repayment leaves collateral at actual payment. Ordinary lag capitalizes at
accrual end and retains enlarged principal until cash settles. PRECEDING can
instead place final cash before an unadjusted nominal maturity: current PIK
must exist by that earlier redemption date, rather than repay nonexistent face
and re-capitalize it afterwards. This explicit projected advance-pay policy
changes neither the nominal accrual interval nor its full coupon factor. It is
shared by native CLO, imported dated movements and portfolio holdings scanning.
No additional coupon accrues during lag and no cash appears at capitalization.

At final PIK capitalization, `principal_repayment` includes opening face plus
current PIK. A record with opening 100, current PIK 10 and maturity principal
110 therefore has cash 110 and ending face 0. A record with principal 100 and
cash 110 would violate the cash identity and is rejected.

Examples with note distributions on 20 April and final settlement on 20 July:

| Asset event | Date | Collateral face | Actual principal cash |
|---|---|---:|---:|
| Opening | 20 January | 100 | 0 |
| Current PIK capitalization | 20 April | 110 | 0 |
| Lagged final receipt | 22 April | 0 | 110 |
| Next note distribution | 20 July | 0 | Already held cash, released once |

Imported records have their own authoritative cash/par event trace, including
noncash additions. A native PIK addition must not be applied on top of an
imported or stressed movement trace. Credit stress and source classification
are separate from the contractual PIK instruction: default moves actual
performing face into a default claim, recovery converts a claim to cash, and
writeoff resolves the remainder.

Detailed records with an explicit accrual end retain the same earlier-of PIK
event, separately from principal cash settlement. Native export/import must
preserve row amounts and between-date face, including OC before lagged cash
receipt and nonnegative balances on a preceding cash date. An external tape
without a distinct effective date retains its declared source convention; the
adapter cannot reconstruct an unreported date from weighted rate metadata.

For native PIK whose actual payment differs from nominal accrual end, with a
proportional original-pool overlay,
the engine builds a frozen posted-cash reference with explicit dated movements: noncash
PIK at its shared earlier-of date, plus posted coupon/principal at actual receipt.
The source-boundary default profile rescales those posted receipts and face;
it does not claim to recover unrounded historical loan-agent entitlement.
Standalone capitalization dates are excluded from CPR boundaries. CPR measures
its full elapsed interval from the preceding authorized cash-payment boundary,
so adding a noncash event neither prepays prematurely nor shortens the hazard
interval. Earlier defaulted slices cannot receive the future PIK addition.

The native overlay with coincident accrual/payment boundaries retains its exact
unrounded contractual factors.
Explicit off-cycle per-asset credit events with lag still require a separate
receivable ownership profile and are rejected; that is an extension of the old
generator's pure contractual projection, not a silent removal of payment lag
from ordinary generation or the proportional export/import pathway.

## 4. Source-consistent economics

`report_clo_economics(request, projection, funding=None)` returns immutable rows
with `metric_id`, `value`, `unit`, `numerator`, `denominator`, `basis`, `status`
and `message`. Rates are annual decimal fractions, spreads are basis points,
money is EUR, and leverage/MOIC are decimal multiples.

### 4.1 Funding and leverage

| Metric | Numerator | Denominator |
|---|---|---|
| `DEBT_TO_COLLATERAL_PAR` | Opening note face | Opening performing collateral face |
| `DEBT_TO_EQUITY_CASH` | Opening note face | Actual Sources & Uses investor contribution |
| `COLLATERAL_TO_EQUITY_CASH` | Opening collateral face | Actual Sources & Uses investor contribution |
| `WEIGHTED_FLOATING_DEBT_SPREAD_BPS` | Sum of floating-note face × contractual margin | Floating-note face only |
| `WEIGHTED_FIXED_DEBT_COUPON` | Sum of fixed-note face × fixed annual coupon | Fixed-note face only |

The actual equity contribution includes clean acquisition prices, purchased
accrued interest, issue prices, reserve and closing costs. Equity nominal is
not an investor cash outlay. Fixed coupons and floating margins have separate
populations; a fixed tranche does not receive an invented reference spread.

### 4.2 Realized cash yields and debt costs

For each source, exposure is the exact integral of actual live face over the
emitted projection horizon, divided by 365:

```text
performing_face_years = ∫ performing_face(t) dt_in_calendar_days / 365
annual_cash_yield = actual_source_coupon_collections / performing_face_years
```

Original collateral and settled synthetic reinvestment cohorts are separate
sources. The numerator and denominator both reflect the selected credit stress,
prepayment and settlement dates. Purchased cohorts have no exposure before
settlement. Original face sold at a call has no exposure after disposal.

These are annualized cash-collection yields, not an asset IRR, a price-adjusted
yield-to-maturity, or a contractual coupon. Verified opening coupon receipts
are included in original cash collections even though their ownership period
started before the projected horizon; their basis explicitly discloses this.

Reinvestment reference and spread use the same surviving cohort face as the
received coupon. Reference uses the floored term index. Reference cash is
posted once; the received coupon minus that amount is the spread allocation,
so the parts sum to actual coupon cash even at cent ties.

`CASH_DEBT_COST` is all note coupon cash paid from both interest and principal
accounts divided by opening-note face-days/365. It includes any actually paid
historical arrears. Capitalized PIK face redemption is principal cash rather
than a second coupon payment in this measure.

`ACCRUED_DEBT_COST` uses current contractual cash plus PIK coupon and current
interest-on-arrears, divided by the same note exposure. Historical unpaid
coupon principal is not counted as a newly accrued expense again. A full-PIK
note can therefore have zero cash coupon cost and a positive accrued cost.

### 4.3 Contractual coupon/reference/spread diagnostics

Native contractual diagnostics deliberately use an unstressed population:

```text
coupon_DCF_exposure = sum(native opening_face × native coupon DCF)
contractual_coupon_yield = native forward gross coupon / coupon_DCF_exposure
```

The native exact opening accrued claim is removed from forward earnings.
Floating margin uses its DCF-normalized native spread; effective reference is
the floating forward coupon less that margin. Reference therefore retains
floors, coupon bounds and projected overnight compounding effects. Fixed
coupon is a separate component. Total coupon equals reference plus spread
plus fixed-coupon components on this matching basis.

The exported payment horizon is used; future contracts after an exercised call
or a stopped projection are not silently counted. Imported cash without native
rate segments cannot prove the contractual reference/spread decomposition;
these diagnostics return `UNAVAILABLE`. Received original cash yield remains
available when its actual cash and par trace are complete.

### 4.4 Fees and investor returns

Recurring fees aggregate senior expenses, deferred senior expenses and senior/
subordinated manager fees regardless of which permitted cash account paid them.
Lifecycle fees add incentive, call and refinancing fees; total fees also include
Sources & Uses closing costs when a matching closing ledger is supplied.
Principal-funded subordinated fees are included exactly once.

Investor cash contains actual closing funding, dated additional contributions
and net distributions after incentive fees. XIRR uses actual calendar days/365
and its unique-root policy; MOIC uses gross distributions divided by gross
contributions, preserving same-day contributions and distributions. Microsoft's
[XIRR specification](https://support.microsoft.com/en-us/excel/functions/xirr-function)
provides the day basis and discounted dated-cashflow equation. An unresolved
projection has collected cash diagnostics but no fabricated terminal equity
MOIC or XIRR.

For an existing CLO forward projection, historical closing costs and funding
do not establish the investor's current purchase price. Closing investor return
metrics remain unavailable unless a separately supported entry-cost workflow
provides the required economic ownership data.

## 5. Worked liability hand ledger

A note opens at 100 on 20 January 2026, with a fixed 10% ACT/360 coupon and full
mandatory PIK. The first distribution is 20 April, 90 days later; the second
is 20 July, 91 days after the first. Collateral pays 200 cash principal at final.

| Period | Opening face | Current gross coupon | PIK added | Cash coupon | Principal paid | Closing face |
|---|---:|---:|---:|---:|---:|---:|
| 1 | 100.00 | 2.50 | 2.50 | 0.00 | 0.00 | 102.50 |
| 2 | 102.50 | 2.59 | 2.59 | 0.00 | 105.09 | 0.00 |

Equity receives 94.91. Cumulative PIK is 5.09. There is no unpaid coupon claim,
no coupon cash receipt at capitalization, and no coupon cash paid. Each period
independently reconciles face and physical cash.

With a 50% PIK fraction, the first 2.50 coupon splits into cash 1.25 and PIK
1.25. IC cash dues are 1.25; OC actual face before redemption is 101.25. With
full PIK and an OC floor of 2.0 against collateral 200, face 102.50 makes the
test fail; an actual interest-funded principal cure reduces that face, rather
than paying a fictitious cash coupon.

## 6. Code and verification

| Component | Responsibilities |
|---|---|
| `src/trident/clo/models.py` | Typed PIK fraction, period source/exposure amounts and immutable face/coupon snapshots |
| `src/trident/clo/engine.py` | Capitalization order, source cash, face timelines, coverage and independent cash/par/claim identities |
| `src/trident/clo/reinvestment.py` | Source-consistent surviving-face reference/spread coupon attribution |
| `src/trident/clo/reporting.py` | Every class-period cash, face/PIK and coupon bridge; cumulative PIK and gross current coupon |
| `src/trident/clo/economics.py` | Funding, matching-source yields, costs, fees and investor diagnostics |
| `LoanCashflow.pik_capitalization_date` / `application/portfolio_snapshots.py` | One explicit earlier-of date policy, ordered capitalization/redemption, and reconciled holdings observations |
| `tests/test_clo_pik_economics.py` | Independent hand ledgers, maturity shortfall, blocked gate, optional deferral, lagged asset PIK, source yields and fees |

Important model assumptions are the capitalization dates, same-date terminal
capitalization/redemption classification, currency-cent posting, cash debt
service definition, source-specific yield denominators and settlement-par
policy above. They are reviewable economic definitions; they do not claim that
an unexamined transaction indenture or agency-calibrated rating model has been
replicated.
