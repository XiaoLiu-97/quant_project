"""Publish complete typed results into the compact, named Excel interface.

The output package owns formatting and display joins only. Results are saved
by case; selecting a saved case never reruns financial calculations. Publishing
occurs once after all engines finish, so a failed calculation retains the last
complete model and its input evidence.
"""
from datetime import datetime, timezone
from decimal import Decimal

from trident import __version__
from .interface_package import WorkbookPackage, FormulaCell
from .interface_capacity import prepare_input_capacity, refresh_asset_id_options
from .interface_output_capacity import CapacityWorkbookPackage
from .interface_reporting import PREFIX, NA, available, case_tables, comparison_records, number_formats, unit_format, metric_format
from .model_records import flat_record


def _case_options(package, run):
    cases=[c.case_id for c in run.cases]
    for suffix,header,values in [('analysis_options_case','Case',cases),('analysis_options_comparison','Comparison',['NONE',*cases[1:]])]:
        name=PREFIX+suffix
        info=package.write_table(name,tuple({header:x} for x in values))
        left,top,_,bottom=info.bounds
        from .interface_package import _column
        package.define_name('trident_ui_'+suffix,info.sheet,f"${_column(left)}${top+1}:${_column(left)}${bottom}")
    package.write_scalar('trident_ui_analysis_case','BASELINE')
    package.write_scalar('trident_ui_analysis_comparison','NONE')
    if 'trident_ui_comparison_case' in package._names():
        package.write_scalar('trident_ui_comparison_case',cases[1] if len(cases)>1 else 'BASELINE')


def _checks(run):
    result=run.baseline;clo=result.clo;portfolio=result.opening_portfolio
    records=[]
    def row(name,status,message,scope):records.append({'Review item':name,'Status':status,'Reason / action':message,'Scope':scope})
    row('Calculation','COMPLETED','All selected services computed from one validated input snapshot','Python calculation')
    row('Input identity','RECORDED',run.inputs.input_fingerprint,'Exact normalized raw input + execution policy')
    row('Model version',__version__,'Interface schema 1.0; compact named owners','Software')
    row('CLO result','NOT_SELECTED' if clo is None else clo.status.value,'Inspect every period and tranche in Waterfall','Financial result')
    row('Cash conservation','NOT_SELECTED' if clo is None else 'PASS' if all(p.cash_conservation_residual==0 for p in clo.periods) else 'FAIL','Each projected waterfall period reconciles posted cash','CLO accounts')
    row('Opening legal breaches','BREACH' if any(l.status.value=='BREACH' for l in portfolio.limits) else 'NONE',', '.join(l.limit_id for l in portfolio.limits if l.status.value=='BREACH') or 'No measured opening breach','Opening snapshot')
    row('Opening missing-data tests','REVIEW' if any(l.status.value=='UNAVAILABLE' for l in portfolio.limits) else 'NONE',', '.join(l.limit_id for l in portfolio.limits if l.status.value=='UNAVAILABLE') or 'All opening limits measured','Unavailable is never PASS')
    row('Return completeness',result.equity_irr.status.value,result.equity_irr.message,'Forward from current mark' if result.clo_opening_state else 'Closing lifecycle')
    row('What-if cases','COMPLETED' if len(run.cases)>1 else 'NONE',', '.join(c.case_id for c in run.cases[1:]) or 'No enabled edits','Independent complete cases')
    row('Static optimization','DISABLED' if run.optimization is None else run.optimization.status.value,'Static research does not settle trades or certify full CLO replay','Opening snapshot')
    row('Candidate replay','DISABLED' if run.search is None else run.search.status.value,'Every admitted candidate is replayed in the full closing model before ranking','Finite candidate set')
    row('Optimization scope','STATIC','No lifetime trading optimization; configured reinvestment assumption remains projected','First usable release')
    row('Synthetic inputs','SYNTHETIC' if run.inputs.request.factor_mapping and run.inputs.request.factor_mapping.is_synthetic else 'DECLARED','Synthetic TEST coefficients are separate from agency WARF','Factor provenance')
    for warning in run.inputs.warnings:row('Data availability','REVIEW',warning,'Sourced inputs')
    if run.library_projection is not None:
        row('Library reference projections','REVIEW' if run.library_projection.failures else 'COMPLETED',str(len(run.library_projection.cashflows))+' reference cashflow rows; failures '+str(run.library_projection.failures),'REFERENCE_CONTRACT; no holding, acquisition or CLO cash')
    return tuple(records)


def _comparison_reader(package, run):
    full=comparison_records(run)
    package.write_table(PREFIX+'comparison',full)
    package.write_table(PREFIX+'view_comparison',tuple({'Key':r['Scenario']+'|'+r['Metric'],**r} for r in full))
    _record_formats(package,PREFIX+'comparison',full,'Unit',('Base','Scenario result','Difference'))
    _record_formats(package,PREFIX+'view_comparison',full,'Unit',('Base','Scenario result','Difference'))
    # The compact trade comparison shows complete common construction metrics.
    # Every additional note/limit/dated comparison remains in its native table.
    labels=[('Equity IRR','EQUITY_IRR','annual_fraction'),('Equity MOIC','EQUITY_MOIC','multiple'),('Equity funding','EQUITY_CASH_FUNDING','EUR'),('Collateral par','COLLATERAL_PAR','EUR'),('Debt par','DEBT_PAR','EUR'),('WAS','WAS_BPS','bps'),('WAC','WAC_RATE','fraction'),('WARF','WARF','rating_factor'),('Synthetic factor','TEST_FACTOR_AVERAGE','synthetic_factor'),('BSL factor','BSL_TEST_FACTOR_AVERAGE','synthetic_factor'),('WARR','WARR','fraction'),('WAL','WAL_YEARS','years'),('Senior share','SENIOR_FRACTION','fraction'),('Secured share','SECURED_FRACTION','fraction'),('PIK share','PIK_FRACTION','fraction'),('Largest obligor','LARGEST_OBLIGOR_FRACTION','fraction'),('Largest sector','LARGEST_SECTOR_FRACTION','fraction'),('Largest country','LARGEST_COUNTRY_FRACTION','fraction'),('Limit breaches','OPENING_LIMIT_BREACH_COUNT','count'),('Limits unavailable','OPENING_LIMIT_UNAVAILABLE_COUNT','count'),('Final debt','FINAL_DEBT_PAR','EUR'),('Equity distributions','TOTAL_EQUITY_DISTRIBUTIONS','EUR')]
    if run.baseline.clo_opening_state is not None:
        labels[2]=('Current equity value','FORWARD_EQUITY_VALUE','EUR')
    options=['BASELINE',*(c.case_id for c in run.cases[1:])]
    if run.optimization is not None:options.append('STATIC')
    name='trident_ui_comparison_case'
    if name not in package._names():
        package.define_name(name,'Trades & Comparison','$D$7')
    package.write_scalar(name,options[1] if len(options)>1 else 'BASELINE')
    cases={}
    baseline=run.cases[0]
    from trident.application.scenarios import _model_observations
    base_obs=_model_observations(baseline.request,baseline.result)
    for case in run.cases:
        obs=_model_observations(case.request,case.result);rows=[]
        for label,key,unit in labels:
            b=next((v for (scope,m,identity),v in base_obs.items() if m==key and identity is None),(None,'UNAVAILABLE',unit,''))
            p=next((v for (scope,m,identity),v in obs.items() if m==key and identity is None),(None,'UNAVAILABLE',unit,''))
            from trident.application.scenarios import _delta
            delta,status=_delta(b[0],p[0],b[1],p[1])
            rows.append({'Metric':label,'Saved Base':available(b[0]),'Proposed':available(p[0]),'Delta':available(delta),'Unit':unit,'Status':status,'Scope / detail':'Forward snapshot' if case.request.clo_opening_state else case.origin})
        cases[case.case_id]=tuple(rows)
    if run.optimization is not None:
        cases['STATIC']=_static_comparison_rows(run,labels)
    package.add_case_view(PREFIX+'comparison_reader',cases,selector_name=name)
    _mixed_formats(package,PREFIX+'comparison_reader',cases)
    # Reuse an existing hidden selector catalogue; no extra visible tab.
    info=package.add_table(PREFIX+'comparison_case_options',('Case',),tuple({'Case':c} for c in options))
    from .interface_package import _column
    left,top,_,bottom=info.bounds
    package.define_name('trident_ui_comparison_case_options',info.sheet,f'${_column(left)}${top+1}:${_column(left)}${bottom}')
    package.set_list_validation('Trades & Comparison','D7','trident_ui_comparison_case_options',title='Saved comparison basis')


def _static_comparison_rows(run,labels):
    """Show measured proposal statistics without inventing a projected IRR.

    The linear solver's spread denominator is all held par. It is therefore
    labelled explicitly rather than being confused with market WAS, whose
    denominator contains floating-rate loans only. Baseline aggregates use
    the exact same mandate holdings and basis as the solver's reconstruction.
    """
    from fractions import Fraction
    from trident.domain.numeric import decimal_fraction,post_currency
    from .interface_inputs import static_optimization_request
    request=static_optimization_request(run.inputs,run.baseline)
    result=run.optimization
    total=sum((Fraction(h.par) for h in request.holdings),Fraction())
    bsl=tuple(h for h in request.holdings if h.asset.kind.value=='BSL')
    bsl_par=sum((Fraction(h.par) for h in bsl),Fraction())
    mean=lambda holdings,field,denominator:decimal_fraction(sum((Fraction(h.par)*Fraction(getattr(h.asset,field)) for h in holdings),Fraction())/denominator) if denominator else None
    synthetic=bool(run.inputs.request.factor_mapping and run.inputs.request.factor_mapping.is_synthetic)
    factor_key='TEST_FACTOR_AVERAGE' if synthetic else 'WARF'
    bsl_key='BSL_TEST_FACTOR_AVERAGE' if synthetic else 'BSL_WARF'
    before={'COLLATERAL_PAR':post_currency(total),factor_key:mean(request.holdings,'factor',total),bsl_key:mean(bsl,'factor',bsl_par),'ALL_ASSET_SPREAD_BPS':mean(request.holdings,'spread_bps',total),'AVAILABLE_STATIC_CASH':request.starting_cash}
    after={'COLLATERAL_PAR':result.ending_par,factor_key:result.overall_factor,bsl_key:result.bsl_factor,'ALL_ASSET_SPREAD_BPS':result.spread_bps,'AVAILABLE_STATIC_CASH':result.ending_cash}
    from trident.application.scenarios import _delta
    rows=[]
    for label,key,unit in [*labels,('Available static cash','AVAILABLE_STATIC_CASH','EUR')]:
        if key=='WAS_BPS':label,key='Linear all-asset spread','ALL_ASSET_SPREAD_BPS'
        if key not in after:
            rows.append({'Metric':label,'Saved Base':NA,'Proposed':NA,'Delta':NA,'Unit':unit,'Status':'NOT_MEASURED','Scope / detail':'STATIC_ONLY; no CLO replay or investor return'})
            continue
        base,proposed=before.get(key),after[key]
        delta,status=_delta(base,proposed,'AVAILABLE' if base is not None else 'UNAVAILABLE','AVAILABLE' if proposed is not None else 'UNAVAILABLE')
        rows.append({'Metric':label,'Saved Base':available(base),'Proposed':available(proposed),'Delta':available(delta),'Unit':unit,'Status':status,'Scope / detail':'STATIC_ONLY; mandate '+result.status.value})
    return tuple(rows)


def _trade_reports(package, run):
    rows=[];audit=[]
    quotes={(q['asset_id'],q['side']):q for q in run.inputs.quotes}
    if run.search is not None:
        from .candidate_records import candidate_result_record
        for evaluation in run.search.evaluations:
            audit.append(candidate_result_record(evaluation,run.search.selected_candidate_id))
            replay=evaluation.replay
            if replay is None or replay.plan is None:continue
            for t in replay.plan.trades:
                record=flat_record(t)
                quote=quotes.get((t.asset_id,t.side.value),{})
                rows.append({'Proposal':evaluation.candidate_id,'Side':t.side.value,'Asset ID':t.asset_id,'Face (EUR)':t.par,'Price / 100':quote.get('clean_price_pct',NA),'Settlement':replay.plan.settlement_date,'Cash (EUR)':t.cash_change,'Status':'VALIDATED_NOT_EXECUTED' if replay.validated else 'REJECTED_NOT_EXECUTED'})
        package.add_table(PREFIX+'candidate_evaluations',tuple(audit[0]) if audit else ('Status',),audit or ({'Status':'NO_CANDIDATES'},),
                          number_formats=number_formats(tuple(audit[0]) if audit else ('Status',)))
        findings=[{'candidate_id':e.candidate_id,**flat_record(f)} for e in run.search.evaluations if e.replay for f in e.replay.findings]
        package.add_table(PREFIX+'candidate_findings',tuple(findings[0]) if findings else ('Status',),findings or ({'Status':'NONE'},))
    elif run.optimization is not None:
        for t in run.optimization.trades:
            r=flat_record(t)
            quote=quotes.get((t.asset_id,t.side.value),{})
            rows.append({'Proposal':'STATIC','Side':t.side.value,'Asset ID':t.asset_id,'Face (EUR)':t.par,'Price / 100':quote.get('clean_price_pct',NA),'Settlement':run.inputs.controls['optimizer_settlement_date'],'Cash (EUR)':t.cash_change,'Status':'STATIC_NOT_REPLAYED_NOT_EXECUTED'})
    if run.search is None:
        for suffix in ('candidate_evaluations','candidate_findings'):
            name=PREFIX+suffix
            if name in package.table_inventory():package.write_table(name,())
    package.write_table(PREFIX+'proposed_trades',rows,number_formats=number_formats(package.table_inventory()[PREFIX+'proposed_trades'].headers))


def write_interface_run(source,destination,run):
    """Write reports through declared names/Tables, retaining native Excel UI."""
    ownership=run.inputs.input_ownership
    protected_names=[v['name'] for v in ownership.values() if 'name' in v]
    protected_tables=[v['table'] for v in ownership.values() if 'table' in v]
    package=CapacityWorkbookPackage(source,run=run,protected_names=protected_names,protected_tables=protected_tables)
    prepare_input_capacity(package)
    _case_options(package,run)
    # Moving only output Tables frees all future period columns. Structured
    # Table references retain identity when the visible Waterfall grows.
    for suffix in ('waterfall_records','account_records'):
        info=package.table_inventory()[PREFIX+suffix]
        if info.sheet!='_Results':package.move_table(PREFIX+suffix)
    datasets={};audit={}
    for case in run.cases:
        tables,details=case_tables(case,run.inputs)
        for name,rows in tables.items():datasets.setdefault(name,{})[case.case_id]=rows
        for key,rows in details.items():
            audit.setdefault(key,[]).extend({'Case':case.case_id,**r} for r in rows)
    if run.library_projection is not None:
        columns=('loan_id','period_number','payment_date','opening_balance','cash_interest','pik_interest','principal_repayment','closing_balance','total_cash','currency','accrual_start','accrual_end','index_rate','spread_bps','all_in_rate','day_count_fraction')
        name=PREFIX+'asset_cashflows';headers=package.table_inventory()[name].headers
        datasets[name]['LIBRARY_REFERENCE']=tuple({h:available(getattr(r,c,None)) for h,c in zip(headers,columns)} for r in run.library_projection.cashflows)
        package.define_name('trident_ui_asset_cashflow_case','Asset Cashflows','D7')
        package.write_scalar('trident_ui_asset_cashflow_case','BASELINE')
        info=package.add_table(PREFIX+'asset_cashflow_case_options',('Case',),tuple({'Case':c} for c in datasets[name]))
        from .interface_package import _column
        l,t,_,b=info.bounds
        package.define_name('trident_ui_asset_cashflow_case_options',info.sheet,f'${_column(l)}${t+1}:${_column(l)}${b}')
        package.set_list_validation('Asset Cashflows','D7','trident_ui_asset_cashflow_case_options',title='Saved cashflow basis')
        package.write_cells('Asset Cashflows',{'B3':'Choose a saved case or LIBRARY_REFERENCE. Library reference uses contract start/reference face; it is separate from held CLO cash.','B7':'Cashflow basis'})
    for name,cases in datasets.items():
        if name not in package.table_inventory():
            # New report contracts live in independent hidden column lanes;
            # they extend measured scope/status detail without another tab.
            first=next((rows[0] for rows in cases.values() if rows),None)
            if first is None:
                continue
            package.add_table(name,tuple(first),())
        headers=package.table_inventory()[name].headers
        selector='trident_ui_asset_cashflow_case' if name==PREFIX+'asset_cashflows' else 'trident_ui_analysis_case'
        package.add_case_view(name,cases,selector_name=selector,number_formats=number_formats(headers))
        _mixed_formats(package,name,cases)
        if name==PREFIX+'limit_results':
            _limit_result_formats(package,name,cases,run)
    for key,rows in audit.items():
        if rows:
            package.add_table(PREFIX+'audit_'+key,tuple(rows[0]),rows,number_formats=number_formats(tuple(rows[0])))
            if key=='portfolio_metrics':
                _record_formats(package,PREFIX+'audit_'+key,rows,'unit',('value',),metric_column='name')
            elif key=='limit_tests':
                _audit_limit_formats(package,PREFIX+'audit_'+key,rows,run)
        elif PREFIX+'audit_'+key in package.table_inventory():
            package.write_table(PREFIX+'audit_'+key,())
    if run.period_comparisons:
        records=[flat_record(r) for r in run.period_comparisons]
        package.add_table(PREFIX+'scenario_periods',tuple(records[0]),records,number_formats=number_formats(tuple(records[0])))
        _record_formats(package,PREFIX+'scenario_periods',records,'unit',('baseline_value','scenario_value','delta'))
    elif PREFIX+'scenario_periods' in package.table_inventory():
        package.write_table(PREFIX+'scenario_periods',())
    _comparison_reader(package,run);_trade_reports(package,run)
    package.write_table(PREFIX+'checks',_checks(run))
    now=datetime.now(timezone.utc).isoformat(timespec='seconds')
    metadata=({'Item':'Calculated at UTC','Value':now},{'Item':'Input fingerprint','Value':run.inputs.input_fingerprint},{'Item':'Software version','Value':__version__},{'Item':'Execution profile','Value':run.inputs.execution_policy.profile_id},{'Item':'Result cases','Value':', '.join(c.case_id for c in run.cases)},{'Item':'Existing return basis','Value':'CURRENT_SOURCED_EQUITY_VALUE' if run.baseline.clo_opening_state else 'ORIGINAL_CLOSING_FUNDING'})
    package.add_table(PREFIX+'run_metadata',('Item','Value'),metadata)
    package.write_cells('Home',{'B3':'PROJECT TRIDENT | Integrated CLO model','B4':'Edit inputs, save and close Excel, then run Run_Model.cmd. Results and saved cases are refreshed together.','I7':FormulaCell('trident_ui_analysis_case','BASELINE'),'N7':run.baseline.cashflows.projection_start_date,'B38':'Calculate Baseline, enabled What-if cases and optional static optimization together with Run_Model.cmd. Asset IDs link all terms, holdings and projections.','B42':'Last complete calculation: '+now,'B44':'Asset inputs: 300 rows. Table capacities: hidden _Results.','B46':'Coverage / accounts are in CLO Assumptions; OC flags / marks in Pool; budget / constraints in Optimization.','B48':'Input status','D48':FormulaCell('trident_ui_input_freshness_status','UNCHANGED INPUTS')})
    package.write_cells('CLO Analysis',{'B8':FormulaCell('"Input status: "&trident_ui_input_freshness_status','Input status: UNCHANGED INPUTS')})
    package.write_cells('CLO Analysis',{'B3':'Calculated results | '+now+' | Select a complete saved case below.','B4':'Opening portfolio metrics describe the selected case snapshot. WF date controls coverage views; full dated analysis is stored in the detailed Results tables.','J7':'All listed cases include complete projections and portfolio results.','B104':'Agency ratings and factor systems require declared sources; synthetic TEST factors are labelled separately.','M13':FormulaCell('IF(COUNT(tbl_trident_ui_view_coverage_minima[Minimum gate OC headroom])=0,"n.a.",MIN(tbl_trident_ui_view_coverage_minima[Minimum gate OC headroom]))')})
    # The funding card is J12:J15; E12:E15 owns MOIC. Update both workflows
    # explicitly, so opening a closing file after an Existing CLO run cannot
    # leave a stale mark label or a broken MATCH against the former metric.
    existing=run.baseline.clo_opening_state is not None
    funding_label='Current equity value' if existing else 'Equity funding'
    return_basis='Forward from sourced opening mark' if existing else 'Full-CLO lifecycle'
    package.write_cells('CLO Analysis',{
        'B13':FormulaCell('INDEX(tbl_trident_ui_dashboard[Saved Base Case],MATCH("Equity IRR",tbl_trident_ui_dashboard[Metric],0))',available(run.baseline.equity_irr.value)),
        'E12':'Equity MOIC',
        'E13':FormulaCell('INDEX(tbl_trident_ui_dashboard[Saved Base Case],MATCH("Equity MOIC",tbl_trident_ui_dashboard[Metric],0))',available(run.baseline.equity_moic.value)),
        'J12':funding_label,
        'J13':FormulaCell('INDEX(tbl_trident_ui_dashboard[Saved Base Case],MATCH("'+funding_label+'",tbl_trident_ui_dashboard[Metric],0))',abs(run.baseline.equity_cashflows[0].amount) if run.baseline.equity_cashflows else NA),
        'J15':'EUR sourced opening mark' if existing else 'EUR closing cash',
        'B15':return_basis,'E15':return_basis,
        'E54':FormulaCell('INDEX(tbl_trident_ui_dashboard[Saved Base Case],MATCH("Equity IRR",tbl_trident_ui_dashboard[Metric],0))' if existing else '"n.a."',run.baseline.equity_irr.value if existing else NA),
        'H54':run.baseline.equity_irr.status.value if existing else 'NOT_APPLICABLE',
    })
    package.write_cells('Waterfall',{'B4':'Full per-period, per-tranche calculated waterfall. Case follows CLO Analysis; choose the tranche below.'})
    for sheet in ('Asset Library','Asset Schedules','Asset Cashflows','Market Data','CLO Assumptions','Collateral Pool','Capital Stack','Scenarios','Trade Universe','Optimization','Trades & Comparison','Checks'):
        if sheet!='Market Data':package.write_cells(sheet,{'B4':'Edit owning input cells, save and close Excel, then run Run_Model.cmd. Output selectors filter complete saved results.'})
    package.write_cells('Optimization',{'B3':'Choose closing candidate replay or static snapshot research. Constraints tighten the inherited deal limits; trades remain unexecuted.'})
    package.write_cells('Trades & Comparison',{'E7':'Choose a full calculated case or STATIC proposal statistics. Base, Proposed and Delta use matching units and scope.','J7':'Proposed trades are research outputs. STATIC has no projected IRR; full replay cases are saved separately.'})
    package.refresh_display_views(run)
    _input_limit_formats(package,run)
    package.refresh_input_witnesses(run.inputs)
    package.invalidate_chart_caches()
    package.refresh_capacity_registry()
    package.save(destination,overwrite=True)


def _record_formats(package,name,records,unit,columns,*,metric_column=None):
    """Apply semantic formats to mixed-unit records without changing values.

    Full audit and scenario Tables remain inspectable even when hidden. Their
    value columns contain rates, face, factors and years; formatting them all
    as currency would make correct calculations difficult to review.
    """
    from .interface_package import _column
    info=package.table_inventory()[name];updates={}
    for index,record in enumerate(records,info.bounds[1]+1):
        for header in columns:
            if header in info.headers:
                address=f'{_column(info.bounds[0]+info.headers.index(header))}{index}'
                updates[address]=(metric_format(record.get(metric_column),record.get(unit))
                                  if metric_column is not None else unit_format(record.get(unit,'')))
    package.set_cell_number_formats(info.sheet,updates)


def _mixed_formats(package,name,cases):
    """Format every saved value by its declared unit, including hidden backing.

    This prevents one column's first numeric style from displaying an annual
    rate as money or a cash amount as a percent. Units are stable by metric;
    records may differ in availability without changing their number format.
    """
    targets={
      PREFIX+'dashboard':('Unit',('Saved Base Case',)),
      PREFIX+'metrics':('Unit',('Value',)),
      PREFIX+'view_scope_metrics':('Unit',('Value',)),
      PREFIX+'economics':('Unit',('Value',)),
      PREFIX+'analysis_details':('Unit',('Value',)),
      PREFIX+'comparison_reader':('Unit',('Saved Base','Proposed','Delta')),
    }
    if name not in targets:return
    from .interface_package import _column
    unit,columns=targets[name];info=package.table_inventory()[name]
    base=cases.get('BASELINE',next(iter(cases.values()),()))
    # Currency alone cannot distinguish face inventory from cash funding;
    # known metric IDs/labels refine that display distinction without changing
    # the declared Unit or any stored result value.
    metric_column='Economics metric' if 'Economics metric' in info.headers else 'Metric'
    updates={}
    for index,r in enumerate(base,info.bounds[1]+1):
        for h in columns:updates[f'{_column(info.bounds[0]+info.headers.index(h))}{index}']=metric_format(r.get(metric_column),r.get(unit))
    package.set_cell_number_formats(info.sheet,updates)
    backing=package.table_inventory()[PREFIX+'results_'+name.removeprefix(PREFIX)]
    updates={};row=backing.bounds[1]+1
    for records in cases.values():
        for r in records:
            for h in columns:updates[f'{_column(backing.bounds[0]+backing.headers.index(h))}{row}']=metric_format(r.get(metric_column),r.get(unit))
            row+=1
    package.set_cell_number_formats(backing.sheet,updates)


def _portfolio_limit_formats(portfolio):
    """Join each legal limit to its measured metric's unit, never its label.

    Concentration limits have no separate metric record in the published
    portfolio metrics; their established concentration: ID supplies fraction
    semantics. Missing/custom units fall back to General, including when the
    measured value is unavailable but the threshold is populated.
    """
    units={metric.name:metric.unit for metric in getattr(portfolio,'metrics',())}
    return {limit.limit_id:metric_format(limit.metric,units.get(limit.metric))
            for limit in getattr(portfolio,'limits',())}


def _set_row_formats(package,name,formats,columns):
    """Apply row-specific formats to an existing named output Table only."""
    from .interface_package import _column
    info=package.table_inventory()[name]
    offsets={header:info.headers.index(header) for header in columns if header in info.headers}
    updates={f'{_column(info.bounds[0]+offset)}{ordinal}':fmt
             for ordinal,fmt in enumerate(formats,info.bounds[1]+1)
             for offset in offsets.values()}
    package.set_cell_number_formats(info.sheet,updates)


def _limit_result_formats(package,name,cases,run):
    """Format the selected reader and every complete case's limit records.

    A limit result lacks a Unit column. Resolve its Limit ID inside the same
    case's opening portfolio, then join that limit's metric to that portfolio's
    units. Row ordering and IDs can differ between cases; applying the baseline
    row's percentage style to the next case would misstate factors/WAL/cash.
    No record columns or report schemas are added for this display-only join.
    """
    by_case={case.case_id:_portfolio_limit_formats(case.result.opening_portfolio)
             for case in run.cases}
    selected=str(package.read_scalar('trident_ui_analysis_case'))
    selected_rows=cases.get(selected,())
    _set_row_formats(package,name,
                    (by_case.get(selected,{}).get(row['Limit'],'General') for row in selected_rows),
                    ('Value','Threshold','Headroom'))
    backing=PREFIX+'results_'+name.removeprefix(PREFIX)
    _set_row_formats(package,backing,
                    (by_case.get(case_id,{}).get(row['Limit'],'General')
                     for case_id,rows in cases.items() for row in rows),
                    ('Value','Threshold','Headroom'))


def _audit_limit_formats(package,name,records,run):
    """Use the same case/date/phase as each dated audit limit observation.

    The audit includes opening and lifetime snapshots. Matching only Limit ID
    or a baseline portfolio silently borrows another case's units. Index the
    actual observation once so display work is linear in reported records;
    unknown context/units stay General rather than inventing a measurement.
    """
    indexed={}
    for case in run.cases:
        result=case.result
        reports=getattr(result,'portfolio_observations',()) or (
            result.opening_portfolio,*getattr(result,'portfolio_snapshots',()))
        for report in reports:
            for limit_id,fmt in _portfolio_limit_formats(report).items():
                indexed[(case.case_id,report.as_of_date,available(report.phase),limit_id)]=fmt
    _set_row_formats(package,name,
                    (indexed.get((row['Case'],row['as_of_date'],row['phase'],row['limit_id']),'General')
                     for row in records),('value','threshold','headroom'))


def _input_limit_formats(package,run):
    """Keep owning mixed Threshold inputs readable without rewriting payloads.

    A future added WARF/WAS/WAL limit must not inherit the first concentration
    row's percentage format. Filled rows resolve the declared Metric; unused
    reserved rows stay General. Protected Tables/names grant explicit style-
    only permission here: numeric values, formulas and date types never change.
    """
    from .interface_package import _column,_overlap
    name=PREFIX+'limits'
    info=package.table_inventory().get(name)
    if info is None or 'Threshold' not in info.headers or 'Metric' not in info.headers:
        return
    units={metric.name:metric.unit for metric in run.baseline.opening_portfolio.metrics}
    rows=package._table_records(name)
    column=_column(info.bounds[0]+info.headers.index('Threshold'))
    formats={f'{column}{info.bounds[1]+ordinal}':metric_format(row.get('Metric'),units.get(row.get('Metric')))
             for ordinal,row in enumerate(rows,1)}
    # Scope the style exception to protected aliases overlapping this owning
    # Table. Other protected scalar/input regions retain their ordinary guard.
    names=[]
    for owner in package.protected_names:
        sheet,bounds=package.named_region(owner)
        if sheet==info.sheet and _overlap(bounds,info.bounds):
            names.append(owner)
    package.set_cell_number_formats(info.sheet,formats,
        allow_protected_names=names,
        allow_protected_tables=(name,) if name in package.protected_tables else ())
