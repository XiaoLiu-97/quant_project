"""Named Excel acceptance controls with independent small financial ledgers.

Every test edits an isolated input-template copy. Expected coupons, cash,
settlement balances and benchmark values are written from calendar arithmetic
or explicit hand transactions, never copied from the calculated catalog.
Read-only checks and rejected runs must preserve saved artifacts byte for byte.
"""

from contextlib import redirect_stderr, redirect_stdout
from datetime import date
from decimal import Decimal
from io import StringIO
import json
from pathlib import Path
import tempfile
import unittest

from openpyxl import load_workbook

from trident.adapters import excel_schema as schema, pilot_schema
from trident.adapters.excel import NamedWorkbook, run_workbook
from trident.adapters.pilot_workbook import check_model_workbook
from trident.cli import main
from trident.domain.models import InputValidationError
from workbook_fixtures import copy_input_template, hand_controls, put_records, write_controls


D = Decimal
START, OPEN, PAY = date(2026, 1, 1), date(2026, 2, 1), date(2026, 4, 1)
COMMIT, SETTLE, LEDGER_END = date(2026, 2, 2), date(2026, 2, 3), date(2026, 2, 4)
SOURCE = "Independent signed coupon and settlement hand ledger"


def benchmark(kind, identity, metric, stage, expected, *, day=PAY, unit="EUR", reference=None):
    """Literal external expectation with a complete semantic reconciliation key."""
    return dict(observation_date=day, entity_type=kind, entity_id=identity, metric=metric,
                stage=stage, expected=expected, tolerance=0, unit=unit, source=SOURCE,
                reference_id=reference or f"HAND-{kind}-{identity}-{metric}")


class PilotWorkbookAcceptanceTests(unittest.TestCase):
    def setUp(self):
        folder = tempfile.TemporaryDirectory()
        self.addCleanup(folder.cleanup)
        self.path = Path(folder.name) / "isolated_model.xlsx"
        copy_input_template(self.path)
        self._small_seasoned_case()

    @staticmethod
    def table(adapter, key):
        return adapter.table_records(schema.TABLE_RANGE_NAMES[key], schema.TABLE_NAMES[key])

    def access(self, function, *, save=False):
        book = load_workbook(self.path)
        try:
            value = function(NamedWorkbook(book))
            if save:
                book.save(self.path)
            return value
        finally:
            book.close()

    def edit_table(self, key, rows):
        self.access(lambda adapter: put_records(adapter, key, rows), save=True)

    def _small_seasoned_case(self, *, floating=False):
        """Original Jan-Apr asset; newly issued Feb-Apr note; zero charges.

        Full coupon ownership is 100*12%*90/360=3.00. Note ownership starts
        Feb1:80*6%*59/360=.79. Equity pays21.03 and receives22.21. A floating
        control instead uses observed2% plus400bps, not the flat9% scenario.
        """
        def edit(adapter):
            asset = dict(self.table(adapter, "assets")[0])
            asset.update(loan_id="L", initial_par=100, current_par=100,
                cashflow_projection_start_date=START, par_as_of_date=OPEN,
                maturity_date_unadjusted=PAY, schedule_anchor_day=1,
                frequency_months=3, day_count="ACT/360", business_day_convention="UNADJUSTED",
                accrual_date_basis="UNADJUSTED", fixing_lag_target_business_days=0,
                coupon_type="FLOATING" if floating else "FIXED",
                fixed_rate=None if floating else .12,
                rate_index="EURIBOR_3M" if floating else None,
                spread_bps=400 if floating else 0, index_floor_bps=None,
                reset_frequency_months=None, index_cap_bps=None,
                all_in_floor_bps=None, all_in_cap_bps=None,
                amortization_type="BULLET", amortization_fraction_initial_par_per_period=0,
                amortization_first_date_unadjusted=None, amortization_periods_remaining=None,
                scheduled_principal_amount=None, amortization_growth=None, balloon_amount=None,
                first_payment_date_unadjusted=None, last_regular_payment_date_unadjusted=None,
                purchase_price_pct=100, acquired_accrued_interest=.52 if floating else 1.03)
            capital = self.table(adapter, "capital_stack")
            debt = dict(next(row for row in capital if row["instrument_type"] == "DEBT"))
            debt.update(class_id="A", nominal_amount=80, issue_price_pct=100,
                coupon_type="FIXED", fixed_rate=.06, rate_index=None,
                spread_bps=0, index_floor_bps=None, oc_minimum=None, ic_minimum=None)
            equity = dict(next(row for row in capital if row["instrument_type"] == "EQUITY"))
            equity.update(class_id="EQUITY", nominal_amount=20, issue_price_pct=100)
            # Clear unrelated optional scenarios, trades and references before
            # authoring this one small case; retain the explicit factor mapping.
            for key in schema.INPUT_TABLE_KEYS:
                if key not in {"assets", "capital_stack", "factor_mapping"}:
                    put_records(adapter, key, ())
            put_records(adapter, "assets", (asset,))
            put_records(adapter, "capital_stack", (debt, equity))
            controls = hand_controls((asset,), (debt, equity), closing_date=OPEN,
                                     first_payment_date=PAY, legal_final_date=PAY)
            controls.update(legacy_payment_date_convention="Unadjusted",
                clo_accrual_date_basis="UNADJUSTED", legacy_rate_fixing_lag=0,
                legacy_determination_lag=0, synthetic_rate=.09 if floating else 0,
                legacy_purchased_accrued_interest=.52 if floating else 1.03)
            write_controls(adapter, controls)
            put_records(adapter, "seasoned_positions", ({"scope": "ASSET", "loan_id": "L",
                "opening_accrued_interest": .52 if floating else 1.03,
                "entitlement_policy": "FULL_CURRENT_PERIOD", "source": SOURCE},))
            if floating:
                put_records(adapter, "opening_fixings", ({"scope": "ASSET", "loan_id": "L",
                    "fixing_date": START, "index_rate": .02},))
        self.access(edit, save=True)

    def _coupon_benchmarks(self):
        return (benchmark("ASSET_CONTRACT", "L", "cash_interest", "CONTRACTUAL", "3.00"),
                benchmark("TRANCHE", "A", "current_coupon_due", "WATERFALL", ".79"),
                benchmark("SCALAR", "DEAL", "result_equity_distributions", "BASELINE", "22.21", day=OPEN))

    def _ledger_inputs(self, *, pending=False):
        """An independent operating ledger; no cash is inferred from the CLO."""
        def edit(adapter):
            put_records(adapter, "ledger_controls", ({"as_of_date": OPEN,
                "horizon_date": LEDGER_END, "currency": "EUR", "principal_cash": 100,
                "interest_cash": 10, "allow_principal_for_accrued": False,
                "allow_principal_for_fees": False, "source": "Verified opening bank balances"},))
            put_records(adapter, "opening_holdings", ({"asset_id": "L", "currency": "EUR",
                "settled_par": 100, "status": "PERFORMING"},))
            put_records(adapter, "trade_ledger", ({"trade_id": "BUY", "asset_id": "Y", "side": "BUY",
                "trade_date": date(2026, 1, 31) if pending else COMMIT,
                "settlement_date": date(2026, 2, 5) if pending else SETTLE,
                "par": 50, "clean_price_pct": 100, "accrued_cash": 1, "fees_cash": .50,
                "accrued_account": "INTEREST", "fee_account": "INTEREST",
                "lot_size": 25, "minimum_ticket": 25, "maximum_par": 50},))
            put_records(adapter, "opening_receivables", ({"receivable_id": "R", "asset_id": "L",
                "recognition_date": date(2026, 1, 31), "due_date": SETTLE,
                "principal_cash": 5, "interest_cash": 2, "source": "Verified agent receivable"},))
            if not pending:
                put_records(adapter, "ledger_events", (
                    {"event_id": "INCOME", "event_date": COMMIT, "kind": "CASH_COLLECTION",
                     "asset_id": "L", "interest_cash": 3, "source": "Actual loan-agent income"},
                    {"event_id": "PAYMENT", "event_date": COMMIT, "kind": "CASH_PAYMENT",
                     "principal_cash": 2, "interest_cash": 1, "source": "Actual trustee payment"},
                    {"event_id": "RECEIPT", "event_date": SETTLE, "kind": "RECEIVABLE_COLLECTION",
                     "asset_id": "L", "receivable_id": "R", "principal_cash": 5,
                     "interest_cash": 2, "source": "Actual matched claim receipt"},
                    {"event_id": "DEFAULT", "event_date": LEDGER_END, "kind": "DEFAULT",
                     "asset_id": "Y", "source": "Verified default notice"},
                ))
        self.access(edit, save=True)

    def test_named_interfaces_publish_seasoned_cash_and_independent_matches(self):
        self.edit_table("benchmarks", self._coupon_benchmarks())
        result = run_workbook(self.path)
        self.assertEqual(result.cashflows.total_interest, D(3))
        self.assertEqual(result.cashflows.funding.equity_cash_funding, D("21.03"))
        self.assertEqual(result.clo.periods[0].note_coupon_due, D(".79"))
        self.assertEqual(result.clo.total_equity_distributions, D("22.21"))
        def check(adapter):
            # All operational interfaces are real named Tables, with no cell
            # coordinate serving as a financial test key.
            for key in pilot_schema.DESCRIPTORS:
                self.table(adapter, key)
            audit, = self.table(adapter, "run_audit")
            self.assertEqual(audit["readiness_status"], "BENCHMARK_SCOPE_MATCHED")
            self.assertEqual(audit["reconciliation_status"], "MATCH")
            self.assertEqual(audit["ledger_status"], "NOT_CONFIGURED")
            accrued, = self.table(adapter, "seasoned_audit")
            self.assertEqual(accrued["original_anchor"].date(), START)
            self.assertEqual(accrued["projection_date"].date(), OPEN)
            self.assertEqual(accrued["first_cash_interest"], 3)
            self.assertEqual(accrued["opening_accrued_interest"], 1.03)
            comparisons = self.table(adapter, "reconciliation_results")
            self.assertEqual([row["status"] for row in comparisons], ["MATCH"] * 3)
            self.assertTrue(all(row["source"] == SOURCE for row in comparisons))
            self.assertEqual(comparisons[0]["expected"], 3)
            self.assertEqual(comparisons[0]["reference_id"], "HAND-ASSET_CONTRACT-L-cash_interest")
            paid, = self.table(adapter, "tranche_cashflows")
            self.assertEqual(paid["current_coupon_due"], .79)
        self.access(check)

    def test_original_carried_rate_reaches_named_outputs_instead_of_flat_scenario(self):
        self._small_seasoned_case(floating=True)
        result = run_workbook(self.path)
        row, = result.cashflows.cashflows
        self.assertEqual(row.fixing_date, START)
        self.assertEqual(row.index_rate, D(".02"))
        self.assertEqual(row.cash_interest, D("1.50"))
        self.assertEqual(result.clo.total_equity_distributions, D("20.71"))
        self.access(lambda adapter: self.assertEqual(
            self.table(adapter, "seasoned_audit")[0]["historical_fixing_count"], 1))

    def test_check_model_is_read_only_and_saved_input_edit_marks_results_stale(self):
        self.edit_table("benchmarks", self._coupon_benchmarks())
        run_workbook(self.path)
        before = self.path.read_bytes()
        stdout, stderr = StringIO(), StringIO()
        with redirect_stdout(stdout), redirect_stderr(stderr):
            code = main(["check-model", str(self.path), "--project", "--require-reconciliation"])
        self.assertEqual(code, 0, stderr.getvalue())
        report = json.loads(stdout.getvalue())
        self.assertEqual(report["saved_results"], "CURRENT")
        self.assertEqual(report["reconciliation"], "MATCH")
        self.assertTrue(report["read_only"])
        self.assertEqual(self.path.read_bytes(), before)
        self.access(lambda adapter: adapter.write_scalar(
            schema.SCALAR_NAMES["legacy_other_upfront_costs"], 1), save=True)
        changed = self.path.read_bytes()
        report = check_model_workbook(self.path)
        self.assertEqual(report["saved_results"], "STALE_OR_NOT_RUN")
        self.assertEqual(report["status"], "INPUT_READY")
        self.assertEqual(self.path.read_bytes(), changed)

    def test_absent_benchmarks_do_not_pass_required_reconciliation(self):
        run_workbook(self.path)
        self.access(lambda adapter: self.assertEqual(
            self.table(adapter, "run_audit")[0]["reconciliation_status"], "NOT_CONFIGURED"))
        before = self.path.read_bytes()
        report = check_model_workbook(self.path, project=True, require_reconciliation=True)
        self.assertEqual(report["status"], "REVIEW_FAILED")
        self.assertEqual(report["reconciliation"], "NOT_CONFIGURED")
        self.assertEqual(self.path.read_bytes(), before)

    def test_mismatch_unavailable_missing_key_and_unit_mismatch_remain_visible(self):
        self.edit_table("benchmarks", (
            benchmark("ASSET_CONTRACT", "L", "cash_interest", "CONTRACTUAL", "3.01"),
            benchmark("SCALAR", "DEAL", "result_was_bps", "BASELINE", "1", day=OPEN, unit="BPS"),
            benchmark("ASSET_CONTRACT", "UNKNOWN", "cash_interest", "CONTRACTUAL", "0"),
            benchmark("ASSET_CONTRACT", "L", "interest_unrounded", "CONTRACTUAL", "3", unit="USD"),
        ))
        run_workbook(self.path)
        def check(adapter):
            rows = self.table(adapter, "reconciliation_results")
            self.assertEqual([row["status"] for row in rows], ["MISMATCH", "UNAVAILABLE", "UNAVAILABLE", "UNAVAILABLE"])
            self.assertEqual(rows[0]["difference"], -.01)
            self.assertIsNone(rows[1]["actual"])
            self.assertIsNone(rows[2]["actual"])
            self.assertIn("Unit mismatch", rows[3]["message"])
            audit, = self.table(adapter, "run_audit")
            self.assertEqual(audit["readiness_status"], "REVIEW_FAILED")
            self.assertEqual(audit["reconciliation_status"], "UNAVAILABLE")
        self.access(check)
        before = self.path.read_bytes()
        self.assertEqual(check_model_workbook(self.path, project=True)["status"], "REVIEW_FAILED")
        self.assertEqual(self.path.read_bytes(), before)

    def test_invalid_or_missing_carried_fixing_preserves_source_and_destination(self):
        self._small_seasoned_case(floating=True)
        destination = self.path.with_name("existing_destination.xlsx")
        destination.write_bytes(b"UNTOUCHED_EXISTING_ARTIFACT")
        invalid = ((),
            ({"scope": "ASSET", "loan_id": "L", "fixing_date": date(2026, 1, 2), "index_rate": .02},),
            ({"scope": "ASSET", "loan_id": "L", "fixing_date": START, "index_rate": .02},) * 2,
            ({"scope": "ASSET", "loan_id": "L", "fixing_date": PAY, "index_rate": .02},))
        for fixings in invalid:
            with self.subTest(fixings=fixings):
                self.edit_table("opening_fixings", fixings)
                before = self.path.read_bytes()
                with self.assertRaises(InputValidationError):
                    run_workbook(self.path, destination)
                self.assertEqual(self.path.read_bytes(), before)
                self.assertEqual(destination.read_bytes(), b"UNTOUCHED_EXISTING_ARTIFACT")

    def test_actual_ledger_commitment_settlement_and_claim_receipt_reconcile(self):
        self._ledger_inputs()
        self.edit_table("benchmarks", (
            benchmark("LEDGER_CASH", "LEDGER", "principal_cash", "END_OF_DAY", "53", day=LEDGER_END),
            benchmark("LEDGER_CASH", "LEDGER", "interest_cash", "END_OF_DAY", "12.50", day=LEDGER_END),
            benchmark("LEDGER_CASH", "LEDGER", "settled_par", "END_OF_DAY", "150", day=LEDGER_END),
        ))
        result = run_workbook(self.path)
        # The operating ledger is a separate actual-state review. Its explicit
        # cash events/default notice never alter this new CLO's projected cash.
        self.assertEqual(result.clo.total_equity_distributions, D("22.21"))
        def check(adapter):
            cash = {row["as_of_date"].date(): row for row in self.table(adapter, "ledger_snapshots")}
            commit, final = cash[COMMIT], cash[LEDGER_END]
            self.assertEqual((commit["principal_cash"], commit["interest_cash"]), (98, 12))
            self.assertEqual((commit["reserved_principal"], commit["reserved_interest"]), (50, 1.5))
            self.assertEqual((commit["settled_par"], commit["committed_buy_par"], commit["trade_date_par"]), (100, 50, 150))
            self.assertEqual((final["principal_cash"], final["interest_cash"]), (53, 12.5))
            self.assertEqual((final["performing_par"], final["defaulted_par"], final["settled_par"]), (100, 50, 150))
            self.assertEqual((final["reserved_principal"], final["receivable_principal"]), (0, 0))
            self.assertEqual(self.table(adapter, "ledger_pending"), ())
            journal = self.table(adapter, "ledger_journal")
            receipt = next(row for row in journal if row["event_type"] == "RECEIVABLE_COLLECTION")
            self.assertEqual(receipt["source"], "Actual matched claim receipt")
            audit, = self.table(adapter, "run_audit")
            self.assertEqual(audit["ledger_status"], "REPLAYED_EXPLICIT_INPUTS")
            self.assertEqual(audit["reconciliation_status"], "MATCH")
        self.access(check)

    def test_opening_pending_buy_and_due_claim_do_not_create_cash_or_settled_par(self):
        self._ledger_inputs(pending=True)
        run_workbook(self.path)
        def check(adapter):
            final = self.table(adapter, "ledger_snapshots")[-1]
            self.assertEqual((final["principal_cash"], final["interest_cash"]), (100, 10))
            self.assertEqual((final["settled_par"], final["committed_buy_par"], final["trade_date_par"]), (100, 50, 150))
            self.assertEqual((final["available_principal"], final["available_interest"]), (50, 8.5))
            self.assertEqual((final["receivable_principal"], final["receivable_interest"]), (5, 2))
            pending = self.table(adapter, "ledger_pending")
            self.assertEqual({row["kind"] for row in pending}, {"COMMITMENT", "RECEIVABLE"})
            self.assertEqual(self.table(adapter, "ledger_journal"), ())
        self.access(check)

    def test_orphan_or_overdrawn_operating_inputs_fail_before_atomic_save(self):
        self.edit_table("opening_holdings", ({"asset_id": "L", "currency": "EUR",
            "settled_par": 100, "status": "PERFORMING"},))
        before = self.path.read_bytes()
        with self.assertRaisesRegex(InputValidationError, "Ledger Controls"):
            run_workbook(self.path)
        self.assertEqual(self.path.read_bytes(), before)
        self._ledger_inputs()
        self.edit_table("ledger_events", ({"event_id": "OVERDRAW", "event_date": COMMIT,
            "kind": "CASH_PAYMENT", "principal_cash": 101, "source": "Independent debit control"},))
        before = self.path.read_bytes()
        with self.assertRaises(InputValidationError):
            run_workbook(self.path)
        self.assertEqual(self.path.read_bytes(), before)


if __name__ == "__main__":
    unittest.main()
