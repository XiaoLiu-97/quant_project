"""End-to-end named-interface tests using private copies of the delivered UI."""

import tempfile
import unittest
from dataclasses import replace
from datetime import date
from decimal import Decimal
from pathlib import Path

from openpyxl import load_workbook
from workbook_fixtures import copy_input_template
from trident.adapters.clo_example import run_synthetic_clo_example
from trident.adapters.excel import NamedWorkbook, run_workbook
from trident.adapters.excel_model import read_model_workbook_inputs
from trident.adapters import excel_schema as schema
from trident.application.clo_services import TridentModelService
from trident.clo.models import ProjectionStatus
from workbook_fixtures import assert_h00_projection_matches


ROOT = Path(__file__).resolve().parents[1]
EXAMPLE = ROOT / "data/examples/hybrid_500m"
D = Decimal


class ExcelModelRunTests(unittest.TestCase):
    def setUp(self):
        self.folder = tempfile.TemporaryDirectory()
        self.addCleanup(self.folder.cleanup)
        self.path = Path(self.folder.name) / "model.xlsx"
        copy_input_template(self.path)

    def edit(self, function):
        workbook = load_workbook(self.path)
        try:
            function(NamedWorkbook(workbook))
            workbook.save(self.path)
        finally:
            workbook.close()

    def read(self, function):
        workbook = load_workbook(self.path)
        try:
            return function(NamedWorkbook(workbook))
        finally:
            workbook.close()

    @staticmethod
    def table(adapter, key):
        return adapter.table_records(schema.TABLE_RANGE_NAMES[key], schema.TABLE_NAMES[key])

    def test_complete_model_and_csv_fixture_have_identical_economics(self):
        actual, fixture = run_workbook(self.path), run_synthetic_clo_example(EXAMPLE)
        assert_h00_projection_matches(self, actual.clo, fixture.clo)
        self.assertEqual(actual.equity_irr, fixture.equity_irr)
        self.assertEqual(actual.opening_portfolio.metric("LONG_DATED_FRACTION").value, 0)
        self.assertEqual(replace(actual.opening_portfolio, limits=fixture.opening_portfolio.limits,
                                metrics=tuple(actual.opening_portfolio.metric(metric.name)
                                              for metric in fixture.opening_portfolio.metrics)),
                         fixture.opening_portfolio)
        self.assertEqual(actual.clo.status, ProjectionStatus.COMPLETED)
        self.assertEqual(actual.clo.total_equity_distributions, D("96115867.54"))
        self.assertEqual(self.read(lambda a: a.scalar(schema.SCALAR_NAMES["result_optimizer_status"])), "DISABLED")
        self.assertEqual(len(self.read(lambda a: self.table(a, "clo_periods"))), 40)
        self.assertEqual(len(self.read(lambda a: self.table(a, "limit_tests"))),
                         sum(len(report.limits) for report in
                             (actual.opening_portfolio, *actual.portfolio_snapshots)))

    def test_cashflow_only_clears_previous_clo_and_return_outputs(self):
        def select_standalone(adapter):
            adapter.write_scalar(schema.SCALAR_NAMES["mode"], "CASHFLOW_ONLY")
            adapter.write_scalar(schema.SCALAR_NAMES["scenario_enabled"], False)
        self.edit(select_standalone)
        result = run_workbook(self.path)
        self.assertIsNone(result.clo)
        self.assertIsNone(self.read(lambda a: a.scalar(schema.SCALAR_NAMES["result_equity_irr"])))
        for key in ("clo_periods", "tranche_cashflows", "coverage_tests", "equity_cashflows"):
            self.assertEqual(self.read(lambda a, k=key: self.table(a, k)), ())

    def test_capital_stack_change_recalculates_actual_investor_returns(self):
        def edit(a):
            rows = tuple(dict(row) for row in self.table(a, "capital_stack"))
            rows[0]["spread_bps"] = 200
            a.write_table(schema.TABLE_RANGE_NAMES["capital_stack"], schema.TABLE_NAMES["capital_stack"], rows)
        self.edit(edit)
        result = run_workbook(self.path)
        self.assertLess(result.equity_irr.value, D(".09980827792719147"))
        self.assertLess(result.clo.periods[0].equity_from_interest, D("1894781.51"))

    def test_invalid_header_is_rejected_without_saving_any_outputs(self):
        def edit(a):
            sheet, (left, top, _, _) = a.region(schema.TABLE_RANGE_NAMES["portfolio_limits"])
            sheet.cell(top, left).value = "WRONG_LIMIT_HEADER"
        self.edit(edit)
        before = self.path.read_bytes()
        with self.assertRaises(ValueError):
            run_workbook(self.path)
        self.assertEqual(self.path.read_bytes(), before)

    def test_named_formula_input_is_rejected_atomically(self):
        def edit(a):
            sheet, (left, top, _, _) = a.region(schema.SCALAR_NAMES["legacy_senior_management_fee"])
            sheet.cell(top, left).value = "=15+1"
        self.edit(edit)
        before = self.path.read_bytes()
        with self.assertRaisesRegex(ValueError, "formula"):
            run_workbook(self.path)
        self.assertEqual(self.path.read_bytes(), before)

    def enable_quotes(self, *, accrued=0, settlement=date(2026, 11, 20)):
        def edit(a):
            sold = next(row for row in self.table(a, "assets") if row["asset_class"] == "BSL" and row["test_factor_bucket"] == "TEST_06")
            common = {"asset_class": "BSL", "country_code": sold["country_code"], "sector": sold["sector"],
                      "currency": "EUR", "maximum_par": 1500000, "accrued_per_par": accrued,
                      "proportional_fee_per_par": 0, "lot_size": 500000, "minimum_ticket": 500000, "fixed_fee": 0}
            rows = (
                {**common, "asset_id": sold["loan_id"], "side": "SELL", "obligor_id": sold["obligor_id"],
                 "spread_bps": sold["spread_bps"], "factor_bucket": sold["test_factor_bucket"], "clean_price_pct": 100},
                {**common, "asset_id": "NEW_SYNTHETIC_BSL", "side": "BUY", "obligor_id": "NEW_SYNTHETIC_OBLIGOR",
                 "spread_bps": 400, "factor_bucket": "TEST_02", "clean_price_pct": 98.5},
            )
            a.write_table(schema.TABLE_RANGE_NAMES["trade_candidates"], schema.TABLE_NAMES["trade_candidates"], rows)
            a.write_scalar(schema.SCALAR_NAMES["optimizer_enabled"], True)
            a.write_scalar(schema.SCALAR_NAMES["optimizer_settlement_date"], settlement)
        self.edit(edit)

    def test_milp_trade_proposal_is_static_bsl_only_and_clo_is_not_replayed(self):
        self.enable_quotes()
        result = run_workbook(self.path)
        trades = self.read(lambda a: self.table(a, "optimizer_trades"))
        summary = {row["name"]: row["value"] for row in self.read(lambda a: self.table(a, "optimizer_summary"))}
        self.assertEqual(summary["status"], "OPTIMAL")
        self.assertEqual(summary["validation_scope"], "STATIC_ONLY")
        self.assertEqual(summary["clo_replay_status"], "NOT_RUN")
        self.assertEqual(summary["portfolio_limit_table_validation"], "NOT_RUN")
        self.assertEqual(len(trades), 2)
        self.assertEqual({row["side"] for row in trades}, {"BUY", "SELL"})
        self.assertTrue(all(row["par"] == 1500000 for row in trades))
        self.assertEqual(summary["ending_cash"], 22500)
        self.assertEqual(summary["ending_par"], 500000000)
        self.assertLess(summary["overall_factor"], 2120)
        self.assertEqual(result.clo.total_equity_distributions, D("96115867.54"))

    def test_accrued_trade_interest_cannot_be_spent_as_principal_cash(self):
        self.enable_quotes(accrued=.01)
        before = self.path.read_bytes()
        with self.assertRaisesRegex(ValueError, "zero accrued"):
            run_workbook(self.path)
        self.assertEqual(self.path.read_bytes(), before)

    def test_future_trade_requires_event_state_replay(self):
        self.enable_quotes(settlement=date(2027, 2, 22))
        with self.assertRaisesRegex(ValueError, "opening holdings date"):
            run_workbook(self.path)

    def test_typed_exposure_spread_and_maturity_must_match_cashflow_terms(self):
        # Reuse the single current named-input boundary before service execution.
        model = self.read(lambda adapter: read_model_workbook_inputs(adapter).request)
        for change in ({"spread_bps": D(999)}, {"maturity_date": date(2035, 1, 1)}):
            exposure = replace(model.exposures[0], **change)
            with self.subTest(change=change), self.assertRaisesRegex(ValueError, "maturity/spread"):
                TridentModelService().run(replace(model, exposures=(exposure, *model.exposures[1:])))


if __name__ == "__main__":
    unittest.main()
