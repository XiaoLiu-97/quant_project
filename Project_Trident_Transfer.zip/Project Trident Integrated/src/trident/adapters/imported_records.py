"""Named-column transport for the old detailed 24 / simplified 9 input contracts.

Original source labels are accepted for copy/paste compatibility; new named
Tables can use canonical semantic headers. Financial calculations consume the
typed source objects and never depend on worksheet coordinates.
"""

from collections.abc import Mapping
from decimal import Decimal

from trident.application.imported_cashflows import DetailedImportedCashflow, SimplifiedImportedCashflow
from trident.domain.models import InputValidationError
from trident.domain.numeric import post_currency
from fractions import Fraction

from .records import date_value, decimal_value, integer_value

DETAILED_COLUMNS = (
    "asset_id", "period", "accrual_start", "accrual_end", "payment_date", "beginning_notional",
    "coupon_type", "reference_index", "reset_frequency", "first_fixing_date", "last_fixing_date",
    "reset_observation_count", "weighted_base_rate", "weighted_spread_bps", "effective_all_in_rate",
    "day_count_fraction", "gross_interest", "cash_interest", "pik_interest", "principal_repayment",
    "ending_notional", "total_cash_payment", "notes", "currency",
)
DETAILED_SOURCE_HEADERS = (
    "Asset ID", "Period", "Accrual Start", "Accrual End", "Payment Date", "Beginning Notional (Local Ccy)",
    "Coupon Type", "Reference Index", "Reset Frequency", "First Fixing / Observation Date",
    "Last Fixing / Observation Date", "Reset / Observation Count", "Weighted Base Rate", "Weighted Spread (bps)",
    "Effective All-in Rate", "Day Count Fraction", "Gross Interest (Local Ccy)", "Cash Interest (Local Ccy)",
    "PIK Interest (Local Ccy)", "Principal Repayment (Local Ccy)", "Ending Notional (Local Ccy)",
    "Total Cash Payment (Local Ccy)", "Notes", "Currency",
)
SIMPLIFIED_COLUMNS = (
    "payment_date", "interest_proceeds", "principal_proceeds", "performing_par_reduction",
    "ending_performing_par", "defaulted_par_memo", "recovery_proceeds_memo", "currency", "source_notes",
)
SIMPLIFIED_SOURCE_HEADERS = (
    "Payment Date", "Interest Proceeds", "Principal Proceeds", "Performing Par Reduction (Optional)",
    "Ending Performing Par (Optional)", "Defaulted Par (Memo, Optional)", "Recovery Proceeds (Memo, Optional)",
    "Currency (Optional)", "Source / Notes",
)


def _canonical(row: Mapping[str, object], columns, headers):
    if not isinstance(row, Mapping):
        raise InputValidationError("Imported source row must be a named-column mapping")
    mapping = dict(zip(headers, columns))
    unknown = set(row) - set(columns) - set(headers)
    if unknown:
        raise InputValidationError(f"Unregistered imported source headers: {sorted(unknown)}")
    canonical = {}
    for key, value in row.items():
        key = mapping.get(key, key)
        if key in canonical:
            raise InputValidationError(f"Duplicate semantic imported source header: {key}")
        canonical[key] = value
    return canonical


def _optional(row, key):
    value = row.get(key)
    return None if value in (None, "") else decimal_value(value, key)


def detailed_from_records(rows: tuple[Mapping[str, object], ...]) -> tuple[DetailedImportedCashflow, ...]:
    """Retain explicit cash/PIK/par amounts; external coupon math stays auditable.

    Optional rate/reset fields remain source audit metadata. Where gross interest
    is supplied, gross = cash + PIK is independently cross-checked. No historical
    observed fixing is invented from a weighted external coupon field.
    """
    output = []
    for raw in rows:
        row = _canonical(raw, DETAILED_COLUMNS, DETAILED_SOURCE_HEADERS)
        cash = decimal_value(row.get("cash_interest"), "cash_interest")
        pik = _optional(row, "pik_interest") or Decimal(0)
        gross = _optional(row, "gross_interest")
        if gross is not None and Fraction(gross) != Fraction(cash) + Fraction(pik):
            raise InputValidationError("Detailed gross interest must equal cash interest plus PIK")
        begin = decimal_value(row.get("beginning_notional"), "beginning_notional")
        principal = decimal_value(row.get("principal_repayment"), "principal_repayment")
        ending = decimal_value(row.get("ending_notional"), "ending_notional")
        total = _optional(row, "total_cash_payment")
        if total is None:
            total = post_currency(Fraction(cash) + Fraction(principal))
        start, end = row.get("accrual_start"), row.get("accrual_end")
        identifier = row.get("asset_id")
        notes = row.get("notes")
        output.append(DetailedImportedCashflow(identifier, integer_value(row.get("period"), "period"),
                     date_value(row.get("payment_date"), "payment_date"), begin, cash, principal, ending, total, pik,
                     row.get("currency") or "EUR", notes or "USER_SUPPLIED_DETAILED_CASHFLOW",
                     None if start in (None, "") else date_value(start, "accrual_start"),
                     None if end in (None, "") else date_value(end, "accrual_end")))
    return tuple(output)


def simplified_from_records(rows: tuple[Mapping[str, object], ...]) -> tuple[SimplifiedImportedCashflow, ...]:
    """Parse aggregate rows; blank currency means the explicit base EUR policy."""
    output = []
    for raw in rows:
        row = _canonical(raw, SIMPLIFIED_COLUMNS, SIMPLIFIED_SOURCE_HEADERS)
        output.append(SimplifiedImportedCashflow(
            date_value(row.get("payment_date"), "payment_date"),
            decimal_value(row.get("interest_proceeds"), "interest_proceeds"),
            decimal_value(row.get("principal_proceeds"), "principal_proceeds"),
            _optional(row, "performing_par_reduction"), _optional(row, "ending_performing_par"),
            _optional(row, "defaulted_par_memo") or Decimal(0), _optional(row, "recovery_proceeds_memo") or Decimal(0),
            row.get("currency") or "EUR", row.get("source_notes") or "USER_SUPPLIED_SIMPLIFIED_CASHFLOW"))
    return tuple(output)


def imported_projection_from_records(
    legacy_values: Mapping[str, object],
    detailed_records: tuple[Mapping[str, object], ...] = (),
    simplified_records: tuple[Mapping[str, object], ...] = (),
):
    """Compile named sources using the corresponding typed legacy assumptions."""
    from trident.application.imported_cashflows import CollateralCashflowInputMode, compile_imported_cashflows
    try:
        mode = CollateralCashflowInputMode(str(legacy_values["collateral_cashflow_input_mode"]).upper())
    except (KeyError, ValueError) as error:
        raise InputValidationError("Imported projection requires a valid Collateral Cashflow Input Mode") from error
    return compile_imported_cashflows(
        mode,
        date_value(legacy_values.get("closing_date"), "closing_date"),
        decimal_value(legacy_values.get("opening_collateral_par"), "opening_collateral_par"),
        detailed_from_records(detailed_records) if mode in {CollateralCashflowInputMode.DETAILED, CollateralCashflowInputMode.MIXED} else (),
        simplified_from_records(simplified_records) if mode in {CollateralCashflowInputMode.SIMPLIFIED, CollateralCashflowInputMode.MIXED} else (),
        decimal_value(legacy_values.get("simplified_pool_opening_performing_par", 0), "simplified_pool_opening_performing_par"),
        mode in {CollateralCashflowInputMode.SIMPLIFIED, CollateralCashflowInputMode.MIXED}
            and legacy_values.get("simplified_cashflows_include_credit_prepayment_effects") == "Yes",
        legacy_values.get("credit_prepayment_overlay") == "On",
    )
