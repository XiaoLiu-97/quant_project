"""Strict, shared input checks for financial date conventions."""

from datetime import date


def require_date(value: object, field_name: str) -> date:
    """Accept a plain date only; datetime carries unsupported time semantics."""
    if type(value) is not date:
        raise TypeError(f"{field_name} must be a datetime.date, without a time component")
    return value


def require_integer(value: object, field_name: str) -> int:
    """Reject booleans and numeric coercions at the public API boundary."""
    if type(value) is not int:
        raise TypeError(f"{field_name} must be an integer")
    return value
