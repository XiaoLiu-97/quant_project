"""Migration acceptance through the same named Excel interface used by users.

Small cases assert financial identities and independent contractual cash, not
merely a successful file save. Every workbook is an isolated input fixture;
the published model is neither modified nor used as a financial oracle.
"""

from datetime import date
from decimal import Decimal
from fractions import Fraction
from pathlib import Path
import tempfile
import unittest
from xml.etree import ElementTree

from openpyxl import load_workbook
from workbook_fixtures import copy_input_template, put_records, write_controls
from test_assumption_execution import small_inputs
from trident.adapters import excel_schema as schema
from trident.adapters.excel import NamedWorkbook, run_workbook
from trident.adapters.imported_records import detailed_from_records

D = Decimal


class MigrationWorkbookTests(unittest.TestCase):
    def setUp(self):
        self.directory = tempfile.TemporaryDirectory()
        self.addCleanup(self.directory.cleanup)
        self.path = Path(self.directory.name) / 'model.xlsx'
        copy_input_template(self.path)

    def configure(self, *, currency='EUR', mode='CLO_BASELINE', overnight=False, pik=False):
        assets, capital, controls, factors, _ = small_inputs()
        asset = dict(assets[0], currency=currency, coupon_type='FIXED', fixed_rate=D('.12'),
            spread_bps=0, rate_index=None, index_floor_bps=None, pik=pik,
            interest_mode='PIK' if pik else 'CASH', pik_fraction=1 if pik else 0,
            holiday_calendar='LONDON', day_count='ACT/365F')
        if overnight:
            asset.update(coupon_type='FLOATING', fixed_rate=None, rate_index='SONIA', spread_bps=100)
        notes = tuple(dict(row, currency=currency, pik_rate_fraction=D('.5') if pik and row['instrument_type']=='DEBT' else 0,
                           fixed_rate=D('.04') if row['instrument_type']=='DEBT' else None) for row in capital)
        controls.update(mode=mode, legacy_base_currency=currency, scenario_enabled=False,
            legacy_credit_prepayment_overlay='Off', legacy_reinvestment_enabled='No',
            legacy_upfront_arrangement_fee=0)
        book = load_workbook(self.path)
        try:
            adapter = NamedWorkbook(book)
            put_records(adapter, 'assets', (asset,))
            put_records(adapter, 'capital_stack', notes)
            put_records(adapter, 'factor_mapping', factors)
            put_records(adapter, 'portfolio_limits', ())
            write_controls(adapter, controls)
            book.save(self.path)
        finally:
            book.close()

    def rows(self, key):
        book = load_workbook(self.path)
        try:
            return NamedWorkbook(book).table_records(schema.TABLE_RANGE_NAMES[key], schema.TABLE_NAMES[key])
        finally:
            book.close()

    def test_native_asset_and_note_pik_export_face_and_economics(self):
        self.configure(pik=True)
        result = run_workbook(self.path)
        self.assertEqual(result.cashflows.opening_collateral_par, D(100))
        self.assertGreater(result.cashflows.total_pik_interest, 0)
        self.assertEqual(result.cashflows.total_principal, D(100)+result.cashflows.total_pik_interest)
        detailed = self.rows('cashflow_detailed_export')
        self.assertEqual(tuple(detailed[0]), schema.DETAILED_COLUMNS)
        imported = detailed_from_records(detailed)
        for row in imported:
            self.assertEqual(Fraction(row.total_cash), Fraction(row.cash_interest)+Fraction(row.principal_collection))
        waterfall = self.rows('tranche_waterfall')
        debt = [row for row in waterfall if row['instrument_type']=='DEBT']
        self.assertGreater(sum(row['pik_interest_capitalized'] for row in debt), 0)
        for row in debt:
            self.assertAlmostEqual(row['closing_balance'], row['opening_balance']+row['pik_interest_capitalized']-row['total_principal_paid'], places=8)
        metrics = {row['metric_id']: row for row in self.rows('clo_economics')}
        self.assertIn('DEBT_TO_EQUITY_CASH', metrics)
        self.assertEqual(metrics['DEBT_TO_EQUITY_CASH']['value'], 1.5)

    def test_standalone_gbp_projected_sonia_uses_named_zero_block(self):
        self.configure(currency='GBP', mode='CASHFLOW_ONLY', overnight=True)
        result = run_workbook(self.path)
        self.assertIsNone(result.clo)
        self.assertEqual(result.cashflows.currency, 'GBP')
        self.assertGreater(result.cashflows.total_interest, 0)
        self.assertTrue(all(row['reset_frequency']=='O/N' for row in self.rows('cashflow_detailed_export')))
        self.assertTrue(all(row['unit']=='GBP' for row in self.rows('funding_summary')))
        self.assertEqual(self.rows('clo_economics'), ())
        book = load_workbook(self.path)
        try:
            adapter = NamedWorkbook(book)
            sheet, (left, top, _, _) = adapter.region(schema.SCALAR_NAMES['result_total_interest'])
            self.assertEqual(sheet.cell(top, left-1).value, 'Contractual interest (base currency)')
        finally:
            book.close()

    def test_all_font_definitions_default_and_theme_are_arial(self):
        self.configure()
        run_workbook(self.path)
        book = load_workbook(self.path)
        try:
            self.assertEqual({font.name for font in book._fonts}, {'Arial'})
            self.assertEqual({style.font.name for style in book._named_styles}, {'Arial'})
            theme = ElementTree.fromstring(book.loaded_theme)
            ns = {'a': 'http://schemas.openxmlformats.org/drawingml/2006/main'}
            scheme = theme.find('a:themeElements/a:fontScheme', ns)
            self.assertTrue(all(node.get('typeface')=='Arial' for node in scheme.iter() if 'typeface' in node.attrib))
        finally:
            book.close()
