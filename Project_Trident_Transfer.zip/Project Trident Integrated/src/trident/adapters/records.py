"""Parse semantic row fields, shared by CSV and Excel input adapters."""

from datetime import date, datetime, time
from decimal import Decimal, InvalidOperation
from typing import Mapping

from trident.conventions.calendar import BusinessDayConvention, CalendarName, calendar_from_name
from trident.conventions.day_count import DayCount
from trident.conventions.schedule import AccrualDateBasis, StubConvention
from trident.domain.models import (AmortizationType, CouponStep, CouponStepPolicy, CouponType,
    InputValidationError, InterestMode, LoanPosition, LoanTerms)
from trident.funding.engine import AssetPurchase, ClosingCostBudget, ClosingCostItem, ClosingSourceType, DebtIssue
from trident.application.services import CashflowRunRequest
from trident.market.rates import RateProvider
from trident.domain.numeric import basis_points_rate


# Descriptive metadata is retained for later modules but not used as hidden
# contractual instructions. Unknown columns must be classified explicitly.
ASSET_FIELDS = frozenset({
    "fixture_id", "fixture_version", "provenance", "loan_id", "obligor_id",
    "asset_class", "financing_type", "country_code", "sector", "currency",
    "initial_par", "current_par", "par_as_of_date", "cashflow_projection_start_date",
    "maturity_date_unadjusted", "coupon_type", "rate_index", "spread_bps",
    "index_floor_bps", "day_count", "frequency_months", "schedule_anchor_day",
    "index_cap_bps", "all_in_floor_bps", "all_in_cap_bps", "reset_frequency_months",
    "business_day_convention", "holiday_calendar", "accrual_date_basis",
    "fixing_lag_target_business_days", "amortization_type",
    "amortization_fraction_initial_par_per_period", "amortization_periods_remaining",
    "amortization_first_date_unadjusted", "purchase_price_pct", "credit_status",
    "seniority", "secured", "construction_risk", "revolver", "pik", "rating_agency",
    "agency_rating", "test_factor_system", "test_factor_bucket",
    "discretionary_trade_eligible", "fixed_rate", "payment_lag_business_days",
    "end_of_month", "stub_convention", "acquired_accrued_interest", "user_note",
    "rating_factor", "rating_system", "rating_version", "rating_bucket",
    "scheduled_principal_amount", "amortization_growth", "balloon_amount",
    "first_payment_date_unadjusted", "last_regular_payment_date_unadjusted",
    "recovery_rate", "recovery_rate_source",
    "is_ccc", "is_discount", "oc_market_price_fraction", "interest_mode", "pik_fraction",
})
CAPITAL_FIELDS = frozenset({
    "fixture_id", "fixture_version", "provenance", "class_id", "payment_priority",
    "instrument_type", "currency", "nominal_amount", "coupon_type", "rate_index",
    "spread_bps", "index_floor_bps", "issue_price_pct", "day_count",
    "frequency_months", "schedule_anchor_day", "business_day_convention",
    "holiday_calendar", "accrual_date_basis", "fixing_lag_target_business_days",
    "rating_agency", "agency_rating", "user_note",
    "fixed_rate", "oc_minimum", "ic_minimum", "interest_deferrable", "pik_rate_fraction",
})


def _validate_fields(row: Mapping[str, object], allowed: frozenset[str], label: str) -> None:
    unknown = set(row) - allowed
    if unknown:
        raise InputValidationError(f"{label}: unregistered fields {sorted(unknown)}; classify and implement new terms before use")


def decimal_value(value: object, field: str) -> Decimal:
    """Convert Excel's decimal text representation, never Decimal(float)."""
    if isinstance(value, bool) or value is None or str(value).strip() == "":
        raise InputValidationError(f"Missing or invalid numeric field: {field}")
    try:
        result = Decimal(str(value))
    except (InvalidOperation, ValueError) as error:
        raise InputValidationError(f"Invalid numeric field {field}: {value!r}") from error
    if not result.is_finite():
        raise InputValidationError(f"Non-finite numeric field: {field}")
    return result


def date_value(value: object, field: str) -> date:
    """Excel midnight datetimes are calendar dates; intraday values are invalid."""
    if type(value) is date:
        return value
    if isinstance(value, datetime) and value.tzinfo is None and value.time() == time():
        return value.date()
    if isinstance(value, str):
        try:
            return date.fromisoformat(value)
        except ValueError as error:
            raise InputValidationError(f"Invalid ISO date in {field}: {value!r}") from error
    raise InputValidationError(f"Invalid calendar date in {field}: {value!r}")


def integer_value(value: object, field: str) -> int:
    number = decimal_value(value, field)
    if number != number.to_integral_value():
        raise InputValidationError(f"{field} must be an integer")
    return int(number)


def boolean_value(value: object, field: str) -> bool:
    if type(value) is bool:
        return value
    if isinstance(value, str) and value.lower() in {"true", "false"}:
        return value.lower() == "true"
    raise InputValidationError(f"{field} must be true or false")


def text_value(value: object, field: str) -> str:
    if not isinstance(value, str) or not value.strip():
        raise InputValidationError(f"Missing or invalid text field: {field}")
    if value != value.strip():
        raise InputValidationError(f"Remove surrounding whitespace from {field}")
    return value


def _floor_from_bps(row: Mapping[str, object]) -> Decimal | None:
    floor = _optional_decimal(row, "index_floor_bps")
    return None if floor is None else basis_points_rate(floor)


def _optional_decimal(row: Mapping[str, object], field: str) -> Decimal | None:
    value = row.get(field)
    return None if value is None or value == "" else decimal_value(value, field)


def _optional_date(row: Mapping[str, object], field: str) -> date | None:
    value = row.get(field)
    return None if value is None or value == "" else date_value(value, field)


def _optional_bps(row: Mapping[str, object], field: str) -> Decimal | None:
    """Transport explicit bps bounds to annual fractions; preserve blank/zero."""
    value = _optional_decimal(row, field)
    return None if value is None else basis_points_rate(value)


def coupon_steps_from_records(
    rows: tuple[Mapping[str, object], ...], assets: tuple[Mapping[str, object], ...], *, scope: str = "ASSET",
) -> dict[str, tuple[tuple[CouponStep, ...], CouponStepPolicy]]:
    """Group a normalized detail table into immutable per-contract step terms.

    One row is an absolute coupon or margin level, never an increment. Rates
    stay annual fractions and margins stay basis points. Sorting is a transport
    convenience; duplicate dates, conflicting policies and orphan identities
    fail explicitly. The caller separately validates both supported scopes,
    including stepped candidates when the expensive search is disabled.
    """
    if scope not in {"ASSET", "CANDIDATE"}:
        raise InputValidationError(f"Unsupported Coupon Steps scope: {scope!r}")
    known_ids = {text_value(row.get("loan_id"), f"{scope} loan_id") for row in assets}
    grouped: dict[str, list[CouponStep]] = {}
    policies: dict[str, CouponStepPolicy] = {}
    for row in rows:
        if not isinstance(row, Mapping):
            raise InputValidationError("Coupon Steps rows must be semantic field mappings")
        _validate_fields(row, frozenset({"scope", "loan_id", "effective_date", "fixed_rate", "spread_bps", "policy"}), "Coupon Steps")
        row_scope = text_value(row.get("scope"), "Coupon Steps scope")
        if row_scope not in {"ASSET", "CANDIDATE"}:
            raise InputValidationError(f"Unsupported Coupon Steps scope: {row_scope!r}")
        identifier = text_value(row.get("loan_id"), "Coupon Steps loan_id")
        # Different scopes have independent identity namespaces. ASSET means
        # the held baseline; CANDIDATE means a new Candidate Assets contract.
        if row_scope != scope:
            continue
        if identifier not in known_ids:
            raise InputValidationError(f"Coupon Steps {scope} refers to unknown loan_id: {identifier}")
        try:
            policy = CouponStepPolicy(text_value(row.get("policy"), "Coupon Steps policy"))
        except ValueError as error:
            raise InputValidationError(f"Coupon Steps {identifier}: invalid policy") from error
        if identifier in policies and policies[identifier] is not policy:
            raise InputValidationError(f"Coupon Steps {identifier}: all rows must use the same policy")
        policies[identifier] = policy
        grouped.setdefault(identifier, []).append(CouponStep(
            effective_date=date_value(row.get("effective_date"), "Coupon Steps effective_date"),
            fixed_rate=_optional_decimal(row, "fixed_rate"),
            spread_bps=_optional_decimal(row, "spread_bps"),
        ))
    result = {}
    for identifier, steps in grouped.items():
        ordered = tuple(sorted(steps, key=lambda step: step.effective_date))
        if len({step.effective_date for step in ordered}) != len(ordered):
            raise InputValidationError(f"Coupon Steps {identifier}: duplicate effective_date")
        result[identifier] = ordered, policies[identifier]
    return result


def position_from_record(row: Mapping[str, object], *, principal_schedule: tuple = (),
                         coupon_steps: tuple[CouponStep, ...] = (),
                         coupon_step_policy: CouponStepPolicy = CouponStepPolicy.ACTUAL_DATE,
                         seasoned_state=None) -> LoanPosition:
    """Reject unsupported economics instead of treating missing features as zero."""
    identifier = row.get("loan_id", "")
    try:
        _validate_fields(row, ASSET_FIELDS, "Asset")
        identifier = text_value(identifier, "loan_id")
        if row.get("credit_status") != "PERFORMING":
            raise InputValidationError("Native cashflow input projects PERFORMING loans only")
        for field in ("revolver", "construction_risk"):
            if boolean_value(row.get(field), field):
                raise InputValidationError(f"Native asset input does not implement {field}")
        # The legacy descriptive PIK flag selects full PIK only when explicit
        # coupon terms are absent. Mixed coupons always require their fraction;
        # conflicting metadata must not silently change contractual cash.
        pik_flag = boolean_value(row.get("pik", False), "pik")
        interest_mode = InterestMode(row.get("interest_mode") or ("PIK" if pik_flag else "CASH"))
        pik_fraction = _optional_decimal(row, "pik_fraction")
        if pik_fraction is None:
            pik_fraction = Decimal(1) if interest_mode is InterestMode.PIK else Decimal(0)
        if pik_flag != (interest_mode is not InterestMode.CASH):
            raise InputValidationError("pik metadata must match interest_mode; use explicit MIXED and pik_fraction for split coupons")
        calendar = calendar_from_name(row.get("holiday_calendar", "TARGET"))
        start = date_value(row.get("cashflow_projection_start_date"), "cashflow_projection_start_date")
        frequency = integer_value(row.get("frequency_months"), "frequency_months")
        coupon = CouponType(row.get("coupon_type"))
        amortization = AmortizationType(row.get("amortization_type"))
        fraction = _optional_decimal(row, "amortization_fraction_initial_par_per_period") or Decimal(0)
        maturity = date_value(row.get("maturity_date_unadjusted"), "maturity_date_unadjusted")
        stub = StubConvention(row.get("stub_convention", "SHORT_LAST"))
        first_payment = _optional_date(row, "first_payment_date_unadjusted")
        front_stub = stub.value in {"SHORT_FIRST", "LONG_FIRST"}
        anchor = (first_payment or maturity) if front_stub else start
        if integer_value(row.get("schedule_anchor_day"), "schedule_anchor_day") != anchor.day:
            raise InputValidationError("schedule_anchor_day must match the regular unadjusted schedule anchor")
        raw_index = row.get("rate_index")
        terms = LoanTerms(
            loan_id=identifier, currency=str(row.get("currency", "")),
            start_date=start, maturity_date=maturity,
            reference_principal=decimal_value(row.get("initial_par"), "initial_par"),
            coupon_type=coupon, frequency_months=frequency,
            interest_mode=interest_mode, pik_fraction=pik_fraction,
            holiday_calendar=CalendarName(row.get("holiday_calendar", "TARGET")),
            day_count=(DayCount[row["day_count"]] if row.get("day_count") in DayCount.__members__ else DayCount(row.get("day_count"))),
            rate_index=None if raw_index is None or raw_index == "" else str(raw_index),
            spread_bps=decimal_value(row.get("spread_bps", 0), "spread_bps"),
            fixed_rate=_optional_decimal(row, "fixed_rate"),
            index_floor=_floor_from_bps(row),
            index_cap=_optional_bps(row, "index_cap_bps"),
            all_in_floor=_optional_bps(row, "all_in_floor_bps"),
            all_in_cap=_optional_bps(row, "all_in_cap_bps"),
            reset_frequency_months=None if row.get("reset_frequency_months") in (None, "") else integer_value(row["reset_frequency_months"], "reset_frequency_months"),
            amortization_type=amortization, amortization_fraction=fraction,
            business_day_convention=BusinessDayConvention(row.get("business_day_convention")),
            accrual_date_basis=AccrualDateBasis(row.get("accrual_date_basis")),
            fixing_lag_business_days=integer_value(row.get("fixing_lag_target_business_days"), "fixing_lag_target_business_days"),
            payment_lag_business_days=integer_value(row.get("payment_lag_business_days", 0), "payment_lag_business_days"),
            end_of_month=boolean_value(row.get("end_of_month", False), "end_of_month"),
            stub_convention=stub,
            first_payment_date=first_payment,
            last_regular_payment_date=_optional_date(row, "last_regular_payment_date_unadjusted"),
            amortization_start_date=_optional_date(row, "amortization_first_date_unadjusted"),
            scheduled_principal_amount=_optional_decimal(row, "scheduled_principal_amount"),
            amortization_growth=_optional_decimal(row, "amortization_growth"),
            balloon_amount=_optional_decimal(row, "balloon_amount"),
            principal_schedule=principal_schedule,
            coupon_steps=coupon_steps, coupon_step_policy=coupon_step_policy,
        )
        if amortization is not AmortizationType.BULLET:
            # Validation and calculation must use exactly the same schedule configuration.
            from trident.conventions.schedule import ScheduleBuilder
            periods = ScheduleBuilder(calendar).build(
                start, maturity, frequency,
                business_day_convention=terms.business_day_convention,
                accrual_date_basis=terms.accrual_date_basis,
                fixing_lag_business_days=terms.fixing_lag_business_days,
                payment_lag_business_days=terms.payment_lag_business_days,
                end_of_month=terms.end_of_month, stub_convention=terms.stub_convention,
                first_payment_date=terms.first_payment_date,
                last_regular_payment_date=terms.last_regular_payment_date,
            )
            if (terms.amortization_start_date is not None
                    and terms.amortization_start_date != terms.start_date
                    and terms.amortization_start_date not in {period.unadjusted_end for period in periods}):
                raise InputValidationError("amortization_start_date must be an unadjusted accrual boundary")
            raw_count = row.get("amortization_periods_remaining")
            if raw_count is not None and raw_count != "":
                eligible = sum(terms.amortization_start_date is None or period.unadjusted_end >= terms.amortization_start_date for period in periods)
                declared = integer_value(raw_count, "amortization_periods_remaining")
                if declared != eligible:
                    raise InputValidationError("amortization_periods_remaining does not match eligible principal periods")
        return LoanPosition(terms, date_value(row.get("par_as_of_date"), "par_as_of_date"),
                            decimal_value(row.get("current_par"), "current_par"), seasoned_state)
    except (ValueError, TypeError, KeyError) as error:
        raise InputValidationError(f"Asset {identifier or '<missing loan_id>'}: {error}") from error


def purchase_from_record(row: Mapping[str, object]) -> AssetPurchase:
    return AssetPurchase(
        text_value(row.get("loan_id"), "loan_id"), decimal_value(row.get("current_par"), "current_par"),
        decimal_value(row.get("purchase_price_pct"), "purchase_price_pct"),
        decimal_value(row.get("acquired_accrued_interest", 0), "acquired_accrued_interest"),
    )


def debt_from_records(rows: tuple[Mapping[str, object], ...], *, existing_clo: bool = False) -> tuple[DebtIssue, ...]:
    """Equity nominal never enters debt issuance cash proceeds."""
    issues: list[DebtIssue] = []
    ids: set[str] = set()
    for row in rows:
        _validate_fields(row, CAPITAL_FIELDS, "Capital Stack")
        class_id = text_value(row.get("class_id"), "class_id")
        if not class_id or class_id in ids:
            raise InputValidationError(f"Missing/duplicate capital class_id: {class_id!r}")
        ids.add(class_id)
        kind = row.get("instrument_type")
        if kind == "DEBT":
            par = decimal_value(row.get("nominal_amount"), "nominal_amount")
            # An inactive redeemed class remains in the liability master and
            # claim report, but supplies no hypothetical issuance proceeds.
            if existing_clo and par == 0:
                continue
            issues.append(DebtIssue(class_id, par, decimal_value(row.get("issue_price_pct"), "issue_price_pct")))
        elif kind != "EQUITY":
            raise InputValidationError(f"Unknown instrument_type for {class_id}: {kind!r}")
    return tuple(issues)


def run_request_from_records(
    assets: tuple[Mapping[str, object], ...], capital: tuple[Mapping[str, object], ...],
    provider: RateProvider, *, upfront_fees: Decimal, cash_reserve: Decimal, rate_provenance: str,
    principal_schedule_records: tuple[Mapping[str, object], ...] = (),
    coupon_step_records: tuple[Mapping[str, object], ...] = (),
    seasoned_states: Mapping[str, object] | None = None,
    other_initial_uses: Decimal = Decimal(0),
    other_initial_sources: Decimal = Decimal(0),
    other_initial_source_type: ClosingSourceType | None = None,
    closing_cost_budget: ClosingCostBudget | None = None,
    existing_clo: bool = False,
) -> CashflowRunRequest:
    """Translate external schemas into typed application input in one adapter."""
    currencies = {row.get("currency") for row in assets}
    if len(currencies) != 1 or any(row.get("currency") not in currencies for row in capital):
        raise InputValidationError("Assets and Capital Stack must share one currency; no implicit FX conversion")
    from trident.domain.models import PrincipalScheduleEntry
    known_ids = {row.get("loan_id") for row in assets}
    schedules: dict[str, list[PrincipalScheduleEntry]] = {}
    step_groups = coupon_steps_from_records(coupon_step_records, assets)
    for row in principal_schedule_records:
        _validate_fields(row, frozenset({"loan_id", "payment_date_unadjusted", "amount"}), "Principal Schedule")
        identifier = text_value(row.get("loan_id"), "principal schedule loan_id")
        if identifier not in known_ids:
            raise InputValidationError(f"Principal Schedule refers to unknown loan_id: {identifier}")
        schedules.setdefault(identifier, []).append(PrincipalScheduleEntry(
            date_value(row.get("payment_date_unadjusted"), "payment_date_unadjusted"),
            decimal_value(row.get("amount"), "principal schedule amount"),
        ))
    return CashflowRunRequest(
        tuple(position_from_record(row,
            principal_schedule=tuple(sorted(schedules.get(row.get("loan_id"), ()), key=lambda item: item.payment_date)),
            coupon_steps=step_groups.get(row.get("loan_id"), ((), CouponStepPolicy.ACTUAL_DATE))[0],
            coupon_step_policy=step_groups.get(row.get("loan_id"), ((), CouponStepPolicy.ACTUAL_DATE))[1],
            seasoned_state=(seasoned_states or {}).get(row.get("loan_id"))) for row in assets),
        tuple(purchase_from_record(row) for row in assets), debt_from_records(capital, existing_clo=existing_clo),
        provider, upfront_fees, cash_reserve, rate_provenance,
        other_initial_uses, other_initial_sources, other_initial_source_type, closing_cost_budget,
    )


def closing_cost_budget_from_records(
    rows: tuple[Mapping[str, object], ...], *, arrangement_fee_base: object,
    arrangement_fee_rate: object,
) -> ClosingCostBudget:
    """Parse identified cash costs; never infer a percentage base from par.

    Call only when itemized funding mode was explicitly selected. A rate/base
    of zero and an empty table is a valid deliberately zero-cost budget.
    """
    costs = []
    for row in rows:
        _validate_fields(row, frozenset({"cost_id", "amount"}), "Closing Costs")
        costs.append(ClosingCostItem(text_value(row.get("cost_id"), "closing cost_id"),
                                     decimal_value(row.get("amount"), "closing cost amount")))
    return ClosingCostBudget(decimal_value(arrangement_fee_base, "arrangement_fee_base"),
                             decimal_value(arrangement_fee_rate, "arrangement_fee_rate"), tuple(costs))
