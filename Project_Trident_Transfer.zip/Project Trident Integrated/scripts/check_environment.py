"""Read-only checks for a freshly installed Trident environment.

Import success alone does not prove a compiled solver or an Excel writer works.
Each selected profile performs a tiny independent known-answer calculation or
an in-memory round trip. The script uses only standard-library imports until
the requested probe runs; missing optional packages therefore produce an
actionable report rather than preventing the diagnostic from starting.

No project inputs, workbooks, network services or environment settings are
changed. A PASS confirms installation plumbing, not financial-model readiness.
"""

import argparse
from datetime import date
from decimal import Decimal
from importlib import import_module, metadata
from io import BytesIO
import json
from math import isclose
import platform
import re
import struct
import sys
from typing import Callable


PROFILES = {
    "core": (),
    "excel": ("openpyxl",),
    "model": ("openpyxl", "numpy", "scipy"),
    "reporting": ("openpyxl", "numpy", "scipy", "reportlab"),
}
TESTED_VERSIONS = {
    "openpyxl": "3.1.5", "numpy": "2.3.5", "scipy": "1.18.1",
    "reportlab": "4.4.9",
}
SUPPORTED_VERSIONS = {
    "openpyxl": ((3, 1, 0), (4, 0, 0)),
    "numpy": ((1, 26, 0), (3, 0, 0)),
    "scipy": ((1, 13, 0), (2, 0, 0)),
    "reportlab": ((4, 4, 0), (5, 0, 0)),
}


def _release_tuple(version: str) -> tuple[int, int, int]:
    """Read the stable numeric release prefix for our declared major bounds.

    This is deliberately not a general dependency resolver. pip enforces the
    full package metadata; this small check highlights obvious lower/upper
    bound mistakes without adding a diagnostic-only packaging dependency.
    """
    match = re.match(r"^(\d+)\.(\d+)(?:\.(\d+))?", version)
    if match is None:
        raise ValueError(f"Unrecognised distribution version: {version}")
    return tuple(int(value or 0) for value in match.groups())


def _package_version(name: str) -> str:
    """Import a distribution and reject versions outside the project contract."""
    import_module(name)
    version = metadata.version(name)
    lower, upper = SUPPORTED_VERSIONS[name]
    if not lower <= _release_tuple(version) < upper:
        raise ValueError(f"{name} {version} is outside supported range {lower} <= version < {upper}")
    return version


def _probe_core() -> dict[str, object]:
    """A EUR100 quarterly 12% 30E/360 bullet owes EUR3 interest and EUR100 par.

    Dates are nominal with no business-day adjustment, so the known answer is
    simply 100 * 0.12 * 90 / 360. The test requires no market data or examples
    outside the installed wheel and therefore works from any current directory.
    """
    import trident
    from trident.cashflows.engine import ContractualCashflowEngine
    from trident.conventions import BusinessDayConvention, DayCount
    from trident.domain.models import CouponType, LoanPosition, LoanTerms
    from trident.market.rates import FlatRateProvider

    terms = LoanTerms(
        loan_id="ENVIRONMENT_CHECK", currency="EUR",
        start_date=date(2027, 1, 1), maturity_date=date(2027, 4, 1),
        reference_principal=Decimal("100"), coupon_type=CouponType.FIXED,
        fixed_rate=Decimal("0.12"), day_count=DayCount.THIRTY_E_360,
        business_day_convention=BusinessDayConvention.UNADJUSTED,
    )
    rows = ContractualCashflowEngine(FlatRateProvider({})).generate(
        LoanPosition(terms, terms.start_date, Decimal("100")),
    )
    if len(rows) != 1 or rows[0].cash_interest != Decimal("3.00") or rows[0].principal_repayment != Decimal("100.00"):
        raise ArithmeticError("Installed core failed the EUR3 interest / EUR100 principal known answer")
    return {"software_version": trident.__version__, "interest_eur": "3.00", "principal_eur": "100.00"}


def _probe_excel() -> dict[str, object]:
    """Round-trip a semantic named input entirely in memory, without Excel COM."""
    from openpyxl import Workbook, load_workbook
    from openpyxl.workbook.defined_name import DefinedName

    workbook = Workbook()
    workbook.active.title = "Environment Check"
    # Coordinates belong to this tiny adapter-level layout only; consumers
    # resolve the named range rather than discovering business fields by cell.
    workbook.active["A1"] = 123.45
    workbook.defined_names.add(DefinedName("trident_environment_value", attr_text="'Environment Check'!$A$1"))
    payload = BytesIO()
    workbook.save(payload)
    workbook.close()
    payload.seek(0)
    loaded = load_workbook(payload)
    try:
        sheet, address = next(loaded.defined_names["trident_environment_value"].destinations)
        if loaded[sheet][address].value != 123.45:
            raise ArithmeticError("Named Excel value failed the in-memory save/load round trip")
    finally:
        loaded.close()
        payload.close()
    return {"named_range_roundtrip": True}


def _probe_optimization() -> dict[str, object]:
    """Exercise both HiGHS paths with independent scalar optima.

    Minimise x subject to x >= 1.5. The continuous optimum is 1.5; with x an
    integer it is 2. This catches unavailable native libraries/API mismatches
    while avoiding a slow portfolio projection or the production optimizer's
    own coefficient builder as the source of the expected answers.
    """
    import numpy as np
    from scipy.optimize import Bounds, LinearConstraint, linprog, milp
    from scipy.sparse import csc_array

    lp = linprog([1.0], A_ub=csc_array([[-1.0]]), b_ub=[-1.5], bounds=[(0.0, 10.0)], method="highs-ds")
    integer = milp(
        np.asarray([1.0]), integrality=np.asarray([1]),
        bounds=Bounds([0.0], [10.0]),
        constraints=LinearConstraint(csc_array([[1.0]]), [1.5], [np.inf]),
    )
    for label, result, expected in (("LP", lp, 1.5), ("MILP", integer, 2.0)):
        if not result.success or result.x is None or not isclose(float(result.x[0]), expected, rel_tol=0, abs_tol=1e-8):
            raise ArithmeticError(f"HiGHS {label} failed known optimum {expected}: {result.message}")
    return {"highs_dual_simplex_x": 1.5, "highs_milp_x": 2.0}


def _probe_reporting() -> dict[str, object]:
    """Verify an optional ReportLab PDF writer, without requiring Windows fonts."""
    from reportlab.pdfgen.canvas import Canvas

    payload = BytesIO()
    canvas = Canvas(payload)
    canvas.drawString(20, 20, "Project Trident environment check")
    canvas.save()
    if not payload.getvalue().startswith(b"%PDF-"):
        raise ArithmeticError("ReportLab did not produce a PDF header")
    payload.close()
    return {"in_memory_pdf": True}


def check_environment(profile: str = "model") -> dict[str, object]:
    """Return every requested check with explicit failures and baseline warnings.

    Installation outside the pinned Python/package snapshot can still pass
    functional probes, but requires the full model regression before use. Each
    independent check continues after a failure to show all missing components.
    """
    if profile not in PROFILES:
        raise ValueError(f"Unknown environment profile: {profile}")
    checks: list[dict[str, object]] = []
    warnings: list[str] = []

    def record(label: str, action: Callable[[], object]) -> bool:
        try:
            detail = action()
        except Exception as error:
            checks.append({"check": label, "status": "FAIL", "error": f"{type(error).__name__}: {error}"})
            return False
        checks.append({"check": label, "status": "PASS", "detail": detail})
        return True

    def python_contract() -> str:
        if sys.version_info < (3, 11):
            raise RuntimeError("Trident requires Python >=3.11; the pinned deployment baseline uses Python 3.12")
        return platform.python_version()

    record("python", python_contract)
    if sys.version_info[:2] != (3, 12) or struct.calcsize("P") * 8 != 64:
        warnings.append("The validated deployment snapshot uses Python 3.12 (64-bit); rerun the full suite on this environment.")
    record("core_known_answer", _probe_core)
    available = set()
    for name in PROFILES[profile]:
        if record(name, lambda name=name: _package_version(name)):
            available.add(name)
            version = checks[-1]["detail"]
            if version != TESTED_VERSIONS[name]:
                warnings.append(f"{name} {version} differs from tested version {TESTED_VERSIONS[name]}; rerun the full suite.")
    if "openpyxl" in available:
        record("named_excel_roundtrip", _probe_excel)
    if {"numpy", "scipy"} <= available:
        record("highs_lp_milp", _probe_optimization)
    if "reportlab" in available:
        record("pdf_writer", _probe_reporting)
    return {
        "status": "FAIL" if any(check["status"] == "FAIL" for check in checks) else "PASS",
        "profile": profile, "python_executable": sys.executable,
        "python_version": platform.python_version(), "architecture_bits": struct.calcsize("P") * 8,
        "checks": checks, "warnings": warnings,
        "scope": "INSTALLATION_AND_SMALL_KNOWN_ANSWERS_ONLY_NOT_MODEL_APPROVAL",
    }


def main(argv: list[str] | None = None) -> int:
    """Print a machine-readable report; exit 2 if any requested component fails."""
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--profile", choices=tuple(PROFILES), default="model")
    arguments = parser.parse_args(argv)
    report = check_environment(arguments.profile)
    print(json.dumps(report, ensure_ascii=False, indent=2))
    return 0 if report["status"] == "PASS" else 2


if __name__ == "__main__":
    raise SystemExit(main())
