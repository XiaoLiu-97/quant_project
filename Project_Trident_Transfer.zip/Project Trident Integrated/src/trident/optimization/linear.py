"""Sparse HiGHS proposals followed by exact static portfolio verification.

LP variables are continuous EUR m; lot variables are integer counts. A quoted
minimum ticket/fixed fee adds a binary activation variable. Cent conversion of
continuous proposals is explicit and may fail exact verification; failed plans
are never represented as validated merely because HiGHS returned success.
"""

from dataclasses import dataclass
from decimal import Decimal
from fractions import Fraction
from math import isfinite
from typing import Callable

from trident.domain.models import InputValidationError, require_money
from trident.domain.numeric import decimal_fraction, post_currency
from trident.optimization.models import (
    AssetDescriptor, AssetKind, Holding, OptimizationObjective, OptimizationRequest,
    OptimizationResult, OptimizationStatus, ProposedTrade, TradeSide,
)

F = Fraction
SCALE = F(1_000_000)
Metric = Callable[[AssetDescriptor], Fraction]


@dataclass(frozen=True)
class _LinearProblem:
    """Scaled sparse coefficients; decision variables precede activation flags.

    ``units[i]`` converts quote variable i to EUR par. Continuous quotes use
    EUR millions and integer quotes use their explicit EUR lot size. Constraint
    dictionaries contain only nonzero coefficients; their row scale need not
    be the decision variable's scale.
    """
    objective: tuple[float, ...]
    rows: tuple[dict[int, float], ...]
    rhs: tuple[float, ...]
    equalities: tuple[dict[int, float], ...]
    equality_rhs: tuple[float, ...]
    upper: tuple[float, ...]
    integrality: tuple[int, ...]
    units: tuple[Fraction, ...]
    activations: tuple[tuple[int, int], ...]


def _solver_number(value: Fraction) -> float:
    """Reject binary64 range loss rather than silently delete a coefficient."""
    converted = float(value)
    if not isfinite(converted) or (value and converted == 0):
        raise InputValidationError("Optimization coefficients exceed solver numeric range (overflow/underflow)")
    return converted


def _build(request: OptimizationRequest) -> _LinearProblem:
    """Translate the static financial mandate into a scaled LP or MILP.

    Holdings contribute the fixed baseline; buys add and sells subtract par.
    The positive target-par equality makes mean factor/spread optimization
    linear. This coefficient builder deliberately does not project cashflows
    or treat static quoted spread as investor IRR.
    """
    quotes = request.quotes
    units = tuple(F(q.lot_size) if q.lot_size is not None else SCALE for q in quotes)
    # Binary z flags implement 0-or-[minimum, availability], not an arbitrary
    # rounding of continuous trades. The fixed fee is paid only when z=1.
    active = {i: len(quotes) + j for j, i in enumerate(
        i for i, q in enumerate(quotes) if q.minimum_ticket > 0 or q.fixed_fee > 0
    )}
    count = len(quotes) + len(active)
    upper = [_solver_number(F(q.maximum_par) / units[i]) for i, q in enumerate(quotes)] + [1.0] * len(active)
    integrality = [int(q.lot_size is not None) for q in quotes] + [1] * len(active)
    rows: list[dict[int, float]] = []
    rhs: list[float] = []

    def expression(metric: Metric) -> tuple[Fraction, list[Fraction]]:
        base = sum((F(h.par) * metric(h.asset) for h in request.holdings), F(0))
        coefficients = [F(0)] * count
        for i, q in enumerate(quotes):
            coefficients[i] = units[i] * metric(q.asset) * (1 if q.side is TradeSide.BUY else -1)
        return base, coefficients

    def inequality(coefficients: list[Fraction] | dict[int, Fraction], bound: Fraction, scale: Fraction = SCALE) -> None:
        items = coefficients.items() if isinstance(coefficients, dict) else enumerate(coefficients)
        rows.append({i: _solver_number(c / scale) for i, c in items if c})
        rhs.append(_solver_number(bound / scale))

    base_par, par_coeff = expression(lambda a: F(1))
    equalities = ({i: _solver_number(c / SCALE) for i, c in enumerate(par_coeff) if c},)
    equality_rhs = (_solver_number((F(request.limits.target_par) - base_par) / SCALE),)

    # Cash is signed from the settlement account's perspective. A sale earns
    # clean+accrued less fees; a purchase consumes all three. The solver uses
    # unposted coefficients; exact cent posting is checked independently later.
    cash_coeff = [F(0)] * count
    for i, quote in enumerate(quotes):
        clean_accrued = F(quote.clean_price_pct) / 100 + F(quote.accrued_per_par)
        fee = F(quote.proportional_fee_per_par)
        cash_coeff[i] = units[i] * (-(clean_accrued + fee) if quote.side is TradeSide.BUY else clean_accrued - fee)
        if i in active:
            z = active[i]
            cash_coeff[z] = -F(quote.fixed_fee)
            coefficients = [F(0)] * count
            coefficients[i], coefficients[z] = units[i], -F(quote.maximum_par)
            inequality(coefficients, F(0))
            coefficients = [F(0)] * count
            coefficients[i], coefficients[z] = -units[i], F(quote.minimum_ticket)
            inequality(coefficients, F(0))
    inequality([-c for c in cash_coeff], F(request.starting_cash) - F(request.limits.minimum_cash))

    limits = request.limits
    for dimension, cap in (("obligor", limits.maximum_obligor_share),
                           ("country", limits.maximum_country_share),
                           ("sector", limits.maximum_sector_share)):
        if cap is None:
            continue
        # Build group incidence once, avoiding a dense groups-by-assets matrix.
        group_base: dict[str, Fraction] = {}
        group_coeff: dict[str, dict[int, Fraction]] = {}
        for holding in request.holdings:
            group = getattr(holding.asset, dimension)
            group_base[group] = group_base.get(group, F(0)) + F(holding.par)
        for i, quote in enumerate(quotes):
            group = getattr(quote.asset, dimension)
            group_coeff.setdefault(group, {})[i] = units[i] * (1 if quote.side is TradeSide.BUY else -1)
        for group in sorted(group_base.keys() | group_coeff.keys()):
            inequality(group_coeff.get(group, {}), F(cap) * F(limits.target_par) - group_base.get(group, F(0)))
    if limits.maximum_bsl_share is not None:
        base, coefficients = expression(lambda a: F(int(a.kind is AssetKind.BSL)))
        inequality(coefficients, F(limits.maximum_bsl_share) * F(limits.target_par) - base)
    if limits.minimum_infra_share is not None:
        base, coefficients = expression(lambda a: F(int(a.kind is AssetKind.INFRA)))
        inequality([-c for c in coefficients], base - F(limits.minimum_infra_share) * F(limits.target_par))
    if limits.maximum_overall_factor is not None:
        cap = F(limits.maximum_overall_factor)
        base, coefficients = expression(lambda a: F(a.factor) - cap)
        inequality(coefficients, -base, F(limits.target_par) * max(F(1), cap))
    if limits.maximum_bsl_factor is not None:
        # BSL par can change even though total pool par is fixed. Multiplying
        # the upper-bound ratio by its nonnegative denominator gives the linear
        # sum(par * (factor-cap)) <= 0. No BSL par is a vacuous cap, reported N/A.
        cap = F(limits.maximum_bsl_factor)
        base, coefficients = expression(lambda a: (F(a.factor) - cap) if a.kind is AssetKind.BSL else F(0))
        inequality(coefficients, -base, F(limits.target_par) * max(F(1), cap))
    if limits.minimum_spread_bps is not None:
        minimum = F(limits.minimum_spread_bps)
        base, coefficients = expression(lambda a: F(a.spread_bps) - minimum)
        inequality([-c for c in coefficients], base, F(limits.target_par) * max(F(1), minimum))
    if limits.maximum_trade_par is not None:
        coefficients = list(units) + [F(0)] * len(active)
        inequality(coefficients, F(limits.maximum_trade_par))
    objective_metric = (lambda a: F(a.factor)) if request.objective is OptimizationObjective.MIN_FACTOR else (lambda a: -F(a.spread_bps))
    _, objective = expression(objective_metric)
    # This is the change in the fixed-denominator objective, not its full level.
    objective_float = tuple(_solver_number(c / F(limits.target_par)) for c in objective)
    return _LinearProblem(objective_float, tuple(rows), tuple(rhs), equalities,
                          equality_rhs, tuple(upper), tuple(integrality), units, tuple(active.items()))


@dataclass(frozen=True)
class StaticProposalVerification:
    """Rebuilt settlement ledger and exact mandate evidence, without a solver.

    Amounts and cash are cent-posted EUR; factors and quoted spreads are
    par-weighted diagnostics. The mandate is checked using exact fractions,
    never the displayed rounded averages or a numerical solver tolerance.
    Named fields keep cash, par and rating diagnostics from being confused
    across the solver/reconciliation boundary.
    """

    trades: tuple[ProposedTrade, ...]
    ending_holdings: tuple[Holding, ...]
    ending_cash: Decimal
    ending_par: Decimal
    overall_factor: Decimal
    bsl_factor: Decimal | None
    spread_bps: Decimal
    violations: tuple[str, ...]


def _verify(request: OptimizationRequest, amounts: tuple[Decimal, ...]) -> StaticProposalVerification:
    """Recompute posted cash and all mandate inequalities with exact fractions.

    This is the single financial rule implementation used both immediately
    after a solver call and at the independent proposal trust boundary. Solver
    tolerances never relax a contractual cash, quantity or risk inequality.
    """
    violations: list[str] = []
    positions = {h.asset.asset_id: [h.asset, F(h.par)] for h in request.holdings}
    trades: list[ProposedTrade] = []
    cash = F(request.starting_cash)
    turnover = F(0)
    for quote, amount in zip(request.quotes, amounts, strict=True):
        par = F(amount)
        if par < 0 or par > F(quote.maximum_par):
            violations.append(f"{quote.asset.asset_id}: quoted quantity violated")
        if par != 0 and par < F(quote.minimum_ticket):
            violations.append(f"{quote.asset.asset_id}: minimum ticket violated")
        if quote.lot_size is not None and (par / F(quote.lot_size)).denominator != 1:
            violations.append(f"{quote.asset.asset_id}: lot size violated")
        if par <= 0:
            continue
        clean = post_currency(par * F(quote.clean_price_pct) / 100)
        accrued = post_currency(par * F(quote.accrued_per_par))
        fee = post_currency(par * F(quote.proportional_fee_per_par))
        fee = post_currency(F(fee) + F(quote.fixed_fee))
        delta = -(F(clean) + F(accrued) + F(fee)) if quote.side is TradeSide.BUY else F(clean) + F(accrued) - F(fee)
        trades.append(ProposedTrade(quote.asset.asset_id, quote.side, amount, clean, accrued, fee, post_currency(delta)))
        cash += delta
        turnover += par
        if quote.side is TradeSide.BUY:
            positions[quote.asset.asset_id] = [quote.asset, par]
        else:
            positions[quote.asset.asset_id][1] -= par
    if any(p < 0 for _, p in positions.values()):
        violations.append("Negative ending held par")
    holdings = tuple(Holding(asset, post_currency(par)) for asset, par in positions.values() if par > 0)
    total = sum((F(h.par) for h in holdings), F(0))
    limits = request.limits
    if total != F(limits.target_par):
        violations.append("Ending par does not exactly equal target_par")
    if cash < F(limits.minimum_cash):
        violations.append("Posted ending cash is below minimum_cash")
    if limits.maximum_trade_par is not None and turnover > F(limits.maximum_trade_par):
        violations.append("Gross trade par exceeds maximum_trade_par")
    for dimension, cap in (("obligor", limits.maximum_obligor_share),
                           ("country", limits.maximum_country_share),
                           ("sector", limits.maximum_sector_share)):
        if cap is None:
            continue
        exposure: dict[str, Fraction] = {}
        for holding in holdings:
            group = getattr(holding.asset, dimension)
            exposure[group] = exposure.get(group, F(0)) + F(holding.par)
        for group, par in exposure.items():
            if par > F(cap) * total:
                violations.append(f"{dimension} {group}: concentration cap violated")
    bsl = sum((F(h.par) for h in holdings if h.asset.kind is AssetKind.BSL), F(0))
    infra = total - bsl
    if limits.maximum_bsl_share is not None and bsl > F(limits.maximum_bsl_share) * total:
        violations.append("BSL share cap violated")
    if limits.minimum_infra_share is not None and infra < F(limits.minimum_infra_share) * total:
        violations.append("Infra minimum share violated")
    factor_sum = sum((F(h.par) * F(h.asset.factor) for h in holdings), F(0))
    bsl_factor_sum = sum((F(h.par) * F(h.asset.factor) for h in holdings if h.asset.kind is AssetKind.BSL), F(0))
    spread_sum = sum((F(h.par) * F(h.asset.spread_bps) for h in holdings), F(0))
    if limits.maximum_overall_factor is not None and factor_sum > F(limits.maximum_overall_factor) * total:
        violations.append("Overall factor cap violated")
    if limits.maximum_bsl_factor is not None and bsl_factor_sum > F(limits.maximum_bsl_factor) * bsl:
        violations.append("BSL factor cap violated")
    if limits.minimum_spread_bps is not None and spread_sum < F(limits.minimum_spread_bps) * total:
        violations.append("Minimum spread violated")
    return StaticProposalVerification(tuple(trades), holdings, post_currency(cash), post_currency(total),
            decimal_fraction(factor_sum / total) if total else Decimal(0),
            decimal_fraction(bsl_factor_sum / bsl) if bsl else None,
            decimal_fraction(spread_sum / total) if total else Decimal(0), tuple(violations))


def verify_static_amounts(request: OptimizationRequest,
                          amounts: tuple[Decimal, ...]) -> StaticProposalVerification:
    """Verify one cent-par amount per permitted quote at the trust boundary.

    A result's OPTIMAL status is solver evidence, not proof that a caller has
    respected this request's limits. Reconciliation therefore uses the same
    independently posted arithmetic as the optimizer to verify every mandate.
    Zero means an inactive quote and incurs no minimum ticket or fixed fee.
    """
    if not isinstance(request, OptimizationRequest):
        raise InputValidationError("request must be OptimizationRequest")
    if type(amounts) is not tuple or len(amounts) != len(request.quotes):
        raise InputValidationError("Static amounts must be one immutable cent-par amount per quote")
    for amount in amounts:
        require_money(amount, "static proposed par")
    return _verify(request, amounts)


class StaticTradeOptimizer:
    """Generate static trade proposals; current BSL sales and new BSL purchases.

    No future cashflows, credit overlays or IRR are approximated as final output.
    Every returned validated plan passes strict cent-posted cash/par/limit checks.
    """

    def solve(self, request: OptimizationRequest) -> OptimizationResult:
        """Solve proposals, reconstruct tradable EUR par, then verify the ledger.

        LP success proves only a floating-point model result. A time-limited
        incumbent is reported as such and needs the same exact verification.
        No incumbent, malformed evidence or a cent-level breach cannot become
        a validated trade recommendation.
        """
        if not isinstance(request, OptimizationRequest):
            raise InputValidationError("request must be OptimizationRequest")
        if not request.quotes:
            return self._baseline(request)
        try:
            import numpy as np
            from scipy.optimize import Bounds, LinearConstraint, linprog, milp
        except ImportError as error:
            raise RuntimeError("Static optimization requires the project's optional scipy dependency") from error
        try:
            problem = _build(request)
        except (OverflowError, ValueError) as error:
            raise InputValidationError("Optimization coefficients exceed solver numeric range") from error
        coefficients = [*problem.objective, *problem.rhs, *problem.equality_rhs, *problem.upper]
        coefficients.extend(value for row in problem.rows + problem.equalities for value in row.values())
        if any(not isfinite(value) for value in coefficients):
            raise InputValidationError("Optimization coefficients exceed solver numeric range")
        options: dict[str, object] = {"presolve": True}
        if request.solver_time_limit is not None:
            options["time_limit"] = request.solver_time_limit
        # A single lot/ticket/fixed-fee feature changes the problem class;
        # passing these requirements to ordinary simplex would silently lose
        # their discrete meaning. SciPy's MILP owns branch-and-cut decisions.
        integer = any(problem.integrality)
        if integer:
            options["mip_rel_gap"] = request.mip_relative_gap
            rows = problem.rows + problem.equalities
            lower = [-np.inf] * len(problem.rows) + list(problem.equality_rhs)
            upper = list(problem.rhs) + list(problem.equality_rhs)
            constraints = LinearConstraint(_sparse(rows, len(problem.upper)), lower, upper)
            raw = milp(np.asarray(problem.objective), integrality=np.asarray(problem.integrality),
                       bounds=Bounds(np.zeros(len(problem.upper)), np.asarray(problem.upper)),
                       constraints=constraints, options=options)
            method = "HIGHS_MILP"
        else:
            options["primal_feasibility_tolerance"] = 1e-9
            options["dual_feasibility_tolerance"] = 1e-9
            raw = linprog(problem.objective, A_ub=_sparse(problem.rows, len(problem.upper)), b_ub=problem.rhs,
                          A_eq=_sparse(problem.equalities, len(problem.upper)), b_eq=problem.equality_rhs,
                          bounds=[(0, value) for value in problem.upper], method="highs-ds", options=options)
            method = "HIGHS_DUAL_SIMPLEX"
        status = {0: OptimizationStatus.OPTIMAL, 1: OptimizationStatus.NO_INCUMBENT,
                  2: OptimizationStatus.INFEASIBLE, 3: OptimizationStatus.UNBOUNDED}.get(
                      raw.status, OptimizationStatus.NUMERICAL_ERROR)
        evidence = dict(solver_status=int(raw.status), solver_message=str(raw.message), solver_method=method,
                        solver_objective=_finite_optional(getattr(raw, "fun", None)),
                        solver_bound=_finite_optional(getattr(raw, "mip_dual_bound", None)),
                        solver_gap=_finite_optional(getattr(raw, "mip_gap", None)),
                        factor_provenance=request.factor_provenance)
        if raw.status not in {0, 1} or raw.x is None:
            return OptimizationResult(status=status, **evidence)
        if raw.status == 1:
            status = OptimizationStatus.FEASIBLE_TIME_LIMIT
        if len(raw.x) != len(problem.upper) or any(not isfinite(float(v)) for v in raw.x):
            return OptimizationResult(status=OptimizationStatus.NUMERICAL_ERROR, **evidence)
        amounts: list[Decimal] = []
        reconstruction_errors: list[str] = []
        for i, integer_required in enumerate(problem.integrality):
            value = float(raw.x[i])
            if integer_required and abs(value - round(value)) > 1e-6:
                reconstruction_errors.append(f"Solver integer variable {i} failed integrality verification")
            if integer_required and (round(value) < 0 or round(value) > problem.upper[i] + 1e-6):
                reconstruction_errors.append(f"Solver integer variable {i} violated its decision bounds")
        for i, quote in enumerate(request.quotes):
            value = float(raw.x[i])
            if quote.lot_size is not None:
                rounded_count = round(value)
                par = post_currency(F(rounded_count) * problem.units[i])
            else:
                # This changes the decision, not the feasibility tolerance.
                # The rebuilt cent-par decision must satisfy every exact test.
                par = post_currency(F(Decimal(str(value))) * problem.units[i])
            amounts.append(par)
        # Exact cash/par checks cannot detect an impossible binary flag if the
        # posted trade otherwise happens to be affordable. Verify this discrete
        # solver evidence too: positive quantities must activate their ticket
        # and fee variable. The 1e-6 check above is integer reconstruction
        # precision; it never relaxes a financial mandate or a posted amount.
        for quote_index, flag_index in problem.activations:
            if amounts[quote_index] > 0 and round(float(raw.x[flag_index])) != 1:
                reconstruction_errors.append(
                    f"{request.quotes[quote_index].asset.asset_id}: positive trade lacks solver activation"
                )
        verified = _verify(request, tuple(amounts))
        violations = verified.violations + tuple(reconstruction_errors)
        if violations:
            status = OptimizationStatus.REJECTED_POST_VALIDATION
        return OptimizationResult(status=status, trades=verified.trades, ending_holdings=verified.ending_holdings,
                                  ending_cash=verified.ending_cash, ending_par=verified.ending_par,
                                  overall_factor=verified.overall_factor, bsl_factor=verified.bsl_factor,
                                  spread_bps=verified.spread_bps, violations=violations, **evidence)

    def _baseline(self, request: OptimizationRequest) -> OptimizationResult:
        verified = _verify(request, ())
        status = OptimizationStatus.INFEASIBLE if verified.violations else OptimizationStatus.OPTIMAL
        return OptimizationResult(status=status, solver_status=2 if verified.violations else 0,
            solver_message="No trade quotes: exact baseline feasibility check", solver_method="NO_TRADE_CHECK",
            solver_objective=0.0 if not verified.violations else None, solver_bound=None, solver_gap=None,
            factor_provenance=request.factor_provenance, trades=verified.trades, ending_holdings=verified.ending_holdings,
            ending_cash=verified.ending_cash, ending_par=verified.ending_par, overall_factor=verified.overall_factor,
            bsl_factor=verified.bsl_factor, spread_bps=verified.spread_bps, violations=verified.violations)


def _finite_optional(value: object) -> float | None:
    if value is None:
        return None
    number = float(value)
    return number if isfinite(number) else None


def _sparse(rows: tuple[dict[int, float], ...], columns: int):
    """Construct CSC directly from nonzero incidence, without a dense copy."""
    from scipy.sparse import csc_array

    values, row_indices, column_indices = [], [], []
    for row_number, row in enumerate(rows):
        for column, value in row.items():
            values.append(value)
            row_indices.append(row_number)
            column_indices.append(column)
    return csc_array((values, (row_indices, column_indices)), shape=(len(rows), columns))
