"""Explicit Excel settlement inputs to the independent operational ledger.

The ledger does not infer loan-agent interest allocation, refresh quotes or
initialize an existing CLO's waterfall. Cash collection events and permissions
are independent verified inputs. Empty controls disable the ledger only when
all its other input tables are empty as well.
"""

from fractions import Fraction
from trident.domain.models import InputValidationError
from trident.domain.numeric import post_currency
from trident.portfolio import (CashAccount, CashBalances, CashReceivable, HoldingStatus,
    HoldingsLedgerRequest, HoldingsLedgerService, LedgerEvent, LedgerEventKind,
    LedgerPermissions, OpeningHolding, TradeCommitment, TradeSide)
from . import excel_schema as schema
from .records import boolean_value, date_value, decimal_value, text_value


def ledger_request_from_workbook(adapter):
    def records(key):
        return adapter.table_records(schema.TABLE_RANGE_NAMES[key], schema.TABLE_NAMES[key])
    controls = records('ledger_controls')
    holding_rows, trade_rows, event_rows, claim_rows = (
        records(key) for key in ('opening_holdings', 'trade_ledger', 'ledger_events', 'opening_receivables'))
    if not controls:
        if any((holding_rows, trade_rows, event_rows, claim_rows)):
            raise InputValidationError('Ledger inputs require exactly one Ledger Controls opening snapshot')
        return None
    if len(controls) != 1:
        raise InputValidationError('Ledger Controls requires exactly one row')
    control = controls[0]
    asof = date_value(control.get('as_of_date'), 'ledger as_of_date')
    currency = text_value(control.get('currency'), 'ledger currency')
    def money(row, field, *, optional=False):
        value = row.get(field)
        if optional and value in (None, ''):
            value = 0
        return decimal_value(value, field)
    def optional_money(row, field):
        return None if row.get(field) in (None, '') else money(row, field)
    def optional_text(row, field):
        return None if row.get(field) in (None, '') else text_value(row[field], field)
    holdings = tuple(OpeningHolding(text_value(row.get('asset_id'), 'asset_id'),
        text_value(row.get('currency'), 'holding currency'), money(row, 'settled_par'),
        HoldingStatus(text_value(row.get('status'), 'holding status'))) for row in holding_rows)
    trades = tuple(TradeCommitment(
        trade_id=text_value(row.get('trade_id'), 'trade_id'), asset_id=text_value(row.get('asset_id'), 'asset_id'),
        side=TradeSide(text_value(row.get('side'), 'trade side')),
        trade_date=date_value(row.get('trade_date'), 'trade_date'), settlement_date=date_value(row.get('settlement_date'), 'settlement_date'),
        par=money(row, 'par'), clean_price_pct=money(row, 'clean_price_pct'),
        accrued_cash=money(row, 'accrued_cash', optional=True), fees_cash=money(row, 'fees_cash', optional=True),
        accrued_account=CashAccount(text_value(row.get('accrued_account'), 'accrued account')),
        fee_account=CashAccount(text_value(row.get('fee_account'), 'fee account')),
        lot_size=optional_money(row, 'lot_size'), minimum_ticket=money(row, 'minimum_ticket', optional=True),
        maximum_par=optional_money(row, 'maximum_par'), currency=currency) for row in trade_rows)
    events = tuple(LedgerEvent(
        event_id=text_value(row.get('event_id'), 'event_id'), event_date=date_value(row.get('event_date'), 'event_date'),
        kind=LedgerEventKind(text_value(row.get('kind'), 'event kind')), source=text_value(row.get('source'), 'event source'),
        asset_id=optional_text(row, 'asset_id'), principal_cash=money(row, 'principal_cash', optional=True),
        interest_cash=money(row, 'interest_cash', optional=True), par_reduction=money(row, 'par_reduction', optional=True),
        trade_id=optional_text(row, 'trade_id'), receivable_id=optional_text(row, 'receivable_id')) for row in event_rows)
    claims = tuple(CashReceivable(text_value(row.get('receivable_id'), 'receivable_id'),
        text_value(row.get('asset_id'), 'receivable asset_id'),
        date_value(row.get('recognition_date'), 'claim recognition_date'), date_value(row.get('due_date'), 'claim due_date'),
        money(row, 'principal_cash', optional=True), money(row, 'interest_cash', optional=True),
        text_value(row.get('source'), 'claim source')) for row in claim_rows)
    return HoldingsLedgerRequest(asof, date_value(control.get('horizon_date'), 'ledger horizon_date'), currency,
        CashBalances(money(control, 'principal_cash'), money(control, 'interest_cash')), holdings,
        trades=tuple(trade for trade in trades if trade.trade_date >= asof), events=events,
        opening_commitments=tuple(trade for trade in trades if trade.trade_date < asof), opening_receivables=claims,
        permissions=LedgerPermissions(boolean_value(control.get('allow_principal_for_accrued'), 'principal accrued permission'),
            boolean_value(control.get('allow_principal_for_fees'), 'principal fee permission')),
        source=text_value(control.get('source'), 'ledger source'))


def ledger_reports(request):
    """Cash/par/commitment/receivable reports share one deterministic replay."""
    keys = ('ledger_snapshots', 'ledger_positions', 'ledger_journal', 'ledger_pending')
    if request is None:
        return {key: () for key in keys}
    result = HoldingsLedgerService().replay(request)
    # Opening is a distinct state only when same-day events change it. Prevent
    # indistinguishable duplicated observation dates in the Excel report.
    states = {result.opening_snapshot.as_of_date: result.opening_snapshot}
    states.update({item.as_of_date: item for item in result.snapshots})
    snapshots = tuple(states[day] for day in sorted(states))
    cash_rows, position_rows = [], []
    for item in snapshots:
        cash_rows.append(dict(as_of_date=item.as_of_date, currency=item.currency,
            settled_par=item.settled_par, performing_par=item.performing_par, defaulted_par=item.defaulted_par,
            committed_buy_par=item.committed_buy_par, committed_sell_par=item.committed_sell_par,
            trade_date_par=item.trade_date_par, principal_cash=item.cash.principal, interest_cash=item.cash.interest,
            reserved_principal=item.reserved_cash.principal, reserved_interest=item.reserved_cash.interest,
            available_principal=item.available_cash.principal, available_interest=item.available_cash.interest,
            receivable_principal=post_currency(sum((Fraction(claim.principal_cash) for claim in item.receivables), Fraction())),
            receivable_interest=post_currency(sum((Fraction(claim.interest_cash) for claim in item.receivables), Fraction()))))
        position_rows.extend(dict(as_of_date=item.as_of_date, asset_id=holding.asset_id, currency=holding.currency,
            status=holding.status.value, settled_par=holding.settled_par, available_to_sell=item.available_to_sell(holding.asset_id))
            for holding in item.holdings)
    # Supplied cash/default events retain their individual evidence source.
    # Generated commitment/settlement entries use the opening ledger source;
    # matching kind as well as ID prevents a user ID collision from borrowing
    # the provenance of an unrelated generated entry.
    event_sources = {(item.event_id, item.kind.value): item.source for item in request.events}
    journal = tuple(dict(event_date=item.event_date, event_type=item.kind, reference_id=item.entry_id,
        asset_id=item.asset_id, principal_cash_change=item.principal_cash_change,
        interest_cash_change=item.interest_cash_change, settled_par_change=item.par_change,
        source=event_sources.get((item.entry_id, item.kind), request.source)) for item in result.journal)
    final = result.final_snapshot
    pending = tuple(dict(kind='COMMITMENT', reference_id=item.trade.trade_id, asset_id=item.trade.asset_id,
        due_date=item.trade.settlement_date, side=item.trade.side.value, par=item.trade.par,
        principal_cash=post_currency(Fraction(item.settlement_receivable.principal) - Fraction(item.reserved_cash.principal)),
        interest_cash=post_currency(Fraction(item.settlement_receivable.interest) - Fraction(item.reserved_cash.interest)),
        source=request.source) for item in final.pending_trades)
    pending += tuple(dict(kind='RECEIVABLE', reference_id=item.receivable_id, asset_id=item.asset_id,
        due_date=item.due_date, side=None, par=None, principal_cash=item.principal_cash,
        interest_cash=item.interest_cash, source=item.source) for item in final.receivables)
    return dict(zip(keys, (tuple(cash_rows), tuple(position_rows), journal, pending)))
