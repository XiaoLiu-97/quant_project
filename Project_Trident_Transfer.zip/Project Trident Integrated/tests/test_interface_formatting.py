"""Known units and workbook identities survive display-only publication.

Small native workbook fixtures exercise hidden cases, dated observations and
protected inputs independently of the large production template. Assertions
bind exact numeric/date payloads as well as displayed units, so a formatting
repair cannot pass by rounding values or weakening input protection.
"""
from datetime import date
from decimal import Decimal
from pathlib import Path
from tempfile import TemporaryDirectory
from types import SimpleNamespace
import unittest

from openpyxl import Workbook,load_workbook
from openpyxl.styles import Border,Font,PatternFill,Side
from openpyxl.workbook.defined_name import DefinedName
from openpyxl.worksheet.table import Table

from trident.adapters.interface_capacity import InputCapacityPolicy,prepare_input_capacity
from trident.adapters.interface_output import (_audit_limit_formats,_input_limit_formats,
                                               _limit_result_formats)
from trident.adapters.interface_package import WorkbookPackage
from trident.adapters.interface_reporting import (CASH_FORMAT,DATE_FORMAT,FACE_FORMAT,
                                                  PREFIX,metric_format,number_formats,unit_format)
from trident.domain.models import InputValidationError

D=Decimal
OPEN=date(2026,11,20)
NEXT=date(2027,2,22)


def portfolio(entries,*,as_of=OPEN,phase='OPENING'):
    """One independent metric/unit set, with arbitrary but stable limit IDs."""
    return SimpleNamespace(
        as_of_date=as_of,phase=phase,
        metrics=tuple(SimpleNamespace(name=metric,unit=unit) for _,metric,unit in entries),
        limits=tuple(SimpleNamespace(limit_id=identity,metric=metric) for identity,metric,_ in entries))


class InterfaceFormattingTests(unittest.TestCase):
    def setUp(self):
        self.temporary=TemporaryDirectory()
        self.addCleanup(self.temporary.cleanup)
        self.root=Path(self.temporary.name)
        self.source=self.root/'source.xlsx'
        book=Workbook();home=book.active;home.title='Home'
        home['D2']='BASELINE'
        book.defined_names.add(DefinedName('trident_ui_schema',attr_text='"1.0"'))
        book.defined_names.add(DefinedName('trident_ui_analysis_case',attr_text="'Home'!$D$2"))
        book.create_sheet('CLO Analysis')
        book.save(self.source);book.close()

    def saved(self,package,name='result.xlsx'):
        target=package.save(self.root/name)
        book=load_workbook(target,data_only=True)
        self.addCleanup(book.close)
        return book

    def table_formats(self,book,package,name,column):
        info=package.table_inventory()[name]
        c=info.bounds[0]+info.headers.index(column)
        return [book[info.sheet].cell(row,c).number_format
                for row in range(info.bounds[1]+1,info.bounds[3]+1)]

    def test_cash_principal_face_inventory_ratios_and_prices_have_distinct_units(self):
        cash=('eligible_asset_principal','debt_principal_from_principal',
              'equity_from_principal','collateral_sale_proceeds','collateral_sale_gain_loss',
              'refinancing_fee','interest_diversion_test_held_principal',
              'principal_from_principal','gate_ic_numerator','period_end_ic_denominator',
              'incentive_hurdle_balance','note_pik_capitalized')
        face=('par','reinvestment_par_acquired','oc_defaulted_value','oc_ccc_haircut',
              'collateral_non_cash_par_change','opening_collateral_par',
              'gate_oc_numerator','post_diversion_oc_denominator')
        headers=(*cash,*face,'fraction','Issue price / 100','oc_minimum','ic_minimum',
                 'Settlement','future_custom_measure')
        formats=number_formats(headers)
        for field in cash:self.assertEqual(formats[field],CASH_FORMAT,field)
        for field in face:self.assertEqual(formats[field],FACE_FORMAT,field)
        self.assertEqual(formats['fraction'],'0.00%')
        self.assertEqual(formats['Issue price / 100'],'0.00')
        self.assertEqual(formats['oc_minimum'],'0.0000"x"')
        self.assertEqual(formats['ic_minimum'],'0.0000"x"')
        self.assertEqual(formats['Settlement'],DATE_FORMAT)
        self.assertNotIn('future_custom_measure',formats)

    def test_unknown_units_do_not_guess_percent_and_currency_face_keeps_inventory_semantics(self):
        self.assertEqual(unit_format('FRACTION'),'0.00%')
        self.assertEqual(unit_format('years_ACT365F'),'0.000')
        self.assertEqual(unit_format('rating_factor'),'#,##0')
        self.assertEqual(unit_format('EUR'),CASH_FORMAT)
        self.assertEqual(unit_format('custom_unit'),'General')
        self.assertEqual(metric_format('CUSTOM_FRACTION','custom_unit'),'General')
        self.assertEqual(metric_format('concentration:sector:energy'),'0.00%')
        self.assertEqual(metric_format('Collateral face','EUR'),FACE_FORMAT)
        self.assertEqual(metric_format('COLLATERAL_PAR','EUR'),FACE_FORMAT)
        self.assertEqual(metric_format('Equity funding','EUR'),CASH_FORMAT)

    def test_limit_reader_and_hidden_cases_join_units_by_case_and_identity(self):
        package=WorkbookPackage(self.source)
        headers=('Limit','Value','Threshold','Headroom','Result')
        package.add_table(PREFIX+'limit_results',headers,())
        rows=(
            {'Limit':'SHARE','Value':D('.7'),'Threshold':D('.6'),'Headroom':D('.1'),'Result':'PASS'},
            {'Limit':'WAL','Value':D('5.7923'),'Threshold':D(7),'Headroom':D('1.2077'),'Result':'PASS'},
            {'Limit':'FACTOR','Value':D(2120),'Threshold':D(2300),'Headroom':D(180),'Result':'PASS'},
            {'Limit':'CASH','Value':D('12.34'),'Threshold':D('10.01'),'Headroom':D('2.33'),'Result':'PASS'},
            {'Limit':'WAS','Value':D('337.5'),'Threshold':D(300),'Headroom':D('37.5'),'Result':'PASS'},
            {'Limit':'CUSTOM','Value':'n.a.','Threshold':D('1.23'),'Headroom':'n.a.','Result':'UNAVAILABLE'})
        base=portfolio((('SHARE','INFRA_FRACTION','fraction'),('WAL','WAL_YEARS','years_ACT365F'),
                        ('FACTOR','TEST_FACTOR_AVERAGE','synthetic_factor'),('CASH','AVAILABLE_CASH','EUR'),
                        ('WAS','WAS_BPS','bps'),('CUSTOM','CUSTOM','custom_unit')))
        # The second complete case deliberately reorders IDs and uses a custom
        # unit under the same ID. A baseline positional/ID-only join fails it.
        other=portfolio((('FACTOR','CUSTOM','custom_unit'),('WAL','WAL_YEARS','years_ACT365F')))
        cases={'BASELINE':rows,'OTHER':(rows[2],rows[1])}
        run=SimpleNamespace(cases=tuple(SimpleNamespace(case_id=i,result=SimpleNamespace(opening_portfolio=p))
                                       for i,p in (('BASELINE',base),('OTHER',other))))
        package.add_case_view(PREFIX+'limit_results',cases)
        before=package._table_records(PREFIX+'results_limit_results')
        _limit_result_formats(package,PREFIX+'limit_results',cases,run)
        book=self.saved(package)
        expected=['0.00%','0.000','#,##0',CASH_FORMAT,'0.00','General']
        for field in ('Value','Threshold','Headroom'):
            self.assertEqual(self.table_formats(book,package,PREFIX+'limit_results',field),expected)
            self.assertEqual(self.table_formats(book,package,PREFIX+'results_limit_results',field),
                             [*expected,'General','0.000'])
        self.assertEqual(package._table_records(PREFIX+'results_limit_results'),before)
        self.assertNotIn('Unit',package.table_inventory()[PREFIX+'limit_results'].headers)
        package.write_scalar('trident_ui_analysis_case','OTHER')
        package.add_case_view(PREFIX+'limit_results',cases)
        _limit_result_formats(package,PREFIX+'limit_results',cases,run)
        book=self.saved(package,'other.xlsx')
        self.assertEqual(self.table_formats(book,package,PREFIX+'limit_results','Value')[:2],['General','0.000'])

    def test_dated_audit_uses_same_case_date_and_phase_not_opening_units(self):
        package=WorkbookPackage(self.source)
        opening=portfolio((('X','CUSTOM','fraction'),))
        later=portfolio((('X','CUSTOM','EUR'),),as_of=NEXT,phase='AFTER_PAYMENT')
        other=portfolio((('X','CUSTOM','years_ACT365F'),),as_of=NEXT,phase='AFTER_PAYMENT')
        records=tuple({'Case':case,'as_of_date':report.as_of_date,'phase':report.phase,
                       'limit_id':'X','metric':'CUSTOM','value':value,'threshold':D('1.23'),'headroom':'n.a.'}
                      for case,report,value in (('BASELINE',opening,D('.5')),
                                               ('BASELINE',later,D('12.34')),('OTHER',other,D('7.125'))))
        name=PREFIX+'audit_limit_tests'
        package.add_table(name,tuple(records[0]),records,number_formats=number_formats(tuple(records[0])))
        run=SimpleNamespace(cases=(
            SimpleNamespace(case_id='BASELINE',result=SimpleNamespace(opening_portfolio=opening,
                            portfolio_observations=(opening,later))),
            SimpleNamespace(case_id='OTHER',result=SimpleNamespace(opening_portfolio=other,
                            portfolio_observations=(other,)))))
        before=package._table_records(name)
        _audit_limit_formats(package,name,records,run)
        book=self.saved(package)
        for column in ('value','threshold','headroom'):
            self.assertEqual(self.table_formats(book,package,name,column),['0.00%',CASH_FORMAT,'0.000'])
        self.assertEqual(self.table_formats(book,package,name,'as_of_date'),[DATE_FORMAT]*3)
        self.assertEqual(package._table_records(name),before)

    def test_protected_threshold_styles_change_without_rewriting_or_weakening_owner(self):
        book=load_workbook(self.source);sheet=book.create_sheet('Inputs')
        rows=(('Limit ID','Metric','Threshold','Enabled'),
              ('SHARE','INFRA_FRACTION',.6,True),('FACTOR','WARF',2300,True),
              ('WAL','WAL_YEARS',7.125,False),('WAS','WAS_BPS',337.5,True),
              ('CASH','AVAILABLE_CASH',12.34,True),(None,None,None,None))
        for row in rows:sheet.append(row)
        for row in range(2,8):sheet.cell(row,3).number_format='0.00%'
        name=PREFIX+'limits';sheet.add_table(Table(displayName=name,ref='A1:D7'))
        book.defined_names.add(DefinedName('trident_ui_limits',attr_text="'Inputs'!$A$1:$D$7"))
        book.save(self.source);book.close()
        package=WorkbookPackage(self.source,protected_names=('trident_ui_limits',),protected_tables=(name,))
        before=package._table_records(name)
        p=portfolio((('SHARE','INFRA_FRACTION','fraction'),('FACTOR','WARF','rating_factor'),
                     ('WAL','WAL_YEARS','years_ACT365F'),('WAS','WAS_BPS','bps'),
                     ('CASH','AVAILABLE_CASH','EUR')))
        _input_limit_formats(package,SimpleNamespace(baseline=SimpleNamespace(opening_portfolio=p)))
        self.assertEqual(package._table_records(name),before)
        with self.assertRaises(InputValidationError):package.write_table(name,before)
        with self.assertRaises(InputValidationError):package.write_cells('Inputs',{'C2':0})
        with self.assertRaises(InputValidationError):package.set_cell_number_formats('Inputs',{'C2':'0'})
        book=self.saved(package)
        self.assertEqual(self.table_formats(book,package,name,'Threshold'),
                         ['0.00%','#,##0','0.000','0.00',CASH_FORMAT,'General'])
        self.assertEqual(book['Inputs']['C5'].value,337.5)

    def test_date_dropdown_refresh_retains_numeric_identity_and_unified_format_on_repeat(self):
        book=load_workbook(self.source);sheet=book['CLO Analysis'];sheet['O6']=OPEN
        sheet['O6'].number_format='yyyy-mm-dd'
        book.defined_names.add(DefinedName('trident_ui_analysis_date',attr_text="'CLO Analysis'!$O$6"))
        book.save(self.source);book.close()
        package=WorkbookPackage(self.source)
        name=PREFIX+'analysis_options_date';package.add_table(name,('Date',),())
        run=SimpleNamespace(cases=(SimpleNamespace(case_id='BASELINE',result=SimpleNamespace(
            clo=SimpleNamespace(periods=(SimpleNamespace(payment_date=NEXT),)))),))
        package.refresh_date_options(run);package.refresh_date_options(run)
        book=self.saved(package)
        self.assertEqual(book['CLO Analysis']['O6'].number_format,DATE_FORMAT)
        self.assertEqual(book['CLO Analysis']['O6'].value.date(),NEXT)
        for table in (name,PREFIX+'results_analysis_options_date'):
            self.assertEqual(self.table_formats(book,package,table,'Date'),[DATE_FORMAT])
            self.assertEqual(package._table_records(table)[0]['Date'],
                             package._table_records(name)[0]['Date'])
        self.assertEqual(package.named_region('trident_ui_analysis_options_date')[1][3],
                         package.table_inventory()[name].bounds[1]+1)

    def test_column_numeric_refresh_preserves_each_existing_rows_manual_style(self):
        book=load_workbook(self.source);sheet=book.create_sheet('Output')
        sheet.append(('Cash','Date'));sheet.append((12.34,NEXT));sheet.append((56.78,OPEN))
        sheet['A2'].fill=PatternFill('solid',fgColor='FF00AA00')
        sheet['A3'].fill=PatternFill('solid',fgColor='FFFFAA00')
        sheet['A3'].font=Font(name='Arial',size=12,bold=True,color='FF001199')
        sheet['A3'].border=Border(bottom=Side(style='double',color='FF000000'))
        sheet.add_table(Table(displayName=PREFIX+'styles',ref='A1:B3'))
        book.save(self.source);book.close()
        package=WorkbookPackage(self.source)
        records=({'Cash':D('12.34'),'Date':NEXT},{'Cash':D('56.78'),'Date':OPEN})
        for _ in range(2):package.write_table(PREFIX+'styles',records,number_formats={'Cash':CASH_FORMAT,'Date':DATE_FORMAT})
        book=self.saved(package)
        self.assertEqual(book['Output']['A3'].fill.fgColor.rgb,'FFFFAA00')
        self.assertEqual(book['Output']['A3'].font.color.rgb,'FF001199')
        self.assertEqual(book['Output']['A3'].font.sz,12)
        self.assertTrue(book['Output']['A3'].font.b)
        self.assertEqual(book['Output']['A3'].border.bottom.style,'double')
        self.assertEqual(book['Output']['A3'].number_format,CASH_FORMAT)
        self.assertEqual(book['Output']['A3'].value,56.78)

    def test_dynamic_metric_reader_uses_saved_unit_precision_without_english_general(self):
        package=WorkbookPackage(self.source)
        rows=tuple({'Group':'Review','Metric':metric,'Value':value,'Unit':unit}
                   for metric,value,unit in (
                       ('IRR',D('.0329'),'annual return'),('MOIC',D('1.1234'),'multiple'),
                       ('WAL',D('5.7923'),'years_ACT365F'),('WARF',D(2120),'rating_factor'),
                       ('WAS',D('337.5'),'bps'),('Collateral face',D('500000000.01'),'EUR'),
                       ('Equity funding',D('53475000.01'),'EUR'),('Custom',D('1.2345'),'custom_unit')))
        package.add_table(PREFIX+'analysis_details',tuple(rows[0]),rows)
        package.add_table(PREFIX+'analysis_options_metric',('Metric','Row index','Display format'),())
        package.define_name('trident_ui_analysis_metric','Home','F10')
        before=package._table_records(PREFIX+'analysis_details')
        for _ in range(2):package.refresh_metric_catalog()
        formats=[row['Display format'] for row in package._table_records(PREFIX+'analysis_options_metric')]
        self.assertEqual(formats,['0.00%','0.000"x"','0.000','#,##0','0.00',
                                  FACE_FORMAT,CASH_FORMAT,'0.###############'])
        self.assertNotIn('General',formats)
        self.assertEqual(package._table_records(PREFIX+'analysis_details'),before)

    def test_new_mixed_input_capacity_is_general_existing_date_type_is_retained(self):
        book=load_workbook(self.source);sheet=book.create_sheet('Scenarios')
        rows=(('Scenario ID','Field','New value'),('S1','spread_bps',150),
              ('S2','maturity_date',NEXT))
        for row in rows:sheet.append(row)
        sheet['C2'].number_format='0.0';sheet['C3'].number_format=DATE_FORMAT
        name=PREFIX+'scenario_edits';sheet.add_table(Table(displayName=name,ref='A1:C3'))
        book.save(self.source);book.close()
        package=WorkbookPackage(self.source,protected_tables=(name,))
        policy=InputCapacityPolicy(scenario_edit_rows=5)
        prepare_input_capacity(package,policy)
        book=self.saved(package)
        self.assertEqual(book['Scenarios']['C2'].number_format,'0.0')
        self.assertEqual(book['Scenarios']['C3'].number_format,DATE_FORMAT)
        self.assertEqual(book['Scenarios']['C3'].value.date(),NEXT)
        self.assertEqual([book['Scenarios'].cell(row,3).number_format for row in range(4,7)],['General']*3)
        self.assertTrue(all(book['Scenarios'].cell(row,3).value is None for row in range(4,7)))


if __name__=='__main__':unittest.main()
