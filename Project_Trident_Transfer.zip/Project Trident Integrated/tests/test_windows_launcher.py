"""Exercise the real Windows batch launcher without calculating a workbook.

A tiny temporary project replaces only the financial entry point and optional
package imports. Native cmd.exe still parses the delivered launcher, resolves
its interpreter, anchors a Unicode path and blocks at its final pause. These
checks protect the one-click user path that pure Python CLI tests do not cover.
"""

import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time
from tempfile import TemporaryDirectory
import unittest
import venv

PROJECT = Path(__file__).resolve().parents[1]
LAUNCHER = PROJECT / "Run_Model.cmd"


class LauncherEncodingTests(unittest.TestCase):
    def test_batch_is_ascii_and_has_single_windows_line_endings(self):
        data = LAUNCHER.read_bytes()
        data.decode("ascii")
        self.assertNotIn(b"\r\r\n", data)
        self.assertEqual(data.replace(b"\r\n", b""), data.replace(b"\n", b"").replace(b"\r", b""))
        self.assertTrue(data.endswith(b"\r\n"))
        self.assertNotIn(b"\x00", data)


@unittest.skipUnless(os.name == "nt", "Native cmd.exe launcher integration requires Windows")
class WindowsLauncherTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.temporary = TemporaryDirectory(prefix="trident-launcher-tests-")
        cls.root = Path(cls.temporary.name)
        cls.project = cls.root / "Unicode 空间 (test) & project"
        cls.project.mkdir()
        shutil.copyfile(LAUNCHER, cls.project / "Run_Model.cmd")
        (cls.project / "outputs").mkdir()
        cls.workbook = cls.project / "outputs" / "Project_Trident.xlsx"
        cls.fixture = b"UNCHANGED STUB WORKBOOK"
        (cls.project / "src" / "trident").mkdir(parents=True)
        (cls.project / "src" / "trident" / "__init__.py").write_text("", encoding="utf-8")
        (cls.project / "src" / "trident" / "__main__.py").write_text(
            'import json, os, sys\n'
            'print("STUB_RESULT=" + json.dumps({"args": sys.argv[1:], "cwd": os.getcwd(), "executable": sys.executable}))\n'
            'raise SystemExit(int(os.environ.get("TRIDENT_TEST_EXIT", "0")))\n',
            encoding="utf-8",
        )
        # Dummy package modules isolate launcher diagnostics from financial
        # dependencies. An explicit failure flag exercises the preflight path.
        for dependency in ("openpyxl", "numpy", "scipy"):
            (cls.project / "src" / (dependency + ".py")).write_text(
                'import os\n'
                'if os.environ.get("TRIDENT_TEST_IMPORT_FAIL") == __name__: raise ImportError("Injected package failure")\n',
                encoding="utf-8",
            )
        venv.EnvBuilder(with_pip=False, system_site_packages=True).create(cls.project / ".venv")
        cls.interpreter_tools = cls.root / "interpreter-tools"
        cls.interpreter_tools.mkdir()
        # Native temporary shims make PATH discovery deterministic. The real
        # Windows Python launcher depends on per-user version registration,
        # which can select a different interpreter under restricted tokens.
        # Only dispatch is replaced: the declared test interpreter still runs
        # the delivered batch preflight and its actual financial-entry stub.
        shim_source = cls.interpreter_tools / "InterpreterShim.cs"
        shim_source.write_text(r"""
using System;
using System.Diagnostics;
using System.IO;
using System.Text;
public class InterpreterShim {
    static string Quote(string argument) {
        StringBuilder result = new StringBuilder();
        result.Append((char)34);
        int backslashes = 0;
        foreach (char character in argument) {
            if (character == (char)92) { backslashes++; continue; }
            if (character == (char)34) {
                result.Append((char)92, backslashes * 2 + 1);
                result.Append(character);
            } else {
                result.Append((char)92, backslashes);
                result.Append(character);
            }
            backslashes = 0;
        }
        result.Append((char)92, backslashes * 2);
        result.Append((char)34);
        return result.ToString();
    }
    public static int Main(string[] args) {
        if (Path.GetFileName(Process.GetCurrentProcess().MainModule.FileName).Equals("where.exe", StringComparison.OrdinalIgnoreCase)) {
            // Isolate discovery as well: restricted Windows tokens can filter
            // where.exe directory enumeration while direct invocation works.
            string candidate = Path.Combine(Environment.GetEnvironmentVariable("TRIDENT_TEST_TOOLS"), args[0]);
            if (File.Exists(candidate)) { Console.WriteLine(candidate); return 0; }
            return 1;
        }
        int first = args.Length > 0 && args[0] == "-3" ? 1 : 0;
        StringBuilder arguments = new StringBuilder();
        for (int index = first; index < args.Length; index++) {
            if (index > first) arguments.Append(' ');
            arguments.Append(Quote(args[index]));
        }
        ProcessStartInfo info = new ProcessStartInfo(
            Environment.GetEnvironmentVariable("TRIDENT_TEST_INTERPRETER"), arguments.ToString());
        info.UseShellExecute = false;
        info.CreateNoWindow = true;
        info.RedirectStandardOutput = true;
        info.RedirectStandardError = true;
        using (Process child = new Process()) {
            child.StartInfo = info;
            child.OutputDataReceived += (sender, eventArgs) => {
                if (eventArgs.Data != null) Console.WriteLine(eventArgs.Data);
            };
            child.ErrorDataReceived += (sender, eventArgs) => {
                if (eventArgs.Data != null) Console.Error.WriteLine(eventArgs.Data);
            };
            child.Start();
            child.BeginOutputReadLine();
            child.BeginErrorReadLine();
            child.WaitForExit();
            return child.ExitCode;
        }
    }
}
""", encoding="utf-8")
        compiler = Path(os.environ["SYSTEMROOT"]) / "Microsoft.NET" / "Framework64" / "v4.0.30319" / "csc.exe"
        if not compiler.exists():
            compiler = Path(os.environ["SYSTEMROOT"]) / "Microsoft.NET" / "Framework" / "v4.0.30319" / "csc.exe"
        compiled = subprocess.run(
            [str(compiler), "/nologo", "/target:exe", "/out:" + str(cls.interpreter_tools / "py.exe"), str(shim_source)],
            stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=30,
        )
        if compiled.returncode:
            raise AssertionError("Could not build the controlled test interpreter shim: " + compiled.stdout.decode("utf-8", errors="replace"))
        shutil.copyfile(cls.interpreter_tools / "py.exe", cls.interpreter_tools / "python.exe")
        shutil.copyfile(cls.interpreter_tools / "py.exe", cls.interpreter_tools / "where.exe")

    @classmethod
    def tearDownClass(cls):
        cls.temporary.cleanup()

    def setUp(self):
        self.workbook.write_bytes(self.fixture)
        self.environment = os.environ.copy()
        self.environment.pop("TRIDENT_TEST_EXIT", None)
        self.environment.pop("TRIDENT_TEST_IMPORT_FAIL", None)
        self.environment["TRIDENT_TEST_INTERPRETER"] = sys.executable
        self.environment["TRIDENT_TEST_TOOLS"] = str(self.interpreter_tools)

    def run_launcher(self):
        # File Explorer launches batch files through cmd.exe. Feed a newline
        # only after confirming its own pause keeps the console process alive.
        process = subprocess.Popen(
            f'"{os.environ.get("COMSPEC", "cmd.exe")}" /d /s /c ""{self.project / "Run_Model.cmd"}""',
            cwd=self.root,
            env=self.environment,
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
        )
        try:
            time.sleep(0.5)
            if process.poll() is not None:
                output, _ = process.communicate()
                self.fail("Console closed before pause: " + output.decode("utf-8", errors="replace"))
            output, _ = process.communicate(input=b"\n", timeout=25)
        finally:
            if process.poll() is None:
                process.kill()
                process.communicate()
        if self.workbook.exists():
            self.assertEqual(self.workbook.read_bytes(), self.fixture)
        return process.returncode, output.decode("utf-8", errors="replace")

    def test_success_shows_start_completion_and_resolves_unicode_project_path(self):
        status, output = self.run_launcher()
        self.assertEqual(status, 0, output)
        self.assertIn("Project Trident - Model calculation", output)
        self.assertIn("[1/2] Checking Python", output)
        self.assertIn("[2/2] Calculating and saving", output)
        self.assertIn("SUCCESS: Calculation completed", output)
        self.assertIn("Press any key to close", output)
        payload = json.loads(output.split("STUB_RESULT=", 1)[1].splitlines()[0])
        self.assertEqual(payload["args"], ["workbook", "outputs\\Project_Trident.xlsx"])
        self.assertEqual(Path(payload["cwd"]), self.project)
        self.assertEqual(Path(payload["executable"]), self.project / ".venv" / "Scripts" / "python.exe")

    def test_financial_error_is_visible_paused_and_preserves_exit_status(self):
        self.environment["TRIDENT_TEST_EXIT"] = "7"
        status, output = self.run_launcher()
        self.assertEqual(status, 7, output)
        self.assertIn("ERROR: Calculation failed", output)
        self.assertIn("last complete workbook was retained", output)
        self.assertNotIn("SUCCESS:", output)
        self.assertIn("Press any key to close", output)

    def test_missing_package_is_visible_and_does_not_run_the_model(self):
        self.environment["TRIDENT_TEST_IMPORT_FAIL"] = "openpyxl"
        status, output = self.run_launcher()
        self.assertEqual(status, 2, output)
        self.assertIn("Injected package failure", output)
        self.assertIn("ERROR: Python or a required package", output)
        self.assertIn('pip install -e ".[excel,optimization]"', output)
        self.assertNotIn("STUB_RESULT=", output)
        self.assertIn("Press any key to close", output)

    def test_optional_solver_packages_do_not_block_the_excel_workflow(self):
        # The solver owns its dependency check when optimization is selected.
        # A plain Excel cashflow/CLO run requires only the excel extra.
        for dependency in ("numpy", "scipy"):
            with self.subTest(dependency=dependency):
                self.environment["TRIDENT_TEST_IMPORT_FAIL"] = dependency
                status, output = self.run_launcher()
                self.assertEqual(status, 0, output)
                self.assertIn("STUB_RESULT=", output)
                self.assertIn("SUCCESS: Calculation completed", output)
                self.assertNotIn("Injected package failure", output)

    def test_missing_workbook_is_visible_and_does_not_run_the_model(self):
        self.workbook.unlink()
        status, output = self.run_launcher()
        self.assertEqual(status, 2, output)
        self.assertIn("Project_Trident.xlsx was not found", output)
        self.assertNotIn("STUB_RESULT=", output)
        self.assertIn("Press any key to close", output)

    def test_py_launcher_fallback_runs_without_a_project_environment(self):
        environment_path = self.project / ".venv"
        inactive_path = self.project / "inactive-environment"
        environment_path.rename(inactive_path)
        self.environment["PATH"] = str(self.interpreter_tools) + os.pathsep + str(Path(os.environ["SYSTEMROOT"]) / "System32")
        try:
            status, output = self.run_launcher()
        finally:
            inactive_path.rename(environment_path)
        self.assertEqual(status, 0, output)
        self.assertIn('Python: "py.exe" -3', output)
        self.assertIn("STUB_RESULT=", output)
        self.assertIn("SUCCESS: Calculation completed", output)

    def test_python_fallback_runs_when_py_launcher_is_not_on_path(self):
        environment_path = self.project / ".venv"
        inactive_path = self.project / "inactive-environment"
        environment_path.rename(inactive_path)
        py_shim = self.interpreter_tools / "py.exe"
        inactive_shim = self.interpreter_tools / "inactive-py.exe"
        py_shim.rename(inactive_shim)
        self.environment["PATH"] = str(self.interpreter_tools) + os.pathsep + str(Path(os.environ["SYSTEMROOT"]) / "System32")
        try:
            status, output = self.run_launcher()
        finally:
            inactive_shim.rename(py_shim)
            inactive_path.rename(environment_path)
        self.assertEqual(status, 0, output)
        self.assertIn('Python: "python.exe"', output)
        self.assertIn("STUB_RESULT=", output)
        self.assertIn("SUCCESS: Calculation completed", output)

    def test_missing_python_is_visible_and_paused(self):
        # Remove only this temporary environment from interpreter discovery;
        # Windows System32 retains where.exe but has no Python installation.
        environment_path = self.project / ".venv"
        inactive_path = self.project / "inactive-environment"
        environment_path.rename(inactive_path)
        self.environment["PATH"] = str(Path(os.environ["SYSTEMROOT"]) / "System32")
        try:
            status, output = self.run_launcher()
        finally:
            inactive_path.rename(environment_path)
        self.assertEqual(status, 2, output)
        self.assertIn("ERROR: Python was not found", output)
        self.assertNotIn("STUB_RESULT=", output)
        self.assertIn("Press any key to close", output)


if __name__ == "__main__":
    unittest.main()
