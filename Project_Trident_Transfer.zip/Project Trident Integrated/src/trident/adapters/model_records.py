"""Translate semantic external fields into the unified model request."""

from dataclasses import asdict
from datetime import date
from decimal import Decimal
from enum import Enum
from typing import Mapping

from trident.analysis import AssetExposure, FactorMapping, LimitDirection, LimitSpec
from trident.application.clo_services import TridentModelRequest
from trident.clo.models import (CloTerms, NoteTranche, RecurringSeniorExpense, PrincipalRepaymentMode,
                             InterestDiversionMode, ManagementFeeBasis, CashAccountAccrualMode)
from trident.conventions import AccrualDateBasis, BusinessDayConvention, DayCount, StubConvention
from trident.conventions.calendar import CalendarName
from trident.domain.models import CouponType, InputValidationError
from trident.domain.numeric import basis_points_rate
from trident.market import RateProvider

from trident.funding import ClosingSourceType
from .records import (boolean_value, date_value, decimal_value, integer_value, run_request_from_records,
                      text_value, closing_cost_budget_from_records)


def optional_text(value: object, label: str) -> str | None:
    return None if value is None or value == "" else text_value(value, label)


def optional_decimal(value: object, label: str) -> Decimal | None:
    return None if value is None or value == "" else decimal_value(value, label)


def factor_mapping_from_records(rows: tuple[Mapping[str, object], ...]) -> FactorMapping | None:
    """Build one declared methodology/version; never mix agency/test systems.

    Missing rows mean unavailable factors. Synthetic coefficients stay labelled
    and are not substituted for a production agency WARF mapping.
    """
    if not rows:
        return None
    if any(row.get("version") is None or row.get("version") == "" or isinstance(row.get("version"), bool) for row in rows):
        raise InputValidationError("Factor version is required")
    identities = {(text_value(row.get("system"), "factor system"), text_value(str(row.get("version", "")), "factor version"),
                   boolean_value(row.get("is_synthetic"), "is_synthetic")) for row in rows}
    if len(identities) != 1:
        raise InputValidationError("Factor Mapping must contain one explicit system/version/synthetic classification")
    system, version, synthetic = next(iter(identities))
    factors = {}
    for row in rows:
        bucket = text_value(row.get("bucket"), "factor bucket")
        if bucket in factors:
            raise InputValidationError(f"Duplicate factor bucket: {bucket}")
        factors[bucket] = decimal_value(row.get("factor"), "factor")
    return FactorMapping(system, version, factors, synthetic)


def exposures_from_records(rows: tuple[Mapping[str, object], ...], mapping: FactorMapping | None) -> tuple[AssetExposure, ...]:
    """Keep explicit classifications and coupon scope; missing facts stay None.

    A fixed coupon contributes to WAC, not a fabricated floating spread. Rating
    buckets/factors are declared inputs, not a Bloomberg rating/notching engine.
    """
    assets = []
    for row in rows:
        if mapping is not None and mapping.is_synthetic and row.get("test_factor_system") not in (None, "", mapping.system):
            raise InputValidationError("Asset test-factor system conflicts with the selected mapping")
        attrs = {}
        for field, column in (("is_secured", "secured"), ("is_pik", "pik"), ("is_revolver", "revolver"), ("is_construction", "construction_risk")):
            value = row.get(column)
            attrs[field] = None if value is None or value == "" else boolean_value(value, column)
        seniority = optional_text(row.get("seniority"), "seniority")
        # Explicitly classify known alternatives; unknown descriptions remain
        # missing rather than being claimed junior/senior by a guessed default.
        attrs["is_senior"] = True if seniority == "SENIOR" else False if seniority in {"JUNIOR", "SUBORDINATED"} else None
        assets.append(AssetExposure(
            loan_id=text_value(row.get("loan_id"), "loan_id"),
            obligor=optional_text(row.get("obligor_id"), "obligor_id"),
            asset_class=optional_text(row.get("asset_class"), "asset_class"),
            financing_type=optional_text(row.get("financing_type"), "financing_type"),
            country=optional_text(row.get("country_code"), "country_code"),
            sector=optional_text(row.get("sector"), "sector"),
            currency=text_value(row.get("currency"), "currency"),
            par=decimal_value(row.get("current_par"), "current_par"),
            spread_bps=(optional_decimal(row.get("spread_bps"), "spread_bps") if row.get("coupon_type") == "FLOATING" else None),
            maturity_date=date_value(row.get("maturity_date_unadjusted"), "maturity_date_unadjusted"),
            test_factor_bucket=optional_text(row.get("test_factor_bucket"), "test_factor_bucket"),
            rating_bucket=optional_text(row.get("rating_bucket") or row.get("agency_rating"), "rating_bucket"),
            rating_factor=optional_decimal(row.get("rating_factor"), "rating_factor"),
            rating_system=optional_text(row.get("rating_system"), "rating_system"),
            rating_version=optional_text(row.get("rating_version"), "rating_version"),
            recovery_rate=optional_decimal(row.get("recovery_rate"), "recovery_rate"),
            recovery_rate_source=optional_text(row.get("recovery_rate_source"), "recovery_rate_source"),
            coupon_type=CouponType(row.get("coupon_type")),
            fixed_coupon_rate=(optional_decimal(row.get("fixed_rate"), "fixed_rate")
                               if row.get("coupon_type") == "FIXED" else None),
            **attrs,
        ))
    return tuple(assets)


def limits_from_records(rows: tuple[Mapping[str, object], ...]) -> tuple[LimitSpec, ...]:
    results = []
    for row in rows:
        if not boolean_value(row.get("enabled"), "limit enabled"):
            continue
        phases = optional_text(row.get("phases"), "limit phases")
        results.append(LimitSpec(
            text_value(row.get("limit_id"), "limit_id"), text_value(row.get("metric"), "limit metric"),
            decimal_value(row.get("threshold"), "limit threshold"), LimitDirection(row.get("direction")),
            () if phases is None else tuple(item.strip() for item in phases.split(",")),
        ))
    return tuple(results)


def notes_from_records(rows: tuple[Mapping[str, object], ...], terms: CloTerms) -> tuple[NoteTranche, ...]:
    if sum(row.get("instrument_type") == "EQUITY" for row in rows) != 1:
        raise InputValidationError("CLO_BASELINE requires one combined residual equity class")
    notes = []
    for row in rows:
        if row.get("instrument_type") != "DEBT":
            continue
        # A common note schedule is explicit in this increment. Per-class timing
        # must not be silently ignored when a user changes the capital stack.
        expected = {
            "frequency_months": terms.frequency_months,
            "schedule_anchor_day": ((terms.first_payment_date_unadjusted or terms.legal_final_date).day
                                    if terms.stub_convention in {StubConvention.SHORT_FIRST, StubConvention.LONG_FIRST}
                                    else terms.closing_date.day),
            "fixing_lag_target_business_days": terms.fixing_lag_business_days,
        }
        for field, value in expected.items():
            if integer_value(row.get(field), field) != value:
                raise InputValidationError(f"Note {row.get('class_id')}: {field} differs from common CLO schedule")
        for field, value in (("business_day_convention", terms.business_day_convention.value),
                             ("accrual_date_basis", terms.accrual_date_basis.value)):
            if row.get(field) != value:
                raise InputValidationError(f"Note {row.get('class_id')}: {field} differs from common CLO schedule")
        if CalendarName(row.get("holiday_calendar")) is not (terms.payment_calendar or CalendarName.TARGET):
            raise InputValidationError(f"Note {row.get('class_id')}: holiday_calendar differs from common CLO schedule")
        raw_count = row.get("day_count")
        count = DayCount[raw_count] if raw_count in DayCount.__members__ else DayCount(raw_count)
        floor = optional_decimal(row.get("index_floor_bps"), "note index_floor_bps")
        notes.append(NoteTranche(
            text_value(row.get("class_id"), "class_id"), integer_value(row.get("payment_priority"), "payment_priority"),
            decimal_value(row.get("nominal_amount"), "nominal_amount"), CouponType(row.get("coupon_type")),
            optional_text(row.get("rate_index"), "note rate_index"), decimal_value(row.get("spread_bps"), "note spread_bps"),
            optional_decimal(row.get("fixed_rate"), "note fixed_rate"), None if floor is None else basis_points_rate(floor),
            count, optional_decimal(row.get("oc_minimum"), "oc_minimum"), optional_decimal(row.get("ic_minimum"), "ic_minimum"),
            interest_deferrable=boolean_value(row.get("interest_deferrable", False), "interest_deferrable"),
            pik_rate_fraction=optional_decimal(row.get("pik_rate_fraction"), "pik_rate_fraction") or Decimal(0),
        ))
    return tuple(notes)


def model_request_from_records(
    assets: tuple[Mapping[str, object], ...], capital: tuple[Mapping[str, object], ...],
    provider: RateProvider, *, controls: Mapping[str, object], provenance: str,
    factors: tuple[Mapping[str, object], ...], limits: tuple[Mapping[str, object], ...],
    principal_schedule_records: tuple[Mapping[str, object], ...] = (),
    closing_cost_records: tuple[Mapping[str, object], ...] = (),
    recurring_expense_records: tuple[Mapping[str, object], ...] = (),
) -> TridentModelRequest:
    """Separate input transport into funding, analytical and legal term objects.

    Aggregate and itemized costs are mutually exclusive to prevent duplicate
    cash uses. Cashflow-only mode shares loan/funding code with CLO mode; only
    CLO mode adds note terms and waterfall policy. Contractual enum/date/unit
    validation stays in typed constructors instead of worksheet formulas.
    """
    mode_costs = controls.get("closing_costs_mode", "AGGREGATE")
    if mode_costs not in {"AGGREGATE", "ITEMIZED"}:
        raise InputValidationError("closing_costs_mode must be AGGREGATE or ITEMIZED")
    arrangement_base = decimal_value(controls.get("arrangement_fee_base", 0), "arrangement_fee_base")
    arrangement_rate = decimal_value(controls.get("arrangement_fee_rate", 0), "arrangement_fee_rate")
    if mode_costs == "AGGREGATE" and (closing_cost_records or arrangement_base != 0 or arrangement_rate != 0):
        raise InputValidationError("AGGREGATE closing costs require empty itemized costs and zero arrangement inputs")
    budget = (closing_cost_budget_from_records(closing_cost_records, arrangement_fee_base=arrangement_base,
                                             arrangement_fee_rate=arrangement_rate) if mode_costs == "ITEMIZED" else None)
    source_type = optional_text(controls.get("other_initial_source_type"), "other_initial_source_type")
    cash_request = run_request_from_records(
        assets, capital, provider, upfront_fees=decimal_value(controls["upfront_fees"], "upfront_fees"),
        cash_reserve=decimal_value(controls["cash_reserve"], "cash_reserve"), rate_provenance=provenance,
        principal_schedule_records=principal_schedule_records,
        closing_cost_budget=budget,
        other_initial_uses=decimal_value(controls.get("other_initial_uses", 0), "other_initial_uses"),
        other_initial_sources=decimal_value(controls.get("other_initial_sources", 0), "other_initial_sources"),
        other_initial_source_type=None if source_type is None else ClosingSourceType(source_type),
    )
    mapping = factor_mapping_from_records(factors)
    exposures = exposures_from_records(assets, mapping)
    mode = controls["mode"]
    if mode not in {"CASHFLOW_ONLY", "CLO_BASELINE"}:
        raise InputValidationError(f"Unsupported model mode: {mode}")
    if mode == "CASHFLOW_ONLY":
        return TridentModelRequest(cash_request, exposures, mapping, limits_from_records(limits))
    start = cash_request.positions[0].par_as_of_date if cash_request.positions else None
    expense_mode = controls.get("recurring_expenses_mode", "AGGREGATE")
    if expense_mode not in {"AGGREGATE", "ITEMIZED"}:
        raise InputValidationError("recurring_expenses_mode must be AGGREGATE or ITEMIZED")
    if expense_mode == "AGGREGATE" and recurring_expense_records:
        raise InputValidationError("AGGREGATE recurring expenses require an empty itemized expense table")
    recurring = []
    for row in recurring_expense_records:
        if set(row) != {"expense_id", "annual_amount"}:
            raise InputValidationError("Recurring expenses require exactly expense_id/annual_amount")
        recurring.append(RecurringSeniorExpense(text_value(row.get("expense_id"), "expense_id"),
                                                decimal_value(row.get("annual_amount"), "annual_amount")))
    if expense_mode == "ITEMIZED" and decimal_value(controls["annual_senior_expenses"], "annual_senior_expenses") != 0:
        raise InputValidationError("ITEMIZED recurring expenses require zero aggregate annual_senior_expenses")
    terms = CloTerms(
        closing_date=start, legal_final_date=date_value(controls["legal_final_date"], "legal_final_date"),
        frequency_months=integer_value(controls["clo_frequency_months"], "clo_frequency_months"),
        senior_management_fee_bps=decimal_value(controls["senior_management_fee_bps"], "senior_management_fee_bps"),
        subordinated_management_fee_bps=decimal_value(controls["subordinated_management_fee_bps"], "subordinated_management_fee_bps"),
        annual_senior_expenses=decimal_value(controls["annual_senior_expenses"], "annual_senior_expenses"),
        initial_reserve=cash_request.cash_reserve,
        business_day_convention=BusinessDayConvention(controls["clo_business_day_convention"]),
        accrual_date_basis=AccrualDateBasis(controls["clo_accrual_date_basis"]),
        fixing_lag_business_days=integer_value(controls["clo_fixing_lag_business_days"], "clo_fixing_lag_business_days"),
        end_of_month=boolean_value(controls["clo_end_of_month"], "clo_end_of_month"),
        stub_convention=StubConvention(controls["clo_stub_convention"]),
        collection_cutoff_business_days=integer_value(controls["collection_cutoff_business_days"], "collection_cutoff_business_days"),
        reinvestment_strategy=text_value(controls["reinvestment_strategy"], "reinvestment_strategy"),
        coverage_tests_enabled=boolean_value(controls.get("coverage_tests_enabled", True), "coverage_tests_enabled"),
        interest_diversion_enabled=boolean_value(controls.get("interest_diversion_enabled", True), "interest_diversion_enabled"),
        principal_repayment_mode=PrincipalRepaymentMode(controls.get("principal_repayment_mode", "SEQUENTIAL")),
        interest_diversion_mode=InterestDiversionMode(controls.get("interest_diversion_mode", "ALL_RESIDUAL")),
        management_fee_basis=ManagementFeeBasis(controls.get("management_fee_basis", "TIME_WEIGHTED_PERFORMING_PAR")),
        management_fee_day_count=DayCount(controls.get("management_fee_day_count", "ACT/360")),
        recurring_senior_expenses=tuple(recurring),
        variable_senior_expenses_bps=decimal_value(controls.get("variable_senior_expenses_bps", 0), "variable_senior_expenses_bps"),
        senior_expenses_day_count=DayCount(controls.get("senior_expenses_day_count", "ACT/365F")),
        annual_senior_expense_cap=optional_decimal(controls.get("annual_senior_expense_cap"), "annual_senior_expense_cap"),
        senior_expense_cap_bps=decimal_value(controls.get("senior_expense_cap_bps", 0), "senior_expense_cap_bps"),
        include_principal_cash_in_oc=boolean_value(controls.get("include_principal_cash_in_oc", True), "include_principal_cash_in_oc"),
        first_payment_date_unadjusted=None if controls.get("first_payment_date_unadjusted") in (None, "") else date_value(controls["first_payment_date_unadjusted"], "first_payment_date_unadjusted"),
        last_regular_date_unadjusted=None if controls.get("last_regular_date_unadjusted") in (None, "") else date_value(controls["last_regular_date_unadjusted"], "last_regular_date_unadjusted"),
        first_stub_rate_override=optional_decimal(controls.get("first_stub_rate_override"), "first_stub_rate_override"),
        cash_account_accrual_mode=CashAccountAccrualMode(controls.get("cash_account_accrual_mode", "NONE")),
        cash_account_fixed_rate=optional_decimal(controls.get("cash_account_fixed_rate"), "cash_account_fixed_rate"),
        cash_account_rate_index=optional_text(controls.get("cash_account_rate_index"), "cash_account_rate_index"),
        cash_account_spread_bps=decimal_value(controls.get("cash_account_spread_bps", 0), "cash_account_spread_bps"),
        cash_account_rate_floor=optional_decimal(controls.get("cash_account_rate_floor", 0), "cash_account_rate_floor"),
        cash_account_day_count=DayCount(controls.get("cash_account_day_count", "ACT/360")),
        cash_account_fixing_lag_business_days=integer_value(controls.get("cash_account_fixing_lag_business_days", 0), "cash_account_fixing_lag_business_days"),
    )
    return TridentModelRequest(cash_request, exposures, mapping, limits_from_records(limits), terms,
                            notes_from_records(capital, terms), date_value(controls["reinvestment_end_date"], "reinvestment_end_date"))


def flat_record(value: object) -> dict[str, object]:
    """Output transport keeps enums readable and unavailable numbers blank."""
    return {key: item.value if isinstance(item, Enum) else item for key, item in asdict(value).items()}
