"""Independent expected answers for source-bearing numerical reconciliation.

Literal EUR100/EUR100.01 and ratio boundaries verify inclusive absolute
tolerances. The benchmark records below are test references, never generated
from the comparison service or represented as actual trustee sign-off.
"""

from dataclasses import FrozenInstanceError, replace
from datetime import date, datetime, timedelta
from decimal import Decimal, Inexact, localcontext
from fractions import Fraction
import unittest

from trident.domain.models import InputValidationError
from trident.validation import (
    BenchmarkRecord, ObservedMetric, ReconciliationKey, ReconciliationReport,
    ReconciliationResult, ReconciliationService, ReconciliationStatus,
    index_observations,
)


D = Decimal
DAY = date(2026, 6, 22)


def key(metric="PRINCIPAL_PAID", *, identity="A", entity_type="TRANCHE", stage="PERIOD_END", day=DAY):
    return ReconciliationKey(day, entity_type, identity, metric, stage)


def benchmark(identity=None, *, expected="100", tolerance="0", unit="EUR"):
    return BenchmarkRecord(identity or key(), D(expected), D(tolerance), unit,
                           "INDEPENDENT_HAND_CASE", "REFERENCE_A_PRINCIPAL")


class ReconciliationTests(unittest.TestCase):
    def setUp(self):
        self.service = ReconciliationService()

    def test_exact_zero_tolerance_and_zero_observations_match(self):
        reference = benchmark(expected="0")
        report = self.service.compare((reference,), {reference.key: ObservedMetric(D(0), "EUR")})
        self.assertTrue(report.matched)
        self.assertTrue(report.complete)
        self.assertIs(report.status, ReconciliationStatus.MATCH)
        self.assertEqual((report.matched_count, report.mismatched_count, report.unavailable_count), (1, 0, 0))
        self.assertEqual(report.results[0].difference, D(0))

    def test_absolute_tolerance_is_inclusive_in_both_directions(self):
        reference = benchmark(tolerance="0.01")
        for actual, signed in (("100.01", "0.01"), ("99.99", "-0.01")):
            with self.subTest(actual=actual):
                row = self.service.compare((reference,), {reference.key: ObservedMetric(D(actual), "EUR")}).results[0]
                self.assertIs(row.status, ReconciliationStatus.MATCH)
                self.assertEqual(row.difference, D(signed))
                self.assertEqual(row.absolute_difference, D("0.01"))

    def test_tolerance_does_not_quantize_inputs_to_cents(self):
        reference = benchmark(tolerance="0.01")
        report = self.service.compare((reference,), {reference.key: ObservedMetric(D("100.0100001"), "EUR")})
        self.assertIs(report.status, ReconciliationStatus.MISMATCH)
        self.assertEqual(report.results[0].difference, D("0.0100001"))
        self.assertFalse(report.matched)
        self.assertTrue(report.complete)

    def test_ratio_or_bps_units_are_not_currency_posted(self):
        reference = benchmark(key("OC_RATIO", entity_type="COVERAGE", stage="GATE"),
                              expected="1.2500000", tolerance="0.0000001", unit="ratio")
        row = self.service.compare((reference,), {reference.key: ObservedMetric(D("1.2500001"), "ratio")}).results[0]
        self.assertIs(row.status, ReconciliationStatus.MATCH)
        self.assertEqual(row.absolute_difference, D("0.0000001"))

    def test_negative_cash_and_large_magnitudes_keep_signed_difference(self):
        reference = benchmark(expected="-100", tolerance="0.01")
        row = self.service.compare((reference,), {reference.key: ObservedMetric(D("-99.99"), "EUR")}).results[0]
        self.assertEqual(row.difference, D("0.01"))
        huge = benchmark(expected="100000000000000000000000000000000000000000000000000000000000000000000000000000000", tolerance="0.01")
        value = D("100000000000000000000000000000000000000000000000000000000000000000000000000000000.01")
        with localcontext() as context:
            context.prec = 2
            context.traps[Inexact] = True
            exact = self.service.compare((huge,), {huge.key: ObservedMetric(value, "EUR")})
        self.assertTrue(exact.matched)
        self.assertEqual(exact.results[0].difference, D("0.01"))

    def test_small_coefficient_tail_is_exact_under_hostile_context(self):
        reference = benchmark(expected="1.00000000000000000000000000000000000000001", tolerance="0")
        with localcontext() as context:
            context.prec = 2
            context.traps[Inexact] = True
            report = self.service.compare((reference,), {reference.key: ObservedMetric(D(1), "EUR")})
        self.assertIs(report.status, ReconciliationStatus.MISMATCH)
        self.assertEqual(Fraction(report.results[0].difference), -Fraction(1, 10**41))

    def test_missing_key_is_unavailable_without_discarding_reference(self):
        reference = benchmark()
        report = self.service.compare((reference,), {})
        row = report.results[0]
        self.assertIs(report.status, ReconciliationStatus.UNAVAILABLE)
        self.assertFalse(report.complete)
        self.assertFalse(report.matched)
        self.assertIs(row.benchmark, reference)
        self.assertIsNone(row.observation)
        self.assertIsNone(row.difference)
        self.assertEqual((row.benchmark.source, row.benchmark.reference_id),
                         ("INDEPENDENT_HAND_CASE", "REFERENCE_A_PRINCIPAL"))

    def test_explicit_model_unavailability_retains_reason(self):
        reference = benchmark(key("OC_RATIO", entity_type="COVERAGE", stage="GATE"), unit="ratio")
        observed = ObservedMetric(None, "ratio", "Outstanding tested debt is zero")
        row = self.service.compare((reference,), {reference.key: observed}).results[0]
        self.assertIs(row.status, ReconciliationStatus.UNAVAILABLE)
        self.assertEqual(row.message, "Outstanding tested debt is zero")
        self.assertIsNone(row.absolute_difference)

    def test_blank_unavailability_reason_gets_explicit_message(self):
        reference = benchmark()
        row = self.service.compare((reference,), {reference.key: ObservedMetric(None, "EUR")}).results[0]
        self.assertTrue(row.message)
        self.assertIs(row.status, ReconciliationStatus.UNAVAILABLE)

    def test_unit_mismatch_is_unavailable_and_never_converted(self):
        reference = benchmark(expected="5", unit="percent")
        row = self.service.compare((reference,), {reference.key: ObservedMetric(D("0.05"), "fraction")}).results[0]
        self.assertIs(row.status, ReconciliationStatus.UNAVAILABLE)
        self.assertIsNone(row.difference)
        self.assertIn("no conversion", row.message)

    def test_date_entity_metric_stage_are_exact_keys(self):
        reference = benchmark()
        for mismatch in (replace(reference.key, observation_date=DAY + timedelta(days=1)),
                         replace(reference.key, entity_type="ASSET"),
                         replace(reference.key, entity_id="B"),
                         replace(reference.key, metric="principal_paid"),
                         replace(reference.key, stage="GATE")):
            with self.subTest(mismatch=mismatch):
                row = self.service.compare((reference,), {mismatch: ObservedMetric(D(100), "EUR")}).results[0]
                self.assertIs(row.status, ReconciliationStatus.UNAVAILABLE)

    def test_closing_asset_tranche_and_coverage_stages_coexist(self):
        keys = (key("EQUITY_FUNDING", identity="D", entity_type="DEAL", stage="BASELINE"),
                key("CASH_INTEREST", identity="L", entity_type="ASSET"),
                key("COUPON_PAID"),
                key("OC_RATIO", entity_type="COVERAGE", stage="GATE"),
                key("OC_RATIO", entity_type="COVERAGE", stage="POST_DIVERSION"),
                key("OC_RATIO", entity_type="COVERAGE", stage="PERIOD_END"))
        references = tuple(benchmark(identity, expected=str(index), unit="ratio" if index >= 3 else "EUR")
                           for index, identity in enumerate(keys))
        observed = index_observations((reference.key, ObservedMetric(reference.expected, reference.unit))
                                      for reference in references)
        report = self.service.compare(references, observed)
        self.assertEqual(tuple(row.key for row in report.results), keys)
        self.assertTrue(report.matched)

    def test_known_mismatch_survives_in_incomplete_report(self):
        references = (benchmark(), benchmark(key(identity="B")), benchmark(key(identity="C")))
        observed = {references[0].key: ObservedMetric(D(101), "EUR"),
                    references[1].key: ObservedMetric(D(100), "EUR")}
        report = self.service.compare(references, observed)
        self.assertIs(report.status, ReconciliationStatus.UNAVAILABLE)
        self.assertEqual((report.matched_count, report.mismatched_count, report.unavailable_count), (1, 1, 1))

    def test_unreferenced_observation_does_not_expand_validation_scope(self):
        reference = benchmark()
        observed = {reference.key: ObservedMetric(D(100), "EUR"), key(identity="UNREFERENCED"): ObservedMetric(D(-99), "EUR")}
        report = self.service.compare((reference,), observed)
        self.assertEqual(len(report.results), 1)
        self.assertTrue(report.matched)

    def test_no_records_duplicate_or_mutable_benchmarks_fail_closed(self):
        reference = benchmark()
        for invalid in ((), [], [reference], (reference, reference), (object(),), None):
            with self.subTest(invalid=invalid), self.assertRaises(InputValidationError):
                self.service.compare(invalid, {})

    def test_observation_index_rejects_duplicates_and_freezes_generator(self):
        reference = benchmark()
        pair = (reference.key, ObservedMetric(D(100), "EUR"))
        consumed = []
        def pairs():
            consumed.append(1)
            yield pair
        indexed = index_observations(pairs())
        self.assertEqual(consumed, [1])
        self.assertEqual(indexed[reference.key], pair[1])
        with self.assertRaises(TypeError):
            indexed[reference.key] = ObservedMetric(D(101), "EUR")
        with self.assertRaises(InputValidationError):
            index_observations((pair, pair))

    def test_invalid_mapping_or_pair_does_not_silently_ignore_bad_records(self):
        reference = benchmark()
        for invalid in ((), None, {reference.key: None}, {"wrong": ObservedMetric(D(100), "EUR")}):
            with self.subTest(invalid=invalid), self.assertRaises(InputValidationError):
                self.service.compare((reference,), invalid)
        for invalid in (None, ((reference.key,),), ((reference.key, 1),), ([reference.key, ObservedMetric(D(100), "EUR")],)):
            with self.subTest(invalid=invalid), self.assertRaises(InputValidationError):
                index_observations(invalid)

    def test_benchmark_requires_finite_decimal_tolerance_and_provenance(self):
        reference = benchmark()
        for changes in ({"expected": 100}, {"expected": 100.0}, {"expected": True},
                        {"expected": D("NaN")}, {"expected": D("Infinity")},
                        {"tolerance": D(-1)}, {"tolerance": 0}, {"tolerance": D("sNaN")},
                        {"unit": ""}, {"unit": " EUR"}, {"source": ""},
                        {"reference_id": ""}, {"key": "wrong"}):
            with self.subTest(changes=changes), self.assertRaises(InputValidationError):
                replace(reference, **changes)

    def test_keys_require_exact_dates_and_nonblank_labels(self):
        reference = key()
        for changes in ({"observation_date": datetime(2026, 6, 22)}, {"observation_date": "2026-06-22"},
                        {"observation_date": None}, {"metric": ""}, {"stage": " GATE"},
                        {"entity_id": ""}, {"entity_type": ""}):
            with self.subTest(changes=changes), self.assertRaises(InputValidationError):
                replace(reference, **changes)

    def test_observed_value_is_not_coerced_or_contradictory(self):
        for value in (100, 100.0, True, D("NaN"), D("-Infinity")):
            with self.subTest(value=value), self.assertRaises(InputValidationError):
                ObservedMetric(value, "EUR")
        for args in ((D(100), "", ""), (None, "EUR", None),
                     (None, "EUR", " missing "), (D(100), "EUR", "Unavailable")):
            with self.subTest(args=args), self.assertRaises(InputValidationError):
                ObservedMetric(*args)

    def test_report_and_inputs_are_immutable(self):
        reference = benchmark()
        row = self.service.compare((reference,), {reference.key: ObservedMetric(D(100), "EUR")}).results[0]
        for obj, field, value in ((reference, "expected", D(999)), (reference.key, "metric", "BAD"),
                                  (row.observation, "value", D(999)), (row, "difference", D(999))):
            with self.subTest(obj=obj), self.assertRaises(FrozenInstanceError):
                setattr(obj, field, value)

    def test_manually_forged_result_cannot_claim_a_match(self):
        reference = benchmark()
        observed = ObservedMetric(D(101), "EUR")
        for status, difference, absolute in ((ReconciliationStatus.MATCH, D(1), D(1)),
                (ReconciliationStatus.MISMATCH, D(0), D(0)),
                (ReconciliationStatus.UNAVAILABLE, None, None), ("MATCH", D(1), D(1))):
            with self.subTest(status=status), self.assertRaises(InputValidationError):
                ReconciliationResult(reference, observed, status, difference, absolute, "Claim")
        with self.assertRaises(InputValidationError):
            ReconciliationResult(reference, None, ReconciliationStatus.MATCH, D(0), D(0), "Claim")

    def test_empty_duplicate_or_invalid_report_is_never_match(self):
        reference = benchmark()
        row = self.service.compare((reference,), {}).results[0]
        for invalid in ((), [], (row, row), (object(),)):
            with self.subTest(invalid=invalid), self.assertRaises(InputValidationError):
                ReconciliationReport(invalid)


if __name__ == "__main__":
    unittest.main()
