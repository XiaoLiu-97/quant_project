"""Source-consistent CLO economics, independent of spreadsheet presentation.

Cash yields use the waterfall's actual stressed receipts and matching dated
performing-face exposure. Contractual coupon diagnostics use the unstressed
native contract and its own coupon DCF. Keeping those two bases explicit avoids
the legacy error of dividing pre-stress interest by post-stress outstanding par.
No metric here changes waterfall cash, assumes a terminal value or substitutes
equity nominal for an investor's actual cash contribution.
"""

from dataclasses import dataclass
from decimal import Decimal
from enum import Enum
from fractions import Fraction

from trident.analysis.returns import DatedCashflow, moic, xirr
from trident.domain.models import CouponType, InputValidationError, require_decimal
from trident.domain.numeric import decimal_fraction
from trident.funding.engine import SourcesUses

from .models import CloProjection, CloRunRequest
from .reporting import report_tranche_periods


class EconomicsStatus(str, Enum):
    """An absent denominator or source is unavailable, never a fabricated zero."""

    AVAILABLE = "AVAILABLE"
    UNAVAILABLE = "UNAVAILABLE"
    AMBIGUOUS = "AMBIGUOUS"
    NUMERIC_FAILURE = "NUMERIC_FAILURE"


@dataclass(frozen=True)
class CloEconomicsMetric:
    """One labelled metric with its units and independently inspectable basis.

    Rate values are annual decimal fractions. Money is EUR; ratios are decimal
    multiples and spreads are bps. ``numerator`` and ``denominator`` refer to the
    formula in ``basis``; XIRR has a dated stream rather than a simple quotient.
    Availability covers data/formula sufficiency, not a legal compliance opinion.
    """

    metric_id: str
    value: Decimal | None
    unit: str
    numerator: Decimal | None
    denominator: Decimal | None
    basis: str
    status: EconomicsStatus
    message: str = ""

    def __post_init__(self) -> None:
        for label in ("metric_id", "unit", "basis"):
            value = getattr(self, label)
            if not isinstance(value, str) or not value or value != value.strip():
                raise InputValidationError(f"Economics {label} must be nonblank, unpadded text")
        if not isinstance(self.status, EconomicsStatus):
            raise InputValidationError("Economics status must be EconomicsStatus")
        for label in ("value", "numerator", "denominator"):
            if getattr(self, label) is not None:
                require_decimal(getattr(self, label), f"Economics {label}")
        if (self.status is EconomicsStatus.AVAILABLE) != (self.value is not None):
            raise InputValidationError("Economics availability conflicts with its value")


def _sum(values) -> Decimal:
    """Aggregate posted amounts or high precision exposures without context loss."""
    return decimal_fraction(sum((Fraction(value) for value in values), Fraction()))


def _ratio(metric_id: str, numerator: Decimal, denominator: Decimal,
           unit: str, basis: str) -> CloEconomicsMetric:
    if denominator <= 0:
        return CloEconomicsMetric(metric_id, None, unit, numerator, denominator, basis,
                                  EconomicsStatus.UNAVAILABLE, "A positive matching denominator is required")
    return CloEconomicsMetric(metric_id, decimal_fraction(Fraction(numerator) / Fraction(denominator)),
                              unit, numerator, denominator, basis, EconomicsStatus.AVAILABLE)


def _amount(metric_id: str, value: Decimal, basis: str) -> CloEconomicsMetric:
    return CloEconomicsMetric(metric_id, value, "EUR", value, None, basis, EconomicsStatus.AVAILABLE)


def _missing(metric_id: str, unit: str, basis: str, message: str) -> CloEconomicsMetric:
    return CloEconomicsMetric(metric_id, None, unit, None, None, basis, EconomicsStatus.UNAVAILABLE, message)


def _contractual_metrics(request: CloRunRequest, projection: CloProjection) -> tuple[CloEconomicsMetric, ...]:
    """Use matching native contract exposure and coupon before credit stress.

    Opening acquired accrual belongs to earlier ownership time; remove its exact
    claim from forward contractual earnings. Floating reference is the effective
    reference component after bounds/compounding; spread is the residual. Fixed
    coupon is presented separately so fixed assets do not invent an index rate.
    Imported files without native rate segments cannot establish this split.
    """
    ids = ("ORIGINAL_CONTRACTUAL_COUPON_YIELD", "ORIGINAL_CONTRACTUAL_REFERENCE_YIELD",
           "ORIGINAL_CONTRACTUAL_SPREAD_YIELD", "ORIGINAL_CONTRACTUAL_FIXED_COUPON_YIELD")
    basis = "Unstressed native forward coupon / native opening-face coupon-DCF exposure; emitted payment horizon"
    if request.imported_collateral is not None:
        return tuple(_missing(identifier, "ANNUAL_RATE", basis,
                              "Imported cash does not prove native contractual rate segments") for identifier in ids)
    horizon = projection.periods[-1].payment_date
    rows = tuple(row for row in request.asset_cashflows if row.payment_date <= horizon)
    if not rows:
        return tuple(_missing(identifier, "ANNUAL_RATE", basis,
                              "No native coupon falls within the emitted cash horizon") for identifier in ids)
    exposure = sum((Fraction(row.opening_balance) * Fraction(row.day_count_fraction) for row in rows), Fraction())
    gross = sum((Fraction(row.interest_unrounded) - row.opening_accrued_exact for row in rows), Fraction())
    reference = spread = fixed = Fraction()
    for row in rows:
        earned = Fraction(row.interest_unrounded) - row.opening_accrued_exact
        if row.index_rate is None:
            fixed += earned
            continue
        # Annualized margin display is DCF-normalized by the native engine,
        # including reset/step segments. Exact reference is the gross forward
        # factor minus margin: floors/caps/overnight effects stay in reference.
        margin = Fraction(row.opening_balance) * Fraction(row.spread_bps) / 10_000 * Fraction(row.day_count_fraction)
        spread += margin
        reference += earned - margin
    denominator = decimal_fraction(exposure)
    return tuple(_ratio(identifier, decimal_fraction(amount), denominator, "ANNUAL_RATE", basis)
                 for identifier, amount in zip(ids, (gross, reference, spread, fixed), strict=True))


def report_clo_economics(request: CloRunRequest, projection: CloProjection,
                         funding: SourcesUses | None = None) -> tuple[CloEconomicsMetric, ...]:
    """Produce closing funding, coupon economics and full investor diagnostics.

    O(number of emitted class periods + native coupons); no alternative CLO runs
    or IRR optimization is launched. Existing CLO forward runs should omit
    ``funding`` unless it is a separately verified current investor entry cost;
    historical closing Sources & Uses cannot establish a forward entry price.
    Unresolved projections keep collected cash totals, but suppress terminal
    equity MOIC/XIRR. Additional refinancing contributions remain investor cash
    outflows on their real dates, including same-day gross amounts for MOIC.
    """
    if not isinstance(request, CloRunRequest) or not isinstance(projection, CloProjection) or not projection.periods:
        raise InputValidationError("CLO economics requires a request and nonempty typed projection")
    if funding is not None and not isinstance(funding, SourcesUses):
        raise InputValidationError("CLO economics funding must be SourcesUses or None")
    reports = report_tranche_periods(projection)
    periods = projection.periods
    expected = {row.class_id for row in request.tranches}
    if {row.class_id for row in reports} != expected:
        raise InputValidationError("CLO economics projection classes differ from the request")
    if periods[0].opening_debt_par != _sum(row.opening_balance for row in request.tranches):
        raise InputValidationError("CLO economics projection opening debt differs from the request")
    if periods[0].opening_collateral_par != request.opening_collateral_par:
        raise InputValidationError("CLO economics projection opening collateral differs from the request")
    metrics = []
    debt = _sum(row.opening_balance for row in request.tranches)
    metrics.append(_ratio("DEBT_TO_COLLATERAL_PAR", debt, request.opening_collateral_par, "MULTIPLE",
                          "Opening note face / opening performing collateral face"))
    floating = tuple(row for row in request.tranches if row.coupon_type is CouponType.FLOATING)
    fixed = tuple(row for row in request.tranches if row.coupon_type is CouponType.FIXED)
    metrics.append(_ratio("WEIGHTED_FLOATING_DEBT_SPREAD_BPS",
        decimal_fraction(sum((Fraction(row.opening_balance) * Fraction(row.spread_bps) for row in floating), Fraction())),
        _sum(row.opening_balance for row in floating), "BPS", "Opening floating-note face weighted contractual margins; fixed classes excluded"))
    metrics.append(_ratio("WEIGHTED_FIXED_DEBT_COUPON",
        decimal_fraction(sum((Fraction(row.opening_balance) * Fraction(row.fixed_rate) for row in fixed), Fraction())),
        _sum(row.opening_balance for row in fixed), "ANNUAL_RATE", "Opening fixed-note face weighted coupon; floating classes excluded"))
    original_exposure = _sum(row.original_performing_par_years for row in periods)
    reinvestment_exposure = _sum(row.reinvestment_performing_par_years for row in periods)
    debt_exposure = _sum(row.debt_face_par_years for row in periods)
    for metric_id, numerator, denominator, basis in (
        ("ORIGINAL_REALIZED_CASH_YIELD", _sum(row.original_asset_cash_interest for row in periods), original_exposure,
         "Actual original borrower coupon received / same-source stressed performing face-days/365; includes verified opening coupon receipts"),
        ("REINVESTMENT_REALIZED_CASH_YIELD", _sum(row.reinvestment_asset_cash_interest for row in periods), reinvestment_exposure,
         "Actual settled synthetic-cohort coupon received / same-source stressed performing face-days/365"),
        ("REINVESTMENT_REFERENCE_CASH_YIELD", _sum(row.reinvestment_reference_interest for row in periods), reinvestment_exposure,
         "Floored synthetic reference coupon on surviving face / matching stressed cohort face-days/365"),
        ("REINVESTMENT_SPREAD_CASH_YIELD", _sum(row.reinvestment_spread_interest for row in periods), reinvestment_exposure,
         "Synthetic received coupon minus reference allocation / matching stressed cohort face-days/365"),
        ("CASH_DEBT_COST", _sum(row.total_coupon_paid for row in reports), debt_exposure,
         "All note coupon cash paid from either account / opening note face-days/365; includes paid historical arrears"),
        ("ACCRUED_DEBT_COST", _sum(value for row in reports for value in
                                  (row.total_current_coupon_accrued, row.coupon_shortfall_interest)), debt_exposure,
         "Current cash plus mandatory PIK coupon and interest-on-arrears / opening note face-days/365; unpaid claim principal not reaccrued"),
    ):
        metrics.append(_ratio(metric_id, numerator, denominator, "ANNUAL_RATE", basis))
    metrics.extend(_contractual_metrics(request, projection))
    recurring_fees = _sum(value for row in periods for value in (row.senior_expenses_paid,
        row.deferred_senior_expenses_paid, row.senior_management_fee_paid, row.subordinated_management_fee_paid))
    life_fees = _sum((recurring_fees, projection.total_incentive_fee_paid,
                     _sum(row.optional_call_costs for row in periods), projection.total_refinancing_fees))
    amounts = (
        ("TOTAL_RECURRING_FEES_PAID", recurring_fees, "Expenses plus senior/subordinated manager fees from interest, principal and authorized reserve"),
        ("TOTAL_INCENTIVE_FEES_PAID", projection.total_incentive_fee_paid, "Posted investor hurdle-account fee; not an IRR-trigger approximation"),
        ("TOTAL_LIFECYCLE_FEES_PAID", life_fees, "Recurring fees plus incentive, optional-call and refinancing fees; excludes closing costs"),
        ("TOTAL_DEFAULTED_EXPOSURE", projection.total_defaulted_exposure, "Cumulative newly defaulted face; not loss or cash repayment"),
        ("TOTAL_RECOVERY_COLLECTIONS", projection.total_recovery_collections, "Actual received workout principal cash"),
        ("TOTAL_RECOGNIZED_PAR_LOSS", projection.total_recognized_par_loss, "Resolved default claim writeoffs"),
        ("DEBT_REDEMPTION_FROM_INTEREST", _sum(row.debt_principal_from_interest for row in periods), "Actual face redemption funded by interest; includes final mandatory debt catch-up"),
        ("INTEREST_DIVERSION_TO_PRINCIPAL", _sum(row.interest_diversion_test_transferred for row in periods), "Independent IDT account transfers; not additional cash or necessarily completed purchases"),
        ("TOTAL_NOTE_PIK_CAPITALIZED", _sum(row.note_pik_capitalized for row in periods), "Mandatory current coupon settled in additional actual face, excluding optional deferred claims"),
        ("TOTAL_EQUITY_DISTRIBUTIONS", projection.total_equity_distributions, "Actual net investor distributions after incentive fees from all accounts"),
        ("TOTAL_REINVESTMENT_CASH_USED", _sum(row.cash_used for row in projection.reinvestment_purchases), "Actual synthetic consideration consumed; distinct from acquired face"),
        ("TOTAL_REINVESTMENT_PAR_ACQUIRED", _sum(row.acquired_par for row in projection.reinvestment_purchases), "Actual synthetic face acquired; distinct from cash consideration"),
    )
    metrics.extend(_amount(*record) for record in amounts)
    closing_only = ("DEBT_TO_EQUITY_CASH", "COLLATERAL_TO_EQUITY_CASH", "EQUITY_CASH_FUNDING",
                    "TOTAL_FEES_PAID", "EQUITY_MOIC", "EQUITY_XIRR")
    if funding is None or request.opening_state is not None:
        reason = "A verified closing investor funding ledger is required; forward existing-CLO entry price is not inferred"
        metrics.extend(_missing(identifier, "EUR" if identifier in {"EQUITY_CASH_FUNDING", "TOTAL_FEES_PAID"}
                               else "ANNUAL_RATE" if identifier == "EQUITY_XIRR" else "MULTIPLE",
                               "Actual closing investor funding and emitted dated investor cash", reason) for identifier in closing_only)
        return tuple(metrics)
    if funding.debt_par != debt or funding.collateral_par != request.opening_collateral_par:
        raise InputValidationError("CLO economics funding face differs from the projected opening")
    metrics.extend((
        _ratio("DEBT_TO_EQUITY_CASH", debt, funding.equity_cash_funding, "MULTIPLE", "Opening issued note face / actual closing investor cash funding"),
        _ratio("COLLATERAL_TO_EQUITY_CASH", funding.collateral_par, funding.equity_cash_funding, "MULTIPLE", "Opening collateral face / actual closing investor cash funding"),
        _amount("EQUITY_CASH_FUNDING", funding.equity_cash_funding, "Sources & Uses actual investor contribution, including clean prices and closing costs"),
        _amount("TOTAL_FEES_PAID", _sum((life_fees, funding.upfront_fees)), "All cash lifecycle fees plus cash closing costs; every source account included"),
    ))
    investor = (DatedCashflow(request.terms.closing_date, funding.equity_cash_funding.copy_negate()),
        *(DatedCashflow(row.payment_date, row.amount.copy_negate()) for row in projection.equity_contributions),
        *(DatedCashflow(row.payment_date, row.amount) for row in projection.equity_cashflows))
    for identifier, unit, result in (("EQUITY_MOIC", "MULTIPLE", moic(investor)), ("EQUITY_XIRR", "ANNUAL_RATE", xirr(investor))):
        if not projection.terminal_value_available:
            metrics.append(_missing(identifier, unit, "Actual closing cash plus additional contributions and net dated distributions",
                                    "Terminal claims remain unresolved; collected cash does not establish a terminal investor return"))
        else:
            metrics.append(CloEconomicsMetric(identifier, result.value, unit, None, None,
                "Actual closing cash plus additional contributions and net dated distributions; XIRR actual/365, MOIC gross cash",
                EconomicsStatus(result.status.value), result.message))
    return tuple(metrics)
