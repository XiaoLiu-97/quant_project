"""Independent examples and boundary tests for explicit term-rate inputs."""

from dataclasses import FrozenInstanceError
from datetime import date, datetime
from decimal import Decimal, localcontext
import unittest

from trident.market.rates import (
    CurveRangeError,
    CurveRateProvider,
    ExtrapolationPolicy,
    FlatRateProvider,
    MissingCurveError,
    ProjectedRateCurve,
    RatePoint,
    RequiredFixingError,
)


INDEX = "EURIBOR_3M"


class RatePointTests(unittest.TestCase):
    def test_valid_negative_rate_and_immutability(self) -> None:
        point = RatePoint(date(2026, 1, 1), Decimal("-0.005"))
        self.assertEqual(point.rate, Decimal("-0.005"))
        with self.assertRaises(FrozenInstanceError):
            point.rate = Decimal("0.01")

    def test_reject_non_decimal_and_nonfinite_rate(self) -> None:
        for invalid in [0.025, 1, True, "0.025", Decimal("NaN"), Decimal("sNaN"), Decimal("Infinity"), Decimal("-Infinity")]:
            with self.subTest(rate=invalid), self.assertRaises(ValueError):
                RatePoint(date(2026, 1, 1), invalid)

    def test_reject_datetime_and_invalid_date_types(self) -> None:
        for invalid in [datetime(2026, 1, 1), "2026-01-01", True, None]:
            with self.subTest(fixing_date=invalid), self.assertRaises(ValueError):
                RatePoint(invalid, Decimal("0.025"))


class FlatRateProviderTests(unittest.TestCase):
    def test_flat_rates_are_explicitly_synthetic(self) -> None:
        provider = FlatRateProvider({INDEX: Decimal("0.025")})
        self.assertTrue(provider.is_synthetic)
        self.assertEqual(provider.provenance, "SYNTHETIC_ASSUMPTION")
        self.assertEqual(provider.rate(INDEX, date(2026, 1, 1)), Decimal("0.025"))
        self.assertEqual(provider.rate(INDEX, date(2050, 1, 1)), Decimal("0.025"))

    def test_custom_source_label_does_not_make_flat_inputs_observed(self) -> None:
        provider = FlatRateProvider({INDEX: Decimal("-0.005")}, "USER_STRESS_SCENARIO")
        self.assertTrue(provider.is_synthetic)
        self.assertEqual(provider.rate(INDEX, date(2026, 1, 1)), Decimal("-0.005"))

    def test_mapping_is_copied_and_read_only(self) -> None:
        inputs = {INDEX: Decimal("0.025")}
        provider = FlatRateProvider(inputs)
        inputs[INDEX] = Decimal("0.9")
        inputs["OTHER"] = Decimal("0.1")
        self.assertEqual(provider.rate(INDEX, date(2026, 1, 1)), Decimal("0.025"))
        with self.assertRaises(MissingCurveError):
            provider.rate("OTHER", date(2026, 1, 1))
        with self.assertRaises(TypeError):
            provider.rates[INDEX] = Decimal("0.9")
        with self.assertRaises(FrozenInstanceError):
            provider.provenance = "CHANGED"

    def test_missing_index_is_explicit(self) -> None:
        with self.assertRaises(MissingCurveError):
            FlatRateProvider({INDEX: Decimal("0.025")}).rate("EURIBOR_6M", date(2026, 1, 1))

    def test_validate_mapping_values_and_identifiers(self) -> None:
        for inputs in [{INDEX: 0.025}, {INDEX: True}, {INDEX: Decimal("NaN")}, {"": Decimal("0")}, {" EURIBOR_3M": Decimal("0")}, {True: Decimal("0")}, None]:
            with self.subTest(inputs=inputs), self.assertRaises(ValueError):
                FlatRateProvider(inputs)

    def test_query_requires_exact_date_type_and_identifier(self) -> None:
        provider = FlatRateProvider({INDEX: Decimal("0.025")})
        for invalid in [datetime(2026, 1, 1), "2026-01-01", None]:
            with self.subTest(fixing_date=invalid), self.assertRaises(ValueError):
                provider.rate(INDEX, invalid)
        for invalid in ["", "   ", "EURIBOR_3M ", False]:
            with self.subTest(index=invalid), self.assertRaises(ValueError):
                provider.rate(invalid, date(2026, 1, 1))

    def test_provenance_is_required(self) -> None:
        for invalid in ["", "   ", True, None]:
            with self.subTest(provenance=invalid), self.assertRaises(ValueError):
                FlatRateProvider({INDEX: Decimal("0.025")}, invalid)


class ProjectedRateCurveTests(unittest.TestCase):
    def setUp(self) -> None:
        self.points = (
            RatePoint(date(2026, 1, 1), Decimal("0.03")),
            RatePoint(date(2026, 1, 11), Decimal("0.05")),
        )

    def test_actual_calendar_days_interpolate_across_weekend(self) -> None:
        curve = ProjectedRateCurve(INDEX, self.points)
        # Jan 3 is Saturday, but still 2/10 of the calendar-day interval.
        self.assertEqual(curve.rate(INDEX, date(2026, 1, 3)), Decimal("0.034"))
        self.assertEqual(curve.rate(INDEX, date(2026, 1, 6)), Decimal("0.04"))

    def test_leap_day_counts_as_actual_calendar_day(self) -> None:
        curve = ProjectedRateCurve(INDEX, (
            RatePoint(date(2028, 2, 28), Decimal("0.01")),
            RatePoint(date(2028, 3, 1), Decimal("0.03")),
        ))
        self.assertEqual(curve.rate(INDEX, date(2028, 2, 29)), Decimal("0.02"))

    def test_negative_rates_are_not_floored(self) -> None:
        curve = ProjectedRateCurve(INDEX, (
            RatePoint(date(2026, 1, 1), Decimal("-0.02")),
            RatePoint(date(2026, 1, 11), Decimal("0.02")),
        ))
        self.assertEqual(curve.rate(INDEX, date(2026, 1, 3)), Decimal("-0.012"))
        self.assertEqual(curve.rate(INDEX, date(2026, 1, 6)), Decimal("0"))

    def test_exact_nodes_are_returned_without_rounding(self) -> None:
        exact = Decimal("0.03123456789012345678901234567890123456789")
        curve = ProjectedRateCurve(INDEX, (RatePoint(date(2026, 1, 1), exact),))
        self.assertEqual(curve.rate(INDEX, date(2026, 1, 1)), exact)
        multi_node = ProjectedRateCurve(INDEX, self.points)
        for point in self.points:
            self.assertEqual(multi_node.rate(INDEX, point.fixing_date), point.rate)

    def test_default_rejects_dates_outside_both_endpoints(self) -> None:
        curve = ProjectedRateCurve(INDEX, self.points)
        for query_date in [date(2025, 12, 31), date(2026, 1, 12)]:
            with self.subTest(query_date=query_date), self.assertRaises(CurveRangeError):
                curve.rate(INDEX, query_date)

    def test_explicit_flat_extrapolation_uses_correct_endpoint(self) -> None:
        curve = ProjectedRateCurve(INDEX, self.points, ExtrapolationPolicy.FLAT)
        self.assertEqual(curve.rate(INDEX, date(2025, 12, 31)), Decimal("0.03"))
        self.assertEqual(curve.rate(INDEX, date(2026, 1, 12)), Decimal("0.05"))

    def test_single_node_has_no_implicit_projection_range(self) -> None:
        curve = ProjectedRateCurve(INDEX, self.points[:1])
        with self.assertRaises(CurveRangeError):
            curve.rate(INDEX, date(2026, 1, 2))
        flat = ProjectedRateCurve(INDEX, self.points[:1], ExtrapolationPolicy.FLAT)
        self.assertEqual(flat.rate(INDEX, date(2050, 1, 1)), Decimal("0.03"))

    def test_duplicate_and_unordered_nodes_are_rejected(self) -> None:
        for points in [self.points[::-1], (self.points[0], self.points[0])]:
            with self.subTest(points=points), self.assertRaises(ValueError):
                ProjectedRateCurve(INDEX, points)

    def test_curve_inputs_are_strict_and_immutable(self) -> None:
        for invalid in [(), list(self.points), ("not a rate point",), None]:
            with self.subTest(points=invalid), self.assertRaises(ValueError):
                ProjectedRateCurve(INDEX, invalid)
        curve = ProjectedRateCurve(INDEX, self.points)
        with self.assertRaises(FrozenInstanceError):
            curve.index = "OTHER"
        with self.assertRaises(FrozenInstanceError):
            curve.points = self.points[::-1]

    def test_extrapolation_identifier_and_date_validation(self) -> None:
        with self.assertRaises(ValueError):
            ProjectedRateCurve(INDEX, self.points, "FLAT")
        with self.assertRaises(ValueError):
            ProjectedRateCurve("", self.points)
        with self.assertRaises(ValueError):
            ProjectedRateCurve(INDEX, self.points, provenance="")
        curve = ProjectedRateCurve(INDEX, self.points)
        with self.assertRaises(MissingCurveError):
            curve.rate("EURIBOR_6M", date(2026, 1, 1))
        with self.assertRaises(ValueError):
            curve.rate(INDEX, datetime(2026, 1, 1))

    def test_interpolation_precision_is_independent_of_callers_context(self) -> None:
        curve = ProjectedRateCurve(INDEX, (
            RatePoint(date(2026, 1, 1), Decimal("0.0123456789")),
            RatePoint(date(2026, 1, 3), Decimal("0.0323456789")),
        ))
        with localcontext() as context:
            context.prec = 2
            # The midpoint adds exactly 0.01; precision=2 would lose input digits.
            self.assertEqual(curve.rate(INDEX, date(2026, 1, 2)), Decimal("0.0223456789"))
            self.assertEqual(context.prec, 2)


class CurveRateProviderTests(unittest.TestCase):
    def setUp(self) -> None:
        self.valuation_date = date(2026, 1, 10)
        self.curve = ProjectedRateCurve(INDEX, (
            RatePoint(date(2026, 1, 1), Decimal("0.03")),
            RatePoint(date(2026, 1, 21), Decimal("0.05")),
        ), ExtrapolationPolicy.FLAT)

    def test_actual_fixing_overrides_curve_on_and_before_valuation(self) -> None:
        provider = CurveRateProvider({INDEX: self.curve}, self.valuation_date, {
            (INDEX, date(2026, 1, 1)): Decimal("-0.01"),
            (INDEX, self.valuation_date): Decimal("0.025"),
        })
        self.assertEqual(provider.rate(INDEX, date(2026, 1, 1)), Decimal("-0.01"))
        self.assertEqual(provider.rate(INDEX, self.valuation_date), Decimal("0.025"))

    def test_missing_actual_is_not_interpolated_or_clamped(self) -> None:
        provider = CurveRateProvider({INDEX: self.curve}, self.valuation_date, {
            (INDEX, date(2026, 1, 1)): Decimal("0.03"),
        })
        for query_date in [date(2025, 12, 31), date(2026, 1, 2), self.valuation_date]:
            with self.subTest(query_date=query_date), self.assertRaises(RequiredFixingError):
                provider.rate(INDEX, query_date)

    def test_future_uses_projected_curve(self) -> None:
        provider = CurveRateProvider({INDEX: self.curve}, self.valuation_date)
        self.assertEqual(provider.rate(INDEX, date(2026, 1, 11)), Decimal("0.04"))

    def test_missing_future_curve_is_explicit(self) -> None:
        provider = CurveRateProvider({}, self.valuation_date)
        with self.assertRaises(MissingCurveError):
            provider.rate(INDEX, date(2026, 1, 11))

    def test_historical_only_provider_does_not_need_a_curve(self) -> None:
        provider = CurveRateProvider({}, self.valuation_date, {
            (INDEX, self.valuation_date): Decimal("0.025"),
        })
        self.assertEqual(provider.rate(INDEX, self.valuation_date), Decimal("0.025"))

    def test_default_historical_mapping_is_not_shared(self) -> None:
        first = CurveRateProvider({}, self.valuation_date)
        second = CurveRateProvider({}, self.valuation_date)
        self.assertIsNot(first.historical_fixings, second.historical_fixings)

    def test_caller_mutation_does_not_change_provider(self) -> None:
        curves = {INDEX: self.curve}
        actuals = {(INDEX, self.valuation_date): Decimal("0.025")}
        provider = CurveRateProvider(curves, self.valuation_date, actuals)
        curves.clear()
        actuals[(INDEX, self.valuation_date)] = Decimal("0.9")
        self.assertEqual(provider.rate(INDEX, self.valuation_date), Decimal("0.025"))
        self.assertEqual(provider.rate(INDEX, date(2026, 1, 11)), Decimal("0.04"))
        with self.assertRaises(TypeError):
            provider.curves["OTHER"] = self.curve
        with self.assertRaises(TypeError):
            provider.historical_fixings[(INDEX, self.valuation_date)] = Decimal("0.9")
        with self.assertRaises(FrozenInstanceError):
            provider.valuation_date = date(2030, 1, 1)

    def test_curve_map_keys_must_match_curve_index(self) -> None:
        for invalid in [{"OTHER": self.curve}, {INDEX: Decimal("0.03")}, {"": self.curve}, None]:
            with self.subTest(curves=invalid), self.assertRaises(ValueError):
                CurveRateProvider(invalid, self.valuation_date)

    def test_historical_fixing_keys_rates_and_dates_are_validated(self) -> None:
        invalid_maps = [
            {INDEX: Decimal("0.03")},
            {(INDEX,): Decimal("0.03")},
            {(INDEX, datetime(2026, 1, 1)): Decimal("0.03")},
            {(INDEX, "2026-01-01"): Decimal("0.03")},
            {("", date(2026, 1, 1)): Decimal("0.03")},
            {(INDEX, date(2026, 1, 1)): 0.03},
            {(INDEX, date(2026, 1, 1)): True},
            {(INDEX, date(2026, 1, 1)): Decimal("Infinity")},
            {(INDEX, date(2026, 1, 11)): Decimal("0.03")},
            None,
        ]
        for invalid in invalid_maps:
            with self.subTest(historical_fixings=invalid), self.assertRaises(ValueError):
                CurveRateProvider({INDEX: self.curve}, self.valuation_date, invalid)

    def test_valuation_and_query_date_types_are_strict(self) -> None:
        for invalid in [datetime(2026, 1, 10), "2026-01-10", True, None]:
            with self.subTest(valuation_date=invalid), self.assertRaises(ValueError):
                CurveRateProvider({INDEX: self.curve}, invalid)
        provider = CurveRateProvider({INDEX: self.curve}, self.valuation_date)
        for invalid in [datetime(2026, 1, 11), "2026-01-11", False, None]:
            with self.subTest(fixing_date=invalid), self.assertRaises(ValueError):
                provider.rate(INDEX, invalid)

    def test_invalid_query_index_is_rejected_before_lookup(self) -> None:
        provider = CurveRateProvider({INDEX: self.curve}, self.valuation_date)
        for invalid in ["", " ", "EURIBOR_3M ", True, None]:
            with self.subTest(index=invalid), self.assertRaises(ValueError):
                provider.rate(invalid, date(2026, 1, 11))


if __name__ == "__main__":
    unittest.main()
