"""Independent financial counterexamples discovered in the financial audit.

Expected values are elementary cash arithmetic or reduced rational identities,
not outputs from the production implementation or the previous Excel model.
"""

from dataclasses import replace
from datetime import date, timedelta
from decimal import Decimal, Inexact, localcontext
from fractions import Fraction
import unittest

from trident.analysis import AssetExposure, DatedCashflow, LimitDirection, LimitSpec, LimitStatus, MetricStatus, PortfolioAnalyzer, ReturnStatus, moic, xirr, xnpv
from trident.cashflows import ContractualCashflowEngine
from trident.conventions import AccrualDateBasis, BusinessDayConvention, DayCount
from trident.conventions.calendar import TargetCalendar
from trident.conventions.day_count import accrual_fraction
from trident.conventions.liability_rates import FirstStubRateMethod, first_stub_reference_rate
from trident.domain.models import CouponType, InputValidationError, LoanPosition, LoanTerms
from trident.funding import AssetPurchase, DebtIssue, FundingEngine
from trident.market import FlatRateProvider


D = Decimal
ASOF = date(2026, 1, 1)


def exposure(identity="F1", par="70", spread="300", *, coupon_type=CouponType.FLOATING, coupon=None):
    return AssetExposure(identity, "OB1", "BSL", "CORPORATE", "DE", "power", "EUR", D(par),
                         None if spread is None else D(spread), date(2031, 1, 1),
                         coupon_type=coupon_type, fixed_coupon_rate=None if coupon is None else D(coupon))


class CouponPopulationAuditTests(unittest.TestCase):
    def test_fixed_par_does_not_dilute_floating_was(self):
        # 70 floating at 300bps +30 fixed at8%: WAS300bps, WAC8%.
        assets = (exposure(), exposure("X", "30", None, coupon_type=CouponType.FIXED, coupon=".08"))
        report = PortfolioAnalyzer().analyze(assets, ASOF,
            limits=(LimitSpec("MIN_WAS", "WAS_BPS", D(300), LimitDirection.MINIMUM),))
        self.assertEqual(report.metric("WAS_BPS").value, D(300))
        self.assertEqual(report.metric("WAC_RATE").value, D(".08"))
        self.assertEqual(report.metric("WAS_BPS").coverage, D(1))
        self.assertEqual(report.limits[0].status, LimitStatus.PASS)

    def test_fixed_wac_has_its_own_exact_par_denominator(self):
        # (20*6%+30*8%)/50 =7.2%, independently of50 floating par.
        assets = (exposure(par="50"),
                  exposure("X1", "20", None, coupon_type=CouponType.FIXED, coupon=".06"),
                  exposure("X2", "30", None, coupon_type=CouponType.FIXED, coupon=".08"))
        report = PortfolioAnalyzer().analyze(assets, ASOF,
            limits=(LimitSpec("MIN_WAC", "WAC_RATE", D(".072"), LimitDirection.MINIMUM),))
        self.assertEqual(report.metric("WAC_RATE").value, D(".072"))
        self.assertEqual(report.limits[0].headroom, D(0))
        self.assertEqual(report.limits[0].status, LimitStatus.PASS)

    def test_floating_was_limit_uses_exact_fraction_not_display_value(self):
        # (70*300+20*450)/90 =1000/3, slightly above the finite display.
        threshold = D("333.3333333333333333333333333333333")
        report = PortfolioAnalyzer().analyze((exposure(), exposure("F2", "20", "450"),
            exposure("X", "10", None, coupon_type=CouponType.FIXED, coupon=".1")), ASOF,
            limits=(LimitSpec("MAX_WAS", "WAS_BPS", threshold),))
        self.assertEqual(report.metric("WAS_BPS").value, threshold)
        self.assertEqual(report.limits[0].status, LimitStatus.BREACH)

    def test_missing_coupon_classification_does_not_infer_floating(self):
        report = PortfolioAnalyzer().analyze((exposure(), exposure("UNKNOWN", "30", "400", coupon_type=None)), ASOF,
            limits=(LimitSpec("MIN_WAS", "WAS_BPS", D(250), LimitDirection.MINIMUM),))
        self.assertIsNone(report.metric("WAS_BPS").value)
        self.assertIsNone(report.metric("WAC_RATE").value)
        self.assertEqual(report.metric("WAS_BPS").status, MetricStatus.UNAVAILABLE)
        self.assertEqual(report.metric("ALL_ASSET_SPREAD_BPS").value, D(330))
        self.assertEqual(report.limits[0].status, LimitStatus.UNAVAILABLE)

    def test_missing_spread_keeps_full_floating_denominator(self):
        report = PortfolioAnalyzer().analyze((exposure(), exposure("F2", "20", None),
            exposure("X", "10", None, coupon_type=CouponType.FIXED, coupon=".08")), ASOF)
        metric = report.metric("WAS_BPS")
        self.assertEqual(metric.status, MetricStatus.INCOMPLETE)
        self.assertIsNone(metric.value)
        self.assertEqual(Fraction(metric.coverage).limit_denominator(), Fraction(7, 9))

    def test_empty_coupon_subset_is_unavailable_rather_than_zero(self):
        report = PortfolioAnalyzer().analyze((exposure(coupon_type=CouponType.FIXED, spread=None, coupon=".06"),), ASOF)
        self.assertEqual(report.metric("WAS_BPS").status, MetricStatus.UNAVAILABLE)
        self.assertEqual(report.metric("WAC_RATE").value, D(".06"))
        report = PortfolioAnalyzer().analyze((exposure(),), ASOF)
        self.assertEqual(report.metric("WAC_RATE").status, MetricStatus.UNAVAILABLE)

    def test_missing_fixed_coupon_is_incomplete_and_observed_zero_is_valid(self):
        report = PortfolioAnalyzer().analyze((exposure("X1", "70", None, coupon_type=CouponType.FIXED, coupon="0"),
            exposure("X2", "30", None, coupon_type=CouponType.FIXED)), ASOF)
        self.assertEqual(report.metric("WAC_RATE").status, MetricStatus.INCOMPLETE)
        self.assertEqual(report.metric("WAC_RATE").coverage, D(".7"))
        report = PortfolioAnalyzer().analyze((exposure(coupon_type=CouponType.FIXED, spread=None, coupon="0"),), ASOF)
        self.assertEqual(report.metric("WAC_RATE").value, D(0))

    def test_coupon_metadata_is_typed_and_context_independent(self):
        for changes in (dict(coupon_type="FLOATING"), dict(coupon_type=None, fixed_coupon_rate=D(".06")),
                        dict(coupon_type=CouponType.FLOATING, fixed_coupon_rate=D(".06")),
                        dict(coupon_type=CouponType.FIXED, fixed_coupon_rate=0.06),
                        dict(coupon_type=CouponType.FIXED, fixed_coupon_rate=D("NaN"))):
            with self.subTest(changes=changes), self.assertRaises(InputValidationError):
                replace(exposure(), **changes)
        with localcontext() as context:
            context.prec = 2
            context.traps[Inexact] = True
            report = PortfolioAnalyzer().analyze((exposure(par="50"),
                exposure("X1", "20", None, coupon_type=CouponType.FIXED, coupon=".06"),
                exposure("X2", "30", None, coupon_type=CouponType.FIXED, coupon=".08")), ASOF)
        self.assertEqual(report.metric("WAC_RATE").value, D(".072"))


class FundingSnapshotAuditTests(unittest.TestCase):
    def test_one_shot_funding_inputs_preserve_real_sources_and_uses(self):
        # Uses99.50clean +1accrued +2fees +3reserve=105.50;
        # debt60*.99=59.40; equity46.10. A validation-consumed generator gave0.
        result = FundingEngine().calculate(iter((AssetPurchase("L", D(100), D("99.5"), D(1)),)),
            iter((DebtIssue("A", D(60), D(99)),)), upfront_fees=D(2), cash_reserve=D(3))
        self.assertEqual(result.asset_clean_cost, D("99.50"))
        self.assertEqual(result.debt_proceeds, D("59.40"))
        self.assertEqual(result.equity_cash_funding, D("46.10"))
        self.assertEqual(result.total_sources, D("105.50"))
        self.assertEqual(result.total_uses, D("105.50"))

    def test_duplicate_generator_inputs_are_rejected_before_posting(self):
        purchase = AssetPurchase("L", D(100), D(100))
        issue = DebtIssue("A", D(20), D(100))
        for purchases, issues in ((iter((purchase, purchase)), ()), ((purchase,), iter((issue, issue)))):
            with self.subTest(), self.assertRaisesRegex(InputValidationError, "Duplicate"):
                FundingEngine().calculate(purchases, issues, upfront_fees=D(0), cash_reserve=D(0))

    def test_empty_or_noniterable_funding_inputs_fail_explicitly(self):
        for purchases, issues in ((iter(()), ()), (None, ()), ((AssetPurchase("L", D(100), D(100)),), None)):
            with self.subTest(), self.assertRaises(InputValidationError):
                FundingEngine().calculate(purchases, issues, upfront_fees=D(0), cash_reserve=D(0))


class FixingAndMathAuditTests(unittest.TestCase):
    def test_exact_three_month_stub_observation_needs_only_three_month_rate(self):
        # Jan31+3M=Apr30. The exact3M observation need not have a1M neighbour.
        rate = D("0.001" + "9" * 65)
        provider = FlatRateProvider({"EURIBOR_3M": rate})
        result = first_stub_reference_rate(provider, date(2026, 1, 29), date(2026, 1, 31),
            date(2026, 4, 30), "EURIBOR_3M", FirstStubRateMethod.INTERPOLATE_1M_3M_6M)
        self.assertEqual(result, rate)
        self.assertEqual(Fraction(result), Fraction(rate))

    def test_invalid_used_stub_observations_rejected_on_every_lookup_path(self):
        class InvalidProvider:
            def rate(self, index, fixing_date):
                return float("nan")
        for method, end in ((FirstStubRateMethod.SELECTED_REFERENCE, date(2026, 3, 31)),
                            (FirstStubRateMethod.INTERPOLATE_1M_3M_6M, date(2026, 2, 28)),
                            (FirstStubRateMethod.INTERPOLATE_1M_3M_6M, date(2026, 4, 30)),
                            (FirstStubRateMethod.INTERPOLATE_1M_3M_6M, date(2026, 7, 31))):
            with self.subTest(method=method, end=end), self.assertRaisesRegex(ValueError, "finite Decimal"):
                first_stub_reference_rate(InvalidProvider(), date(2026, 1, 29), date(2026, 1, 31), end, "EURIBOR_3M", method)

    def test_eurobond_and_us_eom_february_conventions_are_distinct(self):
        # Feb28->Mar31: Eurobond32/360, US-EOM30/360; never infer one.
        self.assertEqual(accrual_fraction(date(2026, 2, 28), date(2026, 3, 31), DayCount.THIRTY_E_360), Fraction(32, 360))
        self.assertEqual(accrual_fraction(date(2026, 2, 28), date(2026, 3, 31), DayCount.THIRTY_U_360_EOM), Fraction(30, 360))

    def test_target_holidays_do_not_gain_substitute_mondays(self):
        # ECB2027 closures: May1Saturday/Dec25Saturday/Dec26Sunday.
        calendar = TargetCalendar()
        self.assertFalse(calendar.is_business_day(date(2027, 5, 1)))
        self.assertTrue(calendar.is_business_day(date(2027, 5, 3)))
        self.assertTrue(calendar.is_business_day(date(2027, 12, 27)))

    def test_principal_is_repaid_after_same_day_coupon_on_opening_par(self):
        # Unadjusted30E/360 quarter:100*4%*.25=1; final100par gives101cash.
        terms = LoanTerms("L", "EUR", date(2026, 1, 20), date(2026, 4, 20), D(100), CouponType.FIXED,
            fixed_rate=D(".04"), day_count=DayCount.THIRTY_E_360,
            business_day_convention=BusinessDayConvention.UNADJUSTED, accrual_date_basis=AccrualDateBasis.UNADJUSTED)
        row, = ContractualCashflowEngine(FlatRateProvider({})).generate(LoanPosition(terms, terms.start_date, D(100)))
        self.assertEqual(row.cash_interest, D(1))
        self.assertEqual(row.principal_repayment, D(100))
        self.assertEqual(row.total_cash, D(101))

    def test_actual_date_return_cashflows_and_same_day_gross_moic(self):
        # -100 at0, same-day60reinvest/10distribution, later175distribution:
        # net150invested at0,175in365days =>1/6 IRR; grossMOIC185/160.
        flows = (DatedCashflow(ASOF, D(-100)), DatedCashflow(ASOF, D(-60)), DatedCashflow(ASOF, D(10)),
                 DatedCashflow(ASOF + timedelta(days=365), D(175)))
        result = xirr(flows)
        self.assertEqual(result.status, ReturnStatus.AVAILABLE)
        self.assertLess(abs(Fraction(result.value) - Fraction(1, 6)), Fraction(1, 10**12))
        self.assertLess(abs(result.residual), D("1e-8"))
        self.assertEqual(moic(flows).value, D("1.15625"))
        self.assertEqual(xnpv(D(0), flows), D(25))


if __name__ == "__main__":
    unittest.main()
