"""Named transport and independently calculable credit workbook examples.

Only private copies are edited. The delivered workbook is a template/reference,
and failed input validation must leave its copy byte-for-byte unchanged.
"""

import tempfile
import unittest
from datetime import date
from decimal import Decimal
from pathlib import Path

from openpyxl import load_workbook
from workbook_fixtures import copy_input_template
from openpyxl.utils.cell import get_column_letter, quote_sheetname

from trident.adapters import excel_schema as schema
from trident.adapters.credit_records import credit_events_from_records
from trident.adapters.excel import NamedWorkbook, run_workbook
from trident.adapters.clo_example import run_synthetic_clo_example
from trident.credit import CreditProjectionStatus
from workbook_fixtures import hand_controls, put_records, write_controls, assert_h00_projection_matches


ROOT = Path(__file__).resolve().parents[1]
D = Decimal


class CreditRecordsTests(unittest.TestCase):
    def parse(self, events, recoveries=()):
        return credit_events_from_records(tuple(events), tuple(recoveries), loan_ids=frozenset({"LOAN"}))

    def test_empty_credit_inputs_are_empty(self):
        self.assertEqual(self.parse(()), ())

    def test_unsorted_actual_recovery_dates_sort_without_changing_fractions(self):
        event, = self.parse(({"loan_id":"LOAN","event_type":"DEFAULT","event_date":"2027-02-01","writeoff_date":"2027-05-01"},), (
            {"loan_id":"LOAN","recovery_date":"2027-04-01","recovery_fraction":"0.35"},
            {"loan_id":"LOAN","recovery_date":"2027-03-01","recovery_fraction":"0.25"},
        ))
        self.assertEqual([row.recovery_date for row in event.recoveries], [date(2027,3,1),date(2027,4,1)])
        self.assertEqual([row.recovery_fraction for row in event.recoveries], [D("0.25"),D("0.35")])

    def test_unknown_duplicate_and_unsupported_events_fail(self):
        base = {"loan_id":"LOAN","event_type":"DEFAULT","event_date":"2027-02-01","writeoff_date":None}
        for events in ((dict(base,loan_id="UNKNOWN"),), (base,base), (dict(base,event_type="PARTIAL_DEFAULT"),),
                       (dict(base,event_type="PREPAYMENT",writeoff_date="2027-03-01"),),
                       (dict(base,implied_recovery_rate=.6),)):
            with self.subTest(events=events), self.assertRaises(ValueError):
                self.parse(events)

    def test_recovery_must_belong_to_default_and_cannot_exceed_claim(self):
        event = {"loan_id":"LOAN","event_type":"DEFAULT","event_date":"2027-02-01","writeoff_date":None}
        recovery = {"loan_id":"LOAN","recovery_date":"2027-03-01","recovery_fraction":"0.6"}
        invalid = (
            ((), (recovery,)),
            ((dict(event,event_type="PREPAYMENT"),), (recovery,)),
            ((event,), (dict(recovery,loan_id="UNKNOWN"),)),
            ((event,), (recovery,dict(recovery,recovery_date="2027-04-01",recovery_fraction="0.40001"))),
            ((event,), (recovery,recovery)),
            ((dict(event,writeoff_date="2027-02-15"),), (recovery,)),
            ((event,), (dict(recovery,recovery_lag=12),)),
        )
        for events, recoveries in invalid:
            with self.subTest(events=events,recoveries=recoveries), self.assertRaises(ValueError):
                self.parse(events,recoveries)


class ExcelInterfaceTests(unittest.TestCase):
    def setUp(self):
        folder = tempfile.TemporaryDirectory()
        self.addCleanup(folder.cleanup)
        self.path = Path(folder.name) / "model.xlsx"
        copy_input_template(self.path)

    def access(self, function, *, save=False):
        book = load_workbook(self.path)
        try:
            result = function(NamedWorkbook(book))
            if save:
                book.save(self.path)
            return result
        finally:
            book.close()

    @staticmethod
    def table(adapter, key):
        return adapter.table_records(schema.TABLE_RANGE_NAMES[key],schema.TABLE_NAMES[key])

    def edit_table(self, key, rows):
        self.access(lambda a:a.write_table(schema.TABLE_RANGE_NAMES[key],schema.TABLE_NAMES[key],tuple(rows)),save=True)

    def small_hand_example(self):
        """100 asset par, 50 zero-coupon debt, zero fees and 50 equity funding."""
        def edit(adapter):
            asset = dict(self.table(adapter,"assets")[0])
            asset.update(loan_id="LOAN",initial_par=100,current_par=100,purchase_price_pct=100,
                         coupon_type="FIXED",fixed_rate=.12,rate_index=None,index_floor_bps=None,spread_bps=0,
                         maturity_date_unadjusted=date(2027,11,20),amortization_type="BULLET",
                         amortization_fraction_initial_par_per_period=0,amortization_first_date_unadjusted=None,
                         amortization_periods_remaining=None,acquired_accrued_interest=0)
            capital = self.table(adapter,"capital_stack")
            debt = dict(next(row for row in capital if row["instrument_type"] == "DEBT"))
            debt.update(nominal_amount=50,issue_price_pct=100,coupon_type="FIXED",fixed_rate=0,
                        rate_index=None,index_floor_bps=None,spread_bps=0,oc_minimum=None,ic_minimum=None)
            equity = dict(next(row for row in capital if row["instrument_type"] == "EQUITY"))
            equity.update(nominal_amount=50,issue_price_pct=100)
            put_records(adapter, "assets", (asset,))
            put_records(adapter, "capital_stack", (debt, equity))
            write_controls(adapter, hand_controls((asset,), (debt, equity),
                closing_date=date(2026,11,20), first_payment_date=date(2027,2,20),
                legal_final_date=date(2028,11,20)))
            put_records(adapter, "portfolio_limits", ())
        self.access(edit,save=True)


    def test_empty_credit_tables_leave_baseline_economics_identical(self):
        # Disable unrelated synthetic what-if cases to test this boundary once.
        self.access(lambda a:a.write_scalar(schema.SCALAR_NAMES["scenario_enabled"],False),save=True)
        result = run_workbook(self.path)
        reference = run_synthetic_clo_example(ROOT/"data/examples/hybrid_500m")
        assert_h00_projection_matches(self, result.clo, reference.clo)
        self.assertEqual(result.equity_irr,reference.equity_irr)
        self.assertEqual(result.credit_projections,())
        self.access(lambda a:self.assertEqual(self.table(a,"credit_summary"),()))

    def test_default_recovery_and_writeoff_publish_separate_actual_ledgers(self):
        self.small_hand_example()
        self.edit_table("credit_events",({"loan_id":"LOAN","event_type":"DEFAULT","event_date":date(2027,2,22),"writeoff_date":date(2027,2,22)},))
        self.edit_table("recovery_schedule",({"loan_id":"LOAN","recovery_date":date(2027,2,22),"recovery_fraction":.6},))
        result = run_workbook(self.path)
        credit, = result.credit_projections
        self.assertEqual(credit.defaulted_exposure,D(100))
        self.assertEqual(credit.total_recovery_principal,D(60))
        self.assertEqual(credit.total_par_loss,D(40))
        self.assertEqual(credit.total_cash_interest,D("3.13"))
        self.assertEqual(result.clo.total_equity_distributions,D("13.13"))
        self.assertTrue(result.clo.terminal_value_available)
        def check(adapter):
            summary, = self.table(adapter,"credit_summary")
            self.assertEqual(summary["status"],"DEFAULT_RESOLVED")
            self.assertEqual(summary["total_recovery_principal"],60)
            self.assertEqual(summary["total_par_loss"],40)
            self.assertEqual([row["source"] for row in self.table(adapter,"credit_collections")],["SCHEDULED","RECOVERY"])
            self.assertEqual([row["source"] for row in self.table(adapter,"asset_par_movements")],["SCHEDULED","DEFAULT","RECOVERY","WRITE_OFF"])
            # Original reference still repays100, actual receipts only60.
            self.assertEqual(sum(row["principal_repayment"] for row in self.table(adapter,"asset_cashflows")),100)
            self.assertEqual(sum(row["principal_collection"] for row in self.table(adapter,"credit_collections")),60)
            period, = self.table(adapter,"clo_periods")
            self.assertEqual(period["newly_defaulted_par"],100)
            self.assertEqual(period["recognized_par_loss"],40)
        self.access(check)

    def test_prepayment_actual_coupon_and_principal_reach_excel_and_clo(self):
        self.small_hand_example()
        self.edit_table("credit_events",({"loan_id":"LOAN","event_type":"PREPAYMENT","event_date":date(2027,1,15),"writeoff_date":None},))
        result = run_workbook(self.path)
        credit, = result.credit_projections
        # Nov20--Jan15 is56ACTdays:100*.12*56/360=1.8666..., posted1.87.
        self.assertEqual(credit.total_cash_interest,D("1.87"))
        self.assertEqual(credit.total_prepayment_principal,D(100))
        self.assertIs(credit.status,CreditProjectionStatus.PREPAID)
        self.assertEqual(result.clo.total_equity_distributions,D("51.87"))
        self.access(lambda a:self.assertEqual(self.table(a,"credit_collections")[0]["cash_interest"],1.87))

    def test_zero_recovery_writeoff_and_unresolved_claim_have_distinct_statuses(self):
        self.small_hand_example()
        self.edit_table("credit_events",({"loan_id":"LOAN","event_type":"DEFAULT","event_date":date(2027,1,15),"writeoff_date":None},))
        result = run_workbook(self.path)
        credit, = result.credit_projections
        self.assertEqual(credit.final_defaulted_par,D(100))
        self.assertEqual(credit.total_par_loss,0)
        self.assertFalse(result.clo.terminal_value_available)
        self.assertIsNone(result.equity_irr.value)
        self.edit_table("credit_events",({"loan_id":"LOAN","event_type":"DEFAULT","event_date":date(2027,1,15),"writeoff_date":date(2027,1,15)},))
        result = run_workbook(self.path)
        credit, = result.credit_projections
        self.assertEqual(credit.final_defaulted_par,0)
        self.assertEqual(credit.total_par_loss,D(100))
        # Debt is still50: resolving claim is not equivalent to curing debt.
        self.assertFalse(result.clo.terminal_value_available)
        self.assertEqual(result.clo.final_debt_par,D(50))

    def test_invalid_explicit_default_oc_policy_fails_atomically(self):
        self.small_hand_example()
        self.edit_table("credit_events",({"loan_id":"LOAN","event_type":"DEFAULT","event_date":date(2027,1,15),"writeoff_date":date(2027,1,15)},))
        self.access(lambda adapter: adapter.write_scalar(
            schema.SCALAR_NAMES["legacy_defaulted_asset_valuation_fraction"], 1.01), save=True)
        before = self.path.read_bytes()
        with self.assertRaisesRegex(ValueError,"defaulted_asset_valuation_fraction"):
            run_workbook(self.path)
        self.assertEqual(self.path.read_bytes(),before)

    def test_invalid_credit_header_rejects_before_outputs_change(self):
        def edit(adapter):
            sheet,(left,top,_,_) = adapter.region(schema.TABLE_RANGE_NAMES["credit_events"])
            sheet.cell(top,left).value="unknown"
        self.access(edit,save=True)
        before = self.path.read_bytes()
        with self.assertRaisesRegex(ValueError,"headers|metadata"):
            run_workbook(self.path)
        self.assertEqual(self.path.read_bytes(),before)

    def test_input_table_movement_and_renamed_sheet_are_resolved_by_names(self):
        self.small_hand_example()
        self.edit_table("credit_events",({"loan_id":"LOAN","event_type":"PREPAYMENT","event_date":date(2027,1,15),"writeoff_date":None},))
        def move(adapter):
            sheet,(left,top,right,bottom)=adapter.region(schema.TABLE_RANGE_NAMES["credit_events"])
            matrix = [[sheet.cell(row,col).value for col in range(left,right+1)] for row in range(top,bottom+1)]
            table = sheet.tables[schema.TABLE_NAMES["credit_events"]]
            del sheet.tables[table.name]
            sheet.title="Moved Credit Inputs"
            for row in range(top,bottom+1):
                for col in range(left,right+1):
                    sheet.cell(row,col).value=None
            for row_index,values in enumerate(matrix,11):
                for col_index,value in enumerate(values,4):
                    sheet.cell(row_index,col_index).value=value
            end_col=get_column_letter(3+len(matrix[0]))
            table.ref=f"D11:{end_col}{10+len(matrix)}"
            sheet.add_table(table)
            adapter.workbook.defined_names[schema.TABLE_RANGE_NAMES["credit_events"]].attr_text=f"{quote_sheetname(sheet.title)}!$D$11:${end_col}${10+len(matrix)}"
        self.access(move,save=True)
        result=run_workbook(self.path)
        self.assertEqual(result.credit_projections[0].total_prepayment_principal,D(100))
        self.access(lambda a:self.assertEqual(self.table(a,"credit_events")[0]["loan_id"],"LOAN"))

    def test_clearing_credit_events_clears_stale_credit_outputs(self):
        self.small_hand_example()
        self.edit_table("credit_events",({"loan_id":"LOAN","event_type":"PREPAYMENT","event_date":date(2027,1,15),"writeoff_date":None},))
        run_workbook(self.path)
        self.edit_table("credit_events",())
        result=run_workbook(self.path)
        self.assertEqual(result.credit_projections,())
        for key in ("credit_summary","credit_collections","asset_par_movements"):
            self.access(lambda a,k=key:self.assertEqual(self.table(a,k),()))


if __name__=="__main__":
    unittest.main()
