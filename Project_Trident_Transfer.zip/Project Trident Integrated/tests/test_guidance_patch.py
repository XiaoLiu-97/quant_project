"""A presentation donor must not alter finance, native features or style parts."""

import importlib.util
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
from xml.etree import ElementTree as ET
from zipfile import ZipFile

from openpyxl import Workbook, load_workbook
from openpyxl.styles import Alignment, Font

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location('guidance_patch', ROOT / 'scripts/apply_guidance_patch.py')
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)


class GuidancePackagingTests(unittest.TestCase):
    def setUp(self):
        (ROOT / '.tmp').mkdir(exist_ok=True)
        self.folder = tempfile.TemporaryDirectory(dir=ROOT / '.tmp')
        self.addCleanup(self.folder.cleanup)
        self.original, self.authored = [Path(self.folder.name) / name for name in ('base.xlsx', 'donor.xlsx')]
        for destination in (self.original, self.authored):
            book = Workbook()
            sheet = book.active
            sheet.title = 'Guidance'
            for address in ('A3', 'B14', 'A34', 'B34'):
                sheet[address] = 'original guidance'
                sheet[address].font = Font(name='Arial', size=10)
                sheet[address].alignment = Alignment(wrap_text=True)
            sheet['C80'] = 'unrelated user note'
            sheet = book.create_sheet('Assets')
            sheet['A1'] = 'unchanged financial input'
            book.save(destination)
            book.close()
        book = load_workbook(self.authored)
        for address in module.CELLS:
            book['Guidance'][address] = 'New method instruction ' + address
        book['Guidance'].row_dimensions[34].height = 60
        book['Guidance'].row_dimensions[66].height = 60
        book['Guidance'].row_dimensions[74].height = 115
        book['Assets']['A1'] = 'must not transfer'
        book.save(self.authored)
        book.close()
        # Artifact exports can encode literal strings with t="str" rather
        # than inlineStr. Independently construct that package representation
        # so the text-only merge accepts it without accepting formula cells.
        with ZipFile(self.authored) as donor:
            entries = [(entry, donor.read(entry)) for entry in donor.infolist()]
            part = module.guidance_part(donor)
        with ZipFile(self.authored, 'w') as donor:
            for entry, payload in entries:
                if entry.filename == part:
                    tree = ET.fromstring(payload)
                    cell = next(c for c in tree.iter(module.Q('c')) if c.get('r') == 'B14')
                    cell.remove(cell.find(module.Q('is')))
                    cell.set('t', 'str')
                    ET.SubElement(cell, module.Q('v')).text = 'New method instruction B14'
                    payload = ET.tostring(tree)
                donor.writestr(entry, payload)

    def test_only_guidance_package_part_changes_and_styles_remain_original(self):
        with ZipFile(self.original) as package:
            before = {name: package.read(name) for name in package.namelist()}
            part = module.guidance_part(package)
        module.apply_guidance_patch(self.original, self.authored)
        with ZipFile(self.original) as package:
            self.assertEqual(set(package.namelist()), set(before))
            self.assertTrue(all(package.read(name) == data for name, data in before.items() if name != part))
        book = load_workbook(self.original)
        self.addCleanup(book.close)
        self.assertEqual(book['Guidance']['B34'].value, 'New method instruction B34')
        self.assertEqual(book['Guidance']['C80'].value, 'unrelated user note')
        self.assertEqual(book['Guidance']['B66'].style_id, book['Guidance']['B34'].style_id)
        self.assertEqual(book['Assets']['A1'].value, 'unchanged financial input')
        self.assertEqual(book['Guidance'].row_dimensions[34].height, 60)
        self.assertEqual(book['Guidance']['B74'].value, 'New method instruction B74')
        self.assertEqual(book['Guidance'].row_dimensions[74].height, 115)

    def test_formula_donor_fails_without_replacing_original(self):
        before = self.original.read_bytes()
        book = load_workbook(self.authored)
        book['Guidance']['B14'] = '=1+1'
        book.save(self.authored)
        book.close()
        with self.assertRaisesRegex(ValueError, 'literal text'):
            module.apply_guidance_patch(self.original, self.authored)
        self.assertEqual(self.original.read_bytes(), before)

    def test_atomic_replacement_failure_preserves_original_and_cleans_staging(self):
        before = self.original.read_bytes()
        with patch.object(module.os, 'replace', side_effect=PermissionError('locked')):
            with self.assertRaises(PermissionError):
                module.apply_guidance_patch(self.original, self.authored)
        self.assertEqual(self.original.read_bytes(), before)
        self.assertEqual(list(Path(self.folder.name).glob('.guidance-*')), [])
