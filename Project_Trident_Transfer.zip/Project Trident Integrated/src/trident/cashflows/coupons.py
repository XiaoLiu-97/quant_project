"""Resolve term resets and projected compounded overnight coupon factors.

Payment schedules determine cash dates; reset schedules determine rate
entitlement. Their intersections retain frozen rate observations so a partial
prepayment never uses a rounded full-period weighted-average coupon. This is
Term observations and overnight DF forwards are separate input contracts.
Projected overnight period factors retain exact rational values; the displayed
equivalent annual rate never becomes an input to cash posting.
"""

from bisect import bisect_left, bisect_right
from dataclasses import dataclass
from datetime import date
from decimal import Decimal
from fractions import Fraction

from trident.conventions.calendar import BusinessCalendar, calendar_from_name
from trident.conventions.day_count import DayCount, accrual_fraction
from trident.conventions.schedule import AccrualPeriod, ScheduleBuilder, StubConvention
from trident.domain.models import CouponSegment, CouponStepPolicy, CouponType, InputValidationError, LoanCashflow, LoanTerms, require_date, require_decimal
from trident.domain.numeric import basis_points_rate, compose_floating_rate, decimal_fraction
from trident.market.rates import RateProvider


def segment_factor(segments: tuple[CouponSegment, ...], day_count: DayCount,
                   through: date | None = None) -> Fraction:
    """Sum unposted simple-interest factors, optionally cut at actual exit.

    End dates are exclusive. Each reset's own partial DCF is computed before
    the sum, including day-count rules which need not be globally additive.
    There is one monetary rounding at the final loan/payment boundary.
    """
    return sum(((s.exact_factor * accrual_fraction(s.accrual_start,
        min(s.accrual_end, through) if through is not None else s.accrual_end, day_count)
        / accrual_fraction(s.accrual_start, s.accrual_end, day_count)
        if s.exact_factor is not None else Fraction(s.all_in_rate) * accrual_fraction(s.accrual_start,
        min(s.accrual_end, through) if through is not None else s.accrual_end, day_count))
        for s in segments if through is None or through > s.accrual_start), Fraction())


def cashflow_coupon_factor(row: LoanCashflow, day_count: DayCount,
                           through: date | None = None) -> Fraction:
    """Use native frozen segments; unsegmented scalar references remain valid.

    Legacy hand/imported reference rows have no segments. Their scalar coupon
    is constant by contract; never reconstruct native multi-reset economics
    from a weighted display rate. Public credit replay enforces that boundary.
    """
    if row.coupon_segments:
        return segment_factor(row.coupon_segments, day_count, through)
    end = min(row.accrual_end, through) if through is not None else row.accrual_end
    return Fraction(row.all_in_rate) * accrual_fraction(row.accrual_start, end, day_count)


@dataclass(frozen=True)
class PeriodCoupon:
    """Exact factor plus display rates and original frozen segment entitlement."""

    segments: tuple[CouponSegment, ...]
    exact_dcf: Fraction
    exact_factor: Fraction
    index_rate: Decimal | None
    fixing_date: date | None
    all_in_rate: Decimal
    spread_bps: Decimal


class CouponProjector:
    """Build one reset grid; lazily resolve each needed fixing once per loan.

    Bisect selects overlapping reset intervals without scanning all resets for
    every payment. The cache is private to this loan/projection, never global.
    Frozen replay accepts observations but recomputes dates and coupon bounds;
    a fixing reused across payments must have one consistent observed value.
    """

    def __init__(self, terms: LoanTerms, periods: tuple[AccrualPeriod, ...],
                 calendar: BusinessCalendar, provider: RateProvider | None = None) -> None:
        self.terms, self.provider = terms, provider
        self.is_overnight = terms.rate_index in {"ESTR", "SOFR", "SONIA"}
        self.payment_starts = tuple(p.accrual_start for p in periods)
        independent = (terms.coupon_type is CouponType.FLOATING and
                       terms.reset_frequency_months is not None and
                       terms.reset_frequency_months != terms.frequency_months)
        self.resets = ScheduleBuilder(calendar).build(
            terms.start_date, terms.maturity_date, terms.reset_frequency_months,
            business_day_convention=terms.business_day_convention,
            accrual_date_basis=terms.accrual_date_basis,
            fixing_lag_business_days=terms.fixing_lag_business_days,
            end_of_month=terms.end_of_month, stub_convention=StubConvention.SHORT_LAST,
        ) if independent else periods
        self.starts = tuple(p.accrual_start for p in self.resets)
        self.step_dates = tuple(s.effective_date for s in terms.coupon_steps)
        self.step_values = tuple(s.fixed_rate if terms.coupon_type is CouponType.FIXED else s.spread_bps
                                 for s in terms.coupon_steps)
        base = terms.fixed_rate if terms.coupon_type is CouponType.FIXED else terms.spread_bps
        # A no-op replacement never introduces a new accrual boundary. Besides
        # avoiding redundant work, it prevents dates alone changing economics.
        self.change_dates = tuple(day for day, value, previous in
            zip(self.step_dates, self.step_values, (base, *self.step_values[:-1])) if value != previous)
        self.observations: dict[date, Decimal] = {}

    @classmethod
    def for_terms(cls, terms: LoanTerms, calendar: BusinessCalendar | None = None,
                  provider: RateProvider | None = None) -> "CouponProjector":
        """Build the same payment/reset grids for dated analytical entitlement.

        No observations are fetched until project() needs one. Analytics may
        therefore reuse one local resolver per stepped loan across snapshots,
        rather than inferring a current margin from historical weighted rates.
        """
        calendar = calendar or calendar_from_name(terms.holiday_calendar)
        periods = ScheduleBuilder(calendar).build(
            terms.start_date, terms.maturity_date, terms.frequency_months,
            business_day_convention=terms.business_day_convention,
            accrual_date_basis=terms.accrual_date_basis,
            fixing_lag_business_days=terms.fixing_lag_business_days,
            payment_lag_business_days=terms.payment_lag_business_days,
            end_of_month=terms.end_of_month, stub_convention=terms.stub_convention,
            first_payment_date=terms.first_payment_date,
            last_regular_payment_date=terms.last_regular_payment_date,
        )
        return cls(terms, periods, calendar, provider)

    def _level(self, lookup: date) -> Decimal:
        """Latest absolute level at an already policy-selected calendar date."""
        index = bisect_right(self.step_dates, lookup) - 1
        if index >= 0:
            return self.step_values[index]
        return self.terms.fixed_rate if self.terms.coupon_type is CouponType.FIXED else self.terms.spread_bps

    def _lookup_date(self, as_of: date) -> date:
        """Resolve current entitlement using original starts, not cash dates."""
        require_date(as_of, "coupon entitlement as_of")
        policy = self.terms.coupon_step_policy
        starts = (self.starts if policy is CouponStepPolicy.RESET_START else
                  self.payment_starts if policy is CouponStepPolicy.PAYMENT_START else ())
        if starts:
            index = bisect_right(starts, as_of) - 1
            # Before the first adjusted boundary, no deferred step has taken
            # effect. In a long holiday gap, looking up as_of would otherwise
            # apply a step before the first actual accrual/reset has begun.
            return starts[index] if index >= 0 else min(as_of, self.terms.start_date)
        return as_of

    def active_spread_bps(self, as_of: date) -> Decimal:
        """Raw floating margin currently effective; bounds do not alter WAS."""
        if self.terms.coupon_type is not CouponType.FLOATING:
            raise InputValidationError("A fixed loan has no floating spread entitlement")
        return self._level(self._lookup_date(as_of))

    def active_fixed_rate(self, as_of: date) -> Decimal:
        """Fixed annual coupon currently effective, separate from period display."""
        if self.terms.coupon_type is not CouponType.FIXED:
            raise InputValidationError("A floating loan has no fixed coupon entitlement")
        return self._level(self._lookup_date(as_of))

    def effective_change_dates(self) -> tuple[date, ...]:
        """Return actual raw-coupon changes for independent quality monitoring.

        Deferred replacements become effective on the original payment/reset
        starts, using exactly the same lookup as cash entitlement. Several
        input steps between two boundaries may cancel each other; such a
        boundary adds no observation. Steps after the final start never affect
        that deferred contract. Resolving this calendar fetches no fixing and
        never creates a payment, reset or waterfall distribution.
        """
        if self.terms.coupon_step_policy is CouponStepPolicy.ACTUAL_DATE:
            return self.change_dates
        starts = (self.starts if self.terms.coupon_step_policy is CouponStepPolicy.RESET_START
                  else self.payment_starts)
        previous = (self.terms.fixed_rate if self.terms.coupon_type is CouponType.FIXED
                    else self.terms.spread_bps)
        changes = []
        for start in starts:
            level = self._level(start)
            if level != previous:
                changes.append(start)
            previous = level
        return tuple(changes)

    def layout(self, period: AccrualPeriod) -> tuple[tuple[date, date, date | None, date | None], ...]:
        """Intersect payment, original resets and actual-date level changes.

        A margin step retains the reference reset and fixing. Deferred policies
        add no intra-reset/period dates. Same-date reset and step make one
        boundary; each interval is start-inclusive and end-exclusive.
        """
        if self.terms.coupon_type is CouponType.FIXED:
            base = ((period.accrual_start, period.accrual_end, None, None),)
        elif self.is_overnight:
            original_start = self.starts[max(0, bisect_right(self.starts, period.accrual_start) - 1)]
            # The old forward-O/N contract observes the accrual interval, not a
            # lagged term fixing. Calendar fixing lag has no O/N meaning here.
            base = ((period.accrual_start, period.accrual_end, original_start, original_start),)
        else:
            base = self._reset_layout(period)
        if self.terms.coupon_step_policy is not CouponStepPolicy.ACTUAL_DATE or not self.change_dates:
            return base
        result = []
        for start, end, reset, fixing in base:
            first, last = bisect_right(self.change_dates, start), bisect_left(self.change_dates, end)
            boundaries = (start, *self.change_dates[first:last], end)
            result.extend((left, right, reset, fixing) for left, right in zip(boundaries, boundaries[1:]))
        return tuple(result)

    def _reset_layout(self, period: AccrualPeriod) -> tuple[tuple[date, date, date, date], ...]:
        """Bisect directly to the first overlapping original reference reset."""
        index = max(0, bisect_right(self.starts, period.accrual_start) - 1)
        result = []
        cursor = period.accrual_start
        while index < len(self.resets) and cursor < period.accrual_end:
            reset = self.resets[index]
            end = min(reset.accrual_end, period.accrual_end)
            if reset.accrual_start > cursor or end <= cursor:
                raise InputValidationError("Reset grid cannot cover payment accrual continuously")
            result.append((cursor, end, reset.accrual_start, reset.fixing_date))
            cursor, index = end, index + 1
        if cursor != period.accrual_end:
            raise InputValidationError("Reset grid does not reach payment accrual end")
        return tuple(result)

    def project(self, period: AccrualPeriod,
                frozen: tuple[CouponSegment, ...] | None = None) -> PeriodCoupon:
        """Freeze current observations or independently validate supplied ones."""
        if self.is_overnight:
            return self._project_overnight(period, frozen)
        layout = self.layout(period)
        if frozen is not None and (type(frozen) is not tuple or len(frozen) != len(layout)
                                  or any(not isinstance(s, CouponSegment) for s in frozen)):
            raise InputValidationError("Contractual coupon segments do not match reset grid")
        segments = []
        for number, (start, end, reset, fixing) in enumerate(layout):
            supplied = None if frozen is None else frozen[number]
            index = None
            spread = Decimal(0)
            if self.terms.coupon_type is CouponType.FIXED:
                # A seasoned first row clips accrual at as-of, while a deferred
                # fixed step still uses the ORIGINAL payment-period start.
                lookup = self._lookup_date(period.accrual_start) if self.terms.coupon_step_policy is CouponStepPolicy.PAYMENT_START else start
                rate = self._level(lookup)
            else:
                if supplied is not None:
                    index = require_decimal(supplied.index_rate, "frozen segment index rate")
                    if fixing in self.observations and self.observations[fixing] != index:
                        raise InputValidationError("Repeated fixing has inconsistent frozen index observations")
                elif fixing in self.observations:
                    index = self.observations[fixing]
                else:
                    if self.provider is None:
                        raise InputValidationError("Missing frozen reset observation")
                    index = require_decimal(self.provider.rate(self.terms.rate_index, fixing), "index rate")
                self.observations[fixing] = index
                lookup = reset if self.terms.coupon_step_policy is CouponStepPolicy.RESET_START else start
                spread = self._level(lookup)
                rate = compose_floating_rate(index, spread, self.terms.index_floor,
                    index_cap=self.terms.index_cap, all_in_floor=self.terms.all_in_floor,
                    all_in_cap=self.terms.all_in_cap)
            segment = CouponSegment(start, end, reset, fixing, index, spread, rate)
            if supplied is not None and supplied != segment:
                raise InputValidationError("Contractual coupon segment dates/rate differ from supplied terms")
            segments.append(segment)
        segments = tuple(segments)
        dcf = accrual_fraction(period.accrual_start, period.accrual_end, self.terms.day_count)
        factor = segment_factor(segments, self.terms.day_count)
        # Preserve every finite digit on the unchanged single-reset path.
        # Weighted display rates have 34 digits and never feed monetary math.
        rate = segments[0].all_in_rate if len(segments) == 1 else decimal_fraction(factor / dcf)
        index = None if self.terms.coupon_type is CouponType.FIXED else (
            segments[0].index_rate if len(segments) == 1 else decimal_fraction(sum((
                Fraction(s.index_rate) * accrual_fraction(s.accrual_start, s.accrual_end, self.terms.day_count)
                for s in segments), Fraction()) / dcf))
        # Spread is a quoted-margin diagnostic, not a cash factor. Normalize
        # by summed segment weights: non-additive day counts must not change a
        # constant quoted margin just because two original resets overlap cash.
        spread = segments[0].spread_bps if all(s.spread_bps == segments[0].spread_bps for s in segments) else decimal_fraction(sum((
            Fraction(s.spread_bps) * accrual_fraction(s.accrual_start, s.accrual_end, self.terms.day_count)
            for s in segments), Fraction()) / sum((accrual_fraction(s.accrual_start, s.accrual_end, self.terms.day_count)
                                                  for s in segments), Fraction()))
        return PeriodCoupon(segments, dcf, factor, index, segments[0].fixing_date, rate, spread)

    @staticmethod
    def _bounded_fraction(value: Fraction, floor: Decimal | None, cap: Decimal | None) -> Fraction:
        """Apply contractual annual bounds before any display-rate conversion."""
        if floor is not None:
            value = max(value, Fraction(floor))
        return value if cap is None else min(value, Fraction(cap))

    def _project_overnight(self, period: AccrualPeriod,
                           frozen: tuple[CouponSegment, ...] | None) -> PeriodCoupon:
        """Project one O/N period from DF(start)/DF(end), plus simple margin.

        This reproduces the source generator's forward-compounded projection,
        not a realized RFR observation engine. Reference bounds act on the
        period-equivalent annual rate; all-in bounds act after margin. Frozen
        exact factors permit credit replay without feeding a 34-digit display
        rate back into currency math. A partial replay prorates the frozen
        equivalent period factor by exact DCF; it does not claim that an
        unexpected exit realizes the original curve's shorter DF ratio.

        ACTUAL_DATE margin steps add exact simple spread slices while retaining
        the one compounded reference factor. RESET_START defers steps to the
        original payment-period start, matching the source O/N convention.
        """
        terms = self.terms
        layout = self.layout(period)
        dcf = accrual_fraction(period.accrual_start, period.accrual_end, terms.day_count)
        if frozen is not None:
            if (type(frozen) is not tuple or len(frozen) != len(layout)
                    or any(not isinstance(s, CouponSegment) or s.exact_index_factor is None for s in frozen)):
                raise InputValidationError("Projected overnight replay requires original exact frozen factors")
            raw_factor = sum((s.exact_index_factor for s in frozen), Fraction())
        else:
            accumulation = getattr(self.provider, "accumulation_factor", None)
            if not callable(accumulation):
                raise InputValidationError("Projected overnight asset coupons require an explicit discount-factor curve provider")
            raw_factor = accumulation(terms.rate_index, period.accrual_start, period.accrual_end, terms.day_count)
            if not isinstance(raw_factor, Fraction):
                raise InputValidationError("Projected overnight provider must return an exact Fraction factor")
        raw_annual = raw_factor / dcf
        bounded_index = self._bounded_fraction(raw_annual, terms.index_floor, terms.index_cap)
        segments = []
        for number, (start, end, reset, fixing) in enumerate(layout):
            part_dcf = accrual_fraction(start, end, terms.day_count)
            lookup = reset if terms.coupon_step_policy is CouponStepPolicy.RESET_START else start
            spread = self._level(lookup)
            all_in = self._bounded_fraction(bounded_index + Fraction(basis_points_rate(spread)),
                                            terms.all_in_floor, terms.all_in_cap)
            segment = CouponSegment(start, end, reset, fixing, decimal_fraction(raw_annual), spread,
                decimal_fraction(all_in), all_in * part_dcf, raw_annual * part_dcf)
            if frozen is not None and frozen[number] != segment:
                raise InputValidationError("Projected overnight frozen factor differs from contractual dates/margin/bounds")
            segments.append(segment)
        segments = tuple(segments)
        factor = segment_factor(segments, terms.day_count)
        weighted_spread = sum((Fraction(s.spread_bps) * accrual_fraction(s.accrual_start,
            s.accrual_end, terms.day_count) for s in segments), Fraction()) / dcf
        return PeriodCoupon(segments, dcf, factor, decimal_fraction(raw_annual),
            segments[0].fixing_date, decimal_fraction(factor / dcf), decimal_fraction(weighted_spread))
