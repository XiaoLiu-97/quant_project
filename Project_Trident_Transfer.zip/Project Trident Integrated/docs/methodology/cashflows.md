# 契约 cashflow 方法与迁移范围

更新：2026-10-06。契约生成器是独立可用的 Python 模块，也给 CLO 原池提供 frozen reference；default、prepayment、recovery、reinvestment、loan trading 和 waterfall 不混入合同现金流。详细现金/PIK与O/N规则见[native coupon migration](native_coupon_migration.md)，日期及day-count见[conventions](conventions.md)。

## 数据与执行顺序

`LoanTerms` 保存明确的合同anchor、原始摊还reference、coupon、calendar及principal策略；`LoanPosition` 保存as-of held face和opening entitlement。Date必须是calendar `date`，rates和amounts必须是finite `Decimal`。Binary float不能进入financial boundary。

```mermaid
flowchart TD
    A[Explicit contract and held opening face] --> V[Typed unit and parameter validation]
    V --> S[Original accrual and payment schedule]
    S --> H[Select as-of forward entitlements and verified opening claim]
    H --> R[Term resets or projected O/N DF factor]
    R --> C[Dated absolute coupon levels and reference/all-in bounds]
    C --> I[Exact gross coupon on interest-earning opening face]
    I --> K[Cash and explicit PIK split with one cent allocation]
    K --> P[Principal policy on original schedule index]
    P --> F[Final capitalized PIK redeemed in enlarged principal]
    F --> B[Cash and par conservation with frozen audit metadata]
    B --> O[Independent contract output or CLO reference]
```

原始contract schedule建立一次，reset grid和effective coupon levels通过bisect选取，不逐日暴力枚举。Fixed与EURIBOR simple accrual使用exact Fraction DCF；O/N使用50-digit DF数值转换为exact Fraction earnings factor；所有coupon先累计经济因子，最后按贷款和付款边界post cents。Displayed年化rate、DCF、unroundedamount是audit，不能成为新的financial inputs。

## Schedule、calendar与payment lag

支付频率为1/3/6/12个月；term EURIBOR reset为1/3/6个月，可与payment频率不同。Payment与reference reset频率相同时复用payment grid；独立reset grid保留原合同start anchor。当前独立reset profile使用SHORT_LAST，而非任意resetstub/anchor配置。

支持Short First、Long First、Short Last、Long Last及None stubs；显式first_payment_date和last_regular_payment_date是contractual nominal anchors。None必须与频率严格对齐，first/last anchors必须形成合法严格递增时间轴；非法日期不会通过默默丢弃某period来“修复”。Bespoke本金日期是unadjusted accrual boundary，不是在cashdate重新识别。End-of-month、Adjusted/Unadjusted accrual basis、fixing lag和payment lag均独立。

Named market calendar支持TARGET、WEEKENDS_ONLY、LONDON、NEW_YORK、TOKYO、SYDNEY、TORONTO、ZURICH。Regional范围与holidayprofile需核对[calendar说明](regional_calendars.md)；calendar并不自动知道每份合同的金融中心组合。显式APIcalendar可以携带extra holidays，并优先于合同中的namedcalendar。Payment date在BDC调整之后再应用business-day lag；standalone amortizing契约已允许非零lag。

Principal和PIK的contract accrual boundary与actual receipt date分开。Contract下一期的interest-earning face使用已发生的scheduled reduction和PIK；CLO collateral/receivable桥接分别记录资本化与实际收款，不用lag天数额外计贷款coupon。Ended-but-unpaid seasoned opening仍需要explicit receivable state，不能只凭openingface恢复。

## Fixed、term EURIBOR与projected O/N

Fixed coupon按明确的绝对annualrate accrual；EURIBOR_1M/3M/6M按原reset/fixing、floor/cap及margin计算，每段固定rate和exactDCF在原paymentperiod内求和。历史fixing必须是实际carried observation，curve projection不能伪装成已观测历史。

ESTR / SOFR / SONIA使用currency-matched projected DF forward，分别为EUR/USD/GBP。`reference_factor=DF(start)/DF(end)-1`，reference bounds作用于period-equivalentannualrate，再加simplemargin及all-in bounds。Margin不进入dailycompounding；当前profile没有realizeddailyfixings、lookback、lockout或observationshift。旧生成器仅支持这种projectedO/N方式；它已迁移到assetcoupon，独立于cash-account remuneration。

Cash / PIK / Mixed与Fixed / Floating是独立维度。NativePIK在边界增加loanface；末期先资本化再偿还enlargedface，PIK不再额外加到cashinterest。明确比例、centresidual、seasonedopening和partial-creditassumption见[nativecoupon方法](native_coupon_migration.md)。

## Principal策略

| 策略 | 规则 | 关键限制 |
| --- | --- | --- |
| BULLET | 原finalperiod偿还remainingface；PIK包括当前capitalization | 无隐含mid-period本金event |
| LINEAR_INITIAL_PAR | 明确referenceface×每期fraction | 不是grownPIKface比例；fraction>0 |
| LINEAR_AMOUNT | 明确固定currency金额 | 可指定amortizationstart和balloon；到期规则显式 |
| LINEAR_AUTO | heldopening减balloon，在eligiblepayments等额校准 | 非历史合同payment重建；seasoned自动recast拒绝 |
| ACCELERATED | baseamount×(1+growth)^ordinal | growth为每期fraction；原base按eligibility增长 |
| ACCELERATED_AUTO | exactgeometricseries校准base，使原face减balloon覆盖eligiblepayments | 支持growth=0的linear极限；numericbudget显式 |
| ANNUITY | 完整projectedfactors解levelP&I；principal=postedpayment−postedcashcoupon | Cash-only、explicitballoon；negativeamortization拒绝 |
| BESPOKE | 按unadjustedperiodboundary读取明确centamount | 日期唯一递增，含maturity，sum等于heldopeningface；可指定amortstart和balloonfloor，已填金额必须与两者一致；不得隐含off-cyclepayment |

Cash-only projected annuity设`q_t=annualcoupon_t×DCF_t`、`d_t=product(1+q_i)^(-1)`：

`level_payment=(openingface−balloon×d_n)/sum(d_t)`。

公式是O(n) exact递推，不用rootsearch。Grace期coupon单独cash-paid；finalpayment额外清偿balloon和roundingresidual。Fixedequalperiodfactor归约为标准PMT；可交叉核对[Microsoft PMT](https://support.microsoft.com/en-us/office/pmt-function-0214da64-9a63-4996-bc20-214433fa6441)。这不是floatingloan的legalrecast rule。Negativeprincipal、unexpectedearlyretirement或invalidballoon明确拒绝。PIKannuity是旧生成器明确不支持的组合，仍不自行假设。

## Coupon steps与bounds

Steps是absolute replacement levels，不能当increment叠加。ACTUAL_DATE按真实生效日期切段；固定PAYMENT_START只在原paymentstart生效，floatingRESET_START只在原resetstart生效。输入日期不因holiday调整。非additive30/360规则不允许ACTUAL_DATE拆分，以免两个subperiodDCF合计与整period不同。

Zero floor/cap有效；None才表示absent。Referencefloor/cap在加margin前，all-infloor/cap在margin后；每个collar的floor不得大于cap。Fixed合同没有floatingreferencebounds。Couponstep不会refi、修改principal日期、移动settlement或重新观测termfixing。

## Opening、credit和分析的界限

Seasonedcashopening保留originalschedule和actualcarriedfixings；FULL、POST_ASOF_ONLY、EXPLICIT_CASH_CLAIM分别表示全currentperiodownership、仅as-of之后entitlement和来源明确的cashclaim。Funding的acquiredaccruedcost和ownershipclaim不是同一个金额；claim只加入firstfuturecoupon一次。

已capitalizedhistoricalPIK包含在heldface；futurePIK不由history推测。Explicitdatedcredit采用独立cash/performing/defaulted/lossledgers，当前要求paymentlag0；legacyannualCDR/CPR已支持nativePIK，并通过独立sourceledger支持PIK+lag组合。实际trade/receivable/rightassignment和unknownhistoricalPIK仍需explicit state。见[credit方法](credit.md)。

完整contractprojection不保证agencyratingfactor、所有legalqualitytests或funded-principalWALavailable。CapitalizedPIK redemption可高于openingfundedface；WAL在缺少明确capitalizedcouponallocation时保留INCOMPLETE/UNAVAILABLE，不伪造普通principal-WAL。

## 验证路径

Financialexpectedanswers来自handcalculation和明确references，不把旧VBA输出普遍当oracle。`test_cashflows*`覆盖stub、scheduleanchors、principal、annuity、growth、seasoned、reset和step；`test_native_coupon_migration`覆盖nativePIK/Mixed、maturityclassification、O/Nfactor及centties；`test_native_pik_credit`覆盖信用、proportionaloverlay、source-dateCPR及unifiedAPIcash/par/monitoring桥接。Invalid组合对应显式异常测试，不能用成功保存Excel代替financial验收。
