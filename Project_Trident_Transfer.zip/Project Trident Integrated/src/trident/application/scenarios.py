"""Independent closing what-if runs with a shared, immutable economic baseline.

Every scenario replaces explicit closing inputs and reruns the same cashflow,
funding, portfolio and CLO services. It is not an effective-dated trade engine:
no acquisitions, disposals, defaults, calls or market-curve edits are inferred.
Money is EUR cents; price is percent of par, spread is basis points, and rates
and coverage thresholds are decimal fractions. Unavailable results never gain
an assumed zero for comparison.
"""

from dataclasses import dataclass, replace
from datetime import date
from decimal import Context, Decimal, ROUND_HALF_EVEN, localcontext
from enum import Enum
from fractions import Fraction
from types import MappingProxyType
from typing import Mapping

from trident.analysis import LimitStatus
from trident.cashflows.seasoned import resize_seasoned_state
from trident.clo.models import CoverageStatus, PrincipalRepaymentMode, InterestDiversionMode, ManagementFeeBasis
from trident.conventions import DayCount
from trident.domain.models import (
    CouponType, InputValidationError, OpeningCouponEntitlement, PrincipalScheduleEntry,
    require_date, require_decimal, require_money,
)
from trident.domain.numeric import post_currency

from .clo_services import TridentModelRequest, TridentModelResult, TridentModelService, ModelProjectionRunner


class ScenarioTarget(str, Enum):
    ASSET = "ASSET"
    NOTE = "NOTE"
    CONTROL = "CONTROL"


# Public transport metadata, not a second set of financial domain validators.
# Optional decimal permits an explicit None to remove a floor/coverage gate.
SCENARIO_FIELD_TYPES: Mapping[ScenarioTarget, Mapping[str, str]] = MappingProxyType({
    ScenarioTarget.ASSET: MappingProxyType({
        "par": "decimal", "clean_price_pct": "decimal", "spread_bps": "decimal",
        "fixed_rate": "decimal", "maturity_date": "date", "index_floor": "optional_decimal",
        "index_cap": "optional_decimal", "all_in_floor": "optional_decimal", "all_in_cap": "optional_decimal",
    }),
    ScenarioTarget.NOTE: MappingProxyType({
        "par": "decimal", "issue_price_pct": "decimal", "spread_bps": "decimal",
        "fixed_rate": "decimal", "oc_minimum": "optional_decimal",
        "ic_minimum": "optional_decimal", "index_floor": "optional_decimal",
    }),
    ScenarioTarget.CONTROL: MappingProxyType({
        "upfront_fees": "decimal", "cash_reserve": "decimal",
        "senior_management_fee_bps": "decimal", "subordinated_management_fee_bps": "decimal",
        "annual_senior_expenses": "decimal", "legal_final_date": "date",
        "other_initial_uses": "decimal", "other_initial_sources": "decimal",
        "arrangement_fee_base": "decimal", "arrangement_fee_rate": "decimal",
        "coverage_tests_enabled": "boolean", "interest_diversion_enabled": "boolean",
        "include_principal_cash_in_oc": "boolean", "principal_repayment_mode": "text",
        "interest_diversion_mode": "text", "management_fee_basis": "text",
        "management_fee_day_count": "text", "senior_expenses_day_count": "text",
        "variable_senior_expenses_bps": "decimal", "senior_expense_cap_bps": "decimal",
        "annual_senior_expense_cap": "optional_decimal", "first_stub_rate_override": "optional_decimal",
        "forward_equity_value": "decimal", "equity_value_source": "text",
    }),
})


def _identifier(value: object, label: str) -> None:
    if not isinstance(value, str) or not value or value != value.strip():
        raise InputValidationError(f"{label} must be a nonempty, unpadded string")


@dataclass(frozen=True)
class ScenarioEdit:
    """One absolute replacement, never a relative bump or implicit transaction.

    CONTROL uses identifier DEAL. A par edit resizes an asset's opening par,
    amortisation reference, absolute principal/balloon amounts and acquired
    accrued settlement cost proportionately, with HALF_UP cent posting. A
    retained FULL_CURRENT_PERIOD coupon claim scales from its exact original
    accrual before posting; it never scales an already rounded cent component.
    Bespoke dates
    remain unchanged: amounts use largest remainders, ties in date order, so
    their total is exactly the new held par. This is holding resizing, not a new
    amortisation contract or an effective-dated purchase.
    """

    target: ScenarioTarget
    identifier: str
    field: str
    value: Decimal | date | str | bool | None

    def __post_init__(self) -> None:
        if not isinstance(self.target, ScenarioTarget):
            raise InputValidationError("Scenario target must be ScenarioTarget")
        _identifier(self.identifier, "Scenario edit identifier")
        _identifier(self.field, "Scenario edit field")
        if self.target is ScenarioTarget.CONTROL and self.identifier != "DEAL":
            raise InputValidationError("CONTROL edits require identifier DEAL")
        kind = SCENARIO_FIELD_TYPES[self.target].get(self.field)
        if kind is None:
            raise InputValidationError(f"Unsupported {self.target.value} scenario field: {self.field}")
        if kind == "date":
            require_date(self.value, f"Scenario {self.field}")
        elif kind == "boolean":
            if type(self.value) is not bool:
                raise InputValidationError(f"Scenario {self.field} must be boolean")
        elif kind == "text":
            _identifier(self.value, f"Scenario {self.field}")
        elif not (kind == "optional_decimal" and self.value is None):
            require_decimal(self.value, f"Scenario {self.field}")


@dataclass(frozen=True)
class ScenarioDefinition:
    """Named scenario whose edits all apply to the original baseline snapshot."""

    scenario_id: str
    edits: tuple[ScenarioEdit, ...] = ()

    def __post_init__(self) -> None:
        _identifier(self.scenario_id, "scenario_id")
        if self.scenario_id.casefold() == "baseline":
            raise InputValidationError("Scenario name BASELINE is reserved")
        if not isinstance(self.edits, tuple) or any(not isinstance(edit, ScenarioEdit) for edit in self.edits):
            raise InputValidationError("Scenario edits must be an immutable tuple of ScenarioEdit")
        keys = {(edit.target, edit.identifier, edit.field) for edit in self.edits}
        if len(keys) != len(self.edits):
            raise InputValidationError(f"Duplicate edit in scenario {self.scenario_id}")


class ScenarioExecutionError(InputValidationError):
    """A named scenario failed; the batch returns no partial economic result."""

    def __init__(self, scenario_id: str, reason: str) -> None:
        self.scenario_id = scenario_id
        super().__init__(f"Scenario {scenario_id}: {reason}")


@dataclass(frozen=True)
class ScenarioMetricComparison:
    """Flat status-aware model, opening-portfolio or note comparison."""

    scenario_id: str
    scope: str
    metric: str
    identifier: str | None
    unit: str
    baseline_value: Decimal | None
    scenario_value: Decimal | None
    delta: Decimal | None
    baseline_status: str
    scenario_status: str
    delta_status: str
    message: str = ""


@dataclass(frozen=True)
class ScenarioPeriodComparison:
    """Dates are outer joined; absent periods never acquire zero collections."""

    scenario_id: str
    payment_date: date
    class_id: str | None
    metric: str
    unit: str
    baseline_value: Decimal | None
    scenario_value: Decimal | None
    delta: Decimal | None
    baseline_status: str
    scenario_status: str
    delta_status: str
    message: str = ""


@dataclass(frozen=True)
class ScenarioResult:
    scenario_id: str
    request: TridentModelRequest
    result: TridentModelResult
    comparisons: tuple[ScenarioMetricComparison, ...]
    period_comparisons: tuple[ScenarioPeriodComparison, ...]


@dataclass(frozen=True)
class ScenarioBatchResult:
    baseline: TridentModelResult
    scenarios: tuple[ScenarioResult, ...]


def _delta(left: Decimal | None, right: Decimal | None, left_status: str, right_status: str) -> tuple[Decimal | None, str]:
    """Subtract displayed observations exactly, independent of caller context."""
    if left_status != "AVAILABLE" or right_status != "AVAILABLE" or left is None or right is None:
        return None, "UNAVAILABLE"
    # Decimal operands are finite; enough digits retain their complete aligned
    # coefficients, including monetary cents and tiny changes in annual IRR.
    precision = max(34, max(left.adjusted(), right.adjusted()) - min(left.as_tuple().exponent, right.as_tuple().exponent) + 3)
    with localcontext(Context(prec=precision, rounding=ROUND_HALF_EVEN)):
        return right - left, "AVAILABLE"


def resize_principal_schedule(schedule: tuple[PrincipalScheduleEntry, ...], ratio: Fraction,
                     new_par: Decimal) -> tuple[PrincipalScheduleEntry, ...]:
    """Allocate fractional cents without moving dates or inventing principal.

    The original complete dated schedule sums to held par. Flooring its resized
    amounts leaves fewer than N cents; assign those to the largest fractional
    remainders with stable earlier-date tie breaking. Complexity is O(N log N),
    and no combinations of schedule amounts are enumerated.
    """
    if not schedule:
        return ()
    exact_cents = tuple(Fraction(row.amount) * ratio * 100 for row in schedule)
    cents = [amount.numerator // amount.denominator for amount in exact_cents]
    residual = int(Fraction(new_par) * 100) - sum(cents)
    if not 0 <= residual < len(schedule):
        raise InputValidationError("Cannot resize an unreconciled bespoke principal schedule")
    order = sorted(range(len(schedule)), key=lambda index: (-(exact_cents[index] - cents[index]), index))
    for index in order[:residual]:
        cents[index] += 1
    resized = tuple(replace(row, amount=post_currency(Fraction(amount, 100))) for row, amount in zip(schedule, cents, strict=True))
    if sum((Fraction(row.amount) for row in resized), Fraction()) != Fraction(new_par):
        raise ArithmeticError("Resized bespoke schedule does not conserve held par")
    return resized


def _apply_edits(baseline: TridentModelRequest, scenario: ScenarioDefinition) -> TridentModelRequest:
    """Replace local copies and synchronize each economic identity once."""
    if baseline.clo_opening_state is not None:
        raise InputValidationError('Closing scenario edits cannot alter an existing CLO opening snapshot')
    if baseline.coupon_proceeds_allocations:
        raise InputValidationError('Closing scenario edits require refreshed receipt-specific coupon proceeds instructions; automatic rebinding is unsupported')
    cash = baseline.cashflow_request
    positions = {row.terms.loan_id: row for row in cash.positions}
    exposures = {row.loan_id: row for row in baseline.exposures}
    purchases = {row.loan_id: row for row in cash.purchases}
    notes = {row.class_id: row for row in baseline.notes}
    issues = {row.class_id: row for row in cash.issues}
    terms = baseline.clo_terms
    cash_changes: dict[str, object] = {}
    budget_changes: dict[str, object] = {}
    # A collar is one contractual condition. Validate its final pair once,
    # rather than rejecting a valid simultaneous change because the first
    # edited endpoint temporarily crosses the old opposite endpoint.
    coupon_bounds: dict[str, dict[str, object]] = {}
    for edit in scenario.edits:
        field, value, key = edit.field, edit.value, edit.identifier
        if edit.target is ScenarioTarget.ASSET:
            if baseline.imported_collateral is not None and field != "clean_price_pct":
                raise InputValidationError(
                    "Asset contract/holding what-if requires a refreshed imported cashflow/par source; "
                    "only clean_price_pct can change closing cost while preserving the supplied imported entitlement"
                )
            if key not in positions or key not in exposures or key not in purchases:
                raise InputValidationError(f"Unknown or unreconciled asset identifier: {key}")
            position, exposure, purchase = positions[key], exposures[key], purchases[key]
            # A FULL_CURRENT_PERIOD opening claim is evidence of an existing
            # contractual period, not a hypothetical rate generated at closing.
            # Retroactively replacing its rate, bounds or schedule can alter the
            # exact earned prefix even when both prefixes round to the same cent.
            # Price and independent slice resizing preserve that source history;
            # future contractual changes require explicit dated coupon steps.
            if (position.seasoned_state is not None
                    and position.seasoned_state.entitlement_policy is OpeningCouponEntitlement.FULL_CURRENT_PERIOD
                    and field not in {"par", "clean_price_pct"}):
                raise InputValidationError(
                    f"Asset {key}: seasoned FULL_CURRENT_PERIOD what-if cannot replace historical "
                    "rate, bounds or schedule; preserve the original contract and use verified future dated coupon steps"
                )
            if field == "par":
                require_money(value, "Scenario asset par", positive=True)
                ratio = Fraction(value) / Fraction(position.opening_balance)
                contract = position.terms
                amount_changes = {name: post_currency(Fraction(getattr(contract, name)) * ratio)
                                  for name in ("reference_principal", "scheduled_principal_amount", "balloon_amount")
                                  if getattr(contract, name) is not None}
                amount_changes["principal_schedule"] = resize_principal_schedule(contract.principal_schedule, ratio, value)
                # Historical coupon entitlement scales independently of the
                # clean purchase price and accrued settlement cost. Preserve
                # the actual original fixing observations in the target slice.
                state = resize_seasoned_state(position, ratio)
                positions[key] = replace(position, opening_balance=value,
                    terms=replace(contract, **amount_changes), seasoned_state=state)
                exposures[key] = replace(exposure, par=value)
                purchases[key] = replace(purchase, par=value, accrued_interest=post_currency(Fraction(purchase.accrued_interest) * ratio))
            elif field == "clean_price_pct":
                purchases[key] = replace(purchase, clean_price_pct=value)
            else:
                if field in {"spread_bps", "index_floor", "index_cap", "all_in_floor", "all_in_cap"} and position.terms.coupon_type is not CouponType.FLOATING:
                    raise InputValidationError(f"Asset {key}: {field} requires a floating coupon")
                if field == "fixed_rate" and position.terms.coupon_type is not CouponType.FIXED:
                    raise InputValidationError(f"Asset {key}: fixed_rate requires a fixed coupon")
                if field in {"index_floor", "index_cap", "all_in_floor", "all_in_cap"}:
                    coupon_bounds.setdefault(key, {})[field] = value
                    continue
                positions[key] = replace(position, terms=replace(position.terms, **{field: value}))
                if field in {"spread_bps", "maturity_date"}:
                    exposures[key] = replace(exposure, **{field: value})
                elif field == "fixed_rate":
                    exposures[key] = replace(exposure, coupon_type=CouponType.FIXED,
                                             fixed_coupon_rate=value)
        elif edit.target is ScenarioTarget.NOTE:
            if key not in notes or key not in issues:
                raise InputValidationError(f"Unknown or unreconciled note identifier: {key}")
            note, issue = notes[key], issues[key]
            if field == "par":
                notes[key] = replace(note, opening_balance=value)
                issues[key] = replace(issue, par=value)
            elif field == "issue_price_pct":
                issues[key] = replace(issue, issue_price_pct=value)
            else:
                if field in {"spread_bps", "index_floor"} and note.coupon_type is not CouponType.FLOATING:
                    raise InputValidationError(f"Note {key}: {field} requires a floating coupon")
                if field == "fixed_rate" and note.coupon_type is not CouponType.FIXED:
                    raise InputValidationError(f"Note {key}: fixed_rate requires a fixed coupon")
                notes[key] = replace(note, **{field: value})
        else:
            if field in {"forward_equity_value", "equity_value_source"}:
                raise InputValidationError("Forward equity valuation edits require an existing CLO opening scenario")
            elif field in {"upfront_fees", "cash_reserve", "other_initial_uses", "other_initial_sources"}:
                if field == "upfront_fees" and cash.closing_cost_budget is not None:
                    raise InputValidationError("upfront_fees edit requires AGGREGATE closing costs; edit arrangement fee terms in ITEMIZED mode")
                cash_changes[field] = value
                if field == "cash_reserve" and terms is not None:
                    terms = replace(terms, initial_reserve=value)
            elif field in {"arrangement_fee_base", "arrangement_fee_rate"}:
                if cash.closing_cost_budget is None:
                    raise InputValidationError(f"{field} edit requires an explicit ITEMIZED closing cost budget")
                budget_changes[field] = value
            else:
                if terms is None:
                    raise InputValidationError(f"{field} requires a CLO projection")
                enum_fields = {"principal_repayment_mode": PrincipalRepaymentMode,
                               "interest_diversion_mode": InterestDiversionMode, "management_fee_basis": ManagementFeeBasis,
                               "management_fee_day_count": DayCount, "senior_expenses_day_count": DayCount}
                terms = replace(terms, **{field: enum_fields[field](value) if field in enum_fields else value})
    for key, bounds in coupon_bounds.items():
        position = positions[key]
        positions[key] = replace(position, terms=replace(position.terms, **bounds))
    if budget_changes:
        cash_changes["closing_cost_budget"] = replace(cash.closing_cost_budget, **budget_changes)
    # OC discount treatment consumes the actual acquisition economics of the
    # same holding; a price what-if must not retain its old classification price.
    refreshed_oc_data = []
    for data in baseline.oc_asset_data:
        purchase = purchases.get(data.loan_id)
        if purchase is None:
            raise InputValidationError("OC classification refers to an unknown scenario holding")
        parts = purchase.clean_price_pct.as_tuple()
        clean_fraction = Decimal((parts.sign, parts.digits, parts.exponent - 2))
        refreshed_oc_data.append(replace(data, clean_price_fraction=clean_fraction))
    return replace(baseline, cashflow_request=replace(cash,
        positions=tuple(positions[row.terms.loan_id] for row in cash.positions),
        purchases=tuple(purchases[row.loan_id] for row in cash.purchases),
        issues=tuple(issues[row.class_id] for row in cash.issues), **cash_changes),
        exposures=tuple(exposures[row.loan_id] for row in baseline.exposures),
        notes=tuple(notes[row.class_id] for row in baseline.notes), clo_terms=terms,
        oc_asset_data=tuple(refreshed_oc_data))


def _model_observations(request: TridentModelRequest, result: TridentModelResult) -> dict[tuple[str, str, str | None], tuple[Decimal | None, str, str, str]]:
    """Observation tuple is value, availability, unit and explanatory message."""
    funding = result.cashflows.funding
    funding_fields = ("collateral_par", "asset_clean_cost", "acquired_accrued_interest", "upfront_fees", "cash_reserve", "debt_par", "debt_proceeds", "equity_cash_funding",
                      "arrangement_fee", "other_upfront_costs", "other_initial_uses", "other_initial_sources")
    if funding is not None:
        rows = {("MODEL", name.upper(), None): (getattr(funding, name), "AVAILABLE", "EUR", "")
                for name in funding_fields}
    else:
        # Existing holdings are not purchased or issued again. Current face,
        # physical reserve and the declared forward equity mark have an actual
        # opening basis; historical acquisition and issuance cash do not.
        rows = {("MODEL", name.upper(), None): (None, "NOT_APPLICABLE", "EUR",
                "Existing CLO opening has no new acquisition or issuance funding")
                for name in funding_fields}
        held = post_currency(sum((Fraction(row.opening_balance) for row in request.cashflow_request.positions), Fraction()))
        debt = post_currency(sum((Fraction(row.opening_balance) for row in request.notes), Fraction()))
        for name, value in (("COLLATERAL_PAR", held), ("DEBT_PAR", debt), ("CASH_RESERVE", request.clo_opening_state.reserve)):
            rows[("MODEL", name, None)] = (value, "AVAILABLE", "EUR", "Current sourced opening snapshot")
        rows[("MODEL", "FORWARD_EQUITY_VALUE", None)] = (request.forward_equity_value, "AVAILABLE", "EUR",
                "Forward return from declared current equity valuation; source: " + request.equity_value_source)
    rows[("MODEL", "ASSET_TOTAL_INTEREST", None)] = (result.cashflows.total_interest, "AVAILABLE", "EUR", "")
    for name, observation, unit in (("EQUITY_IRR", result.equity_irr, "annual_fraction"), ("EQUITY_MOIC", result.equity_moic, "multiple")):
        rows[("MODEL", name, None)] = (observation.value, observation.status.value, unit, observation.message)
    for metric in result.opening_portfolio.metrics:
        rows[("OPENING_METRIC", metric.name, None)] = (metric.value, metric.status.value, metric.unit, metric.message)
    breaches = sum(row.status is LimitStatus.BREACH for row in result.opening_portfolio.limits)
    rows[("MODEL", "OPENING_LIMIT_BREACH_COUNT", None)] = (Decimal(breaches), "AVAILABLE", "count", "Unavailable limits are reported separately and never counted as passes")
    unknown = sum(row.status is LimitStatus.UNAVAILABLE for row in result.opening_portfolio.limits)
    rows[("MODEL", "OPENING_LIMIT_UNAVAILABLE_COUNT", None)] = (Decimal(unknown), "AVAILABLE", "count", "")
    metric_units = {row.name: row.unit for row in result.opening_portfolio.metrics}
    for row in result.opening_portfolio.limits:
        status = "AVAILABLE" if row.headroom is not None else row.status.value
        unit = ("fraction" if row.metric.startswith("concentration:")
                else metric_units.get(row.metric, "unknown"))
        rows[("OPENING_LIMIT", "HEADROOM", row.limit_id)] = (row.headroom, status, unit, f"Limit status: {row.status.value}; {row.message}".rstrip("; "))
        rows[("OPENING_LIMIT", "STATUS", row.limit_id)] = (None, row.status.value, "status", row.message)
    for row in result.opening_portfolio.concentrations:
        # A missing descriptive bucket remains explicitly missing. It is not
        # silently folded into any compliant named obligor/country/sector.
        identifier = f"{row.dimension}:bucket={row.bucket}" if row.bucket is not None else f"{row.dimension}:missing"
        rows[("OPENING_CONCENTRATION", "PAR", identifier)] = (row.par, "AVAILABLE", "EUR", "")
        rows[("OPENING_CONCENTRATION", "FRACTION", identifier)] = (row.fraction, "AVAILABLE", "fraction", "")
    for note in request.notes:
        rows[("NOTE", "OPENING_PAR", note.class_id)] = (note.opening_balance, "AVAILABLE", "EUR", "")
    clo = result.clo
    rows[("MODEL", "CLO_STATUS", None)] = (None, clo.status.value if clo is not None else "NOT_SELECTED", "status", "")
    for name in ("total_equity_distributions", "final_debt_par", "final_collateral_par", "final_reserve"):
        rows[("MODEL", name.upper(), None)] = (getattr(clo, name) if clo is not None else None,
            "AVAILABLE" if clo is not None else "UNAVAILABLE", "EUR", "" if clo is not None else "CLO projection was not selected")
    for gate in ("oc", "ic"):
        failed = (sum(getattr(row, f"{gate}_status") is CoverageStatus.FAIL for row in clo.coverage_tests if row.stage == "GATE") if clo is not None else None)
        rows[("MODEL", f"{gate.upper()}_FAILED_GATE_COUNT", None)] = (Decimal(failed) if failed is not None else None,
            "AVAILABLE" if clo is not None else "UNAVAILABLE", "count", "Evaluated GATE rows only; blocked junior gates are not assumed passes")
    if clo is not None:
        for name in ("total_defaulted_exposure", "total_recovery_collections", "total_recognized_par_loss", "final_defaulted_par"):
            rows[("CREDIT", name.upper(), None)] = (getattr(clo, name) if clo is not None else None,
                "AVAILABLE" if clo is not None else "UNAVAILABLE", "EUR", "Through the CLO projection horizon only")
    return rows


def _period_observations(result: TridentModelResult) -> dict[tuple[date, str | None, str], tuple[Decimal | None, str, str, str]]:
    if result.clo is None:
        return {}
    observations = {}
    for row in result.clo.periods:
        names = ("received_asset_interest", "received_asset_principal", "closing_collateral_par", "closing_debt_par",
                     "note_coupon_due", "note_coupon_paid", "equity_from_interest", "equity_from_principal", "equity_from_reserve",
                     "senior_management_fee_paid", "subordinated_management_fee_paid", "reserve_closing")
        names += ("defaulted_par", "scheduled_principal_received", "prepayment_principal_received",
                  "recovery_principal_received", "newly_defaulted_par", "recognized_par_loss",
                  "interest_diversion_test_transferred", "interest_diversion_test_held_principal")
        for name in names:
            observations[(row.payment_date, None, name.upper())] = (getattr(row, name), "AVAILABLE", "EUR", "")
        idt_status = row.interest_diversion_test_status.value
        observations[(row.payment_date, None, "IDT_STATUS")] = (None, idt_status, "status", "")
        ratio = row.interest_diversion_test_oc_ratio
        observations[(row.payment_date, None, "IDT_OC_RATIO")] = (
            ratio, "AVAILABLE" if ratio is not None else idt_status, "ratio", "")
    # Per-class snapshots preserve all distinct coupon funding, arrears and
    # principal channels. Deal totals alone can hide a diverted junior coupon.
    for row in result.clo.tranche_periods:
        for name in ("opening_balance", "closing_balance", "opening_coupon_arrears", "current_coupon_due",
                     "coupon_paid_from_interest", "coupon_paid_from_principal", "closing_coupon_arrears",
                     "principal_from_interest", "principal_from_principal", "coupon_shortfall_interest",
                     "waived_coupon_shortfall"):
            observations[(row.payment_date, row.class_id, name.upper())] = (getattr(row, name), "AVAILABLE", "EUR", "")
        observations[(row.payment_date, row.class_id, "INTEREST_GATE_BLOCKED")] = (
            Decimal(int(row.interest_gate_blocked)), "AVAILABLE", "boolean", "")
        for name, unit in (("all_in_rate", "annual_fraction"), ("day_count_fraction", "fraction")):
            observations[(row.payment_date, row.class_id, name.upper())] = (getattr(row, name), "AVAILABLE", unit, "")
        observations[(row.payment_date, row.class_id, "INDEX_RATE")] = (
            row.index_rate, "AVAILABLE" if row.index_rate is not None else "NOT_APPLICABLE", "annual_fraction", "")
    for row in result.clo.coverage_tests:
        if row.stage != "GATE":
            continue
        for gate in ("oc", "ic"):
            ratio, minimum, status = getattr(row, f"{gate}_ratio"), getattr(row, f"{gate}_minimum"), getattr(row, f"{gate}_status")
            message = f"Coverage gate status: {status.value}"
            availability = "AVAILABLE" if ratio is not None else status.value
            observations[(row.payment_date, row.class_id, f"{gate.upper()}_GATE_STATUS")] = (None, status.value, "status", message)
            observations[(row.payment_date, row.class_id, f"{gate.upper()}_GATE_RATIO")] = (ratio, availability, "ratio", message)
            headroom, available = _delta(minimum, ratio, "AVAILABLE" if minimum is not None else "UNAVAILABLE", availability)
            observations[(row.payment_date, row.class_id, f"{gate.upper()}_GATE_HEADROOM")] = (headroom, available, "ratio", message)
    return observations


_MISSING = (None, "NOT_PRESENT", "", "Observation is absent from this projection")


def compare_model_results(scenario_id: str, baseline_request: TridentModelRequest, baseline: TridentModelResult,
             request: TridentModelRequest, result: TridentModelResult) -> tuple[tuple[ScenarioMetricComparison, ...], tuple[ScenarioPeriodComparison, ...]]:
    """Compare independently calculated pools using identities and actual dates.

    Shared by what-if and closing construction. Status-aware deltas retain
    missing/unavailable observations instead of treating them as numeric zero.
    This function reports evidence; it does not certify limits or performance.
    """
    left, right = _model_observations(baseline_request, baseline), _model_observations(request, result)
    comparisons = []
    for scope, metric, identifier in sorted(left.keys() | right.keys(), key=lambda key: (key[0], key[1], key[2] or "")):
        key = scope, metric, identifier
        a, b = left.get(key, _MISSING), right.get(key, _MISSING)
        delta, status = _delta(a[0], b[0], a[1], b[1])
        message = " | ".join(dict.fromkeys(text for text in (a[3], b[3]) if text))
        comparisons.append(ScenarioMetricComparison(scenario_id, scope, metric, identifier, a[2] or b[2], a[0], b[0], delta, a[1], b[1], status, message))
    left, right = _period_observations(baseline), _period_observations(result)
    periods = []
    for payment_date, class_id, metric in sorted(left.keys() | right.keys(), key=lambda key: (key[0], key[1] or "", key[2])):
        key = payment_date, class_id, metric
        a, b = left.get(key, _MISSING), right.get(key, _MISSING)
        delta, status = _delta(a[0], b[0], a[1], b[1])
        message = " | ".join(dict.fromkeys(text for text in (a[3], b[3]) if text))
        periods.append(ScenarioPeriodComparison(scenario_id, payment_date, class_id, metric, a[2] or b[2], a[0], b[0], delta, a[1], b[1], status, message))
    return tuple(comparisons), tuple(periods)


class ScenarioRunner:
    """Run baseline once, then independently rebuild and reprice each scenario.

    Validation or projection errors identify the failed scenario and abort the
    batch. Callers can therefore publish a complete result atomically instead
    of combining successful scenarios with stale or partial output tables.
    """

    def __init__(self, service: ModelProjectionRunner | None = None) -> None:
        self._service = service if service is not None else TridentModelService()

    def run(self, baseline: TridentModelRequest, scenarios: tuple[ScenarioDefinition, ...]) -> ScenarioBatchResult:
        """Validate all edits first, then compare each full run to one baseline.

        Requests are rebuilt immutably so a changed price, spread or capital
        stack cannot leak into another scenario. A failing case aborts the
        batch; the Excel adapter publishes only complete, consistent outputs.
        """
        if not isinstance(baseline, TridentModelRequest):
            raise TypeError("baseline must be TridentModelRequest")
        if not isinstance(scenarios, tuple) or any(not isinstance(row, ScenarioDefinition) for row in scenarios):
            raise InputValidationError("scenarios must be an immutable tuple of ScenarioDefinition")
        if len({row.scenario_id.casefold() for row in scenarios}) != len(scenarios):
            raise InputValidationError("Scenario names must be unique, ignoring case")
        requests = []
        for scenario in scenarios:
            try:
                requests.append(_apply_edits(baseline, scenario))
            except (ValueError, ArithmeticError) as exc:
                raise ScenarioExecutionError(scenario.scenario_id, str(exc)) from exc
        baseline_result = self._service.run(baseline)
        results = []
        for scenario, request in zip(scenarios, requests, strict=True):
            try:
                result = self._service.run(request)
                comparisons, periods = compare_model_results(scenario.scenario_id, baseline, baseline_result, request, result)
            except (ValueError, ArithmeticError) as exc:
                raise ScenarioExecutionError(scenario.scenario_id, str(exc)) from exc
            results.append(ScenarioResult(scenario.scenario_id, request, result, comparisons, periods))
        return ScenarioBatchResult(baseline_result, tuple(results))
