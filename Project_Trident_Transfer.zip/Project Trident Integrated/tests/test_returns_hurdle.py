"""Inclusive return mandates evaluated on actual investor cash, not root noise."""

from datetime import date
from decimal import Decimal, Inexact, localcontext
import unittest

from trident.analysis import AssetExposure, ReturnStatus, xnpv
from trident.application.clo_services import TridentModelRequest, TridentModelService
from trident.application.construction import FindingSeverity, _projection_findings
from trident.application.services import CashflowRunRequest
from trident.clo import CloTerms, NoteTranche
from trident.conventions import AccrualDateBasis, BusinessDayConvention, DayCount
from trident.domain.models import CouponType, InputValidationError, LoanPosition, LoanTerms
from trident.funding import AssetPurchase, DebtIssue
from trident.market import FlatRateProvider

D = Decimal


def exact_five_percent_model():
    start, end = date(2026, 1, 20), date(2027, 1, 20)
    loan = LoanPosition(LoanTerms("L", "EUR", start, end, D(100), CouponType.FIXED,
        frequency_months=12, fixed_rate=D(".025"), day_count=DayCount.THIRTY_E_360,
        business_day_convention=BusinessDayConvention.UNADJUSTED,
        accrual_date_basis=AccrualDateBasis.UNADJUSTED), start, D(100))
    cash = CashflowRunRequest((loan,), (AssetPurchase("L", D(100), D(100)),),
        (DebtIssue("A", D(50), D(100)),), FlatRateProvider({}), D(0), D(0), "SYNTHETIC_HAND_MODEL")
    exposure = AssetExposure("L", "O", "BSL", "TERM_LOAN", "GB", "S", "EUR", D(100), None, end)
    terms = CloTerms(start, end, frequency_months=12, business_day_convention=BusinessDayConvention.UNADJUSTED,
                     accrual_date_basis=AccrualDateBasis.UNADJUSTED)
    return TridentModelService().run(TridentModelRequest(cash, (exposure,), clo_terms=terms,
        notes=(NoteTranche("A", 1, D(50), CouponType.FIXED, fixed_rate=D(0)),)))


class MinimumIrrReviewTests(unittest.TestCase):
    def test_exact_inclusive_irr_boundary_does_not_breach_due_to_bisection(self):
        result = exact_five_percent_model()
        # 100 at par funded by50 zero-coupon debt and50 equity. Exact loan
        # annual30E coupon2.50 => equity52.50 after365days => exactly5% IRR.
        self.assertEqual([row.amount for row in result.equity_cashflows], [D(-50), D("2.50"), D(50)])
        self.assertEqual([row.payment_date for row in result.equity_cashflows[1:]], [date(2027, 1, 20)] * 2)
        self.assertIs(result.equity_irr.status, ReturnStatus.AVAILABLE)
        self.assertLess(abs(result.equity_irr.value - D(".05")), D("1e-12"))
        findings = _projection_findings(result, "TARGET", FindingSeverity.ERROR, D(".05"))
        self.assertFalse(any(row.code.startswith("MINIMUM_EQUITY_IRR") for row in findings))

    def test_threshold_just_above_exact_return_still_breaches_without_a_tolerance(self):
        result = exact_five_percent_model()
        for threshold, breaches in ((D(".05000000000000000001"), True),
                                    (D(".04999999999999999999"), False)):
            with self.subTest(threshold=threshold):
                findings = _projection_findings(result, "TARGET", FindingSeverity.ERROR, threshold)
                self.assertEqual(any(row.code == "MINIMUM_EQUITY_IRR_BREACH" for row in findings), breaches)

    def test_low_caller_precision_keeps_inclusive_mandate_decision(self):
        result = exact_five_percent_model()
        with localcontext() as context:
            context.prec = 2
            context.traps[Inexact] = True
            findings = _projection_findings(result, "TARGET", FindingSeverity.ERROR, D(".05"))
        self.assertFalse(any(row.code.startswith("MINIMUM_EQUITY_IRR") for row in findings))

    def test_out_of_range_minimum_discount_domain_is_named_unavailable_not_pass(self):
        result = exact_five_percent_model()
        threshold = D("1e1000000")
        with self.assertRaises(InputValidationError):
            xnpv(threshold, result.equity_cashflows)
        findings = _projection_findings(result, "TARGET", FindingSeverity.ERROR, threshold)
        self.assertTrue(any(row.code == "MINIMUM_EQUITY_IRR_UNAVAILABLE" and row.severity is FindingSeverity.ERROR
                            for row in findings))


if __name__ == "__main__":
    unittest.main()
