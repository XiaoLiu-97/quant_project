"""Contract-semantic validation of reused, internally balanced credit references."""

from dataclasses import replace
from datetime import date
from decimal import Decimal, Inexact, localcontext
import unittest

from trident.cashflows.engine import ContractualCashflowEngine
from trident.credit import CreditEventCashflowEngine, PrepaymentEvent
from trident.domain.models import CouponType, InputValidationError
from trident.market.rates import FlatRateProvider
from test_credit_events import held_loan

D = Decimal


class CreditReferenceReviewTests(unittest.TestCase):
    def setUp(self):
        self.provider = FlatRateProvider({"EURIBOR_3M": D("0.02")})
        self.engine = CreditEventCashflowEngine(self.provider)

    def test_balanced_coupon_cash_forgery_is_rejected(self):
        position = held_loan()
        rows = ContractualCashflowEngine(self.provider).generate(position)
        # Independent contract answer: 100 * 40% * 90/360 = 10. A forged 11
        # coupon still balances total_cash and all principal, but is not owed.
        bad = (replace(rows[0], cash_interest=D(11), total_cash=D(11)), *rows[1:])
        with self.assertRaisesRegex(InputValidationError, "exact rate/day-count"):
            self.engine.apply(position, bad)

    def test_balanced_early_bullet_repayment_is_not_a_contract_reference(self):
        position = held_loan()
        rows = ContractualCashflowEngine(self.provider).generate(position)
        bad = (replace(rows[0], principal_repayment=D(100), closing_balance=D(0), total_cash=D(110)),)
        with self.assertRaisesRegex(InputValidationError, "repayment policy"):
            self.engine.apply(position, bad)

    def test_fixed_rate_or_diagnostic_metadata_cannot_change_prepayment_economics(self):
        position = held_loan()
        rows = ContractualCashflowEngine(self.provider).generate(position)
        for changes in (
            {"all_in_rate": D("0.44"), "cash_interest": D(11), "interest_unrounded": D(11), "total_cash": D(11)},
            {"index_rate": D(0)}, {"fixing_date": date(2026, 1, 1)},
            {"spread_bps": D(1)}, {"day_count_fraction": D("0.3")},
            {"interest_unrounded": D(11)}, {"day_count_fraction": .25},
        ):
            with self.subTest(changes=changes), self.assertRaises(InputValidationError):
                self.engine.apply(position, (replace(rows[0], **changes), *rows[1:]),
                                  PrepaymentEvent("CREDIT_1", date(2026, 2, 15)))

    def test_floating_margin_floor_and_fixing_identity_are_validated_without_new_rate_queries(self):
        class CountingRates:
            def __init__(self):
                self.calls = 0
            def rate(self, index, fixing_date):
                self.calls += 1
                return D("0.02")
        provider = CountingRates()
        position = held_loan(coupon_type=CouponType.FLOATING, fixed_rate=None,
                             rate_index="EURIBOR_3M", spread_bps=D(300), index_floor=D("0.025"))
        rows = ContractualCashflowEngine(provider).generate(position)
        calls = provider.calls
        engine = CreditEventCashflowEngine(provider)
        result = engine.apply(position, rows)
        self.assertEqual(result.total_cash_interest, D("4.14"))  # Three 1.375 -> 1.38 coupons.
        self.assertEqual(provider.calls, calls)
        for changes in ({"fixing_date": date(2026, 1, 2)}, {"all_in_rate": D("0.05")},
                        {"index_rate": None}, {"spread_bps": D(301)}):
            with self.subTest(changes=changes), self.assertRaises(InputValidationError):
                engine.apply(position, (replace(rows[0], **changes), *rows[1:]))
        self.assertEqual(provider.calls, calls)

    def test_half_cent_and_caller_context_are_preserved(self):
        position = held_loan(reference_principal=D("0.02"), fixed_rate=D(1))
        rows = ContractualCashflowEngine(self.provider).generate(position)
        # .02 * 1 * .25 = .005 -> .01; reconstructing through a rounded DCF
        # must not move the contractual HALF_UP boundary.
        self.assertEqual(rows[0].cash_interest, D("0.01"))
        with localcontext() as context:
            context.prec = 2
            context.traps[Inexact] = True
            result = self.engine.apply(position, rows)
        self.assertEqual(result.total_cash_interest, D("0.03"))


if __name__ == "__main__":
    unittest.main()
