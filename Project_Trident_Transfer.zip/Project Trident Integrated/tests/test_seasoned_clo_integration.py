"""Independent hand controls for an opening held loan inside a new CLO.

The economic claim earned before the opening snapshot and the accrued price
paid to a seller are independent inputs. These tests use small cash ledgers to
make any double entitlement, restarted rate reset, or backdated note coupon
visible. They validate a closing redesign with seasoned collateral; they do
not initialize an existing CLO's historical debt, arrears, or cash accounts.
"""

import unittest
from dataclasses import replace
from datetime import date
from decimal import Decimal, Inexact, localcontext

from trident.analysis import AssetExposure, ReturnStatus
from trident.application.clo_services import TridentModelRequest, TridentModelService
from trident.application.services import CashflowRunRequest, CashflowRunService
from trident.clo.engine import DeterministicCloEngine
from trident.clo.lifecycle import AdjustedCollateralValuePolicy
from trident.clo.models import (
    CloRunRequest, CloTerms, DefaultedAssetOcTreatment, NoteTranche, ProjectionStatus,
)
from trident.conventions import AccrualDateBasis, BusinessDayConvention, DayCount
from trident.credit import DefaultEvent, PrepaymentEvent, RecoveryEvent
from trident.domain.models import (
    CouponStep, CouponType, InputValidationError, LoanPosition, LoanTerms,
    OpeningCouponEntitlement, OpeningFixing, SeasonedLoanState,
)
from trident.funding.engine import AssetPurchase, DebtIssue
from trident.market import FlatRateProvider


D = Decimal
START = date(2026, 1, 1)
OPEN = date(2026, 2, 1)
FIRST = date(2026, 4, 1)
SOURCE = "Independent signed opening entitlement control"


class RecordingRateProvider:
    """Return a deliberately different projected rate and record every call."""

    def __init__(self, projected=D("0.09")):
        self.projected = projected
        self.calls = []

    def rate(self, index, fixing_date):
        self.calls.append((index, fixing_date))
        return self.projected


def fixed_position(*, opening_claim=D("1.03"), start=START, maturity=FIRST,
                   coupon_steps=(), entitlement_policy=OpeningCouponEntitlement.FULL_CURRENT_PERIOD):
    terms = LoanTerms(
        "L", "EUR", start, maturity, D(100), CouponType.FIXED,
        fixed_rate=D("0.12"), day_count=DayCount.ACT_360,
        business_day_convention=BusinessDayConvention.UNADJUSTED,
        accrual_date_basis=AccrualDateBasis.UNADJUSTED,
        fixing_lag_business_days=0, coupon_steps=coupon_steps,
    )
    return LoanPosition(terms, OPEN, D(100), SeasonedLoanState(
        opening_claim, SOURCE, entitlement_policy=entitlement_policy))


def cashflow_request(position, *, purchase_accrued=D("1.03"), provider=None):
    return CashflowRunRequest(
        (position,), (AssetPurchase("L", D(100), D(100), purchase_accrued),),
        (DebtIssue("A", D(80), D(100)),),
        provider if provider is not None else FlatRateProvider({"EURIBOR_3M": D("0.09")}),
        D(0), D(0), "Explicit hand-control projection, no live market feed",
    )


def clo_request(position, *, purchase_accrued=D("1.03"), adjusted_oc=False,
                provider=None):
    loan = position.terms
    exposure = AssetExposure(
        "L", "Obligor", "BSL", "LOAN", "FR", "Industrial", "EUR", D(100),
        None if loan.coupon_type is CouponType.FIXED else loan.spread_bps,
        loan.maturity_date, coupon_type=loan.coupon_type,
        fixed_coupon_rate=loan.fixed_rate if loan.coupon_type is CouponType.FIXED else None,
    )
    terms = CloTerms(
        position.par_as_of_date, loan.maturity_date,
        business_day_convention=BusinessDayConvention.UNADJUSTED,
        accrual_date_basis=AccrualDateBasis.UNADJUSTED,
        fixing_lag_business_days=0,
        adjusted_oc_policy=AdjustedCollateralValuePolicy() if adjusted_oc else None,
    )
    note = NoteTranche("A", 1, D(80), CouponType.FIXED,
                       fixed_rate=D("0.06"), day_count=DayCount.ACT_360)
    return TridentModelRequest(
        cashflow_request(position, purchase_accrued=purchase_accrued, provider=provider),
        (exposure,), clo_terms=terms, notes=(note,),
    )


class SeasonedCloIntegrationTests(unittest.TestCase):
    def test_standalone_coupon_and_funding_retain_separate_claim_and_cost(self):
        result = CashflowRunService().run(cashflow_request(fixed_position()))
        self.assertEqual(result.projection_start_date, OPEN)
        self.assertEqual(len(result.cashflows), 1)
        row = result.cashflows[0]
        self.assertEqual((row.unadjusted_start, row.accrual_start), (START, OPEN))
        self.assertEqual((row.accrual_end, row.payment_date), (FIRST, FIRST))
        # Claim1.03 plus100*12%*59/360 rounds once to3.00. Funding buys
        # 100 clean plus1.03 accrued and borrows80, so equity pays21.03.
        self.assertEqual(row.opening_accrued_interest, D("1.03"))
        self.assertEqual(row.cash_interest, D("3.00"))
        self.assertEqual(row.principal_repayment, D(100))
        self.assertEqual(result.funding.acquired_accrued_interest, D("1.03"))
        self.assertEqual(result.funding.equity_cash_funding, D("21.03"))
        self.assertEqual(result.total_interest, D("3.00"))

    def test_clo_neither_adds_acquired_claim_twice_nor_backdates_note_coupon(self):
        result = TridentModelService().run(clo_request(fixed_position()))
        self.assertEqual(result.clo.status, ProjectionStatus.COMPLETED)
        self.assertTrue(result.clo.terminal_value_available)
        self.assertEqual(result.equity_irr.status, ReturnStatus.AVAILABLE)
        period, = result.clo.periods
        self.assertEqual((period.accrual_start, period.accrual_end), (OPEN, FIRST))
        self.assertEqual(period.received_asset_interest, D("3.00"))
        self.assertEqual(period.received_asset_principal, D(100))
        # The note is newly issued onFeb1;80*6%*59/360 posts0.79.
        # Total asset cash103, less note coupon0.79 and face80, leaves22.21.
        self.assertEqual(period.note_coupon_due, D("0.79"))
        self.assertEqual(period.note_coupon_paid, D("0.79"))
        self.assertEqual(result.clo.total_equity_distributions, D("22.21"))
        self.assertEqual(result.equity_cashflows[0].amount, D("-21.03"))
        self.assertEqual(result.clo.tranche_periods[0].current_coupon_due, D("0.79"))
        self.assertEqual(period.cash_conservation_residual, D(0))

    def test_adjusted_oc_does_not_turn_purchase_cost_into_another_entitlement(self):
        for acquired_cost in (D(0), D("1.03"), D(2)):
            with self.subTest(acquired_cost=acquired_cost):
                result = TridentModelService().run(clo_request(
                    fixed_position(), purchase_accrued=acquired_cost, adjusted_oc=True))
                self.assertEqual(result.clo.periods[0].received_asset_interest, D("3.00"))
                self.assertEqual(result.clo.total_equity_distributions, D("22.21"))
                self.assertEqual(result.cashflows.funding.equity_cash_funding,
                                 D(20) + acquired_cost)

    def test_explicit_zero_retained_claim_can_have_nonzero_purchase_cost(self):
        result = TridentModelService().run(clo_request(
            fixed_position(opening_claim=D(0), entitlement_policy=OpeningCouponEntitlement.POST_ASOF_ONLY),
            purchase_accrued=D(2), adjusted_oc=True))
        # Ex-coupon/retained-entitlement decisions belong to opening evidence.
        # A seller's2.00 quote cannot manufacture an asset coupon claim.
        self.assertEqual(result.cashflows.funding.equity_cash_funding, D(22))
        self.assertEqual(result.cashflows.cashflows[0].cash_interest, D("1.97"))
        self.assertEqual(result.clo.periods[0].received_asset_interest, D("1.97"))
        self.assertEqual(result.clo.total_equity_distributions, D("21.18"))

    def test_low_level_clo_rejects_a_second_acquired_claim_on_the_same_coupon(self):
        model_request = clo_request(fixed_position(), adjusted_oc=True)
        cash = CashflowRunService().run(model_request.cashflow_request)
        duplicated = CloRunRequest(
            cash.cashflows, D(100), model_request.notes, model_request.clo_terms,
            acquired_accrued_by_loan={"L": D("1.03")},
        )
        with self.assertRaisesRegex(InputValidationError, "second receipt"):
            DeterministicCloEngine(model_request.cashflow_request.rate_provider).run(duplicated)

    def test_zero_cent_display_does_not_hide_an_exact_opening_entitlement(self):
        position = fixed_position(opening_claim=D(0))
        position = replace(position, terms=replace(position.terms, fixed_rate=D("0.000001")))
        model_request = clo_request(position, purchase_accrued=D(".01"), adjusted_oc=True)
        cash = CashflowRunService().run(model_request.cashflow_request)
        row, = cash.cashflows
        self.assertEqual(row.opening_accrued_interest, D(0))
        self.assertGreater(row.opening_accrued_exact, 0)
        duplicated = CloRunRequest(
            cash.cashflows, D(100), model_request.notes, model_request.clo_terms,
            acquired_accrued_by_loan={"L": D(".01")})
        with self.assertRaisesRegex(InputValidationError, "second receipt"):
            DeterministicCloEngine(model_request.cashflow_request.rate_provider).run(duplicated)

    def test_carried_original_fixing_overrides_the_forward_provider(self):
        terms = LoanTerms(
            "L", "EUR", START, FIRST, D(100), CouponType.FLOATING,
            rate_index="EURIBOR_6M", spread_bps=D(400), reset_frequency_months=6,
            business_day_convention=BusinessDayConvention.UNADJUSTED,
            accrual_date_basis=AccrualDateBasis.UNADJUSTED, fixing_lag_business_days=0,
        )
        position = LoanPosition(terms, OPEN, D(100), SeasonedLoanState(
            D("0.52"), SOURCE, (OpeningFixing(START, D("0.02")),)))
        provider = RecordingRateProvider()
        result = TridentModelService().run(clo_request(
            position, purchase_accrued=D("0.52"), provider=provider))
        row, = result.cashflows.cashflows
        self.assertEqual(row.fixing_date, START)
        self.assertEqual(row.index_rate, D("0.02"))
        self.assertEqual(row.all_in_rate, D("0.06"))
        self.assertEqual(row.cash_interest, D("1.50"))
        self.assertEqual(result.clo.periods[0].received_asset_interest, D("1.50"))
        self.assertEqual(provider.calls, [])

    def test_missing_carried_fixing_is_not_replaced_by_a_flat_scenario(self):
        terms = replace(fixed_position().terms, coupon_type=CouponType.FLOATING,
                        fixed_rate=None, rate_index="EURIBOR_3M", spread_bps=D(400))
        position = LoanPosition(terms, OPEN, D(100), SeasonedLoanState(D("0.52"), SOURCE))
        provider = RecordingRateProvider()
        with self.assertRaisesRegex(InputValidationError, "opening fixing dates"):
            CashflowRunService().run(cashflow_request(position, provider=provider))
        self.assertEqual(provider.calls, [])

    def test_full_current_coupon_retains_exact_accrual_until_single_posting(self):
        # Apr1–Jul1 is91actualdays. Splitting atMay15 produces44old and
        # 47new days. The old display claim rounds1.4666... to1.47, but
        # reusing that cent value would incorrectly make the coupon3.04.
        # FULL_CURRENT_PERIOD keeps exact ownership and posts91days to3.03.
        terms = replace(fixed_position().terms, start_date=FIRST,
                        maturity_date=date(2026, 7, 1))
        position = LoanPosition(terms, date(2026, 5, 15), D(100),
                                SeasonedLoanState(D("1.47"), SOURCE))
        result = TridentModelService().run(clo_request(
            position, purchase_accrued=D("1.47"), adjusted_oc=True))
        row, = result.cashflows.cashflows
        self.assertEqual(row.opening_accrued_interest, D("1.47"))
        self.assertEqual(row.cash_interest, D("3.03"))
        self.assertEqual(result.clo.periods[0].received_asset_interest, D("3.03"))
        self.assertEqual(result.clo.periods[0].note_coupon_due, D("0.63"))
        self.assertEqual(result.clo.total_equity_distributions, D("22.40"))
        self.assertEqual(result.cashflows.funding.equity_cash_funding, D("21.47"))

    def test_verified_explicit_cash_claim_has_a_distinct_posting_policy(self):
        terms = replace(fixed_position().terms, start_date=FIRST,
                        maturity_date=date(2026, 7, 1))
        position = LoanPosition(terms, date(2026, 5, 15), D(100), SeasonedLoanState(
            D("1.47"), SOURCE, entitlement_policy=OpeningCouponEntitlement.EXPLICIT_CASH_CLAIM))
        result = TridentModelService().run(clo_request(position, purchase_accrued=D("1.47")))
        # A specifically agreed cent claim is an independent economic right.
        # It intentionally differs from full-period contractual entitlement.
        self.assertEqual(result.cashflows.cashflows[0].cash_interest, D("3.04"))
        self.assertEqual(result.clo.total_equity_distributions, D("22.41"))

    def test_full_current_coupon_rejects_an_inconsistent_opening_statement(self):
        with self.assertRaisesRegex(InputValidationError, "claim|accrued"):
            CashflowRunService().run(cashflow_request(fixed_position(opening_claim=D("1.02"))))

    def test_full_current_entitlement_is_posted_once_at_earlier_prepayment(self):
        terms = replace(fixed_position().terms, start_date=FIRST,
                        maturity_date=date(2026, 7, 1))
        position = LoanPosition(terms, date(2026, 5, 15), D(100),
                                SeasonedLoanState(D("1.47"), SOURCE))
        request = replace(clo_request(position, purchase_accrued=D("1.47")),
                          credit_events=(PrepaymentEvent("L", date(2026, 6, 1)),))
        result = TridentModelService().run(request)
        # Full coupon ownership fromApr1 toJun1 is61days:2.0333... posts2.03.
        # The3.03 contractual Jul1 coupon is retained only as a reference.
        self.assertEqual(result.cashflows.cashflows[0].cash_interest, D("3.03"))
        receipt, = result.credit_projections[0].collections
        self.assertEqual(receipt.payment_date, date(2026, 6, 1))
        self.assertEqual(receipt.cash_interest, D("2.03"))
        self.assertEqual(receipt.principal_collection, D(100))
        self.assertEqual(result.clo.periods[0].received_asset_interest, D("2.03"))
        self.assertEqual(result.clo.total_equity_distributions, D("21.40"))
        self.assertEqual(result.clo.periods[0].cash_conservation_residual, D(0))

    def test_default_before_first_coupon_does_not_collect_the_opening_claim(self):
        request = clo_request(fixed_position())
        request = replace(request,
            clo_terms=replace(request.clo_terms,
                              defaulted_asset_oc_treatment=DefaultedAssetOcTreatment.EXCLUDE),
            credit_events=(DefaultEvent("L", date(2026, 3, 1),
                           (RecoveryEvent(date(2026, 3, 15), D(1)),)),))
        result = TridentModelService().run(request)
        # Principal recovery is an explicit100% scenario input, not evidence
        # that the defaulted asset also pays its promised historical coupon.
        self.assertEqual(result.cashflows.cashflows[0].cash_interest, D("3.00"))
        self.assertEqual(sum(row.cash_interest for row in result.credit_projections[0].collections), D(0))
        self.assertEqual(result.clo.periods[0].received_asset_interest, D(0))
        self.assertEqual(result.clo.periods[0].recovery_principal_received, D(100))
        self.assertEqual(result.clo.total_equity_distributions, D("19.21"))
        self.assertTrue(result.clo.terminal_value_available)
        self.assertEqual(result.clo.periods[0].cash_conservation_residual, D(0))

    def test_full_coupon_requires_finished_historical_reset_segments(self):
        terms = LoanTerms(
            "L", "EUR", START, FIRST, D(100), CouponType.FLOATING,
            rate_index="EURIBOR_1M", spread_bps=D(300), reset_frequency_months=1,
            business_day_convention=BusinessDayConvention.UNADJUSTED,
            accrual_date_basis=AccrualDateBasis.UNADJUSTED, fixing_lag_business_days=0,
        )
        state = SeasonedLoanState(D("0.66"), SOURCE, (
            OpeningFixing(START, D("0.02")), OpeningFixing(date(2026, 2, 1), D("0.03"))))
        position = LoanPosition(terms, date(2026, 2, 15), D(100), state)
        provider = RecordingRateProvider(D("0.04"))
        result = CashflowRunService().run(cashflow_request(position, provider=provider))
        self.assertEqual(result.cashflows[0].cash_interest, D("1.50"))
        self.assertEqual(provider.calls, [("EURIBOR_1M", date(2026, 3, 1))])
        incomplete = replace(position, seasoned_state=replace(
            state, fixing_observations=state.fixing_observations[1:]))
        with self.assertRaisesRegex(InputValidationError, "opening fixing dates"):
            CashflowRunService().run(cashflow_request(incomplete, provider=RecordingRateProvider()))

    def test_old_paid_coupon_is_excluded_without_restarting_contractual_grid(self):
        position = fixed_position(start=date(2025, 10, 1))
        result = TridentModelService().run(clo_request(position))
        row, = result.cashflows.cashflows
        self.assertEqual(row.period_number, 1)
        self.assertEqual(row.unadjusted_start, START)
        self.assertEqual(row.accrual_start, OPEN)
        self.assertEqual(row.payment_date, FIRST)
        self.assertEqual(row.cash_interest, D("3.00"))
        self.assertEqual(result.clo.periods[0].received_asset_interest, D("3.00"))

    def test_future_step_uses_original_entitlement_and_updates_observed_quality(self):
        position = fixed_position(coupon_steps=(CouponStep(date(2026, 3, 1), fixed_rate=D("0.24")),))
        result = TridentModelService().run(clo_request(position))
        # Forward28days at12% and31days at24%, plus explicit old claim1.03,
        # gives4.03 after one cent posting; opening WAC stays12%.
        self.assertEqual(result.cashflows.cashflows[0].cash_interest, D("4.03"))
        self.assertEqual(result.clo.periods[0].received_asset_interest, D("4.03"))
        self.assertEqual(result.opening_portfolio.metric("WAC_RATE").value, D("0.12"))
        step_report = next(report for report in result.portfolio_observations
                           if report.as_of_date == date(2026, 3, 1))
        self.assertEqual(step_report.metric("WAC_RATE").value, D("0.24"))

    def test_past_step_seasoning_is_rejected_until_candidate_transport_matches(self):
        terms = replace(fixed_position().terms,
                        coupon_steps=(CouponStep(date(2026, 1, 15), fixed_rate=D("0.24")),))
        with self.assertRaises(InputValidationError):
            LoanPosition(terms, OPEN, D(100), SeasonedLoanState(D("1.60"), SOURCE))

    def test_nonseasoned_acquired_cost_remains_restricted_without_entitlement_policy(self):
        seasoned = fixed_position()
        fresh = LoanPosition(replace(seasoned.terms, start_date=OPEN), OPEN, D(100))
        with self.assertRaisesRegex(InputValidationError, "nonzero accrued"):
            TridentModelService().run(clo_request(fresh))
        # Standalone funding can report a acquisition cost without pretending
        # that the fresh contract pays additional inherited coupon.
        cash = CashflowRunService().run(cashflow_request(fresh))
        self.assertEqual(cash.cashflows[0].cash_interest, D("1.97"))
        self.assertEqual(cash.funding.equity_cash_funding, D("21.03"))

    def test_seasoned_full_run_is_independent_of_callers_decimal_context(self):
        request = clo_request(fixed_position(), adjusted_oc=True)
        reference = TridentModelService().run(request)
        with localcontext() as caller:
            caller.prec = 6
            caller.traps[Inexact] = True
            actual = TridentModelService().run(request)
        self.assertEqual(actual.cashflows.funding, reference.cashflows.funding)
        self.assertEqual(actual.cashflows.cashflows, reference.cashflows.cashflows)
        self.assertEqual(actual.clo, reference.clo)
        self.assertEqual(actual.equity_irr, reference.equity_irr)


if __name__ == "__main__":
    unittest.main()
