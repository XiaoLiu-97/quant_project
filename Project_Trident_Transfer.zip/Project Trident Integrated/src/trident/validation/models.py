"""Typed, source-bearing benchmarks for independent financial reconciliation.

Reconciliation compares an explicitly supplied finite set of observations. It
does not choose legal tolerances, certify the reference source, or approve a
deal. Dates, entity identity, stage, metric and unit are part of the contract;
similar labels are never silently aliased and percentages are not converted.
"""

from dataclasses import dataclass
from datetime import date
from decimal import Decimal
from enum import Enum
from fractions import Fraction

from trident.domain.models import InputValidationError, require_date, require_decimal


def _text(value: object, label: str) -> None:
    """Require intentional semantic labels, retaining their exact spelling."""
    if not isinstance(value, str) or not value or value != value.strip():
        raise InputValidationError(f"{label} must be nonempty, unpadded text")


class ReconciliationStatus(str, Enum):
    """Numerical evidence within the submitted benchmark scope only."""

    MATCH = "MATCH"
    MISMATCH = "MISMATCH"
    UNAVAILABLE = "UNAVAILABLE"


@dataclass(frozen=True)
class ReconciliationKey:
    """Identify one metric without coupling the engine to Excel coordinates.

    ``entity_type`` can identify a DEAL, ASSET, TRANCHE, COVERAGE, ACCOUNT or
    another explicit adapter namespace. ``entity_id`` is the actual deal/loan/
    class identity. ``stage`` distinguishes GATE, POST_DIVERSION, PERIOD_END,
    or a closing BASELINE on the same date; it never infers a waterfall node.
    The reporting adapter owns the canonical metric registry and aggregation.
    """

    observation_date: date
    entity_type: str
    entity_id: str
    metric: str
    stage: str = "BASELINE"

    def __post_init__(self) -> None:
        require_date(self.observation_date, "reconciliation observation_date")
        for field in ("entity_type", "entity_id", "metric", "stage"):
            _text(getattr(self, field), f"reconciliation {field}")


@dataclass(frozen=True)
class BenchmarkRecord:
    """One independent expected value, absolute tolerance and source locator.

    Both ``expected`` and ``tolerance`` use the explicit ``unit``. A tolerance
    of zero requests exact agreement; nonzero tolerance is caller-selected,
    never a production default. ``source`` identifies the independent report,
    contract, manually checked calculation or system. ``reference_id`` locates
    its particular record (for example report section or named source field).
    These labels establish traceability, not verification of source authority.
    """

    key: ReconciliationKey
    expected: Decimal
    tolerance: Decimal
    unit: str
    source: str
    reference_id: str

    def __post_init__(self) -> None:
        if not isinstance(self.key, ReconciliationKey):
            raise InputValidationError("benchmark key must be ReconciliationKey")
        require_decimal(self.expected, "benchmark expected")
        require_decimal(self.tolerance, "benchmark tolerance", minimum=Decimal(0))
        for field in ("unit", "source", "reference_id"):
            _text(getattr(self, field), f"benchmark {field}")


@dataclass(frozen=True)
class ObservedMetric:
    """A generated number or explicit absence, with its canonical unit.

    A present value must be a finite Decimal; binary floats and automatic
    coercion are rejected. The adapter must inspect model availability before
    exposing a value: a diagnostic displayed for an unavailable model metric
    must be represented as None here. The reason retains that model evidence.
    """

    value: Decimal | None
    unit: str
    unavailable_reason: str = ""

    def __post_init__(self) -> None:
        if self.value is not None:
            require_decimal(self.value, "observed metric value")
        _text(self.unit, "observed metric unit")
        if not isinstance(self.unavailable_reason, str):
            raise InputValidationError("unavailable_reason must be text")
        if self.unavailable_reason != self.unavailable_reason.strip():
            raise InputValidationError("unavailable_reason must not have surrounding whitespace")
        if self.value is not None and self.unavailable_reason:
            raise InputValidationError("A present observed metric cannot also have an unavailable reason")


@dataclass(frozen=True)
class ReconciliationResult:
    """One comparison, retaining source, expected/actual units and difference.

    ``difference`` is actual minus expected; ``absolute_difference`` is compared
    inclusively with the explicit tolerance. Neither value is rounded to cents:
    the benchmark unit could be EUR, bps, a ratio, or another precision. Missing
    values and unit mismatches have no numerical difference.
    """

    benchmark: BenchmarkRecord
    observation: ObservedMetric | None
    status: ReconciliationStatus
    difference: Decimal | None
    absolute_difference: Decimal | None
    message: str

    def __post_init__(self) -> None:
        """Reject contradictory public result records at the evidence boundary.

        Exact fraction checks independently bind a published difference and
        status to its two finite input values. A hand-built result cannot turn
        absent data, a mismatched unit, or a tolerance breach into MATCH.
        """
        if not isinstance(self.benchmark, BenchmarkRecord):
            raise InputValidationError("Reconciliation result requires a BenchmarkRecord")
        if self.observation is not None and not isinstance(self.observation, ObservedMetric):
            raise InputValidationError("Reconciliation result observation must be ObservedMetric or None")
        if not isinstance(self.status, ReconciliationStatus):
            raise InputValidationError("Reconciliation result status must be ReconciliationStatus")
        _text(self.message, "reconciliation result message")
        comparable = (self.observation is not None and self.observation.value is not None
                      and self.observation.unit == self.benchmark.unit)
        if self.status is ReconciliationStatus.UNAVAILABLE:
            if comparable or self.difference is not None or self.absolute_difference is not None:
                raise InputValidationError("UNAVAILABLE reconciliation result must have absent/incompatible data and no difference")
            return
        if not comparable:
            raise InputValidationError("Comparable reconciliation result requires an available value in the benchmark unit")
        require_decimal(self.difference, "reconciliation difference")
        require_decimal(self.absolute_difference, "reconciliation absolute difference", minimum=Decimal(0))
        exact = Fraction(self.observation.value) - Fraction(self.benchmark.expected)
        if Fraction(self.difference) != exact or Fraction(self.absolute_difference) != abs(exact):
            raise InputValidationError("Published reconciliation difference does not match actual minus expected")
        expected_match = abs(exact) <= Fraction(self.benchmark.tolerance)
        if (self.status is ReconciliationStatus.MATCH) != expected_match:
            raise InputValidationError("Reconciliation status conflicts with the explicit absolute tolerance")

    @property
    def key(self) -> ReconciliationKey:
        """Expose the full semantic identity without copying benchmark data."""
        return self.benchmark.key


@dataclass(frozen=True)
class ReconciliationReport:
    """Finite comparison evidence; no automatic sign-off or legal approval.

    Any unavailable row makes the report UNAVAILABLE even when other rows show
    known mismatches. Counts retain both facts. MATCH requires at least one
    record and complete numerical agreement within every stated tolerance.
    Unreferenced generated metrics are outside the submitted benchmark scope.
    """

    results: tuple[ReconciliationResult, ...]

    def __post_init__(self) -> None:
        if type(self.results) is not tuple or not self.results:
            raise InputValidationError("Reconciliation reports require a nonempty immutable result tuple")
        if any(not isinstance(row, ReconciliationResult) for row in self.results):
            raise InputValidationError("Reconciliation report rows must be ReconciliationResult")
        if len({row.key for row in self.results}) != len(self.results):
            raise InputValidationError("Duplicate reconciliation result identity")

    @property
    def status(self) -> ReconciliationStatus:
        """Keep incompleteness distinct from a completed numerical mismatch."""
        if self.unavailable_count:
            return ReconciliationStatus.UNAVAILABLE
        return ReconciliationStatus.MISMATCH if self.mismatched_count else ReconciliationStatus.MATCH

    @property
    def matched_count(self) -> int:
        return sum(row.status is ReconciliationStatus.MATCH for row in self.results)

    @property
    def mismatched_count(self) -> int:
        return sum(row.status is ReconciliationStatus.MISMATCH for row in self.results)

    @property
    def unavailable_count(self) -> int:
        return sum(row.status is ReconciliationStatus.UNAVAILABLE for row in self.results)

    @property
    def complete(self) -> bool:
        """All referenced observations exist and have compatible units."""
        return self.unavailable_count == 0

    @property
    def matched(self) -> bool:
        """Numerical agreement within this explicit scope, never model approval."""
        return self.status is ReconciliationStatus.MATCH
