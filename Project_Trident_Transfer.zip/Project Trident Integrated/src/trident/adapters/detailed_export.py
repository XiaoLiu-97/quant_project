"""Export native coupons to the reference generator's 24-field cashflow tape.

This is a transport view over posted engine results, never a second engine.
Column identities are semantic and match the Detailed collateral importer;
Excel addresses are deliberately absent. Contract rates are annual fractions,
margin is bps and all amounts are the posted currency units in each row.
"""

from fractions import Fraction

from trident.domain.models import CouponType, LoanCashflow, LoanPosition, InputValidationError


def detailed_cashflow_records(
    cashflows: tuple[LoanCashflow, ...], positions: tuple[LoanPosition, ...],
) -> tuple[dict[str, object], ...]:
    """Produce one complete A:X-compatible record per contractual payment.

    Weighted rates are the engine's display diagnostics. Exact segment factors
    remain inside the native projection; importing this rounded tape uses its
    posted cash/face ledger and must not reconstruct coupon from display rates.
    PIK at maturity is redeemed as principal so the face bridge always closes.
    """
    terms = {position.terms.loan_id: position.terms for position in positions}
    if len(terms) != len(positions):
        raise InputValidationError("Detailed export requires unique contract identities")
    result = []
    for row in cashflows:
        if row.loan_id not in terms:
            raise InputValidationError("Detailed export cashflow has no matching contract")
        loan = terms[row.loan_id]
        observations = tuple(dict.fromkeys(segment.fixing_date for segment in row.coupon_segments
                                           if segment.fixing_date is not None))
        # O/N projection has a period observation, not a realised daily fixing
        # series. Keeping this label explicit prevents false lookback claims.
        overnight = loan.rate_index in {"ESTR", "SOFR", "SONIA"}
        if overnight:
            observations = (row.accrual_start,)
        reset = ("O/N" if overnight else f"{loan.reset_frequency_months or loan.frequency_months}M"
                 if loan.coupon_type is CouponType.FLOATING else "")
        result.append(dict(
            asset_id=row.loan_id, period=row.period_number, accrual_start=row.accrual_start,
            accrual_end=row.accrual_end, payment_date=row.payment_date,
            beginning_notional=row.opening_balance, coupon_type=loan.coupon_type.value,
            reference_index=loan.rate_index or "", reset_frequency=reset,
            first_fixing_date=observations[0] if observations else None,
            last_fixing_date=row.accrual_end if overnight else observations[-1] if observations else None,
            reset_observation_count=len(observations), weighted_base_rate=row.index_rate,
            weighted_spread_bps=row.spread_bps, effective_all_in_rate=row.all_in_rate,
            day_count_fraction=row.day_count_fraction, gross_interest=row.gross_interest,
            cash_interest=row.cash_interest, pik_interest=row.pik_interest,
            principal_repayment=row.principal_repayment, ending_notional=row.closing_balance,
            total_cash_payment=row.total_cash,
            notes=("NATIVE_PROJECTED_OVERNIGHT_DF_FORWARD" if overnight else "NATIVE_CONTRACTUAL")
                  + f"; settlement={row.interest_mode.value}; PIK fraction={row.pik_fraction}",
            currency=row.currency,
        ))
        if (Fraction(row.opening_balance) + Fraction(row.pik_interest) - Fraction(row.principal_repayment)
                != Fraction(row.closing_balance)):
            raise ArithmeticError("Detailed export face bridge failed")
    return tuple(result)
