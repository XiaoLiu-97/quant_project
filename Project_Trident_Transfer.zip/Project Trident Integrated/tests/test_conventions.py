"""Independent date/convention examples and invalid-input regression cases."""

from dataclasses import FrozenInstanceError
from datetime import date, datetime
from decimal import Decimal, Inexact, ROUND_DOWN, localcontext
from fractions import Fraction
import unittest

from trident.conventions import (
    AccrualDateBasis,
    AccrualPeriod,
    BusinessDayConvention,
    DayCount,
    ScheduleBuilder,
    StubConvention,
    TargetCalendar,
    WeekendCalendar,
    accrual_fraction,
    year_fraction,
)


class CalendarTests(unittest.TestCase):
    def setUp(self) -> None:
        self.target = TargetCalendar()
        self.weekends = WeekendCalendar()

    def test_target_2026_easter_and_fixed_closures(self) -> None:
        # ECB's 2026 published calendar: Good Friday 3 April, Easter Monday 6 April.
        for holiday in (
            date(2026, 1, 1), date(2026, 4, 3), date(2026, 4, 6),
            date(2026, 5, 1), date(2026, 12, 25), date(2026, 12, 26),
        ):
            with self.subTest(holiday=holiday):
                self.assertFalse(self.target.is_business_day(holiday))
        self.assertTrue(self.target.is_business_day(date(2026, 4, 2)))
        self.assertTrue(self.target.is_business_day(date(2026, 4, 7)))
        # ECB office closures are not automatically TARGET closures.
        self.assertTrue(self.target.is_business_day(date(2026, 5, 14)))
        self.assertTrue(self.target.is_business_day(date(2026, 12, 24)))
        self.assertTrue(self.target.is_business_day(date(2026, 12, 28)))

    def test_target_leap_century_easter_regressions(self) -> None:
        # Gregorian Easter dates; ECB's public table also confirms 2027/2028.
        for good_friday, easter_monday in (
            (date(2000, 4, 21), date(2000, 4, 24)),
            (date(2018, 3, 30), date(2018, 4, 2)),
            (date(2027, 3, 26), date(2027, 3, 29)),
            (date(2028, 4, 14), date(2028, 4, 17)),
        ):
            with self.subTest(year=good_friday.year):
                self.assertFalse(self.target.is_business_day(good_friday))
                self.assertFalse(self.target.is_business_day(easter_monday))

    def test_calendar_adjustment_known_answers(self) -> None:
        nonbusiness = date(2026, 1, 31)  # Saturday; following would cross the month.
        expectations = {
            BusinessDayConvention.UNADJUSTED: date(2026, 1, 31),
            BusinessDayConvention.FOLLOWING: date(2026, 2, 2),
            BusinessDayConvention.MODIFIED_FOLLOWING: date(2026, 1, 30),
            BusinessDayConvention.PRECEDING: date(2026, 1, 30),
            BusinessDayConvention.MODIFIED_PRECEDING: date(2026, 1, 30),
        }
        for convention, expected in expectations.items():
            with self.subTest(convention=convention):
                self.assertEqual(self.target.adjust(nonbusiness, convention), expected)
        self.assertEqual(
            self.weekends.adjust(date(2026, 3, 1), BusinessDayConvention.MODIFIED_PRECEDING),
            date(2026, 3, 2),
        )
        business_date = date(2026, 1, 30)
        for convention in BusinessDayConvention:
            self.assertEqual(self.target.adjust(business_date, convention), business_date)

    def test_lags_exclude_anchor_and_skip_target_closures(self) -> None:
        self.assertEqual(self.target.add_business_days(date(2026, 4, 7), -2), date(2026, 4, 1))
        self.assertEqual(self.target.add_business_days(date(2026, 4, 2), 1), date(2026, 4, 7))
        self.assertEqual(self.weekends.add_business_days(date(2026, 1, 31), 0), date(2026, 1, 31))
        self.assertEqual(self.weekends.add_business_days(date(2026, 1, 31), -1), date(2026, 1, 30))
        self.assertEqual(self.weekends.add_business_days(date(2026, 1, 31), 1), date(2026, 2, 2))

    def test_explicit_exception_and_immutability(self) -> None:
        closed = date(2026, 11, 20)
        calendar = TargetCalendar(frozenset({closed}))
        self.assertFalse(calendar.is_business_day(closed))
        self.assertTrue(self.target.is_business_day(closed))
        with self.assertRaises(FrozenInstanceError):
            calendar.extra_holidays = frozenset()  # type: ignore[misc]

    def test_calendar_rejects_invalid_inputs_and_range(self) -> None:
        for bad_date in (datetime(2026, 1, 1), "2026-01-01", None):
            with self.subTest(bad_date=bad_date):
                with self.assertRaises(TypeError):
                    self.target.is_business_day(bad_date)  # type: ignore[arg-type]
                with self.assertRaises(TypeError):
                    self.weekends.adjust(bad_date, BusinessDayConvention.UNADJUSTED)  # type: ignore[arg-type]
        for bad_lag in (True, 1.5, "2"):
            with self.assertRaises(TypeError):
                self.target.add_business_days(date(2026, 1, 2), bad_lag)  # type: ignore[arg-type]
        with self.assertRaises(TypeError):
            self.target.adjust(date(2026, 1, 2), "FOLLOWING")  # type: ignore[arg-type]
        with self.assertRaises(TypeError):
            TargetCalendar({date(2026, 1, 2)})  # type: ignore[arg-type]
        with self.assertRaises(TypeError):
            TargetCalendar(frozenset({datetime(2026, 1, 2)}))
        for unsupported in (date(1899, 12, 31), date(2200, 1, 1)):
            with self.assertRaises(ValueError):
                self.target.is_business_day(unsupported)
            with self.assertRaises(ValueError):
                self.target.adjust(unsupported, BusinessDayConvention.UNADJUSTED)
        with self.assertRaises(ValueError):
            self.weekends.add_business_days(date.max, 1)
        with self.assertRaises(ValueError):
            self.weekends.add_business_days(date.min, -1)

    def test_modified_preceding_at_calendar_range_edge(self) -> None:
        # New Year's Day at the lower bound must roll forward within January,
        # without querying the unsupported previous December.
        self.assertEqual(
            self.target.adjust(date(1900, 1, 1), BusinessDayConvention.MODIFIED_PRECEDING),
            date(1900, 1, 2),
        )


class DayCountTests(unittest.TestCase):
    def test_exact_fraction_preserves_one_third_and_cross_year_sum(self) -> None:
        # Jan 1--May 1 2026: 31+28+31+30 = 120 days; the exact DCF is 1/3.
        self.assertEqual(
            accrual_fraction(date(2026, 1, 1), date(2026, 5, 1), DayCount.ACT_360),
            Fraction(1, 3),
        )
        self.assertEqual(
            accrual_fraction(date(2023, 12, 31), date(2024, 1, 2), DayCount.ACT_ACT_ISDA),
            Fraction(1, 365) + Fraction(1, 366),
        )
        # Exact multiplication retains the contractual half-cent before posting.
        interest = Fraction(Decimal("10")) * Fraction(Decimal("0.0015")) * accrual_fraction(
            date(2026, 1, 1), date(2026, 5, 1), DayCount.ACT_360,
        )
        self.assertEqual(interest, Fraction(Decimal("0.005")))

    def test_ninety_day_and_hybrid_ninety_four_day_answers(self) -> None:
        # Jan 1--Apr 1 2026: 31+28+31 = 90 days.
        self.assertEqual(year_fraction(date(2026, 1, 1), date(2026, 4, 1), DayCount.ACT_360), Decimal("0.25"))
        # Nov 20--Feb 22: 11+31+31+21 = 94; no generated expectation.
        start, end = date(2026, 11, 20), date(2027, 2, 22)
        self.assertEqual(year_fraction(start, end, DayCount.ACT_360), Decimal("0.2611111111111111111111111111111111"))
        self.assertEqual(year_fraction(start, end, DayCount.ACT_365F), Decimal("0.2575342465753424657534246575342466"))

    def test_actual_actual_isda_crosses_years_and_leap_day(self) -> None:
        # One day in 2023 /365 plus one day in 2024 /366.
        expected = Decimal("0.005471966464555730219327793996556628")
        self.assertEqual(year_fraction(date(2023, 12, 31), date(2024, 1, 2), DayCount.ACT_ACT_ISDA), expected)
        self.assertEqual(year_fraction(date(2024, 2, 28), date(2024, 3, 1), DayCount.ACT_ACT_ISDA), Decimal("0.005464480874316939890710382513661202"))
        self.assertEqual(year_fraction(date(2020, 1, 1), date(2023, 1, 1), DayCount.ACT_ACT_ISDA), Decimal(3))
        self.assertEqual(year_fraction(date(2024, 1, 1), date(2025, 1, 1), DayCount.ACT_ACT_ISDA), Decimal(1))
        # ACT/365F does not switch to 366 in a leap year.
        self.assertEqual(year_fraction(date(2024, 1, 1), date(2025, 1, 1), DayCount.ACT_365F), Decimal("1.002739726027397260273972602739726"))

    def test_day_count_zero_bounds_and_decimal_context_isolation(self) -> None:
        for convention in DayCount:
            self.assertEqual(year_fraction(date.min, date.min, convention), Decimal(0))
        self.assertEqual(year_fraction(date(9999, 12, 30), date.max, DayCount.ACT_ACT_ISDA), Decimal("0.002739726027397260273972602739726027"))
        with localcontext() as context:
            context.prec = 3
            context.rounding = ROUND_DOWN
            context.traps[Inexact] = True
            self.assertEqual(year_fraction(date(2026, 1, 1), date(2026, 1, 2), DayCount.ACT_360), Decimal("0.002777777777777777777777777777777778"))
            self.assertEqual(context.prec, 3)

    def test_day_count_rejects_invalid_dates_order_and_convention(self) -> None:
        with self.assertRaises(ValueError):
            year_fraction(date(2026, 1, 2), date(2026, 1, 1), DayCount.ACT_360)
        with self.assertRaises(TypeError):
            year_fraction(datetime(2026, 1, 1), date(2026, 1, 2), DayCount.ACT_360)
        with self.assertRaises(TypeError):
            year_fraction(date(2026, 1, 1), "2026-01-02", DayCount.ACT_360)  # type: ignore[arg-type]
        with self.assertRaises(TypeError):
            year_fraction(date(2026, 1, 1), date(2026, 1, 2), "ACT/360")  # type: ignore[arg-type]


class ScheduleTests(unittest.TestCase):
    def setUp(self) -> None:
        self.builder = ScheduleBuilder(TargetCalendar())

    def test_original_january_month_end_anchor_does_not_drift(self) -> None:
        periods = self.builder.build(date(2026, 1, 31), date(2026, 4, 30), 1)
        self.assertEqual(
            tuple(period.unadjusted_end for period in periods),
            (date(2026, 2, 28), date(2026, 3, 31), date(2026, 4, 30)),
        )
        self.assertEqual(
            tuple(period.accrual_end for period in periods),
            (date(2026, 2, 27), date(2026, 3, 31), date(2026, 4, 30)),
        )
        self.assertEqual(periods[0].accrual_start, date(2026, 1, 30))
        for left, right in zip(periods, periods[1:]):
            self.assertEqual(left.accrual_end, right.accrual_start)
        self.assertEqual(tuple(period.period_number for period in periods), (1, 2, 3))

    def test_non_month_end_and_explicit_end_of_month(self) -> None:
        periods = self.builder.build(date(2026, 1, 30), date(2026, 3, 30), 1, stub_convention=StubConvention.NONE)
        self.assertEqual(tuple(period.unadjusted_end for period in periods), (date(2026, 2, 28), date(2026, 3, 30)))
        eom = self.builder.build(date(2026, 4, 30), date(2026, 6, 30), 1, end_of_month=True, stub_convention=StubConvention.NONE)
        self.assertEqual(tuple(period.unadjusted_end for period in eom), (date(2026, 5, 31), date(2026, 6, 30)))

    def test_hybrid_first_period_ninety_four_days(self) -> None:
        periods = self.builder.build(date(2026, 11, 20), date(2027, 11, 20), 3)
        first = periods[0]
        self.assertEqual(first.unadjusted_end, date(2027, 2, 20))
        self.assertEqual(first.accrual_end, date(2027, 2, 22))
        self.assertEqual(first.payment_date, date(2027, 2, 22))
        self.assertEqual(first.fixing_date, date(2026, 11, 18))
        self.assertEqual(first.reset_date, first.accrual_start)
        self.assertEqual((first.accrual_end - first.accrual_start).days, 94)

    def test_unadjusted_accrual_payment_and_holiday_fixing_are_distinct(self) -> None:
        period = self.builder.build(
            date(2026, 4, 7), date(2026, 7, 7), 3,
            accrual_date_basis=AccrualDateBasis.UNADJUSTED,
            payment_lag_business_days=2,
        )[0]
        self.assertEqual(period.fixing_date, date(2026, 4, 1))
        self.assertEqual(period.payment_date, date(2026, 7, 9))
        weekend_end = self.builder.build(
            date(2026, 11, 20), date(2027, 2, 20), 3,
            accrual_date_basis=AccrualDateBasis.UNADJUSTED,
        )[0]
        self.assertEqual(weekend_end.accrual_end, date(2027, 2, 20))
        self.assertEqual(weekend_end.payment_date, date(2027, 2, 22))

    def test_short_last_stub_and_none_alignment(self) -> None:
        periods = self.builder.build(date(2026, 1, 20), date(2026, 8, 10), 3)
        self.assertEqual(tuple(period.unadjusted_end for period in periods), (date(2026, 4, 20), date(2026, 7, 20), date(2026, 8, 10)))
        self.assertEqual(periods[-1].unadjusted_start, date(2026, 7, 20))
        with self.assertRaises(ValueError):
            self.builder.build(date(2026, 1, 20), date(2026, 8, 10), 3, stub_convention=StubConvention.NONE)
        one_stub = self.builder.build(date(2026, 1, 20), date(2026, 2, 10), 3)
        self.assertEqual(len(one_stub), 1)
        self.assertEqual(one_stub[0].unadjusted_end, date(2026, 2, 10))

    def test_frequency_and_zero_lags(self) -> None:
        for frequency in (1, 3, 6, 12):
            with self.subTest(frequency=frequency):
                periods = self.builder.build(date(2026, 1, 20), date(2027, 1, 20), frequency, fixing_lag_business_days=0, stub_convention=StubConvention.NONE)
                self.assertEqual(len(periods), 12 // frequency)
                self.assertTrue(all(period.fixing_date == period.reset_date for period in periods))

    def test_schedule_rejects_invalid_inputs(self) -> None:
        valid = dict(start_date=date(2026, 1, 20), maturity_date=date(2027, 1, 20), frequency_months=3)
        invalid_value_cases = (
            {"frequency_months": 2}, {"frequency_months": 0},
            {"maturity_date": date(2026, 1, 20)}, {"maturity_date": date(2025, 1, 20)},
            {"fixing_lag_business_days": -1}, {"payment_lag_business_days": -1},
            {"end_of_month": True},
        )
        for replacement in invalid_value_cases:
            with self.subTest(replacement=replacement):
                with self.assertRaises(ValueError):
                    self.builder.build(**(valid | replacement))
        invalid_type_cases = (
            {"start_date": datetime(2026, 1, 20)}, {"maturity_date": "2027-01-20"},
            {"frequency_months": True}, {"frequency_months": 3.0},
            {"business_day_convention": "FOLLOWING"}, {"accrual_date_basis": "ADJUSTED"},
            {"fixing_lag_business_days": True}, {"payment_lag_business_days": 1.5},
            {"end_of_month": 1}, {"stub_convention": "SHORT_LAST"},
        )
        for replacement in invalid_type_cases:
            with self.subTest(replacement=replacement):
                with self.assertRaises(TypeError):
                    self.builder.build(**(valid | replacement))
        with self.assertRaises(TypeError):
            ScheduleBuilder("TARGET")  # type: ignore[arg-type]

    def test_adjustment_cannot_create_zero_accrual_interval(self) -> None:
        with self.assertRaisesRegex(ValueError, "positive length"):
            self.builder.build(date(2026, 1, 31), date(2026, 2, 1), 1, business_day_convention=BusinessDayConvention.FOLLOWING)

    def test_date_max_short_stub_and_calendar_limit(self) -> None:
        builder = ScheduleBuilder(WeekendCalendar())
        period = builder.build(
            date(9999, 1, 20), date(9999, 12, 20), 12,
            business_day_convention=BusinessDayConvention.UNADJUSTED,
            accrual_date_basis=AccrualDateBasis.UNADJUSTED,
            fixing_lag_business_days=0,
        )[0]
        self.assertEqual(period.unadjusted_end, date(9999, 12, 20))
        with self.assertRaises(ValueError):
            self.builder.build(date(2199, 11, 20), date(2200, 2, 20), 3)

    def test_period_is_frozen_and_validates_its_dates(self) -> None:
        values = dict(
            period_number=1, unadjusted_start=date(2026, 1, 20), unadjusted_end=date(2026, 4, 20),
            accrual_start=date(2026, 1, 20), accrual_end=date(2026, 4, 20),
            payment_date=date(2026, 4, 20), fixing_date=date(2026, 1, 16),
        )
        period = AccrualPeriod(**values)
        with self.assertRaises(FrozenInstanceError):
            period.period_number = 2  # type: ignore[misc]
        with self.assertRaises(TypeError):
            AccrualPeriod(**(values | {"period_number": True}))
        with self.assertRaises(ValueError):
            AccrualPeriod(**(values | {"period_number": 0}))
        with self.assertRaises(ValueError):
            AccrualPeriod(**(values | {"accrual_end": values["accrual_start"]}))
        with self.assertRaises(ValueError):
            AccrualPeriod(**(values | {"unadjusted_end": values["unadjusted_start"]}))
        with self.assertRaises(ValueError):
            AccrualPeriod(**(values | {"fixing_date": date(2026, 1, 21)}))
        with self.assertRaises(TypeError):
            AccrualPeriod(**(values | {"payment_date": datetime(2026, 4, 20)}))


if __name__ == "__main__":
    unittest.main()
