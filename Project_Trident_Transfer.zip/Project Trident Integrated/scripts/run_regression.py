"""Run the complete financial suite and bind its evidence to frozen sources.

The runner records hashes before and after execution so a concurrent edit
cannot be labelled as tested. It uses unittest, captures its exact log and
replaces only the current regression record. Source workbooks are never read
or modified by this utility. Installation probes are separate evidence.
"""
from datetime import datetime, timezone
from hashlib import sha256
import json
import os
from pathlib import Path
import re
import subprocess
import sys
from time import monotonic

ROOT=Path(__file__).resolve().parents[1]

def hashes(paths):
    return {path.relative_to(ROOT).as_posix(): sha256(path.read_bytes()).hexdigest()
            for path in sorted(paths)}

def main():
    source=hashes((ROOT/'src/trident').rglob('*.py'))
    tests=hashes(path for path in (ROOT/'tests').rglob('*') if path.is_file()
                 and '__pycache__' not in path.parts and path.suffix in {'.py','.json','.csv','.xlsx'})
    env=dict(os.environ, PYTHONDONTWRITEBYTECODE='1', PYTHONPATH=str(ROOT/'src'), PYTHONIOENCODING='utf-8')
    command=[sys.executable,'-X','utf8','-m','unittest','discover','-s','tests','-v']
    start=datetime.now(timezone.utc).isoformat()
    timer=monotonic()
    destination=ROOT/'docs/validation/tests.log'
    # Each invocation owns one staging file. Interrupted Windows venv launcher
    # processes can leave a child alive; another run must never truncate its
    # file and produce sparse/corrupted shared-log evidence. Publish the final
    # complete log only after this invocation's child has actually exited.
    running_log=destination.with_name(f'.tests-running-{os.getpid()}.log')
    with running_log.open('w',encoding='utf8') as log:
        result=subprocess.run(command,cwd=ROOT,env=env,stdout=log,stderr=subprocess.STDOUT,check=False)
    text=running_log.read_text(encoding='utf8')
    match=re.search(r'Ran (\d+) tests in ([\d.]+)s',text)
    if match is None:
        raise RuntimeError('Unittest did not report a complete test count; inspect tests.log')
    if '\x00' in text:
        raise RuntimeError('Regression log contains corrupt null bytes; no evidence published')
    os.replace(running_log,destination)
    skipped=len(re.findall(r'\.\.\. skipped ',text))
    changed=(source!=hashes((ROOT/'src/trident').rglob('*.py')) or tests!=hashes(
        path for path in (ROOT/'tests').rglob('*') if path.is_file()
        and '__pycache__' not in path.parts and path.suffix in {'.py','.json','.csv','.xlsx'}))
    # The public version comes from the same source bytes recorded above.
    sys.path.insert(0,str(ROOT/'src'))
    from trident import __version__
    from trident.adapters.excel_schema import SCHEMA_VERSION
    evidence=dict(recorded_at_utc=datetime.now(timezone.utc).isoformat(),software_version=__version__,
        workbook_schema='1.0',canonical_adapter_schema=SCHEMA_VERSION,status='PASS_SUPPORTED_INTEGRATED_CAPABILITIES' if result.returncode==0 and not changed and not skipped else 'FAIL',
        scope='COMPACT_NAMED_UI;FULL_CASE_PRESENTATION;STATIC_OPENING_WHAT_IF;NATIVE_CASH_PIK_MIXED;PROJECTED_OVERNIGHT;REGIONAL_CALENDARS;SCHEDULED_PAYMENT_LAG;EUR_CLO;CASHFLOW_ONLY_EUR_USD_GBP;EXPLICIT_CREDIT_BOUNDED_PROFILE;PROPORTIONAL_OVERLAY;SYNTHETIC_REINVESTMENT;ECONOMICS;NAMED_EXCEL;OPTIMIZATION;EXISTING_OPENING;LEDGER;RECONCILIATION',
        full_regression=dict(command=command,started_at_utc=start,finished_at_utc=datetime.now(timezone.utc).isoformat(),
            python_exit_code=result.returncode,elapsed_seconds=monotonic()-timer,tests_run=int(match[1]),
            unittest_seconds=float(match[2]),skip_count=skipped,status='PASS' if result.returncode==0 and not changed and not skipped else 'FAIL',
            log='tests.log',log_sha256=sha256(destination.read_bytes()).hexdigest(),
            package_source_sha256=source,test_input_sha256=tests,source_and_tests_unchanged=not changed))
    (ROOT/'docs/validation/current.json').write_text(json.dumps(evidence,ensure_ascii=False,indent=2),encoding='utf8')
    print(json.dumps({key:value for key,value in evidence['full_regression'].items()
                      if not key.endswith('sha256')},indent=2))
    return 0 if evidence['status'].startswith('PASS') else 1

if __name__=='__main__':
    raise SystemExit(main())
