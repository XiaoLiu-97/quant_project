"""Cheap, read-only data gates before an expensive solve and CLO replay.

Readiness means that the supplied snapshot can enter the configured research
workflow. It says nothing about solver feasibility, live Bloomberg access,
rating calibration or permission to execute a trade. No engine or solver runs
here; complete execution retains its own independent validation.
"""

from dataclasses import dataclass
from decimal import Decimal

from trident.domain.models import InputValidationError
from trident.optimization import OptimizationRequest
from trident.optimization.models import TradeSide
from trident.optimization.universe import CandidateUniverseValidator

from .candidate_search import ClosingPoolSearchRequest
from .construction import validate_closing_pool_inputs


@dataclass(frozen=True)
class ReadinessIssue:
    """One actionable input observation, optionally tied to a loan or variant."""
    severity: str
    code: str
    message: str
    identifier: str | None = None


@dataclass(frozen=True)
class OptimizationReadiness:
    """Immutable data evidence; not a proposal, projected return or trade order."""
    mode: str
    holdings_count: int
    quote_count: int
    candidate_count: int
    admitted_count: int
    quarantined_count: int
    variant_count: int
    issues: tuple[ReadinessIssue, ...]
    checks_not_run: tuple[str, ...] = (
        "SOLVER_FEASIBILITY_AND_OPTIMALITY", "BASELINE_AND_TARGET_CLO_PROJECTIONS",
        "FUTURE_LIMIT_AND_COVERAGE_TESTS", "COMPLETE_MARKET_FIXING_AND_CURVE_COVERAGE",
        "BLOOMBERG_FIELD_ENTITLEMENT_OR_REFRESH", "AGENCY_RATING_FACTOR_CALIBRATION",
        "CONTRACT_AND_LEGAL_ELIGIBILITY_VERIFICATION", "DEALER_SIZE_AND_EXECUTION",
    )

    @property
    def ready(self) -> bool:
        """No known input blocker; warnings and unperformed checks remain visible."""
        return not any(row.severity == "ERROR" for row in self.issues)

    @property
    def status(self) -> str:
        return "DATA_READY" if self.ready else "NOT_READY"


class OptimizationReadinessService:
    """Validate frozen data and unsupported replay scope without calculations."""

    def check(self, request: OptimizationRequest | ClosingPoolSearchRequest) -> OptimizationReadiness:
        """Check quote units and admission; preserve every exclusion reason.

        Magnitude checks are warnings only: distressed clean prices and unusual
        loan spreads can be real. Unknown contracts/provenance never receive
        fabricated replacements to make an optimization pass.
        """
        if not isinstance(request, (OptimizationRequest, ClosingPoolSearchRequest)):
            raise InputValidationError("readiness requires a typed optimization or closing-search request")
        search = request if isinstance(request, ClosingPoolSearchRequest) else None
        mandate = search.base_mandate if search is not None else request
        issues: list[ReadinessIssue] = []
        if not mandate.quotes:
            issues.append(ReadinessIssue("ERROR", "EMPTY_QUOTES", "Add frozen BUY/SELL rows in Trade Candidates."))
        for quote in mandate.quotes:
            identifier = quote.asset.asset_id
            if quote.clean_price_pct <= 2:
                issues.append(ReadinessIssue("WARNING", "CHECK_CLEAN_PRICE_UNITS",
                    "clean_price_pct uses price points: 99 means 99% of par. Confirm this unusually low price.", identifier))
            if 0 < quote.asset.spread_bps < 1:
                issues.append(ReadinessIssue("WARNING", "CHECK_SPREAD_UNITS",
                    "spread_bps uses basis points: 350 means 3.50%. Confirm the supplied margin.", identifier))
            if abs(quote.accrued_per_par) > Decimal(".2"):
                issues.append(ReadinessIssue("WARNING", "CHECK_ACCRUED_UNITS",
                    "accrued_per_par is EUR per EUR1 par; 0.02 means EUR2 per EUR100 par.", identifier))
        admitted_count = quarantined_count = candidate_count = variant_count = 0
        if search is not None:
            baseline = search.baseline
            candidate_count, variant_count = len(search.candidate_snapshot.candidates), len(search.variants)
            if baseline.clo_terms is None or not baseline.notes:
                issues.append(ReadinessIssue("ERROR", "CLO_REQUIRED", "Closing search requires CLO mode and a complete capital stack."))
            elif mandate.settlement_date != baseline.clo_terms.closing_date:
                issues.append(ReadinessIssue("ERROR", "CLOSING_DATE_MISMATCH", "Candidate settlement must equal the redesigned CLO closing date."))
            if baseline.credit_events:
                issues.append(ReadinessIssue("ERROR", "EXPLICIT_EVENTS_UNSUPPORTED", "Closing search currently does not support explicit per-loan credit events."))
            if baseline.imported_collateral is not None:
                issues.append(ReadinessIssue("ERROR", "IMPORTED_COLLATERAL_UNSUPPORTED", "Use native identified contracts; imported cashflows do not reproject a changed target pool."))
            policy = None if baseline.clo_terms is None else baseline.clo_terms.adjusted_oc_policy
            if policy is not None and policy.use_asset_level_test_data:
                for quote in mandate.quotes:
                    if quote.side is TradeSide.BUY:
                        issues.append(ReadinessIssue("ERROR", "NEW_BUY_OC_CLASSIFICATION_UNSUPPORTED",
                            "Asset-level adjusted OC replay needs sourced CCC/discount classifications; candidate inputs do not yet transport them.", quote.asset.asset_id))
            admission = CandidateUniverseValidator().validate(search.candidate_snapshot, search.admission_policy)
            admitted_count, quarantined_count = len(admission.admitted), len(admission.quarantined)
            # Every quoted row is submitted to the optimizer. Silently dropping
            # a quarantined row would change the user's universe and mandate.
            quoted = {row.asset.asset_id for row in mandate.quotes}
            known = {row.asset_id for row in admission.admitted}
            for row in admission.quarantined:
                issues.append(ReadinessIssue("ERROR" if row.asset_id in quoted else "WARNING",
                    "QUARANTINED_CANDIDATE", "; ".join(row.reasons), row.asset_id))
            absent = quoted - known - {row.asset_id for row in admission.quarantined}
            for identifier in sorted(absent):
                issues.append(ReadinessIssue("ERROR", "MISSING_CANDIDATE", "Quoted asset is absent from the frozen candidate snapshot.", identifier))
            # Reuse execution's pure input gate rather than maintain a second
            # interpretation of selected factors or retained SELL contracts.
            if not any(row.severity == "ERROR" for row in issues):
                try:
                    validate_closing_pool_inputs(baseline, mandate, search.candidate_snapshot, search.admission_policy)
                except InputValidationError as error:
                    issues.append(ReadinessIssue("ERROR", "COMMON_INPUT_MISMATCH", str(error)))
            for variant in search.variants:
                for name in ("maximum_overall_factor", "maximum_bsl_factor", "minimum_spread_bps", "maximum_trade_par"):
                    prior, value = getattr(mandate.limits, name), getattr(variant, name)
                    relaxes = value is not None and prior is not None and (
                        value < prior if name == "minimum_spread_bps" else value > prior)
                    if relaxes:
                        issues.append(ReadinessIssue("ERROR", "VARIANT_RELAXES_MANDATE", f"{name} must tighten or preserve the base mandate.", variant.candidate_id))
            issues.append(ReadinessIssue("WARNING", "CLOSING_REDESIGN_SCOPE",
                "This workflow redesigns the closing pool; it does not settle dated reinvestment trades or report realized trading P&L."))
        else:
            issues.append(ReadinessIssue("WARNING", "STATIC_ONLY_SCOPE",
                "Static mode checks typed inputs only; it does not require full candidate contracts or price/rating admission."))
        issues.append(ReadinessIssue("WARNING", "FACTOR_LINEAGE_UNVERIFIED",
            "Factor provenance identifies the selected mapping; it does not verify agency-specific rating selection, notching or Bloomberg entitlement."))
        return OptimizationReadiness("CANDIDATE" if search is not None else "STATIC",
            len(mandate.holdings), len(mandate.quotes), candidate_count, admitted_count,
            quarantined_count, variant_count, tuple(issues))
