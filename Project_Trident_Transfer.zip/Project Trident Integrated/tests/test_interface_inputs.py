"""Input-boundary tests: ownership, units, joins and current opening evidence."""
from datetime import date, datetime
from decimal import Decimal

import unittest
from openpyxl import Workbook
from openpyxl.workbook.defined_name import DefinedName
from openpyxl.worksheet.table import Table, TableColumn
from openpyxl.utils.cell import get_column_letter, range_boundaries

from trident.adapters import interface_inputs as ui
from trident.adapters.legacy_inputs import LEGACY_INPUTS
from trident.application.clo_services import TridentModelService
from trident.domain.models import InputValidationError
from trident.market.rates import RequiredFixingError


def _name(w,key,sheet,ref):
    w.defined_names.add(DefinedName(ui.UI_PREFIX+key,attr_text=f"'{sheet.title}'!{ref}"))


def _table(w,key,mapping,records,extra=()):
    sheet=w.create_sheet(key[:31]);headers=list(mapping)+[x[0] for x in extra]
    sheet.append(headers)
    for record in records:sheet.append([record.get(v) for v in mapping.values()]+[x[1] for x in extra])
    ref=f"A1:{get_column_letter(len(headers))}{len(records)+1}"
    table=Table(displayName=ui.TABLE_PREFIX+key,ref=ref)
    table.tableColumns=[TableColumn(id=i,name=h) for i,h in enumerate(headers,1)]
    sheet.add_table(table);_name(w,key,sheet,ref)
    return sheet


def _cell(w,key,column,row=2):
    sheet=next(s for s in w if any(t.displayName==ui.TABLE_PREFIX+key for t in s.tables.values()))
    headers=[c.value for c in sheet[1]]
    return sheet.cell(row,headers.index(column)+1)


def workbook_fixture():
    """Small declared synthetic fixture, independent of any production file."""
    w=Workbook();w.remove(w.active)
    overrides={
        'pricing_date':date(2026,11,20),'closing_date':date(2026,11,20),'first_note_payment_date':date(2027,2,20),
        'maturity_date':date(2029,11,20),'reinvestment_end_date':date(2027,11,20),
        'clo_size':Decimal('20000000'),'opening_collateral_par':Decimal('20000000'),
        'collateral_purchase_price':Decimal('.9955'),'purchased_accrued_interest':Decimal('999'),
        'reinvestment_enabled':'No','optional_call_enabled':'No','refinancing_enabled':'No',
        'incentive_management_fee_enabled':'No','credit_prepayment_overlay':'Off',
        'minimum_collateral_was':Decimal('.02'),'liability_reference_floor':Decimal('.01'),
        'maximum_single_obligor':Decimal('1'),'maximum_industry':Decimal('1'),
        'original_annual_default_rate':Decimal('.02'),'reinvestment_annual_default_rate':Decimal('.04'),
        'use_asset_level_test_data':'No',
    }
    values={f.field_id:overrides.get(f.field_id,f.default_value) for f in LEGACY_INPUTS}
    coverage={'include_deferred_interest_in_ic':False,'include_deferred_interest_in_oc':True,
        'principal_coupon_policy':'NON_DEFERRABLE_AND_CONTROLLING','interest_diversion_test_enabled':False,
        'interest_diversion_test_class_id':'A','interest_diversion_test_oc_minimum':Decimal('1.06'),
        'interest_diversion_test_max_fraction':Decimal('.5'),'interest_diversion_test_end_date':date(2027,11,20),'interest_diversion_mode':'ALL_RESIDUAL'}
    main=_table(w,'deal_assumptions',{'Assumption':'label','Value':'value'},
        [{'label':f.label,'value':values[f.field_id]} for f in LEGACY_INPUTS]+[{'label':k,'value':v} for k,v in coverage.items()])
    for n,f in enumerate(LEGACY_INPUTS,2):_name(w,f.field_id,main,f'B{n}')
    for n,key in enumerate(coverage,len(LEGACY_INPUTS)+2):_name(w,key,main,f'B{n}')
    home=w.create_sheet('Home');home['D7']='New Issue';_name(w,'workflow',home,'D7');home['D3']='1.0';_name(w,'schema',home,'D3')
    _table(w,'factor_mapping',ui.FACTOR,[{'system':None,'version':None,'bucket':None,'factor':None,'is_synthetic':None,'source':None}])
    _table(w,'limits',ui.LIMIT,[{'limit_id':'COUNTRY','metric':'LARGEST_COUNTRY_FRACTION','direction':'MAXIMUM','threshold':Decimal('.75'),'phases':'CLOSING,REINVESTMENT','enabled':True}])
    identities=[];terms=[];details=[];ratings=[];pool=[]
    for key,kind,price,accrued in [('I','INFRA',90,Decimal('123.45')),('B','BSL',105,Decimal('456.78'))]:
        identities.append(dict(loan_id=key,obligor_id='OB'+key,asset_class=kind,financing_type='PROJECT_FINANCE' if kind=='INFRA' else 'CORPORATE',currency='EUR',country_code='DE' if key=='I' else 'FR',sector='energy' if key=='I' else 'services',maturity_date_unadjusted=date(2028,11,20),credit_status='PERFORMING'))
        terms.append(dict(loan_id=key,cashflow_projection_start_date=date(2026,11,20),coupon_type='FLOATING',rate_index='EURIBOR_3M',spread_bps=300,index_floor_bps=0,day_count='ACT_360',frequency_months=3,amortization_type='BULLET',initial_par=10000000,seniority='SENIOR',secured=True,contract_source='EXPLICIT_SYNTHETIC_TEST'))
        details.append(dict(loan_id=key,schedule_anchor_day=20,end_of_month=False,business_day_convention='MODIFIED_FOLLOWING',holiday_calendar='TARGET',accrual_date_basis='ADJUSTED',fixing_lag_target_business_days=2,payment_lag_business_days=0,stub_convention='SHORT_LAST',interest_mode='CASH',pik_fraction=0,construction_risk=False,revolver=False,pik=False,classification_source='EXPLICIT_SYNTHETIC_TEST'))
        ratings.append(dict(loan_id=key,use_for_model=False))
        pool.append(dict(loan_id=key,current_par=10000000,purchase_price_pct=price,acquired_accrued_interest=accrued,trade_permission='LOCKED' if key=='I' else 'TRADABLE',par_as_of_date=date(2026,11,20)))
    _table(w,'assets',ui.IDENTITY,identities,extra=(('Selected agency','=1/0'),('Selected rating','=1/0')))
    _table(w,'asset_terms',ui.TERMS,terms);_table(w,'asset_details',ui.DETAILS,details)
    _table(w,'asset_ratings',ui.RATINGS,ratings,extra=(('Selected asset key','=1/0'),))
    _table(w,'pool',ui.POOL,pool,extra=(('Selected rating','=1/0'),('OC input status','=1/0')))
    _table(w,'stack',ui.STACK,[dict(class_id='A',payment_priority=1,instrument_type='DEBT',nominal_amount=15000000,issue_price_pct=100,rate_index='EURIBOR_1M',spread_bps=100,oc_minimum=Decimal('1.05'),ic_minimum=Decimal('1.05'),interest_deferrable=False,day_count='ACT_365F',holiday_calendar='TARGET'),dict(class_id='SUB',payment_priority=2,instrument_type='EQUITY',nominal_amount=5000000,interest_deferrable=False,holiday_calendar='TARGET')])
    _table(w,'principal_schedule',ui.PRINCIPAL,[dict(loan_id='I',currency='EUR',case='BASE',source='Blank instructional row')])
    _table(w,'asset_events',ui.EVENT,[dict(loan_id='I',record_type='DEFAULT_EVENT',case='BASE',source='Blank instructional row')])
    _table(w,'scenario_edits',ui.SCENARIO,[dict(scenario_id='FEE',target='CONTROL',identifier='DEAL',field='senior_management_fee_bps',value=20,enabled=False,applies_from='Base snapshot')])
    _table(w,'trade_universe',ui.QUOTE,[dict(loan_id='B',allow_buy=True,allow_sell=True)])
    settings={'Candidate search enabled':False,'Selection objective':'MAX_EQUITY_IRR','Linear candidate objective':'MIN_FACTOR','Target collateral par':20000000,'Declared incremental cash':0,'Minimum cash after trades':0,'Gross BUY + SELL par cap':1000000,'Settlement / closing date':date(2026,11,20),'Minimum candidate equity IRR':None,'Quote snapshot ID':None,'Captured at (timezone)':None,'Snapshot source':None,'Maximum quote age':24,'Admitted quote quality':'FIRM'}
    _table(w,'optimizer',{'Setting / constraint':'label','Value':'value'},[dict(label=k,value=v) for k,v in settings.items()])
    _table(w,'pm_constraints',{'Constraint':'label','Value':'value'},[dict(label=k,value=v) for k,v in {'Maximum overall factor':2300,'Maximum BSL factor':3300,'Minimum quoted spread':None,'Maximum sector share':1,'Maximum obligor share':1,'Maximum country share':1}.items()])
    opening_values=[('Workflow','=trident_ui_workflow'),('Opening timing','POST_DISTRIBUTION'),('Opening as of',None),('Opening statement source',None),('Original schedule start',None),('Original collateral par',None),('Current equity value',None),('Equity value date',None),('Equity value source','=IF(D8="","",D8)')]
    _table(w,'opening',{'Opening parameter':'label','Value':'value','Source':'source'},[dict(label=k,value=v) for k,v in opening_values])
    _table(w,'opening_accounts',{'Account / designation':'account','Balance (EUR)':'balance','Source':'source'},[dict(account=k) for k in ui.ACCOUNT_FIELDS])
    _table(w,'opening_fees',{'Fee claim':'fee_type','Unpaid (EUR)':'amount','Source':'source'},[dict(fee_type=k) for k in ui.FEE_FIELDS])
    market=w.create_sheet('Market Data');market['B3']=date(2026,11,20)
    for c,v in enumerate(('Curve Date','EURIBOR_1M','EURIBOR_3M','EURIBOR_6M','Source'),1):market.cell(5,c,v)
    for i in range(240):
        year=2026+(10+i)//12;month=(10+i)%12+1
        for c,v in enumerate((date(year,month,1),Decimal('.02'),Decimal('.025'),Decimal('.03')),1):market.cell(6+i,c,v)
    for c,v in enumerate(('TenorYears','ESTR','SOFR','SONIA'),7):market.cell(5,c,v)
    for i in range(20):
        for c,v in enumerate((Decimal(i+1)/4,Decimal('.025'),Decimal('.025'),Decimal('.025')),7):market.cell(6+i,c,v)
    for key,cell,value in [('market_date','B3',date(2026,11,20)),('market_mode','P7','SYNTHETIC_FLAT'),('synthetic_rate','P9',Decimal('.025')),('term_lookup','P11','MONTH_BUCKET'),('zero_basis','P13','ACT/365F'),('zero_compounding','P15','CONTINUOUS')]:market[cell]=value;_name(w,key,market,cell)
    _name(w,'term_curve',market,'A5:E205');_name(w,'zero_curve',market,'G5:J25')
    return w


def _existing(w):
    w['Home']['D7']='Existing CLO'
    asof=date(2027,2,22)
    for n in (2,3):_cell(w,'pool','Holding as of',n).value=asof
    opening={'Opening as of':asof,'Opening statement source':'KNOWN_SYNTHETIC_STATEMENT','Original schedule start':date(2026,11,20),'Original collateral par':20000000,'Current equity value':3000000,'Equity value date':asof}
    for n in range(2,11):
        label=_cell(w,'opening','Opening parameter',n).value
        if label in opening:
            _cell(w,'opening','Value',n).value=opening[label]
            _cell(w,'opening','Source',n).value='EXPLICIT_SYNTHETIC_EVIDENCE'
    for n in range(2,10):
        _cell(w,'opening_accounts','Balance (EUR)',n).value=0
        _cell(w,'opening_accounts','Source',n).value='KNOWN_ZERO'
    for n in range(2,6):
        _cell(w,'opening_fees','Unpaid (EUR)',n).value=0
        _cell(w,'opening_fees','Source',n).value='KNOWN_ZERO'
    _cell(w,'stack','Opening unpaid coupon (EUR)').value=0
    _cell(w,'stack','Claim source').value='KNOWN_ZERO'
    # Native positions require an explicit sourced opening coupon entitlement
    # for every seasoned loan, even at an accrual boundary. No earned prefix
    # or historical fixing is inferred from the as-of date or purchase price.
    events=w['asset_events'];events.delete_rows(2,events.max_row)
    for key in ('I','B'):
        events.append([key,'OPENING_ACCRUED_POST_ASOF_ONLY',asof,0,'EUR','BASE','EXPLICIT_POST_DISTRIBUTION_ENTITLEMENT'])
        events.append([key,'OPENING_FIXED_RATE',date(2027,2,18),Decimal('.025'),'annual fraction','BASE','EXPLICIT_TEST_INDEX_FIXING'])
    next(iter(events.tables.values())).ref='A1:G5'
    w.defined_names['trident_ui_asset_events'].attr_text="'asset_events'!A1:G5"


class InterfaceInputTests(unittest.TestCase):
    def test_static_and_candidate_modes_are_explicitly_mutually_exclusive(self):
        w=workbook_fixture();w['Home']['D5']=True;_name(w,'optimizer_enabled',w['Home'],'D5')
        for row in range(2,w['optimizer'].max_row+1):
            if _cell(w,'optimizer','Setting / constraint',row).value=='Candidate search enabled':
                candidate_cell=_cell(w,'optimizer','Value',row)
                candidate_cell.value=True
                break
        with self.assertRaisesRegex(InputValidationError,'Select only one optimization mode'):
            ui.read_interface_inputs(w)
        w['Home']['D5']=False
        candidate=ui.read_interface_inputs(w)
        self.assertTrue(candidate.controls['candidate_search_enabled'])
        self.assertFalse(candidate.controls['optimizer_enabled'])
        candidate_cell.value=False;w['Home']['D5']=True
        static=ui.read_interface_inputs(w)
        self.assertTrue(static.controls['optimizer_enabled'])
        self.assertFalse(static.controls['candidate_search_enabled'])

    def test_unheld_library_bespoke_and_coupon_steps_project_as_reference_contract(self):
        w=workbook_fixture()
        for key in ('assets','asset_terms','asset_details','asset_ratings'):
            s=w[key];s.append([c.value for c in s[2]]);s.cell(4,1,'U')
            table=next(iter(s.tables.values()));table.ref=f'A1:{get_column_letter(len(table.tableColumns))}4'
            w.defined_names[ui.UI_PREFIX+key].attr_text=f"'{s.title}'!{table.ref}"
        _cell(w,'assets','Obligor ID',4).value='OBU'
        _cell(w,'assets','Asset type',4).value='BSL'
        _cell(w,'asset_terms','Principal strategy',4).value='BESPOKE'
        _cell(w,'asset_terms','Amortization reference face',4).value=5000000
        s=w['principal_schedule'];s.delete_rows(2,s.max_row)
        s.append(['U',date(2027,11,20),2000000,'EUR','BASE','EXPLICIT_CONTRACT'])
        s.append(['U',date(2028,11,20),3000000,'EUR','BASE','EXPLICIT_CONTRACT'])
        next(iter(s.tables.values())).ref='A1:F3';w.defined_names['trident_ui_principal_schedule'].attr_text="'principal_schedule'!A1:F3"
        s=w['asset_events'];s.delete_rows(2,s.max_row)
        s.append(['U','COUPON_STEP',date(2027,5,20),400,'bps','BASE','EXPLICIT_CONTRACT'])
        inputs=ui.read_interface_inputs(w)
        assert len(inputs.request.cashflow_request.positions)==2
        assert len(inputs.principal_schedule_records)==0
        assert len(inputs.library_principal_schedule_records)==2
        reference=ui.project_library_cashflows(inputs,exclude_held=True)
        assert reference.basis=='REFERENCE_CONTRACT' and not reference.failures
        assert {row.loan_id for row in reference.cashflows}=={'U'}
        assert sum(row.principal_repayment for row in reference.cashflows)==Decimal(5000000)
        assert reference.reference_positions[0].terms.coupon_steps[0].spread_bps==Decimal(400)
        assert reference.reference_positions[0].par_as_of_date==date(2026,11,20)
        # The same owned schedule must travel into a prospective new BUY, not
        # merely its Library chart. No agency rating is invented for admission.
        f=w['factor_mapping']
        for n,value in enumerate(('EXPLICIT_TEST','1.0','TEST_01',2000,True,'SYNTHETIC_FIXTURE'),1):f.cell(2,n,value)
        for row in (2,3,4):
            for header,value in [('Factor system','EXPLICIT_TEST'),('Factor version','1.0'),('Selected bucket','TEST_01'),('Factor source','SYNTHETIC_FIXTURE')]:_cell(w,'asset_ratings',header,row).value=value
        for row in range(2,w['optimizer'].max_row+1):
            label=_cell(w,'optimizer','Setting / constraint',row).value
            if label in {'Quote snapshot ID','Captured at (timezone)','Snapshot source'}:
                _cell(w,'optimizer','Value',row).value={'Quote snapshot ID':'TOY_SNAPSHOT','Captured at (timezone)':'2026-11-20T09:00:00+00:00','Snapshot source':'EXPLICIT_TEST_QUOTES'}[label]
        q=w['trade_universe'];headers=[c.value for c in q[1]]
        values={'Asset ID':'U','Allow buy':True,'Allow sell':False,'Ask / 100':100,'Ask size (EUR)':1000000,'Settlement date':date(2026,11,20),'Quote time':'2026-11-20T09:00:00+00:00','Quote source':'EXPLICIT_TEST_QUOTES','Quote quality':'FIRM','Buy accrued / par':0,'Trade fees / par':0,'Fixed BUY fee (EUR)':0}
        q.append([values.get(header) for header in headers]);t=next(iter(q.tables.values()));t.ref=f'A1:{get_column_letter(len(headers))}3';w.defined_names['trident_ui_trade_universe'].attr_text=f"'trade_universe'!{t.ref}"
        inputs=ui.read_interface_inputs(w);search=ui.closing_candidate_request(inputs)
        candidate=next(c for c in search.candidate_snapshot.candidates if c.asset_id=='U')
        assert candidate.position.terms.amortization_type.value=='BESPOKE'
        assert [entry.amount for entry in candidate.position.terms.principal_schedule]==[Decimal(2000000),Decimal(3000000)]
        assert candidate.position.terms.coupon_steps[0].spread_bps==Decimal(400)
        assert candidate.ratings==()

    def test_partial_quote_is_rejected_when_static_research_is_enabled(self):
        w=workbook_fixture();w['Home']['D5']=True;_name(w,'optimizer_enabled',w['Home'],'D5')
        _cell(w,'trade_universe','Bid / 100').value=99
        with self.assertRaisesRegex(InputValidationError,'active frozen quote'):ui.read_interface_inputs(w)

    def test_actual_curves_require_exact_historical_fixings_and_keep_all_240_rows(self):
        w=workbook_fixture();w['Market Data']['P7']='MARKET_CURVES'
        inputs=ui.read_interface_inputs(w)
        with self.assertRaises(RequiredFixingError):
            inputs.request.cashflow_request.rate_provider.rate('EURIBOR_3M',date(2026,11,18))
        events=w['asset_events'];events.delete_rows(2,events.max_row)
        events.append(['EURIBOR_3M','FIXING',date(2026,11,18),Decimal('.023'),'annual fraction','BASE','ACTUAL_OBSERVED_FIXING'])
        next(iter(events.tables.values())).ref='A1:G2'
        inputs=ui.read_interface_inputs(w)
        assert len(inputs.input_snapshot['market:term_curve'])==240
        assert inputs.request.cashflow_request.rate_provider.rate('EURIBOR_3M',date(2026,11,18))==Decimal('.023')

    def test_existing_projection_uses_current_equity_value_without_closing_funding(self):
        w=workbook_fixture();_existing(w)
        inputs=ui.read_interface_inputs(w)
        result=TridentModelService().run(inputs.request)
        assert result.cashflows.funding is None
        assert result.equity_cashflows[0].payment_date==date(2027,2,22)
        assert result.equity_cashflows[0].amount==Decimal('-3000000')
        assert result.clo_opening_state==inputs.request.clo_opening_state
        assert result.clo.status.value=='COMPLETED'

    def test_optional_static_research_toggle_has_owning_cell_and_fingerprint(self):
        w=workbook_fixture();w['Home']['D5']=False;_name(w,'optimizer_enabled',w['Home'],'D5')
        baseline=ui.read_interface_inputs(w)
        w['Home']['D5']=True;changed=ui.read_interface_inputs(w)
        assert changed.controls['optimizer_enabled'] is True
        assert changed.input_ownership['scalar:optimizer_enabled']['ref']=='D5'
        assert changed.input_fingerprint!=baseline.input_fingerprint

    def test_explicit_test_factor_inputs_enable_static_research_without_fake_agency_ratings(self):
        w=workbook_fixture();f=w['factor_mapping']
        for n,value in enumerate(('EXPLICIT_TEST','1.0','TEST_01',2000,True,'SYNTHETIC_FIXTURE'),1):f.cell(2,n,value)
        for row in (2,3):
            for header,value in [('Factor system','EXPLICIT_TEST'),('Factor version','1.0'),('Selected bucket','TEST_01'),('Factor source','SYNTHETIC_FIXTURE')]:
                _cell(w,'asset_ratings',header,row).value=value
        inputs=ui.read_interface_inputs(w)
        mandate=ui.static_optimization_request(inputs)
        assert mandate.limits.maximum_country_share==Decimal('.75')
        assert mandate.limits.minimum_spread_bps==Decimal(200)
        assert inputs.request.factor_mapping.is_synthetic is True
        assert all(asset['agency_rating'] is None for asset in inputs.assets)
        assert {asset.asset.factor for asset in mandate.holdings}=={Decimal(2000)}

    def test_individual_acquisition_note_index_day_count_and_floor_are_executed(self):
        inputs=ui.read_interface_inputs(workbook_fixture())
        cash=inputs.request.cashflow_request
        assert [(p.clean_price_pct,p.accrued_interest) for p in cash.purchases]==[(Decimal(90),Decimal('123.45')),(Decimal(105),Decimal('456.78'))]
        funding=ui.FundingEngine().calculate(cash.purchases,cash.issues,upfront_fees=cash.upfront_fees,cash_reserve=cash.cash_reserve,closing_cost_budget=cash.closing_cost_budget)
        assert funding.asset_clean_cost==Decimal('19500000.00')
        assert funding.acquired_accrued_interest==Decimal('580.23')
        assert inputs.request.clo_terms.incentive_initial_equity_funding==funding.equity_cash_funding
        note=inputs.request.notes[0]
        assert (note.rate_index,note.day_count.value,note.index_floor)==('EURIBOR_1M','ACT/365F',Decimal('.01'))
        assert [x.clean_price_fraction for x in inputs.request.oc_asset_data]==[Decimal('.90'),Decimal('1.05')]


    def test_lookup_formula_caches_are_unused_and_unknown_credit_stays_unavailable(self):
        inputs=ui.read_interface_inputs(workbook_fixture())
        assert all(e.rating_bucket is None for e in inputs.request.exposures)
        assert all(e.recovery_rate is None for e in inputs.request.exposures)
        assert inputs.request.factor_mapping is None
        assert inputs.warnings
        assert len(inputs.input_snapshot['market:term_curve'])==240


    def test_owning_formula_or_error_is_rejected(self):
        for value in ['=1+1','#VALUE!']:
            w=workbook_fixture();c=_cell(w,'pool','Purchase price / 100');c.value=value
            if value.startswith('#'):c.data_type='e'
            with self.assertRaisesRegex(InputValidationError,'formula/error'):ui.read_interface_inputs(w)


    def test_duplicate_labels_resolve_by_validated_field_names(self):
        inputs=ui.read_interface_inputs(workbook_fixture())
        assert inputs.controls['legacy_original_annual_default_rate']==Decimal('.02')
        assert inputs.controls['legacy_reinvestment_annual_default_rate']==Decimal('.04')
        w=workbook_fixture();w.defined_names['trident_ui_original_annual_default_rate'].attr_text="'Home'!D7"
        with self.assertRaisesRegex(InputValidationError,'owning labelled Value'):ui.read_interface_inputs(w)


    def test_duplicate_selected_ratings_and_orphan_holding_fail(self):
        w=workbook_fixture();s=w['asset_ratings'];t=next(iter(s.tables.values()));t.ref='A1:N4'
        headers=[c.value for c in s[1]]
        for n in (2,4):
            s.cell(n,1,'I');s.cell(n,headers.index('Use for model')+1,True)
        w.defined_names['trident_ui_asset_ratings'].attr_text="'asset_ratings'!A1:N4"
        with self.assertRaisesRegex(InputValidationError,'More than one Use for model'):ui.read_interface_inputs(w)
        w=workbook_fixture();_cell(w,'pool','Asset ID').value='ORPHAN'
        with self.assertRaisesRegex(InputValidationError,'missing from Asset Library'):ui.read_interface_inputs(w)


    def test_accidental_date_format_cannot_change_a_numeric_assumption(self):
        w=workbook_fixture();name=w.defined_names['trident_ui_long_dated_oc_valuation_fraction'];s,(l,t,r,b)=ui.NamedWorkbook(w).region(name.name)
        s.cell(t,l).value=datetime(1900,1,1);s.cell(t,l).number_format='dd-mmm-yyyy'
        assert ui.read_interface_inputs(w).controls['legacy_long_dated_oc_valuation_fraction']==1


    def test_flat_anchor_and_actual_curve_date_are_distinct(self):
        w=workbook_fixture();w['Market Data']['B3']=date(2026,8,4)
        inputs=ui.read_interface_inputs(w)
        assert inputs.controls['valuation_date']==date(2026,11,20)
        assert inputs.controls['market_curve_as_of']==date(2026,8,4)
        assert inputs.request.cashflow_request.rate_provider.cash_curves['ESTR'].valuation_date==date(2026,8,4)
        w['Market Data']['P7']='MARKET_CURVES'
        with self.assertRaisesRegex(InputValidationError,'Pricing Date must match'):ui.read_interface_inputs(w)


    def test_current_opening_requires_all_sourced_balances_and_keeps_scenarios(self):
        w=workbook_fixture();_existing(w);_cell(w,'scenario_edits','Enabled').value=True
        inputs=ui.read_interface_inputs(w)
        state=inputs.request.clo_opening_state
        assert state.as_of_date==date(2027,2,22)
        assert state.initial_collateral_par==20000000
        assert state.principal_cash==state.pending_principal_cash==state.held_diversion_principal==0
        assert len(state.note_coupon_claims)==1
        assert inputs.request.forward_equity_value==3000000
        assert inputs.request.clo_terms.closing_date==date(2026,11,20)
        assert len(inputs.scenarios)==1
        _cell(w,'opening_accounts','Balance (EUR)').value=None
        with self.assertRaisesRegex(InputValidationError,'account balance'):ui.read_interface_inputs(w)


    def test_current_mark_requires_snapshot_date_and_provenance(self):
        w=workbook_fixture();_cell(w,'pool','Current OC mark / 100').value=75
        _cell(w,'pool','OC mark as of').value=date(2026,11,19);_cell(w,'pool','OC mark source').value='KNOWN_MARK'
        with self.assertRaisesRegex(InputValidationError,'held snapshot date'):ui.read_interface_inputs(w)
        _cell(w,'pool','OC mark as of').value=date(2026,11,20)
        assert ui.read_interface_inputs(w).request.oc_asset_data[0].market_price_fraction==Decimal('.75')


    def test_explicit_dated_default_and_recovery_translate_without_proxy_rating(self):
        w=workbook_fixture();s=w['asset_events'];t=next(iter(s.tables.values()));t.ref='A1:G3';w.defined_names['trident_ui_asset_events'].attr_text="'asset_events'!A1:G3"
        s.append(['I','RECOVERY_EVENT',date(2027,8,20),Decimal('.4'),'fraction','BASE','EXPLICIT_RECOVERY'])
        _cell(w,'asset_events','Effective date').value=date(2027,2,20)
        events=ui.read_interface_inputs(w).request.credit_events
        assert len(events)==1 and events[0].recoveries[0].recovery_fraction==Decimal('.4')


    def test_legal_static_limits_cannot_be_relaxed_by_pm_and_policy_changes_fingerprint(self):
        w=workbook_fixture();first=ui.read_interface_inputs(w)
        assert first.controls['optimizer_maximum_country_share']==Decimal('.75')
        assert first.controls['optimizer_minimum_spread_bps']==Decimal(200)
        second=ui.read_interface_inputs(w,policy=ui.InterfaceExecutionPolicy(profile_id='REVIEWED_CUSTOM',cash_account_day_count='ACT/365F'))
        assert first.input_fingerprint!=second.input_fingerprint
        _cell(w,'pool','Purchased accrued (EUR)').value=Decimal('124.45')
        assert ui.read_interface_inputs(w).input_fingerprint!=first.input_fingerprint


    def test_transport_read_never_saves_or_mutates_workbook_inputs(self):
        w=workbook_fixture();before=[(s.title,c.coordinate,c.value,c.data_type) for s in w for row in s for c in row if c.value is not None]
        ui.read_interface_inputs(w)
        after=[(s.title,c.coordinate,c.value,c.data_type) for s in w for row in s for c in row if c.value is not None]
        assert before==after
