"""Independent financial meanings survive the compact report transport."""
from dataclasses import replace
from decimal import Decimal
from datetime import date
from pathlib import Path
from tempfile import TemporaryDirectory
from types import SimpleNamespace
import unittest

from openpyxl import Workbook, load_workbook
from openpyxl.workbook.defined_name import DefinedName
from openpyxl.worksheet.table import Table

from test_opening_clo_acceptance import operating_request, note, state, NEXT, OPEN
from trident.adapters.interface_output import _mixed_formats
from trident.adapters.interface_package import WorkbookPackage
from trident.adapters.interface_reporting import case_tables, number_formats, unit_format, PREFIX
from trident.application.clo_services import TridentModelService
from trident.clo.models import DefaultedAssetOcTreatment
from trident.credit import DefaultEvent, RecoveryEvent
from trident.funding.engine import DebtIssue

D = Decimal


def reports(request):
    result = TridentModelService().run(request)
    inputs = SimpleNamespace(
        capital=tuple({'class_id':n.class_id, 'instrument_type':'DEBT',
                       'nominal_amount':n.opening_balance, 'payment_priority':n.payment_priority}
                      for n in request.notes) +
                ({'class_id':'EQ', 'instrument_type':'EQUITY', 'nominal_amount':D(20),
                  'payment_priority':len(request.notes)+1},),
        library_assets=({'loan_id':'L', 'credit_status':'PERFORMING'},),
    )
    tables, audit = case_tables(SimpleNamespace(request=request, result=result), inputs)
    return result, tables, audit


class InterfaceReportingFinancialTests(unittest.TestCase):
    def test_existing_mark_label_and_dated_net_cash_have_one_return_basis(self):
        result, tables, _ = reports(operating_request())
        dashboard = {r['Metric']:r for r in tables[PREFIX+'dashboard']}
        self.assertEqual(dashboard['Current equity value']['Saved Base Case'], D(18))
        self.assertNotIn('Equity funding', dashboard)
        equity = tables[PREFIX+'equity_cashflows']
        dated={}
        for r in equity:
            dated[r['Equity cash date']]=dated.get(r['Equity cash date'],D(0))+r['Cashflow (EUR)']
        self.assertEqual(dated,{OPEN:D(-18),NEXT:D('21.82')})
        self.assertEqual(equity[0]['Source'], 'CURRENT_EQUITY_VALUE')
        self.assertAlmostEqual(float(dashboard['Equity MOIC']['Saved Base Case']),float(D('21.82')/D(18)),places=12)
        hand_irr = (float(D('21.82')/D(18))) ** (365/91) - 1
        self.assertAlmostEqual(float(result.equity_irr.value),hand_irr,places=9)
        view = tables[PREFIX+'view_equity']
        self.assertEqual(view[-1]['Cumulative net cashflow'],D('3.82'))
        self.assertEqual(sum(r['Net cashflow'] for r in view),sum(r.amount for r in result.equity_cashflows))

    def test_scope_measurements_retain_their_actual_value_and_availability(self):
        result,tables,_=reports(operating_request())
        rows={r['Key']:r for r in tables[PREFIX+'view_scope_metrics']}
        for metric in result.opening_portfolio.metrics:
            row=rows['Whole|'+metric.name]
            self.assertEqual(row['Value'],'n.a.' if metric.value is None else metric.value)
            self.assertEqual(row['Data status'],metric.status.value)
            self.assertEqual(row['Unit'],metric.unit)
        self.assertEqual(rows['BSL|ASSET_COUNT']['Value'],1)
        self.assertEqual(rows['BSL|WARF']['Value'],'n.a.')
        self.assertNotEqual(rows['BSL|WARF']['Data status'],'AVAILABLE')
        self.assertEqual(rows['INFRA|ASSET_COUNT']['Value'],0)
        self.assertEqual(rows['INFRA|SELECTED_RATING_COVERAGE']['Value'],'n.a.')
        self.assertEqual(rows['INFRA|SELECTED_RATING_COVERAGE']['Data status'],'NOT_APPLICABLE')

    def test_disabled_coverage_does_not_publish_a_measured_headroom(self):
        baseline = operating_request()
        request = replace(baseline,notes=(replace(baseline.notes[0],oc_minimum=D('1.1'),ic_minimum=D('1.2')),),
                          clo_terms=replace(baseline.clo_terms,coverage_tests_enabled=False))
        _,tables,_ = reports(request)
        row, = tables[PREFIX+'view_coverage_minima']
        self.assertEqual(row['Minimum gate OC headroom'],'n.a.')
        self.assertEqual(row['Minimum gate IC headroom'],'n.a.')
        self.assertEqual(row['Minimum gate OC date'],'n.a.')
        self.assertEqual(row['Redemption period'],2)
        self.assertEqual(tables[PREFIX+'view_coverage'][0]['Gate OC status'],'NOT_CONFIGURED')

    def test_unconfigured_gates_stay_unavailable_and_fixed_pool_has_no_was(self):
        _,tables,_ = reports(operating_request())
        row, = tables[PREFIX+'view_coverage_minima']
        self.assertEqual(row['Minimum gate OC headroom'],'n.a.')
        self.assertEqual(row['Minimum gate IC headroom'],'n.a.')
        scopes = {r['scope']:r for r in tables[PREFIX+'view_scope']}
        self.assertEqual(scopes['Whole']['was_bps'],'n.a.')
        self.assertEqual(scopes['BSL']['was_bps'],'n.a.')
        self.assertEqual(scopes['BSL']['opening_face'],D(100))
        self.assertEqual(scopes['BSL']['whole_face_share'],D(1))
        self.assertEqual(scopes['INFRA']['opening_face'],D(0))
        self.assertEqual(scopes['INFRA']['collateral_wal_years_act365f'],'n.a.')

    def test_blocked_junior_gate_never_becomes_an_available_minimum(self):
        baseline=operating_request(opening=state(claims=(('A','0'),('B','0'))))
        request=replace(baseline,notes=(note('A',1,'60',oc_minimum=D(2)),
                                       note('B',2,'20',oc_minimum=D('1.1'))),
                        cashflow_request=replace(baseline.cashflow_request,issues=(
                            DebtIssue('A',D(60),D(100)),DebtIssue('B',D(20),D(100)))))
        _,tables,_=reports(request)
        coverage={r['Tranche']:r for r in tables[PREFIX+'view_coverage']}
        minima={r['Tranche']:r for r in tables[PREFIX+'view_coverage_minima']}
        self.assertEqual(coverage['A']['Gate OC status'],'FAIL')
        self.assertEqual(coverage['B']['Gate OC status'],'BLOCKED')
        self.assertLess(minima['A']['Minimum gate OC headroom'],0)
        self.assertEqual(minima['B']['Minimum gate OC headroom'],'n.a.')
        self.assertEqual(minima['B']['Minimum gate OC date'],'n.a.')

    def test_credit_reference_principal_is_separate_from_actual_recovery(self):
        baseline=operating_request()
        request=replace(baseline,notes=(replace(baseline.notes[0],fixed_rate=D(0)),),
                        clo_terms=replace(baseline.clo_terms,defaulted_asset_oc_treatment=DefaultedAssetOcTreatment.EXCLUDE),
                        credit_events=(DefaultEvent('L',date(2026,5,1),
                            (RecoveryEvent(date(2026,6,1),D('.8')),),date(2026,6,1)),))
        result,tables,audit=reports(request)
        self.assertEqual(sum(r['Principal'] for r in tables[PREFIX+'asset_cashflows']),D(100))
        self.assertEqual(sum(r['Principal received'] for r in tables[PREFIX+'view_amortization']),D(80))
        self.assertEqual(result.clo.periods[-1].recognized_par_loss,D(20))
        self.assertEqual(result.clo.periods[-1].cash_conservation_residual,D(0))
        self.assertTrue(audit['credit_collections'])
        self.assertEqual(tables[PREFIX+'view_equity'][-1]['Cumulative net cashflow'],D(-18))

    def test_semantic_columns_display_years_shares_bps_and_rates_in_their_units(self):
        result=number_formats(('collateral_wal_years_act365f','whole_face_share',
                               'was_bps','cash_account_all_in_rate','received_asset_interest'))
        self.assertEqual(result['collateral_wal_years_act365f'],'0.000')
        self.assertEqual(result['whole_face_share'],'0.00%')
        self.assertEqual(result['was_bps'],'0.00')
        self.assertEqual(result['cash_account_all_in_rate'],'0.00%')
        self.assertIn('#,##0.00',result['received_asset_interest'])
        self.assertEqual(unit_format('ANNUAL_RATE'),'0.00%')
        dates=number_formats(('as_of_date','equity_value_date'))
        self.assertEqual(dates['as_of_date'],'dd-mmm-yyyy')
        self.assertEqual(dates['equity_value_date'],'dd-mmm-yyyy')

    def test_mixed_value_rows_keep_units_in_visible_and_hidden_saved_cases(self):
        with TemporaryDirectory() as directory:
            source=Path(directory)/'source.xlsx';target=Path(directory)/'output.xlsx'
            book=Workbook();home=book.active;home.title='Home';home['D2']='BASELINE'
            book.defined_names.add(DefinedName('trident_ui_schema',attr_text='"1.0"'))
            book.defined_names.add(DefinedName('trident_ui_analysis_case',attr_text="'Home'!$D$2"))
            output=book.create_sheet('CLO Analysis')
            output.append(('Metric','Value','Unit','Coverage','Data status'))
            output.append(('Seed',0,'EUR',1,'AVAILABLE'))
            output.add_table(Table(displayName=PREFIX+'metrics',ref='A1:E2'))
            book.save(source);book.close()
            package=WorkbookPackage(source)
            rows=({'Metric':'Future cash','Value':D('12.34'),'Unit':'EUR','Coverage':1,'Data status':'AVAILABLE'},
                  {'Metric':'WAC','Value':D('.08'),'Unit':'fraction','Coverage':1,'Data status':'AVAILABLE'},
                  {'Metric':'WAL','Value':D('1.25'),'Unit':'years','Coverage':1,'Data status':'AVAILABLE'},
                  {'Metric':'MOIC','Value':D('1.02'),'Unit':'multiple','Coverage':1,'Data status':'AVAILABLE'})
            cases={'BASELINE':rows,'CASE':tuple({**r,'Value':None if r['Metric']=='WAC' else r['Value']} for r in rows)}
            package.add_case_view(PREFIX+'metrics',cases)
            _mixed_formats(package,PREFIX+'metrics',cases)
            package.save(target)
            saved=load_workbook(target,data_only=True)
            try:
                expected=['#,##0.00;(#,##0.00);–','0.00%','0.000','0.000"x"']
                self.assertEqual([saved['CLO Analysis'].cell(r,2).number_format for r in range(2,6)],expected)
                backing=package.table_inventory()[PREFIX+'results_metrics']
                left,top,_,_=backing.bounds;value_col=left+backing.headers.index('Value')
                self.assertEqual([saved[backing.sheet].cell(r,value_col).number_format for r in range(top+1,top+9)],expected*2)
                self.assertAlmostEqual(saved['CLO Analysis']['B2'].value,12.34)
                self.assertAlmostEqual(saved['CLO Analysis']['B3'].value,.08)
            finally:saved.close()


if __name__=='__main__':unittest.main()
