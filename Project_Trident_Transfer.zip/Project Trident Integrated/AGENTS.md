# Project Trident Integrated — 工程约定

本文件适用于本项目及其子目录。用户在当前会话中的明确要求优先于本文件；开发、审查与交接时先阅读 [项目上下文](docs/project_context.md)，再阅读相关实现、测试与专项说明。

## 当前项目与交付范围

- 这是独立的当前项目，拥有自己的源码、测试、环境、输入和文档。按用户最新授权，外部原项目完整保留；不得修改它，也不得让当前项目通过旧项目路径、链接、解释器或运行时文件建立依赖。
- 默认只维护当前版本，不积累旧代码、文档、模型或输出副本。用户明确要求的历史保存应独立进行；当前测试使用稳定输入 fixture，不能依赖用户正在打开的输出文件。
- 当前用户入口为 `outputs/Project_Trident.xlsx`。交付范围依据 [用户指南](docs/user_guide.md) 与 [验收及边界](docs/readiness.md)：首个可用版本应简单、可操作，无明显或重大建模错误；支持 Closing、受支持 opening state、完整 what-if、静态优化及明确的 synthetic reinvestment assumptions。动态 lifetime trading optimization 不属于当前必要范围。
- 外部模型可作为业务需求、输入格式和对账参考，不能成为当前运行依赖、必须复刻的架构或自动正确的 oracle。合成示例、generic execution profile 与真实交易验证必须明确区分。
- 不在模型、代码、文档、注释、界面或文件 metadata 中添加生成者或作者自述。必要的金融来源、数据来源、合成测试说明、假设与验证记录应保留。

## 架构、代码与注释

1. **清晰架构与模块化**：明确每个模块的职责、依赖方向和数据流，分离领域逻辑、应用编排、输入输出适配与展示；避免重复逻辑和承担过多职责的模块。
2. **面向对象**：以领域对象表达状态、行为和约束，优先组合，谨慎继承。简单的无状态计算可以使用函数，不为形式而包装成类。
3. **可维护与可扩展**：接口清晰、实现内聚、改动尽量局部化。围绕已知变化点设计抽象，新增复杂度须有具体需求，不提前搭建完整平台。
4. **高效实现**：选择合适的算法与数据结构，避免不必要的穷举、重复计算、解析和复制。性能优化必须保留正确性、可读性与领域不变量。
5. **健壮与可读**：命名准确、风格一致、类型明确、函数职责单一。验证输入、领域约束和边界，明确异常，不吞掉错误或静默忽略不支持的业务请求。
6. **显式状态**：不依赖隐式全局状态；需要随机模拟时支持明确种子与可复现输入。金融计算独立于 Excel、数据库和界面。
7. **有意义的测试**：功能增量与缺陷修复覆盖正常路径、边界、非法输入和相关 corner cases；采用独立已知答案、守恒与回归。不要只用实现本身生成期望值。文档或低影响可逆修改无需为形式新增测试。
8. **完善注释**：模块入口、公共接口和关键领域逻辑必须有足够的 comment/docstring，说明职责、数据流、设计理由、假设、单位、时间口径与约束；无需逐行复述代码。

注释应帮助读者理解执行阶段、状态与账户的区别、输入输出契约、不变量、异常路径和已知边界。复杂算法说明推导或选择理由、精度与舍入、分支、缓存条件和性能取舍；金融步骤说明现金、面值、应收和递延的区别。行为变化时同步更新注释，不能留下失效默认值或把计划写成已实现能力。整体阅读路径见 [架构](docs/architecture.md) 与 [计算流程](docs/calculation_flowcharts.md)。

## 金融正确性与约定

- 金融正确性优先于性能、功能数量和交付速度。已知未解决的重大金融计算问题不能作为已验证结果交付，也不能通过删去 opening state、claims 或 typed inputs、补造零值或改变 valuation basis 绕过保护。
- 先明确当前阶段的输入、输出、假设与验收，再实现。区分契约条款、模型假设和计算逻辑，使前两者可显式配置、验证并追溯来源。
- 金额、利率、日期、期间、币种、现金流方向和 return basis 必须有明确语义。实际现金、performing/defaulted par、debt face、应计/递延 claims 与当前 equity value 分别处理，不相互替代。
- 日期、day count、fixing/reset、floor、应计利息、settlement、评级和 recovery 按适用合同与市场约定确定。市场惯例不等于每笔合同条款；来源冲突须记录并解决。
- 重要假设记录值、单位、范围、来源或选择理由、结果影响与验证状态；测试假设不能静默成为生产默认值。数值类型、精度、逐项/汇总舍入及容差按使用场景记录，显示格式不能改变底层精度。
- 重要公式和处理方式应核对权威原始 reference，并以独立手算、已知答案或不同实现交叉验证。现金分配、face 和 claim 变化须有守恒及领域不变量；旧工作簿结果不是自动正确的答案。
- 静态 proposal、完整 replay 后的 return ranking、synthetic reinvestment 与实际执行交易应明确区分。未执行的交易和缺失估值不能展示成已完成收益；candidate funding、accrued interest 和费用按实际现金及 cents 对账，不能用 ranking surrogate 代替最终经济结果。
- 完整模型 case 从同一输入基准独立建立。支持的 phase/limits 应按实际时间与适用条件检查；不支持的组合明确拒绝或说明，不静默跳过。

细则见 [模型假设](docs/model_assumptions.md)、[金融验证标准](docs/methodology/financial_validation.md) 与 [市场约定](docs/methodology/conventions.md)。

## 输入拥有者与 Excel 命名接口

- 每个业务字段只有一个 owning input。Library 管共同身份、合同、评级及一对多 schedules；Pool 管持仓与逐资产 position inputs；Capital Stack 管 note 条款。具体映射以当前 schema 和 [用户指南](docs/user_guide.md) 为准。
- 明确区分可编辑输入、派生输出、保留的 reference 和未启用字段。`When used`、注释与校验必须说明实际拥有者；保留参考值不能伪装成生效的全局 override。不支持的编辑应明确报错，不能默默忽略。
- 所有业务标量、输出区域和公式接口通过有语义的 named ranges 管理；当前 UI 名称使用 `trident_ui_` 命名空间。可变长度明细使用命名 Excel Tables、列名和登记其业务区域的 names，Table 不能成为绕开命名管理的替代方案。
- Adapter 统一解析 names、Tables 和 headers。坐标仅用于模板排版、名称定义和解析后的底层传输，不得用固定行列识别金融字段；名称失效不得静默退回硬编码位置。
- 维护 schema/名称 registry：逻辑字段、名称、类型、单位、方向、范围、版本。读入、扩容与写出校验缺失/冲突名称、`#REF!`、区域形状、表头及重叠；相应功能变化时验证移动、增删、空表和非法 schema。
- 枚举和 boolean 使用 native dropdown，选项有限且与当前 schema 一致，提供输入提示及 Stop 拒绝非法值。日期、tranche、case 和 scope catalogue 来自实际支持或已保存记录，不能含表头、过期条目或可选空尾行。
- Selector 仅过滤对应的完整 saved results，不得把 headline-only comparison 说成完整计算，也不得因日期过滤而暗中重算或改变 forward return 的起点。

## Excel 展示、格式与保存保护

- 使用 Arial；数据、表头和 selector 居中，较长说明与注释按可读性左对齐并适当换行。颜色区分 owning inputs、outputs 和灰色 reference，真正的权限与拥有者由 schema 决定。
- 数值以语义格式展示：现金为 cents、face 为整数、rate/share 为百分比、bps 为明确 bps、factor/multiple 和 years 用适当精度，日期与日期标签按 [界面格式约定](docs/interface_style.md)。可见页和隐藏完整结果都要有正确格式及足够列宽，不能只检查可见 headlines。
- 缺失、未配置、未选择、不适用、blocked 和有效的零值保持区别。可见 value 与 status 必须来自同一 case/scope 的保存记录；友好标签可以转换 raw status 的文字，不能捏造 AVAILABLE 或假零。
- Python 是金融计算来源；Excel 公式负责命名引用、筛选和展示，避免另建一套金融计算。现金流 reference、credit-adjusted receipts、initial investment 和 current equity mark 必须标明不同口径。
- 保存时保留输入值/公式、Tables、names、validation、native charts、原样式资源及已有 package 结构；Market Data 的可粘贴布局与内容不得被展示更新破坏。新增样式尽量复用或 append，不重写已有样式含义。
- 可变明细和 full-case backing data 使用独立列 lanes 扩容；扩容不能覆盖输入、相邻 Tables、names 或其他展示。容量或冲突应明确拒绝，不能截断完整数据或覆写相邻区域。
- 运行保存 input snapshot/fingerprint、版本、execution profile、时间、case/scope 和 return basis，明确过期结果。失败应保留上一份完整输出；最终写出采用完整验证后的原子发布。
- Workbook 变更需进行实际正常打开、计算、保存重开及必要的渲染/视觉检查。Formula/chart caches 只能来自匹配的公式与系列；注册 `NA()` chart gaps 与真实 lookup/error 区分，不能把所有 Excel error 泛化豁免。

## 界面修改后的统一验收

- 每次修改user interface，无论新增、修改或删除，都须核对与整个界面的格式、交互及业务语义一致。涵盖但不限于字体、字体层级、颜色、输入/输出/参考拥有者提示、日期及数字/单位格式、对齐、边框、行高列宽、换行、导航、冻结窗格、分组/隐藏、下拉框、状态/条件格式、图表及预留区域。
- 修改完成后，在交付前进行**整个界面检查**，不能只验证修改位置或可见首页。包括隐藏行列及支持页、各Table的表头/有效记录/空白容量、首次/中间/最后期间、各已保存case与相关selector状态。增加或删除内容还须检查相邻区域、names/Tables/validation、导航和chart bindings没有遗漏或失效。
- 长表须核对**每个业务分区和全部分区交界**，逐行检查同角色字体/底色与Table隔行条纹，包含直接格式、named-style继承及条件格式的实际优先级。首行/中间/末行抽样不能作为整张长表颜色一致的证明。使用原生Excel `DisplayFormat`验证实际颜色，逐段渲染受影响长表，记录实际视觉覆盖，不能把结构检查或金融测试数量当作视觉验收。
- 检查须区分有意的角色差异与不一致，不为视觉统一改变金融数值、原始输入、字段单位或状态含义；禁止把不同单位的mixed Value/Threshold列统一设为百分比。格式修正应在后续运行及扩容后保留。
- 按实际界面变更验证正常Excel打开、交互、保存重开及视觉显示，修复发现的问题后复查受影响内容；记录检查范围及未解决限制，不把用户自行找错作为默认验收步骤。
- 如果仅修改内部代码且没有改变界面、显示、输出schema或交互逻辑，无需额外进行界面检查；代码/金融回归仍按对应改动执行。改变格式writer或展示逻辑即属于界面修改，不能因改动位于Python代码而免除整体界面检查。

## 工作流程与文档同步

- 用户说“等等”“包括但不限于”“诸如”或 `etc` 时，列举是示例而非上限。主动补齐与授权目标相关的同类事项、遗漏依赖、模块交互和边界，并说明重要补充的理由；同时遵守最新首用范围，避免添加不必要 inputs、outputs、tabs 或平台功能。
- 修改前阅读现有实现、相关约定与测试；独立任务可并行，但共享文件必须明确负责人，遵守会话工具、权限和协作规则。
- 每次重大交付更新 [项目上下文](docs/project_context.md) 的需求、已采纳决策、实际状态、验证证据和下一步；同步相关 user guidance、assumptions、methodology、architecture、flow charts 和版本。纯文字微调无需重写整套文档，金融条款、公式、输入输出或流程变化必须更新对应说明。
- 每次交付清楚说明范围、假设、实际验证和限制。区分静态检查、金融参考核验、独立已知答案、模型回归、native Excel 和真实交易验证；不声称未运行的检查通过，不用测试数量替代适用 profile 的金融结论。
- 当前证据和支持范围统一维护在 [验收说明](docs/readiness.md)，安装与独立运行见 [部署说明](docs/deployment.md)。文档链接只指向本项目当前存在的文件，不链接旧项目或不存在的说明。
