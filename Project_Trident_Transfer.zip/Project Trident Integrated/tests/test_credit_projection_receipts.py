"""Credit-result trust-boundary controls independent of cash conservation.

The forged rows below keep cent totals and principal bridges balanced. They
must still fail because a dated receipt needs a declared economic operation,
and one genuine prepayment cannot authorize an arbitrary additional coupon.
"""

from dataclasses import replace
from datetime import date
from decimal import Decimal, Inexact, ROUND_DOWN, localcontext
from fractions import Fraction
import unittest

from trident.conventions.calendar import BusinessDayConvention
from trident.conventions.day_count import DayCount
from trident.conventions.schedule import AccrualDateBasis
from trident.credit import (
    AssetCashSource, AssetCollection, AssetParMovement, CreditEventCashflowEngine,
    DefaultEvent, PrepaymentEvent, RecoveryEvent,
)
from trident.domain.models import CouponType, InputValidationError, LoanPosition, LoanTerms, SeasonedLoanState
from trident.domain.numeric import post_currency
from trident.market.rates import FlatRateProvider


D = Decimal
START = date(2026, 1, 1)
FINAL = date(2026, 10, 1)


def loan(*, rate: Decimal = D(".12"), start: date = START) -> LoanPosition:
    """A 100-par fixed ACT/360 bullet with original quarterly boundaries."""
    terms = LoanTerms(
        loan_id="RECEIPT_CONTROL", currency="EUR", start_date=start,
        maturity_date=FINAL, reference_principal=D(100),
        coupon_type=CouponType.FIXED, fixed_rate=rate, day_count=DayCount.ACT_360,
        business_day_convention=BusinessDayConvention.UNADJUSTED,
        accrual_date_basis=AccrualDateBasis.UNADJUSTED,
        fixing_lag_business_days=0,
    )
    return LoanPosition(terms, start, D(100))


def cash_row(day: date, source: AssetCashSource, interest: Decimal = D(0), principal: Decimal = D(0)) -> AssetCollection:
    return AssetCollection("RECEIPT_CONTROL", "EUR", day, source, interest, principal,
                           post_currency(Fraction(interest) + Fraction(principal)))


def replaced_cash(result, rows):
    """Keep public aggregates truthful, so rejection tests the economic cause."""
    rows = tuple(sorted(rows, key=lambda row: row.payment_date))
    return replace(result, collections=rows, total_cash_interest=post_currency(
        sum((Fraction(row.cash_interest) for row in rows), Fraction()),
    ))


class CreditReceiptBoundaryTests(unittest.TestCase):
    def setUp(self) -> None:
        self.engine = CreditEventCashflowEngine(FlatRateProvider({}))

    def test_absent_event_cannot_add_interest_only_prepayment(self) -> None:
        result = self.engine.generate(loan())
        phantom = cash_row(date(2026, 5, 1), AssetCashSource.PREPAYMENT, D(1000))
        with self.assertRaisesRegex(InputValidationError, "future/absent.*nonscheduled"):
            replaced_cash(result, (*result.collections, phantom))

    def test_future_events_cannot_license_current_prepayment_cash(self) -> None:
        for event in (DefaultEvent("RECEIPT_CONTROL", date(2026, 6, 1)),
                      PrepaymentEvent("RECEIPT_CONTROL", date(2026, 6, 1))):
            with self.subTest(event=event):
                result = self.engine.generate(loan(), event, horizon_date=date(2026, 5, 1))
                self.assertFalse(result.credit_event_applied)
                with self.assertRaisesRegex(InputValidationError, "future/absent.*nonscheduled"):
                    replaced_cash(result, (*result.collections, cash_row(
                        date(2026, 4, 15), AssetCashSource.PREPAYMENT, D(1000),
                    )))

    def test_absent_event_also_rejects_zero_recovery_metadata(self) -> None:
        result = self.engine.generate(loan())
        with self.assertRaisesRegex(InputValidationError, "future/absent.*nonscheduled"):
            replaced_cash(result, (*result.collections, cash_row(date(2026, 5, 1), AssetCashSource.RECOVERY)))

    def test_prepayment_receipt_cannot_be_duplicated_on_same_or_later_day(self) -> None:
        event = PrepaymentEvent("RECEIPT_CONTROL", date(2026, 5, 15))
        result = self.engine.generate(loan(), event, horizon_date=date(2026, 6, 1))
        # Apr 1--May 15 has 44 actual days: 100*.12*44/360 = 1.466... ->1.47.
        self.assertEqual(result.collections[-1].cash_interest, D("1.47"))
        for day in (event.event_date, date(2026, 5, 20)):
            for interest in (D(0), D(1000)):
                with self.subTest(day=day, interest=interest), self.assertRaisesRegex(
                    InputValidationError, "exactly one PREPAYMENT cash receipt",
                ):
                    replaced_cash(result, (*result.collections, cash_row(day, AssetCashSource.PREPAYMENT, interest)))

    def test_single_correctly_dated_prepayment_cannot_inflate_coupon(self) -> None:
        result = self.engine.generate(loan(), PrepaymentEvent("RECEIPT_CONTROL", date(2026, 5, 15)))
        receipt = result.collections[-1]
        forged = replace(receipt, cash_interest=D("1.48"), total_cash=D("101.48"))
        with self.assertRaisesRegex(InputValidationError, "exact contractual coupon"):
            replaced_cash(result, (*result.collections[:-1], forged))

    def test_prepayment_requires_typed_known_contractual_day_count(self) -> None:
        result = self.engine.generate(loan(), PrepaymentEvent("RECEIPT_CONTROL", date(2026, 5, 15)))
        with self.assertRaisesRegex(InputValidationError, "requires explicit contractual_day_count"):
            replace(result, contractual_day_count=None)
        with self.assertRaisesRegex(InputValidationError, "must be DayCount"):
            replace(result, contractual_day_count="ACT/360")
        with self.assertRaisesRegex(InputValidationError, "explicit day-count"):
            replace(result, contractual_day_count=DayCount.ACT_365F)
        # Legacy aggregate references without prepayment may omit metadata;
        # their actual receipts still need the full contractual prefix.
        absent = self.engine.generate(loan())
        self.assertEqual(replace(absent, contractual_day_count=None).collections, absent.collections)

    def test_signed_zero_and_same_day_exit_coupons_remain_valid(self) -> None:
        for rate, expected in ((D("-.12"), D("-1.47")), (D(0), D(0))):
            with self.subTest(rate=rate):
                result = self.engine.generate(loan(rate=rate), PrepaymentEvent("RECEIPT_CONTROL", date(2026, 5, 15)))
                self.assertEqual(result.collections[-1].cash_interest, expected)
                self.assertEqual(result.collections[-1].principal_collection, D(100))
        same_day = self.engine.generate(loan(), PrepaymentEvent("RECEIPT_CONTROL", date(2026, 4, 1)))
        self.assertEqual([row.cash_interest for row in same_day.collections], [D(3), D(0)])
        self.assertEqual([row.source for row in same_day.collections],
                         [AssetCashSource.SCHEDULED, AssetCashSource.PREPAYMENT])

    def test_seasoned_exact_opening_claim_is_combined_once_at_exit(self) -> None:
        held = loan(start=date(2026, 4, 1))
        held = LoanPosition(held.terms, date(2026, 5, 15), D(100), SeasonedLoanState(D("1.47"), "HAND_AGENT_STATEMENT"))
        with localcontext() as context:
            context.prec = 3
            context.rounding = ROUND_DOWN
            context.traps[Inexact] = True
            result = self.engine.generate(held, PrepaymentEvent("RECEIPT_CONTROL", date(2026, 6, 1)))
        # Original Apr 1--Jun 1 is 61 days, despite a May 15 projection start:
        # 100*.12*61/360 = 2.033... ->2.03, not1.47+.57=2.04.
        self.assertEqual(result.collections[0].cash_interest, D("2.03"))
        forged = replace(result.collections[0], cash_interest=D("2.04"), total_cash=D("102.04"))
        with self.assertRaisesRegex(InputValidationError, "exact contractual coupon"):
            replaced_cash(result, (forged,))

    def test_default_cannot_create_interest_only_prepayment_cash(self) -> None:
        event = DefaultEvent("RECEIPT_CONTROL", date(2026, 5, 1),
                             (RecoveryEvent(date(2026, 6, 1), D(".6")),))
        result = self.engine.generate(loan(), event)
        with self.assertRaisesRegex(InputValidationError, "only explicitly scheduled principal recovery"):
            replaced_cash(result, (*result.collections, cash_row(date(2026, 5, 15), AssetCashSource.PREPAYMENT, D(1000))))

    def test_duplicate_zero_recovery_is_not_an_extra_declared_event(self) -> None:
        event = DefaultEvent("RECEIPT_CONTROL", date(2026, 5, 1),
                             (RecoveryEvent(date(2026, 6, 1), D(0)),))
        result = self.engine.generate(loan(), event)
        self.assertEqual(result.final_defaulted_par, D(100))
        self.assertEqual(result.collections[-1].principal_collection, D(0))
        with self.assertRaisesRegex(InputValidationError, "Recovery ledger/future queue"):
            replaced_cash(result, (*result.collections, result.collections[-1]))

    def test_split_recovery_receipts_cannot_bypass_one_explicit_installment(self) -> None:
        event = DefaultEvent("RECEIPT_CONTROL", date(2026, 5, 1),
                             (RecoveryEvent(date(2026, 6, 1), D(".6")),))
        result = self.engine.generate(loan(), event)
        half = cash_row(date(2026, 6, 1), AssetCashSource.RECOVERY, principal=D(30))
        # The aggregate still contains 60 recovery principal, matching its one
        # par operation. That does not make two receipts the declared event.
        with self.assertRaisesRegex(InputValidationError, "cumulative targets"):
            replaced_cash(result, (*result.collections[:-1], half, half))

    def test_recovery_date_cannot_move_even_when_cash_and_par_move_together(self) -> None:
        event = DefaultEvent("RECEIPT_CONTROL", date(2026, 5, 1),
                             (RecoveryEvent(date(2026, 6, 1), D(".6")),))
        result = self.engine.generate(loan(), event, horizon_date=date(2026, 6, 2))
        moved = replace(result.collections[-1], payment_date=date(2026, 6, 2))
        movement = replace(result.par_movements[-1], event_date=date(2026, 6, 2))
        with self.assertRaisesRegex(InputValidationError, "explicit default, recovery and write-off dates"):
            replace(result, collections=(*result.collections[:-1], moved),
                    par_movements=(*result.par_movements[:-1], movement))

    def test_duplicate_scheduled_noop_cannot_hide_in_principal_sums(self) -> None:
        result = self.engine.generate(loan())
        extra = AssetParMovement("RECEIPT_CONTROL", FINAL, AssetCashSource.SCHEDULED,
                                 D(0), D(0), D(0), D(0), D(0), D(0))
        with self.assertRaisesRegex(InputValidationError, "match each contractual prefix"):
            replace(result, par_movements=(*result.par_movements, extra))

    def test_same_day_schedule_must_precede_default_even_for_zero_principal(self) -> None:
        event = DefaultEvent("RECEIPT_CONTROL", date(2026, 4, 1))
        result = self.engine.generate(loan(), event)
        scheduled, default = result.par_movements
        # Both before/after balances remain mathematically continuous if the
        # zero-principal scheduled row is rewritten after default. Its source
        # chronology would nevertheless contradict scheduled-first policy.
        rewritten_schedule = replace(scheduled, performing_par_before=D(0), performing_par_after=D(0),
                                     defaulted_par_before=D(100), defaulted_par_after=D(100))
        with self.assertRaisesRegex(InputValidationError, "contractual cash before same-day"):
            replace(result, par_movements=(default, rewritten_schedule))


if __name__ == "__main__":
    unittest.main()
