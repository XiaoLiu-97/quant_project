"""Dated investor returns with an explicit, conservative IRR policy.

    Cash outflows are negative and distributions positive. XNPV/XIRR use
    actual calendar days / 365, as in Microsoft's published XIRR definition.
    Multiple sign changes can produce multiple roots: this API reports ambiguity
    and does not choose a favourable result using an implicit initial guess.
"""

from dataclasses import dataclass
from datetime import date
from decimal import Context, Decimal, DecimalException, ROUND_HALF_EVEN, localcontext
from enum import Enum
from fractions import Fraction
from math import exp, fsum, isfinite
from typing import Iterable

from trident.domain.models import InputValidationError, require_date, require_decimal
from trident.domain.numeric import decimal_fraction


class ReturnStatus(str, Enum):
    AVAILABLE = "AVAILABLE"
    UNAVAILABLE = "UNAVAILABLE"
    AMBIGUOUS = "AMBIGUOUS"
    NUMERIC_FAILURE = "NUMERIC_FAILURE"


@dataclass(frozen=True)
class DatedCashflow:
    """Investor-side cash amount on a calendar payment/settlement date."""

    payment_date: date
    amount: Decimal

    def __post_init__(self) -> None:
        require_date(self.payment_date, "payment_date")
        require_decimal(self.amount, "investor cash amount")


@dataclass(frozen=True)
class ReturnResult:
    status: ReturnStatus
    value: Decimal | None
    message: str = ""
    residual: Decimal | None = None


def _aggregate(cashflows: Iterable[DatedCashflow]) -> tuple[DatedCashflow, ...]:
    """Same-date netting is exact and independent of caller Decimal precision."""
    grouped: dict[date, Fraction] = {}
    for row in cashflows:
        if not isinstance(row, DatedCashflow):
            raise InputValidationError("cashflows must contain DatedCashflow objects")
        grouped[row.payment_date] = grouped.get(row.payment_date, Fraction()) + Fraction(row.amount)
    output = []
    for day, amount in sorted(grouped.items()):
        numerator, denominator = Decimal(amount.numerator), Decimal(amount.denominator)
        # Decimal inputs imply a terminating base-10 fraction. Preserve all its
        # digits during aggregation rather than truncating to display precision.
        with localcontext(Context(prec=max(34, numerator.adjusted() + denominator.adjusted() + 4))):
            output.append(DatedCashflow(day, numerator / denominator))
    return tuple(output)


def xnpv(rate: Decimal, cashflows: Iterable[DatedCashflow]) -> Decimal:
    """Discount to the earliest supplied date, using annual effective rate.

    Unlike Excel's positional starting-date restriction, observations are sorted
    by date. A zero observation can explicitly establish the valuation date.
    Domain calculations use Decimal; fractional exponents are numerical, with
    40 significant digits, and are not used to post ledger money.
    """
    require_decimal(rate, "discount rate")
    if rate <= -1:
        raise InputValidationError("discount rate must be greater than -1")
    rows = _aggregate(cashflows)
    if not rows:
        raise InputValidationError("XNPV needs dated cashflows")
    with localcontext(Context(prec=40, rounding=ROUND_HALF_EVEN)) as context:
        origin = rows[0].payment_date
        result = Decimal(0)
        try:
            base = Decimal(1) + rate
            for row in rows:
                time = Decimal((row.payment_date - origin).days) / Decimal(365)
                result += row.amount / context.power(base, time)
        except (DecimalException, OverflowError, ZeroDivisionError) as exc:
            raise InputValidationError("Discounted cashflows exceed the supported numeric domain") from exc
        if not result.is_finite():
            raise InputValidationError("Discounted cashflows exceed the supported numeric domain")
        return +result


def xirr(cashflows: Iterable[DatedCashflow]) -> ReturnResult:
    """Solve a unique one-sign-change XNPV root by bracketed log-rate bisection.

    y = log(1 + rate) spans all admissible rates without an arbitrary -99% lower
    bound. Exponential terms are scaled before evaluation to prevent overflow.
    Roots use floating point only during safeguarded numerical search. The
    returned rate is independently checked with Decimal XNPV, relative to gross
    cash amounts. Numeric limitations are explicit results, never guessed IRRs.
    """
    observations = _aggregate(cashflows)
    rows = tuple(row for row in observations if row.amount)
    signs = [row.amount > 0 for row in rows]
    if not rows or len(set(signs)) < 2:
        return ReturnResult(ReturnStatus.UNAVAILABLE, None, "XIRR requires at least one positive and one negative net dated cashflow")
    changes = sum(left != right for left, right in zip(signs, signs[1:]))
    if changes > 1:
        return ReturnResult(ReturnStatus.AMBIGUOUS, None, "Multiple sign changes: uniqueness is not established; no implicit root selection")
    total = sum((abs(Fraction(row.amount)) for row in rows), Fraction())
    coefficients = [float(Fraction(row.amount) / total) for row in rows]
    if any(coefficient == 0 or not isfinite(coefficient) for coefficient in coefficients):
        return ReturnResult(ReturnStatus.NUMERIC_FAILURE, None, "Cash amount scale exceeds numerical search precision")
    origin = rows[0].payment_date
    times = [(row.payment_date - origin).days / 365 for row in rows]

    def scaled_value(log_rate: float) -> float:
        exponents = [-log_rate * time for time in times]
        scale = max(exponents)
        return fsum(coefficient * exp(exponent - scale) for coefficient, exponent in zip(coefficients, exponents))

    low, high = -1.0, 1.0
    low_value, high_value = scaled_value(low), scaled_value(high)
    for _ in range(12):
        if (low_value < 0) != (high_value < 0):
            break
        low, high = low * 2, high * 2
        low_value, high_value = scaled_value(low), scaled_value(high)
    else:
        return ReturnResult(ReturnStatus.NUMERIC_FAILURE, None, "Unique root lies beyond the safeguarded log-rate search domain")
    middle = 0.0
    for _ in range(180):
        middle = (low + high) / 2
        value = scaled_value(middle)
        if value == 0 or high - low <= 1e-14 * max(1, abs(middle)):
            break
        if (low_value < 0) == (value < 0):
            low, low_value = middle, value
        else:
            high = middle
    with localcontext(Context(prec=50, rounding=ROUND_HALF_EVEN)) as context:
        try:
            rate = context.exp(Decimal(str(middle))) - Decimal(1)
            if rate <= -1:
                return ReturnResult(ReturnStatus.NUMERIC_FAILURE, None, "IRR is indistinguishable from -100% at supported precision")
            # Removing leading zero observations does not change a root. Verify
            # at the earliest nonzero date so unnecessary discount rescaling
            # cannot magnify a valid numerical residual.
            residual = xnpv(rate, rows)
            scale = decimal_fraction(total)
            if abs(residual) > scale * Decimal("1e-10"):
                return ReturnResult(ReturnStatus.NUMERIC_FAILURE, None, "Decimal XNPV residual did not validate the numerical root", residual)
        except (InputValidationError, DecimalException, OverflowError):
            return ReturnResult(ReturnStatus.NUMERIC_FAILURE, None, "Root is outside the supported Decimal verification domain")
        return ReturnResult(ReturnStatus.AVAILABLE, +rate, residual=+residual)


def moic(cashflows: Iterable[DatedCashflow]) -> ReturnResult:
    """Gross positive distributions / absolute gross negative contributions.

    All additional investments are included. Gross amounts are not netted on
    equal dates for MOIC; a same-day contribution and distribution remain two
    economically distinct cash movements. This convention is explicitly
    different from the dated netting required for XNPV/XIRR.
    """
    negative = Fraction()
    positive = Fraction()
    for row in cashflows:
        if not isinstance(row, DatedCashflow):
            raise InputValidationError("cashflows must contain DatedCashflow objects")
        if row.amount < 0:
            negative -= Fraction(row.amount)
        else:
            positive += Fraction(row.amount)
    if not negative:
        return ReturnResult(ReturnStatus.UNAVAILABLE, None, "MOIC needs an investor cash contribution")
    return ReturnResult(ReturnStatus.AVAILABLE, decimal_fraction(positive / negative))
