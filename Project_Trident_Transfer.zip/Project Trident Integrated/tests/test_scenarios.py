"""Closing what-if synchronization, independent runs and economic comparisons."""

from dataclasses import FrozenInstanceError, replace
from datetime import date, datetime
from decimal import Decimal, Inexact, localcontext
import unittest

from trident.analysis import AssetExposure, FactorMapping, LimitDirection, LimitSpec
from trident.application.clo_services import TridentModelRequest, TridentModelService
from trident.application.scenarios import (
    SCENARIO_FIELD_TYPES, ScenarioDefinition, ScenarioEdit, ScenarioExecutionError,
    ScenarioRunner, ScenarioTarget,
)
from trident.application.services import CashflowRunRequest
from trident.clo.models import CloTerms, NoteTranche
from trident.domain.models import AmortizationType, CouponType, LoanPosition, LoanTerms, PrincipalScheduleEntry
from trident.funding.engine import AssetPurchase, DebtIssue
from trident.market import FlatRateProvider


D = Decimal
CLOSE = date(2026, 11, 20)
MATURITY = date(2027, 11, 20)


def request(*, fixed=False, linear=False):
    """Small high-cashflow case avoids accidental failures obscuring edit tests."""
    loan = LoanTerms("L1", "EUR", CLOSE, MATURITY, D("10000000"),
        CouponType.FIXED if fixed else CouponType.FLOATING,
        fixed_rate=D(".10") if fixed else None,
        rate_index=None if fixed else "EURIBOR_3M", spread_bps=D(0) if fixed else D(800),
        amortization_type=AmortizationType.LINEAR_INITIAL_PAR if linear else AmortizationType.BULLET,
        amortization_fraction=D(".1") if linear else D(0))
    exposure = AssetExposure("L1", "BORROWER", "BSL", "TERM_LOAN", "GB", "SERVICES", "EUR",
        D("10000000"), None if fixed else D(800), MATURITY,
        is_senior=True, is_secured=True, is_pik=False, is_revolver=False, is_construction=False,
        test_factor_bucket="TEST")
    cash = CashflowRunRequest((LoanPosition(loan, CLOSE, D("10000000")),),
        (AssetPurchase("L1", D("10000000"), D(100)),),
        (DebtIssue("A", D("8000000"), D(100)),),
        FlatRateProvider({"EURIBOR_3M": D(".02")}), D("100000"), D("50000"), "SYNTHETIC_TEST")
    note = NoteTranche("A", 1, D("8000000"), CouponType.FIXED if fixed else CouponType.FLOATING,
        fixed_rate=D(".05") if fixed else None, rate_index=None if fixed else "EURIBOR_3M",
        spread_bps=D(0) if fixed else D(300), oc_minimum=D("1.1"), ic_minimum=D("1.2"))
    terms = CloTerms(CLOSE, date(2029, 11, 20), senior_management_fee_bps=D(5),
        subordinated_management_fee_bps=D(10), annual_senior_expenses=D("10000"), initial_reserve=D("50000"))
    return TridentModelRequest(cash, (exposure,), FactorMapping("SYNTHETIC", "1", {"TEST": D(2000)}, True),
        (LimitSpec("BSL", "concentration:asset_class:BSL", D(1)),
         LimitSpec("WAS", "WAS_BPS", D(500), LimitDirection.MINIMUM)), terms, (note,))


def edit(target, field, value, identifier=None):
    target = ScenarioTarget(target)
    return ScenarioEdit(target, identifier or {ScenarioTarget.ASSET: "L1", ScenarioTarget.NOTE: "A", ScenarioTarget.CONTROL: "DEAL"}[target], field, value)


def comparison(result, metric, scope="MODEL", identifier=None):
    return next(row for row in result.comparisons if (row.scope, row.metric, row.identifier) == (scope, metric, identifier))


class CountingService(TridentModelService):
    def __init__(self):
        self.calls = []

    def run(self, current):
        self.calls.append(current)
        return super().run(current)


class ScenarioTests(unittest.TestCase):
    def test_noop_repeats_full_economics_and_baseline_runs_once(self):
        service = CountingService()
        baseline = request()
        batch = ScenarioRunner(service).run(baseline, (ScenarioDefinition("NOOP"),))
        result = batch.scenarios[0]
        self.assertEqual(len(service.calls), 2)
        self.assertIs(service.calls[0], baseline)
        self.assertEqual(result.result.cashflows.funding, batch.baseline.cashflows.funding)
        self.assertEqual(result.result.cashflows.cashflows, batch.baseline.cashflows.cashflows)
        self.assertEqual(result.result.clo, batch.baseline.clo)
        self.assertEqual(result.result.equity_irr, batch.baseline.equity_irr)
        self.assertEqual(result.result.opening_portfolio, batch.baseline.opening_portfolio)
        self.assertTrue(all(row.delta == 0 for row in result.comparisons if row.delta_status == "AVAILABLE"))
        self.assertTrue(all(row.delta == 0 for row in result.period_comparisons if row.delta_status == "AVAILABLE"))

    def test_asset_spread_changes_cashflow_analysis_and_equity_irr(self):
        batch = ScenarioRunner().run(request(), (ScenarioDefinition("SPREAD", (edit("ASSET", "spread_bps", D(900)),)),))
        result = batch.scenarios[0]
        self.assertEqual(result.request.cashflow_request.positions[0].terms.spread_bps, D(900))
        self.assertEqual(result.request.exposures[0].spread_bps, D(900))
        self.assertEqual(comparison(result, "WAS_BPS", "OPENING_METRIC").delta, D(100))
        self.assertGreater(comparison(result, "ASSET_TOTAL_INTEREST").delta, 0)
        self.assertGreater(comparison(result, "EQUITY_IRR").delta, 0)
        self.assertGreater(comparison(result, "TOTAL_EQUITY_DISTRIBUTIONS").delta, 0)

    def test_asset_clean_price_changes_funding_without_changing_contractual_cashflows(self):
        batch = ScenarioRunner().run(request(), (ScenarioDefinition("CHEAPER", (edit("ASSET", "clean_price_pct", D(99)),)),))
        result = batch.scenarios[0]
        # 10m * (99%-100%) = -100k acquisition cost/equity cash.
        self.assertEqual(comparison(result, "ASSET_CLEAN_COST").delta, D("-100000"))
        self.assertEqual(comparison(result, "EQUITY_CASH_FUNDING").delta, D("-100000"))
        self.assertEqual(result.result.cashflows.cashflows, batch.baseline.cashflows.cashflows)
        self.assertGreater(comparison(result, "EQUITY_IRR").delta, 0)

    def test_note_issue_price_changes_funding_without_changing_note_coupon_or_par(self):
        batch = ScenarioRunner().run(request(), (ScenarioDefinition("ISSUE", (edit("NOTE", "issue_price_pct", D(99)),)),))
        result = batch.scenarios[0]
        # 8m * -1% = -80k proceeds, +80k equity funding.
        self.assertEqual(comparison(result, "DEBT_PROCEEDS").delta, D("-80000"))
        self.assertEqual(comparison(result, "EQUITY_CASH_FUNDING").delta, D("80000"))
        self.assertEqual(result.result.clo, batch.baseline.clo)
        self.assertLess(comparison(result, "EQUITY_IRR").delta, 0)

    def test_note_par_synchronizes_funded_issuance_and_projected_balance(self):
        batch = ScenarioRunner().run(request(), (ScenarioDefinition("LEVERAGE", (edit("NOTE", "par", D("7900000")),)),))
        result = batch.scenarios[0]
        self.assertEqual(result.request.notes[0].opening_balance, D("7900000"))
        self.assertEqual(result.request.cashflow_request.issues[0].par, D("7900000"))
        self.assertEqual(comparison(result, "DEBT_PAR").delta, D("-100000"))
        self.assertEqual(comparison(result, "EQUITY_CASH_FUNDING").delta, D("100000"))
        self.assertEqual(comparison(result, "OPENING_PAR", "NOTE", "A").delta, D("-100000"))
        self.assertLess(result.result.clo.periods[0].note_coupon_due, batch.baseline.clo.periods[0].note_coupon_due)

    def test_note_spread_changes_waterfall_but_not_asset_cashflows_or_funding(self):
        batch = ScenarioRunner().run(request(), (ScenarioDefinition("NOTE_MARGIN", (edit("NOTE", "spread_bps", D(350)),)),))
        result = batch.scenarios[0]
        self.assertEqual(result.result.cashflows, replace(batch.baseline.cashflows, run_id=result.result.cashflows.run_id))
        self.assertLess(comparison(result, "TOTAL_EQUITY_DISTRIBUTIONS").delta, 0)
        self.assertLess(comparison(result, "EQUITY_IRR").delta, 0)

    def test_asset_par_resizes_amortisation_reference_and_acquired_accrued(self):
        baseline = request(linear=True)
        cash = replace(baseline.cashflow_request, purchases=(replace(baseline.cashflow_request.purchases[0], accrued_interest=D("123.45")),))
        # Funding can price acquired accrued independently. Full CLO returns
        # require an inherited-coupon entitlement state, outside this subset.
        baseline = replace(baseline, cashflow_request=cash, clo_terms=None, notes=())
        batch = ScenarioRunner().run(baseline, (ScenarioDefinition("SIZE", (edit("ASSET", "par", D("12000000")),)),))
        current = batch.scenarios[0].request
        self.assertEqual(current.cashflow_request.positions[0].opening_balance, D("12000000"))
        self.assertEqual(current.cashflow_request.positions[0].terms.reference_principal, D("12000000"))
        self.assertEqual(current.exposures[0].par, D("12000000"))
        self.assertEqual(current.cashflow_request.purchases[0].par, D("12000000"))
        self.assertEqual(current.cashflow_request.purchases[0].accrued_interest, D("148.14"))
        self.assertEqual(batch.scenarios[0].result.cashflows.cashflows[0].principal_repayment, D("1200000"))
        self.assertEqual(baseline.cashflow_request.positions[0].terms.reference_principal, D("10000000"))

    def test_reserve_and_upfront_fees_are_both_funded_and_reserve_is_projected(self):
        scenario = ScenarioDefinition("FUNDING", (edit("CONTROL", "cash_reserve", D("60000")), edit("CONTROL", "upfront_fees", D("105000"))))
        batch = ScenarioRunner().run(request(), (scenario,))
        current = batch.scenarios[0]
        self.assertEqual(current.request.clo_terms.initial_reserve, D("60000"))
        self.assertEqual(current.request.cashflow_request.cash_reserve, D("60000"))
        self.assertEqual(comparison(current, "EQUITY_CASH_FUNDING").delta, D("15000"))
        self.assertEqual(current.result.clo.periods[0].reserve_opening, D("60000"))
        self.assertEqual(current.result.clo.periods[-1].equity_from_reserve, D("60000"))

    def test_recurring_fee_edits_flow_through_actual_cashwaterfall(self):
        changes = (edit("CONTROL", "senior_management_fee_bps", D(10)),
                   edit("CONTROL", "subordinated_management_fee_bps", D(20)),
                   edit("CONTROL", "annual_senior_expenses", D("11000")))
        batch = ScenarioRunner().run(request(), (ScenarioDefinition("FEES", changes),))
        current = batch.scenarios[0]
        self.assertEqual(comparison(current, "EQUITY_CASH_FUNDING").delta, D(0))
        self.assertLess(comparison(current, "TOTAL_EQUITY_DISTRIBUTIONS").delta, 0)
        self.assertLess(comparison(current, "EQUITY_IRR").delta, 0)
        self.assertGreater(current.result.clo.periods[0].senior_expenses_paid, batch.baseline.clo.periods[0].senior_expenses_paid)

    def test_maturity_edit_changes_both_projection_and_analysis_and_dates_outer_join(self):
        batch = ScenarioRunner().run(request(), (ScenarioDefinition("LONGER", (edit("ASSET", "maturity_date", date(2028, 11, 20)),)),))
        current = batch.scenarios[0]
        self.assertEqual(current.request.exposures[0].maturity_date, date(2028, 11, 20))
        self.assertGreater(comparison(current, "WAL_YEARS", "OPENING_METRIC").delta, 0)
        absent = [row for row in current.period_comparisons if row.baseline_status == "NOT_PRESENT"]
        self.assertTrue(absent)
        self.assertTrue(all(row.baseline_value is None and row.delta is None and row.delta_status == "UNAVAILABLE" for row in absent))

    def test_independent_scenarios_never_accumulate_edits(self):
        baseline = request()
        unchanged = repr(baseline)
        batch = ScenarioRunner().run(baseline, (
            ScenarioDefinition("PRICE", (edit("ASSET", "clean_price_pct", D(99)),)),
            ScenarioDefinition("MARGIN", (edit("ASSET", "spread_bps", D(900)),)),
        ))
        first, second = batch.scenarios
        self.assertEqual(second.request.cashflow_request.purchases[0].clean_price_pct, D(100))
        self.assertEqual(first.request.cashflow_request.positions[0].terms.spread_bps, D(800))
        self.assertEqual(comparison(second, "EQUITY_CASH_FUNDING").delta, D(0))
        self.assertEqual(repr(baseline), unchanged)
        self.assertIs(first.request.cashflow_request.rate_provider, baseline.cashflow_request.rate_provider)
        self.assertIs(second.request.cashflow_request.rate_provider, baseline.cashflow_request.rate_provider)
        with self.assertRaises(FrozenInstanceError):
            first.request.notes = ()

    def test_unavailable_warf_and_cashflow_only_returns_never_become_zero(self):
        baseline = replace(request(), clo_terms=None, notes=())
        batch = ScenarioRunner().run(baseline, (ScenarioDefinition("NOOP"),))
        current = batch.scenarios[0]
        for metric, scope in (("WARF", "OPENING_METRIC"), ("EQUITY_IRR", "MODEL"), ("EQUITY_MOIC", "MODEL")):
            row = comparison(current, metric, scope)
            self.assertIsNone(row.baseline_value)
            self.assertIsNone(row.scenario_value)
            self.assertIsNone(row.delta)
            self.assertEqual(row.delta_status, "UNAVAILABLE")
        self.assertEqual(current.period_comparisons, ())

    def test_fixed_rate_edits_are_supported_but_coupon_type_switches_are_explicitly_rejected(self):
        batch = ScenarioRunner().run(request(fixed=True), (ScenarioDefinition("FIXED", (
            edit("ASSET", "fixed_rate", D(".11")), edit("NOTE", "fixed_rate", D(".055")))),))
        current = batch.scenarios[0]
        self.assertEqual(current.request.cashflow_request.positions[0].terms.fixed_rate, D(".11"))
        self.assertEqual(current.request.notes[0].fixed_rate, D(".055"))
        for target, field, value in (("ASSET", "spread_bps", D(0)), ("NOTE", "index_floor", None)):
            with self.subTest(target=target, field=field), self.assertRaises(ScenarioExecutionError):
                ScenarioRunner().run(request(fixed=True), (ScenarioDefinition("BAD_COUPON", (edit(target, field, value),)),))
        with self.assertRaises(ScenarioExecutionError):
            ScenarioRunner().run(request(), (ScenarioDefinition("BAD_FIXED", (edit("ASSET", "fixed_rate", D(".10")),)),))

    def test_explicit_threshold_and_floor_removal(self):
        baseline = request()
        baseline = replace(baseline, notes=(replace(baseline.notes[0], index_floor=D(".03")),))
        batch = ScenarioRunner().run(baseline, (ScenarioDefinition("NO_GATES", (
            edit("NOTE", "oc_minimum", None), edit("NOTE", "ic_minimum", None), edit("NOTE", "index_floor", None))),))
        current = batch.scenarios[0]
        self.assertIsNone(current.request.notes[0].oc_minimum)
        self.assertIsNone(current.request.notes[0].ic_minimum)
        self.assertIsNone(current.request.notes[0].index_floor)
        headrooms = [row for row in current.period_comparisons if row.metric.endswith("GATE_HEADROOM")]
        self.assertTrue(headrooms)
        self.assertTrue(all(row.scenario_value is None and row.delta is None for row in headrooms))

    def test_invalid_schema_types_names_and_duplicate_edit_reject(self):
        for constructor in (
            lambda: ScenarioEdit("ASSET", "L1", "par", D(1)),
            lambda: edit("ASSET", "currency", D(1)),
            lambda: edit("ASSET", "par", 10.0),
            lambda: edit("ASSET", "par", True),
            lambda: edit("ASSET", "par", None),
            lambda: edit("ASSET", "maturity_date", datetime(2028, 11, 20)),
            lambda: edit("CONTROL", "cash_reserve", D(10), "WRONG"),
            lambda: ScenarioDefinition("BASELINE"),
            lambda: ScenarioDefinition("baseline"),
            lambda: ScenarioDefinition(" PADDED "),
            lambda: ScenarioDefinition("DUP", (edit("ASSET", "par", D(1)), edit("ASSET", "par", D(2)))),
            lambda: ScenarioDefinition("LIST", []),
        ):
            with self.subTest(constructor=constructor), self.assertRaises(ValueError):
                constructor()
        with self.assertRaises(ValueError):
            ScenarioRunner().run(request(), (ScenarioDefinition("CASE"), ScenarioDefinition("case")))

    def test_unknown_id_zero_par_and_invalid_domain_edits_identify_scenario(self):
        for alteration in (edit("ASSET", "par", D(0)), edit("NOTE", "par", D(0)),
                           edit("ASSET", "par", D(1), "MISSING"), edit("NOTE", "par", D(1), "MISSING"),
                           edit("CONTROL", "cash_reserve", D("-.01")),
                           edit("ASSET", "maturity_date", CLOSE)):
            with self.subTest(alteration=alteration), self.assertRaisesRegex(ScenarioExecutionError, "Scenario INVALID"):
                ScenarioRunner().run(request(), (ScenarioDefinition("INVALID", (alteration,)),))

    def test_failure_does_not_return_successful_subset_or_invent_overfunding_use(self):
        with self.assertRaisesRegex(ScenarioExecutionError, "Scenario OVERFUNDING"):
            ScenarioRunner().run(request(), (ScenarioDefinition("VALID"),
                ScenarioDefinition("OVERFUNDING", (edit("NOTE", "par", D("20000000")),))))

    def test_unresolved_scenario_reports_projection_status_and_no_invented_irr(self):
        batch = ScenarioRunner().run(request(), (ScenarioDefinition("EARLY_FINAL", (
            edit("CONTROL", "legal_final_date", date(2027, 2, 20)),)),))
        current = batch.scenarios[0]
        status = comparison(current, "CLO_STATUS")
        self.assertEqual(status.baseline_status, "COMPLETED")
        self.assertEqual(status.scenario_status, "LEGAL_FINAL_UNRESOLVED")
        returns = comparison(current, "EQUITY_IRR")
        self.assertIsNotNone(returns.baseline_value)
        self.assertIsNone(returns.scenario_value)
        self.assertIsNone(returns.delta)
        self.assertEqual(returns.delta_status, "UNAVAILABLE")

    def test_limit_with_missing_agency_factor_is_reported_unavailable(self):
        baseline = request()
        baseline = replace(baseline, limits=(*baseline.limits, LimitSpec("UNKNOWN", "WARF", D(1))))
        batch = ScenarioRunner().run(baseline, (ScenarioDefinition("NOOP"),))
        row = comparison(batch.scenarios[0], "HEADROOM", "OPENING_LIMIT", "UNKNOWN")
        self.assertEqual(row.unit, "rating_factor")
        self.assertEqual(row.baseline_status, "UNAVAILABLE")
        self.assertIsNone(row.delta)

    def test_edits_to_price_and_par_commute_and_keep_partial_holding_scale(self):
        baseline = request(linear=True)
        cash = baseline.cashflow_request
        position = replace(cash.positions[0], terms=replace(cash.positions[0].terms, reference_principal=D("20000000")))
        baseline = replace(baseline, cashflow_request=replace(cash, positions=(position,)))
        edits = (edit("ASSET", "par", D("12000000")), edit("ASSET", "clean_price_pct", D(99)))
        batch = ScenarioRunner().run(baseline, (ScenarioDefinition("FORWARD", edits), ScenarioDefinition("REVERSED", tuple(reversed(edits)))))
        forward, reversed_edits = batch.scenarios
        self.assertEqual(forward.request, reversed_edits.request)
        self.assertEqual(forward.request.cashflow_request.positions[0].terms.reference_principal, D("24000000"))
        self.assertEqual(forward.result.cashflows.cashflows[0].principal_repayment, D("2400000"))
        self.assertEqual(forward.result.clo, reversed_edits.result.clo)

    def test_par_edit_scales_absolute_instalments_and_annuity_balloon(self):
        for kind in (AmortizationType.LINEAR_AMOUNT, AmortizationType.ACCELERATED, AmortizationType.ANNUITY):
            with self.subTest(kind=kind):
                baseline = request()
                cash = baseline.cashflow_request
                terms = replace(cash.positions[0].terms, amortization_type=kind,
                    scheduled_principal_amount=None if kind is AmortizationType.ANNUITY else D("2000000"),
                    amortization_growth=D(".1") if kind is AmortizationType.ACCELERATED else None,
                    balloon_amount=D("2000000"))
                baseline = replace(baseline, cashflow_request=replace(cash, positions=(replace(cash.positions[0], terms=terms),)))
                batch = ScenarioRunner().run(baseline, (ScenarioDefinition("ABSOLUTE", (edit("ASSET", "par", D("12000000")),)),))
                current = batch.scenarios[0]
                resized = current.request.cashflow_request.positions[0].terms
                self.assertEqual(resized.balloon_amount, D("2400000"))
                self.assertEqual(resized.scheduled_principal_amount, None if kind is AmortizationType.ANNUITY else D("2400000"))
                self.assertEqual(resized.amortization_growth, terms.amortization_growth)
                self.assertEqual(current.result.cashflows.total_principal, D("12000000"))
                self.assertEqual(terms.balloon_amount, D("2000000"))

    def test_bespoke_par_resize_allocates_fractional_cents_and_preserves_dates(self):
        baseline = request()
        cash = baseline.cashflow_request
        dates = (date(2027, 2, 20), date(2027, 5, 20), date(2027, 8, 20), MATURITY)
        schedule = tuple(PrincipalScheduleEntry(day, D("2500000")) for day in dates)
        terms = replace(cash.positions[0].terms, amortization_type=AmortizationType.BESPOKE, principal_schedule=schedule)
        baseline = replace(baseline, cashflow_request=replace(cash, positions=(replace(cash.positions[0], terms=terms),)))
        batch = ScenarioRunner().run(baseline, (ScenarioDefinition("CENT_RESIZE", (edit("ASSET", "par", D("10000000.02")),)),))
        current = batch.scenarios[0]
        resized = current.request.cashflow_request.positions[0].terms.principal_schedule
        # Each exact share gains half a cent. Allocate the two cents to the
        # earliest dates, retaining total par without a hidden maturity sweep.
        self.assertEqual(tuple(row.amount for row in resized), (D("2500000.01"), D("2500000.01"), D("2500000"), D("2500000")))
        self.assertEqual(tuple(row.payment_date for row in resized), dates)
        self.assertEqual(current.result.cashflows.total_principal, D("10000000.02"))
        self.assertEqual(tuple(row.amount for row in terms.principal_schedule), (D("2500000"),) * 4)
        with self.assertRaisesRegex(ScenarioExecutionError, "BESPOKE requires an explicit maturity schedule entry"):
            ScenarioRunner().run(baseline, (ScenarioDefinition("MOVED_MATURITY", (edit("ASSET", "maturity_date", date(2028, 11, 20)),)),))

    def test_bespoke_resize_never_allocates_residual_to_zero_schedule_entry(self):
        baseline = request()
        cash = baseline.cashflow_request
        dates = (date(2027, 2, 20), date(2027, 5, 20), date(2027, 8, 20), MATURITY)
        schedule = tuple(PrincipalScheduleEntry(day, amount) for day, amount in zip(dates, (D(0), D("5000000"), D(0), D("5000000")), strict=True))
        terms = replace(cash.positions[0].terms, amortization_type=AmortizationType.BESPOKE, principal_schedule=schedule)
        baseline = replace(baseline, cashflow_request=replace(cash, positions=(replace(cash.positions[0], terms=terms),)))
        batch = ScenarioRunner().run(baseline, (ScenarioDefinition("ZERO_ENTRIES", (edit("ASSET", "par", D("10000000.01")),)),))
        resized = batch.scenarios[0].request.cashflow_request.positions[0].terms.principal_schedule
        self.assertEqual(tuple(row.amount for row in resized), (D(0), D("5000000.01"), D(0), D("5000000")))

    def test_comparison_is_independent_of_callers_decimal_precision(self):
        baseline = request()
        definitions = (ScenarioDefinition("PRICE", (edit("ASSET", "clean_price_pct", D("99.123456789")),)),)
        expected = ScenarioRunner().run(baseline, definitions)
        with localcontext() as caller:
            caller.prec = 6
            caller.traps[Inexact] = True
            actual = ScenarioRunner().run(baseline, definitions)
        self.assertEqual(actual.scenarios[0].comparisons, expected.scenarios[0].comparisons)
        self.assertEqual(actual.scenarios[0].period_comparisons, expected.scenarios[0].period_comparisons)

    def test_transport_field_metadata_is_immutable(self):
        self.assertEqual(SCENARIO_FIELD_TYPES[ScenarioTarget.ASSET]["maturity_date"], "date")
        self.assertEqual(SCENARIO_FIELD_TYPES[ScenarioTarget.NOTE]["oc_minimum"], "optional_decimal")
        with self.assertRaises(TypeError):
            SCENARIO_FIELD_TYPES[ScenarioTarget.ASSET]["par"] = "float"


if __name__ == "__main__":
    unittest.main()
