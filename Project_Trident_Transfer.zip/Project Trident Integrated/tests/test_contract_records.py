"""Semantic adapter transport and cash-pay CLO cross-integration.

Use one cloned synthetic fixture row, scaled to EUR1,000, and one EUR800 note.
Independent nominal 30E/360 quarters give 20 asset interest and 8 note interest
in period one; expected principal amounts are hand contract controls.
"""

import csv
import unittest
from datetime import date
from decimal import Decimal, Inexact, ROUND_DOWN, localcontext
from fractions import Fraction
from pathlib import Path

from trident.adapters.model_records import model_request_from_records
from trident.adapters.records import position_from_record, run_request_from_records
from trident.adapters.scenario_records import scenarios_from_records
from trident.analysis import MetricStatus, ReturnStatus
from trident.application.clo_services import TridentModelService
from trident.application.scenarios import ScenarioTarget
from trident.clo.models import ProjectionStatus
from trident.conventions import DayCount, StubConvention
from trident.domain.models import AmortizationType, PrincipalScheduleEntry
from trident.market import FlatRateProvider

D = Decimal
EXAMPLE = Path(__file__).resolve().parents[1] / "data/examples/hybrid_500m"


def _first_csv(name: str) -> dict[str, object]:
    with (EXAMPLE / name).open(encoding="utf-8", newline="") as stream:
        return dict(next(csv.DictReader(stream)))


def _asset(**changes: object) -> dict[str, object]:
    row = _first_csv("assets.csv")
    row.update(
        loan_id="CONTRACT_LOAN", initial_par="1000", current_par="1000",
        maturity_date_unadjusted="2027-11-20", coupon_type="FIXED", fixed_rate="0.08",
        rate_index="", spread_bps="0", index_floor_bps="", day_count="30E/360",
        accrual_date_basis="UNADJUSTED", amortization_type="LINEAR_AMOUNT",
        amortization_fraction_initial_par_per_period="0", amortization_periods_remaining="4",
        amortization_first_date_unadjusted="2027-02-20", scheduled_principal_amount="100",
        amortization_growth="", balloon_amount="", first_payment_date_unadjusted="",
        last_regular_payment_date_unadjusted="", payment_lag_business_days="0",
        end_of_month=False, stub_convention="NONE", acquired_accrued_interest="0",
    )
    row.update(changes)
    return row


def _capital() -> tuple[dict[str, object], ...]:
    note = _first_csv("capital_stack.csv")
    note.update(
        class_id="A", nominal_amount="800", coupon_type="FIXED", fixed_rate="0.04",
        rate_index="", spread_bps="0", index_floor_bps="", day_count="30E/360",
        accrual_date_basis="UNADJUSTED", oc_minimum="", ic_minimum="",
    )
    residual = dict(note, class_id="EQ", instrument_type="EQUITY", nominal_amount="200")
    return note, residual


def _controls() -> dict[str, object]:
    return dict(
        mode="CLO_BASELINE", upfront_fees="0", cash_reserve="0", legal_final_date="2028-11-20",
        clo_frequency_months="3", senior_management_fee_bps="0", subordinated_management_fee_bps="0",
        annual_senior_expenses="0", clo_business_day_convention="MODIFIED_FOLLOWING",
        clo_accrual_date_basis="UNADJUSTED", clo_fixing_lag_business_days="2", clo_end_of_month=False,
        clo_stub_convention="NONE", collection_cutoff_business_days="0", reinvestment_strategy="NO_TRADES",
        reinvestment_end_date="2027-11-20",
    )


def _request(row: dict[str, object], principal_rows=()):
    return model_request_from_records(
        (row,), _capital(), FlatRateProvider({"EURIBOR_3M": D("0.025")}),
        controls=_controls(), factors=(), limits=(), provenance="SYNTHETIC_SMALL_CONTROL",
        principal_schedule_records=principal_rows,
    )


def _principal_row(value: str, amount: str, identifier="CONTRACT_LOAN") -> dict[str, object]:
    return {"loan_id": identifier, "payment_date_unadjusted": value, "amount": amount}


def _scenario_row(**changes: object) -> dict[str, object]:
    row = dict(scenario_id="PRICE", enabled=True, target="ASSET", identifier="CONTRACT_LOAN",
               field="clean_price_pct", value="99")
    row.update(changes)
    return row


class ContractRecordsTests(unittest.TestCase):
    def test_all_new_principal_policies_reach_the_same_clo_service(self) -> None:
        principal_rows = tuple(_principal_row(day, amount) for day, amount in (
            ("2027-02-20", "100"), ("2027-05-20", "200"), ("2027-08-20", "300"), ("2027-11-20", "400"),
        ))
        cases = (
            ("LINEAR_AMOUNT", {}, (), D(100)),
            ("ACCELERATED", {"amortization_growth": "1"}, (), D(100)),
            ("ANNUITY", {"scheduled_principal_amount": "", "balloon_amount": "0"}, (), D("242.62")),
            ("BESPOKE", {"scheduled_principal_amount": "", "amortization_first_date_unadjusted": ""}, principal_rows, D(100)),
        )
        for kind, extra, schedule, first_principal in cases:
            with self.subTest(kind=kind):
                request = _request(_asset(amortization_type=kind, **extra), schedule)
                result = TridentModelService().run(request)
                self.assertEqual(request.cashflow_request.positions[0].terms.amortization_type, AmortizationType(kind))
                self.assertEqual(result.cashflows.funding.collateral_par, D(1000))
                self.assertEqual(result.cashflows.funding.debt_proceeds, D(800))
                self.assertEqual(result.cashflows.funding.equity_cash_funding, D(200))
                self.assertEqual(result.cashflows.cashflows[0].principal_repayment, first_principal)
                self.assertEqual(result.cashflows.cashflows[0].cash_interest, D(20))
                self.assertEqual(sum((Fraction(row.principal_repayment) for row in result.cashflows.cashflows)), Fraction(1000))
                self.assertEqual(result.clo.periods[0].equity_from_interest, D(12))
                self.assertEqual(result.clo.periods[0].closing_collateral_par, D(1000) - first_principal)
                self.assertEqual(result.clo.status, ProjectionStatus.COMPLETED)
                self.assertTrue(result.clo.terminal_value_available)
                self.assertEqual(result.equity_irr.status, ReturnStatus.AVAILABLE)
                for field in ("final_collateral_par", "final_debt_par", "final_interest_cash", "final_principal_cash",
                              "final_pending_interest_cash", "final_pending_principal_cash", "final_reserve",
                              "final_senior_claims", "final_note_coupon_arrears", "final_subordinated_fee_arrears"):
                    self.assertEqual(getattr(result.clo, field), D(0), field)
                for period, snapshot in zip(result.clo.periods, result.portfolio_snapshots, strict=True):
                    self.assertEqual(period.cash_conservation_residual, D(0))
                    self.assertEqual(period.opening_collateral_par - period.received_asset_principal, period.closing_collateral_par)
                    self.assertEqual(period.opening_debt_par - period.debt_principal_from_interest - period.debt_principal_from_principal,
                                     period.closing_debt_par)
                    self.assertEqual(snapshot.total_par, period.closing_collateral_par)

    def test_analytical_wal_has_independent_dated_principal_controls(self) -> None:
        # Principal:100/100/100/700; modified-following cash dates independently specified.
        result = TridentModelService().run(_request(_asset()))
        dates = (date(2027, 2, 22), date(2027, 5, 20), date(2027, 8, 20), date(2027, 11, 22))
        self.assertEqual(tuple(row.payment_date for row in result.cashflows.cashflows), dates)
        weights = (100, 100, 100, 700)
        expected = sum((Fraction(weight * (day - date(2026, 11, 20)).days, 365_000)
                        for day, weight in zip(dates, weights, strict=True)), Fraction())
        metric = result.opening_portfolio.metric("WAL_YEARS")
        self.assertEqual(metric.status, MetricStatus.AVAILABLE)
        with localcontext() as precise:
            precise.prec = 64
            independent = D(expected.numerator) / D(expected.denominator)
            self.assertLess(abs(metric.value - independent), D("1e-32"))

    def test_principal_fields_are_typed_and_zero_balloon_survives_transport(self) -> None:
        position = position_from_record(_asset(
            amortization_type="ACCELERATED", amortization_growth="0.125", balloon_amount="0",
            first_payment_date_unadjusted="2027-02-20", last_regular_payment_date_unadjusted="2027-11-20",
        ))
        terms = position.terms
        self.assertEqual(terms.scheduled_principal_amount, D(100))
        self.assertEqual(terms.amortization_growth, D("0.125"))
        self.assertEqual(terms.balloon_amount, D(0))
        self.assertEqual(terms.amortization_start_date, date(2027, 2, 20))
        self.assertEqual(terms.first_payment_date, date(2027, 2, 20))
        self.assertEqual(terms.last_regular_payment_date, date(2027, 11, 20))

    def test_remaining_count_is_optional_and_counts_eligible_boundaries(self) -> None:
        row = _asset(amortization_first_date_unadjusted="2027-05-20", amortization_periods_remaining="3")
        position = position_from_record(row)
        self.assertEqual(position.terms.amortization_start_date, date(2027, 5, 20))
        position_from_record(dict(row, amortization_periods_remaining=""))
        position_from_record({name: value for name, value in row.items() if name != "amortization_periods_remaining"})
        with self.assertRaisesRegex(ValueError, "eligible principal periods"):
            position_from_record(dict(row, amortization_periods_remaining="4"))

    def test_front_stub_regular_anchor_and_30e_daycount_reach_typed_service(self) -> None:
        row = _asset(
            maturity_date_unadjusted="2027-10-15", stub_convention="SHORT_FIRST", schedule_anchor_day="15",
            first_payment_date_unadjusted="2027-01-15", last_regular_payment_date_unadjusted="2027-10-15",
            amortization_first_date_unadjusted="2027-01-15",
        )
        request = _request(row)
        self.assertEqual(request.cashflow_request.positions[0].terms.stub_convention, StubConvention.SHORT_FIRST)
        self.assertEqual(request.cashflow_request.positions[0].terms.day_count, DayCount.THIRTY_E_360)
        result = TridentModelService().run(request)
        self.assertEqual([cash.unadjusted_end for cash in result.cashflows.cashflows],
                         [date(2027, 1, 15), date(2027, 4, 15), date(2027, 7, 15), date(2027, 10, 15)])
        # Nominal 55/360 * 1000 * .08 = 12.222..., before first100principal.
        self.assertEqual(result.cashflows.cashflows[0].cash_interest, D("12.22"))
        self.assertEqual(result.cashflows.cashflows[0].principal_repayment, D(100))
        self.assertEqual(result.clo.status, ProjectionStatus.COMPLETED)
        with self.assertRaisesRegex(ValueError, "regular unadjusted schedule anchor"):
            position_from_record(dict(row, schedule_anchor_day="20"))

    def test_implicit_front_stub_anchor_uses_maturity_roll_day(self) -> None:
        row = _asset(maturity_date_unadjusted="2027-10-15", stub_convention="SHORT_FIRST", schedule_anchor_day="15",
                     amortization_first_date_unadjusted="", amortization_periods_remaining="")
        result = TridentModelService().run(_request(row))
        self.assertEqual(result.cashflows.cashflows[0].unadjusted_end, date(2027, 1, 15))
        with self.assertRaisesRegex(ValueError, "regular unadjusted schedule anchor"):
            position_from_record(dict(row, schedule_anchor_day="20"))

    def test_asset_floor_conversion_is_independent_of_caller_precision(self) -> None:
        row = _asset(coupon_type="FLOATING", fixed_rate="", spread_bps="300", rate_index="EURIBOR_3M",
                     index_floor_bps="123.456789")
        with localcontext() as caller:
            caller.prec = 2
            caller.rounding = ROUND_DOWN
            caller.traps[Inexact] = True
            parsed = position_from_record(row)
        self.assertEqual(parsed.terms.index_floor, D("0.0123456789"))

    def test_all_30day_variants_require_unambiguous_named_conventions(self) -> None:
        for value, expected in (("30/360.ISDA", DayCount.THIRTY_360_ISDA), ("THIRTY_360_ISDA", DayCount.THIRTY_360_ISDA),
                                ("30U/360.EOM", DayCount.THIRTY_U_360_EOM), ("30E/360", DayCount.THIRTY_E_360)):
            with self.subTest(value=value):
                self.assertEqual(position_from_record(_asset(day_count=value)).terms.day_count, expected)
        with self.assertRaises(ValueError):
            position_from_record(_asset(day_count="30/360"))

    def test_principal_rows_for_an_unselected_policy_are_rejected(self) -> None:
        for kind, values in (("LINEAR_AMOUNT", {}), ("ANNUITY", {"scheduled_principal_amount": "", "balloon_amount": "0"}),
                             ("BULLET", {"scheduled_principal_amount": "", "amortization_first_date_unadjusted": ""})):
            with self.subTest(kind=kind), self.assertRaisesRegex(ValueError, "not applicable"):
                _request(_asset(amortization_type=kind, **values), (_principal_row("2027-11-20", "1000"),))

    def test_principal_rows_reject_unknown_ids_duplicates_and_wrong_totals(self) -> None:
        row = _asset(amortization_type="BESPOKE", scheduled_principal_amount="", amortization_first_date_unadjusted="")
        invalid = (
            ((_principal_row("2027-11-20", "1000", "UNKNOWN"),), "unknown loan_id"),
            ((_principal_row("2027-11-20", "500"), _principal_row("2027-11-20", "500")), "strictly increasing"),
            ((_principal_row("2027-11-20", "999"),), "sum exactly"),
            ((_principal_row("2027-05-20", "1000"),), "maturity schedule entry"),
            ((dict(_principal_row("2027-11-20", "1000"), unexpected="ignored"),), "unregistered fields"),
        )
        for principal_rows, reason in invalid:
            with self.subTest(reason=reason), self.assertRaisesRegex(ValueError, reason):
                _request(row, principal_rows)

    def test_off_boundary_bespoke_dates_fail_before_any_model_result(self) -> None:
        row = _asset(amortization_type="BESPOKE", scheduled_principal_amount="", amortization_first_date_unadjusted="")
        request = _request(row, (_principal_row("2027-04-20", "100"), _principal_row("2027-11-20", "900")))
        with self.assertRaisesRegex(ValueError, "unadjusted accrual boundaries"):
            TridentModelService().run(request)

    def test_bespoke_table_groups_sorted_rows_without_affecting_other_assets(self) -> None:
        row = _asset(amortization_type="BESPOKE", scheduled_principal_amount="", amortization_first_date_unadjusted="")
        cash_request = run_request_from_records(
            (row,), _capital(), FlatRateProvider({"EURIBOR_3M": D("0.025")}),
            upfront_fees=D(0), cash_reserve=D(0), rate_provenance="TEST",
            principal_schedule_records=(_principal_row("2027-11-20", "900"), _principal_row("2027-02-20", "100")),
        )
        self.assertEqual(cash_request.positions[0].terms.principal_schedule, (
            PrincipalScheduleEntry(date(2027, 2, 20), D(100)), PrincipalScheduleEntry(date(2027, 11, 20), D(900)),
        ))

    def test_scenario_parser_uses_public_typed_fields_and_preserves_group_order(self) -> None:
        cases = scenarios_from_records((
            _scenario_row(),
            _scenario_row(scenario_id="CLEAR_GATE", target="NOTE", identifier="A", field="oc_minimum", value=""),
            _scenario_row(scenario_id="PRICE", target="CONTROL", identifier="DEAL", field="legal_final_date", value="2029-11-20"),
        ))
        self.assertEqual([case.scenario_id for case in cases], ["PRICE", "CLEAR_GATE"])
        self.assertEqual(cases[0].edits[0].value, D(99))
        self.assertIsInstance(cases[0].edits[0].value, Decimal)
        self.assertEqual(cases[0].edits[1].value, date(2029, 11, 20))
        self.assertEqual(cases[0].edits[1].target, ScenarioTarget.CONTROL)
        self.assertIsNone(cases[1].edits[0].value)

    def test_scenario_parser_ignores_disabled_rows_before_required_fields(self) -> None:
        cases = scenarios_from_records((_scenario_row(), {"enabled": False}))
        self.assertEqual(len(cases), 1)
        self.assertEqual(len(cases[0].edits), 1)

    def test_scenario_parser_rejects_duplicate_edits_blank_required_and_untyped_values(self) -> None:
        invalid = (
            (_scenario_row(), _scenario_row(value="98")),
            (_scenario_row(value=""),),
            (_scenario_row(value=True),),
            (_scenario_row(field="frequency_months", value="3"),),
            (_scenario_row(target="CONTROL", identifier="A", field="cash_reserve", value="0"),),
            (_scenario_row(target="CONTROL", identifier="DEAL", field="legal_final_date", value=""),),
        )
        for rows in invalid:
            with self.subTest(rows=rows), self.assertRaises(ValueError):
                scenarios_from_records(rows)


if __name__ == "__main__":
    unittest.main()
