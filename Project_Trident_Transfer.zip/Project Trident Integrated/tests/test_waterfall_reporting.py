"""Independent class cash ledgers and adversarial joined-report checks."""

import unittest
from dataclasses import FrozenInstanceError, replace
from decimal import Decimal, Inexact, localcontext

from trident.clo import CoverageStatus, TranchePeriodStatus, report_tranche_periods, report_equity_periods
from trident.domain.models import InputValidationError
from test_clo import CLOSE, FIRST, SECOND, note, receipt, run


D = Decimal


class TrancheReportingTests(unittest.TestCase):
    def setUp(self) -> None:
        self.projection = run(
            (receipt("L", 1, CLOSE, FIRST, "100", "40", "5"),
             receipt("L", 2, FIRST, SECOND, "60", "60", "5")),
            (note("B", 2, "20", "0.10"), note("A", 1, "80", "0.10")),
        )

    def test_every_class_every_emitted_period_and_order(self) -> None:
        rows = report_tranche_periods(self.projection)
        self.assertEqual([(row.period_number, row.class_id) for row in rows],
                         [(1, "A"), (1, "B"), (2, "A"), (2, "B")])
        self.assertEqual(rows[0].accrual_start, CLOSE)
        self.assertEqual(rows[0].accrual_end, FIRST)
        self.assertEqual(rows[2].accrual_start, FIRST)

    def test_hand_cash_totals_and_class_cumulative_amounts(self) -> None:
        first_a, first_b, second_a, second_b = report_tranche_periods(self.projection)
        self.assertEqual(first_a.total_coupon_claim, D("2"))
        self.assertEqual(first_a.total_coupon_paid, D("2"))
        self.assertEqual(first_a.total_principal_paid, D("40"))
        self.assertEqual(first_a.total_cash_paid, D("42"))
        self.assertEqual(first_b.total_cash_paid, D("0.50"))
        # Second A coupon 40 ×10%×91/360 posts 1.01, then 40 principal.
        self.assertEqual(second_a.total_cash_paid, D("41.01"))
        self.assertEqual(second_a.cumulative_coupon_paid, D("3.01"))
        self.assertEqual(second_a.cumulative_principal_paid, D("80"))
        self.assertEqual(second_a.cumulative_cash_paid, D("83.01"))
        self.assertEqual(second_b.cumulative_cash_paid, D("21.01"))
        self.assertIs(first_a.class_status, TranchePeriodStatus.ACTIVE)
        self.assertIs(second_a.class_status, TranchePeriodStatus.REDEEMED)

    def test_missing_junior_gate_is_not_fabricated_pass(self) -> None:
        projection = run(
            (receipt("L", 1, CLOSE, FIRST, "100", "0.20", "40"),
             receipt("L", 2, FIRST, SECOND, "99.80", "99.80", "5")),
            (note("A", 1, "80", "0.04", oc_minimum=D("1.5")), note("B", 2, "20", "0.04")),
        )
        senior, junior = report_tranche_periods(projection)[:2]
        self.assertTrue(senior.gate_evaluated)
        self.assertIs(senior.gate_oc_status, CoverageStatus.FAIL)
        self.assertEqual(senior.gate_minimum_interest_repayment_for_oc, D("13.34"))
        self.assertIs(senior.post_diversion_oc_status, CoverageStatus.PASS)
        self.assertTrue(junior.interest_gate_blocked)
        self.assertFalse(junior.gate_evaluated)
        self.assertIsNone(junior.gate_oc_status)
        self.assertIsNone(junior.gate_ic_denominator)
        self.assertTrue(junior.post_diversion_evaluated)
        self.assertEqual(junior.coupon_paid_from_principal, D("0.20"))
        self.assertEqual(junior.total_coupon_claim, D("0.20"))

    def test_coupon_arrears_status_and_truncated_projection_no_future_rows(self) -> None:
        projection = run(
            (receipt("L", 1, CLOSE, FIRST, "100", "0", "0"),
             receipt("L", 2, FIRST, SECOND, "100", "100", "5")), (note(rate="0.08"),),
        )
        (row,) = report_tranche_periods(projection)
        self.assertIs(row.class_status, TranchePeriodStatus.COUPON_ARREARS)
        self.assertEqual(row.closing_coupon_arrears, D("2"))
        self.assertEqual(row.total_cash_paid, D(0))
        self.assertEqual(row.payment_date, FIRST)

    def test_source_is_immutable_and_not_rewritten(self) -> None:
        original = self.projection
        rows = report_tranche_periods(original)
        self.assertEqual(original, self.projection)
        with self.assertRaises(FrozenInstanceError):
            rows[0].closing_balance = D(0)

    def test_low_caller_precision_and_traps_do_not_change_cash(self) -> None:
        expected = report_tranche_periods(self.projection)
        with localcontext() as context:
            context.prec = 2
            context.traps[Inexact] = True
            self.assertEqual(report_tranche_periods(self.projection), expected)

    def test_duplicate_missing_or_orphan_rows_are_rejected(self) -> None:
        snapshots = self.projection.tranche_periods
        for modified in (
            snapshots + snapshots[:1], snapshots[:-1],
            (*snapshots[:-1], replace(snapshots[-1], period_number=3)),
        ):
            with self.subTest(modified=modified), self.assertRaises(InputValidationError):
                report_tranche_periods(replace(self.projection, tranche_periods=modified))

    def test_date_or_priority_changes_are_rejected(self) -> None:
        snapshots = self.projection.tranche_periods
        for changed in (replace(snapshots[-1], payment_date=FIRST),
                        replace(snapshots[-1], payment_priority=3)):
            with self.subTest(changed=changed), self.assertRaises(InputValidationError):
                report_tranche_periods(replace(self.projection, tranche_periods=(*snapshots[:-1], changed)))

    def test_duplicate_unknown_or_orphan_tests_are_rejected(self) -> None:
        tests = self.projection.coverage_tests
        for modified in (
            tests + tests[:1], (*tests, replace(tests[0], stage="GUESS")),
            (*tests, replace(tests[0], class_id="ORPHAN")),
        ):
            with self.subTest(modified=modified), self.assertRaises(InputValidationError):
                report_tranche_periods(replace(self.projection, coverage_tests=modified))

    def test_missing_period_end_or_missing_active_gate_is_rejected(self) -> None:
        tests = self.projection.coverage_tests
        for stage in ("PERIOD_END", "GATE"):
            filtered = tuple(test for test in tests if not (test.period_number == 1 and test.class_id == "A" and test.stage == stage))
            with self.subTest(stage=stage), self.assertRaises(InputValidationError):
                report_tranche_periods(replace(self.projection, coverage_tests=filtered))

    def test_forged_cash_bridge_and_aggregate_totals_are_rejected(self) -> None:
        snapshots = self.projection.tranche_periods
        modified = (*snapshots[:-1], replace(snapshots[-1], principal_from_principal=D("19.99")))
        with self.assertRaises(InputValidationError):
            report_tranche_periods(replace(self.projection, tranche_periods=modified))
        periods = self.projection.periods
        with self.assertRaises(InputValidationError):
            report_tranche_periods(replace(self.projection, periods=(replace(periods[0], note_coupon_paid=D("2.49")), periods[1])))

    def test_empty_or_missing_period_is_rejected(self) -> None:
        for periods in ((), (self.projection.periods[1],)):
            with self.subTest(periods=periods), self.assertRaises(InputValidationError):
                report_tranche_periods(replace(self.projection, periods=periods))

    def test_wrong_input_type_rejected(self) -> None:
        with self.assertRaises(InputValidationError):
            report_tranche_periods(None)


class ResidualEquityReportingTests(unittest.TestCase):
    def setUp(self) -> None:
        self.projection = run(
            (receipt("L", 1, CLOSE, FIRST, "100", "40", "5"),
             receipt("L", 2, FIRST, SECOND, "60", "60", "5")),
            (note("B", 2, "20", "0.10"), note("A", 1, "80", "0.10")), initial_reserve=D("10"),
        )

    def report(self, **kwargs):
        values = dict(class_id="EQ", payment_priority=3, equity_cash_funding=D("10"))
        values.update(kwargs)
        return report_equity_periods(self.projection, **values)

    def test_equity_every_period_with_separate_cash_sources_and_actual_funding(self) -> None:
        first, second = self.report()
        self.assertEqual(first.class_id, "EQ")
        self.assertEqual(first.instrument_type, "EQUITY")
        self.assertEqual(first.class_status, "RESIDUAL")
        self.assertEqual(first.equity_from_interest, D("2.50"))
        self.assertEqual(first.equity_from_principal, D(0))
        self.assertEqual(first.equity_from_reserve, D(0))
        self.assertEqual(first.total_cash_paid, D("2.50"))
        self.assertEqual(first.cumulative_equity_distribution_multiple, D("0.25"))
        self.assertEqual(second.equity_from_interest, D("3.48"))
        self.assertEqual(second.equity_from_reserve, D("10"))
        self.assertEqual(second.total_cash_paid, D("13.48"))
        self.assertEqual(second.cumulative_cash_paid, D("15.98"))
        self.assertEqual(second.cumulative_equity_distribution_multiple, D("1.598"))
        self.assertEqual(first.equity_cash_funding, D("10"))
        self.assertEqual(second.equity_cash_funding, D("10"))

    def test_zero_funding_does_not_fabricate_distribution_multiple(self) -> None:
        rows = self.report(equity_cash_funding=D(0))
        self.assertTrue(all(row.cumulative_equity_distribution_multiple is None for row in rows))
        self.assertEqual(rows[-1].cumulative_cash_paid, D("15.98"))

    def test_zero_distribution_period_is_not_omitted(self) -> None:
        projection = run((receipt("L", 1, CLOSE, FIRST, "100", "40", "0"),
                          receipt("L", 2, FIRST, SECOND, "60", "60", "5")), (note(par="90"),))
        first, second = report_equity_periods(projection, class_id="EQ", payment_priority=2, equity_cash_funding=D("10"))
        self.assertEqual(first.total_cash_paid, D(0))
        self.assertEqual(second.total_cash_paid, D("15"))

    def test_no_debt_balance_coupon_or_coverage_is_invented_for_equity(self) -> None:
        (row, _) = self.report()
        self.assertFalse(hasattr(row, "opening_balance"))
        self.assertFalse(hasattr(row, "current_coupon_due"))
        self.assertFalse(hasattr(row, "period_end_oc_status"))

    def test_invalid_identity_priority_or_funding_is_rejected(self) -> None:
        for kwargs in (
            {"class_id": " A"}, {"class_id": "A"}, {"payment_priority": 1},
            {"payment_priority": True}, {"equity_cash_funding": D("-1")},
            {"equity_cash_funding": 10.0},
        ):
            with self.subTest(kwargs=kwargs), self.assertRaises(InputValidationError):
                self.report(**kwargs)

    def test_dated_ledger_or_aggregate_mismatch_is_rejected(self) -> None:
        for projection in (
            replace(self.projection, equity_cashflows=self.projection.equity_cashflows[:-1]),
            replace(self.projection, total_equity_distributions=D("15.97")),
        ):
            with self.subTest(projection=projection), self.assertRaises(InputValidationError):
                report_equity_periods(projection, class_id="EQ", payment_priority=3, equity_cash_funding=D("10"))

    def test_independent_of_caller_decimal_precision_and_traps(self) -> None:
        expected = self.report()
        with localcontext() as context:
            context.prec = 2
            context.traps[Inexact] = True
            self.assertEqual(self.report(), expected)


if __name__ == "__main__":
    unittest.main()
