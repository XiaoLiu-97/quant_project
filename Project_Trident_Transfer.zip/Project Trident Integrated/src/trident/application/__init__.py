"""Application services compose domain engines and return immutable results."""
